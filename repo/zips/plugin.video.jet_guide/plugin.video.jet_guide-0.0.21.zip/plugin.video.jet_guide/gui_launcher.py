import sys
import os

import xbmc
import xbmcgui
import xbmcaddon

from analytics import track, track_feature, flush_session
from changelog_window import check_and_show_changelog

ADDON = xbmcaddon.Addon()
ADDONNAME = ADDON.getAddonInfo('name')
ADDONID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')


def main():
    try:
        track_feature(feature="home", action="launch_script")

        xbmc.executebuiltin('Dialog.Close(all)')
        xbmc.sleep(200)

        check_and_show_changelog(ADDON_PATH)

        from tenbuttons import show_ten_buttons
        show_ten_buttons()

    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Failed to start {ADDONNAME}: {str(e)}")

    finally:
        if not xbmc.Player().isPlaying():
            flush_session()


if __name__ == '__main__':
    main()
