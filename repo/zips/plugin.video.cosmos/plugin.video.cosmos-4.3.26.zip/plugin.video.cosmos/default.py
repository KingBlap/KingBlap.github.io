# -*- coding: utf-8 -*-
"""
C.O.S.M.O.S - Cinema On-demand Streaming Multimedia Operating System

This addon and code was created by Zeus768 for Cosmos.
Author: Zeus768 (Enigma also contributed)
Website: https://github.com/zeus768

Kodi plugin entry point.

NOTE: The default BASE_URL for the menu can be changed here or via the addon
settings (Settings -> General -> Menu Base URL). The setting, if non-empty,
always overrides this constant.
"""
import sys
import traceback

import xbmc
import xbmcgui

# Default menu base URL (pastebin RAW). Change this line to point the addon
# at a different menu feed, or override via the addon settings panel.
BASE_URL = "https://team-enigma.xyz/extras/home.xml"

if __name__ == '__main__':
    try:
        # Import inside the guarded startup path so a missing optional Kodi
        # module or a syntax/import regression produces a useful notification
        # instead of an unhandled traceback with no user-facing feedback.
        from resources.lib import cosmos
        cosmos.run(sys.argv, default_base_url=BASE_URL)
    except Exception as e:
        xbmc.log(
            f"COSMOS: Fatal error during addon startup: {e}\n{traceback.format_exc()}",
            xbmc.LOGERROR,
        )
        xbmcgui.Dialog().notification("C.O.S.M.O.S Error", "Addon failed to start. Check Kodi log for details.", xbmcgui.NOTIFICATION_ERROR, 5000)
