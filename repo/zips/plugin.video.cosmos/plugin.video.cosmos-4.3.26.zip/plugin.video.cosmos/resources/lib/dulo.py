"""Discover Dulo movie/episode servers and resolve them to native Kodi media."""
import re
import json
import time
from html import unescape
from html.parser import HTMLParser
from urllib.parse import parse_qsl, unquote, urljoin, urlsplit
from urllib.request import Request, urlopen

from . import lulustream

BASE = 'https://dulo.vg'
HEADERS = {'User-Agent': lulustream.UA, 'Referer': BASE + '/'}


def watch_url(tmdb_id, kind='movie', season=0, episode=0):
    if not str(tmdb_id).isdigit() or int(tmdb_id) < 1 or kind not in ('movie', 'tv'):
        raise ValueError('Invalid Dulo media identifier')
    path = '/watch/%s/%s' % (kind, tmdb_id)
    if kind == 'tv':
        season, episode = int(season), int(episode)
        if season < 0 or episode < 1:
            raise ValueError('Invalid Dulo episode')
        path += '/%d/%d' % (season, episode)
    return BASE + path


class _Servers(HTMLParser):
    def __init__(self, body):
        super().__init__(convert_charrefs=True)
        self.servers = []
        self.feed(body)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'a' and 'sd-server' in attrs.get('class', '').split():
            self.servers.append(attrs)


def servers(body, tmdb_id, kind='movie', season=0, episode=0):
    """Read the site's server pills; reject a different title or episode."""
    expected = urlsplit(watch_url(tmdb_id, kind, season, episode)).path
    suffix = '/%s/%s' % (kind, tmdb_id)
    if kind == 'tv':
        suffix += '/%d/%d' % (int(season), int(episode))
    result, seen = [], set()
    for attrs in _Servers(body).servers:
        route = urlsplit(urljoin(BASE, attrs.get('href', '')))
        url = unescape(attrs.get('data-embed', ''))
        parts = urlsplit(url)
        host = parts.hostname or ''
        host = host[4:] if host.startswith('www.') else host
        if host in ('cdn.toffee.bz', 'vidlink.pro',
                    'player.videasy.net', 'player.videasy.to'):
            continue
        if (route.hostname != 'dulo.vg' or route.path != expected
                or parts.scheme not in ('http', 'https') or not parts.hostname
                or parts.username or url in seen):
            continue
        # MoviesAPI uses /tv/<id>-<season>-<episode>; the remaining
        # observed servers use /[embed/]movie/<id> or /tv/<id>/<s>/<e>.
        alternate = '/tv/%s-%d-%d' % (tmdb_id, int(season), int(episode)) if kind == 'tv' else ''
        if not (parts.path.rstrip('/').endswith(suffix)
                or alternate and parts.path.rstrip('/') == alternate):
            continue
        number = dict(parse_qsl(route.query)).get('server', str(len(result) + 1))
        host = parts.hostname
        host = host[4:] if host.startswith('www.') else host
        result.append({'url': url, 'label': 'Server %s / %s' % (number, host)})
        seen.add(url)
    return result


def discover(tmdb_id, kind='movie', season=0, episode=0):
    url = watch_url(tmdb_id, kind, season, episode)
    with urlopen(Request(url, headers=HEADERS), timeout=15) as response:
        raw = response.read(2 * 1024 * 1024 + 1)
        final = urlsplit(response.geturl())
    if (len(raw) > 2 * 1024 * 1024 or final.hostname != 'dulo.vg'
            or final.path != urlsplit(url).path):
        return []
    return servers(raw.decode('utf-8', 'replace'), tmdb_id, kind, season, episode)


def _candidates(body, page):
    result = lulustream._candidates(body, page)
    # Some Dulo servers expose var src = "proxy.php?url=..." rather
    # than a player source object. Keep the proxy URL and its signed query.
    for match in re.finditer(r'''\b(?:var|let|const)\s+(?:src|source|file)\s*=\s*(["'])(.*?)\1''', body):
        value = unescape(lulustream._unescape_js(match[2]))
        url = urljoin(page, value)
        parts = urlsplit(url)
        decoded = unquote(unquote(url)).lower()
        kind = 'hls' if '.m3u8' in decoded else 'dash' if '.mpd' in decoded else 'mp4' if '.mp4' in decoded else ''
        if parts.scheme in ('http', 'https') and parts.hostname and kind and not any(row['url'] == url for row in result):
            result.append({'url': url, 'type': kind})
    return result


def _moviesapi_candidates(body, page, opener, deadline):
    """Use the API and public player key declared by this server's script."""
    parts = urlsplit(page)
    if parts.hostname != 'moviesapi.to':
        return []
    movie = re.fullmatch(r'/movie/(\d+)', parts.path)
    tv = re.fullmatch(r'/tv/(\d+)[/-](\d+)[/-](\d+)', parts.path.rstrip('/'))
    if not movie and not tv:
        return []
    route = 'movie/' + movie[1] if movie else 'tv/' + '/'.join(tv.groups())
    for src in re.findall(r'''<script\b[^>]*\bsrc=["']([^"']+)''', body, re.I):
        script_url = urljoin(page, unescape(src))
        if urlsplit(script_url).hostname != parts.hostname or '/assets/index-' not in script_url:
            continue
        with opener.open(Request(script_url, headers=dict(HEADERS, Referer=page)),
                         timeout=min(12, max(1, deadline - time.monotonic()))) as response:
            raw = response.read(4 * 1024 * 1024 + 1)
        if len(raw) > 4 * 1024 * 1024:
            continue
        script = raw.decode('utf-8', 'replace')
        variable = re.search(r'''["']x-player-key["']\s*:\s*([A-Za-z_$][\w$]*)''', script)
        if not variable or '/api/vidora' not in script:
            continue
        key = re.search(r'\b' + re.escape(variable[1]) + r'''\s*=\s*[`"']([A-Za-z0-9]+)[`"']''', script)
        if not key:
            continue
        endpoint = 'https://moviesapi.to/api/vidora/v1/' + route
        # Signed CDN URLs must come from a fresh API response, not a cached one.
        with opener.open(Request(endpoint, headers=dict(HEADERS, Referer=page, **{
                'x-player-key': key[1], 'Cache-Control': 'no-cache', 'Pragma': 'no-cache'})),
                         timeout=min(12, max(1, deadline - time.monotonic()))) as response:
            raw = response.read(2 * 1024 * 1024 + 1)
        if len(raw) > 2 * 1024 * 1024:
            return []
        data = json.loads(raw.decode('utf-8'))
        if not isinstance(data, dict) or not data.get('result'):
            return []
        if tv:
            for field, expected in (('season', tv[2]), ('episode', tv[3])):
                if data.get(field) is not None and int(data[field]) != int(expected):
                    return []
        rows = data.get('sources')
        return [{'url': row['url'], 'headers': row.get('headers', data.get('headers', {}))} for row in rows
                if isinstance(row, dict) and isinstance(row.get('url'), str)
                and urlsplit(row['url']).scheme in ('http', 'https')
                and urlsplit(row['url']).hostname] if isinstance(rows, list) else []
    return []


def resolve_server(url):
    """Dispatch the selected Dulo server to its own player protocol."""
    from .dulo_resolvers import resolve
    return resolve(url)


def _pick_server(candidates, tmdb_id, kind, season, episode):
    from . import tmdb
    from .source_finder_dialog import LinkPickerDialog, ADDON_PATH
    try:
        meta = tmdb.get_metadata(tmdb_id, 'movie' if kind == 'movie' else 'tvshow') or {}
    except Exception:
        meta = {}
    context = 'Movie' if kind == 'movie' else 'S%02d E%02d' % (season, episode)
    links = [{'label': row['label'], 'meta': '%s / Via Dulo' % context,
              'format_label': 'AUTO'} for row in candidates]
    dialog = LinkPickerDialog('DuloServerPicker.xml', ADDON_PATH, 'Default', '720p',
                             quality_label=meta.get('title') or 'Dulo',
                             poster=meta.get('poster', ''), links=links)
    try:
        dialog.doModal()
        selected = dialog.selected_index
        return selected if selected is not None and 0 <= selected < len(candidates) else -1
    finally:
        del dialog


def resolve(tmdb_id, kind='movie', season=0, episode=0, candidates=None):
    try:
        candidates = discover(tmdb_id, kind, season, episode) if candidates is None else candidates
        if not candidates:
            return {'error': 'Dulo has no listed servers for this movie or episode.'}
        selected = _pick_server(candidates, tmdb_id, kind, season, episode)
        if selected < 0:
            return {'cancelled': True}
        return resolve_server(candidates[selected]['url'])
    except Exception:
        return {'error': 'Dulo could not load this movie or episode. Please try again.'}
