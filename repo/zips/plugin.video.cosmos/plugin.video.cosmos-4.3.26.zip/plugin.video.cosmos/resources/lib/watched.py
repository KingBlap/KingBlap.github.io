# -*- coding: utf-8 -*-
"""
Watched-status tracker for C.O.S.M.O.S.

Stores the local fallback mapping "tmdb|season|episode" -> unix timestamp
and a throttled cache of the selected remote service's watched history. Status
is set automatically when playback completes and can also be toggled manually
via the movie or episode context menu.

Public API
----------
mark_watched(tmdb, season, episode)
mark_unwatched(tmdb, season, episode)
is_watched(tmdb, season, episode) -> bool
get_watched_set(tmdb) -> set of (int_season, int_episode) tuples
mark_movie_watched(tmdb)
mark_movie_unwatched(tmdb)
is_movie_watched(tmdb) -> bool
get_watched_movies() -> dict of tmdb_id -> unix timestamp
mark_show_watched(tmdb, episodes)
mark_show_unwatched(tmdb, episodes)
"""
import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcvfs

PROFILE_DIR = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/')
WATCHED_FILE = os.path.join(PROFILE_DIR, 'watched.json')
REMOTE_WATCHED_FILE = os.path.join(PROFILE_DIR, 'remote_watched.json')
REMOTE_CACHE_TTL = 10 * 60
ADDON_ID = 'plugin.video.cosmos'

# Kodi stores select settings as their zero-based option index.  This is the
# single source of truth used by both the watched indicator and playback
# scrobbling.
WATCH_TRACKING_SERVICES = {
    '0': 'local',
    '1': 'trakt',
    '2': 'simkl',
    '3': 'punchplay',
}
TRACKING_SERVICE_LABELS = {
    'all': 'All authorized services',
    'local': 'Cosmos local tracking',
    'trakt': 'Trakt',
    'simkl': 'Simkl',
    'punchplay': 'PunchPlay',
}
_REMOTE_SYNC_LOCK = threading.Lock()
_REMOTE_SYNC_IN_FLIGHT = set()
_UNAUTHORIZED_WARNING_LOGGED = set()
_MANUAL_ACTION_LOCK = threading.Lock()
_LAST_MANUAL_ACTION = {}


def _record_manual_action(operation, service, services=None, local=True, count=None):
    """Keep the most recent manual watched mutation result for the UI."""
    global _LAST_MANUAL_ACTION
    result = {
        'operation': operation,
        'service': service,
        'local': bool(local),
        'services': dict(services or {}),
    }
    if count is not None:
        result['count'] = int(count or 0)
    with _MANUAL_ACTION_LOCK:
        _LAST_MANUAL_ACTION = result


def get_last_manual_action():
    """Return a copy of the latest manual watched-service results."""
    with _MANUAL_ACTION_LOCK:
        result = dict(_LAST_MANUAL_ACTION)
    result['services'] = dict(result.get('services') or {})
    return result


def _ensure():
    if not os.path.isdir(PROFILE_DIR):
        try:
            os.makedirs(PROFILE_DIR)
        except OSError:
            pass


def get_configured_tracking_service():
    """Return the service selected in Kodi settings without validation."""
    try:
        selected = str(
            xbmcaddon.Addon(ADDON_ID).getSetting('watch_tracking_service') or '0'
        ).strip().lower()
    except Exception:
        selected = '0'
    # Legacy Kodi select settings can persist the option label rather than
    # its index. In particular, a saved "Simkl" must not silently become
    # local-only tracking. Keep removed/unknown options local-only.
    labels = {'local only': 'local', 'local': 'local',
              'trakt': 'trakt', 'simkl': 'simkl',
              'punchplay': 'punchplay'}
    return WATCH_TRACKING_SERVICES.get(selected, labels.get(selected, 'local'))


def get_tracking_service():
    """Return the effective service, falling back if it is not authorized."""
    service = get_configured_tracking_service()
    if service in ('all', 'local'):
        return service
    if _authorized_for(service):
        _UNAUTHORIZED_WARNING_LOGGED.discard(service)
        return service
    if service not in _UNAUTHORIZED_WARNING_LOGGED:
        _UNAUTHORIZED_WARNING_LOGGED.add(service)
        xbmc.log(
            f'COSMOS watched: {service} is not authorized; using local watched status',
            xbmc.LOGWARNING,
        )
    return 'local'


def tracking_service_label(service=None):
    """Return a user-facing name for the configured tracking service."""
    return TRACKING_SERVICE_LABELS.get(
        service or get_tracking_service(), 'Cosmos local tracking')


def _remote_cache_template():
    return {
        'updated': 0,
        'attempted': 0,
        'movies': {},
        'episodes': {},
        'shows': {},
    }


def _load_remote_cache():
    _ensure()
    if not os.path.isfile(REMOTE_WATCHED_FILE):
        return {}
    try:
        with open(REMOTE_WATCHED_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp) or {}
        return data if isinstance(data, dict) else {}
    except (ValueError, OSError):
        return {}


def _save_remote_cache(data):
    _ensure()
    try:
        with open(REMOTE_WATCHED_FILE, 'w', encoding='utf-8') as fp:
            json.dump(data or {}, fp)
    except OSError as e:
        xbmc.log(f'COSMOS watched: remote cache save failed: {e}', xbmc.LOGWARNING)


def _remote_cache_for(service, data=None):
    data = data if data is not None else _load_remote_cache()
    current = data.get(service)
    if not isinstance(current, dict):
        current = _remote_cache_template()
    for key, default in _remote_cache_template().items():
        if key not in current or not isinstance(current[key], type(default)):
            current[key] = default
    return current


def _tmdb_id(item, parent=None):
    """Extract a TMDB id from the common service response shapes."""
    for source in (item, parent or {}):
        if not isinstance(source, dict):
            continue
        for key in ('tmdb', 'tmdb_id', 'tmdbId'):
            value = source.get(key)
            if value not in (None, ''):
                return str(value)
        ids = source.get('ids')
        if isinstance(ids, dict):
            value = ids.get('tmdb') or ids.get('tmdb_id')
            if value not in (None, ''):
                return str(value)
        value = source.get('sourceId')
        if value not in (None, '') and str(value).isdigit():
            return str(value)
    return ''


def _number(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _timestamp(item, fallback):
    if isinstance(item, dict):
        for key in ('watched_at', 'watchedAt', 'last_watched_at', 'updated_at', 'ts'):
            value = item.get(key)
            if isinstance(value, (int, float)):
                return int(value)
    return int(fallback)


def _cache_movie(cache, tmdb, timestamp):
    if tmdb:
        cache['movies'][str(tmdb)] = int(timestamp)


def _cache_show(cache, tmdb, timestamp):
    if tmdb:
        cache['shows'][str(tmdb)] = int(timestamp)


def _cache_episode(cache, tmdb, season, episode, timestamp):
    season = _number(season)
    episode = _number(episode)
    if tmdb and season is not None and episode is not None:
        cache['episodes'][f'{tmdb}|{season}|{episode}'] = int(timestamp)


def _ingest_seasons(cache, show, timestamp):
    if not isinstance(show, dict):
        return
    seasons = show.get('seasons') or []
    tmdb = _tmdb_id(show)
    for season in seasons:
        if not isinstance(season, dict):
            continue
        season_no = season.get('number') or season.get('season')
        for episode in season.get('episodes') or []:
            if not isinstance(episode, dict):
                continue
            _cache_episode(
                cache, tmdb, season_no,
                episode.get('number') or episode.get('episode'),
                _timestamp(episode, _timestamp(season, timestamp)),
            )


def _ingest_record(cache, record, default_kind='', timestamp=None):
    """Flatten Trakt/Simkl history into cache keys."""
    if not isinstance(record, dict):
        return
    timestamp = _timestamp(record, timestamp or time.time())

    movie = record.get('movie')
    if isinstance(movie, dict):
        _cache_movie(cache, _tmdb_id(movie, record), timestamp)
        return

    show = record.get('show')
    episode = record.get('episode')
    if isinstance(show, dict):
        show_tmdb = _tmdb_id(show, record)
        _cache_show(cache, show_tmdb, timestamp)
        if isinstance(episode, dict):
            _cache_episode(
                cache, show_tmdb,
                episode.get('season') or record.get('season'),
                episode.get('number') or episode.get('episode') or record.get('episode'),
                _timestamp(episode, timestamp),
            )
        _ingest_seasons(cache, show, timestamp)
        _ingest_seasons(cache, record, timestamp)
        return

    media = record
    tmdb = _tmdb_id(media)
    kind = str(
        media.get('content') or media.get('media_type') or media.get('mediatype')
        or media.get('type') or media.get('kind') or default_kind
    ).lower()
    season = media.get('season')
    episode_no = media.get('episode') or media.get('episode_number')
    if isinstance(episode_no, dict):
        episode_no = episode_no.get('number') or episode_no.get('episode')

    if kind in ('movie', 'movies', 'film'):
        _cache_movie(cache, tmdb, timestamp)
    elif kind in ('episode', 'episodes', 'anime_episode') or (
            season not in (None, '') and episode_no not in (None, '')):
        _cache_episode(cache, tmdb, season, episode_no, timestamp)
        _cache_show(cache, tmdb, timestamp)
    elif kind in ('show', 'shows', 'tv', 'tvshow', 'series', 'anime'):
        _cache_show(cache, tmdb, timestamp)
        _ingest_seasons(cache, media, timestamp)


def _authorized_for(service):
    try:
        if service == 'trakt':
            from . import trakt
            return bool(trakt.is_authorized())
        if service == 'simkl':
            from . import simkl
            return bool(simkl.is_authorized())
        if service == 'punchplay':
            from . import punchplay
            return bool(punchplay.has_token())
    except Exception as e:
        xbmc.log(f'COSMOS watched: {service} authorization check failed: {e}', xbmc.LOGDEBUG)
    return False


def get_authorized_tracking_services():
    """Return remote services currently authorized for aggregate mode."""
    return [service for service in ('trakt', 'simkl')
            if _authorized_for(service)]


def _fetch_remote_history(service):
    if not _authorized_for(service):
        return None
    if service == 'trakt':
        from . import trakt
        history = ([(item, 'movie') for item in trakt.get_history('movies', limit=100)] +
                   [(item, 'show') for item in trakt.get_history('shows', limit=100)])
        # /users/me/watched is the authoritative source for the website's
        # watched checkmark and may contain items absent from play history.
        watched = ([(item, 'movie') for item in trakt.get_watched('movies')] +
                   [(item, 'show') for item in trakt.get_watched('shows')])
        return history + watched
    if service == 'simkl':
        from . import simkl
        return ([(item, 'movie') for item in simkl._get_history('movies')] +
                [(item, 'show') for item in simkl._get_history('shows')] +
                [(item, 'show') for item in simkl._get_history('anime')])
    if service == 'punchplay':
        from . import punchplay
        # Partner Sync performs one snapshot and then follows the durable
        # change feed, avoiding repeated downloads of presentation endpoints.
        return [(item, '') for item in
                punchplay.get_partner_resource('history', refresh=True)]
    return None


def _sync_remote(service):
    try:
        fetched = _fetch_remote_history(service)
        if fetched is None:
            return False
        cache = _remote_cache_template()
        now = int(time.time())
        cache['attempted'] = now
        for item, default_kind in fetched:
            _ingest_record(cache, item, default_kind=default_kind, timestamp=now)
        cache['updated'] = now
        data = _load_remote_cache()
        data[service] = cache
        _save_remote_cache(data)
        if get_tracking_service() in (service, 'all'):
            try:
                xbmc.executebuiltin('Container.Refresh')
            except Exception:
                pass
        xbmc.log(
            f'COSMOS watched: synchronized {service} cache '
            f'({len(cache["movies"])} movies, {len(cache["episodes"])} episodes)',
            xbmc.LOGINFO,
        )
        return True
    except Exception as e:
        xbmc.log(f'COSMOS watched: {service} history sync failed: {e}', xbmc.LOGWARNING)
        return False


def _start_remote_sync(service, force=False):
    """Start a throttled background sync for one authorized service."""
    if not _authorized_for(service):
        return False
    now = int(time.time())
    with _REMOTE_SYNC_LOCK:
        data = _load_remote_cache()
        cache = _remote_cache_for(service, data)
        if not force and now - int(cache.get('attempted') or 0) < REMOTE_CACHE_TTL:
            return False
        cache['attempted'] = now
        data[service] = cache
        _save_remote_cache(data)
        if service in _REMOTE_SYNC_IN_FLIGHT:
            return False
        _REMOTE_SYNC_IN_FLIGHT.add(service)

    def _worker():
        try:
            _sync_remote(service)
        finally:
            with _REMOTE_SYNC_LOCK:
                _REMOTE_SYNC_IN_FLIGHT.discard(service)

    threading.Thread(
        target=_worker, name=f'cosmos-watched-sync-{service}', daemon=True
    ).start()
    return True


def maybe_sync_remote(force=False):
    """Refresh the selected remote cache, or all authorized caches."""
    service = get_tracking_service()
    if service == 'all':
        started = False
        for remote_service in get_authorized_tracking_services():
            started = _start_remote_sync(remote_service, force=force) or started
        return started
    if service == 'local':
        return False
    return _start_remote_sync(service, force=force)


def sync_remote_now(service, force=True):
    """Synchronously refresh one remote watched-history cache.

    Interactive menu actions use this variant so the user gets confirmation
    only after the history has actually been downloaded and cached.
    """
    if service in ('local', 'all') or not _authorized_for(service):
        return False
    return _sync_remote(service)


def import_remote_to_local(service):
    """Merge a cached remote watched snapshot into Kodi's local ledger."""
    cache = _remote_cache_for(service, _load_remote_cache())
    count = 0
    for tmdb in cache.get('movies', {}):
        mark_movie_watched(tmdb)
        count += 1
    for key in cache.get('episodes', {}):
        parts = str(key).split('|')
        if len(parts) != 3:
            continue
        mark_watched(parts[0], parts[1], parts[2])
        count += 1
    return count


def _selected_remote_cache():
    service = get_tracking_service()
    if service in ('all', 'local'):
        return None
    maybe_sync_remote()
    return _remote_cache_for(service)


def _aggregate_remote_caches():
    """Return authorized remote caches used by aggregate watched mode."""
    maybe_sync_remote()
    data = _load_remote_cache()
    return [
        _remote_cache_for(service, data)
        for service in get_authorized_tracking_services()
    ]


def _aggregate_episode_pairs(tmdb):
    pairs = set(get_local_watched_set(tmdb))
    prefix = f'{tmdb}|'
    for cache in _aggregate_remote_caches():
        for key in cache.get('episodes', {}):
            parts = str(key).split('|')
            if len(parts) != 3 or not str(key).startswith(prefix):
                continue
            try:
                pairs.add((int(parts[1]), int(parts[2])))
            except (TypeError, ValueError):
                pass
    return pairs


def _key(tmdb, season, episode):
    return f'{tmdb}|{season}|{episode}'


def _movie_key(tmdb):
    return f'movie|{tmdb}'


def _load():
    _ensure()
    if not os.path.isfile(WATCHED_FILE):
        return {}
    try:
        with open(WATCHED_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp) or {}
        return data if isinstance(data, dict) else {}
    except (ValueError, OSError):
        return {}


def _save(data):
    _ensure()
    try:
        with open(WATCHED_FILE, 'w', encoding='utf-8') as fp:
            json.dump(data, fp)
    except OSError as e:
        xbmc.log(f'COSMOS watched: save failed: {e}', xbmc.LOGWARNING)


def mark_watched(tmdb, season, episode):
    """Record (tmdb, season, episode) as fully watched and clear any resume point."""
    if not tmdb or season is None or episode is None:
        return
    try:
        s_int = int(season)
        e_int = int(episode)
    except (ValueError, TypeError):
        return

    # 1. Save watched state
    data = _load()
    data[_key(tmdb, s_int, e_int)] = int(time.time())
    _save(data)

    # 2. Clear any lingering resume points for this specific episode so Next Episode can trigger
    try:
        resume_file = os.path.join(PROFILE_DIR, 'resume.json')
        if os.path.isfile(resume_file):
            with open(resume_file, 'r', encoding='utf-8') as fp:
                resume_data = json.load(fp) or {}
            
            keys_to_remove = []
            for r_key, r_val in resume_data.items():
                if str(r_val.get('tmdb')) == str(tmdb) and str(r_val.get('season')) == str(s_int) and str(r_val.get('episode')) == str(e_int):
                    keys_to_remove.append(r_key)
            
            if keys_to_remove:
                for k in keys_to_remove:
                    resume_data.pop(k, None)
                with open(resume_file, 'w', encoding='utf-8') as fp:
                    json.dump(resume_data, fp)
    except Exception as e:
        xbmc.log(f'COSMOS watched: failed to clear resume point: {e}', xbmc.LOGWARNING)


def mark_movie_watched(tmdb):
    """Record a movie as locally watched and clear its resume point."""
    if not tmdb:
        return
    data = _load()
    data[_movie_key(tmdb)] = int(time.time())
    _save(data)

    # Remove any in-progress resume entry for this movie.
    try:
        resume_file = os.path.join(PROFILE_DIR, 'resume.json')
        if os.path.isfile(resume_file):
            with open(resume_file, 'r', encoding='utf-8') as fp:
                resume_data = json.load(fp) or {}
            keys_to_remove = [
                key for key, value in resume_data.items()
                if str(value.get('tmdb')) == str(tmdb)
                and value.get('content', 'movie') == 'movie'
            ]
            for key in keys_to_remove:
                resume_data.pop(key, None)
            if keys_to_remove:
                with open(resume_file, 'w', encoding='utf-8') as fp:
                    json.dump(resume_data, fp)
    except Exception as e:
        xbmc.log(f'COSMOS watched: failed to clear movie resume point: {e}', xbmc.LOGWARNING)


def mark_movie_unwatched(tmdb):
    """Remove a movie's local watched marker."""
    if not tmdb:
        return
    data = _load()
    if data.pop(_movie_key(tmdb), None) is not None:
        _save(data)


def _remote_mark(service, meta, watched=True):
    """Apply one watched/unwatched mutation to the selected service."""
    meta = dict(meta or {})
    content = (meta.get('content') or 'movie').lower()
    try:
        if service == 'trakt':
            from . import trakt
            if watched:
                return trakt.add_to_history(
                    content, tmdb=meta.get('tmdb'), imdb=meta.get('imdb'),
                    trakt_id=meta.get('trakt'), season=meta.get('season'),
                    episode=meta.get('episode'))
            return trakt.remove_from_history(
                content, tmdb=meta.get('tmdb'), imdb=meta.get('imdb'),
                trakt_id=meta.get('trakt'), season=meta.get('season'),
                episode=meta.get('episode'))
        if service == 'simkl':
            from . import simkl
            return bool(
                simkl.add_to_history(meta) if watched
                else simkl.remove_from_history(meta)
            )
    except Exception as e:
        xbmc.log(
            f'COSMOS watched: {service} {"add" if watched else "remove"} failed: {e}',
            xbmc.LOGWARNING,
        )
    return False


def cache_selected_watched(meta, service=None):
    """Record a successfully completed remote watch in the local cache."""
    service = service or get_tracking_service()
    if service in ('all', 'local'):
        return
    cache = _remote_cache_for(service)
    _ingest_record(cache, dict(meta or {}), timestamp=time.time())
    cache['updated'] = int(time.time())
    cache['attempted'] = cache['updated']
    data = _load_remote_cache()
    data[service] = cache
    _save_remote_cache(data)
    if get_tracking_service() in (service, 'all'):
        # Playback scrobbling completes in a worker thread. Refresh after the
        # cache write so the green watched indicators see the new entry.
        try:
            xbmc.executebuiltin('Container.Refresh')
        except Exception:
            pass


def _remove_cached_watched(meta, service):
    cache = _remote_cache_for(service)
    tmdb = _tmdb_id(meta)
    content = (meta.get('content') or 'movie').lower()
    if content == 'movie':
        cache.get('movies', {}).pop(str(tmdb), None)
    elif meta.get('season') not in (None, '') and meta.get('episode') not in (None, ''):
        season = _number(meta.get('season'))
        episode = _number(meta.get('episode'))
        if tmdb and season is not None and episode is not None:
            cache.get('episodes', {}).pop(f'{tmdb}|{season}|{episode}', None)
            prefix = f'{tmdb}|'
            if not any(str(key).startswith(prefix) for key in cache.get('episodes', {})):
                cache.get('shows', {}).pop(str(tmdb), None)
    else:
        cache.get('shows', {}).pop(str(tmdb), None)
        prefix = f'{tmdb}|'
        for key in list(cache.get('episodes', {})):
            if str(key).startswith(prefix):
                cache['episodes'].pop(key, None)
    data = _load_remote_cache()
    data[service] = cache
    _save_remote_cache(data)


def mark_selected_watched(meta):
    """Mark one item watched using the configured indicator service."""
    meta = dict(meta or {})
    service = get_tracking_service()
    content = (meta.get('content') or 'movie').lower()
    if service == 'all':
        # Keep the local ledger warm while fanning the same mutation out to
        # every authorized remote service. A remote failure must not undo
        # successful writes elsewhere.
        if content == 'movie':
            mark_movie_watched(meta.get('tmdb'))
        else:
            mark_watched(meta.get('tmdb'), meta.get('season'), meta.get('episode'))
        remote_results = {}
        for remote_service in get_authorized_tracking_services():
            remote_ok = _remote_mark(remote_service, meta, watched=True)
            remote_results[remote_service] = bool(remote_ok)
            if remote_ok:
                cache_selected_watched(meta, service=remote_service)
        _record_manual_action('watched', service, remote_results, local=True)
        return True
    if service == 'local':
        if content == 'movie':
            mark_movie_watched(meta.get('tmdb'))
        else:
            mark_watched(meta.get('tmdb'), meta.get('season'), meta.get('episode'))
        _record_manual_action('watched', service, local=True)
        return True
    remote_ok = _remote_mark(service, meta, watched=True)
    if not remote_ok:
        _record_manual_action('watched', service, {service: False}, local=False)
        return False
    cache_selected_watched(meta, service=service)
    # Keep the local ledger warm for users who later switch back to local mode.
    if content == 'movie':
        mark_movie_watched(meta.get('tmdb'))
    else:
        mark_watched(meta.get('tmdb'), meta.get('season'), meta.get('episode'))
    _record_manual_action('watched', service, {service: True}, local=True)
    return True


def unmark_selected_watched(meta):
    """Remove one item from the configured indicator service."""
    meta = dict(meta or {})
    service = get_tracking_service()
    content = (meta.get('content') or 'movie').lower()
    if service == 'all':
        if content == 'movie':
            mark_movie_unwatched(meta.get('tmdb'))
        else:
            mark_unwatched(meta.get('tmdb'), meta.get('season'), meta.get('episode'))
        remote_results = {}
        for remote_service in get_authorized_tracking_services():
            remote_ok = _remote_mark(remote_service, meta, watched=False)
            remote_results[remote_service] = bool(remote_ok)
            if remote_ok:
                _remove_cached_watched(meta, remote_service)
        _record_manual_action('unwatched', service, remote_results, local=True)
        return True
    if service == 'local':
        if content == 'movie':
            mark_movie_unwatched(meta.get('tmdb'))
        else:
            mark_unwatched(meta.get('tmdb'), meta.get('season'), meta.get('episode'))
        _record_manual_action('unwatched', service, local=True)
        return True
    remote_ok = _remote_mark(service, meta, watched=False)
    if not remote_ok:
        _record_manual_action('unwatched', service, {service: False}, local=False)
        return False
    _remove_cached_watched(meta, service)
    if content == 'movie':
        mark_movie_unwatched(meta.get('tmdb'))
    else:
        mark_unwatched(meta.get('tmdb'), meta.get('season'), meta.get('episode'))
    _record_manual_action('unwatched', service, {service: True}, local=True)
    return True


def mark_selected_show_watched(tmdb, title, episodes):
    """Bulk-mark a show's supplied episodes on the selected service."""
    service = get_tracking_service()
    pairs = list(episodes or [])
    if service == 'all':
        count = mark_show_watched(tmdb, pairs)
        remote_results = {}
        for remote_service in get_authorized_tracking_services():
            service_ok = True
            for season, episode in pairs:
                meta = {
                    'tmdb': tmdb, 'title': title, 'content': 'episode',
                    'season': season, 'episode': episode,
                }
                remote_ok = _remote_mark(remote_service, meta, watched=True)
                service_ok = service_ok and bool(remote_ok)
                if remote_ok:
                    cache_selected_watched(meta, service=remote_service)
            remote_results[remote_service] = service_ok
        _record_manual_action('watched', service, remote_results, local=True, count=count)
        return count
    if service == 'local':
        count = mark_show_watched(tmdb, pairs)
        _record_manual_action('watched', service, local=True, count=count)
        return count
    count = 0
    service_ok = True
    for season, episode in pairs:
        meta = {
            'tmdb': tmdb, 'title': title, 'content': 'episode',
            'season': season, 'episode': episode,
        }
        remote_ok = _remote_mark(service, meta, watched=True)
        service_ok = service_ok and bool(remote_ok)
        if remote_ok:
            cache_selected_watched(meta, service=service)
            mark_watched(tmdb, season, episode)
            count += 1
    _record_manual_action('watched', service, {service: service_ok}, local=bool(count), count=count)
    return count


def unmark_selected_show_watched(tmdb, title, episodes=None):
    """Bulk-remove a show's watched episodes from the selected service."""
    service = get_tracking_service()
    if service == 'all':
        pairs = list(episodes or [])
        if not pairs:
            pairs = sorted(_aggregate_episode_pairs(tmdb))
        count = mark_show_unwatched(tmdb, pairs)
        remote_results = {}
        for remote_service in get_authorized_tracking_services():
            service_ok = True
            for season, episode in pairs:
                meta = {
                    'tmdb': tmdb, 'title': title, 'content': 'episode',
                    'season': season, 'episode': episode,
                }
                remote_ok = _remote_mark(remote_service, meta, watched=False)
                service_ok = service_ok and bool(remote_ok)
                if remote_ok:
                    _remove_cached_watched(meta, remote_service)
            remote_results[remote_service] = service_ok
        _record_manual_action('unwatched', service, remote_results, local=True, count=count)
        return count
    if service == 'local':
        count = mark_show_unwatched(tmdb, episodes)
        _record_manual_action('unwatched', service, local=True, count=count)
        return count
    pairs = list(episodes or [])
    if not pairs:
        cache = _selected_remote_cache() or _remote_cache_template()
        prefix = f'{tmdb}|'
        for key in cache.get('episodes', {}):
            parts = str(key).split('|')
            if len(parts) == 3 and str(key).startswith(prefix):
                pairs.append((parts[1], parts[2]))
    count = 0
    service_ok = True
    if pairs:
        for season, episode in pairs:
            meta = {
                'tmdb': tmdb, 'title': title, 'content': 'episode',
                'season': season, 'episode': episode,
            }
            remote_ok = _remote_mark(service, meta, watched=False)
            service_ok = service_ok and bool(remote_ok)
            if remote_ok:
                _remove_cached_watched(meta, service)
                mark_unwatched(tmdb, season, episode)
                count += 1
    else:
        # Do not issue a destructive show-level history removal when the
        # service has not supplied episode-level records.  A background sync
        # may still be populating the cache, and some services interpret a
        # season-less removal as deleting the entire show/library entry.
        xbmc.log(
            f'COSMOS watched: no episode records available to clear for {tmdb}',
            xbmc.LOGWARNING,
        )
    _record_manual_action('unwatched', service, {service: service_ok}, local=bool(count), count=count)
    return count


def is_movie_watched(tmdb):
    """Return watched state from the selected indicator service."""
    if not tmdb:
        return False
    if get_tracking_service() == 'all':
        if str(tmdb) in get_watched_movies():
            return True
        return False
    cache = _selected_remote_cache()
    if cache is not None:
        return str(tmdb) in cache.get('movies', {})
    return _movie_key(tmdb) in _load()


def is_local_movie_watched(tmdb):
    """Return a movie's local watched state regardless of tracking selection."""
    if not tmdb:
        return False
    return _movie_key(tmdb) in _load()


def get_watched_movies():
    """Return selected-service watched movies as ``{tmdb_id: timestamp}``."""
    if get_tracking_service() == 'all':
        out = {}
        for key, timestamp in _load().items():
            if isinstance(key, str) and key.startswith('movie|'):
                tmdb_id = key.split('|', 1)[1]
                if tmdb_id:
                    try:
                        stamp = int(timestamp or 0)
                    except (TypeError, ValueError):
                        stamp = 0
                    out[tmdb_id] = max(stamp, out.get(tmdb_id, 0))
        for cache in _aggregate_remote_caches():
            for tmdb_id, timestamp in (cache.get('movies') or {}).items():
                try:
                    stamp = int(timestamp or 0)
                except (TypeError, ValueError):
                    stamp = 0
                out[str(tmdb_id)] = max(stamp, out.get(str(tmdb_id), 0))
        return out
    cache = _selected_remote_cache()
    if cache is not None:
        return dict(cache.get('movies') or {})
    out = {}
    for key, timestamp in _load().items():
        if isinstance(key, str) and key.startswith('movie|'):
            tmdb_id = key.split('|', 1)[1]
            if tmdb_id:
                out[tmdb_id] = timestamp
    return out


def get_local_watched_movies():
    """Return locally watched movies regardless of tracking selection."""
    out = {}
    for key, timestamp in _load().items():
        if isinstance(key, str) and key.startswith('movie|'):
            tmdb_id = key.split('|', 1)[1]
            if tmdb_id:
                out[tmdb_id] = timestamp
    return out


def mark_unwatched(tmdb, season, episode):
    """Remove the watched flag for (tmdb, season, episode)."""
    if not tmdb or season is None or episode is None:
        return
    data = _load()
    if data.pop(_key(tmdb, season, episode), None) is not None:
        _save(data)


def is_watched(tmdb, season, episode):
    if get_tracking_service() == 'all':
        try:
            pair = (int(season), int(episode))
        except (TypeError, ValueError):
            return False
        return pair in _aggregate_episode_pairs(tmdb)
    cache = _selected_remote_cache()
    if cache is not None:
        try:
            key = f'{tmdb}|{int(season)}|{int(episode)}'
        except (TypeError, ValueError):
            return False
        return key in cache.get('episodes', {})
    return _key(tmdb, season, episode) in _load()


def get_watched_set(tmdb):
    """Return a set of (season, episode) int-pairs watched for *tmdb*."""
    if get_tracking_service() == 'all':
        return _aggregate_episode_pairs(tmdb)
    cache = _selected_remote_cache()
    if cache is not None:
        prefix = f'{tmdb}|'
        out = set()
        for key in cache.get('episodes', {}):
            if not str(key).startswith(prefix):
                continue
            parts = str(key).split('|')
            if len(parts) != 3:
                continue
            try:
                out.add((int(parts[1]), int(parts[2])))
            except ValueError:
                pass
        return out
    return get_local_watched_set(tmdb)


def get_local_watched_set(tmdb):
    """Return local watched episodes regardless of the selected service."""
    prefix = f'{tmdb}|'
    out = set()
    for k in _load():
        if k.startswith(prefix):
            parts = k.split('|')
            if len(parts) == 3:
                try:
                    out.add((int(parts[1]), int(parts[2])))
                except ValueError:
                    pass
    return out


def mark_show_watched(tmdb, episodes):
    """Record all ``(season, episode)`` pairs for a show as watched."""
    if not tmdb:
        return 0
    data = _load()
    timestamp = int(time.time())
    count = 0
    episode_keys = set()
    for season, episode in episodes or []:
        try:
            season = int(season)
            episode = int(episode)
        except (ValueError, TypeError):
            continue
        data[_key(tmdb, season, episode)] = timestamp
        episode_keys.add((str(season), str(episode)))
        count += 1
    if count:
        _save(data)

        # A bulk local watched action must also remove stale resume rows so
        # the show cannot remain visible in In Progress.
        try:
            resume_file = os.path.join(PROFILE_DIR, 'resume.json')
            if os.path.isfile(resume_file):
                with open(resume_file, 'r', encoding='utf-8') as fp:
                    resume_data = json.load(fp) or {}
                keys_to_remove = [
                    key for key, value in resume_data.items()
                    if str(value.get('tmdb')) == str(tmdb)
                    and (str(value.get('season')), str(value.get('episode'))) in episode_keys
                ]
                if keys_to_remove:
                    for key in keys_to_remove:
                        resume_data.pop(key, None)
                    with open(resume_file, 'w', encoding='utf-8') as fp:
                        json.dump(resume_data, fp)
        except Exception as e:
            xbmc.log(f'COSMOS watched: failed to clear show resume points: {e}', xbmc.LOGWARNING)
    return count


def mark_show_unwatched(tmdb, episodes):
    """Remove local watched markers for supplied episodes or the whole show."""
    if not tmdb:
        return 0
    data = _load()
    count = 0
    if episodes is None:
        prefix = f'{tmdb}|'
        for key in list(data):
            if isinstance(key, str) and key.startswith(prefix) and key.count('|') == 2:
                data.pop(key, None)
                count += 1
    else:
        for season, episode in episodes or []:
            try:
                key = _key(tmdb, int(season), int(episode))
            except (ValueError, TypeError):
                continue
            if data.pop(key, None) is not None:
                count += 1
    if count:
        _save(data)
    return count


def get_all_watched_shows():
    """
    Return a dict of all shows with watched episodes, keyed by TMDB ID.
    Each value contains the last watched season/episode and timestamp.
    e.g. {'1399': {'last_watched_s': 8, 'last_watched_e': 3, 'ts': 167...}}
    """
    if get_tracking_service() == 'all':
        shows = {}

        def _merge_episode(tmdb, season, episode, timestamp):
            try:
                candidate = {
                    'last_watched_s': int(season),
                    'last_watched_e': int(episode),
                    'ts': int(timestamp),
                }
            except (TypeError, ValueError):
                return
            if tmdb not in shows or candidate['ts'] >= shows[tmdb]['ts']:
                shows[tmdb] = candidate

        for key, timestamp in _load().items():
            try:
                tmdb, season, episode = key.split('|')
                _merge_episode(tmdb, season, episode, timestamp)
            except (ValueError, AttributeError, TypeError):
                continue

        for cache in _aggregate_remote_caches():
            for key, timestamp in (cache.get('episodes') or {}).items():
                try:
                    tmdb, season, episode = str(key).split('|')
                    _merge_episode(tmdb, season, episode, timestamp)
                except (ValueError, TypeError):
                    continue
            for tmdb, timestamp in (cache.get('shows') or {}).items():
                tmdb = str(tmdb)
                try:
                    ts = int(timestamp or 0)
                except (TypeError, ValueError):
                    ts = 0
                if tmdb not in shows:
                    shows[tmdb] = {
                        'last_watched_s': 0,
                        'last_watched_e': 0,
                        'ts': ts,
                    }
        return shows

    cache = _selected_remote_cache()
    if cache is not None:
        shows = {}
        for key, ts in (cache.get('episodes') or {}).items():
            try:
                tmdb, season, episode = str(key).split('|')
                candidate = {
                    'last_watched_s': int(season),
                    'last_watched_e': int(episode),
                    'ts': int(ts),
                }
                if tmdb not in shows or candidate['ts'] >= shows[tmdb]['ts']:
                    shows[tmdb] = candidate
            except (ValueError, TypeError):
                continue
        for tmdb, ts in (cache.get('shows') or {}).items():
            shows.setdefault(str(tmdb), {
                'last_watched_s': 0,
                'last_watched_e': 0,
                'ts': int(ts),
            })
        return shows

    data = _load()
    shows = {}
    for key, ts in data.items():
        try:
            tmdb, season, episode = key.split('|')
            if tmdb not in shows or ts > shows[tmdb]['ts']:
                shows[tmdb] = {
                    'last_watched_s': int(season),
                    'last_watched_e': int(episode),
                    'ts': int(ts),
                }
        except (ValueError, IndexError, TypeError):
            continue
    return shows
