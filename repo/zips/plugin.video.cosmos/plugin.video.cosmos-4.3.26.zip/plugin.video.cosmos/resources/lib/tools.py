# -*- coding: utf-8 -*-
"""Extra tools for C.O.S.M.O.S.

Currently exposes a single utility — a dead-link checker — that walks
the crawled search index, HEAD-probes every non-debrid, non-magnet URL,
and writes a dead/alive report to the addon profile. A summary dialog
is shown on completion with the option to view the full report.
"""
import json
import os
import re
import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError, URLError

import xbmc
import xbmcgui
import xbmcvfs

from . import filehost
from . import parser
from . import search as search_mod

try:
    from . import debug_bundle as _debug_bundle
    def _dblog(tag, detail):
        _debug_bundle.log(tag, detail)
except Exception:
    def _dblog(tag, detail):
        pass


PROFILE_DIR = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/')
REPORT_FILE = os.path.join(PROFILE_DIR, 'deadlink_report.txt')
REPORT_JSON = os.path.join(PROFILE_DIR, 'deadlink_report.json')
HEALTH_REPORT_FILE = os.path.join(PROFILE_DIR, 'playlist_health_report.txt')
HEALTH_REPORT_JSON = os.path.join(PROFILE_DIR, 'playlist_health_report.json')
USER_AGENT = 'COSMOS-LinkChecker/1.0'
WORKERS = 16
TIMEOUT = 12
HEALTH_MAX_DEPTH = getattr(search_mod, 'MAX_DEPTH', 4)
HEALTH_MAX_FEEDS = getattr(search_mod, 'MAX_FEEDS', 400)


def _ensure_profile():
    if not os.path.isdir(PROFILE_DIR):
        try:
            os.makedirs(PROFILE_DIR)
        except OSError:
            pass


def _classify(url):
    """Skip debrid tokens and magnet links; everything else is probe-able."""
    u = (url or '').strip().lower()
    if not u:
        return 'empty'
    if u in filehost.SEARCH_TOKENS:
        return 'debrid'
    if u.startswith('magnet:'):
        return 'magnet'
    if not (u.startswith('http://') or u.startswith('https://')):
        return 'nonhttp'
    return 'http'


_opener = build_opener(HTTPRedirectHandler())


def _probe(url):
    """HEAD then fallback to GET. Returns (alive: bool, status, detail)."""
    if not url:
        return False, 0, 'empty'
    try:
        req = Request(url, headers={'User-Agent': USER_AGENT,
                                    'Accept': '*/*'}, method='HEAD')
        with _opener.open(req, timeout=TIMEOUT) as r:
            code = getattr(r, 'status', None) or r.getcode()
            if 200 <= int(code) < 400:
                return True, int(code), 'HEAD ok'
            # Some hosts return 405 / 501 on HEAD; fall through to GET.
            if int(code) in (400, 403, 405, 501):
                raise HTTPError(url, int(code), 'HEAD rejected', r.headers, None)
            return False, int(code), f'HEAD {code}'
    except HTTPError as he:
        # 405 / 501 / etc — some hosts disallow HEAD; try a lightweight GET
        if he.code in (400, 403, 405, 501):
            try:
                req = Request(url, headers={'User-Agent': USER_AGENT,
                                            'Accept': '*/*',
                                            'Range': 'bytes=0-0'})
                with _opener.open(req, timeout=TIMEOUT) as r:
                    code = getattr(r, 'status', None) or r.getcode()
                    if 200 <= int(code) < 400:
                        return True, int(code), 'GET ok'
                    return False, int(code), f'GET {code}'
            except HTTPError as ge:
                return False, int(ge.code), f'GET {ge.code}'
            except (URLError, socket.timeout, ValueError, OSError) as ge:
                return False, 0, f'GET err: {ge}'
        return False, int(he.code or 0), f'HTTP {he.code}'
    except (URLError, socket.timeout, ValueError, OSError) as e:
        return False, 0, f'err: {e}'


def _collect_links_from_index():
    """Pull every labelled link from the cached search index.

    Returns a list of ``{'item', 'label', 'url', 'kind'}`` where ``item``
    is a short human-readable locator (name + season/episode + path).
    """
    cache = search_mod._load_cache() or {}
    items = cache.get('items') or []
    collected = []
    for it in items:
        name = it.get('name') or 'Untitled'
        content = it.get('content') or 'movie'
        path = it.get('path') or ''
        prefix = f'{name}'
        if path:
            prefix = f'{name} · {path[:40]}'

        if content == 'tvshow':
            # Walk the seasons/episodes for richer per-episode locators
            for season in (it.get('seasons') or []):
                for ep in (season.get('episodes') or []):
                    se = f'S{season.get("seasonNo","?")}E{ep.get("episode","?")}'
                    for lk in (ep.get('links') or []):
                        collected.append({
                            'item': f'{name} {se}',
                            'label': lk.get('label', ''),
                            'url': lk.get('url', ''),
                            'kind': _classify(lk.get('url', '')),
                        })
            # Also fall back to flat links if seasons were empty
            if not (it.get('seasons') or []):
                for lk in (it.get('links') or []):
                    collected.append({
                        'item': prefix,
                        'label': lk.get('label', ''),
                        'url': lk.get('url', ''),
                        'kind': _classify(lk.get('url', '')),
                    })
        else:
            for lk in (it.get('links') or []):
                collected.append({
                    'item': prefix,
                    'label': lk.get('label', ''),
                    'url': lk.get('url', ''),
                    'kind': _classify(lk.get('url', '')),
                })
    return collected


def _write_report(all_links, results, elapsed):
    """Write both a human-readable .txt and a machine-readable .json
    dead-link report into the addon profile."""
    _ensure_profile()
    dead = [r for r in results if not r['alive']]
    alive = [r for r in results if r['alive']]
    skipped = [lk for lk in all_links if lk['kind'] != 'http']

    try:
        with open(REPORT_JSON, 'w', encoding='utf-8') as fp:
            json.dump({
                'ts': int(time.time()),
                'elapsed': round(elapsed, 2),
                'totals': {
                    'links': len(all_links),
                    'probed': len(results),
                    'alive': len(alive),
                    'dead': len(dead),
                    'skipped': len(skipped),
                },
                'dead': dead,
                'alive': alive,
                'skipped': [
                    {'item': s['item'], 'label': s['label'],
                     'url': s['url'], 'kind': s['kind']} for s in skipped
                ],
            }, fp, indent=2)
    except OSError as e:
        xbmc.log(f'COSMOS deadlink: json write failed: {e}', xbmc.LOGWARNING)

    try:
        with open(REPORT_FILE, 'w', encoding='utf-8') as fp:
            fp.write('C.O.S.M.O.S — Dead-link report\n')
            fp.write(f'Generated: {time.strftime("%Y-%m-%d %H:%M:%S")}  ')
            fp.write(f'({elapsed:.1f}s)\n')
            fp.write('-' * 70 + '\n')
            fp.write(f'Total links in index : {len(all_links)}\n')
            fp.write(f'Skipped (debrid/magnet): {len(skipped)}\n')
            fp.write(f'Probed (HTTP)        : {len(results)}\n')
            fp.write(f'ALIVE                : {len(alive)}\n')
            fp.write(f'DEAD                 : {len(dead)}\n')
            fp.write('-' * 70 + '\n\n')
            if dead:
                fp.write('==== DEAD LINKS ====\n')
                for r in dead:
                    host = urlparse(r['url']).netloc or '?'
                    fp.write(f'[{r["status"] or "ERR"}] {host}\n')
                    fp.write(f'  item : {r["item"]}\n')
                    fp.write(f'  label: {r["label"]}\n')
                    fp.write(f'  url  : {r["url"]}\n')
                    fp.write(f'  why  : {r["detail"]}\n\n')
            fp.write('==== ALIVE LINKS ====\n')
            for r in alive:
                host = urlparse(r['url']).netloc or '?'
                fp.write(f'[{r["status"]}] {host}  — {r["item"]}\n')
    except OSError as e:
        xbmc.log(f'COSMOS deadlink: txt write failed: {e}', xbmc.LOGWARNING)


def run_dead_link_checker(base_url):
    """Interactive dead-link check. Rebuilds the index if empty, HEAD-
    probes every non-debrid URL with a thread pool and a progress dialog,
    then shows a summary + offers to view the text report."""
    dlg = xbmcgui.Dialog()

    # Ensure we have an index to probe
    cache = search_mod._load_cache()
    if not cache or cache.get('base') != base_url:
        pbg = xbmcgui.DialogProgressBG()
        pbg.create('C.O.S.M.O.S', 'Indexing playlists before link check...')

        def _cb(count, label):
            pct = min(95, count * 2)
            pbg.update(pct, 'C.O.S.M.O.S', f'Scanning #{count}: {label[:60]}')

        try:
            search_mod.get_index(base_url, force_refresh=True, progress_cb=_cb)
        finally:
            try:
                pbg.close()
            except Exception:
                pass

    all_links = _collect_links_from_index()
    http_links = [lk for lk in all_links if lk['kind'] == 'http']

    if not http_links:
        dlg.ok('C.O.S.M.O.S',
               'No non-debrid URLs to check.\n'
               'Your feeds are probably using Search4k/1080/720 tokens '
               'or magnet links, which resolve via debrid and are skipped.')
        return

    # Dedupe by URL so we don't hammer the same host
    seen = {}
    for lk in http_links:
        u = lk['url']
        if u and u not in seen:
            seen[u] = lk
    unique = list(seen.values())

    start = time.time()
    progress = xbmcgui.DialogProgress()
    progress.create('C.O.S.M.O.S — Dead-link check',
                    f'Probing {len(unique)} unique URL(s)...')

    results = []
    done = 0
    try:
        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            future_map = {pool.submit(_probe, lk['url']): lk for lk in unique}
            for fut in as_completed(future_map):
                if progress.iscanceled():
                    break
                lk = future_map[fut]
                try:
                    alive, status, detail = fut.result()
                except Exception as e:
                    alive, status, detail = False, 0, f'ex: {e}'
                results.append({
                    'item': lk['item'],
                    'label': lk['label'],
                    'url': lk['url'],
                    'alive': alive,
                    'status': status,
                    'detail': detail,
                })
                done += 1
                pct = int(done * 100 / max(1, len(unique)))
                progress.update(
                    pct,
                    f'Probed {done}/{len(unique)}  ·  '
                    f'alive: {sum(1 for r in results if r["alive"])}  ·  '
                    f'dead: {sum(1 for r in results if not r["alive"])}',
                )
    finally:
        try:
            progress.close()
        except Exception:
            pass

    elapsed = time.time() - start
    _write_report(all_links, results, elapsed)

    dead = sum(1 for r in results if not r['alive'])
    alive = sum(1 for r in results if r['alive'])
    summary = (
        f'Probed {len(results)} of {len(unique)} unique HTTP links '
        f'in {elapsed:.1f}s.\n\n'
        f'[COLOR lime]Alive: {alive}[/COLOR]   '
        f'[COLOR red]Dead: {dead}[/COLOR]   '
        f'Skipped: {len(all_links) - len(http_links)} (debrid/magnet)\n\n'
        f'Report saved to:\n{REPORT_FILE}'
    )
    if dead > 0:
        idx = dlg.yesno('C.O.S.M.O.S — Dead-link report',
                        summary, nolabel='Close', yeslabel='View full report')
        if idx:
            _show_report()
    else:
        dlg.ok('C.O.S.M.O.S — Dead-link report', summary)


def _show_report():
    if not os.path.isfile(REPORT_FILE):
        xbmcgui.Dialog().ok('C.O.S.M.O.S', 'No report available yet.')
        return
    try:
        with open(REPORT_FILE, 'r', encoding='utf-8') as fp:
            body = fp.read()
    except OSError as e:
        xbmcgui.Dialog().ok('C.O.S.M.O.S', f'Read error: {e}')
        return
    # TextViewer window — scrollable
    xbmcgui.Dialog().textviewer('Dead-link report', body)


# ── Playlist health checker ─────────────────────────────────────────────

def _health_issue(issues, code, severity, item, feed, location, detail, url=''):
    issues.append({
        'code': code,
        'severity': severity,
        'item': item or 'Playlist feed',
        'feed': feed or '',
        'location': location or 'Root',
        'detail': detail,
        'url': url or '',
    })


def _health_blocks(body):
    """Return raw item-like blocks for checks the forgiving parser cannot see."""
    parts = re.split(r'</item\s*>', body or '', flags=re.IGNORECASE)
    return [part for part in parts
            if re.search(r'<(?:item|name|linkname|content|tmdb|episode)\b',
                         part, re.IGNORECASE)]


def _health_link_url(url):
    """Remove Kodi pipe headers before probing a URL."""
    return str(url or '').split('|', 1)[0].strip()


def _health_item_key(feed, title, content, season='', episode=''):
    clean = parser.strip_bbcode(str(title or '')).casefold()
    return (feed, clean, str(content or '').casefold(),
            str(season or ''), str(episode or ''))


def _health_validate_links(links, item, feed, location, issues, probe_links,
                           seen_link_urls):
    if not links:
        _health_issue(issues, 'missing_links', 'error', item, feed, location,
                      'No playable links were found.')
        return

    local_urls = set()
    for number, link in enumerate(links, 1):
        if not isinstance(link, dict):
            link = {'label': f'Link {number}', 'url': link}
        label = parser.strip_bbcode(str(link.get('label') or f'Link {number}'))
        raw_url = str(link.get('url') or '').strip()
        url = _health_link_url(raw_url)
        if not url:
            _health_issue(issues, 'invalid_link', 'error', item, feed, location,
                          f'{label}: URL is empty.')
            continue

        kind = _classify(url)
        if kind in ('nonhttp', 'empty'):
            _health_issue(issues, 'invalid_link', 'error', item, feed, location,
                          f'{label}: unsupported URL format ({kind}).', raw_url)
            continue

        url_key = url.casefold()
        if url_key in local_urls:
            _health_issue(issues, 'duplicate_link', 'warning', item, feed, location,
                          f'{label}: the same URL appears more than once in this item.', raw_url)
        local_urls.add(url_key)

        if kind == 'http' and url_key not in seen_link_urls:
            seen_link_urls.add(url_key)
            probe_links.append({
                'item': item,
                'label': label,
                'url': url,
                'feed': feed,
                'location': location,
            })


def _write_health_report(base_url, issues, stats, elapsed):
    _ensure_profile()
    payload = {
        'ts': int(time.time()),
        'base': base_url,
        'elapsed': round(elapsed, 2),
        'stats': stats,
        'issues': issues,
    }
    try:
        with open(HEALTH_REPORT_JSON, 'w', encoding='utf-8') as fp:
            json.dump(payload, fp, indent=2)
    except OSError as e:
        xbmc.log(f'COSMOS health: json write failed: {e}', xbmc.LOGWARNING)

    try:
        with open(HEALTH_REPORT_FILE, 'w', encoding='utf-8') as fp:
            fp.write('C.O.S.M.O.S — Playlist health report\n')
            fp.write(f'Generated: {time.strftime("%Y-%m-%d %H:%M:%S")}  ')
            fp.write(f'({elapsed:.1f}s)\n')
            fp.write(f'Base feed: {base_url}\n')
            fp.write('-' * 74 + '\n')
            for key in ('feeds', 'entries', 'links', 'probed', 'expired',
                        'errors', 'warnings'):
                fp.write(f'{key.title():12}: {stats.get(key, 0)}\n')
            fp.write('-' * 74 + '\n\n')
            if not issues:
                fp.write('No playlist health issues were found.\n')
            else:
                for issue in issues:
                    fp.write(f'[{issue["severity"].upper()}] '
                             f'{issue["code"]}: {issue["item"]}\n')
                    fp.write(f'  location: {issue["location"]}\n')
                    fp.write(f'  detail  : {issue["detail"]}\n')
                    if issue.get('url'):
                        fp.write(f'  url     : {issue["url"]}\n')
                    fp.write(f'  feed    : {issue["feed"]}\n\n')
    except OSError as e:
        xbmc.log(f'COSMOS health: text write failed: {e}', xbmc.LOGWARNING)


def run_playlist_health_checker(base_url):
    """Crawl the playlist tree and report structural and link problems."""
    dlg = xbmcgui.Dialog()
    started = time.time()
    _dblog('PLAYLIST-HEALTH-START', f'base={base_url}')
    issues = []
    probe_links = []
    seen_link_urls = set()
    seen_feeds = set()
    seen_items = {}
    queue = [(base_url, 0, 'Root')]
    stats = {
        'feeds': 0, 'entries': 0, 'links': 0, 'probed': 0,
        'expired': 0, 'errors': 0, 'warnings': 0,
    }
    cancelled = False

    progress = xbmcgui.DialogProgress()
    progress.create('C.O.S.M.O.S — Playlist health', 'Scanning playlist feeds...')
    try:
        while queue and stats['feeds'] < HEALTH_MAX_FEEDS:
            if progress.iscanceled():
                cancelled = True
                break
            feed_url, depth, location = queue.pop(0)
            if not feed_url or feed_url in seen_feeds:
                continue
            seen_feeds.add(feed_url)
            stats['feeds'] += 1
            _dblog('PLAYLIST-HEALTH-FEED',
                   f'#{stats["feeds"]} location={location} url={feed_url}')
            progress.update(
                min(45, int(stats['feeds'] * 45 / max(1, HEALTH_MAX_FEEDS))),
                f'Feed {stats["feeds"]}: {location[:70]}',
            )

            body = parser.fetch_url(feed_url)
            if not body:
                _health_issue(issues, 'broken_feed', 'error', location,
                              feed_url, location,
                              'Feed could not be fetched or returned no data.')
                continue

            open_items = len(re.findall(r'<item\b', body, re.IGNORECASE))
            close_items = len(re.findall(r'</item\s*>', body, re.IGNORECASE))
            if open_items or close_items:
                if open_items != close_items:
                    _health_issue(issues, 'broken_xml', 'error', location,
                                  feed_url, location,
                                  f'Unbalanced item tags ({open_items} opened, '
                                  f'{close_items} closed).')

            kind, entries = parser.parse_page(body)
            if not entries:
                _health_issue(issues, 'broken_xml', 'error', location,
                              feed_url, location,
                              'Feed contains data but no valid playlist entries were parsed.')
                continue

            # The normal parser intentionally ignores nameless blocks. Catch
            # those here, while allowing TV episode blocks without <name>.
            if kind != 'tvshow':
                for number, block in enumerate(_health_blocks(body), 1):
                    if re.search(r'<episode\b', block, re.IGNORECASE):
                        continue
                    if not re.search(r'<name\s*>', block, re.IGNORECASE):
                        _health_issue(issues, 'missing_title', 'error',
                                      f'Entry {number}', feed_url, location,
                                      'Entry has no <name> title.')

            for entry_number, entry in enumerate(entries, 1):
                if kind == 'directory':
                    title = parser.strip_bbcode(str(entry.get('name') or '')).strip()
                    child = str(entry.get('url') or '').strip()
                    item_location = f'{location} / {title or "Entry " + str(entry_number)}'
                    stats['entries'] += 1
                    if not title:
                        _health_issue(issues, 'missing_title', 'error', item_location,
                                      feed_url, item_location, 'Directory entry has no title.')
                    key = _health_item_key(feed_url, title, 'directory')
                    if key in seen_items:
                        _health_issue(issues, 'duplicate_item', 'warning', title,
                                      feed_url, item_location,
                                      f'Duplicates {seen_items[key]}.')
                    else:
                        seen_items[key] = item_location
                    if not child:
                        _health_issue(issues, 'invalid_link', 'error', title,
                                      feed_url, item_location,
                                      'Directory entry has no child feed URL.')
                    elif _classify(_health_link_url(child)) not in ('http',):
                        _health_issue(issues, 'invalid_link', 'error', title,
                                      feed_url, item_location,
                                      'Child feed URL is not a valid HTTP(S) URL.', child)
                    elif depth + 1 <= HEALTH_MAX_DEPTH:
                        queue.append((child, depth + 1, item_location))
                elif kind == 'tvshow':
                    title = parser.strip_bbcode(str(entry.get('name') or '')).strip()
                    show_location = f'{location} / {title or "Untitled show"}'
                    stats['entries'] += 1
                    if not title:
                        _health_issue(issues, 'missing_title', 'error', show_location,
                                      feed_url, show_location, 'TV show has no title.')
                    show_key = _health_item_key(feed_url, title, 'tvshow')
                    if show_key in seen_items:
                        _health_issue(issues, 'duplicate_item', 'warning', title,
                                      feed_url, show_location,
                                      f'Duplicates {seen_items[show_key]}.')
                    else:
                        seen_items[show_key] = show_location
                    seasons = entry.get('seasons') or []
                    season_numbers = set()
                    for season in seasons:
                        season_no = str(season.get('seasonNo') or '').strip()
                        if not season_no:
                            _health_issue(issues, 'missing_episode_data', 'error', title,
                                          feed_url, show_location,
                                          'Season has no season number.')
                        if season_no in season_numbers:
                            _health_issue(issues, 'duplicate_item', 'warning', title,
                                          feed_url, show_location,
                                          f'Season {season_no} appears more than once.')
                        season_numbers.add(season_no)
                        for ep in season.get('episodes') or []:
                            ep_no = str(ep.get('episode') or '').strip()
                            ep_location = f'{show_location} / S{season_no or "?"}E{ep_no or "?"}'
                            stats['entries'] += 1
                            if not ep_no:
                                _health_issue(issues, 'missing_episode_data', 'error', title,
                                              feed_url, ep_location,
                                              'Episode has no episode number.')
                            ep_key = _health_item_key(feed_url, title, 'episode',
                                                      season_no, ep_no)
                            if ep_key in seen_items:
                                _health_issue(issues, 'duplicate_item', 'warning', title,
                                              feed_url, ep_location,
                                              f'Duplicates {seen_items[ep_key]}.')
                            else:
                                seen_items[ep_key] = ep_location
                            stats['links'] += len(ep.get('links') or [])
                            _health_validate_links(
                                ep.get('links') or [], title, feed_url, ep_location,
                                issues, probe_links, seen_link_urls)
                else:
                    title = parser.strip_bbcode(str(entry.get('name') or '')).strip()
                    content = str(entry.get('content') or 'movie').strip().lower()
                    item_location = f'{location} / {title or "Untitled entry"}'
                    stats['entries'] += 1
                    if not title:
                        _health_issue(issues, 'missing_title', 'error', item_location,
                                      feed_url, item_location, 'Content entry has no title.')
                    key = _health_item_key(feed_url, title, content,
                                           entry.get('season'), entry.get('episode'))
                    if key in seen_items:
                        _health_issue(issues, 'duplicate_item', 'warning', title,
                                      feed_url, item_location,
                                      f'Duplicates {seen_items[key]}.')
                    else:
                        seen_items[key] = item_location
                    links = entry.get('links') or []
                    stats['links'] += len(links)
                    _health_validate_links(
                        links, title, feed_url, item_location, issues,
                        probe_links, seen_link_urls)
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if not cancelled and probe_links:
        progress = xbmcgui.DialogProgress()
        progress.create('C.O.S.M.O.S — Playlist health',
                        f'Checking {len(probe_links)} direct link(s)...')
        try:
            with ThreadPoolExecutor(max_workers=WORKERS) as pool:
                future_map = {
                    pool.submit(_probe, link['url']): link for link in probe_links
                }
                for done, future in enumerate(as_completed(future_map), 1):
                    if progress.iscanceled():
                        cancelled = True
                        break
                    link = future_map[future]
                    try:
                        alive, status, detail = future.result()
                    except Exception as e:
                        alive, status, detail = False, 0, f'ex: {e}'
                    stats['probed'] += 1
                    if not alive:
                        stats['expired'] += 1
                        _health_issue(
                            issues, 'expired_link', 'error', link['item'],
                            link['feed'], link['location'],
                            f'{link["label"]}: {detail} (HTTP {status or "ERR"}).',
                            link['url'],
                        )
                    progress.update(
                        int(done * 100 / max(1, len(probe_links))),
                        f'Checked {done}/{len(probe_links)} direct links',
                    )
        finally:
            try:
                progress.close()
            except Exception:
                pass

    stats['errors'] = sum(1 for issue in issues if issue['severity'] == 'error')
    stats['warnings'] = sum(1 for issue in issues if issue['severity'] == 'warning')
    elapsed = time.time() - started
    _write_health_report(base_url, issues, stats, elapsed)
    _dblog('PLAYLIST-HEALTH-END',
           f'feeds={stats["feeds"]} entries={stats["entries"]} '
           f'issues={len(issues)} expired={stats["expired"]} '
           f'cancelled={cancelled}')

    summary = (
        f'Feeds: {stats["feeds"]}   Entries: {stats["entries"]}\n'
        f'Links: {stats["links"]}   Checked: {stats["probed"]}\n\n'
        f'[COLOR red]Errors: {stats["errors"]}[/COLOR]   '
        f'[COLOR yellow]Warnings: {stats["warnings"]}[/COLOR]\n'
        f'Expired/unreachable: {stats["expired"]}\n\n'
        f'Report saved to:\n{HEALTH_REPORT_FILE}'
    )
    if issues:
        if dlg.yesno('C.O.S.M.O.S — Playlist health', summary,
                     nolabel='Close', yeslabel='View report'):
            _show_health_report()
    else:
        dlg.ok('C.O.S.M.O.S — Playlist health', summary)


def _show_health_report():
    if not os.path.isfile(HEALTH_REPORT_FILE):
        xbmcgui.Dialog().ok('C.O.S.M.O.S', 'No playlist health report available yet.')
        return
    try:
        with open(HEALTH_REPORT_FILE, 'r', encoding='utf-8') as fp:
            body = fp.read()
    except OSError as e:
        xbmcgui.Dialog().ok('C.O.S.M.O.S', f'Read error: {e}')
        return
    xbmcgui.Dialog().textviewer('Playlist health report', body)
