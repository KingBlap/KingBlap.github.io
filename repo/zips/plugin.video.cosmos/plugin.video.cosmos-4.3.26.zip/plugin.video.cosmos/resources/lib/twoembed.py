"""2Embed movie resolver, based on the CineWave HAR player chain."""
import re
from html import unescape
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

BASE = 'https://www.2embed.cc'
UA = 'Mozilla/5.0'
LIMIT = 2 * 1024 * 1024


def embed_url(tmdb_id, kind='movie', season=0, episode=0):
    # Only the movie route is established by the supplied capture.
    identifier = str(tmdb_id)
    if kind == 'movie' and identifier.isdigit() and int(identifier) > 0:
        return BASE + '/embed/movie/' + identifier
    return ''


class _Frames(HTMLParser):
    def __init__(self):
        super().__init__()
        self.urls = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'iframe':
            attrs = dict(attrs)
            self.urls.append(attrs.get('data-src') or attrs.get('src') or '')


def player_url(body, page):
    parser = _Frames()
    parser.feed(body)
    for raw in parser.urls:
        target = urljoin(page, raw)
        parts = urlsplit(target)
        if parts.scheme == 'https' and parts.hostname == 'streamsrcs.2embed.cc' and parts.path == '/swish':
            return target
    return ''


def host_url(body):
    parser = _Frames()
    parser.feed(body)
    for raw in parser.urls:
        # swish.js in the capture prefixes this identifier with this host.
        if re.fullmatch(r'[a-zA-Z0-9]{12}', raw):
            return 'https://2vcdn.skin/e/' + raw
        target = urljoin('https://2vcdn.skin/', raw)
        parts = urlsplit(target)
        if (parts.scheme == 'https' and parts.hostname == '2vcdn.skin'
                and re.fullmatch(r'/e/[a-zA-Z0-9]{12}/?', parts.path)):
            return target
    return ''


def media_urls(body):
    from .lulustream import _unpack, _unescape_js
    seen = set()
    for text in [body] + list(_unpack(body)):
        for raw in re.findall(r'''https?://[^\s"'<>\\]+''', _unescape_js(text)):
            url = unescape(raw)
            if urlsplit(url).path.lower().endswith(('.txt', '.m3u8')) and url not in seen:
                seen.add(url)
                yield url


def _page(url, referer):
    with urlopen(Request(url, headers={'User-Agent': UA, 'Referer': referer}), timeout=12) as response:
        body = response.read(LIMIT + 1)
    if len(body) > LIMIT:
        raise ValueError('Oversized player page')
    return body.decode('utf-8', errors='replace')


def _failure(stage, reason):
    message = '2Embed %s: %s' % (stage, reason)
    try:
        import xbmc
        xbmc.log('COSMOS ' + message, xbmc.LOGWARNING)
    except ImportError:
        pass
    return {'error': message + ' Try another source.', 'stage': stage}


def resolve(url):
    parts = urlsplit(url)
    if parts.scheme != 'https' or parts.hostname not in ('2embed.cc', 'www.2embed.cc') or not re.fullmatch(r'/embed/movie/\d+', parts.path):
        return None
    stage = 'embed page'
    try:
        wrapper = player_url(_page(url, 'https://watch.cinewave.qzz.io/'), url)
        if not wrapper:
            return _failure(stage, 'no supported player was listed for this movie.')
        stage = 'player wrapper'
        host = host_url(_page(wrapper, url))
        if not host:
            return _failure(stage, 'no supported video host was listed.')
        stage = 'video host'
        headers = {'User-Agent': UA, 'Referer': 'https://2vcdn.skin/'}
        candidates = list(media_urls(_page(host, wrapper)))[:4]
        if not candidates:
            return _failure(stage, 'no HLS media links were found.')
        stage = 'media stream'
        reason = 'the host returned data instead of an HLS playlist.'
        for candidate in candidates:
            try:
                with urlopen(Request(candidate, headers=headers), timeout=12) as response:
                    sample = response.read(4096)
                    final = response.geturl()
                if sample.decode('utf-8-sig', errors='replace').lstrip().startswith('#EXTM3U'):
                    return {'url': final, 'type': 'hls', 'headers': headers}
            except HTTPError as exc:
                reason = 'the media server returned HTTP %s.' % exc.code
                continue
            except (URLError, TimeoutError):
                reason = 'the media server could not be reached or timed out.'
                continue
            except Exception as exc:
                reason = 'media validation failed (%s).' % type(exc).__name__
                continue
        return _failure(stage, reason)
    except HTTPError as exc:
        return _failure(stage, 'the provider returned HTTP %s.' % exc.code)
    except (URLError, TimeoutError):
        return _failure(stage, 'the provider could not be reached or timed out.')
    except Exception as exc:
        return _failure(stage, 'resolution failed (%s).' % type(exc).__name__)
