"""Resolve Streamplay links listed on the matched SRStop episode."""
import re
from http.cookiejar import CookieJar
from urllib.parse import parse_qsl, urlsplit, urlunsplit
from urllib.request import Request, build_opener, HTTPCookieProcessor
from . import srstop


def is_url(url):
    try:
        parts = urlsplit(str(url or ''))
        host = (parts.hostname or '').lower()
        host = host[4:] if host.startswith('www.') else host
        return bool(parts.scheme in ('http', 'https') and not parts.username
                    and host == 'straemplay.org'
                    and re.fullmatch(r'/(?:e/|d/|embed/|embed-)?[A-Za-z0-9_-]+(?:\.html)?/?', parts.path))
    except ValueError:
        return False


def _resolve_host_page(url):
    if not is_url(url):
        return None
    try:
        import resolveurl
        hosted = resolveurl.HostedMediaFile(url=url)
        media = hosted.resolve() if hosted.valid_url() else None
        if media:
            target, _, encoded = media.partition('|')
            stream = {'url': target, 'headers': dict(parse_qsl(encoded)),
                      'type': 'hls' if '.m3u8' in urlsplit(target).path.lower() else 'mp4'}
            if srstop.probe_stream(stream):
                return stream
    except Exception:
        pass
    from .lulustream import UA, _candidates
    parts = urlsplit(url)
    code = parts.path.rstrip('/').rsplit('/', 1)[-1]
    code = re.sub(r'^embed-|\.html$', '', code)
    embed = urlunsplit((parts.scheme, parts.netloc, '/embed-' + code + '.html', parts.query, ''))
    jar = CookieJar()
    opener = build_opener(HTTPCookieProcessor(jar))
    for page in dict.fromkeys((url, embed)):
        try:
            with opener.open(Request(page, headers={'User-Agent': UA, 'Referer': srstop.BASE + '/'}), timeout=12) as response:
                raw = response.read(2 * 1024 * 1024 + 1)
                final = response.geturl()
            if len(raw) > 2 * 1024 * 1024:
                continue
            for stream in _candidates(raw.decode('utf-8', 'replace'), final):
                headers = {'User-Agent': UA, 'Referer': final}
                request = Request(stream['url'])
                jar.add_cookie_header(request)
                if request.get_header('Cookie'):
                    headers['Cookie'] = request.get_header('Cookie')
                stream['headers'] = headers
                if srstop.probe_stream(stream):
                    return stream
        except Exception:
            continue
    return None


def resolve(tmdb_id, season, episode):
    from . import tmdb
    try:
        links = srstop.discover_streamplay(tmdb.get_metadata(tmdb_id, 'tv'), season, episode)
        for link in links:
            try:
                stream = _resolve_host_page(link['url'])
                if stream:
                    return stream
            except Exception:
                continue
        return {'error': 'No Streamplay source passed the playback check. Choose another host.'}
    except srstop.SourceError as exc:
        return {'error': str(exc)}
    except Exception:
        return {'error': 'SRStop / Streamplay could not resolve this episode. Please try again.'}
