# -*- coding: utf-8 -*-
"""RlsBB scraper for C.O.S.M.O.S.

Scrapes https://rlsbb.to/ for Movies and TV Shows content.
Also supports UFC via https://search.rlsbb.to/?s=Ufc and generic search.

Site structure (WordPress):
  - Listing:  <article ...> blocks with <h2 class="entry-title"> and <a> links
  - Detail:   post-content div containing plot text and download links
  - Search:   https://search.rlsbb.to/?s=<query>  (separate subdomain)
"""
import html as _html
import re
import ssl
import xbmc
from urllib.parse import quote_plus
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

_BASE        = 'https://rlsbb.to'
_SEARCH_BASE = 'https://search.rlsbb.to'
_MIRROR_BASES = (
    'https://rlsbb.in',
    'https://rlsbb.ru',
    'https://rlsbb.cc',
)
_MIRROR_SEARCH_BASES = (
    'https://search.rlsbb.in',
    'https://search.rlsbb.ru',
    'https://search.rlsbb.cc',
)
_MIRROR_POST_BASES = (
    'https://post.rlsbb.in',
    'https://post.rlsbb.ru',
    'https://post.rlsbb.cc',
)
_USER_AGENT  = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Safari/537.36'
)

# ── Host / debrid service detection ────────────────────────────────────────
_HOST_MAP = {
    'rapidgator':    'Rapidgator',
    'rg.to':         'Rapidgator',
    'nitroflare':    'Nitroflare',
    'uploady.io':    'Uploady',
    '1fichier':      '1fichier',
    'uploadgig':     'Uploadgig',
    'uploaded':      'Uploaded',
    'ul.to':         'Uploaded',
    'katfile':       'Katfile',
    'filefactory':   'FileFactory',
    'turbobit':      'Turbobit',
    'depositfiles':  'DepositFiles',
    'datafile':      'DataFile',
    'filejoker':     'FileJoker',
    'ddownload':     'DDownload',
    'fboom':         'Fileboom',
    'keep2share':    'Keep2Share',
    'k2s.cc':        'Keep2Share',
    'worldbytez':    'WorldBytez',
    'hotlink.cc':    'Hotlink',
    'filefox':       'FileFox',
    'mega.nz':       'Mega',
    'mega.co':       'Mega',
    'mediafire':     'MediaFire',
    'google.com':    'Google Drive',
    'drive.google':  'Google Drive',
    'dropbox':       'Dropbox',
    'multiup':       'Multiup',
}

# Archive / junk extensions to skip — never treat these as playable
# Note: .torrent is intentionally NOT listed here — it is wanted
_RAR_RE  = re.compile(
    r'\.(?:rar|r\d{2,3}|zip|7z|tar\.gz?|tgz|nfo|sfv|jpg|jpeg|png|gif|srt|sub|idx|txt|exe|iso)(?:\?|#|$)',
    re.I,
)
# Direct-stream extensions we actively want
_DIRECT_VIDEO_RE = re.compile(r'\.(mkv|mp4|avi|mov|m4v|ts|m2ts)(?:\?|#|$)', re.I)
# Torrent: .torrent file URLs or magnet: URIs
_TORRENT_RE = re.compile(r'\.torrent(?:\?|#|$)', re.I)
_MAGNET_RE  = re.compile(r'^magnet:', re.I)
# Quality extraction
_QUAL_RE = re.compile(
    r'(\b(?:2160p|4[Kk]|UHD|1080p|720p|480p|360p|BluRay|BDRip|BRRip|WEB-DL|WEBDl|WEBRip|HDTV|HDCAM|HDTS|CAM|TS|DVDRip|DVDR|x265|HEVC|x264|AVC)\b)',
    re.I,
)
# SxxExx pattern
_SE_RE = re.compile(r'[.\s_]S(\d{1,2})E(\d{1,2})[.\s_]', re.I)


# ── Low-level fetch ─────────────────────────────────────────────────────────

def _make_ssl_ctx():
    """Return a permissive SSL context compatible with Kodi's bundled OpenSSL.

    Kodi ships an older OpenSSL/Python that can produce WRONG_VERSION_NUMBER
    when the server negotiates TLS 1.3 and the client library is too old to
    handle the handshake.  Dropping back to PROTOCOL_TLS with no hostname
    verification resolves this while still encrypting the connection.
    """
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS)          # auto-negotiate best shared version
    except AttributeError:
        ctx = ssl.SSLContext(ssl.PROTOCOL_SSLv23)       # very old Python alias
    ctx.check_hostname = False
    ctx.verify_mode    = ssl.CERT_NONE
    # Prefer TLS 1.2 over TLS 1.3 to avoid version negotiation bugs
    try:
        ctx.maximum_version = ssl.TLSVersion.TLSv1_2
    except AttributeError:
        pass                                            # attribute absent on older builds
    return ctx


_SSL_CTX = _make_ssl_ctx()


def _decode_response(resp):
    """Read and decode a response across Kodi/Python versions."""
    raw = resp.read()
    # Handle any residual content-encoding the server sends despite 'identity'.
    enc = (resp.headers.get('Content-Encoding', '') or '').lower()
    if enc == 'gzip':
        import gzip
        raw = gzip.decompress(raw)
    elif enc in ('deflate', 'zlib'):
        import zlib
        raw = zlib.decompress(raw)

    charset = 'utf-8'
    content_type = resp.headers.get('Content-Type', '') or ''
    match = re.search(r'charset\s*=\s*["\']?([\w.-]+)', content_type, re.I)
    if match:
        charset = match.group(1)
    try:
        return raw.decode(charset, errors='replace')
    except (LookupError, TypeError):
        return raw.decode('utf-8', errors='replace')


def _candidate_urls(url):
    """Return the requested URL followed by equivalent RlsBB mirrors."""
    candidates = [url]
    mirror_groups = (
        (_BASE, _MIRROR_BASES),
        (_SEARCH_BASE, _MIRROR_SEARCH_BASES),
        ('https://post.rlsbb.to', _MIRROR_POST_BASES),
    )
    for primary, mirrors in mirror_groups:
        if url.startswith(primary):
            suffix = url[len(primary):]
            candidates.extend(mirror + suffix for mirror in mirrors)
            break
    return candidates


def _fetch(url, timeout=25):
    """Fetch raw HTML with fallbacks for Kodi's older HTTPS stacks.

    Some Kodi/Python builds reject the ``context=`` keyword or cannot use the
    SSL context created above, while newer builds can. Try the normal urllib
    path first, then retry with the permissive context before reporting an
    actual failure.
    """
    errors = []
    for candidate in _candidate_urls(url):
        req = Request(candidate, headers={
            'User-Agent': _USER_AGENT,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'identity',
            'Connection': 'close',
        })
        for kwargs in ({}, {'context': _SSL_CTX}):
            try:
                resp = urlopen(req, timeout=timeout, **kwargs)
                body = _decode_response(resp)
                if body:
                    if candidate != url:
                        xbmc.log(
                            f'RlsBB: primary unavailable, using mirror {candidate}',
                            xbmc.LOGWARNING,
                        )
                    return body
            except (HTTPError, URLError, OSError, TypeError, ValueError) as exc:
                errors.append(f'{candidate}: {exc}')
            except Exception as exc:
                errors.append(f'{candidate}: {exc}')

    xbmc.log(
        f'RlsBB: fetch failed after mirror fallbacks {url}: '
        f'{" | ".join(errors) or "empty response"}',
        xbmc.LOGERROR,
    )
    return ''


# ── Helpers ─────────────────────────────────────────────────────────────────

def _host_name(url):
    url_l = url.lower()
    for key, name in _HOST_MAP.items():
        if key in url_l:
            return name
    m = re.match(r'https?://(?:www\.)?([^/]+)', url_l)
    if m:
        return m.group(1).split('.')[0].title()
    return 'Link'


def _quality(title):
    hits = _QUAL_RE.findall(title)
    return ' '.join(hits) if hits else ''


def _detect_content(title):
    se = _SE_RE.search(title)
    if se:
        return 'episode', se.group(1).zfill(2), se.group(2).zfill(2)
    return 'movie', '', ''


def _is_archive(url):
    return bool(_RAR_RE.search(url))


def _is_direct_video(url):
    """Return True if the URL points to a direct .mkv / .mp4 stream."""
    return bool(_DIRECT_VIDEO_RE.search(url))


def _is_torrent(url):
    """Return True if the URL is a .torrent file or a magnet: URI."""
    return bool(_TORRENT_RE.search(url)) or bool(_MAGNET_RE.match(url))


def _clean_title(raw):
    """Strip HTML tags and decode entities."""
    return _html.unescape(re.sub(r'<[^>]+>', '', raw)).strip()


# ── Listing page scraper ─────────────────────────────────────────────────────

def _scrape_listing(html):
    """Parse a RlsBB listing/archive page and return items.

    RlsBB uses a WordPress theme.  Posts appear as <article> blocks.
    The title is in the first <h1> or <h2> within that article.
    The thumbnail is in an <img> inside a .entry-image / .post-thumbnail div
    or the first <img> before the content.
    """
    items = []

    # Match every <article …>…</article> block
    for art_m in re.finditer(r'<article\b[^>]*>(.*?)</article>', html, re.DOTALL | re.I):
        art = art_m.group(1)

        # ── Title + permalink ─────────────────────────────────────────────
        title = ''
        link  = ''
        # Try: <h1 …><a href="…">Title</a></h1>  or  <h2 …><a …>…</a></h2>
        hm = re.search(
            r'<h[12][^>]*>.*?<a\s[^>]*href=["\']?([^"\'>\s]+)["\']?[^>]*>(.*?)</a>.*?</h[12]>',
            art, re.DOTALL | re.I,
        )
        if hm:
            link  = hm.group(1).strip()
            title = _clean_title(hm.group(2))
        if not title:
            # Fallback: entry-title class
            tm = re.search(r'class=["\'][^"\']*entry-title[^"\']*["\'][^>]*>(.*?)</[^>]+>', art, re.DOTALL | re.I)
            if tm:
                am = re.search(r'<a\s[^>]*href=["\']?([^"\'>\s]+)["\']?[^>]*>(.*?)</a>', tm.group(1), re.DOTALL | re.I)
                if am:
                    link  = am.group(1).strip()
                    title = _clean_title(am.group(2))
                else:
                    title = _clean_title(tm.group(1))

        if not title:
            continue

        # Some RlsBB mirrors inject informational/navigation pages as
        # ``article`` blocks (for example support-us). They are not releases
        # and must never be sent to the detail/source-picker route.
        link_l = link.lower()
        if any(token in link_l for token in (
                '/support-us', '/contact', '/privacy', '/dmca', '/donate',
                '/about', '/login', '/author/', '/category/', '/tag/',
                '/page/', '/feed/')):
            continue

        # ── Thumbnail ────────────────────────────────────────────────────
        poster = ''
        # Look for og:image meta — sometimes embedded in article JSON-LD; skip
        # Prefer thumbnail / wp-post-image class
        im = re.search(
            r'<img\b[^>]*class=["\'][^"\']*(?:wp-post-image|attachment-post-thumbnail|post-image)[^"\']*["\'][^>]*>',
            art, re.I,
        )
        # The current archive markup puts a scene/p2p badge in the date
        # header before the actual release artwork. Prefer images from the
        # summary/content blocks and ignore theme badges/icons.
        image_scopes = []
        for scope_m in re.finditer(
            r'<(?:div|section)\b[^>]*class=["\'][^"\']*entry-(?:summary|content)[^"\']*["\'][^>]*>(.*?)</(?:div|section)>',
            art, re.DOTALL | re.I,
        ):
            image_scopes.append(scope_m.group(1))
        image_scopes.append(art)
        for scope in image_scopes:
            for image_m in re.finditer(r'<img\b[^>]*>', scope, re.I):
                src_m = re.search(r'\bsrc=["\']?([^"\'>\s]+)["\']?', image_m.group(0), re.I)
                if not src_m:
                    continue
                candidate = src_m.group(1)
                candidate_l = candidate.lower()
                if any(token in candidate_l for token in (
                    '/wp-content/', 'p2p.', 'scene.', 'icon', 'sprite',
                    'logo', 'avatar', 'gravatar', 'button', 'banner',
                )):
                    continue
                poster = candidate
                break
            if poster:
                break

        # ── Plot snippet ─────────────────────────────────────────────────
        plot = ''
        pm = re.search(r'<div\b[^>]*class=["\'][^"\']*entry-summary[^"\']*["\'][^>]*>(.*?)</div>', art, re.DOTALL | re.I)
        if not pm:
            pm = re.search(r'<p[^>]*>(.*?)</p>', art, re.DOTALL | re.I)
        if pm:
            plot = _clean_title(pm.group(1))

        content, season, episode = _detect_content(title)
        quality = _quality(title)
        items.append({
            'title':   title,
            'link':    link,
            'poster':  poster,
            'plot':    plot,
            'quality': quality,
            'content': content,
            'season':  season,
            'episode': episode,
        })

    return items


def _has_next_page(html, page):
    """Return True if the HTML contains a link to page+1."""
    return bool(re.search(rf'[/?]page[/=]{page + 1}', html, re.I))


# ── Public API ───────────────────────────────────────────────────────────────

def scrape_listing(url, page=1):
    """Fetch a listing URL (with optional pagination) and return items."""
    if page > 1:
        url = f'{url.rstrip("/")}/page/{page}/'
    html = _fetch(url)
    if not html:
        return [], False
    items    = _scrape_listing(html)
    has_next = _has_next_page(html, page)
    return items, has_next


def get_items_for_category(category_path, page=1):
    """Fetch a named category from rlsbb.to.
    category_path is like 'movies' or 'tv-show' or 'movies/bluray-1080p'.
    """
    url = f'{_BASE}/category/{category_path.strip("/")}/'
    return scrape_listing(url, page=page)


def get_latest(page=1):
    """Fetch the home page (latest releases)."""
    return scrape_listing(_BASE + '/', page=page)


def get_ufc(page=1):
    """Fetch UFC content via search.rlsbb.to."""
    return get_search_results('UFC', page=page)


def get_search_results(query, page=1):
    """Search rlsbb via search.rlsbb.to and return (items, has_next)."""
    encoded = quote_plus(query)
    if page > 1:
        url = f'{_SEARCH_BASE}/page/{page}/?s={encoded}'
    else:
        url = f'{_SEARCH_BASE}/?s={encoded}'
    # ``url`` already contains the requested page for searches. Passing the
    # same page to scrape_listing() would append /page/N/ a second time.
    return scrape_listing(url, page=1)


# ── Detail page scraper ──────────────────────────────────────────────────────

# Domains that are NEVER download hosts on rlsbb — skip every href from these
_SKIP_DOMAINS_RE = re.compile(
    r'(?:imdb\.com|youtube\.com|youtu\.be|limetorrents\.|rlsbb\.to|rlsbb\.ru|'
    r'img\.protected\.to|nfo\.protected\.to|picimg\.net|s\d*\.picimg\.net|'
    r'cdn\.picimg\.net|filespayouts\.com|fast-down\.com|mdiaload\.com|'
    r'fileq\.net|frdl\.io|usersdrive\.com|dailyuploads\.net|mega4upload\.|'
    r'clicknupload\.|megalinks\.|10play\.com|thetvdb\.com|'
    r'post\.rlsbb\.to/(?:author|tag|rapidgator-reseller|category|page))',
    re.I,
)

# Anchor-text patterns that are navigation/metadata — not download links
_SKIP_TEXT_RE = re.compile(
    r'^(?:awards?|see\s*more\s*awards?|imdb|trailer|nfo|subtitles?|'
    r'screenshot|#\d+|homepage|tvdb|torrent\s*search|movies?|top|'
    r'bluray\s*\d+p?|web[\-\s]?dl|view\s*all\s*posts?|previous\s*post|'
    r'next\s*post|leave\s*a\s*comment|purchasing|single\s*file\s*rar|'
    r'backup|p2p|\[\s*p2p\s*\])',
    re.I,
)

# Anchor text patterns that identify the host when behind protected.to
_PROT_HOST_RE = re.compile(
    r'(rapid\s*gator|rapidgator|rapida?g|nitroflare|nitro\s*flare|nitro|uploady)',
    re.I,
)


def resolve_uploady_redirect(url):
    """Follow an RlsBB protected Uploady link to its real Uploady URL."""
    try:
        req = Request(url, headers={'User-Agent': _UA, 'Accept': 'text/html,*/*'})
        with urlopen(req, timeout=20) as response:
            final_url = response.geturl()
        if 'uploady.io/' in (final_url or '').lower():
            return final_url
    except Exception as exc:
        xbmc.log(f'RlsBB Uploady redirect failed: {exc}', xbmc.LOGDEBUG)
    return url


def _link_quality(url):
    """Extract quality tag from a file-host URL's filename component."""
    # e.g. rapidgator.net/file/.../Movie.2026.1080p.BluRay.mkv.html → "1080p BluRay"
    fname = url.rstrip('/').split('/')[-1]
    fname = re.sub(r'\.html?', '', fname, flags=re.I)
    return _quality(fname)


def scrape_detail(url):
    """Fetch a post page on post.rlsbb.to and return metadata + clean links.

    Only Rapidgator and Nitroflare links are surfaced — either as direct
    host URLs (rapidgator.net/file/, nitroflare.com/view/) or via their
    anchor text when wrapped in a protected.to redirect.  Everything else
    (limetorrents search pages, file-mirror hosts, navigation, JS, CSS)
    is discarded so no "Direct Link" noise appears in the picker.
    """
    html = _fetch(url)
    if not html:
        return None

    # ── Title ──────────────────────────────────────────────────────────────
    title = ''
    tm = re.search(r'<title[^>]*>(.*?)</title>', html, re.DOTALL | re.I)
    if tm:
        raw = _clean_title(tm.group(1))
        raw = re.sub(r'\s*[-–|]\s*(?:ReleaseBB|RlsBB).*', '', raw, flags=re.I).strip()
        title = raw
    if not title:
        for tag in ('h1', 'h2'):
            m = re.search(rf'<{tag}[^>]*>(.*?)</{tag}>', html, re.DOTALL | re.I)
            if m:
                title = _clean_title(m.group(1))
                if title:
                    break

    # ── Isolate entry-content div ──────────────────────────────────────────
    # Scope all extraction to this block only — avoids pulling in nav/sidebar
    content_m = re.search(
        r'<div\b[^>]+class=["\'][^"\']*entry-content[^"\']*["\'][^>]*>([\s\S]{50,60000}?)</div>',
        html, re.I,
    )
    content_html = content_m.group(1) if content_m else html

    # ── Poster ─────────────────────────────────────────────────────────────
    # rlsbb posts have no og:image; the first <img> in entry-content IS the poster
    poster = ''
    for im in re.finditer(r'<img\b[^>]*src=["\']?(https?://[^"\'>\s]+)["\']?', content_html, re.I):
        src = im.group(1)
        # Skip known non-poster domains (icons, avatars, ads)
        if any(x in src.lower() for x in ('imdb', 'gravatar', 'icon', 'sprite', 'logo',
                                            'facebook', 'twitter', 'button', 'banner',
                                            'radio_', 'auth_', 'btn_')):
            continue
        poster = src
        break

    # ── Plot ───────────────────────────────────────────────────────────────
    # Extract only the sentence(s) after "Plot:" — stops before the next
    # <strong> block (Genre, IMDB rating, Directed by…) or end of paragraph.
    plot = ''
    pm = re.search(
        r'<strong[^>]*>\s*Plot\s*:?\s*</strong>\s*(.*?)(?=<strong|</p>)',
        content_html, re.DOTALL | re.I,
    )
    if pm:
        plot = _clean_title(pm.group(1)).strip()
    if not plot:
        # Fallback: og:description meta
        og = re.search(
            r'<meta\b[^>]*name=["\']description["\'][^>]*content=["\']([^"\']+)["\']',
            html, re.I,
        )
        if og:
            plot = _html.unescape(og.group(1))

    content, season, episode = _detect_content(title)
    quality = _quality(title)

    # ── Links ──────────────────────────────────────────────────────────────
    # We accept only:
    #   • rapidgator.net/file/  — direct Rapidgator URL (debrid-compatible)
    #   • nitroflare.com/view/  — direct Nitroflare URL (debrid-compatible)
    #   • uploady.io/…         — Uploady API-resolved file URL
    #   • protected.to/f-*      — only when anchor text names Rapidgator or
    #                             Nitroflare explicitly (e.g. "RAPiDGATOR")
    #   • .torrent / magnet:    — torrent files and magnet URIs
    #
    # Everything else is discarded: filespayouts, fast-down, mdiaload,
    # fileq, frdl.io, usersdrive, limetorrents search pages, navigation
    # links, CSS/JS assets, imdb.com, youtube.com, etc.

    links     = []
    seen_urls = set()

    def _add(href, host_name, link_quality_tag=''):
        href = href.strip().rstrip('.,;)"\'')
        if not href or href in seen_urls:
            return
        seen_urls.add(href)
        links.append({
            'host':    host_name,
            'label':   host_name,
            'url':     href,
            'quality': link_quality_tag,
        })

    # Walk every anchor tag inside entry-content only
    for anchor_m in re.finditer(
        r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>([\s\S]*?)</a>',
        content_html, re.I,
    ):
        href = anchor_m.group(1).strip()
        text = _clean_title(anchor_m.group(2)).strip()

        if not href or href.startswith('#'):
            continue

        # Skip domains we never want
        if _SKIP_DOMAINS_RE.search(href):
            continue

        # Skip pure navigation anchor texts
        if _SKIP_TEXT_RE.match(text):
            continue

        href_l = href.lower()

        # ── Direct Rapidgator ─────────────────────────────────────────
        if 'rapidgator.net/file/' in href_l:
            _add(href, 'Rapidgator', _link_quality(href))
            continue

        # ── Direct Nitroflare ─────────────────────────────────────────
        if 'nitroflare.com/view/' in href_l:
            _add(href, 'Nitroflare', _link_quality(href))
            continue

        if 'uploady.io/' in href_l:
            _add(href, 'Uploady', _link_quality(href))
            continue

        # ── protected.to with labeled host ────────────────────────────
        if 'protected.to/f-' in href_l:
            # "RAPiDGATOR Backup" — skip backup/mirror duplicates when we
            # already have a primary link for that host
            host_name = ''
            prot_match = _PROT_HOST_RE.search(text)
            if prot_match:
                matched_host = prot_match.group(1).lower()
                if 'rapidgator' in matched_host or 'rapida' in matched_host:
                    host_name = 'Rapidgator'
                elif 'nitroflare' in matched_host or 'nitro' in matched_host:
                    host_name = 'Nitroflare'
                elif 'uploady' in matched_host:
                    host_name = 'Uploady'
            if not host_name:
                continue  # unlabeled protected link — skip
            is_backup = bool(re.search(r'backup|mirror|alt', text, re.I))
            # Check if we already have a DIRECT link for this host; if so,
            # only add the protected link if there is no direct one yet
            already_direct = any(
                lk['host'] == host_name and 'protected.to' not in lk['url'].lower()
                for lk in links
            )
            if not already_direct and not is_backup:
                _add(href, host_name, '')
            continue

        # ── Actual .torrent file ───────────────────────────────────────
        if _is_torrent(href):
            _add(href, 'Torrent', '')
            continue

        # ── Magnet URI ────────────────────────────────────────────────
        if _MAGNET_RE.match(href):
            _add(href, 'Magnet', '')
            continue

    return {
        'title':   title,
        'poster':  poster,
        'plot':    plot,
        'quality': quality,
        'content': content,
        'season':  season,
        'episode': episode,
        'links':   links,
    }
