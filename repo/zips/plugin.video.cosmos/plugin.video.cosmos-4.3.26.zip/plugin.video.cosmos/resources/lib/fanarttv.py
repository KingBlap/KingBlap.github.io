# -*- coding: utf-8 -*-
"""Fanart.tv artwork fallback client (API v3.2)."""
import json
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


API_BASE = 'https://webservice.fanart.tv/v3.2'
_CACHE = {}


def _request(resource, media_id, key, key_header='api-key', timeout=12):
    url = '%s/%s/%s' % (API_BASE, resource, quote(str(media_id), safe=''))
    request = Request(url, headers={
        key_header: key,
        'Accept': 'application/json',
        'User-Agent': 'COSMOS/4.1.88',
    })
    with urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode('utf-8', 'replace'))


def _best(data, names, language='en'):
    candidates = []
    for name in names:
        for image in (data.get(name) or []):
            if isinstance(image, dict) and image.get('url'):
                candidates.append(image)
    if not candidates:
        return ''
    preferred = str(language or 'en').split('-', 1)[0].lower()
    language_rank = {preferred: 2, '00': 1, '': 0}
    candidates.sort(key=lambda image: (
        language_rank.get(str(image.get('lang') or '').lower(), -1),
        int(image.get('likes') or 0),
        int(image.get('width') or 0) * int(image.get('height') or 0),
    ), reverse=True)
    return str(candidates[0]['url']).replace('http://', 'https://', 1)


def artwork(media_id, content, api_key, language='en'):
    """Return poster/fanart URLs or an empty dict without raising."""
    key = str(api_key or '').strip()
    media_id = str(media_id or '').strip()
    if not key or not media_id:
        return {}
    is_movie = content == 'movie'
    resource = 'movies' if is_movie else 'tv'
    cache_key = (resource, media_id, key, language)
    if cache_key in _CACHE:
        return dict(_CACHE[cache_key])
    data = None
    try:
        data = _request(resource, media_id, key, 'api-key')
    except HTTPError as exc:
        # Current API also permits a personal key by itself as client-key.
        if exc.code == 401:
            try:
                data = _request(resource, media_id, key, 'client-key')
            except (HTTPError, URLError, ValueError, OSError):
                data = None
    except (URLError, ValueError, OSError):
        data = None
    if not isinstance(data, dict):
        _CACHE[cache_key] = {}
        return {}
    if is_movie:
        result = {
            'poster': _best(data, ('movieposter',), language),
            'fanart': _best(data, ('moviebackground',), language),
        }
    else:
        result = {
            'poster': _best(data, ('tvposter',), language),
            'fanart': _best(data, ('showbackground',), language),
        }
    result = {name: value for name, value in result.items() if value}
    _CACHE[cache_key] = result
    return dict(result)
