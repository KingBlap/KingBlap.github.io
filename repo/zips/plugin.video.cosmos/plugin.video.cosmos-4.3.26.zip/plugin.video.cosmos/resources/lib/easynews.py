# -*- coding: utf-8 -*-
import base64
import json
from urllib.parse import quote, urlencode, urlparse, urlunparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
import xbmc
import xbmcaddon

class EasyNewsAPI:
    def __init__(self):
        self.BASE_API = 'https://members.easynews.com/2.0/search/solr-search/'
        self.NZB_API = 'https://members.easynews.com/2.0/api/dl-nzb'
        self.addon = xbmcaddon.Addon('plugin.video.cosmos')

    def _get_credentials(self):
        username = (self.addon.getSetting('easynews_username') or '').strip()
        password = (self.addon.getSetting('easynews_password') or '').strip()
        return username, password

    def has_credentials(self):
        """Return whether Easynews is configured without making a request."""
        username, password = self._get_credentials()
        return bool(username and password)

    @staticmethod
    def _auth_header(username, password):
        auth_str = f'{username}:{password}'
        encoded_auth = base64.b64encode(auth_str.encode('utf-8')).decode('ascii')
        return {
            'Authorization': f'Basic {encoded_auth}',
            'User-Agent': 'COSMOS-Kodi/4.0.0',
        }

    def test_login(self):
        """Test credentials against Easynews API."""
        username, password = self._get_credentials()
        if not username or not password:
            return False
        
        params = {
            'fly': '2', 'sb': '1', 'pno': '1', 'pby': '1', 'u': '1',
            'chxu': '1', 'chxgx': '1', 'st': 'basic', 'gps': 'test',
            'vv': '1', 'safeO': '0', 's1': 'relevance', 's1d': '-',
            'fty[]': 'VIDEO',
        }
        url = f"{self.BASE_API}?{urlencode(params)}"
        headers = self._auth_header(username, password)
        
        try:
            req = Request(url, headers=headers)
            with urlopen(req, timeout=10) as response:
                return response.getcode() == 200
        except HTTPError as e:
            # A 401 Unauthorized is a valid response for failed login, not an exception to be broadly caught.
            if e.code == 401:
                xbmc.log('COSMOS Easynews: Login failed with 401 Unauthorized. Check credentials.', xbmc.LOGWARNING)
            else:
                xbmc.log(f'COSMOS Easynews test_login HTTPError: {e.code} {e.reason}', xbmc.LOGWARNING)
            return False
        except URLError as e:
            xbmc.log(f'COSMOS Easynews test_login URLError: {e.reason}', xbmc.LOGWARNING)
            return False
        except Exception as e:
            xbmc.log(f'COSMOS Easynews test_login failed with unexpected error: {e}', xbmc.LOGWARNING)
            return False

    def search(self, query):
        """Query Easynews API and return a list of result dictionaries."""
        username, password = self._get_credentials()
        if not username or not password:
            return []
        
        safe_search = self.addon.getSetting('easynews_safe_search') != 'false'

        params = [
            ('fly', '2'), ('sb', '1'), ('pno', '1'), ('pby', '250'),
            ('u', '1'), ('chxu', '1'), ('chxgx', '1'), ('st', 'basic'),
            ('gps', query), ('vv', '1'), ('safeO', '0' if safe_search else '1'),
            ('s1', 'relevance'), ('s1d', '-'), ('fty[]', 'VIDEO'),
        ]
        
        url = f"{self.BASE_API}?{urlencode(params)}"
        headers = self._auth_header(username, password)
        
        try:
            req = Request(url, headers=headers)
            with urlopen(req, timeout=15) as response:
                if response.getcode() != 200:
                    xbmc.log(f'COSMOS Easynews search failed with status {response.getcode()}', xbmc.LOGWARNING)
                    return []
                body = response.read().decode('utf-8')
                data = json.loads(body)

                if 'error' in data:
                    xbmc.log(f"COSMOS Easynews API error: {data['error']}", xbmc.LOGWARNING)
                    return []

                sources = []
                items = data.get('data', []) if isinstance(data, dict) else []
                if isinstance(items, dict):
                    items = (
                        items.get('results')
                        or items.get('items')
                        or items.get('files')
                        or []
                    )
                if not isinstance(items, list):
                    items = []

                response_meta = data if isinstance(data, dict) else {}
                for item in items:
                    normalized = self._normalize_item(item, response_meta)
                    if not normalized:
                        continue
                    raw_url = normalized.get('down_url', '')
                    parsed = urlparse(raw_url)
                    host = parsed.hostname or ''
                    if not parsed.scheme or not host:
                        continue
                    try:
                        port = f':{parsed.port}' if parsed.port else ''
                    except ValueError:
                        port = ''
                    auth_netloc = (
                        f'{quote(username, safe="")}:{quote(password, safe="")}@'
                        f'{host}{port}'
                    )
                    normalized['url_dl'] = urlunparse((
                        parsed.scheme, auth_netloc,
                        parsed.path, parsed.params, parsed.query, parsed.fragment
                    ))
                    sources.append(normalized)
                return sources
        except HTTPError as e:
            if e.code == 401:
                xbmc.log('COSMOS Easynews search: 401 Unauthorized. Check credentials.', xbmc.LOGWARNING)
            else:
                xbmc.log(f'COSMOS Easynews search HTTPError: {e.code} {e.reason}', xbmc.LOGWARNING)
            return []
        except URLError as e:
            xbmc.log(f'COSMOS Easynews search URLError: {e.reason}', xbmc.LOGWARNING)
            return []
        except json.JSONDecodeError:
            xbmc.log('COSMOS Easynews search: Failed to decode JSON response.', xbmc.LOGWARNING)
            return []
        except Exception as e:
            xbmc.log(f'COSMOS Easynews search failed with unexpected error: {e}', xbmc.LOGWARNING)
            return []

    @staticmethod
    def _list_value(item, index, default=None):
        return item[index] if isinstance(item, list) and len(item) > index else default

    @staticmethod
    def _as_int(value, default=0):
        try:
            return int(value or 0)
        except (TypeError, ValueError, OverflowError):
            return default

    def _normalize_item(self, item, response_meta):
        """Normalize the current Easynews list-array and legacy dict shapes."""
        if isinstance(item, list):
            raw_hash = self._list_value(item, 0, '')
            filename = self._list_value(item, 10, '') or raw_hash
            ext = self._list_value(item, 11, '') or ''
            subject = self._list_value(item, 6, '') or filename
            # The current official list-array shape does not expose a stable
            # byte-size field; keep this unknown rather than guessing from a
            # positional value that may be another metadata field.
            raw_size = 0
            width = 0
            sig = None
            file_id = ''
        elif isinstance(item, dict):
            raw_hash = item.get('hash') or item.get('id') or ''
            filename = item.get('filename') or item.get('name') or raw_hash
            ext = item.get('ext') or item.get('extension') or ''
            subject = item.get('subject') or filename
            raw_size = item.get('size') or item.get('postSize') or item.get('length') or 0
            width = item.get('video_width') or item.get('width') or 0
            sig = item.get('sig')
            file_id = item.get('fileId') or ''
        else:
            return None

        raw_hash = str(raw_hash or '').strip()
        if not raw_hash:
            return None
        ext = str(ext or '').strip()
        if ext and not ext.startswith('.'):
            ext = '.' + ext
        filename = str(filename or raw_hash).strip()
        if filename.lower().endswith(ext.lower()) and ext:
            filename = filename[:-len(ext)]

        down_url = response_meta.get('downURL') or response_meta.get('downUrl') or ''
        parsed = urlparse(down_url)
        if not parsed.scheme:
            down_url = 'https://members.easynews.com/dl'
        else:
            down_url = down_url.rstrip('/')
        farm = str(response_meta.get('dlFarm') or 'auto')
        port = self._as_int(response_meta.get('dlPort'), 443)
        sid = str(response_meta.get('sid') or '')
        file_part = f'{raw_hash}{file_id}{ext}'
        name_part = f'{filename}{ext}'
        query = {}
        if sid:
            query['sid'] = sid
        if sig:
            query['sig'] = str(sig)
        raw_url = f'{down_url}/{farm}/{port}/{quote(file_part, safe="")}/{quote(name_part, safe="")}'
        if query:
            raw_url = f'{raw_url}?{urlencode(query)}'
        raw_size = self._as_int(raw_size)
        return {
            'name': str(subject),
            # The scraper and direct-playback path consume url_dl.  Keep the
            # authenticated URL here; down_url is retained as the raw API
            # field for callers that need to inspect it.
            'url_dl': raw_url,
            'down_url': raw_url,
            'rawSize': raw_size,
            'width': self._as_int(width),
            'language': None,
            # Some current Easynews list-array responses omit size.  Unknown
            # size must not be treated as a tiny sample or every result is
            # discarded by the scraper.
            'short_vid': bool(raw_size and raw_size < 20971520),
            'hash': raw_hash,
            'fileId': str(file_id or ''),
            'filename': filename,
            'ext': ext,
            'sig': sig,
        }

    def download_nzb(self, item, title='Cosmos'):
        """Download one NZB from Easynews' official API."""
        username, password = self._get_credentials()
        if not username or not password or not isinstance(item, dict):
            return b''
        file_hash = str(item.get('hash') or '')
        filename = str(item.get('filename') or item.get('name') or file_hash)
        ext = str(item.get('ext') or '')
        sig = item.get('sig')
        if not file_hash:
            return b''
        value = (
            f'{file_hash}|{base64.b64encode(filename.encode("utf-8")).decode("ascii").rstrip("=")}:'
            f'{base64.b64encode(ext.encode("utf-8")).decode("ascii").rstrip("=")}'
        )
        key = '0' if not sig else f'0&sig={sig}'
        form = [('autoNZB', '1'), (key, value), ('nameZipQ0', title or filename)]
        body = urlencode(form).encode('utf-8')
        try:
            request = Request(
                self.NZB_API,
                data=body,
                headers=dict(self._auth_header(username, password),
                             **{'Content-Type': 'application/x-www-form-urlencoded'}),
            )
            with urlopen(request, timeout=30) as response:
                if response.getcode() != 200:
                    return b''
                return response.read()
        except (HTTPError, URLError, ValueError) as exc:
            xbmc.log(f'COSMOS Easynews NZB request failed: {exc}', xbmc.LOGWARNING)
            return b''

# Singleton instance for other modules to import
EasyNews = EasyNewsAPI()

# Backward-compatible functions
def test_login():
    return EasyNews.test_login()

def search(query, season='', episode=''):
    s_str = str(season).zfill(2) if season else ''
    e_str = str(episode).zfill(2) if episode else ''
    search_query = f"{query} S{s_str}E{e_str}".strip() if s_str and e_str else query
    results = EasyNews.search(search_query)
    return [{
        'label': f"Easynews | {i['name']}",
        'url': i['url_dl'],
        'source': 'Easynews',
        'size': i['rawSize'],
        'hash': i.get('hash', ''),
        'fileId': i.get('fileId', ''),
        'filename': i.get('filename', ''),
        'ext': i.get('ext', ''),
        'sig': i.get('sig'),
    } for i in results]
