"""Synchronise Cosmos premium logins through installed ResolveURL plugins."""
import importlib
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon


def sync_credentials():
    """Return synced and failed host names; never log account secrets.

    Empty Cosmos accounts leave independently configured ResolveURL accounts alone.
    Plugin setting APIs supply the correct class-prefixed IDs for each version.
    """
    addon = xbmcaddon.Addon('plugin.video.cosmos')
    synced, failed = [], []
    for host, domain in (('rapidgator', 'rapidgator.net'), ('nitroflare', 'nitroflare.com')):
        username = (addon.getSetting(host + '_username') or '').strip()
        password = addon.getSetting(host + '_password') or ''
        if not username or not password:
            continue
        try:
            module = importlib.import_module('resolveurl.plugins.' + host)
            resolver = next(value for value in vars(module).values()
                            if isinstance(value, type) and domain in getattr(value, 'domains', []))
            fields = {ET.fromstring(element).get('id') for element in resolver.get_settings_xml()}
            prefix = resolver.__name__ + '_'
            if not {prefix + 'username', prefix + 'password'}.issubset(fields):
                raise ValueError('Unsupported credential settings')
            changed = (resolver.get_setting('username') != username
                       or resolver.get_setting('password') != password)
            if changed and prefix + 'session_id' in fields:
                resolver.set_setting('session_id', '')
            values = {'username': username, 'password': password}
            for key in ('enabled', 'login', 'premium'):
                if prefix + key in fields:
                    values[key] = 'true'
            for key, value in values.items():
                if resolver.get_setting(key) != value:
                    resolver.set_setting(key, value)
                if resolver.get_setting(key) != value:
                    raise ValueError('Setting not retained')
            synced.append(host.capitalize())
        except Exception:
            failed.append(host.capitalize())
            xbmc.log('COSMOS: %s credential sync unavailable or failed' % host.capitalize(), xbmc.LOGWARNING)
    return synced, failed
