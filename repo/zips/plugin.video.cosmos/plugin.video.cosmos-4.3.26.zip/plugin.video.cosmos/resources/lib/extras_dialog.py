# -*- coding: utf-8 -*-
"""
CosmosExtrasDialog — full Extras window for C.O.S.M.O.S.

Opens a WindowXMLDialog (CosmosExtras.xml) showing eight sections for any
movie or TV show:

  Plot · Cast · Recommended · Similar · Reviews · Trivia · Blunders · Parental Guide

Data sources
------------
- Plot, Cast          : TMDB v3 (from pre-fetched meta dict)
- Recommended/Similar : TMDB /recommendations and /similar endpoints
- Reviews             : TMDB /reviews endpoint
- Trivia              : IMDb /trivia page scrape
- Blunders            : IMDb /goofs page scrape
- Parental Guide      : TMDB content-ratings + IMDb /parentalguide scrape

Works for Enigma XML movies, Enigma XML TV shows, and DDLValley items.
When tmdb_id is empty the dialog still opens using whatever metadata was
passed in (plot, cast list, poster) — TMDB-dependent tabs show empty cards.
"""

import json
import re
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from . import tmdb as tmdb_mod

_ADDON_ID   = 'plugin.video.cosmos'
_ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{_ADDON_ID}/')

_TMDB_BASE  = 'https://api.themoviedb.org/3'
_IMG_W185   = 'https://image.tmdb.org/t/p/w185'

# Kodi action IDs that should close the dialog (Back / Esc / etc.)
_CLOSE_IDS  = (9, 10, 92, 216, 247, 257, 13)

# Button-id → (tab-key,  section label,  panel-control-id or None for plain text)
_TABS = {
    10: ('plot',        'Plot',           None),
    11: ('cast',        'Cast',           2051),
    12: ('recommended', 'Recommended',    2052),
    13: ('similar',     'Similar',        2053),
    14: ('reviews',     'Reviews',        2054),
    15: ('trivia',      'Trivia',         2055),
    16: ('blunders',    'Blunders',       2056),
    17: ('parental',    'Parental Guide', 2057),
}

_BTN_LABELS = {
    10: 'Plot',
    11: 'Cast',
    12: 'Recommended',
    13: 'Similar',
    14: 'Reviews',
    15: 'Trivia',
    16: 'Blunders',
    17: 'Parental Guide',
}


class CosmosExtrasDialog(xbmcgui.WindowXMLDialog):
    """Full-screen Extras metadata dialog (dark-blue theme)."""

    def __new__(cls, *args, **kwargs):
        # WindowXMLDialog.__new__ only accepts the first 4 positional args
        return super().__new__(cls, *args[:4])

    def __init__(self, *args, **kwargs):
        self.meta     = kwargs.get('meta')     or {}
        self.tmdb_id  = str(kwargs.get('tmdb_id')  or '')
        self.content  = kwargs.get('content')  or 'movie'
        self.poster   = kwargs.get('poster')   or ''
        self.fanart   = kwargs.get('fanart')   or ''

    # ──────────────────────────────────────────────────────────────────────
    # Kodi lifecycle
    # ──────────────────────────────────────────────────────────────────────

    def onInit(self):
        m = self.meta

        # ── Core properties used by the XML template ──
        self.setProperty('ce_title',    m.get('title')    or '')
        self.setProperty('ce_tagline',  m.get('tagline')  or '')
        self.setProperty('ce_year',     str(m.get('year') or ''))
        self.setProperty('ce_genre',    m.get('genre')    or '')
        self.setProperty('ce_director', m.get('director') or '')
        self.setProperty('ce_plot',     m.get('plot')     or '')
        self.setProperty('ce_plot_full', m.get('plot')    or '')
        self.setProperty('ce_poster',   self.poster or m.get('poster') or '')
        self.setProperty('ce_fanart',   self.fanart or m.get('fanart') or '')

        rating = m.get('rating') or 0
        self.setProperty('ce_rating', f'{float(rating):.1f}' if rating else '')

        runtime = m.get('runtime') or 0
        if runtime:
            mins = int(runtime / 60) if runtime > 120 else int(runtime)
            self.setProperty('ce_runtime', f'{mins} min')
        else:
            self.setProperty('ce_runtime', '')

        # ── Button labels ──
        for btn_id, label in _BTN_LABELS.items():
            self.setProperty(f'btn{btn_id}_label', label)

        # ── Default to Cast tab ──
        self._switch_tab(11, set_focus=False)

        # ── Load all panel data ──
        self._load_all_data()

        # Now set focus into the cast panel
        try:
            self.setFocusId(2051)
        except Exception:
            pass

    def onClick(self, controlID):
        if controlID == 9001:
            self.close()
            return
        if controlID in _TABS:
            self._switch_tab(controlID, set_focus=True)

    def onAction(self, action):
        if action.getId() in _CLOSE_IDS:
            self.close()

    # ──────────────────────────────────────────────────────────────────────
    # Tab switching
    # ──────────────────────────────────────────────────────────────────────

    def _switch_tab(self, btn_id, set_focus=True):
        tab, label, panel_id = _TABS.get(btn_id, ('cast', 'Cast', 2051))
        self.setProperty('ce_tab',           tab)
        self.setProperty('ce_section_label', label)
        self.setProperty('ce_section_count', '')
        if set_focus and panel_id:
            try:
                xbmc.sleep(80)
                self.setFocusId(panel_id)
            except Exception:
                pass

    # ──────────────────────────────────────────────────────────────────────
    # Data loading
    # ──────────────────────────────────────────────────────────────────────

    def _load_all_data(self):
        key      = (xbmcaddon.Addon().getSetting('tmdb_api_key') or tmdb_mod.DEFAULT_API_KEY).strip()
        tid      = self.tmdb_id
        kind     = 'movie' if self.content == 'movie' else 'tv'
        imdb_id  = self.meta.get('imdb_id') or ''

        # Cast — uses the rich cast data from the pre-fetched meta object
        self._populate_cast_from_meta()

        # Recommended / Similar (TMDB)
        if tid and key:
            self._populate_poster_list(key, tid, kind, 'recommendations', 2052)
            self._populate_poster_list(key, tid, kind, 'similar',         2053)

        # Reviews (TMDB)
        if tid and key:
            self._populate_reviews(key, tid, kind)

        # Trivia / Blunders (IMDb scrape)
        if imdb_id:
            self._populate_imdb_trivia(imdb_id)
            self._populate_imdb_blunders(imdb_id)

        # Parental guide (TMDB content ratings + IMDb fallback)
        self._populate_parental(key, tid, kind, imdb_id)

    # ──────────────────────────────────────────────────────────────────────
    # Network helpers
    # ──────────────────────────────────────────────────────────────────────

    @staticmethod
    def _safe_log_url(url):
        return re.sub(
            r'(?i)([?&](?:api_key|apikey|token)=)[^&\s]+',
            r'\1[REDACTED]',
            str(url or ''),
        )

    @staticmethod
    def _fetch_json(url, timeout=12):
        try:
            req  = Request(url, headers={'User-Agent': 'COSMOS/4.0.0'})
            resp = urlopen(req, timeout=timeout)
            return json.loads(resp.read().decode('utf-8', errors='replace'))
        except Exception as e:
            xbmc.log(f'COSMOS extras json-fetch error ({CosmosExtrasDialog._safe_log_url(url)}): {e}', xbmc.LOGWARNING)
            return None

    @staticmethod
    def _fetch_html(url, timeout=12):
        try:
            req  = Request(url, headers={
                'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
                'Accept-Language': 'en-US,en;q=0.9',
                'Accept':          'text/html,application/xhtml+xml',
            })
            resp = urlopen(req, timeout=timeout)
            return resp.read().decode('utf-8', errors='replace')
        except Exception as e:
            xbmc.log(f'COSMOS extras html-fetch error ({CosmosExtrasDialog._safe_log_url(url)}): {e}', xbmc.LOGWARNING)
            return ''

    # ──────────────────────────────────────────────────────────────────────
    # List-item factory
    # ──────────────────────────────────────────────────────────────────────

    @staticmethod
    def _li(name='', thumb='', text=''):
        li = xbmcgui.ListItem(label=name)
        li.setProperty('name',      name)
        li.setProperty('thumbnail', thumb)
        li.setProperty('text',      text)
        return li

    @staticmethod
    def _strip_html(raw):
        text = re.sub(r'<[^>]+>', '', raw or '')
        text = re.sub(r'&amp;',  '&',  text)
        text = re.sub(r'&lt;',   '<',  text)
        text = re.sub(r'&gt;',   '>',  text)
        text = re.sub(r'&quot;', '"',  text)
        text = re.sub(r'&#39;',  "'",  text)
        text = re.sub(r'&nbsp;', ' ',  text)
        return re.sub(r'\s+', ' ', text).strip()

    # ──────────────────────────────────────────────────────────────────────
    # Panel populators
    # ──────────────────────────────────────────────────────────────────────

    def _populate_cast_from_meta(self):
        """Populate the cast list from the pre-fetched self.meta object."""
        cast = self.meta.get('cast') or []
        if not cast:
            xbmc.log('COSMOS extras: No cast data in provided meta.', xbmc.LOGINFO)
            return

        ctrl = self.getControl(2051)
        ctrl.reset()
        count = 0
        for person in cast:
            if not isinstance(person, dict):
                continue
            name    = person.get('name') or ''
            role    = person.get('character') or ''
            profile = person.get('profile_path')
            thumb   = f'{_IMG_W185}{profile}' if profile else ''
            display = f'{name}[CR][COLOR FF5599CC]{role}[/COLOR]' if role else name
            ctrl.addItem(self._li(display, thumb, role))
            count += 1
        if count > 0:
            self.setProperty('ce_section_count', f'x{count}')

    def _populate_poster_list(self, key, tid, kind, endpoint, panel_id):
        """Recommended or Similar — horizontal poster reel."""
        data = self._fetch_json(
            f'{_TMDB_BASE}/{kind}/{tid}/{endpoint}?api_key={key}&page=1'
        )
        if not data:
            return
        results = data.get('results') or []
        ctrl = self.getControl(panel_id)
        ctrl.reset()
        for item in results[:15]:
            title  = item.get('title') or item.get('name') or ''
            poster = item.get('poster_path')
            thumb  = f'{_IMG_W185}{poster}' if poster else ''
            year   = (item.get('release_date') or item.get('first_air_date') or '')[:4]
            rating = item.get('vote_average') or 0
            label  = title
            if year:
                label += f'[CR][COLOR FF5599CC]{year}[/COLOR]'
            if rating:
                label += f'[COLOR FF66AAFF]  ★ {float(rating):.1f}[/COLOR]'
            ctrl.addItem(self._li(label, thumb, title))

    def _populate_reviews(self, key, tid, kind):
        data = self._fetch_json(
            f'{_TMDB_BASE}/{kind}/{tid}/reviews?api_key={key}&page=1'
        )
        if not data:
            return
        results = data.get('results') or []
        ctrl = self.getControl(2054)
        ctrl.reset()
        for item in results[:10]:
            author  = item.get('author') or 'Unknown'
            content = item.get('content') or ''
            details = item.get('author_details') or {}
            r_val   = details.get('rating')
            header  = f'[B]{author}[/B]'
            if r_val:
                header += f'  [COLOR FF66AAFF]★ {r_val}[/COLOR]'
            text = f'{header}[CR]{content[:500]}'
            ctrl.addItem(self._li(author, '', text))
        self.setProperty('ce_section_count', f'x{len(results[:10])}')

    def _populate_imdb_trivia(self, imdb_id):
        html  = self._fetch_html(f'https://www.imdb.com/title/{imdb_id}/trivia/')
        items = self._parse_imdb_sodatext(html, limit=12)
        if not items:
            return
        ctrl = self.getControl(2055)
        ctrl.reset()
        for text in items:
            ctrl.addItem(self._li('', '', text))
        self.setProperty('ce_section_count', f'x{len(items)}')

    def _populate_imdb_blunders(self, imdb_id):
        html  = self._fetch_html(
            f'https://www.imdb.com/title/{imdb_id}/goofs/?tab=gf'
        )
        items = self._parse_imdb_sodatext(html, limit=12)
        if not items:
            return
        ctrl = self.getControl(2056)
        ctrl.reset()
        for text in items:
            ctrl.addItem(self._li('', '', text))
        self.setProperty('ce_section_count', f'x{len(items)}')

    def _parse_imdb_sodatext(self, html, limit=12):
        """Extract text blocks from IMDb's .sodatext divs."""
        if not html:
            return []
        raw_items = re.findall(
            r'<div[^>]+class="[^"]*(?:sodatext|ipl-html-content)[^"]*"[^>]*>'
            r'(.*?)</div>',
            html, re.DOTALL | re.IGNORECASE
        )
        results = []
        for raw in raw_items:
            text = self._strip_html(raw)
            if len(text) > 30:
                results.append(text[:600])
            if len(results) >= limit:
                break
        return results

    def _populate_parental(self, key, tid, kind, imdb_id):
        items = []

        # ── TMDB content ratings ──
        if tid and key:
            if kind == 'movie':
                data = self._fetch_json(
                    f'{_TMDB_BASE}/movie/{tid}/release_dates?api_key={key}'
                )
                priority = ('US', 'GB', 'AU', 'CA', 'DE', 'FR', 'NZ', 'IE')
                if data:
                    ratings = {}
                    for res in (data.get('results') or []):
                        country = res.get('iso_3166_1', '')
                        for rd in (res.get('release_dates') or []):
                            cert = (rd.get('certification') or '').strip()
                            if cert and country not in ratings:
                                ratings[country] = cert
                    for c in priority:
                        if c in ratings:
                            items.append(
                                f'[B][COLOR FF66AAFF]{c}:[/COLOR][/B]  {ratings[c]}'
                            )
            else:
                data = self._fetch_json(
                    f'{_TMDB_BASE}/tv/{tid}/content_ratings?api_key={key}'
                )
                priority = ('US', 'GB', 'AU', 'CA', 'DE', 'FR', 'NZ', 'IE')
                if data:
                    ratings = {}
                    for res in (data.get('results') or []):
                        country = res.get('iso_3166_1', '')
                        cert    = (res.get('rating') or '').strip()
                        if cert:
                            ratings[country] = cert
                    for c in priority:
                        if c in ratings:
                            items.append(
                                f'[B][COLOR FF66AAFF]{c}:[/COLOR][/B]  {ratings[c]}'
                            )

        # ── IMDb parental guide scrape (if we have imdb_id) ──
        if imdb_id:
            html = self._fetch_html(
                f'https://www.imdb.com/title/{imdb_id}/parentalguide'
            )
            if html:
                # Try to extract severity lines for each category
                cats = re.findall(
                    r'<section[^>]*id="advisory-([a-z]+)"[^>]*>.*?'
                    r'<span[^>]*class="[^"]*ipl-status-pill[^"]*"[^>]*>'
                    r'(.*?)</span>',
                    html, re.DOTALL | re.IGNORECASE
                )
                for cat, severity in cats[:8]:
                    sev = self._strip_html(severity)
                    if sev:
                        label = cat.replace('-', ' ').title()
                        items.append(f'[B][COLOR FF66AAFF]{label}:[/COLOR][/B]  {sev}')

        if not items:
            items = ['[COLOR FF5599CC]No parental guide data found for this title.[/COLOR]']

        ctrl = self.getControl(2057)
        ctrl.reset()
        for text in items:
            ctrl.addItem(self._li('', '', text))


# ──────────────────────────────────────────────────────────────────────────
# Public entry-point
# ──────────────────────────────────────────────────────────────────────────

def open_extras_dialog(meta, tmdb_id='', content='movie', poster='', fanart=''):
    """Create and modally display the CosmosExtras window.

    Parameters
    ----------
    meta     : dict   Pre-fetched metadata dict (from tmdb.get_metadata or a
                      minimal dict for DDLValley / enigma-XML items without TMDB).
    tmdb_id  : str    TMDB id (may be empty for DDLValley / enigma items).
    content  : str    'movie', 'tvshow', or 'episode'.
    poster   : str    Poster URL override (falls back to meta['poster']).
    fanart   : str    Fanart URL override (falls back to meta['fanart']).
    """
    dlg = CosmosExtrasDialog(
        'CosmosExtras.xml',
        _ADDON_PATH,
        'Default',
        '720p',
        meta=meta,
        tmdb_id=tmdb_id or meta.get('tmdb_id', ''),
        content=content,
        poster=poster  or meta.get('poster',  ''),
        fanart=fanart  or meta.get('fanart',  ''),
    )
    dlg.doModal()
    del dlg
