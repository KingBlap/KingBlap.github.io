# -*- coding: utf-8 -*-
"""Branded release browser for the bundled C.O.S.M.O.S changelog."""
import re

import xbmcgui


def parse_releases(body):
    releases = []
    matches = list(re.finditer(r'^v([^\s]+)\s*\(([^)]+)\)\s*$', body, re.M))
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(body)
        lines = body[match.end():end].strip().splitlines()
        notes = []
        for line in lines:
            line = line.strip()
            if not line or re.fullmatch(r'[=\-]+', line):
                continue
            if line.startswith('- '):
                notes.append(line[2:])
            elif notes:
                notes[-1] += ' ' + line
            else:
                notes.append(line)
        releases.append((match.group(1), match.group(2), notes))
    return releases


def format_notes(notes):
    colors = {'Fix': 'FF74DCCF', 'Feature': 'FF56D4F5', 'UI': 'FFC4ABFF'}
    paragraphs = []
    for note in notes:
        category, separator, description = note.partition(': ')
        if separator and category in colors:
            paragraphs.append('[B][COLOR %s]%s[/COLOR][/B][CR]%s' %
                              (colors[category], category.upper(), description))
        else:
            paragraphs.append(note)
    return '[CR][CR]'.join(paragraphs)


class CosmosChangelogDialog(xbmcgui.WindowXMLDialog):
    def __new__(cls, *args, **kwargs):
        return super().__new__(cls, *args[:4])

    def __init__(self, *args, **kwargs):
        self.version = kwargs.get('version', '')
        self.body = kwargs.get('body', '')
        self.releases = parse_releases(self.body)
        self.selected = -1

    def onInit(self):
        self.setProperty('cl_installed', 'INSTALLED  /  v' + self.version)
        listing = self.getControl(100)
        listing.reset()
        for index, (version, date, notes) in enumerate(self.releases):
            item = xbmcgui.ListItem(label='v' + version, label2=date)
            listing.addItem(item)
        self.setProperty('cl_count', '%s releases' % len(self.releases))
        self._select_release()
        self.setFocusId(100 if self.releases else 9001)

    def _select_release(self):
        index = self.getControl(100).getSelectedPosition() if self.releases else -1
        if index == self.selected and self.releases:
            return
        self.selected = index
        if 0 <= index < len(self.releases):
            version, date, notes = self.releases[index]
            self.setProperty('cl_title', 'What\'s new in v' + version)
            self.setProperty('cl_date', date + '  /  ' + ('LATEST RELEASE' if index == 0 else 'RELEASE ARCHIVE'))
            self.getControl(200).setText(format_notes(notes))
        else:
            self.setProperty('cl_title', 'What\'s new')
            self.getControl(200).setText(self.body)
        self.getControl(200).scroll(0)

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216, 247, 257):
            self.close()
        elif self.getFocusId() == 100:
            self._select_release()

    def onClick(self, control_id):
        if control_id == 9001:
            self.close()
        elif control_id == 100:
            self._select_release()
            self.setFocusId(201)


def open_changelog(addon_path, version, body):
    dialog = CosmosChangelogDialog('CosmosChangelog.xml', addon_path, 'Default',
                                  '720p', version=version, body=body)
    try:
        dialog.doModal()
    finally:
        del dialog
