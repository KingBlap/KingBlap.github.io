"""Dulo's individual player APIs, with no browser/runtime dependency.

Vidfast, Vidcore and Vidlink use EncDec's public protocol adapter. Only the
public embed token/ciphertext is sent there; cookies and playback headers stay
with the provider. Vidy and Videasy's seeded source format is decoded locally.
"""
import base64
import json
import re
import struct
import time
from html import unescape
from http.cookiejar import CookieJar
from urllib.parse import parse_qsl, quote, urlencode, unquote, urljoin, urlsplit
from urllib.request import Request, build_opener, HTTPCookieProcessor

from . import lulustream

CRYPTO = 'https://enc-dec.app/api/'
HOSTS = {'vidy.st': 'vidy', 'vidfast.pro': 'vidfast', 'vidfast.vc': 'vidfast',
         'moviesapi.to': 'moviesapi',
         'player.vidzee.wtf': 'vidzee', 'vidcore.net': 'vidcore',
         'vidcore.io': 'vidcore', 'vidsrc-embed.ru': 'vidsrc',
         'vidsrc.sh': 'vidsrc', 'vidlink.pro': 'vidlink',
         'player.videasy.net': 'videasy', 'player.videasy.to': 'videasy'}


def log(provider, stage, exc):
    # Never log signed URLs, cookies, the crypto input, or media tokens.
    try:
        import xbmc
        xbmc.log('COSMOS Dulo %s: %s (%s%s)' %
                 (provider, stage, type(exc).__name__,
                  ' HTTP %s' % exc.code if hasattr(exc, 'code') else ''), xbmc.LOGWARNING)
    except ImportError:
        pass


def http_url(value):
    if not isinstance(value, str):
        return False
    if re.search(r'[\x00-\x20\x7f]', value):
        return False
    try:
        p = urlsplit(value)
    except ValueError:
        return False
    return p.scheme in ('http', 'https') and bool(p.hostname) and not p.username


class Session:
    def __init__(self, timeout=90):
        self.deadline = time.monotonic() + timeout
        self.jar = CookieJar()
        self.opener = build_opener(HTTPCookieProcessor(self.jar))
        self.meta = None
        self.last_error = None

    def get(self, url, headers=None, payload=None, limit=4 * 1024 * 1024, sample=False):
        if not http_url(url):
            raise ValueError('Invalid provider URL')
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('Dulo resolution timed out')
        request_headers = {'User-Agent': lulustream.UA, 'Cache-Control': 'no-cache'}
        request_headers.update(headers or {})
        data = payload
        if isinstance(payload, dict):
            data = json.dumps(payload).encode('utf-8')
            request_headers['Content-Type'] = 'application/json'
        with self.opener.open(Request(url, data=data, headers=request_headers),
                              timeout=min(12, remaining)) as response:
            raw = response.read(limit if sample else limit + 1)
            final = response.geturl()
        if len(raw) > limit:
            raise ValueError('Provider response exceeds limit')
        return raw, final

    def text(self, *args, **kwargs):
        raw, final = self.get(*args, **kwargs)
        return raw.decode('utf-8-sig', 'replace'), final

    def json(self, *args, **kwargs):
        return json.loads(self.text(*args, **kwargs)[0])

    def crypto(self, operation, text, **extra):
        # Use a separate cookie-free request context for this public adapter.
        service = Session(timeout=max(1, self.deadline - time.monotonic()))
        url = CRYPTO + operation
        if operation.startswith('enc-'):
            data = service.json(url + '?' + urlencode({'text': text}))
        else:
            data = service.json(url, payload=dict(extra, text=text))
        if not isinstance(data, dict) or data.get('status') != 200:
            raise ValueError('Public protocol adapter unavailable')
        result = data.get('result')
        if isinstance(result, str) and result[:1] in ('{', '['):
            result = json.loads(result)
        return result


def headers_for(page):
    p = urlsplit(page)
    return {'User-Agent': lulustream.UA, 'Referer': page,
            'Origin': p.scheme + '://' + p.netloc}


def identity(url):
    path = urlsplit(url).path.rstrip('/')
    match = re.search(r'/(movie|tv)/(\d+)(?:/(\d+)/(\d+))?$', path)
    if not match:
        match = re.fullmatch(r'/(tv)/(\d+)-(\d+)-(\d+)', path)
    if not match or match[1] == 'tv' and not match[3]:
        raise ValueError('Missing exact media identity')
    return match[1], match[2], match[3] or '', match[4] or ''


def source_rows(data, headers):
    if isinstance(data, str):
        data = {'url': data}
    if isinstance(data, dict):
        rows = data.get('sources') or data.get('streams') or [data]
    else:
        rows = data
    if not isinstance(rows, list):
        return
    for row in rows:
        if isinstance(row, str):
            row = {'url': row}
        if not isinstance(row, dict):
            continue
        url = row.get('url') or row.get('file') or row.get('playlist')
        if not http_url(url):
            continue
        merged = dict(headers)
        supplied = row.get('headers') or (data.get('headers') if isinstance(data, dict) else {})
        if isinstance(supplied, dict):
            # Normalize names so provider Referer replaces, rather than duplicates, it.
            for key, value in supplied.items():
                if isinstance(key, str) and isinstance(value, str) and not re.search(r'[\x00\r\n]', key + value):
                    for old in list(merged):
                        if old.casefold() == key.casefold():
                            del merged[old]
                    merged[key] = value
        yield {'url': url, 'headers': merged, 'type': row.get('type', '')}


def _mix(value):
    value &= 0xffffffff
    value ^= value >> 16
    value = value * 2246822507 & 0xffffffff
    value ^= value >> 13
    value = value * 3266489909 & 0xffffffff
    return (value ^ value >> 16) & 0xffffffff


def _rol(value, count):
    value &= 0xffffffff
    count &= 31
    return ((value << count) | (value >> ((32 - count) & 31))) & 0xffffffff


def decode_seeded(encoded, seed, media_id):
    """The player's enc=2 source envelope (32-bit JS arithmetic)."""
    raw = base64.urlsafe_b64decode(encoded.strip() + '=' * (-len(encoded.strip()) % 4))
    hashed = 2166136261
    for char in str(seed):
        hashed = (hashed ^ ord(char)) * 16777619 & 0xffffffff
    state = _mix(_mix(hashed) ^ _mix(int(media_id) ^ 2654435769))
    slots = {}
    for counter in range(8):
        index = state % 61
        state = _rol(state + 2654435769, 7 + (counter & 7))
        slots[index] = state ^ _mix(state)
        state = _mix(state + index)
    acc = _mix(2779096485 ^ state)
    out = bytearray()
    for counter in range((len(raw) + 3) // 4):
        index = acc % 61
        a, b = acc, (slots.get(index, 0) ^ (2654435769 * (counter + 1))) & 0xffffffff
        mixed = (a ^ b) | (a & b if index in slots else 0)
        mixed = _rol(mixed + acc, index) ^ _rol(acc, index * 7)
        acc = _mix(mixed + 2654435769)
        slots[index] = acc
        out.extend(struct.pack('<I', acc))
    plain = bytes(a ^ b for a, b in zip(raw, out))
    if plain[:4] != b'mvm1':
        raise ValueError('Source seed signature mismatch')
    return json.loads(plain[4:].decode('utf-8'))


def _leb(raw, pos, signed=False):
    value, shift = 0, 0
    for _ in range(5):
        byte = raw[pos]
        pos += 1
        value |= (byte & 127) << shift
        shift += 7
        if not byte & 128:
            if signed and byte & 64:
                value -= 1 << shift
            return value, pos
    raise ValueError('Invalid WASM integer')


def _vidsrc_key(wasm):
    """Read the published decoder's key material, without executing WASM."""
    if not wasm.startswith(b'\x00asm\x01\x00\x00\x00'):
        raise ValueError('Invalid decoder module')
    memory, functions = {}, []
    pos = 8
    while pos < len(wasm):
        section = wasm[pos]
        length, start = _leb(wasm, pos + 1)
        end = start + length
        if end > len(wasm):
            raise ValueError('Truncated decoder module')
        if section == 10:
            count, p = _leb(wasm, start)
            for _ in range(count):
                size, p = _leb(wasm, p)
                functions.append(wasm[p:p + size])
                p += size
        elif section == 11:
            count, p = _leb(wasm, start)
            for _ in range(count):
                mode, p = _leb(wasm, p)
                if mode != 0 or wasm[p] != 0x41:
                    raise ValueError('Unsupported decoder data layout')
                address, p = _leb(wasm, p + 1, signed=True)
                if address < 0 or wasm[p] != 0x0b:
                    raise ValueError('Unsupported decoder data offset')
                size, p = _leb(wasm, p + 1)
                if p + size > end or address + size > 1024 * 1024:
                    raise ValueError('Invalid decoder data size')
                for i, byte in enumerate(wasm[p:p + size]):
                    memory[address + i] = byte
                p += size
        pos = end
    # ChaCha's eight key words are loaded as XORs of two data tables.
    pattern = re.compile(rb'\x41([\x80-\xff]{0,4}[\x00-\x7f])\x28\x02\x00\x41([\x80-\xff]{0,4}[\x00-\x7f])\x28\x02\x00\x73')
    for function in functions:
        matches = list(pattern.finditer(function))
        if len(matches) < 8:
            continue
        result = bytearray()
        for match in matches[:8]:
            left = _leb(match[1], 0, signed=True)[0]
            right = _leb(match[2], 0, signed=True)[0]
            result.extend(memory[left + i] ^ memory[right + i] for i in range(4))
        return bytes(result)
    raise ValueError('Vidsrc decoder key layout changed')


def _chacha20(raw, key, nonce):
    constants = list(struct.unpack('<4I', b'expand 32-byte k'))
    words = list(struct.unpack('<8I', key))
    nonce_words = list(struct.unpack('<3I', nonce))
    result = bytearray()
    for counter in range((len(raw) + 63) // 64):
        initial = constants + words + [counter] + nonce_words
        state = initial[:]
        def quarter(a, b, c, d):
            state[a] = (state[a] + state[b]) & 0xffffffff
            state[d] = _rol(state[d] ^ state[a], 16)
            state[c] = (state[c] + state[d]) & 0xffffffff
            state[b] = _rol(state[b] ^ state[c], 12)
            state[a] = (state[a] + state[b]) & 0xffffffff
            state[d] = _rol(state[d] ^ state[a], 8)
            state[c] = (state[c] + state[d]) & 0xffffffff
            state[b] = _rol(state[b] ^ state[c], 7)
        for _ in range(10):
            for indexes in ((0,4,8,12),(1,5,9,13),(2,6,10,14),(3,7,11,15),
                            (0,5,10,15),(1,6,11,12),(2,7,8,13),(3,4,9,14)):
                quarter(*indexes)
        block = struct.pack('<16I', *((a + b) & 0xffffffff for a, b in zip(state, initial)))
        chunk = raw[counter * 64:(counter + 1) * 64]
        result.extend(a ^ b for a, b in zip(chunk, block))
    return bytes(result)


def decode_vidsrc(encoded, wasm):
    raw = base64.b64decode(encoded, validate=True)
    if len(raw) < 12:
        raise ValueError('Truncated Vidsrc envelope')
    plain = _chacha20(raw[12:], _vidsrc_key(wasm), raw[:12]).decode('utf-8')
    if not all(http_url(line) for line in plain.splitlines() if line):
        raise ValueError('Vidsrc source signature mismatch')
    return plain


def metadata(session, ident):
    if session.meta is None:
        from . import tmdb
        session.meta = tmdb.get_metadata(ident[1], 'movie' if ident[0] == 'movie' else 'tvshow') or {}
    meta = session.meta
    title = meta.get('originaltitle') or meta.get('title')
    if not title:
        raise ValueError('Title metadata unavailable')
    params = {'title': quote(title, safe=''), 'mediaType': ident[0],
              'tmdbId': ident[1], 'imdbId': meta.get('imdb_id', ''),
              'year': meta.get('year', '')}
    if ident[0] == 'tv':
        params.update(seasonId=ident[2], episodeId=ident[3])
    return params


def seeded(session, page, ident, videasy=False):
    headers = headers_for(page)
    params = metadata(session, ident)
    bases = ('https://api.videasy.net', 'https://api.speedracelight.com', 'https://api.videasy.to') if videasy else ('https://api.wecollege.net',)
    providers = ('cdn', 'm4uhd', 'vsrc', 'hdmovie', 'myflixerzupcloud') if videasy else (
        'miami', 'boise', 'denver', 'seattle', 'phoenix', 'atlanta',
        'portland', 'austin', 'dallas', 'tampa', 'orlando')
    for base in bases:
        try:
            seed = session.json(base + '/seed?' + urlencode({'mediaId': ident[1]}), headers)['seed']
        except Exception as exc:
            session.last_error = exc
            log('videasy' if videasy else 'vidy', 'source seed', exc)
            # Older Videasy mirrors expose only the unseeded source API.
            if not videasy or getattr(exc, 'code', None) not in (404, 405):
                continue
            seed = None
        for provider in providers:
            try:
                query = dict(params, enc='2', seed=seed) if seed is not None else dict(params)
                endpoint = '/%s/%s' % (provider, 'sources-with-title' if videasy else 'sources')
                text, _ = session.text(base + endpoint + '?' + urlencode(query), headers)
                try:
                    data = json.loads(text)
                except ValueError:
                    try:
                        if seed is None:
                            raise ValueError('Legacy encrypted source response')
                        data = decode_seeded(text, seed, ident[1])
                    except ValueError:
                        if not videasy:
                            raise
                        extra = {'id': ident[1]}
                        if seed is not None:
                            extra['seed'] = seed
                        data = session.crypto('dec-videasy', text, **extra)
                if provider in ('austin', 'hdmovie') and isinstance(data, dict):
                    data['sources'] = [r for r in data.get('sources', []) if r.get('quality') == 'English']
                yield from source_rows(data, headers)
            except Exception as exc:
                session.last_error = exc
                log('videasy' if videasy else 'vidy', provider, exc)
            if time.monotonic() >= session.deadline:
                return


def vidzee(session, page, ident):
    route = '/'.join(x for x in ident if x)
    headers = headers_for(page)
    for provider in ('dcloud', 'doppler', 'tik', 'ipcloud', 'v6:English'):
        try:
            # Omitting e=1 requests the provider's own plain JSON response.
            data = session.json('https://core.vidzee.wtf/streams/' + route + '?' + urlencode({'s': provider}), headers)
            yield from source_rows(data, headers)
        except Exception as exc:
            session.last_error = exc
            log('vidzee', provider, exc)


def catalog(session, page, body, provider):
    match = re.search(r'\\"(?:en|token)\\":\\"([^\\"]+)\\"', body)
    if not match:
        match = re.search(r'"(?:en|token)"\s*:\s*"([^"]+)"', body)
    if not match:
        raise ValueError('Embed token missing')
    parts = session.crypto('enc-' + provider, match[1])
    if not isinstance(parts, dict):
        raise ValueError('Invalid catalog routes')
    root = headers_for(page)['Origin']
    allowed = ('vidcore.io', 'vidcore.net') if provider == 'vidcore' else ('vidfast.vc', 'vidfast.pro')
    for field in ('servers', 'stream'):
        if not http_url(parts.get(field)) or urlsplit(parts[field]).hostname not in allowed:
            raise ValueError('Unexpected catalog origin')
    headers = dict(headers_for(page), Referer=root + '/', **{
        'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': str(parts.get('token', ''))})
    encrypted, _ = session.text(parts['servers'], headers, payload=b'')
    rows = session.crypto('dec-' + provider, encrypted)
    if not isinstance(rows, list):
        raise ValueError('Invalid server list')
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get('data'), str):
            continue
        try:
            encrypted, _ = session.text(parts['stream'].rstrip('/') + '/' + quote(row['data'], safe=''), headers, payload=b'')
            result = session.crypto('dec-' + provider, encrypted)
            # CSRF headers are only for the provider API, never the media CDN.
            yield from source_rows(result, dict(headers_for(page), Referer=root + '/'))
        except Exception as exc:
            log(provider, 'stream unlock', exc)


def _vidlink_proxy(row, mp4=False):
    """Match the player's declared media-proxy mapping, including DASH cookies."""
    row = dict(row)
    url = row.get('url') or row.get('playlist')
    if not row.get('requiresProxy') or not http_url(url):
        return row
    p = urlsplit(url)
    headers = row.get('headers') or row.get('playlistHeaders') or {}
    cookie = next((v for k, v in headers.items() if k.casefold() == 'cookie'), '')
    if row.get('type') == 'dash' and cookie:
        sc = base64.urlsafe_b64encode(cookie.encode()).decode().rstrip('=')
        query = list(parse_qsl(p.query)) + [('host', p.scheme + '://' + p.netloc), ('sc', sc)]
        route = '/sacdn'
    else:
        query = [(k, v) for k, v in parse_qsl(p.query) if
                 (k.lower() in ('auth', 'expires', 'hash', 'key', 'sign', 't', 'token') if mp4 else
                  k.lower() not in ('headers', 'host'))]
        query.extend((('headers', json.dumps(headers, separators=(',', ':'))),
                      ('host', p.scheme + '://' + p.netloc)))
        route = '/mp' if mp4 else '/proxy'
    row['url'] = 'https://noon.mooncase.online' + route + p.path + '?' + urlencode(query)
    row['headers'] = {}
    return row


def vidlink(session, page, ident):
    token = session.crypto('enc-vidlink', ident[1])
    if not isinstance(token, str) or not token:
        raise ValueError('Invalid Vidlink identifier')
    route = ident[0] + '/' + quote(token, safe='')
    if ident[0] == 'tv':
        route += '/' + ident[2] + '/' + ident[3]
    headers = dict(headers_for(page), Referer='https://vidlink.pro/')
    data = session.json('https://vidlink.pro/api/b/' + route + '?multiLang=0', headers)
    # Vidlink returns its playlist inside stream, rather than sources.
    if isinstance(data, dict) and isinstance(data.get('stream'), dict):
        data = data['stream']
    if isinstance(data, dict) and data.get('playlist'):
        primary = {'url': data['playlist'], 'headers': data.get('playlistHeaders', {}),
                   'requiresProxy': data.get('requiresProxy'), 'type': data.get('deliveryType', 'hls')}
        yield from source_rows(_vidlink_proxy(primary), headers)
        if primary.get('requiresProxy'):
            yield from source_rows(primary, headers)
    if isinstance(data, dict) and isinstance(data.get('alternates'), dict):
        for alternate in data['alternates'].values():
            if isinstance(alternate, dict):
                yield from source_rows(_vidlink_proxy(alternate), headers)
                if alternate.get('requiresProxy'):
                    yield from source_rows(alternate, headers)
    if isinstance(data, dict) and isinstance(data.get('qualities'), dict):
        qualities = data['qualities']
        rows, direct = [], []
        for key in sorted(qualities, key=lambda k: int(k) if str(k).isdigit() else 0, reverse=True):
            row = dict(qualities[key])
            direct.append(dict(row))
            rows.append(_vidlink_proxy(row, mp4=True))
        yield from source_rows(rows, headers)
        # Kodi does not enforce browser CORS; some CDNs allow the same URL
        # directly with its supplied headers when the browser proxy is offline.
        yield from source_rows(direct, headers)
        return
    yield from source_rows(data, headers)


def moviesapi(session, page, body, ident):
    from .dulo import _moviesapi_candidates
    for row in _moviesapi_candidates(body, page, session.opener, session.deadline):
        yield from source_rows(row, headers_for(page))


def vidsrc(session, page, body, ident):
    from .dulo import _candidates
    queue, seen = [(page, body)], set()
    while queue and len(seen) < 5:
        page, body = queue.pop(0)
        if page in seen:
            continue
        seen.add(page)
        yield from source_rows(_candidates(body, page), headers_for(page))
        links = re.findall(r'<iframe\b[^>]*\bsrc=["\']([^"\']+)', body, re.I)
        config = re.search(r'window\.(?:CFG|CONFIG)\s*=\s*(\{.*?\});', body, re.S)
        if config:
            config = json.loads(config[1])
            if str(config.get('tmdb') or ident[1]) != ident[1]:
                raise ValueError('Vidsrc returned a different title')
            if ident[0] == 'tv':
                for field, expected in (('season', ident[2]), ('episode', ident[3])):
                    if config.get(field) is not None and str(config[field]) != expected:
                        raise ValueError('Vidsrc returned a different episode')
            if isinstance(config.get('playerUrl'), str):
                links.append(config['playerUrl'])
            api = config.get('api')
            if not api and isinstance(config.get('streamBase'), str) and ident[0] == 'tv':
                api = config['streamBase'] + '&' + urlencode({'season': ident[2], 'episode': ident[3]}) + '&stream_urls'
            if isinstance(api, str):
                data = session.json(api, headers_for(page))
                urls = data.get('data', {}).get('stream_urls', [])
                if isinstance(urls, str):
                    protection = data.get('vs', {})
                    if protection.get('wasm_url'):
                        wasm, _ = session.get(protection['wasm_url'], headers_for(page), limit=1024 * 1024)
                    else:
                        wasm = base64.b64decode(protection['wasm'])
                    urls = decode_vidsrc(urls, wasm).splitlines()
                for target in urls:
                    if not http_url(target):
                        continue
                    # The player obtains an IP-bound token from the chosen CDN.
                    stream_headers = headers_for(page)
                    try:
                        token, _ = session.text(headers_for(target)['Origin'] + '/generate.php', stream_headers, limit=4096)
                        token = token.strip()
                        if token.startswith('{'):
                            value = json.loads(token)
                            token = value.get('token') or value.get('data') or ''
                        if token and len(token) < 2048:
                            target = target.replace('__TOKEN__', quote(token, safe='')) if '__TOKEN__' in target else target + ('&' if '?' in target else '?') + urlencode({'token': token})
                    except Exception:
                        pass
                    yield {'url': target, 'headers': stream_headers, 'refresh_tokens': True}
        for api in re.findall(r'\bdata-api=["\']([^"\']+)', body, re.I):
            try:
                data = session.json(urljoin(page, unescape(api)), headers_for(page))
                if isinstance(data, dict) and isinstance(data.get('src'), str):
                    links.append(data['src'])
            except Exception as exc:
                log('vidsrc', 'frame API', exc)
        for link in links:
            target = urljoin(page, unescape(link))
            if not http_url(target) or target in seen:
                continue
            try:
                child, final = session.text(target, dict(headers_for(page), Referer=page))
                queue.append((final, child))
            except Exception as exc:
                log('vidsrc', 'nested player', exc)


def candidates(session, url):
    ident = identity(url)
    host = re.sub(r'^www\.', '', urlsplit(url).hostname or '')
    provider = HOSTS.get(host)
    if not provider:
        return
    # These APIs do not need an HTML bootstrap (Videasy's .net mirror is down).
    if provider in ('vidzee', 'vidy', 'videasy', 'vidlink'):
        if provider == 'vidzee':
            yield from vidzee(session, url, ident)
        elif provider == 'vidlink':
            yield from vidlink(session, url, ident)
        else:
            yield from seeded(session, url, ident, videasy=provider == 'videasy')
        return
    body, page = session.text(url, {'Referer': 'https://dulo.vg/'})
    if identity(page) != ident:
        raise ValueError('Provider redirected to different title or episode')
    if provider in ('vidcore', 'vidfast'):
        yield from catalog(session, page, body, provider)
    else:
        yield from {'moviesapi': moviesapi, 'vidsrc': vidsrc}[provider](session, page, body, ident)


def mp4_handlers(raw):
    """Read track handler types from an ISO BMFF initialization segment."""
    result = set()
    def boxes(start, end, depth=0):
        if depth > 5:
            return
        while start + 8 <= end:
            size, kind = struct.unpack_from('>I4s', raw, start)
            header = 8
            if size == 1:
                if start + 16 > end:
                    return
                size = struct.unpack_from('>Q', raw, start + 8)[0]
                header = 16
            elif size == 0:
                size = end - start
            if size < header or start + size > end:
                return
            body = start + header
            if kind in (b'moov', b'trak', b'mdia'):
                boxes(body, start + size, depth + 1)
            elif kind == b'hdlr' and body + 12 <= start + size:
                result.add(raw[body + 8:body + 12])
            start += size
    boxes(0, len(raw))
    return result


def validate(session, candidate):
    """Verify a manifest's child playlist, key and first media segment."""
    from . import hdhub
    from .vidcore_proxy import video_bytes
    url, headers = candidate['url'], candidate['headers']
    raw, final = session.get(url, dict(headers, Range='bytes=0-65535'), limit=65536, sample=True)
    if raw.strip() == b'WRONG HASH!':
        raise ValueError('CDN rejected the source signature')
    kind = hdhub.media_type(raw)
    native_hls = False
    if not kind:
        raise ValueError('Player returned non-media content')
    if kind == 'hls':
        playlist, base = session.get(final, headers, limit=2 * 1024 * 1024)
        for _ in range(4):
            text = playlist.decode('utf-8-sig')
            links = [line.strip() for line in text.splitlines() if line.strip() and not line.startswith('#')]
            if not links:
                raise ValueError('Empty HLS playlist')
            if '#EXT-X-STREAM-INF:' in text:
                playlist, base = session.get(urljoin(base, links[0]), headers, limit=2 * 1024 * 1024)
                if not playlist.lstrip().startswith(b'#EXTM3U'):
                    raise ValueError('Invalid HLS variant')
                continue
            encrypted = False
            for line in text.splitlines():
                if line.startswith('#EXT-X-KEY:') and 'METHOD=NONE' not in line:
                    if 'METHOD=AES-128' not in line:
                        raise ValueError('Unsupported encrypted stream')
                    key = re.search(r'URI="([^"]+)"', line)
                    if not key:
                        raise ValueError('Missing HLS key')
                    key_bytes, _ = session.get(urljoin(base, key[1]), headers, limit=1024)
                    if len(key_bytes) != 16:
                        raise ValueError('Invalid HLS key')
                    encrypted = True
            # ISA 21 cannot demux audio embedded alongside video in fMP4.
            # Kodi's native FFmpeg HLS player can read both tracks.
            init = re.search(r'#EXT-X-MAP:[^\n]*URI="([^"]+)"', text)
            if init and not encrypted:
                init_bytes, _ = session.get(urljoin(base, init[1]), headers, limit=2 * 1024 * 1024)
                handlers = mp4_handlers(init_bytes)
                native_hls = b'vide' in handlers and b'soun' in handlers
            # Sample a segment, not just the playlist. Bound its size and range.
            segment, _ = session.get(urljoin(base, links[0]), dict(headers, Range='bytes=0-65535'), limit=65536, sample=True)
            if not segment or segment.lstrip().lower().startswith((b'<!doctype', b'<html', b'<?xml', b'{"error"', b'#extm3u')):
                raise ValueError('Segment is an upstream error')
            if not encrypted:
                segment = video_bytes(segment)
                ts = len(segment) > 376 and all(segment[i * 188] == 0x47 for i in range(3))
                mp4 = len(segment) > 8 and segment[4:8] in (b'ftyp', b'styp', b'moof', b'sidx', b'mdat')
                if not ts and not mp4:
                    raise ValueError('Segment does not contain video')
            break
        else:
            raise ValueError('HLS nesting exceeds limit')
    request = Request(final)
    session.jar.add_cookie_header(request)
    playback = dict(headers)
    if request.get_header('Cookie'):
        playback['Cookie'] = request.get_header('Cookie')
    return {'url': final, 'type': kind, 'headers': playback,
            'refresh_tokens': bool(candidate.get('refresh_tokens')),
            'native_hls': native_hls,
            'opener': session.opener}


def resolve(url, metadata_value=None):
    session = Session()
    session.meta = metadata_value
    provider = HOSTS.get(re.sub(r'^www\.', '', urlsplit(url).hostname or ''), 'unknown')
    failure = ''
    def record(exc):
        code = getattr(exc, 'code', None)
        if code:
            return 'The upstream server returned HTTP %s.' % code
        if isinstance(exc, TimeoutError):
            return 'The upstream server timed out.'
        if isinstance(exc, ValueError):
            return str(exc) + '.'
        return 'The upstream player or its media proxy is unreachable.'
    try:
        for candidate in candidates(session, url):
            try:
                return validate(session, candidate)
            except Exception as exc:
                log(provider, 'media validation', exc)
                failure = record(exc)
            if time.monotonic() >= session.deadline:
                break
    except Exception as exc:
        log(provider, 'player API', exc)
        failure = record(exc)
    if not failure and session.last_error:
        failure = record(session.last_error)
    return {'error': 'Dulo / %s could not load playable media for this movie or episode. %s Please choose another server.' % (provider, failure)}
