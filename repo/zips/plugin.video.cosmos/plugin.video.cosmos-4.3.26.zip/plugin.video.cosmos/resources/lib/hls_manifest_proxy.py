"""Hand an already fetched HLS manifest to Kodi without refetching its director."""
import re
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urljoin, urlencode
from urllib.request import Request, urlopen


def absolutize(body, base):
    lines = []
    for line in body.splitlines():
        if line and not line.startswith('#'):
            line = urljoin(base, line.strip())
        elif 'URI="' in line:
            line = re.sub(r'URI="([^"]+)"', lambda m: 'URI="' + urljoin(base, m[1]) + '"', line)
        lines.append(line)
    return '\n'.join(lines) + '\n'


def prepare(stream):
    url, _, suffix = stream.partition('|')
    from urllib.parse import parse_qsl
    headers = dict(parse_qsl(suffix))
    with urlopen(Request(url, headers=headers), timeout=15) as response:
        body = response.read(2 * 1024 * 1024).decode('utf-8-sig')
        base = response.url
    if not body.startswith('#EXTM3U'):
        raise ValueError('Host did not return an HLS playlist')
    payload = absolutize(body, base).encode('utf-8')
    path = '/' + secrets.token_hex(16) + '.m3u8'
    last_access = [time.monotonic()]

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            if self.path != path:
                self.send_error(404)
                return
            last_access[0] = time.monotonic()
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    server.daemon_threads = True
    # Kodi keeps the resolver interpreter alive for its worker thread.
    def serve():
        import xbmc
        monitor = xbmc.Monitor()
        server.timeout = 1
        try:
            while not monitor.abortRequested() and time.monotonic() - last_access[0] < 900:
                server.handle_request()
        finally:
            server.server_close()
    threading.Thread(target=serve, daemon=True).start()
    return 'http://127.0.0.1:{}{}|{}'.format(server.server_port, path, urlencode(headers))
