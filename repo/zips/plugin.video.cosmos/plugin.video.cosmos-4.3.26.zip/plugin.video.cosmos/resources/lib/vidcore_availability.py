"""Bounded media checks for the Vidcore picker; never start playback."""
import re
import time
import threading
from queue import Queue, Empty
from urllib.parse import urljoin, urlsplit
from urllib.request import Request, urlopen


def check_stream(source):
    """Check a manifest and media sample using the playback headers/cookies."""
    if not isinstance(source, dict) or source.get('error') or not source.get('url'):
        return None
    from .hdhub import media_type
    from .vidcore_proxy import video_bytes
    headers = dict(source.get('headers') or {})
    opener = source.get('opener')
    open_url = opener.open if opener is not None else urlopen

    def read(url, media=False):
        if urlsplit(url).scheme not in ('http', 'https'):
            raise ValueError('Unsupported media URL')
        request_headers = dict(headers, **{'Accept-Encoding': 'identity'})
        if media:
            request_headers['Range'] = 'bytes=0-65535'
        with open_url(Request(url, headers=request_headers), timeout=8) as response:
            if response.status not in (200, 206):
                raise ValueError('Media unavailable')
            return response.read(65536 if media else 1024 * 1024), response.geturl()

    try:
        data, base = read(source['url'], media=True)
        stream_type = media_type(data)
        if not stream_type:
            return None
        if stream_type == 'hls':
            # Fetch complete manifests without Range, then descend to media.
            for depth in range(4):
                data, base = read(base)
                text = data.decode('utf-8-sig')
                if not text.lstrip().startswith('#EXTM3U'):
                    return None
                urls = [line.strip() for line in text.splitlines()
                        if line.strip() and not line.startswith('#')]
                if not urls:
                    return None
                if '#EXT-X-STREAM-INF:' in text:
                    base = urljoin(base, urls[0])
                    continue
                # Check encryption keys and initialization data as well.
                encrypted = False
                for line in text.splitlines():
                    if line.startswith(('#EXT-X-KEY:', '#EXT-X-MAP:')):
                        if line.startswith('#EXT-X-KEY:') and 'METHOD=NONE' not in line:
                            if 'METHOD=AES-128' not in line:
                                return None
                            encrypted = True
                        match = re.search(r'URI="([^"]+)"', line)
                        if encrypted and line.startswith('#EXT-X-KEY:') and not match:
                            return None
                        if match:
                            sample, _ = read(urljoin(base, match[1]), media=True)
                            if not sample or (line.startswith('#EXT-X-KEY:') and len(sample) != 16):
                                return None
                sample, _ = read(urljoin(base, urls[0]), media=True)
                if not sample or sample.lstrip().lower().startswith(
                        (b'<!doctype', b'<html', b'<?xml', b'{"error', b'#extm3u')):
                    return None
                if not encrypted:
                    sample = video_bytes(sample)
                    ts = len(sample) > 376 and all(sample[i * 188] == 0x47 for i in range(3))
                    mp4 = len(sample) > 8 and sample[4:8] in (
                        b'ftyp', b'styp', b'moof', b'sidx', b'mdat', b'emsg')
                    aac = sample.startswith(b'ID3') or (
                        len(sample) > 2 and sample[0] == 255 and sample[1] & 246 == 240)
                    if not (ts or mp4 or aac):
                        return None
                break
            else:
                return None
        # Keep original signed URLs and any provider-specific relay options.
        return dict(source, type=stream_type)
    except Exception:
        return None


def check_sources(jobs, progress, monitor, timeout=30, idle_timeout=8):
    """Return checked links promptly, without joining stalled network workers."""
    work, completed = Queue(), Queue()
    stop = threading.Event()
    results = {}
    total = len(jobs)
    count = 0
    started = last_result = time.monotonic()
    deadline = started + timeout

    for job in jobs:
        work.put(job)

    def worker():
        while not stop.is_set():
            try:
                key, resolve = work.get_nowait()
            except Empty:
                return
            resolved = None
            try:
                source = resolve()
                if not stop.is_set():
                    resolved = check_stream(source)
            except Exception:
                pass
            if not stop.is_set():
                completed.put((key, resolved))

    try:
        # Daemon workers cannot hold up the picker or Python shutdown. They
        # never touch Kodi controls and discard results after this scan ends.
        for index in range(min(6, total)):
            threading.Thread(target=worker, name='cosmos-source-check-%d' % index,
                             daemon=True).start()
        while count < total and time.monotonic() < deadline:
            if monitor.abortRequested():
                return None
            if progress.iscanceled():
                # Keep successes already produced by workers, including any
                # queued since the last UI update. Never wait for more work.
                stop.set()
                while True:
                    try:
                        key, resolved = completed.get_nowait()
                    except Empty:
                        break
                    if resolved:
                        results[key] = resolved
                return results
            if results and time.monotonic() - last_result >= idle_timeout:
                break
            try:
                key, resolved = completed.get(timeout=0.1)
            except Empty:
                pass
            else:
                count += 1
                last_result = time.monotonic()
                if resolved:
                    results[key] = resolved
            if hasattr(progress, 'update_sources'):
                progress.update_sources(count, total, len(results))
            else:
                progress.update(int(100 * count / max(1, total)),
                                'Checked %d of %d sources; %d available' %
                                (count, total, len(results)))
        return results
    finally:
        stop.set()
