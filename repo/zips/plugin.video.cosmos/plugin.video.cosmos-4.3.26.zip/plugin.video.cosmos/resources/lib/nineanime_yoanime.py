# -*- coding: utf-8 -*-
"""Optional YoAnime Direct HLS bridge for the embedded 9Anime picker."""

from __future__ import absolute_import, division, print_function, unicode_literals

import html
import json
import re
import threading
import time
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse
from urllib.request import Request, urlopen


YOANIME_BASE = "https://www.yoanime.me"
YOANIME_UA = "Kodi 9anime YoAnime bridge/1.0"
_MATCH_CACHE = {}
_SOURCE_CACHE = {}
_VIDSTREAM_CACHE = {}
_HEALTH_CACHE = {}
_DURATION_CACHE = {}
_CACHE_LOCK = threading.Lock()
_MATCH_TTL = 30 * 60
_SOURCE_TTL = 2 * 60
_HEALTH_TTL = 2 * 60


def _title_key(value):
    value = html.unescape(html.unescape(value or "")).lower()
    return " ".join(re.findall(r"[a-z0-9]+", value))


def _get(url, timeout=12, extra_headers=None):
    headers = {
        "User-Agent": YOANIME_UA,
        "Accept": "text/html,application/json,*/*",
        "Referer": YOANIME_BASE + "/",
    }
    headers.update(extra_headers or {})
    request = Request(url, headers=headers)
    with urlopen(request, timeout=timeout) as response:
        return response.read().decode("utf-8", "replace")


def _cached(cache, key):
    now = time.time()
    with _CACHE_LOCK:
        entry = cache.get(key)
        if entry and entry["expires"] > now:
            return entry["value"]
        if entry:
            cache.pop(key, None)
    return None


def _store(cache, key, value, ttl):
    with _CACHE_LOCK:
        cache[key] = {"value": value, "expires": time.time() + ttl}


def _match_slug(title):
    wanted = _title_key(title)
    if not wanted:
        return ""
    cached = _cached(_MATCH_CACHE, wanted)
    if cached is not None:
        return cached
    source = _get(YOANIME_BASE + "/search?" + urlencode({"keyword": title}))
    pattern = re.compile(
        r'<a\s+href=["\']/anime/([^"\']+)["\'][^>]*>.*?'
        r'<img\b[^>]*\balt=["\']([^"\']+)["\']',
        re.I | re.S,
    )
    slug = ""
    for candidate_slug, candidate_title in pattern.findall(source):
        if _title_key(candidate_title) == wanted:
            slug = html.unescape(candidate_slug).strip().strip("/")
            break
    _store(_MATCH_CACHE, wanted, slug, _MATCH_TTL)
    return slug


def _direct_servers(slug, number):
    key = (slug, int(number))
    cached = _cached(_SOURCE_CACHE, key)
    if cached is not None:
        return list(cached)
    episode_id = "{0}/ep-{1}".format(slug, int(number))
    url = YOANIME_BASE + "/api/scraper/api/episode/direct-servers?" + urlencode({
        "animeEpisodeId": episode_id,
        "only": "anikuro",
    })
    payload = json.loads(_get(url))
    data = payload.get("data", {}) if isinstance(payload, dict) else {}
    servers = data.get("anikuroServers", []) if isinstance(data, dict) else []
    servers = servers if isinstance(servers, list) else []
    _store(_SOURCE_CACHE, key, list(servers), _SOURCE_TTL)
    return servers


def _first_uri(playlist):
    for line in playlist.splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            return line
    return ""


def _playlist_get(url, headers, timeout, limit=16384):
    request = Request(url, headers=headers)
    with urlopen(request, timeout=timeout) as response:
        return response.read(limit)


def source_is_playable(kodi_url, timeout=5):
    """Lightly verify a YoAnime HLS source before Kodi commits to it.

    YoAnime occasionally advertises a valid master/media playlist whose media
    host has already gone stale.  Reading one byte from the first segment lets
    the caller fall through to the next provider instead of leaving Kodi on a
    spinner.  Results are cached briefly to avoid repeating the probe.
    """
    raw_url, separator, encoded_headers = (kodi_url or "").partition("|")
    cached = _cached(_HEALTH_CACHE, raw_url)
    if cached is not None:
        return bool(cached)
    headers = dict(parse_qsl(encoded_headers)) if separator else {}
    headers.setdefault("User-Agent", YOANIME_UA)
    headers.setdefault("Referer", YOANIME_BASE + "/")
    headers.setdefault("Origin", YOANIME_BASE)
    playable = False
    try:
        master = _playlist_get(raw_url, headers, timeout).decode("utf-8", "replace")
        if not master.startswith("#EXTM3U"):
            raise ValueError("invalid HLS master playlist")
        media_url = raw_url
        media = master
        if "#EXT-X-STREAM-INF" in master:
            child = _first_uri(master)
            if not child:
                raise ValueError("HLS master has no media playlist")
            media_url = urljoin(raw_url, child)
            media = _playlist_get(media_url, headers, timeout).decode("utf-8", "replace")
        segment = _first_uri(media)
        if not media.startswith("#EXTM3U") or not segment:
            raise ValueError("HLS media playlist has no segment")
        segment_headers = dict(headers)
        segment_headers["Range"] = "bytes=0-0"
        request = Request(urljoin(media_url, segment), headers=segment_headers)
        with urlopen(request, timeout=timeout) as response:
            playable = response.read(1) != b""
    except Exception:
        playable = False
    _store(_HEALTH_CACHE, raw_url, playable, _HEALTH_TTL)
    return playable


def source_duration(kodi_url, timeout=6):
    """Return a VOD HLS duration in seconds, or ``None`` when unavailable."""
    raw_url, separator, encoded_headers = (kodi_url or "").partition("|")
    cached = _cached(_DURATION_CACHE, raw_url)
    if cached is not None:
        return cached or None
    headers = dict(parse_qsl(encoded_headers)) if separator else {}
    headers.setdefault("User-Agent", YOANIME_UA)
    headers.setdefault("Referer", YOANIME_BASE + "/")
    headers.setdefault("Origin", YOANIME_BASE)
    duration = 0.0
    try:
        master = _playlist_get(raw_url, headers, timeout, 65536).decode("utf-8", "replace")
        media = master
        if "#EXT-X-STREAM-INF" in master:
            child = _first_uri(master)
            if not child:
                raise ValueError("HLS master has no media playlist")
            media = _playlist_get(urljoin(raw_url, child), headers, timeout, 524288).decode("utf-8", "replace")
        values = re.findall(r"#EXTINF:([0-9.]+)", media)
        duration = sum(float(value) for value in values)
    except Exception:
        duration = 0.0
    _store(_DURATION_CACHE, raw_url, duration, _SOURCE_TTL)
    return duration or None


def sources_match_duration(reference_url, candidate_url, timeout=6):
    """Reject opaque provider mappings whose runtime is clearly another video."""
    reference = source_duration(reference_url, timeout)
    candidate = source_duration(candidate_url, timeout)
    if not reference or not candidate:
        return False
    tolerance = max(90.0, reference * 0.15)
    return abs(reference - candidate) <= tolerance


def find_source(title, number, language):
    """Return one exact-match YoAnime native HLS candidate, or ``None``."""
    language = (language or "sub").strip().lower()
    if language not in ("sub", "dub"):
        return None
    slug = _match_slug(title)
    if not slug:
        return None
    for server in _direct_servers(slug, number):
        if not isinstance(server, dict):
            continue
        if str(server.get("category", "")).strip().lower() != language:
            continue
        stream = html.unescape(str(server.get("url") or "")).strip()
        parsed = urlparse(stream)
        if parsed.scheme != "https" or not parsed.netloc or ".m3u8" not in parsed.path.lower():
            continue
        headers = urlencode({
            "User-Agent": YOANIME_UA,
            "Referer": YOANIME_BASE + "/",
            "Origin": YOANIME_BASE,
        })
        return {
            "name": "YoAnime Direct",
            "type": language,
            "url": stream + "|" + headers,
            "source_kind": "YOANIME",
        }
    return None


def _vidstream_hls(slug, number, language):
    key = (slug, int(number), language)
    cached = _cached(_VIDSTREAM_CACHE, key)
    if cached is not None:
        return cached
    watch_url = YOANIME_BASE + "/watch/{0}/ep-{1}?{2}".format(
        slug,
        int(number),
        urlencode({"server": "Vidstream-2", "category": language.upper()}),
    )
    watch_page = _get(watch_url)
    iframe_match = re.search(
        r'<iframe\b[^>]*\bid=["\']yoanime-player-iframe["\'][^>]*\bsrc=["\']([^"\']+)["\']',
        watch_page,
        re.I,
    )
    if not iframe_match:
        _store(_VIDSTREAM_CACHE, key, "", _SOURCE_TTL)
        return ""
    iframe_url = html.unescape(iframe_match.group(1)).strip()
    parsed_iframe = urlparse(iframe_url)
    path_match = re.fullmatch(r"/stream/s-2/([^/]+)/([^/]+)", parsed_iframe.path.rstrip("/"), re.I)
    if parsed_iframe.scheme != "https" or parsed_iframe.netloc.lower() != "megaplay.buzz" or not path_match:
        _store(_VIDSTREAM_CACHE, key, "", _SOURCE_TTL)
        return ""
    media_id, iframe_language = path_match.groups()
    if iframe_language.lower() != language:
        _store(_VIDSTREAM_CACHE, key, "", _SOURCE_TTL)
        return ""
    api_url = "https://megaplay.buzz/stream/getSourcesNew?" + urlencode({
        "id": media_id,
        "type": language,
    })
    api_headers = {
        "Referer": iframe_url,
        "Origin": "https://megaplay.buzz",
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json,text/plain,*/*",
    }
    payload = json.loads(_get(api_url, extra_headers=api_headers))
    sources = payload.get("sources", {}) if isinstance(payload, dict) else {}
    stream = sources.get("file") if isinstance(sources, dict) else ""
    stream = html.unescape(str(stream or "")).strip()
    parsed_stream = urlparse(stream)
    if parsed_stream.scheme != "https" or not parsed_stream.netloc or ".m3u8" not in parsed_stream.path.lower():
        stream = ""
    _store(_VIDSTREAM_CACHE, key, stream, _SOURCE_TTL)
    return stream


def find_embed_source(title, number, language):
    """Resolve one unambiguous YoAnime Vidstream-2 native HLS candidate."""
    language = (language or "sub").strip().lower()
    if language not in ("sub", "dub"):
        return None
    slug = _match_slug(title)
    if not slug:
        return None
    stream = _vidstream_hls(slug, number, language)
    if not stream:
        return None
    # YoAnime sometimes labels one single-audio file as both SUB and DUB. The
    # provider exposes no language metadata inside that file, so neither label
    # is safe. Suppress both entries and retain other providers instead.
    opposite = "dub" if language == "sub" else "sub"
    opposite_stream = _vidstream_hls(slug, number, opposite)
    if opposite_stream and opposite_stream == stream:
        return None
    headers = urlencode({
        "User-Agent": YOANIME_UA,
        "Referer": "https://megaplay.buzz/",
        "Origin": "https://megaplay.buzz",
    })
    return {
        "name": "YoAnime Vidstream-2",
        "type": language,
        "url": stream + "|" + headers,
        "source_kind": "YOANIME_EMBED",
    }


def find_vidplay_source(title, number, language):
    """Resolve YoAnime's VidPlay-1 iframe to a native VidTube HLS candidate."""
    language = (language or "sub").strip().lower()
    if language not in ("sub", "dub"):
        return None
    slug = _match_slug(title)
    if not slug:
        return None
    watch_url = YOANIME_BASE + "/watch/{0}/ep-{1}?{2}".format(
        slug,
        int(number),
        urlencode({"server": "VidPlay-1", "category": language.upper()}),
    )
    watch_page = _get(watch_url)
    iframe_match = re.search(
        r'<iframe\b[^>]*\bid=["\']yoanime-player-iframe["\'][^>]*\bsrc=["\']([^"\']+)["\']',
        watch_page,
        re.I,
    )
    if not iframe_match:
        return None
    iframe_url = html.unescape(iframe_match.group(1)).strip()
    parsed_iframe = urlparse(iframe_url)
    path_match = re.fullmatch(r"/stream/[^/]+/([^/]+)", parsed_iframe.path.rstrip("/"), re.I)
    if parsed_iframe.scheme != "https" or parsed_iframe.netloc.lower() != "vidtube.site" or not path_match:
        return None
    if path_match.group(1).lower() != language:
        return None
    iframe_page = _get(iframe_url, extra_headers={"Referer": YOANIME_BASE + "/"})
    id_match = re.search(r'\bdata-id=["\']([0-9]+)["\']', iframe_page, re.I)
    real_id_match = re.search(r'\bdata-realid=["\']([^"\']+)["\']', iframe_page, re.I)
    if not id_match or not real_id_match:
        return None
    real_id = html.unescape(real_id_match.group(1)).strip().strip("/")
    expected_series = re.sub(r"-[a-z0-9]{5}$", "", slug, flags=re.I)
    expected_real_id = "{0}/ep-{1}".format(expected_series, int(number))
    if real_id.lower() != expected_real_id.lower():
        return None
    api_url = "https://vidtube.site/stream/getSources?" + urlencode({
        "id": id_match.group(1),
        "type": language,
    })
    api_headers = {
        "Referer": iframe_url,
        "Origin": "https://vidtube.site",
        "X-Requested-With": "XMLHttpRequest",
        "Accept": "application/json,text/plain,*/*",
    }
    payload = json.loads(_get(api_url, extra_headers=api_headers))
    sources = payload.get("sources", {}) if isinstance(payload, dict) else {}
    stream = sources.get("file") if isinstance(sources, dict) else ""
    stream = html.unescape(str(stream or "")).strip()
    parsed_stream = urlparse(stream)
    if parsed_stream.scheme != "https" or not parsed_stream.netloc or ".m3u8" not in parsed_stream.path.lower():
        return None
    headers = urlencode({
        "User-Agent": YOANIME_UA,
        "Referer": "https://vidtube.site/",
        "Origin": "https://vidtube.site",
    })
    return {
        "name": "YoAnime VidPlay-1",
        "type": language,
        "url": stream + "|" + headers,
        "source_kind": "YOANIME_VIDPLAY",
    }
