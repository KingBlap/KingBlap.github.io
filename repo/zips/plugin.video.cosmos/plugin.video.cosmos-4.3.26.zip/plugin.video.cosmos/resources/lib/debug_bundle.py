# -*- coding: utf-8 -*-
"""Debug Session Bundler for C.O.S.M.O.S.

When enabled (Settings → Debug → Enable Debug Bundler), actions and link-play
attempts are recorded across the entire addon:
  • playback resolution steps & final streams
  • API syncs & authentication flows (Trakt, Simkl, OpenSubtitles)
  • Scraper & indexer queries (Easynews, DDLValley, RlsBB, Sports replays)

Sessions and general diagnostics are saved inside the ``cosmos_debug/``
subfolder. Use Settings → Debug → "Download All Bundles as ZIP" to collect
all debug logs, a redacted feature/state snapshot, and kodi.log into a single
timestamped archive.
"""
import os
import re
import json
import threading
import datetime
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'plugin.video.cosmos'

_lock = threading.Lock()
_active = None   # _Session or None

_REDACT_PATTERNS = (
    re.compile(r'(?i)(https?://)[^/@\s:]+:[^/@\s]+@'),
    re.compile(r'(?i)(authorization\s*[:=]\s*(?:bearer|basic)\s+)[^\s,}\]]+'),
    re.compile(r'(?i)([?&](?:api[-_]?key|apikey|access_token|refresh_token|client_secret|password|token)=)[^&\s]+'),
    # Signed CDN/media URLs commonly use these short-lived query fields.
    re.compile(r'(?i)([?&](?:sec|dmts|dmv1st|expires|x-expires|sig|x-signature|hash)=)[^&\s|]+'),
    re.compile(r'(?i)(\b(?:access_token|refresh_token|client_secret|client_id|device_id|username|email|password|apikey|api[-_]?key|token|cookie)\b\s*[:=]\s*["\']?)[^,\s}\]]+'),
)

_SENSITIVE_NAME_RE = re.compile(
    r'(?i)(token|auth|credential|secret|password|apikey|api[-_]?key|'
    r'client[_-]?id|device[_-]?id|username|email|cookie)'
)

_DIAGNOSTIC_STATE_FILES = (
    'watched.json', 'remote_watched.json', 'resume.json',
    'favourites.json', 'search_index.json', 'search_history.json',
    'seen_items.json', 'na_state.json', 'downloads.json',
    'active_downloads.json', 'deadlink_report.json',
    'deadlink_report.txt', 'playlist_health_report.json',
    'playlist_health_report.txt',
)


def _redact_text(value):
    """Remove common credentials before they reach Kodi logs or bundles."""
    text = str(value or '')
    for pattern in _REDACT_PATTERNS:
        text = pattern.sub(r'\1[REDACTED]', text)
    return text


def _redact_data(value, key=''):
    """Recursively redact credential-shaped JSON keys and string values."""
    if isinstance(value, dict):
        return {
            str(k): ('[REDACTED]' if _SENSITIVE_NAME_RE.search(str(k))
                     else _redact_data(v, str(k)))
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [_redact_data(item, key) for item in value]
    if isinstance(value, str):
        return _redact_text(value)
    return value


def _addon_path(addon):
    try:
        path = addon.getAddonInfo('path')
        if path:
            return xbmcvfs.translatePath(path)
    except Exception:
        pass
    try:
        return xbmcvfs.translatePath(
            f'special://home/addons/{ADDON_ID}/')
    except Exception:
        return ''


def _setting_ids(addon):
    """Read setting IDs from the installed settings XML when available."""
    path = os.path.join(_addon_path(addon), 'resources', 'settings.xml')
    try:
        with open(path, 'r', encoding='utf-8') as fp:
            xml = fp.read()
        return sorted(set(re.findall(r'<setting\b[^>]*\bid=["\']([^"\']+)', xml)))
    except (OSError, TypeError):
        return []


def _safe_setting_snapshot(addon):
    settings = {}
    for setting_id in _setting_ids(addon):
        try:
            value = addon.getSetting(setting_id) or ''
        except Exception:
            value = ''
        if _SENSITIVE_NAME_RE.search(setting_id):
            settings[setting_id] = {
                'configured': bool(value),
                'value': '[REDACTED]' if value else '',
            }
        else:
            settings[setting_id] = _redact_text(value)
    return settings


def _safe_state_file(path):
    """Read a small state/report file without exporting credential files."""
    try:
        size = os.path.getsize(path)
        if size > 2 * 1024 * 1024:
            return {'skipped': f'file exceeds 2 MiB ({size} bytes)'}
        with open(path, 'r', encoding='utf-8', errors='replace') as fp:
            raw = fp.read()
    except OSError as e:
        return {'error': str(e)}
    if path.lower().endswith('.json'):
        try:
            return _redact_data(json.loads(raw))
        except (TypeError, ValueError):
            return {'raw': _redact_text(raw), 'parse_error': True}
    return _redact_text(raw)


def _download_diagnostics(addon):
    """Collect interrupted-download metadata without copying media files."""
    result = {'interrupted': [], 'part_files': 0}
    try:
        configured = (addon.getSetting('download_path') or '').strip()
    except Exception:
        configured = ''
    try:
        root = xbmcvfs.translatePath(configured) if configured else xbmcvfs.translatePath(
            f'special://profile/addon_data/{ADDON_ID}/downloads/')
        folders = set([root])
        for setting_id, fallback in (
            ('download_movies_subfolder', 'Movies'),
            ('download_tv_subfolder', 'TV Shows'),
        ):
            try:
                folder = (addon.getSetting(setting_id) or fallback).strip() or fallback
            except Exception:
                folder = fallback
            folders.add(os.path.join(root, folder))
    except Exception:
        return result

    for folder in folders:
        if not os.path.isdir(folder):
            continue
        for dirpath, _dirs, files in os.walk(folder):
            for name in files:
                if not name.endswith('.part'):
                    continue
                result['part_files'] += 1
                part_path = os.path.join(dirpath, name)
                row = {
                    'file': os.path.relpath(part_path, root),
                    'bytes': 0,
                }
                try:
                    row['bytes'] = os.path.getsize(part_path)
                except OSError:
                    pass
                sidecar_path = part_path + '.json'
                if os.path.isfile(sidecar_path):
                    row['sidecar'] = _safe_state_file(sidecar_path)
                result['interrupted'].append(row)
                if len(result['interrupted']) >= 200:
                    result['truncated'] = True
                    return result
    return result


def _build_diagnostics_snapshot():
    """Build a redacted, feature-aware snapshot for every debug ZIP."""
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
    except Exception:
        addon = None

    profile_dir = xbmcvfs.translatePath(
        f'special://profile/addon_data/{ADDON_ID}/')
    snapshot = {
        'generated': datetime.datetime.now().isoformat(timespec='seconds'),
        'addon': {'id': ADDON_ID},
        'settings': {},
        'profile_files': {},
        'profile_inventory': [],
        'modules': [],
        'runtime': {},
        'active_playback_session': bool(_active),
        'downloads': {},
        'feature_state': {},
        'provider_caches': {},
    }
    try:
        lounge_window = xbmcgui.Window(10000)
        snapshot['feature_state']['adult_lounge_unlocked'] = (
            lounge_window.getProperty('plugin.video.cosmos.adult.unlocked') == 'true'
        )
    except Exception:
        snapshot['feature_state']['adult_lounge_unlocked'] = False

    if addon is not None:
        try:
            snapshot['addon']['version'] = addon.getAddonInfo('version')
        except Exception:
            pass
        snapshot['settings'] = _safe_setting_snapshot(addon)
        snapshot['downloads'] = _download_diagnostics(addon)
        # Record feature configuration without exporting credentials or PINs.
        for setting_id in (
            'debug_bundle_enabled', 'auto_clear_cache_enabled',
            'background_feed_refresh', 'offline_metadata_cache',
        ):
            try:
                snapshot['feature_state'][setting_id] = addon.getSetting(setting_id) or ''
            except Exception:
                pass

    # Provider cache presence/size helps diagnose stale Freebie TV, Many.xxx,
    # HQPorn, and Plex results while keeping cache contents out of the bundle.
    cache_roots = {
        'tubi': os.path.join(profile_dir, 'tubi_cache'),
        'pluto': os.path.join(profile_dir, 'pluto_cache'),
        'plex': os.path.join(profile_dir, 'plex_cache'),
        'manyxxx': os.path.join(profile_dir, 'manyxxx_cache'),
        'hqpornxxx': os.path.join(profile_dir, 'hqpornxxx_cache'),
    }
    for provider, path in cache_roots.items():
        count = 0
        total = 0
        try:
            for name in os.listdir(path):
                candidate = os.path.join(path, name)
                if os.path.isfile(candidate):
                    count += 1
                    total += os.path.getsize(candidate)
        except OSError:
            pass
        snapshot['provider_caches'][provider] = {
            'present': os.path.isdir(path), 'files': count, 'bytes': total,
        }

    for label, info_label in (
        ('kodi_version', 'System.BuildVersion'),
        ('os_version', 'System.OperatingSystem'),
        ('platform', 'System.Platform'),
    ):
        try:
            snapshot['runtime'][label] = _redact_text(xbmc.getInfoLabel(info_label))
        except Exception:
            snapshot['runtime'][label] = ''

    for name in _DIAGNOSTIC_STATE_FILES:
        path = os.path.join(profile_dir, name)
        if os.path.isfile(path):
            snapshot['profile_files'][name] = _safe_state_file(path)

    try:
        if os.path.isdir(profile_dir):
            for name in sorted(os.listdir(profile_dir)):
                path = os.path.join(profile_dir, name)
                if os.path.isfile(path):
                    entry = {'name': name, 'size': os.path.getsize(path)}
                    if _SENSITIVE_NAME_RE.search(name):
                        entry['contents'] = 'omitted (credential-like filename)'
                    elif name not in snapshot['profile_files']:
                        entry['contents'] = 'not included'
                    else:
                        entry['contents'] = 'included'
                    snapshot['profile_inventory'].append(entry)
    except OSError:
        pass

    lib_dir = os.path.join(_addon_path(addon), 'resources', 'lib') if addon else ''
    try:
        if os.path.isdir(lib_dir):
            snapshot['modules'] = sorted(
                name[:-3] for name in os.listdir(lib_dir)
                if name.endswith('.py') and name != '__init__.py'
            )
    except OSError:
        pass
    return snapshot


# ── Session object ─────────────────────────────────────────────────────────

class _Session:
    def __init__(self, url, title):
        self.url   = _redact_text(url)
        self.title = _redact_text(title)
        self.ts    = datetime.datetime.now()
        self.rows  = []  # list of (elapsed_s, tag, detail)

    def append(self, tag, detail):
        elapsed = (datetime.datetime.now() - self.ts).total_seconds()
        self.rows.append((elapsed, _redact_text(tag), _redact_text(detail)))

    def render(self, stream_url=None, error=None):
        sep  = '═' * 72
        thin = '─' * 72
        lines = [
            sep,
            '  C.O.S.M.O.S  Debug Bundle',
            sep,
            f'  Date    : {self.ts.strftime("%Y-%m-%d  %H:%M:%S")}',
            f'  Title   : {self.title or "(no title)"}',
            f'  URL     : {self.url}',
            sep, '',
        ]
        for elapsed, tag, detail in self.rows:
            lines.append(f'  [{elapsed:>7.3f}s]  {tag:<22}  {detail}')
        lines.append('')
        if stream_url:
            lines += [thin, '  FINAL STREAM URL', thin,
                      f'  {_redact_text(stream_url)}', thin]
        if error:
            lines += [thin, f'  ERROR  {_redact_text(error)}', thin]
        if not stream_url and not error:
            lines += [thin, '  (session ended — no stream and no error recorded)', thin]
        lines.append('')
        return '\n'.join(lines)


# ── Public API ─────────────────────────────────────────────────────────────

def is_enabled():
    """Return True if the debug bundler setting is switched on."""
    try:
        return xbmcaddon.Addon(ADDON_ID).getSetting('debug_bundle_enabled') == 'true'
    except Exception:
        return False


def begin_session(url, title=''):
    """Start a new recording session.  No-op if bundler is disabled."""
    global _active
    if not is_enabled():
        return
    with _lock:
        _active = _Session(url, title)
    _active.append('SESSION-START', f'title={title!r}  url={url}')


def log(tag, detail):
    """Append one line to the active session and general diagnostic log."""
    safe_tag = _redact_text(tag)
    safe_detail = _redact_text(detail)
    with _lock:
        s = _active
    
    # Always log to Kodi log
    xbmc.log(f'COSMOS-DBG [{safe_tag}] {safe_detail}', xbmc.LOGINFO)

    if not is_enabled():
        return

    # Append to active playback session if running
    if s is not None:
        s.append(safe_tag, safe_detail)

    # Also append to daily general diagnostic log (captures Simkl, Easynews, Scrapers, etc.)
    try:
        out_dir = _bundle_dir()
        date_str = datetime.datetime.now().strftime('%Y%m%d')
        gen_fname = f'cosmos_debug_general_{date_str}.txt'
        gen_fpath = os.path.join(out_dir, gen_fname)
        
        timestamp = datetime.datetime.now().strftime('%H:%M:%S.%f')[:-3]
        log_line = f'[{timestamp}] [{safe_tag:<16}] {safe_detail}\n'
        
        with _lock:
            with open(gen_fpath, 'a', encoding='utf-8') as fp:
                fp.write(log_line)
    except Exception as e:
        xbmc.log(f'COSMOS-DBG: failed to write general log: {e}', xbmc.LOGWARNING)


def end_session(stream_url=None, error=None):
    """Finish the session and write the bundle file.  No-op if none is active."""
    global _active
    with _lock:
        s = _active
        _active = None
    if s is None:
        return
    if stream_url:
        s.append('SESSION-END', f'stream → {_redact_text(stream_url)}')
    elif error:
        s.append('SESSION-END', f'error  → {_redact_text(error)}')
    else:
        s.append('SESSION-END', 'no stream / no error')
    _write_bundle(s, stream_url, error)


# ── Directory helpers ──────────────────────────────────────────────────────

def _base_dir():
    """Return the user-configured base folder (or best OS Downloads folder)."""
    try:
        path = xbmcaddon.Addon(ADDON_ID).getSetting('debug_bundle_path').strip()
        if path:
            path = xbmcvfs.translatePath(path)
            if os.path.isdir(path):
                return path
    except Exception:
        pass

    home = os.path.expanduser('~')
    candidates = [
        os.path.join(home, 'Downloads'),
        os.path.join(home, 'Desktop'),
        '/sdcard/Downloads',
        '/storage/emulated/0/Downloads',
        '/storage/downloads',
        '/storage/Downloads',
        '/tmp',
        home,
    ]
    for c in candidates:
        if os.path.isdir(c):
            try:
                test = os.path.join(c, '.cosmos_dbg_test')
                with open(test, 'w') as f:
                    f.write('')
                os.remove(test)
                return c
            except OSError:
                continue

    profile = xbmcvfs.translatePath(
        f'special://profile/addon_data/{ADDON_ID}/'
    )
    os.makedirs(profile, exist_ok=True)
    return profile


def _bundle_dir():
    """Return (and create) the cosmos_debug/ subfolder used for all log files."""
    d = os.path.join(_base_dir(), 'cosmos_debug')
    os.makedirs(d, exist_ok=True)
    return d


def _kodi_log_path():
    """Return the path to kodi.log, or '' if it cannot be found."""
    try:
        log_dir = xbmcvfs.translatePath('special://logpath/')
        candidate = os.path.join(log_dir, 'kodi.log')
        if os.path.isfile(candidate):
            return candidate
    except Exception:
        pass
    # Platform fallbacks
    home = os.path.expanduser('~')
    fallbacks = [
        os.path.join(home, '.kodi', 'temp', 'kodi.log'),
        os.path.join(home, 'AppData', 'Roaming', 'Kodi', 'kodi.log'),
        os.path.join(home, 'Library', 'Application Support', 'Kodi', 'kodi.log'),
        '/storage/.kodi/temp/kodi.log',
        '/sdcard/Android/data/org.xbmc.kodi/files/.kodi/temp/kodi.log',
        '/var/media/KODI_DATA/temp/kodi.log',
    ]
    for f in fallbacks:
        if os.path.isfile(f):
            return f
    return ''


# ── File writing ───────────────────────────────────────────────────────────

def _write_bundle(session, stream_url, error):
    out_dir = _bundle_dir()
    fname   = session.ts.strftime('cosmos_debug_%Y%m%d_%H%M%S.txt')
    fpath   = os.path.join(out_dir, fname)
    text    = session.render(stream_url=stream_url, error=error)
    try:
        with open(fpath, 'w', encoding='utf-8') as fp:
            fp.write(text)
        xbmc.log(f'COSMOS-DBG: bundle written → {fpath}', xbmc.LOGINFO)
        try:
            addon = xbmcaddon.Addon(ADDON_ID)
            addon.setSetting('debug_bundle_last_path', fpath)
            addon.setSetting('debug_bundle_dir', out_dir)
        except Exception:
            pass
        status = 'OK' if stream_url else 'FAILED'
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S Debug',
            f'[{status}] {fname}',
            xbmcgui.NOTIFICATION_INFO if stream_url else xbmcgui.NOTIFICATION_WARNING,
            4000,
        )
    except OSError as e:
        xbmc.log(f'COSMOS-DBG: failed to write bundle: {e}', xbmc.LOGERROR)


# ── Download all bundles as ZIP ────────────────────────────────────────────

def download_all_bundles():
    """Zip debug logs, a redacted addon snapshot, and kodi.log.

    The zip is saved alongside the cosmos_debug/ subfolder (in the base
    Downloads folder) so it is easy to find and share. The snapshot includes
    current settings metadata, module inventory, safe profile state, watched
    and resume data, download state, and playlist-health reports; credential
    files are represented only by their presence and size.
    """
    bundle_dir = _bundle_dir()
    base_dir   = _base_dir()
    diagnostics = _build_diagnostics_snapshot()

    # Collect all debug text files (playback bundles + general diagnostic logs)
    try:
        txt_files = sorted(
            f for f in os.listdir(bundle_dir)
            if (f.startswith('cosmos_debug_') or f.startswith('cosmos_debug_general_')) and f.endswith('.txt')
        )
    except OSError:
        txt_files = []

    # Build zip filename
    ts      = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    zipname = f'cosmos_debug_all_{ts}.zip'
    zippath = os.path.join(base_dir, zipname)

    kodi_log = _kodi_log_path()

    try:
        with zipfile.ZipFile(zippath, 'w', zipfile.ZIP_DEFLATED) as zf:
            for fname in txt_files:
                fpath = os.path.join(bundle_dir, fname)
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='replace') as fp:
                        zf.writestr(fname, _redact_text(fp.read()))
                except OSError as e:
                    xbmc.log(f'COSMOS-DBG: could not add {fname} to zip: {e}', xbmc.LOGWARNING)

            zf.writestr(
                'cosmos_diagnostics.json',
                json.dumps(diagnostics, ensure_ascii=False, indent=2),
            )

            if kodi_log:
                try:
                    with open(kodi_log, 'r', encoding='utf-8', errors='replace') as fp:
                        zf.writestr('kodi.log', _redact_text(fp.read()))
                except OSError as e:
                    xbmc.log(f'COSMOS-DBG: could not add kodi.log to zip: {e}',
                             xbmc.LOGWARNING)

        xbmc.log(f'COSMOS-DBG: zip written → {zippath}', xbmc.LOGINFO)

        # Show a dialog with the exact save location
        kodi_line = 'kodi.log included.' if kodi_log else 'kodi.log not found (not included).'
        xbmcgui.Dialog().ok(
            'C.O.S.M.O.S Debug — ZIP Ready',
            f'{len(txt_files)} log file{"s" if len(txt_files) != 1 else ""} '
            'plus redacted diagnostics packed.\n'
            f'{kodi_line}\n\n'
            f'[COLOR cyan]{zippath}[/COLOR]',
        )

    except OSError as e:
        xbmc.log(f'COSMOS-DBG: failed to create zip: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            'C.O.S.M.O.S Debug',
            f'Could not create zip:\n{e}',
        )


# ── Viewer / folder opener (called from cosmos.py actions) ────────────────

def show_last_bundle():
    """Display the most recently saved playback bundle or general log in Kodi's text viewer."""
    try:
        path = xbmcaddon.Addon(ADDON_ID).getSetting('debug_bundle_last_path').strip()
    except Exception:
        path = ''
    
    # Fallback to the latest general log if no playback bundle path is stored
    if not path or not os.path.isfile(path):
        bundle_dir = _bundle_dir()
        if os.path.isdir(bundle_dir):
            try:
                logs = sorted(
                    [os.path.join(bundle_dir, f) for f in os.listdir(bundle_dir) if f.startswith('cosmos_debug_general_')],
                    key=os.path.getmtime,
                    reverse=True
                )
                if logs:
                    path = logs[0]
            except Exception:
                pass

    if not path or not os.path.isfile(path):
        xbmcgui.Dialog().ok(
            'C.O.S.M.O.S Debug',
            'No debug bundle found yet.\n\n'
            'Enable the Debug Bundler in Settings → Debug,\n'
            'then try playing links or running sync actions.',
        )
        return
    try:
        with open(path, 'r', encoding='utf-8') as fp:
            body = fp.read()
    except OSError as e:
        xbmcgui.Dialog().ok('C.O.S.M.O.S Debug', f'Could not read bundle:\n{e}')
        return
    xbmcgui.Dialog().textviewer(f'Debug Log — {os.path.basename(path)}', body)


def clear_all_bundles():
    """Delete all cosmos_debug_*.txt and cosmos_debug_general_*.txt files from the bundle folder."""
    bundle_dir = _bundle_dir()
    if not os.path.isdir(bundle_dir):
        xbmcgui.Dialog().notification('C.O.S.M.O.S Debug', 'Debug folder not found.', xbmcgui.NOTIFICATION_INFO)
        return

    try:
        files = [f for f in os.listdir(bundle_dir) if (f.startswith('cosmos_debug_') or f.startswith('cosmos_debug_general_')) and f.endswith('.txt')]
    except OSError:
        files = []

    if not files:
        xbmcgui.Dialog().notification('C.O.S.M.O.S Debug', 'No debug bundles to clear.', xbmcgui.NOTIFICATION_INFO)
        return

    if not xbmcgui.Dialog().yesno('C.O.S.M.O.S Debug', f'Delete {len(files)} debug log file(s)?'):
        return

    removed = 0
    for fname in files:
        try:
            os.remove(os.path.join(bundle_dir, fname))
            removed += 1
        except OSError as e:
            xbmc.log(f'COSMOS-DBG: failed to delete {fname}: {e}', xbmc.LOGWARNING)

    xbmcgui.Dialog().notification(
        'C.O.S.M.O.S Debug', f'Cleared {removed} log file(s).', xbmcgui.NOTIFICATION_INFO
    )


def open_bundle_folder():
    """Show the cosmos_debug/ folder in Kodi's file manager."""
    folder = _bundle_dir()
    xbmc.executebuiltin(f'ActivateWindow(filemanager,{folder})')
