"""
C.O.S.M.O.S — Source Finder / Link Picker
Author: Zeus768

Replaces the plain xbmcgui.Dialog().select() text list previously used by
"Link Zero" with two full-screen custom windows:

  1. SourceFinderDialog — a quality tile grid (4K / 1080p / 720p / SD) with
     a per-tile link count, matching the "LINK FINDER" mock. The user picks
     a quality tier; nothing auto-plays.
  2. LinkPickerDialog — a scrollable list of every link at that quality
     tier, matching the "LINK PICKER" mock, with a persistent "current
     selection" banner and an explicit "Play Selected Link" button.
"""
import os
import xbmc
import xbmcgui
import xbmcvfs

ADDON_ID   = 'plugin.video.cosmos'
ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/')
MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')

# Quality tiers shown on the Source Finder grid, in display order.
# Each tier maps to one or more of scrapers.QUALITY_ORDER's buckets.
TIERS = [
    {'key': '2160p', 'label': '4K',       'icon': 'quality_2160p.png', 'buckets': ('2160p',)},
    {'key': '1080p', 'label': '1080p / FHD', 'icon': 'quality_1080p.png', 'buckets': ('1080p',)},
    {'key': '720p',  'label': '720p / HD',   'icon': 'quality_720p.png',  'buckets': ('720p',)},
    {'key': '480p',  'label': 'SD',       'icon': 'quality_480p.png',  'buckets': ('480p', '360p')},
]

# SourceFinder.xml control ids
_SF_TILE_BUTTONS = {'2160p': 3001, '1080p': 3002, '720p': 3003, '480p': 3004}
_SF_COUNT_LABELS = {'2160p': 3021, '1080p': 3022, '720p': 3023, '480p': 3024}
_SF_TITLE_ID = 9101
_SF_SUBTITLE_ID = 9102
_SF_CANCEL = 9002

# LinkPicker.xml control ids
_LP_LIST = 4001
_LP_PLAY = 4003


def _media(name):
    return os.path.join(MEDIA_PATH, name)


class SourceFinderDialog(xbmcgui.WindowXMLDialog):
    """Quality tile picker. Set ``self.selected_tier`` (a TIERS ``key``) or
    ``None`` if the user backed out."""

    def __init__(self, *args, **kwargs):
        self.title = kwargs.pop('title', '')
        self.poster = kwargs.pop('poster', '')
        self.counts = kwargs.pop('counts', {})  # {tier_key: count}
        self.selected_tier = None
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('sf_poster', self.poster or '')
        self.setProperty('sf_title', self.title or '')
        try:
            self.getControl(_SF_SUBTITLE_ID).setLabel(
                f'FOUND LINKS FOR {self.title}' if self.title else 'FOUND LINKS')
        except Exception as e:
            xbmc.log(f'SourceFinderDialog subtitle error: {e}', xbmc.LOGERROR)

        first_enabled = None
        for tier in TIERS:
            count = self.counts.get(tier['key'], 0)
            label_id = _SF_COUNT_LABELS[tier['key']]
            try:
                self.getControl(label_id).setLabel(f'{count} LINKS' if count else 'No links')
            except Exception as e:
                xbmc.log(f'SourceFinderDialog count error: {e}', xbmc.LOGERROR)
            if count and first_enabled is None:
                first_enabled = tier['key']

        try:
            if first_enabled:
                self.setFocusId(_SF_TILE_BUTTONS[first_enabled])
            else:
                self.setFocusId(_SF_CANCEL)
        except Exception as e:
            xbmc.log(f'SourceFinderDialog focus error: {e}', xbmc.LOGERROR)

    def onClick(self, controlId):
        for tier in TIERS:
            if _SF_TILE_BUTTONS[tier['key']] == controlId:
                if self.counts.get(tier['key'], 0) <= 0:
                    xbmc.log(
                        f'COSMOS [CLICK] SourceFinder  tier={tier["key"]!r}'
                        f'  count=0 — ignoring empty tile',
                        xbmc.LOGDEBUG,
                    )
                    return  # ignore clicks on empty tiles
                xbmc.log(
                    f'COSMOS [CLICK] SourceFinder  tier selected={tier["key"]!r}'
                    f'  count={self.counts.get(tier["key"], 0)}',
                    xbmc.LOGDEBUG,
                )
                self.selected_tier = tier['key']
                self.close()
                return
        if controlId == _SF_CANCEL:
            xbmc.log('COSMOS [CLICK] SourceFinder  user pressed Cancel', xbmc.LOGDEBUG)
            self.selected_tier = None
            self.close()

    def onAction(self, action):
        if action.getId() in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
        ):
            xbmc.log(
                f'COSMOS [CLICK] SourceFinder  back/cancel action={action.getId()}',
                xbmc.LOGDEBUG,
            )
            self.selected_tier = None
            self.close()


class LinkPickerDialog(xbmcgui.WindowXMLDialog):
    """Scrollable link list for a single quality tier.

    ``links`` is a list of dicts: ``{label, meta, icon}``. Set
    ``self.selected_index`` (or ``None`` if canceled) when the user presses
    Play. ``icon`` should be an absolute path to one of the quality tile
    PNGs, matching the tier the caller filtered to.
    """

    def __init__(self, *args, **kwargs):
        self.quality_label = kwargs.pop('quality_label', '')
        self.poster = kwargs.pop('poster', '')
        self.icon_path = kwargs.pop('icon_path', '')
        self.links = kwargs.pop('links', [])
        self.current_index = 0
        self.selected_index = None
        super().__init__(*args, **kwargs)

    def _refresh_selection_banner(self):
        if not self.links:
            return
        item = self.links[self.current_index]
        try:
            self.setProperty('lp_sel_icon', self.icon_path or '')
            self.setProperty('lp_sel_title', item.get('label', ''))
            self.setProperty('lp_sel_meta', item.get('meta', ''))
            self.setProperty('lp_sel_cache', item.get('cache_label', 'UNKNOWN'))
            self.setProperty('lp_sel_format', item.get('format_label', 'AUTO'))
        except Exception as e:
            xbmc.log(f'LinkPickerDialog banner error: {e}', xbmc.LOGERROR)

    def onInit(self):
        try:
            self.setProperty('lp_quality_label', self.quality_label)
            self.setProperty('lp_poster', self.poster or '')
            self.setProperty('lp_count', str(len(self.links)))
        except Exception as e:
            xbmc.log(f'LinkPickerDialog header error: {e}', xbmc.LOGERROR)

        try:
            listctl = self.getControl(_LP_LIST)
            listctl.reset()
            for i, item in enumerate(self.links):
                li = xbmcgui.ListItem(label=item.get('label', ''))
                li.setProperty('meta', item.get('meta', ''))
                li.setProperty('icon', item.get('icon') or self.icon_path or '')
                li.setProperty('cache_label', item.get('cache_label', 'UNKNOWN'))
                li.setProperty('format_label', item.get('format_label', 'AUTO'))
                li.setProperty('selected', 'true' if i == self.current_index else 'false')
                listctl.addItem(li)
            if self.links:
                listctl.selectItem(self.current_index)
        except Exception as e:
            xbmc.log(f'LinkPickerDialog list error: {e}', xbmc.LOGERROR)

        self._refresh_selection_banner()

        # Keep the XML default on the always-focusable Play button. Kodi logs
        # a warning if a dynamic list is focused during window creation.

    def _mark_current(self, new_index):
        try:
            listctl = self.getControl(_LP_LIST)
            for i in range(listctl.size()):
                item = listctl.getListItem(i)
                item.setProperty('selected', 'true' if i == new_index else 'false')
        except Exception as e:
            xbmc.log(f'LinkPickerDialog mark error: {e}', xbmc.LOGERROR)
        self.current_index = new_index
        self._refresh_selection_banner()

    def _sync_highlighted_source(self):
        """Keep the preview and Play target aligned with the list cursor."""
        try:
            pos = self.getControl(_LP_LIST).getSelectedPosition()
        except Exception:
            return
        if 0 <= pos < len(self.links) and pos != self.current_index:
            self._mark_current(pos)

    def onFocus(self, controlId):
        self._sync_highlighted_source()

    def onClick(self, controlId):
        if controlId == _LP_LIST:
            try:
                pos = self.getControl(_LP_LIST).getSelectedPosition()
            except Exception:
                pos = -1
            if 0 <= pos < len(self.links):
                _item = self.links[pos]
                xbmc.log(
                    f'COSMOS [CLICK] LinkPicker  list click  pos={pos}'
                    f'  label={_item.get("label","")[:80]!r}',
                    xbmc.LOGDEBUG,
                )
                # Clicking a link plays it directly - no need to highlight
                # it first and then hit the separate Play button.
                self._mark_current(pos)
                self.selected_index = pos
                self.close()
        elif controlId == _LP_PLAY:
            self._sync_highlighted_source()
            xbmc.log(
                f'COSMOS [CLICK] LinkPicker  Play button  current_index={self.current_index}',
                xbmc.LOGDEBUG,
            )
            if self.links:
                self.selected_index = self.current_index
            self.close()

    def onAction(self, action):
        self._sync_highlighted_source()
        if action.getId() in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
        ):
            xbmc.log(
                f'COSMOS [CLICK] LinkPicker  back/cancel action={action.getId()}',
                xbmc.LOGDEBUG,
            )
            self.selected_index = None
            self.close()


# ── Sport host icon mapping ───────────────────────────────────────────────

# Map URL substrings (lowercase) to icon filenames in resources/media/.
# Evaluated in order; first match wins.
_SPORT_HOST_ICONS = [
    ('watchwrestling',    'icon_watchwrestling.png'),
    ('streameast',        'icon_streameast.png'),
    ('shd247.',            'icon_streamhd247.png'),
    ('streamhd247',       'icon_streamhd247.png'),
    ('ripplestream.',      'icon_ripplestream.png'),
    ('rippleplays.',       'icon_ripplestream.png'),
    ('prostreams.',        'icon_prostreams.png'),
    ('streamsify.',        'icon_streamify.png'),
    ('streamify.',         'icon_streamify.png'),
    ('eagle-streams.',     'icon_eagle_streams.png'),
    ('flyembed.',          'icon_eagle_streams.png'),
    ('mega.nz',           'icon_mega.png'),
    ('mega.co.nz',        'icon_mega.png'),
    ('embedwish.com',     'icon_embedwish.png'),
    ('dailymotion.com',  'icon_dailymotion.png'),
    ('dai.ly',           'icon_dailymotion.png'),
    ('ok.ru',            'icon_okru.png'),
    ('okru.',            'icon_okru.png'),
    ('bysesukior',       'icon_bysesukior.png'), # bysesukior.com is "Fiilemoon"
    ('okru.',            'icon_okru.png'),
    ('bysesukior',       'icon_bysesukior.png'), # bysesukior.com is "Fiilemoon"
    ('filemoon.',        'icon_filemoon.png'),
    ('mixdrop.',         'icon_mixdrop.png'),
    ('vidara.',          'icon_vidara.png'),
    ('fitus.',           'icon_filemoon.png'),
    ('soccerfull.',      'icon_soccerfull.png'),
    ('fullraces.',       'icon_racing.png'),
    ('thematchrecap.xyz','icon_thematchrecap.png'),
    ('footballorgin.',   'icon_soccerfull.png'),
    ('vkvideo',          'icon_vkvideo.png'),
    ('vk.ru',            'icon_vkvideo.png'),
    ('vk.com',           'icon_vkvideo.png'),
    ('youtube.com',      'icon_trailers.png'),
    ('youtu.be',         'icon_trailers.png'),
    ('streamtape.',      'icon_streamtape.png'),
    ('doodstream.',      'icon_doodstream.png'),
    ('dood.',            'icon_doodstream.png'),
]


def sport_host_icon(url, fallback_icon=''):
    """Return the absolute path to the best icon for ``url``.

    Tries each entry in ``_SPORT_HOST_ICONS``; returns ``fallback_icon``
    (already an absolute path) if nothing matches.
    """
    low = (url or '').lower()
    for pattern, fname in _SPORT_HOST_ICONS:
        if pattern in low:
            return _media(fname)
    return fallback_icon


class SportLinkPickerDialog(xbmcgui.WindowXMLDialog):
    """Scrollable stream list for boxing / combat / football replays.

    Uses ``SportLinkPicker.xml`` which shares control IDs with
    ``LinkPicker.xml`` so the same click / key handlers apply.

    ``links`` is a list of dicts: ``{label, meta, icon}`` where ``icon``
    is an absolute file path chosen by ``sport_host_icon()``.
    """

    def __init__(self, *args, **kwargs):
        self.quality_label = kwargs.pop('quality_label', '')
        self.section_icon  = kwargs.pop('section_icon', '')
        self.links = kwargs.pop('links', [])
        self.current_index = 0
        self.selected_index = None
        super().__init__(*args, **kwargs)

    def _refresh_banner(self):
        if not self.links:
            return
        item = self.links[self.current_index]
        try:
            self.setProperty('lp_sel_icon',  item.get('icon') or self.section_icon or '')
            self.setProperty('lp_sel_title', item.get('label', ''))
            self.setProperty('lp_sel_meta',  item.get('meta', ''))
        except Exception as e:
            xbmc.log(f'SportLinkPickerDialog banner error: {e}', xbmc.LOGERROR)

    def onInit(self):
        try:
            self.setProperty('lp_quality_label', self.quality_label)
            self.setProperty('lp_count', str(len(self.links)))
        except Exception as e:
            xbmc.log(f'SportLinkPickerDialog header error: {e}', xbmc.LOGERROR)

        try:
            listctl = self.getControl(_LP_LIST)
            listctl.reset()
            for i, item in enumerate(self.links):
                li = xbmcgui.ListItem(label=item.get('label', ''))
                li.setProperty('meta', item.get('meta', ''))
                li.setProperty('icon', item.get('icon') or self.section_icon or '')
                li.setProperty('selected', 'true' if i == self.current_index else 'false')
                listctl.addItem(li)
            if self.links:
                listctl.selectItem(self.current_index)
        except Exception as e:
            xbmc.log(f'SportLinkPickerDialog list error: {e}', xbmc.LOGERROR)

        self._refresh_banner()

        try:
            self.setFocusId(_LP_LIST if self.links else _LP_PLAY)
        except Exception as e:
            xbmc.log(f'SportLinkPickerDialog focus error: {e}', xbmc.LOGERROR)

    def _mark_current(self, new_index):
        try:
            listctl = self.getControl(_LP_LIST)
            for i in range(listctl.size()):
                listctl.getListItem(i).setProperty(
                    'selected', 'true' if i == new_index else 'false')
        except Exception as e:
            xbmc.log(f'SportLinkPickerDialog mark error: {e}', xbmc.LOGERROR)
        self.current_index = new_index
        self._refresh_banner()

    def onClick(self, controlId):
        if controlId == _LP_LIST:
            try:
                pos = self.getControl(_LP_LIST).getSelectedPosition()
            except Exception:
                pos = -1
            if 0 <= pos < len(self.links):
                _item = self.links[pos]
                xbmc.log(
                    f'COSMOS [CLICK] SportLinkPicker  list click  pos={pos}'
                    f'  label={_item.get("label","")[:80]!r}',
                    xbmc.LOGDEBUG,
                )
                self._mark_current(pos)
                self.selected_index = pos
                self.close()
        elif controlId == _LP_PLAY:
            xbmc.log(
                f'COSMOS [CLICK] SportLinkPicker  Play button  current_index={self.current_index}',
                xbmc.LOGDEBUG,
            )
            if self.links:
                self.selected_index = self.current_index
            self.close()

    def onAction(self, action):
        if action.getId() in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
        ):
            xbmc.log(
                f'COSMOS [CLICK] SportLinkPicker  back/cancel action={action.getId()}',
                xbmc.LOGDEBUG,
            )
            self.selected_index = None
            self.close()


class ReleaseBBLinkPickerDialog(xbmcgui.WindowXMLDialog):
    """Scrollable stream list for RlsBB posts.

    Uses ``ReleaseBBLinkPicker.xml`` which shares control IDs with
    ``SportLinkPicker.xml`` so the same click / key handlers apply.

    ``links`` is a list of dicts: ``{label, meta, icon}`` where ``icon``
    is an absolute file path for the host icon.
    """

    def __init__(self, *args, **kwargs):
        self.quality_label = kwargs.pop('quality_label', '')
        self.section_icon  = kwargs.pop('section_icon', '')
        self.links = kwargs.pop('links', [])
        self.current_index = 0
        self.selected_index = None
        super().__init__(*args, **kwargs)

    def _refresh_banner(self):
        if not self.links:
            return
        item = self.links[self.current_index]
        try:
            self.setProperty('lp_sel_icon',  item.get('icon') or self.section_icon or '')
            self.setProperty('lp_sel_title', item.get('label', ''))
            self.setProperty('lp_sel_meta',  item.get('meta', ''))
        except Exception as e:
            xbmc.log(f'ReleaseBBLinkPickerDialog banner error: {e}', xbmc.LOGERROR)

    def onInit(self):
        try:
            self.setProperty('lp_quality_label', self.quality_label)
            self.setProperty('lp_count', str(len(self.links)))
        except Exception as e:
            xbmc.log(f'ReleaseBBLinkPickerDialog header error: {e}', xbmc.LOGERROR)

        try:
            listctl = self.getControl(_LP_LIST)
            listctl.reset()
            for i, item in enumerate(self.links):
                li = xbmcgui.ListItem(label=item.get('label', ''))
                li.setProperty('meta', item.get('meta', ''))
                li.setProperty('icon', item.get('icon') or self.section_icon or '')
                li.setProperty('selected', 'true' if i == self.current_index else 'false')
                listctl.addItem(li)
            if self.links:
                listctl.selectItem(self.current_index)
        except Exception as e:
            xbmc.log(f'ReleaseBBLinkPickerDialog list error: {e}', xbmc.LOGERROR)

        self._refresh_banner()

        try:
            self.setFocusId(_LP_LIST if self.links else _LP_PLAY)
        except Exception as e:
            xbmc.log(f'ReleaseBBLinkPickerDialog focus error: {e}', xbmc.LOGERROR)

    def _mark_current(self, new_index):
        try:
            listctl = self.getControl(_LP_LIST)
            for i in range(listctl.size()):
                listctl.getListItem(i).setProperty(
                    'selected', 'true' if i == new_index else 'false')
        except Exception as e:
            xbmc.log(f'ReleaseBBLinkPickerDialog mark error: {e}', xbmc.LOGERROR)
        self.current_index = new_index
        self._refresh_banner()

    def onClick(self, controlId):
        if controlId == _LP_LIST:
            try:
                pos = self.getControl(_LP_LIST).getSelectedPosition()
            except Exception:
                pos = -1
            if 0 <= pos < len(self.links):
                self._mark_current(pos)
                self.selected_index = pos
                self.close()
        elif controlId == _LP_PLAY:
            if self.links:
                self.selected_index = self.current_index
            self.close()

    def onAction(self, action):
        if action.getId() in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
        ):
            self.selected_index = None
            self.close()


class DDLValleyLinkPickerDialog(xbmcgui.WindowXMLDialog):
    """Scrollable stream list for DDLValley posts.

    Uses ``DDLValleyLinkPicker.xml`` which shares control IDs with
    ``SportLinkPicker.xml`` so the same click / key handlers apply.

    ``links`` is a list of dicts: ``{label, meta, icon}`` where ``icon``
    is an absolute file path for the host icon.
    """

    def __init__(self, *args, **kwargs):
        self.quality_label = kwargs.pop('quality_label', '')
        self.section_icon  = kwargs.pop('section_icon', '')
        self.links = kwargs.pop('links', [])
        self.current_index = 0
        self.selected_index = None
        super().__init__(*args, **kwargs)

    def _refresh_banner(self):
        if not self.links:
            return
        item = self.links[self.current_index]
        try:
            self.setProperty('lp_sel_icon',  item.get('icon') or self.section_icon or '')
            self.setProperty('lp_sel_title', item.get('label', ''))
            self.setProperty('lp_sel_meta',  item.get('meta', ''))
        except Exception as e:
            xbmc.log(f'DDLValleyLinkPickerDialog banner error: {e}', xbmc.LOGERROR)

    def onInit(self):
        try:
            self.setProperty('lp_quality_label', self.quality_label)
            self.setProperty('lp_count', str(len(self.links)))
        except Exception as e:
            xbmc.log(f'DDLValleyLinkPickerDialog header error: {e}', xbmc.LOGERROR)

        try:
            listctl = self.getControl(_LP_LIST)
            listctl.reset()
            for i, item in enumerate(self.links):
                li = xbmcgui.ListItem(label=item.get('label', ''))
                li.setProperty('meta', item.get('meta', ''))
                li.setProperty('icon', item.get('icon') or self.section_icon or '')
                li.setProperty('selected', 'true' if i == self.current_index else 'false')
                listctl.addItem(li)
            if self.links:
                listctl.selectItem(self.current_index)
        except Exception as e:
            xbmc.log(f'DDLValleyLinkPickerDialog list error: {e}', xbmc.LOGERROR)

        self._refresh_banner()

        try:
            self.setFocusId(_LP_LIST if self.links else _LP_PLAY)
        except Exception as e:
            xbmc.log(f'DDLValleyLinkPickerDialog focus error: {e}', xbmc.LOGERROR)

    def _mark_current(self, new_index):
        try:
            listctl = self.getControl(_LP_LIST)
            for i in range(listctl.size()):
                listctl.getListItem(i).setProperty(
                    'selected', 'true' if i == new_index else 'false')
        except Exception as e:
            xbmc.log(f'DDLValleyLinkPickerDialog mark error: {e}', xbmc.LOGERROR)
        self.current_index = new_index
        self._refresh_banner()

    def onClick(self, controlId):
        if controlId == _LP_LIST:
            try:
                pos = self.getControl(_LP_LIST).getSelectedPosition()
            except Exception:
                pos = -1
            if 0 <= pos < len(self.links):
                self._mark_current(pos)
                self.selected_index = pos
                self.close()
        elif controlId == _LP_PLAY:
            if self.links:
                self.selected_index = self.current_index
            self.close()

    def onAction(self, action):
        if action.getId() in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
        ):
            self.selected_index = None
            self.close()


def show_rlsbb_link_picker(links, title='', section_icon=''):
    """Show the ReleaseBB Source Picker dialog.

    ``links`` is a list of ``{label, url, icon}`` dicts.
    Returns the chosen dict, or ``None`` if the user cancelled.
    """
    if not links:
        return None

    dlg_links = [
        {'label': lk.get('label', ''), 'meta': lk.get('url', ''),
         'icon': lk.get('icon') or section_icon, '_link': lk}
        for lk in links
    ]

    dlg = ReleaseBBLinkPickerDialog(
        'ReleaseBBLinkPicker.xml', ADDON_PATH, 'Default', '720p',
        quality_label=title,
        section_icon=section_icon,
        links=dlg_links,
    )
    dlg.doModal()
    idx = dlg.selected_index
    del dlg

    if idx is None:
        return None
    return dlg_links[idx]['_link']


def show_scenesource_link_picker(links, title='', section_icon=''):
    """Show the SceneSource Source Picker dialog.

    ``links`` is a list of ``{label, url, icon}`` dicts.
    Returns the chosen dict, or ``None`` if the user cancelled.
    """
    if not links:
        return None

    dlg_links = [
        {'label': lk.get('label', ''), 'meta': lk.get('url', ''),
         'icon': lk.get('icon') or section_icon, '_link': lk}
        for lk in links
    ]

    dlg = ReleaseBBLinkPickerDialog(
        'SceneSourceLinkPicker.xml', ADDON_PATH, 'Default', '720p',
        quality_label=title,
        section_icon=section_icon,
        links=dlg_links,
    )
    dlg.doModal()
    idx = dlg.selected_index
    del dlg

    if idx is None:
        return None
    return dlg_links[idx]['_link']


def show_ddlvalley_link_picker(links, title='', section_icon=''):
    """Show the DDLValley Source Picker dialog.

    ``links`` is a list of ``{label, url, icon}`` dicts.
    Returns the chosen dict, or ``None`` if the user cancelled.
    """
    if not links:
        return None

    dlg_links = [
        {'label': lk.get('label', ''), 'meta': lk.get('url', ''),
         'icon': lk.get('icon') or section_icon, '_link': lk}
        for lk in links
    ]

    dlg = DDLValleyLinkPickerDialog(
        'DDLValleyLinkPicker.xml', ADDON_PATH, 'Default', '720p',
        quality_label=title,
        section_icon=section_icon,
        links=dlg_links,
    )
    dlg.doModal()
    idx = dlg.selected_index
    del dlg

    if idx is None:
        return None
    return dlg_links[idx]['_link']


def show_rmz_link_picker(links, title='', section_icon=''):
    """Show the RapidMovieZ Source Picker dialog.

    ``links`` is a list of ``{label, url, icon}`` dicts.
    Returns the chosen dict, or ``None`` if the user cancelled.
    """
    if not links:
        return None

    dlg_links = [
        {'label': lk.get('label', ''), 'meta': lk.get('url', ''),
         'icon': lk.get('icon') or section_icon, '_link': lk}
        for lk in links
    ]

    dlg = ReleaseBBLinkPickerDialog(
        'RapidMoviezLinkPicker.xml', ADDON_PATH, 'Default', '720p',
        quality_label=title,
        section_icon=section_icon,
        links=dlg_links,
    )
    dlg.doModal()
    idx = dlg.selected_index
    del dlg

    if idx is None:
        return None
    return dlg_links[idx]['_link']


def show_sport_link_picker(servers, title='', section_icon=''):
    """Show the sports Source Picker dialog for ``servers``.

    ``servers`` is a list of ``{label, url}`` dicts (from boxing / combat /
    football scrapers).  Returns the chosen ``{label, url}`` dict, or
    ``None`` if the user cancelled.

    Each row shows the host-specific icon so the user knows at a glance
    which streaming service the link comes from.
    """
    if not servers:
        return None

    links = []
    for s in servers:
        url = s.get('url') or ''
        label = s.get('label') or 'Stream'
        icon = sport_host_icon(url, fallback_icon=section_icon)
        links.append({'label': label, 'meta': url, 'icon': icon, '_server': s})

    dlg = SportLinkPickerDialog(
        'SportLinkPicker.xml', ADDON_PATH, 'Default', '720p',
        quality_label=title,
        section_icon=section_icon,
        links=links,
    )
    dlg.doModal()
    idx = dlg.selected_index
    del dlg

    if idx is None:
        return None
    return links[idx]['_server']


def pick_link(title, results, quality_order, bucket_of, poster=''):
    """Run the Source Finder → Link Picker flow over ``results``.

    ``results`` is a list of arbitrary dicts (already sorted by caller
    preference within each tier). ``bucket_of(result)`` must return one of
    the TIERS ``buckets`` values for a given result. Returns the chosen
    result dict, or ``None`` if the user backed out at any point.
    """
    tiered = {tier['key']: [] for tier in TIERS}
    for r in results:
        bucket = bucket_of(r)
        for tier in TIERS:
            if bucket in tier['buckets']:
                tiered[tier['key']].append(r)
                break

    counts = {k: len(v) for k, v in tiered.items()}
    xbmc.log(
        f'COSMOS [FLOW] pick_link  title={title!r}  tier_counts={counts}',
        xbmc.LOGDEBUG,
    )
    if not any(counts.values()):
        xbmc.log('COSMOS [FLOW] pick_link  no results in any tier — aborting', xbmc.LOGWARNING)
        return None

    sf = SourceFinderDialog(
        'SourceFinder.xml', ADDON_PATH, 'Default', '720p',
        title=title, counts=counts, poster=poster,
    )
    sf.doModal()
    tier_key = sf.selected_tier
    del sf
    if not tier_key:
        xbmc.log('COSMOS [FLOW] pick_link  SourceFinder cancelled', xbmc.LOGDEBUG)
        return None

    xbmc.log(
        f'COSMOS [FLOW] pick_link  SourceFinder selected tier={tier_key!r}'
        f'  links_in_tier={counts.get(tier_key, 0)}',
        xbmc.LOGDEBUG,
    )

    tier_meta = next(t for t in TIERS if t['key'] == tier_key)
    bucket_results = tiered[tier_key]
    icon_path = _media(tier_meta['icon'])

    links = [{
        'label': r.get('display_title') or r.get('title') or 'Untitled',
        'meta': '  ·  '.join(part.strip() for part in (r.get('display_meta') or '').split('·')
                              if part.strip().lower() not in ('cached', 'uncached')),
        'icon': icon_path,
        'cache_label': 'CACHED' if r.get('cached') else 'UNCACHED',
        '_result': r,
    } for r in bucket_results]

    lp = LinkPickerDialog(
        'LinkPicker.xml', ADDON_PATH, 'Default', '720p',
        quality_label=tier_meta['label'], icon_path=icon_path, links=links,
        poster=poster,
    )
    lp.doModal()
    idx = lp.selected_index
    del lp
    if idx is None:
        xbmc.log('COSMOS [FLOW] pick_link  LinkPicker cancelled', xbmc.LOGDEBUG)
        return None
    _chosen = links[idx]['_result']
    xbmc.log(
        f'COSMOS [FLOW] pick_link  user chose index={idx}'
        f'  title={_chosen.get("title","")[:80]!r}'
        f'  quality={_chosen.get("quality")!r}'
        f'  source={_chosen.get("source")!r}'
        f'  cached={_chosen.get("cached")}',
        xbmc.LOGDEBUG,
    )
    return _chosen
