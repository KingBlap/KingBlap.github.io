# -*- coding: utf-8 -*-
"""Cosmos-themed debrid account status dialog."""

import xbmc
import xbmcgui
import xbmcvfs

from . import debrid


ADDON_ID = 'plugin.video.cosmos'
ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/')
_LIST_ID = 4001
_REFRESH_ID = 4003
_CLOSE_ID = 4004


def _status_color(account):
    status = str(account.get('status') or '').lower()
    days = account.get('days_left')
    if status == 'active' and isinstance(days, int) and days > 0:
        return 'lime'
    if status in ('expired', 'check failed'):
        return 'red'
    if status == 'disabled':
        return 'grey'
    return 'yellow'


def _days_text(account):
    days = account.get('days_left')
    if not isinstance(days, int):
        return 'Days remaining: Unknown'
    if days <= 0:
        return 'Expired'
    return f'{days} day{("s" if days != 1 else "")} remaining'


class DebridAccountStatusDialog(xbmcgui.WindowXMLDialog):
    """Display isolated provider status results in a themed list."""

    def __init__(self, *args, **kwargs):
        self.accounts = kwargs.pop('accounts', []) or []
        super().__init__(*args, **kwargs)

    def onInit(self):  # noqa: N802
        self._populate()
        try:
            self.setFocusId(_LIST_ID if self.accounts else _REFRESH_ID)
        except Exception:
            pass

    def _populate(self):
        try:
            control = self.getControl(_LIST_ID)
            control.reset()
            active = 0
            for account in self.accounts:
                status = str(account.get('status') or 'Unknown')
                if status == 'Active':
                    active += 1
                name = str(account.get('name') or 'Debrid provider')
                expiration = str(account.get('expiration') or '').strip()
                expiry_text = f'Expires {expiration}' if expiration and expiration.lower() not in ('unknown', 'none') else 'Expiry date unavailable'
                item = xbmcgui.ListItem(label=name)
                item.setArt({'icon': 'DefaultNetwork.png', 'thumb': 'DefaultNetwork.png'})
                item.setProperty('status_line', f'[COLOR {_status_color(account)}][B]{status}[/B][/COLOR]')
                item.setProperty('days_line', _days_text(account))
                item.setProperty('expiry_line', expiry_text)
                error = str(account.get('error') or '').strip()
                if error:
                    item.setProperty('expiry_line', f'{expiry_text} · {error[:90]}')
                control.addItem(item)
            self.setProperty(
                'status_summary',
                f'{active} active · {len(self.accounts)} providers checked',
            )
        except Exception as exc:
            xbmc.log(f'COSMOS debrid status UI populate failed: {exc}', xbmc.LOGWARNING)

    def _refresh(self):
        try:
            self.accounts = debrid.get_debrid_account_info()
            self._populate()
            xbmcgui.Dialog().notification(
                'Debrid Accounts', 'Account status refreshed',
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
        except Exception as exc:
            xbmc.log(f'COSMOS debrid status refresh failed: {exc}', xbmc.LOGWARNING)
            xbmcgui.Dialog().notification(
                'Debrid Accounts', 'Refresh failed',
                xbmcgui.NOTIFICATION_ERROR, 3000,
            )

    def onClick(self, control_id):  # noqa: N802
        if control_id == _REFRESH_ID:
            self._refresh()
        elif control_id == _CLOSE_ID:
            self.close()

    def onAction(self, action):  # noqa: N802
        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PARENT_DIR):
            self.close()


def show():
    """Open the account-status dialog with a fresh provider snapshot."""
    accounts = debrid.get_debrid_account_info()
    dialog = DebridAccountStatusDialog(
        'DebridAccountStatus.xml', ADDON_PATH, 'Default', '720p',
        accounts=accounts,
    )
    dialog.doModal()
    del dialog
