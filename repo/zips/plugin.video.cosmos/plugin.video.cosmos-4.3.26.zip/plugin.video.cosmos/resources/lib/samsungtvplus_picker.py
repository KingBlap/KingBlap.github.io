"""Samsung TV Plus channels and programme guide in the Cosmos live picker."""
from datetime import datetime, timezone

from .rakuten_picker import RakutenLivePickerDialog, channel_link as base_channel_link
from .source_finder_dialog import ADDON_PATH


def normalize(key, channel, icon):
    # Samsung provides start timestamps only. The following event supplies
    # the end time; the final row has no known end and is omitted.
    events = []
    for row in channel.get('programs') or []:
        try:
            start = datetime.fromtimestamp(float(row[0]), timezone.utc)
            title = str(row[1])
            events.append((start, title))
        except (IndexError, KeyError, ValueError, TypeError, OverflowError, OSError):
            continue
    events.sort(key=lambda event: event[0])
    programmes = []
    for index, (start, title) in enumerate(events):
        end = events[index + 1][0] if index + 1 < len(events) else start
        if end > start:
            programmes.append({'title': title, 'starts_at': start.isoformat(),
                               'ends_at': end.isoformat()})
    return {'id': key, 'title': channel.get('name') or key,
            'channel_number': channel.get('chno'),
            'images': {'artwork': channel.get('logo') or icon},
            'live_programs': programmes, 'source': channel}


def channel_link(channel, icon):
    link = base_channel_link(channel, icon)
    source = channel['source']
    number = channel.get('channel_number')
    if number is not None:
        link['label'] = '%s  |  %s' % (number, link['label'])
    group = source.get('group') or ''
    link['info']['genre'] = [group] if group else []
    details = '\n\n'.join(value for value in (group, source.get('description')) if value)
    if details:
        link['info']['plot'] += '\n\n' + details
        link['preview_meta'] += '\n\n' + details
    return link


class SamsungLivePickerDialog(RakutenLivePickerDialog):
    provider_title = 'Samsung TV Plus'

    def make_link(self, channel):
        return channel_link(channel, self.channel_icon)


def show(channels, region, icon, refresh_channels):
    if not channels:
        return None
    dialog = SamsungLivePickerDialog(
        'SamsungLivePicker.xml', ADDON_PATH, 'Default', '720p',
        channels=channels, market=region, icon_path=icon,
        refresh_channels=refresh_channels)
    try:
        dialog.doModal()
        index = dialog.selected_index
        return dialog.links[index]['channel'] if index is not None and 0 <= index < len(dialog.links) else None
    finally:
        del dialog
