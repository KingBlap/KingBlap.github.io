"""Match 9anime titles/episodes on Aniwatch and resolve Yuki to native HLS."""
import base64
import hashlib
import hmac
import html
import json
import re
import time
import threading
import unicodedata
from urllib.parse import urlencode, urlparse, urljoin
from urllib.request import Request, urlopen

from .aescbc import decrypt

BASE = 'https://aniwatch.cx'
PLAYER = 'https://megaplay.buzz'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': PLAYER + '/'}
_CACHE = {}
_LOCK = threading.Lock()


def _cached(key, factory, ttl):
    with _LOCK:
        entry = _CACHE.get(key)
        if entry and entry[0] > time.time():
            return entry[1]
    value = factory()
    with _LOCK:
        if len(_CACHE) >= 128:
            del _CACHE[min(_CACHE, key=lambda item: _CACHE[item][0])]
        _CACHE[key] = (time.time() + ttl, value)
    return value


def _get(url, referer, extra_headers=None):
    headers = {'User-Agent': HEADERS['User-Agent'], 'Referer': referer}
    headers.update(extra_headers or {})
    with urlopen(Request(url, headers=headers), timeout=15) as response:
        return response.read(2 * 1024 * 1024).decode('utf-8-sig')


def _key(title):
    value = unicodedata.normalize('NFKD', html.unescape(title or '')).lower()
    value = ''.join(char for char in value if not unicodedata.combining(char))
    return ' '.join(re.findall(r'[^\W_]+', value))


def _attrs(tag):
    return {name.lower(): html.unescape(value) for name, _, value in
            re.findall(r'([\w-]+)\s*=\s*(["\'])(.*?)\2', tag, re.S)}


def _site_url(href):
    url = urljoin(BASE + '/', href)
    return url if urlparse(url).hostname == 'aniwatch.cx' else ''


def _match_title(source, title, year=None):
    matches = set()
    wanted = _key(title)
    if not wanted:
        return ''
    cards = re.split(r'<div\b[^>]*class=["\'][^"\']*\bawt-flw-item\b[^"\']*["\'][^>]*>', source, flags=re.I)
    for card in cards[1:]:
        for tag in re.findall(r'<a\b[^>]*>', card, re.I):
            attrs = _attrs(tag)
            if wanted not in {_key(attrs.get('data-ename')), _key(attrs.get('data-jname'))}:
                continue
            card_year = re.search(r'class=["\']awt-fdi-item["\'][^>]*>\s*(\d{4})\s*<', card)
            if year and card_year and int(card_year[1]) != int(year):
                continue
            url = _site_url(attrs.get('href', ''))
            if url and re.match(r'^/(anime|movie|special|specials|ova|ona|tv|music)/[^/]+/?$',
                                urlparse(url).path, re.I):
                matches.add(url)
    # A same-name remake or ambiguous season should never play a different title.
    return next(iter(matches)) if len(matches) == 1 else ''


def _watch_page(detail_url, number=1):
    page = _cached(('page', detail_url), lambda: _get(detail_url, BASE + '/'), 60)
    if re.search(r"currentHianimeEpId\s*=\s*['\"][^'\"]+['\"]", page):
        return page
    for tag in re.findall(r'<a\b[^>]*>', page, re.I):
        attrs = _attrs(tag)
        if 'awt-btn-play' in attrs.get('class', '').split():
            watch_url = _site_url(attrs.get('href', ''))
            if watch_url:
                # Follow this title's observed episode route, rather than
                # depending on episode 1 embedding every later episode token.
                parsed = urlparse(watch_url)
                route = re.fullmatch(r'(/episode/.+)-(\d+)-([a-zA-Z0-9]+)', parsed.path)
                if route:
                    watch_url = BASE + route[1] + '-' + str(int(number)) + '-' + route[3]
                return _cached(('page', watch_url), lambda: _get(watch_url, detail_url), 60)
    return ''


def _episode_sources(page, number):
    token = ''
    languages = set()
    for tag in re.findall(r'<a\b[^>]*>', page, re.I):
        attrs = _attrs(tag)
        if attrs.get('data-episode') == str(int(number)):
            token = attrs.get('data-stream-token', '')
            languages = {language for language in ('sub', 'dub')
                         if attrs.get('data-has-' + language) == '1'}
            break
    if not token:
        current = re.search(r'\bcurrentEp\s*=\s*(\d+)', page)
        current_token = re.search(r"currentHianimeEpId\s*=\s*['\"]([^'\"]+)['\"]", page)
        # Single-item movies/OVAs/specials can expose a player token and
        # language buttons without an episode list or currentEp variable.
        # Only use that token for item 1; never reuse it for a later episode.
        episode_numbers = re.findall(r'data-episode\s*=\s*[\"\'](\d+)[\"\']', page)
        single_item = (int(number) == 1 and not current and
                       not episode_numbers)
        if not current_token or not (single_item or
                                      (current and int(current[1]) == int(number))):
            return []
        token = current_token[1]
        for tag in re.findall(r'<button\b[^>]*>', page, re.I):
            attrs = _attrs(tag)
            if attrs.get('data-server') == 'backup':
                languages.add(attrs.get('data-version'))
    decoded = base64.urlsafe_b64decode(token + '=' * (-len(token) % 4)).decode()
    episode_id = decoded.split(':', 1)[0]
    if not episode_id.isdigit():
        return []
    result = []
    for language in ('sub', 'dub'):
        if language in languages:
            result.append({'name': 'Aniwatch Yuki', 'type': language,
                           'source_kind': 'ANIWATCH',
                           'url': PLAYER + '/stream/s-2/' + episode_id + '/' + language})
    return result


def find_sources(title, number, year=None):
    if not _key(title) or int(number) < 1:
        return []
    def lookup():
        # Search punctuation handling differs from the displayed aliases.
        # Broader searches still require an exact English/Japanese title match.
        queries = list(dict.fromkeys((title, _key(title), ' '.join(_key(title).split()[:3]))))
        for query in queries:
            search = _get(BASE + '/search?' + urlencode({'q': query}), BASE + '/')
            match = _match_title(search, title, year)
            if match:
                return match
        return ''
    detail_url = _cached(('match', _key(title), year), lookup, 600)
    return _episode_sources(_watch_page(detail_url, number), number) if detail_url else []


def _decode_source(payload):
    if payload.get('enc'):
        value = payload['enc']
        raw = base64.urlsafe_b64decode(value + '=' * (-len(value) % 4))
        return json.loads(decrypt(b'i?LMTAx0Q6,:}50U'.ljust(32, b'\0'),
                                  b"W0;27ToaUpl_P%'c", raw).decode('utf-8'))['file']
    sources = payload.get('sources')
    if isinstance(sources, dict):
        return sources.get('file', '')
    if isinstance(sources, list):
        return next((item.get('file', '') for item in sources if isinstance(item, dict)), '')
    return ''


def _signed_url(url):
    path = re.search(r'/([a-f0-9]{32})/([a-f0-9]{32})/', url, re.I)
    if not path or 'token=' in url:
        return url
    message = (str(int(time.time()) + 90) + '|' + '/'.join(path.groups()).lower()).encode()
    encode = lambda value: base64.urlsafe_b64encode(value).decode().rstrip('=')
    signature = hmac.new(b'MpCdnT0k3n!9f2K#xQ7vL5mR8wN1pY4s', message, hashlib.sha256).digest()
    return url + ('&' if '?' in url else '?') + urlencode({'token': encode(message) + '.' + encode(signature)})


def resolve(url):
    try:
        parsed = urlparse(url)
        if parsed.hostname != 'megaplay.buzz' or not re.fullmatch(r'/stream/s-2/\d+/(sub|dub)', parsed.path):
            raise ValueError('Invalid Aniwatch player URL')
        player = _get(url, BASE + '/')
        file_id = re.search(r'\bdata-id=["\'](\d+)["\']', player)
        if not file_id:
            raise ValueError('Yuki did not return a player file')
        payload = json.loads(_get(PLAYER + '/stream/getSourcesNew?' +
                                 urlencode({'id': file_id[1], 'platform': 'OTHER'}), url,
                                 {'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json'}))
        stream = _decode_source(payload)
        if urlparse(stream).scheme not in ('https', 'http'):
            raise ValueError('Yuki returned no media URL')
        stream = _signed_url(stream)
        manifest = _get(stream, PLAYER + '/')
        if not manifest.lstrip().startswith('#EXTM3U'):
            raise ValueError('Yuki returned no HLS manifest')
        subtitles = []
        for track in payload.get('tracks') or []:
            if (track.get('kind') == 'captions' and track.get('label') == 'English' and
                    urlparse(track.get('file', '')).scheme in ('https', 'http')):
                subtitles.append(track['file'] + '|' + urlencode(HEADERS))
        return {'direct': True, 'url': stream + '|' + urlencode(HEADERS),
                'media_type': 'hls', 'subtitles': subtitles}
    except Exception as exc:
        return {'direct': False, 'url': url, 'error': 'Aniwatch Yuki: ' + str(exc)[:180]}
