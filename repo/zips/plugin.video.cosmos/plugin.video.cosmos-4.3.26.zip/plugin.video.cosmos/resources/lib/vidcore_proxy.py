"""Local HLS relay preserving provider headers, tokens and segment packaging."""
import re
import json
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urljoin, urlsplit, parse_qsl, urlencode, urlunsplit
from urllib.request import Request, urlopen


def video_bytes(data):
    if not data.startswith(b'\x89PNG\r\n\x1a\n'):
        return data
    # Require five consecutive TS sync bytes to avoid matching image data.
    for offset in range(min(len(data) - 752, 65536)):
        if all(data[offset + n * 188] == 0x47 for n in range(5)):
            return data[offset:]
    raise ValueError('Image response contains no MPEG-TS video')


class Proxy:
    def __init__(self, url, headers, refresh_tokens=True, refresh_callback=None, request_opener=None):
        self.headers = headers
        self.open = request_opener.open if request_opener is not None else urlopen
        parsed = urlsplit(url)
        self.token = dict(parse_qsl(parsed.query)).get('token', '') if refresh_tokens else ''
        self.expires = dict(parse_qsl(parsed.query)).get('expires', '') if refresh_tokens else ''
        self.refresh_callback = refresh_callback
        self.token_host = parsed.netloc
        self.root_upstream = url
        self.last_token_refresh = time.monotonic()
        self.refresh_lock = threading.Lock()
        self.urls = {}
        self.lock = threading.Lock()
        self.last_request = time.monotonic()
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                with owner.lock:
                    upstream = owner.urls.get(self.path)
                if not upstream:
                    self.send_error(404)
                    return
                owner.last_request = time.monotonic()
                try:
                    owner.refresh_if_due()
                    request_url = owner.authorize(upstream)
                    request_headers = dict(owner.headers)
                    if self.headers.get('Range'):
                        request_headers['Range'] = self.headers['Range']
                    try:
                        response = owner.open(Request(request_url, headers=request_headers), timeout=20)
                    except Exception as first_error:
                        if (getattr(first_error, 'code', None) not in (401, 403, 404)
                                or not owner.refresh_callback and not owner.token):
                            raise
                        if owner.refresh_callback:
                            owner.refresh_from_source()
                        else:
                            owner.refresh_token()
                        response = owner.open(Request(owner.authorize(upstream), headers=request_headers), timeout=20)
                    with response:
                        data = response.read(32 * 1024 * 1024 + 1)
                        base = response.geturl()
                        status = response.status
                        content_range = response.headers.get('Content-Range')
                    if len(data) > 32 * 1024 * 1024:
                        raise ValueError('Segment exceeds size limit')
                    if data.lstrip().startswith(b'#EXTM3U'):
                        status, content_range = 200, None
                        lines = []
                        manifest = data.decode('utf-8-sig')
                        master = '#EXT-X-STREAM-INF:' in manifest
                        for line in manifest.splitlines():
                            if line and not line.startswith('#'):
                                line = owner.register(urljoin(base, line.strip()),
                                                      '.m3u8' if master else None)
                            elif 'URI="' in line:
                                suffix = '.mp4' if line.startswith('#EXT-X-MAP:') else '.key' if line.startswith('#EXT-X-KEY:') else '.m3u8'
                                line = re.sub(r'URI="([^"]+)"',
                                              lambda m: 'URI="' + owner.register(urljoin(base, m[1]), suffix) + '"', line)
                            lines.append(line)
                        data = ('\n'.join(lines) + '\n').encode('utf-8')
                        mime = 'application/vnd.apple.mpegurl'
                    else:
                        data = video_bytes(data)
                        mime = 'video/mp2t' if data.startswith(b'G') else 'application/octet-stream'
                    self.send_response(status)
                    self.send_header('Content-Type', mime)
                    self.send_header('Content-Length', str(len(data)))
                    if content_range:
                        self.send_header('Content-Range', content_range)
                        self.send_header('Accept-Ranges', 'bytes')
                    self.end_headers()
                    self.wfile.write(data)
                except (OSError, ValueError) as exc:
                    try:
                        import xbmc
                        xbmc.log('COSMOS stream proxy failed: %s' % type(exc).__name__, xbmc.LOGWARNING)
                    except Exception:
                        pass
                    self.send_error(502, 'Stream upstream unavailable')
                finally:
                    owner.last_request = time.monotonic()

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.server.daemon_threads = True
        self.url = self.register(url, '.m3u8')
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def authorize(self, url):
        if not self.token or urlsplit(url).netloc != self.token_host:
            return url
        parsed = urlsplit(url)
        query = dict(parse_qsl(parsed.query))
        if self.token:
            query['token'] = self.token
        if self.expires:
            query['expires'] = self.expires
        return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), parsed.fragment))

    def refresh_token(self):
        origin = 'https://' + self.token_host
        with self.open(Request(origin + '/generate.php', headers=self.headers), timeout=12) as response:
            token = response.read(4096).decode('utf-8').strip()
        if token.startswith('{'):
            data = json.loads(token)
            token = data.get('token') or data.get('data') or data.get('string') or data.get('result') or ''
            self.expires = str(data.get('expires', self.expires))
        if token:
            self.token = token
            self.last_token_refresh = time.monotonic()

    def refresh_if_due(self):
        """Refresh from an active Kodi request, not only the keep-alive loop."""
        if not (self.refresh_callback or self.token):
            return
        if time.monotonic() - self.last_token_refresh < 120:
            return
        if not self.refresh_lock.acquire(False):
            return
        try:
            if time.monotonic() - self.last_token_refresh >= 120:
                if self.refresh_callback:
                    self.refresh_from_source()
                else:
                    self.refresh_token()
        finally:
            self.refresh_lock.release()

    def refresh_from_source(self):
        import xbmc
        fresh_url = self.refresh_callback()
        if not fresh_url:
            raise ValueError('source refresh returned no URL')
        old_root = self.root_upstream
        query = dict(parse_qsl(urlsplit(fresh_url).query))
        with self.lock:
            self.token = query.get('token', self.token)
            self.expires = query.get('expires', self.expires)
            # A refreshed signature can rotate the playlist URL as well as
            # its token. Replace the registered root mapping so Kodi's next
            # manifest reload reaches the new upstream playlist.
            for path, registered in list(self.urls.items()):
                if registered == old_root:
                    self.urls[path] = fresh_url
            self.root_upstream = fresh_url
        self.last_token_refresh = time.monotonic()
        xbmc.log('COSMOS stream: refreshed signed stream token', xbmc.LOGINFO)

    def register(self, url, suffix=None):
        if self.token and urlsplit(url).netloc == self.token_host:
            parsed = urlsplit(url)
            query = dict(parse_qsl(parsed.query))
            query.setdefault('token', self.token)
            url = urlunsplit((parsed.scheme, parsed.netloc, parsed.path,
                              urlencode(query), parsed.fragment))
        with self.lock:
            for path, existing in self.urls.items():
                if existing == url:
                    break
            else:
                # FFmpeg checks HLS segment extensions; keep recognizable
                # media paths even when the provider disguises its segments.
                extension = urlsplit(url).path.rsplit('.', 1)[-1].lower()
                if suffix is None:
                    suffix = '.' + extension if extension in ('m3u8', 'mp4', 'm4s', 'ts', 'aac') else '.ts'
                path = '/' + secrets.token_urlsafe(24) + suffix
                self.urls[path] = url
        return 'http://127.0.0.1:%d%s' % (self.server.server_address[1], path)

    def keep_alive(self):
        import xbmc
        monitor = xbmc.Monitor()
        player = xbmc.Player()
        try:
            while not monitor.abortRequested():
                # Signed provider URLs commonly expire after about five
                # minutes. Refresh with headroom so the next manifest reload
                # does not receive an already-expired URL.
                if (self.refresh_callback or self.token) and time.monotonic() - self.last_token_refresh >= 120:
                    try:
                        if self.refresh_callback:
                            self.refresh_from_source()
                        else:
                            self.refresh_token()
                    except Exception as exc:
                        import xbmc
                        xbmc.log('COSMOS stream: background token refresh failed: %s' %
                                 type(exc).__name__, xbmc.LOGWARNING)
                if time.monotonic() - self.last_request > 45 and not player.isPlayingVideo():
                    break
                if monitor.waitForAbort(1):
                    break
        finally:
            self.server.shutdown()
            self.server.server_close()
