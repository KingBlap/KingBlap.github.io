# -*- coding: utf-8 -*-
"""DDLValley scraper for C.O.S.M.O.S.

Scrapes https://www.ddlvalley.me/ for Movies and TV Shows content.
Produces listing pages (with pagination) and detail pages with download links.

Uses the site's WordPress structure:
  - Listings: <div class="pb fl"> -> <h2><a>...</a></h2> -> <div class="post" id="post-XXX">
  - Detail:   <div class="poster"> with <img> and <div class="plot"> for plot
  - Links:    plain-text in <p> tags with host names as labels
"""
import html as _html
import re
import xbmc
from urllib.parse import quote_plus, urljoin, urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

_BASE = 'https://www.ddlvalley.me'
_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

# These are the file hosts currently exposed by DDLValley's movie/TV posts
# that Cosmos can hand to its existing file-host resolver.  Keep this map
# deliberately narrow so navigation, metadata and unrelated mirror links do
# not become misleading playable sources.
_SUPPORTED_HOST_DOMAINS = {
    'rapidgator.net': 'Rapidgator',
    'rg.to': 'Rapidgator',
    'uploadgig.com': 'Uploadgig',
    'nitroflare.com': 'Nitroflare',
    'uploady.io': 'Uploady',
    'multiup.io': 'Multiup',
    'multiup.org': 'Multiup',
}

# ── Host detection regexes ──────────────────────────────────────────────
_HOST_MAP = {
    'rapidgator': 'Rapidgator',
    'rg.to': 'Rapidgator',
    'nitroflare': 'Nitroflare',
    'uploady.io': 'Uploady',
    '1fichier': '1fichier',
    'uploadgig': 'Uploadgig',
    'uploaded': 'Uploaded',
    'ul.to': 'Uploaded',
    'katfile': 'Katfile',
    'filefactory': 'FileFactory',
    'turbobit': 'Turbobit',
    'depositfiles': 'DepositFiles',
    'datafile': 'DataFile',
    'extabit': 'Extabit',
    'filespace': 'FileSpace',
    'novafile': 'Novafile',
    'solidfiles': 'SolidFiles',
    'zippyshare': 'ZippyShare',
    'mediafire': 'MediaFire',
    'mega.nz': 'Mega',
    'mega.co': 'Mega',
    'google.com': 'Google Drive',
    'drive.google': 'Google Drive',
    'dropbox': 'Dropbox',
    'multiup': 'Multiup',
    'multiup.io': 'Multiup',
    'ddownload': 'DDownload',
    'fboom': 'Fileboom',
    'keep2share': 'Keep2Share',
    'k2s.cc': 'Keep2Share',
    'file.al': 'FileAl',
    'filer': 'Filer',
    'hitfile': 'Hitfile',
    'filejoker': 'FileJoker',
    'filejoker.net': 'FileJoker',
    'filepost': 'FilePost',
    'tusfiles': 'TusFiles',
    'userscloud': 'UsersCloud',
    'worldbytez': 'WorldBytez',
    'fastfile': 'FastFile',
    'hotlink.cc': 'Hotlink',
    'filefox': 'FileFox',
    'prefiles': 'PreFiles',
    'icerbox': 'Icerbox',
    'share-online': 'Share-Online',
}

# RAR / ZIP file extensions to skip
_RAR_RE = re.compile(r'\.(?:rar|r\d{2,3}|zip|7z|tar\.gz|tgz)$', re.I)
# Quality regex
_QUAL_RE = re.compile(
    r'(\b(?:2160p|4k|uhd|1080p|720p|480p|360p|bluray|brrip|web-dl|webdl|webrip|hdtv|hdcam|hdts|cam|ts|dvdrip|dvdr|bdrip|bdr)\b)',
    re.I,
)
# SxxEyy pattern.  DDLValley normally uses dotted release names, but the
# separator class also accepts the hyphen/underscore forms seen in older
# posts and allows a marker at either end of the title.
_SE_RE = re.compile(r'(?:^|[.\s_-])S(\d{1,2})E(\d{1,2})(?=$|[.\s_-])', re.I)


def _clean_text(value):
    """Decode markup text and collapse formatting whitespace."""
    return re.sub(r'\s+', ' ', _html.unescape(value or '')).strip()


def _fetch(url, timeout=20):
    """Fetch raw HTML from DDLValley."""
    candidates = [url]
    if url.startswith('https://www.ddlvalley.me/'):
        candidates.append(url.replace('https://www.ddlvalley.me/', 'https://ddlvalley.me/', 1))
    headers = {
        'User-Agent': _USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'identity',
        'Connection': 'close',
        'Upgrade-Insecure-Requests': '1',
    }
    last_error = None
    for candidate in candidates:
        try:
            req = Request(candidate, headers=headers)
            resp = urlopen(req, timeout=timeout)
            return resp.read().decode('utf-8', errors='replace')
        except (HTTPError, URLError, OSError) as e:
            last_error = e
            continue
        except Exception as e:
            last_error = e
            continue
    xbmc.log(f'DDLValley: fetch failed for {url}: {last_error}', xbmc.LOGERROR)
    return ''


def _host_name(url):
    """Return a clean host name label for a URL."""
    try:
        hostname = (urlsplit(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        hostname = ''

    for domain, name in _SUPPORTED_HOST_DOMAINS.items():
        if hostname == domain or hostname.endswith('.' + domain):
            return name
    for key, name in _HOST_MAP.items():
        key_lower = key.lower()
        # Match complete hostname values/domains, rather than a substring
        # anywhere in the URL path.  Bare tokens are retained for legacy
        # fallback labels but never treated as arbitrary hostname labels;
        # supported file hosts are handled by the exact domain map above.
        if ('.' in key_lower
                and (hostname == key_lower or hostname.endswith('.' + key_lower))
                or '.' not in key_lower and hostname == key_lower):
            return name
    # Fallback: extract domain
    if hostname:
        return hostname.split('.')[0].title()
    return 'Unknown'


def _wanted_host_name(url):
    """Return a supported host only when the URL's hostname is trusted."""
    try:
        hostname = (urlsplit(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        return ''
    for domain, name in _SUPPORTED_HOST_DOMAINS.items():
        if hostname == domain or hostname.endswith('.' + domain):
            return name
    return ''


def _quality(title):
    """Extract quality label from release title."""
    matches = _QUAL_RE.findall(title)
    if matches:
        return ' '.join(matches)
    return ''


def _detect_content(title):
    """Detect if a title is a TV episode or movie."""
    se = _SE_RE.search(title)
    if se:
        return 'episode', se.group(1), se.group(2)
    return 'movie', '', ''


def _is_rar_link(url):
    """Check if a URL points to a compressed archive."""
    try:
        path = urlsplit(url or '').path.lower().rstrip('/')
    except ValueError:
        return False
    # File-host pages commonly append .html to the actual archive filename:
    # e.g. `movie.part1.rar.html`.  Strip that wrapper before testing.
    path = re.sub(r'\.(?:html?|php)$', '', path)
    return bool(_RAR_RE.search(path))


def _extract_post(html, post_id):
    """Extract a single post's data from the listing page HTML.

    Finds the position of the post div, then searches backward for the
    nearest preceding h2 to get the title. This handles any whitespace or
    content between the h2 and the post div.
    """
    # Locate the post div by its id (handles quoted and unquoted attributes)
    post_id_m = re.search(rf'id=["\']?post-{post_id}["\']?', html)
    if not post_id_m:
        return None

    post_pos = post_id_m.start()

    # ── Title and link: search backward for the nearest h2 ──────────────
    title = ''
    link = ''
    preceding = html[:post_pos]
    h2_matches = list(re.finditer(r'<h2[^>]*>(.*?)</h2>', preceding, re.DOTALL | re.I))
    if h2_matches:
        last_h2_content = h2_matches[-1].group(1)
        # Extract href and anchor text from the anchor inside the h2
        # DDLValley uses unquoted href attributes: href=https://... rel=nofollow
        a_m = re.search(r'<a[^>]+href=["\']?([^"\'>\s]+)["\']?[^>]*>(.*?)</a>', last_h2_content, re.DOTALL | re.I)
        if a_m:
            link = urljoin(_BASE + '/', _html.unescape(a_m.group(1).strip()))
            title = _clean_text(re.sub(r'<[^>]+>', '', a_m.group(2)))
        else:
            title = _clean_text(re.sub(r'<[^>]+>', '', last_h2_content))

    # Fallback: img title attribute inside the post block
    if not title:
        chunk = html[post_pos:post_pos + 2000]
        img = re.search(r'<img[^>]*title=["\']([^"\']+)["\']', chunk)
        if img:
            title = _clean_text(img.group(1))

    # ── Poster ─────────────────────────────────────────────────────────────
    poster = ''
    chunk = html[post_pos:post_pos + 2000]
    img_m = re.search(r'<img[^>]*src=["\']?([^"\'>\s]+)["\']?[^>]*>', chunk)
    if img_m:
        poster = urljoin(_BASE + '/', _html.unescape(img_m.group(1).strip()))

    # ── Plot ───────────────────────────────────────────────────────────────
    plot = ''
    plot_m = re.search(r'<div[^>]+class=["\']?plot["\']?[^>]*>(.*?)</div>', chunk, re.DOTALL | re.I)
    if plot_m:
        plot = _clean_text(re.sub(r'<[^>]+>', '', plot_m.group(1)))

    return {
        'title': title,
        'link': link,
        'poster': poster,
        'plot': plot,
    }


def scrape_listing(url, page=1):
    """Scrape a listing page and return list of items.

    Returns list of dicts:
      {'title': str, 'link': str, 'poster': str, 'plot': str, 'quality': str,
       'content': str, 'season': str, 'episode': str}
    """
    if page > 1:
        url = f'{url.rstrip("/")}/page/{page}/'
    html = _fetch(url)
    if not html:
        return []

    # Find all post IDs — try multiple patterns to handle minified HTML
    post_ids = re.findall(r'id=["\']?post-(\d+)["\']?', html)
    # Deduplicate while preserving order
    seen = []
    for pid in post_ids:
        if pid not in seen:
            seen.append(pid)
    post_ids = seen

    items = []
    for pid in post_ids:
        post = _extract_post(html, pid)
        if not post or not post['title']:
            continue
        content, season, episode = _detect_content(post['title'])
        qual = _quality(post['title'])
        items.append({
            'title': post['title'],
            'link': post['link'],
            'poster': post['poster'],
            'plot': post['plot'],
            'quality': qual,
            'content': content,
            'season': season,
            'episode': episode,
        })

    # Search pages on newer DDLValley themes may omit the legacy
    # ``id="post-123"`` wrapper. Fall back to heading links so search keeps
    # working when the result cards use a lighter markup.
    if not items:
        seen_links = set()
        for heading in re.finditer(r'<h[1-6][^>]*>(.*?)</h[1-6]>', html, re.DOTALL | re.I):
            anchor = re.search(
                r'<a\b[^>]*href=["\']?([^"\'>\s]+)["\']?[^>]*>(.*?)</a>',
                heading.group(1), re.DOTALL | re.I,
            )
            if not anchor:
                continue
            link = urljoin(_BASE + '/', _html.unescape(anchor.group(1).strip()))
            title = _clean_text(anchor.group(2))
            if (not title or link in seen_links or
                    link.rstrip('/') == _BASE or
                    any(token in link.lower() for token in ('/category/', '/tag/', '/page/', '/author/'))):
                continue
            seen_links.add(link)
            content, season, episode = _detect_content(title)
            items.append({
                'title': title, 'link': link, 'poster': '', 'plot': '',
                'quality': _quality(title), 'content': content,
                'season': season, 'episode': episode,
            })

    return items


def scrape_detail(url):
    """Scrape a detail page and return list of download links."""
    html = _fetch(url)
    if not html:
        return None

    # Title from <title> tag
    title = ''
    title_tag = re.search(r'<title[^>]*>(.*?)</title>', html, re.DOTALL | re.I)
    if title_tag:
        raw = _clean_text(re.sub(r'<[^>]+>', '', title_tag.group(1)))
        # Strip any combination of " - DDLValley", "| DDLValley", "DDLValley DDLValley", etc.
        raw = re.sub(r'\s*[-–|]\s*DDL\s*Valley.*$', '', raw, flags=re.I).strip()
        raw = re.sub(r'\s*DDLValley.*$', '', raw, flags=re.I).strip()
        title = raw
    if not title:
        for tag in ('h1', 'h2'):
            m = re.search(rf'<{tag}[^>]*>(.*?)</{tag}>', html, re.DOTALL | re.I)
            if m:
                title = _clean_text(re.sub(r'<[^>]+>', '', m.group(1)))
                if title:
                    break

    # Poster
    poster = ''
    img = re.search(
        r'<div[^>]+class=["\']?poster[^>]*>.*?<img[^>]*src=["\']?([^"\'>\s]+)["\']?',
        html, re.DOTALL | re.I,
    )
    if img:
        poster = urljoin(url, _html.unescape(img.group(1).strip()))

    # Plot
    plot = ''
    plot_m = re.search(r'<div[^>]+class=["\']?plot["\']?[^>]*>(.*?)</div>', html, re.DOTALL | re.I)
    if plot_m:
        plot = _clean_text(re.sub(r'<[^>]+>', '', plot_m.group(1)))

    content, season, episode = _detect_content(title)
    qual = _quality(title)

    # ── Links ──────────────────────────────────────────────────────────────
    # DDLValley places a host label in a <strong> immediately before each
    # anchor.  Parse the anchors themselves instead of searching for label
    # text: host names also occur in the visible URL, and that old approach
    # could associate the wrong following anchor with a label.  It also missed
    # Multiup even though the site publishes it and Cosmos can resolve it.
    links = []
    seen_urls = set()
    for anchor_m in re.finditer(
        r'<a\b[^>]*\bhref\s*=\s*(?:["\']([^"\']+)["\']|([^\s>]+))',
        html, re.I,
    ):
        raw_url = _html.unescape((anchor_m.group(1) or anchor_m.group(2) or '').strip())
        raw_url = raw_url.rstrip('.,;)')
        if not raw_url or raw_url.startswith(('#', 'javascript:', 'mailto:')):
            continue
        raw_url = urljoin(url, raw_url)
        actual_host = _wanted_host_name(raw_url)
        if not actual_host or _is_rar_link(raw_url):
            continue
        if raw_url in seen_urls:
            continue
        seen_urls.add(raw_url)
        links.append({'label': actual_host, 'host': actual_host, 'url': raw_url})

    return {
        'title': title,
        'poster': poster,
        'plot': plot,
        'quality': qual,
        'content': content,
        'season': season,
        'episode': episode,
        'links': links,
    }


def has_next_page(url, page=1):
    """Check if the listing page has a next page link."""
    if page > 1:
        url = f'{url.rstrip("/")}/page/{page}/'
    html = _fetch(url)
    if not html:
        return False
    return bool(re.search(rf'page/{page + 1}/', html, re.I))


def get_items_for_url(category_url, page=1):
    """Fetch items for a full category URL, with fallback if the first attempt
    returns empty (tries page without trailing content variation)."""
    items = scrape_listing(category_url, page=page)
    return items, has_next_page(category_url, page=page) if items else False


def get_items_for_xml(category, page=1):
    """Fetch items for a category slug path like 'movies' or 'movies/bdrip'.
    If the nested URL returns empty, falls back to the flat top-level URL."""
    url = f'{_BASE}/category/{category}/'
    items = scrape_listing(url, page=page)
    if not items and '/' in category:
        # Fallback: try the leaf slug without parent
        flat = category.split('/')[-1]
        flat_url = f'{_BASE}/category/{flat}/'
        items = scrape_listing(flat_url, page=page)
        if items:
            url = flat_url
    return items, has_next_page(url, page=page) if items else False


def get_items_for_search(query, page=1):
    """Search DDLValley and return (items, has_next)."""
    encoded = quote_plus(query)
    if page > 1:
        url = f'{_BASE}/page/{page}/?s={encoded}'
    else:
        url = f'{_BASE}/?s={encoded}'
    items = scrape_listing(url, page=1)
    # Check if next page exists
    next_url = f'{_BASE}/page/{page + 1}/?s={encoded}'
    next_html = _fetch(next_url)
    has_next = bool(next_html and re.search(r'id=["\']?post-\d+', next_html))
    return items, has_next
