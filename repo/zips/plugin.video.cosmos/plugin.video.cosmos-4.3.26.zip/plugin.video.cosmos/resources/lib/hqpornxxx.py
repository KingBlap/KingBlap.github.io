# -*- coding: utf-8 -*-
"""Catalogue and signed-stream parser for hqporn.xxx."""
import html
import re
import time
from urllib.parse import urljoin
from urllib.request import Request, urlopen


BASE_URL = 'https://hqporn.xxx/'
USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'
)
_PAGE_CACHE = {}
_PAGE_CACHE_TTL = 180


def clear_cache():
    _PAGE_CACHE.clear()


def fetch(url, referer=BASE_URL, timeout=20):
    cached = _PAGE_CACHE.get(url)
    if cached and time.time() - cached[0] < _PAGE_CACHE_TTL:
        return cached[1]
    request = Request(url, headers={
        'User-Agent': USER_AGENT,
        'Referer': referer or BASE_URL,
        'Accept-Language': 'en-GB,en;q=0.8',
    })
    with urlopen(request, timeout=timeout) as response:
        document = response.read().decode('utf-8', 'replace')
    _PAGE_CACHE[url] = (time.time(), document)
    if len(_PAGE_CACHE) > 80:
        oldest = sorted(_PAGE_CACHE, key=lambda key: _PAGE_CACHE[key][0])[:20]
        for key in oldest:
            _PAGE_CACHE.pop(key, None)
    return document


def parse_listing(document, page_url=BASE_URL):
    items = []
    seen = set()
    pattern = re.compile(
        r'<a\b([^>]*\bhref=["\']([^"\']+_\d+\.html)[^>]*)>([\s\S]*?)</a>', re.I)
    for match in pattern.finditer(document or ''):
        url = urljoin(page_url, html.unescape(match.group(2)))
        if url in seen:
            continue
        seen.add(url)
        attributes, body = match.group(1), match.group(3)
        title_match = re.search(r'\btitle=["\']([^"\']+)', attributes, re.I)
        image_match = re.search(
            r'(?:data-src|srcset|src)=["\']([^"\']+)', body, re.I)
        duration_match = re.search(
            r'class=["\'][^"\']*duration[^"\']*["\'][^>]*>[\s\S]*?'
            r'<span[^>]*>([^<]+)', body, re.I)
        title = html.unescape(title_match.group(1) if title_match else '').strip()
        if not title:
            alt = re.search(r'<img\b[^>]*alt=["\']([^"\']+)', body, re.I)
            title = html.unescape(alt.group(1) if alt else '').strip()
        items.append({
            'title': title or 'hqporn.xxx video',
            'url': url,
            'thumb': urljoin(page_url, html.unescape(image_match.group(1))) if image_match else '',
            'duration': html.unescape(duration_match.group(1)).strip() if duration_match else '',
        })
    next_url = ''
    current = re.search(r'/(\d+)/?(?:[?#]|$)', page_url.rstrip('/'))
    target_page = int(current.group(1)) + 1 if current else 2
    for href in re.findall(r'href=["\']([^"\']+)["\']', document or '', re.I):
        absolute = urljoin(page_url, html.unescape(href))
        if re.search(r'/%d/?(?:[?#]|$)' % target_page, absolute):
            next_url = absolute
            break
    return items, next_url


def parse_channels(document, page_url=BASE_URL):
    """Extract channel links from the HQPorn channels index."""
    channels = []
    seen = set()
    for attrs, href, body in re.findall(r'<a\b([^>]*href=["\']([^"\']+)["\'][^>]*)>([\s\S]*?)</a>', document or '', re.I):
        url = urljoin(page_url, html.unescape(href))
        if '/channels/' not in url or url.rstrip('/').endswith('/channels'):
            continue
        title_match = re.search(r'\btitle=["\']([^"\']+)', attrs, re.I)
        alt_match = re.search(r'\balt=["\']([^"\']+)', body, re.I)
        image_match = re.search(
            r'<img\b[^>]*(?:src|data-src|data-original|data-lazy-src|data-image)=["\']([^"\']+)'
            r'|background-image\s*:\s*url\(["\']?([^"\')]+)',
            attrs + body, re.I,
        )
        title = title_match.group(1) if title_match else (alt_match.group(1) if alt_match else body)
        title = re.sub(r'<[^>]+>', ' ', title)
        title = re.sub(r'\s+', ' ', html.unescape(title)).strip()
        if not title:
            title = url.rstrip('/').rsplit('/', 1)[-1].replace('-', ' ').title()
        lowered = title.casefold()
        if (not title or url in seen or lowered in ('channels', 'next', 'previous', 'report')
                or title.isdigit() or '${' in title or '{{' in title or '}}' in title
                or lowered.startswith('join ') or re.search(r'/channels/\d+/?$', url)):
            continue
        seen.add(url)
        channels.append({'title': title, 'url': url})
    return channels


def parse_pornstars(document, page_url=BASE_URL):
    """Extract pornstar profile links from the HQPorn index."""
    people = []
    seen = set()
    for attrs, href, body in re.findall(r'<a\b([^>]*href=["\']([^"\']+)["\'][^>]*)>([\s\S]*?)</a>', document or '', re.I):
        url = urljoin(page_url, html.unescape(href))
        if '/alias/' not in url or url.rstrip('/').endswith('/alias'):
            continue
        title_match = re.search(r'\btitle=["\']([^"\']+)', attrs, re.I)
        alt_match = re.search(r'\balt=["\']([^"\']+)', body, re.I)
        image_match = re.search(r'<img\b[^>]*(?:src|data-src)=["\']([^"\']+)', body, re.I)
        title = title_match.group(1) if title_match else (alt_match.group(1) if alt_match else body)
        title = re.sub(r'<[^>]+>', ' ', title)
        title = re.sub(r'\s+', ' ', html.unescape(title)).strip()
        lowered = title.casefold()
        if (not title or url in seen or title.isdigit() or '${' in title
                or '{{' in title or '}}' in title
                or lowered in ('pornstars', 'next', 'previous', 'report')
                or lowered.startswith('join ')):
            continue
        seen.add(url)
        image_url = ''
        if image_match:
            image_url = image_match.group(1) or image_match.group(2) or ''
        people.append({'title': title, 'url': url,
                       'thumb': urljoin(page_url, html.unescape(image_url)) if image_url else ''})
    return people


def parse_sources(document, page_url):
    sources = []
    seen = set()
    for tag in re.findall(r'<source\b[^>]*>', document or '', re.I):
        src = re.search(r'\bsrc=["\']([^"\']+)', tag, re.I)
        if not src:
            continue
        url = urljoin(page_url, html.unescape(src.group(1)))
        if url in seen or not re.search(r'\.mp4(?:\?|$)', url, re.I):
            continue
        seen.add(url)
        label_match = re.search(r'\b(?:label|data-quality)=["\']([^"\']+)', tag, re.I)
        quality = re.search(r'[_-](\d{3,4})p?\.mp4', url, re.I)
        label = (label_match.group(1) if label_match else '') or (
            quality.group(1) + 'p' if quality else 'MP4')
        sources.append({'label': html.unescape(label), 'url': url})
    sources.sort(key=lambda item: int((re.search(r'(\d+)', item['label']) or ['0'])[0]),
                 reverse=True)
    return sources


def kodi_stream_url(url, referer):
    from urllib.parse import quote_plus
    return '%s|User-Agent=%s&Referer=%s' % (
        url, quote_plus(USER_AGENT), quote_plus(referer))
