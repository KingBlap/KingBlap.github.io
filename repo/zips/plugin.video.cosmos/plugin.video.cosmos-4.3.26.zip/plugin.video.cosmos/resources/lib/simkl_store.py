"""Persistent, transactional Simkl read cache shared by Kodi invocations."""
import json
import os
import sqlite3
import time

TYPES = ('shows', 'movies', 'anime')
BLOCKS = ('tv_shows', 'movies', 'anime')
TTL = 900


def connect(folder, name='simkl_sync.db'):
    os.makedirs(folder, exist_ok=True)
    # A sync can hold the write transaction while the API request is in
    # flight.  Kodi may open the same menu from more than one invocation, so
    # let the second invocation wait instead of treating normal contention as
    # a failed sync.
    db = sqlite3.connect(os.path.join(folder, name), timeout=10)
    db.execute('PRAGMA busy_timeout=10000')
    db.execute('CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, value TEXT)')
    return db


def read(db, key):
    row = db.execute('SELECT value FROM state WHERE key=?', (key,)).fetchone()
    return json.loads(row[0]) if row else {}


def write(db, key, value):
    db.execute('INSERT OR REPLACE INTO state VALUES (?,?)', (key, json.dumps(value)))


def throttle(folder):
    # A separate database avoids contention with the sync transaction.
    db = connect(folder, 'simkl_requests.db')
    try:
        db.execute('PRAGMA busy_timeout=10000')
        db.execute('BEGIN IMMEDIATE')
        last = read(db, 'last').get('at', 0)
        time.sleep(max(0, 1.5 - (time.time() - last)))
        write(db, 'last', {'at': time.time()})
        db.commit()
    finally:
        db.close()


def identity(item):
    if not isinstance(item, dict):
        raise ValueError('Invalid Simkl item')
    media = item.get('movie') or item.get('show') or item.get('anime') or item
    if not isinstance(media, dict):
        raise ValueError('Invalid Simkl media item')
    ids = media.get('ids') or item.get('ids') or {}
    if not isinstance(ids, dict):
        raise ValueError('Invalid Simkl identifiers')
    for key in ('simkl', 'simkl_id', 'imdb', 'tmdb', 'tvdb'):
        if ids.get(key) is not None:
            return ('simkl' if key == 'simkl_id' else key) + ':' + str(ids[key])
    raise ValueError('Simkl item missing an identifier')


def library_response(data):
    if not isinstance(data, dict) or data.get('error'):
        raise ValueError('Invalid library response')
    result = {}
    for kind in TYPES:
        rows = data.get(kind, [])
        if not isinstance(rows, list):
            raise ValueError('Invalid library section')
        result[kind] = {identity(row): row for row in rows}
    return result


def invalidate(folder, account):
    db = connect(folder)
    try:
        db.execute('BEGIN IMMEDIATE')
        state = read(db, account)
        state['checked'] = 0
        state['dirty'] = True
        state.pop('retry_at', None)
        for record in state.get('resources', {}).values():
            record['dirty'] = True
        write(db, account, state)
        db.commit()
    finally:
        db.close()


def sync(folder, account, request, force=False, resource=None):
    """Commit data and cursor together; failed work never advances its cursor."""
    db = connect(folder)
    state = read(db, account)
    try:
        db.execute('BEGIN IMMEDIATE')
        state = read(db, account)
        now = time.time()
        if not force and now < state.get('retry_at', 0):
            raise ValueError('Sync retry deferred')
        if force or now - state.get('checked', 0) >= TTL:
            status, activities, _ = request('/sync/activities')
            if status != 200 or not isinstance(activities, dict) or not activities.get('all'):
                raise ValueError('Activity check failed')
            old = state.get('activity', {})
            params = dict(extended='full', episode_watched_at='yes',
                          include_all_episodes='yes', next_watch_info='yes')
            if 'library' not in state:
                # The unfiltered endpoint returns all media sections in one
                # response.  Besides being faster, this avoids spending three
                # full-library requests on the first menu open.
                status, data, _ = request('/sync/all-items', params=params)
                if status != 200:
                    raise ValueError('Initial library download failed')
                state['library'] = library_response(data)
            elif old.get('all') != activities['all'] or state.get('dirty'):
                params['date_from'] = old['all']
                status, data, _ = request('/sync/all-items', params=params)
                if status != 200:
                    raise ValueError('Library delta failed')
                delta = library_response(data)
                for kind in TYPES:
                    state['library'][kind].update(delta[kind])
                removed = any((old.get(b) or {}).get('removed_from_list') !=
                              (activities.get(b) or {}).get('removed_from_list') for b in BLOCKS)
                if removed:
                    status, data, _ = request('/sync/all-items', params={'extended': 'simkl_ids_only'})
                    if status != 200:
                        raise ValueError('Deletion reconciliation failed')
                    present = library_response(data)
                    for kind in TYPES:
                        state['library'][kind] = {key: row for key, row in state['library'][kind].items()
                                                  if key in present[kind]}
            state.update(activity=activities, checked=now, dirty=False)
        if resource:
            path, params, stamp = resource(state.get('activity', {}))
            records = state.setdefault('resources', {})
            key = path + json.dumps(params, sort_keys=True)
            previous = records.get(key, {})
            if previous.get('dirty') or previous.get('stamp') != stamp or 'data' not in previous:
                status, data, _ = request(path, params=params)
                if status != 200 or not isinstance(data, (dict, list)) or (isinstance(data, dict) and data.get('error')):
                    raise ValueError('Resource download failed')
                records[key] = {'stamp': stamp, 'data': data}
            result = records[key]['data']
        else:
            result = state.get('library')
        state.pop('retry_at', None)
        write(db, account, state)
        db.commit()
        return result, True
    except (ValueError, KeyError, TypeError, OSError, sqlite3.Error) as exc:
        db.rollback()
        # Preserve the old snapshot and back off failed menu requests.
        state = read(db, account)
        try:
            if isinstance(exc, sqlite3.Error):
                raise exc
            if time.time() >= state.get('retry_at', 0):
                state['retry_at'] = time.time() + TTL
            write(db, account, state)
            db.commit()
        except sqlite3.Error:
            db.rollback()
        if resource:
            path, params, _ = resource(state.get('activity', {}))
            key = path + json.dumps(params, sort_keys=True)
            return state.get('resources', {}).get(key, {}).get('data'), False
        return state.get('library'), False
    finally:
        db.close()
