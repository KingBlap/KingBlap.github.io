# -*- coding: utf-8 -*-
"""Cross-device sync for C.O.S.M.O.S.

Packs the user's favourites, resume points, search history and
newly-added snapshot into a single JSON "sync bundle" and offers
four transports:

    1. Export to a local file (folder picker).
    2. Upload anonymously to gofile.io, returning a share URL.
    3. Import from a local file.
    4. Import from any HTTP(S) URL — gofile share links are handled
       transparently (API lookup -> direct content URL).

No third-party libraries: gofile.io has a simple public JSON API
reachable via ``urllib``.
"""
import json
import os
import re
import threading
import tempfile
import time
from urllib.parse import urlparse
from urllib.request import urlopen, Request
from urllib.error import HTTPError, URLError

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import favourites as fav_mod
from . import resume as resume_mod
from . import search_history as sh_mod
from . import newly_added as na_mod


ADDON = xbmcaddon.Addon()
ADDON_ID = 'plugin.video.cosmos'
BUNDLE_VERSION = 1
MAX_BUNDLE_BYTES = 10 * 1024 * 1024
MAX_BUNDLE_ITEMS = 5000
USER_AGENT = 'COSMOS-Sync/1.0'
PROFILE_DIR = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/')


# ── Bundle build / apply ─────────────────────────────────────────────────

def _read_json(path, default):
    if not os.path.isfile(path):
        return default
    try:
        with open(path, 'r', encoding='utf-8') as fp:
            return json.load(fp)
    except (ValueError, OSError):
        return default


def build_bundle():
    """Collect all syncable state into a single dict."""
    resume_data = _read_json(resume_mod.RESUME_FILE, {})
    if not isinstance(resume_data, dict):
        resume_data = {}
    resume_data = {
        key: value for key, value in (resume_data or {}).items()
        if isinstance(value, dict) and not resume_mod.is_nineanime(value)
    }
    seen_items = _read_json(na_mod.SEEN_FILE, {})
    if not isinstance(seen_items, dict):
        seen_items = {}
    return {
        '_format': 'cosmos-sync',
        '_version': BUNDLE_VERSION,
        '_exported_at': int(time.time()),
        'favourites': fav_mod.load(),
        'resume': resume_data,
        'search_history': sh_mod.load(),
        'seen_items': seen_items,
    }


def apply_bundle(bundle, strategy='merge'):
    """Apply a bundle to the local profile.

    strategy:
        'merge'    -> combine with local data, prefer newest per key.
        'overwrite'-> replace local data entirely with bundle's values.
    """
    if not isinstance(bundle, dict) or bundle.get('_format') != 'cosmos-sync':
        raise ValueError('Not a C.O.S.M.O.S sync bundle')
    if bundle.get('_version') not in (None, BUNDLE_VERSION):
        raise ValueError('Unsupported C.O.S.M.O.S sync bundle version')

    incoming_fav = bundle.get('favourites') or []
    incoming_resume = bundle.get('resume') or {}
    incoming_hist = bundle.get('search_history') or []
    incoming_seen = bundle.get('seen_items') or {}
    if (not isinstance(incoming_fav, list)
            or not isinstance(incoming_resume, dict)
            or not isinstance(incoming_hist, list)
            or not isinstance(incoming_seen, dict)):
        raise ValueError('Malformed C.O.S.M.O.S sync bundle data')
    if any(len(value) > MAX_BUNDLE_ITEMS for value in
           (incoming_fav, incoming_resume, incoming_hist, incoming_seen)):
        raise ValueError('C.O.S.M.O.S sync bundle contains too many items')

    # Ignore malformed records rather than allowing a downloaded bundle to
    # crash the plugin while it is being merged.
    incoming_fav = [item for item in incoming_fav if isinstance(item, dict)]
    incoming_resume = {
        key: value for key, value in incoming_resume.items()
        if (isinstance(key, str) and isinstance(value, dict)
            and not resume_mod.is_nineanime(value))
    }
    incoming_hist = [item for item in incoming_hist if isinstance(item, dict)]
    incoming_seen = {
        key: value for key, value in incoming_seen.items()
        if isinstance(key, str) and isinstance(value, dict)
    }

    # Favourites
    if strategy == 'overwrite':
        fav_mod.save(incoming_fav)
    else:
        existing = [item for item in (fav_mod.load() or [])
                    if isinstance(item, dict)]
        by_key = {i.get('key'): i for i in existing}
        for it in incoming_fav:
            k = it.get('key')
            if not k:
                continue
            cur = by_key.get(k)
            if not cur or _safe_int(it.get('added')) >= _safe_int(cur.get('added')):
                by_key[k] = it
        merged = list(by_key.values())
        merged.sort(key=lambda i: _safe_int(i.get('added')), reverse=True)
        fav_mod.save(merged)

    # Resume points
    if strategy == 'overwrite':
        _write_json(resume_mod.RESUME_FILE, incoming_resume)
    else:
        existing = _read_json(resume_mod.RESUME_FILE, {})
        if not isinstance(existing, dict):
            existing = {}
        existing = {
            key: value for key, value in existing.items()
            if (isinstance(key, str) and isinstance(value, dict)
                and not resume_mod.is_nineanime(value))
        }
        for k, v in incoming_resume.items():
            cur = existing.get(k)
            if not cur or _safe_int(v.get('ts')) >= _safe_int(cur.get('ts')):
                existing[k] = v
        _write_json(resume_mod.RESUME_FILE, existing)

    # Search history
    if strategy == 'overwrite':
        sh_mod.save(incoming_hist)
    else:
        existing = [item for item in (sh_mod.load() or [])
                    if isinstance(item, dict)]
        by_q = {(i.get('q') or '').lower(): i for i in existing}
        for it in incoming_hist:
            q = (it.get('q') or '').lower()
            if not q:
                continue
            cur = by_q.get(q)
            if not cur or _safe_int(it.get('ts')) >= _safe_int(cur.get('ts')):
                by_q[q] = it
        merged = list(by_q.values())
        merged.sort(key=lambda i: _safe_int(i.get('ts')), reverse=True)
        sh_mod.save(merged)

    # Seen items (newly-added tracker): merge by earliest first_seen
    if strategy == 'overwrite':
        _write_json(na_mod.SEEN_FILE, incoming_seen)
    else:
        existing = _read_json(na_mod.SEEN_FILE, {})
        if not isinstance(existing, dict):
            existing = {}
        existing = {
            key: value for key, value in existing.items()
            if isinstance(key, str) and isinstance(value, dict)
        }
        for k, v in incoming_seen.items():
            cur = existing.get(k)
            if not cur:
                existing[k] = v
            else:
                # keep the earliest first_seen so items don't appear newer on sync
                if _safe_int(v.get('first_seen')) < _safe_int(cur.get('first_seen')):
                    cur['first_seen'] = _safe_int(v.get('first_seen'))
                existing[k] = cur
        _write_json(na_mod.SEEN_FILE, existing)


def _safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default


def _write_json(path, data):
    tmp_path = ''
    try:
        d = os.path.dirname(path)
        if d and not os.path.isdir(d):
            os.makedirs(d)
        fd, tmp_path = tempfile.mkstemp(
            prefix='.cosmos-sync-', suffix='.tmp', dir=d or None)
        os.close(fd)
        with open(tmp_path, 'w', encoding='utf-8') as fp:
            json.dump(data, fp)
        os.replace(tmp_path, path)
    except (OSError, TypeError, ValueError) as e:
        xbmc.log(f'COSMOS sync: write {path} failed: {e}', xbmc.LOGWARNING)
        if tmp_path:
            try:
                os.remove(tmp_path)
            except OSError:
                pass


# ── Local file I/O ───────────────────────────────────────────────────────

def export_to_path(dest_path):
    bundle = build_bundle()
    try:
        with open(dest_path, 'w', encoding='utf-8') as fp:
            json.dump(bundle, fp, indent=2)
        return True, dest_path
    except OSError as e:
        return False, str(e)


def import_from_path(src_path):
    if not os.path.isfile(src_path):
        return False, 'File not found'
    try:
        if os.path.getsize(src_path) > MAX_BUNDLE_BYTES:
            return False, 'Sync bundle is too large'
    except OSError as e:
        return False, f'File error: {e}'
    try:
        with open(src_path, 'r', encoding='utf-8') as fp:
            bundle = json.load(fp)
    except (ValueError, OSError) as e:
        return False, f'Read error: {e}'
    return _apply_and_report(bundle)


def _apply_and_report(bundle):
    strategy = _ask_strategy()
    if strategy is None:
        return False, 'Cancelled'
    try:
        apply_bundle(bundle, strategy=strategy)
    except ValueError as e:
        return False, str(e)
    summary = (f"Favourites: {len(bundle.get('favourites') or [])}, "
               f"Resume: {len(bundle.get('resume') or {})}, "
               f"History: {len(bundle.get('search_history') or [])}")
    return True, summary


def _ask_strategy():
    dlg = xbmcgui.Dialog()
    idx = dlg.select('How should incoming data be applied?',
                     ['Merge (recommended)',
                      'Overwrite local data',
                      'Cancel'])
    if idx == 0:
        return 'merge'
    if idx == 1:
        if not dlg.yesno('C.O.S.M.O.S',
                         'Overwrite ALL local favourites, resume points\n'
                         'and search history with the imported bundle?'):
            return None
        return 'overwrite'
    return None


# ── gofile.io transport ──────────────────────────────────────────────────

_GOFILE_UA = {'User-Agent': USER_AGENT, 'Accept': 'application/json'}


def _http_json(url, data=None, headers=None, timeout=30, method=None):
    hdr = dict(_GOFILE_UA)
    if headers:
        hdr.update(headers)
    req = Request(url, data=data, headers=hdr, method=method)
    with urlopen(req, timeout=timeout) as r:
        body = r.read().decode('utf-8', errors='replace')
    try:
        return json.loads(body)
    except ValueError:
        return {'_raw': body}


def _gofile_server():
    """Fetch the current best upload server from gofile.io."""
    data = _http_json('https://api.gofile.io/servers', timeout=20)
    if data.get('status') != 'ok':
        raise RuntimeError(f'gofile /servers status={data.get("status")}')
    servers = ((data.get('data') or {}).get('servers') or [])
    if not servers:
        raise RuntimeError('gofile returned no servers')
    return servers[0].get('name') or 'store1'


def _multipart_body(field_name, filename, content_bytes,
                    content_type='application/json'):
    """Build a minimal multipart/form-data body. Returns (body, headers)."""
    import uuid
    boundary = f'----CosmosSync{uuid.uuid4().hex}'
    crlf = '\r\n'
    head = (
        f'--{boundary}{crlf}'
        f'Content-Disposition: form-data; name="{field_name}"; '
        f'filename="{filename}"{crlf}'
        f'Content-Type: {content_type}{crlf}{crlf}'
    ).encode('utf-8')
    tail = f'{crlf}--{boundary}--{crlf}'.encode('utf-8')
    body = head + content_bytes + tail
    headers = {
        'Content-Type': f'multipart/form-data; boundary={boundary}',
        'Content-Length': str(len(body)),
    }
    return body, headers


def upload_to_gofile():
    """Upload the current bundle to gofile.io and return a share URL.

    Returns (ok, url_or_error).
    """
    bundle = build_bundle()
    payload = json.dumps(bundle, indent=2).encode('utf-8')
    filename = f'cosmos-sync-{int(time.time())}.json'

    try:
        server = _gofile_server()
    except (HTTPError, URLError, RuntimeError, ValueError) as e:
        return False, f'gofile server lookup failed: {e}'

    body, headers = _multipart_body('file', filename, payload)
    upload_url = f'https://{server}.gofile.io/contents/uploadfile'

    try:
        data = _http_json(upload_url, data=body, headers=headers, timeout=60)
    except (HTTPError, URLError, ValueError) as e:
        return False, f'gofile upload failed: {e}'

    if data.get('status') != 'ok':
        return False, f'gofile status={data.get("status")}'
    download_page = ((data.get('data') or {}).get('downloadPage')
                     or (data.get('data') or {}).get('link') or '')
    if not download_page:
        return False, 'gofile did not return a share URL'
    return True, download_page


_GOFILE_HOST_RE = re.compile(r'^https?://(?:www\.)?gofile\.io/d/([A-Za-z0-9]+)/?',
                             re.IGNORECASE)


def _looks_like_gofile_page(url):
    return bool(_GOFILE_HOST_RE.match(url or ''))


def _gofile_direct_url(share_url):
    """Given a gofile.io/d/<code> URL, return the first file's direct link."""
    m = _GOFILE_HOST_RE.match(share_url or '')
    if not m:
        raise ValueError('Not a gofile share URL')
    code = m.group(1)
    api_url = f'https://api.gofile.io/contents/{code}?wt=4fd6sg89d7s6'
    data = _http_json(api_url, timeout=20)
    if data.get('status') != 'ok':
        raise RuntimeError(f'gofile lookup status={data.get("status")}')
    d = data.get('data') or {}
    children = d.get('children') or {}
    if isinstance(children, dict):
        iterable = children.values()
    else:
        iterable = children
    for child in iterable:
        link = child.get('link') or child.get('directLink')
        if link:
            return link
    raise RuntimeError('gofile share is empty or password-protected')


def download_bundle_from_url(url):
    """Fetch a sync bundle from a direct JSON URL or a gofile share URL."""
    if _looks_like_gofile_page(url):
        url = _gofile_direct_url(url)
    parsed = urlparse(url or '')
    if parsed.scheme not in ('http', 'https') or not parsed.netloc:
        raise ValueError('Bundle URL must be an http(s) URL')
    req = Request(url, headers=_GOFILE_UA)
    with urlopen(req, timeout=45) as r:
        content_length = _safe_int(r.headers.get('Content-Length'))
        if content_length > MAX_BUNDLE_BYTES:
            raise ValueError('Sync bundle is too large')
        chunks = []
        total = 0
        while True:
            chunk = r.read(min(65536, MAX_BUNDLE_BYTES - total + 1))
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_BUNDLE_BYTES:
                raise ValueError('Sync bundle is too large')
            chunks.append(chunk)
        body = b''.join(chunks).decode('utf-8', errors='replace')
    try:
        return json.loads(body)
    except ValueError as e:
        raise ValueError(f'Bundle parse error: {e}')


# ── Auto-upload on every change ──────────────────────────────────────────
#
# When the user opts in (Settings → Sync → "Auto-upload on changes"), any
# mutation to favourites / resume points / search history triggers a
# background upload of the current sync bundle to gofile.io. A minimum
# interval between uploads prevents API abuse when many writes arrive in
# quick succession (e.g. during a resume-tracker sample burst).

_AUTO_MIN_INTERVAL = 60          # seconds between actual uploads
_AUTO_DEBOUNCE = 8               # wait this long after last trigger before upload
_auto_lock = threading.Lock()
_auto_state = {'last_ts': 0, 'pending': False, 'trigger_ts': 0}


def _is_auto_enabled():
    try:
        return (ADDON.getSetting('sync_auto_upload') or 'false').lower() == 'true'
    except Exception:
        return False


def _auto_worker():
    """Debounce + rate-limit loop: waits until the configured debounce
    window has elapsed with no new triggers, then performs one upload
    (honouring the global minimum interval). Runs in a daemon thread."""
    while True:
        with _auto_lock:
            if not _auto_state['pending']:
                return
            trigger_ts = _auto_state['trigger_ts']
            last_ts = _auto_state['last_ts']
        # Debounce: wait for the quiet window
        wait = max(0, (trigger_ts + _AUTO_DEBOUNCE) - time.time())
        if wait > 0:
            time.sleep(wait)
            with _auto_lock:
                # a newer trigger arrived — loop to re-evaluate
                if _auto_state['trigger_ts'] > trigger_ts:
                    continue
        # Respect the global rate limit
        gap = time.time() - last_ts
        if gap < _AUTO_MIN_INTERVAL:
            time.sleep(_AUTO_MIN_INTERVAL - gap)
            with _auto_lock:
                if _auto_state['trigger_ts'] > trigger_ts:
                    continue

        # Do the upload
        ok, info = upload_to_gofile()
        now = int(time.time())
        try:
            if ok:
                ADDON.setSetting('sync_last_url', info)
                ADDON.setSetting('sync_last_ts', str(now))
                xbmc.log(f'COSMOS sync: auto-upload OK -> {info}', xbmc.LOGINFO)
            else:
                xbmc.log(f'COSMOS sync: auto-upload failed: {info}', xbmc.LOGWARNING)
        except Exception:
            pass
        with _auto_lock:
            _auto_state['last_ts'] = time.time()
            # If no new triggers arrived while we were uploading, clear pending
            if _auto_state['trigger_ts'] <= trigger_ts:
                _auto_state['pending'] = False
                return


def maybe_autosync():
    """Register a change event. Cheap: only spawns a worker if the
    setting is enabled, and coalesces rapid-fire calls via a debounce
    window so one upload covers many writes."""
    try:
        if not _is_auto_enabled():
            return
    except Exception:
        return
    with _auto_lock:
        _auto_state['trigger_ts'] = time.time()
        if _auto_state['pending']:
            return
        _auto_state['pending'] = True
    t = threading.Thread(target=_auto_worker, daemon=True)
    t.start()


def auto_upload_now():
    """User-triggered immediate upload (bypasses debounce)."""
    ok, info = upload_to_gofile()
    dlg = xbmcgui.Dialog()
    if ok:
        try:
            ADDON.setSetting('sync_last_url', info)
            ADDON.setSetting('sync_last_ts', str(int(time.time())))
        except Exception:
            pass
        dlg.ok('C.O.S.M.O.S - Auto-Sync',
               'Uploaded to gofile.io:\n\n' + info)
    else:
        dlg.ok('C.O.S.M.O.S', f'Upload failed:\n{info}')


# ── Interactive helpers (called from cosmos.py) ──────────────────────────

def _default_export_path():
    name = f'cosmos-sync-{time.strftime("%Y%m%d-%H%M%S")}.json'
    return os.path.join(PROFILE_DIR, name)


def interactive_export():
    dlg = xbmcgui.Dialog()
    choice = dlg.select('Export C.O.S.M.O.S sync data',
                        ['Save to a file on this device',
                         'Upload to gofile.io (share URL)',
                         'Cancel'])
    if choice == 0:
        folder = dlg.browse(0, 'Pick export folder', 'files',
                            '', False, False, PROFILE_DIR)
        if not folder:
            return
        path = os.path.join(xbmcvfs.translatePath(folder),
                            f'cosmos-sync-{time.strftime("%Y%m%d-%H%M%S")}.json')
        ok, info = export_to_path(path)
        if ok:
            dlg.ok('C.O.S.M.O.S', f'Exported to:\n{info}')
        else:
            dlg.ok('C.O.S.M.O.S', f'Export failed:\n{info}')
    elif choice == 1:
        prog = xbmcgui.DialogProgressBG()
        prog.create('C.O.S.M.O.S Sync', 'Uploading to gofile.io...')
        try:
            ok, info = upload_to_gofile()
        finally:
            try:
                prog.close()
            except Exception:
                pass
        if ok:
            # Copy to the clipboard-ish via input dialog with pre-filled URL
            dlg.ok('C.O.S.M.O.S - Share URL',
                   'Your sync bundle is live on gofile.io.\n\n' + info +
                   '\n\nOpen this URL on another device and use\n'
                   '"Import Sync Data" to restore.')
        else:
            dlg.ok('C.O.S.M.O.S', f'Upload failed:\n{info}')


def interactive_import():
    dlg = xbmcgui.Dialog()
    choice = dlg.select('Import C.O.S.M.O.S sync data',
                        ['Pick a file on this device',
                         'Paste a URL (gofile.io / direct JSON)',
                         'Cancel'])
    if choice == 0:
        path = dlg.browse(1, 'Pick sync file', 'files',
                          '.json', False, False, PROFILE_DIR)
        if not path or not path.lower().endswith('.json'):
            return
        ok, info = import_from_path(xbmcvfs.translatePath(path))
        if ok:
            dlg.ok('C.O.S.M.O.S', f'Imported successfully.\n{info}')
            xbmc.executebuiltin('Container.Refresh')
        else:
            dlg.ok('C.O.S.M.O.S', f'Import failed:\n{info}')
    elif choice == 1:
        kb = xbmc.Keyboard('', 'Paste sync URL')
        kb.doModal()
        if not kb.isConfirmed():
            return
        url = (kb.getText() or '').strip()
        if not url:
            return
        try:
            p = urlparse(url)
            if p.scheme not in ('http', 'https'):
                dlg.ok('C.O.S.M.O.S', 'Please enter a http(s) URL.')
                return
        except ValueError:
            dlg.ok('C.O.S.M.O.S', 'Invalid URL.')
            return

        prog = xbmcgui.DialogProgressBG()
        prog.create('C.O.S.M.O.S Sync', 'Downloading bundle...')
        try:
            bundle = download_bundle_from_url(url)
        except (HTTPError, URLError, ValueError, RuntimeError) as e:
            try:
                prog.close()
            except Exception:
                pass
            dlg.ok('C.O.S.M.O.S', f'Download failed:\n{e}')
            return
        finally:
            try:
                prog.close()
            except Exception:
                pass

        ok, info = _apply_and_report(bundle)
        if ok:
            dlg.ok('C.O.S.M.O.S', f'Imported successfully.\n{info}')
            xbmc.executebuiltin('Container.Refresh')
        else:
            dlg.ok('C.O.S.M.O.S', f'Import failed:\n{info}')
