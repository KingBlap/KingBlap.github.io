# -*- coding: utf-8 -*-
"""Favourites store for C.O.S.M.O.S.

A simple JSON-backed list of movie / TV-show items the user starred from
the browse, search or episode views. Re-opening a favourite reconstructs
the normal item view (show_links for movies, tv_seasons for shows).
"""
import json
import os
import time

import xbmc
import xbmcvfs


PROFILE_DIR = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/')
FAV_FILE = os.path.join(PROFILE_DIR, 'favourites.json')


def _ensure():
    if not os.path.isdir(PROFILE_DIR):
        try:
            os.makedirs(PROFILE_DIR)
        except OSError:
            pass


def _key(tmdb, content, name=''):
    if tmdb:
        return f'tmdb:{content or "movie"}:{tmdb}'
    # Fallback for items without tmdb
    return f'name:{content or "movie"}:{(name or "").strip().lower()}'


def load():
    _ensure()
    if not os.path.isfile(FAV_FILE):
        return []
    try:
        with open(FAV_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp)
        if not isinstance(data, list):
            return []
        return [item for item in data if isinstance(item, dict)]
    except (ValueError, OSError):
        return []


def save(items):
    _ensure()
    try:
        with open(FAV_FILE, 'w', encoding='utf-8') as fp:
            json.dump(items, fp, indent=2)
    except OSError as e:
        xbmc.log(f'COSMOS favourites: save failed: {e}', xbmc.LOGWARNING)
    try:
        # Lazy import avoids circular dependency (sync imports favourites).
        from . import sync as _sync
        _sync.maybe_autosync()
    except Exception:
        pass


def is_favourite(tmdb, content, name=''):
    k = _key(tmdb, content, name)
    return any(i.get('key') == k for i in load())


def add(entry):
    """Add a favourite. entry must contain tmdb, content, name and payload
    (the JSON-string payload that will be passed to show_links / tv_seasons)."""
    if not isinstance(entry, dict):
        return False
    items = load()
    k = _key(entry.get('tmdb'), entry.get('content'), entry.get('name'))
    items = [i for i in items if i.get('key') != k]
    entry = dict(entry)
    entry['key'] = k
    entry['added'] = int(time.time())
    items.insert(0, entry)
    save(items)
    return True


def remove(tmdb, content, name=''):
    k = _key(tmdb, content, name)
    items = load()
    new = [i for i in items if i.get('key') != k]
    if len(new) == len(items):
        return False
    save(new)
    return True
