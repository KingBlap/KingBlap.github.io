"""
C.O.S.M.O.S — Full-screen debrid authorisation dialogs
Author: Zeus768
"""
import os
import time
import xbmc
import xbmcgui
import xbmcvfs

ADDON_ID   = 'plugin.video.cosmos'
ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/')
MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')

# ── Control IDs — AuthDialog (device-code flow) ────────────────────────────
ID_QR     = 100
ID_ICON   = 101
ID_TITLE  = 200
ID_URL    = 202
ID_STEP2  = 203
ID_CODE   = 204
ID_TIMER  = 205
ID_CANCEL = 9001

# ── Control IDs — CredentialsDialog (username / password flow) ─────────────
CD_ICON     = 101
CD_TITLE    = 200
CD_USERNAME = 301
CD_PASSWORD = 302
CD_OK       = 300
CD_CANCEL   = 9001


class AuthDialog(xbmcgui.WindowXMLDialog):
    """Full-screen device-code authorisation window."""

    def __init__(self, *args, **kwargs):
        self.service_name      = kwargs.pop('service_name',      'Authorization')
        self.step2_label       = kwargs.pop(
            'step2_label',
            f'Step 2  —  Enter this code into {self.service_name}:',
        )
        self.user_code         = kwargs.pop('user_code',         '')
        self.verification_url  = kwargs.pop('verification_url',  '')
        self.verification_label = kwargs.pop('verification_label', '')
        self.expires_in        = int(kwargs.pop('expires_in',    600))
        self.icon_path         = kwargs.pop('icon_path',         '')
        self.qr_path           = kwargs.pop('qr_path',           '')
        self.canceled          = False
        self.authorized        = False
        self._start            = time.time()
        super().__init__(*args, **kwargs)

    def onInit(self):
        # Each control is wrapped independently so one failure can't block others
        try:
            if self.qr_path and os.path.exists(self.qr_path):
                self.getControl(ID_QR).setImage(self.qr_path)
        except Exception as e:
            xbmc.log(f'AuthDialog QR error: {e}', xbmc.LOGERROR)

        try:
            if self.icon_path and os.path.exists(self.icon_path):
                self.getControl(ID_ICON).setImage(self.icon_path)
        except Exception as e:
            xbmc.log(f'AuthDialog icon error: {e}', xbmc.LOGERROR)

        try:
            self.getControl(ID_TITLE).setLabel(
                f'[B]{self.service_name} Authorization[/B]')
        except Exception as e:
            xbmc.log(f'AuthDialog title error: {e}', xbmc.LOGERROR)

        try:
            url_text = self.verification_label or self.verification_url
            self.getControl(ID_URL).setLabel(
                f'[COLOR FF56D4F5]{url_text}[/COLOR]')
        except Exception as e:
            xbmc.log(f'AuthDialog URL error: {e}', xbmc.LOGERROR)

        try:
            self.getControl(ID_STEP2).setLabel(self.step2_label)
        except Exception as e:
            xbmc.log(f'AuthDialog step label error: {e}', xbmc.LOGERROR)

        try:
            self.getControl(ID_CODE).setLabel(
                f'[COLOR FFFFCC00]{self.user_code}[/COLOR]')
        except Exception as e:
            xbmc.log(f'AuthDialog code error: {e}', xbmc.LOGERROR)

        try:
            remaining = max(0, self.expires_in - int(time.time() - self._start))
            self.getControl(ID_TIMER).setLabel(f'Expires in: {remaining}s')
        except Exception as e:
            xbmc.log(f'AuthDialog timer error: {e}', xbmc.LOGERROR)

    def update_remaining(self, remaining):
        try:
            self.getControl(ID_TIMER).setLabel(f'Expires in: {int(remaining)}s')
        except Exception:
            pass

    def mark_authorized(self):
        self.authorized = True
        self.close()

    def mark_denied(self):
        self.canceled = True
        self.close()

    def onAction(self, action):
        if action.getId() in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
            xbmcgui.ACTION_STOP,
        ):
            self.canceled = True
            self.close()

    def onClick(self, controlId):
        if controlId == ID_CANCEL:
            self.canceled = True
            self.close()


class CredentialsDialog(xbmcgui.WindowXMLDialog):
    """Full-screen username / password entry dialog (LinkSnappy)."""

    def __init__(self, *args, **kwargs):
        self.service_name = kwargs.pop('service_name', 'Authorization')
        self.icon_path    = kwargs.pop('icon_path',    '')
        self.username     = ''
        self.password     = ''
        self.confirmed    = False
        super().__init__(*args, **kwargs)

    def onInit(self):
        try:
            if self.icon_path and os.path.exists(self.icon_path):
                self.getControl(CD_ICON).setImage(self.icon_path)
        except Exception as e:
            xbmc.log(f'CredentialsDialog icon error: {e}', xbmc.LOGERROR)

        try:
            self.getControl(CD_TITLE).setLabel(
                f'[B]{self.service_name} Authorization[/B]')
        except Exception as e:
            xbmc.log(f'CredentialsDialog title error: {e}', xbmc.LOGERROR)

    def onClick(self, controlId):
        if controlId == CD_OK:
            try:
                self.username  = self.getControl(CD_USERNAME).getText()
                self.password  = self.getControl(CD_PASSWORD).getText()
                self.confirmed = True
                self.close()
            except Exception as e:
                xbmc.log(f'CredentialsDialog OK error: {e}', xbmc.LOGERROR)
        elif controlId == CD_CANCEL:
            self.close()

    def onAction(self, action):
        if action.getId() in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
        ):
            self.close()


# ── Control IDs — AIOStreamsDialog ──────────────────────────────────────────
AIO_ICON     = 101
AIO_TITLE    = 200
AIO_URL      = 301
AIO_USERNAME = 302
AIO_PASSWORD = 303
AIO_OK       = 300
AIO_CANCEL   = 9001


class AIOStreamsDialog(xbmcgui.WindowXMLDialog):
    """Full-screen AIO Streams setup dialog (Server URL + username + password)."""

    def __init__(self, *args, **kwargs):
        self.service_name = kwargs.pop('service_name', 'AIO Streams')
        self.icon_path    = kwargs.pop('icon_path',    '')
        self.initial_url  = kwargs.pop('initial_url',  '')
        self.url          = ''
        self.username     = ''
        self.password     = ''
        self.confirmed    = False
        super().__init__(*args, **kwargs)

    def onInit(self):
        try:
            if self.icon_path and os.path.exists(self.icon_path):
                self.getControl(AIO_ICON).setImage(self.icon_path)
        except Exception as e:
            xbmc.log(f'AIOStreamsDialog icon error: {e}', xbmc.LOGERROR)

        try:
            self.getControl(AIO_TITLE).setLabel(
                f'[B]{self.service_name} Setup[/B]')
        except Exception as e:
            xbmc.log(f'AIOStreamsDialog title error: {e}', xbmc.LOGERROR)

        try:
            if self.initial_url:
                self.getControl(AIO_URL).setText(self.initial_url)
        except Exception as e:
            xbmc.log(f'AIOStreamsDialog URL preset error: {e}', xbmc.LOGERROR)

    def onClick(self, controlId):
        if controlId == AIO_OK:
            try:
                self.url      = self.getControl(AIO_URL).getText().strip().rstrip('/')
                self.username = self.getControl(AIO_USERNAME).getText()
                self.password = self.getControl(AIO_PASSWORD).getText()
                self.confirmed = True
                self.close()
            except Exception as e:
                xbmc.log(f'AIOStreamsDialog OK error: {e}', xbmc.LOGERROR)
        elif controlId == AIO_CANCEL:
            self.close()

    def onAction(self, action):
        if action.getId() in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
        ):
            self.close()
