"""User-driven Simkl catalog browsing; no background polling or row hydration."""
import hashlib
import json
import time
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcplugin

from . import simkl as api
from . import simkl_store as store
from . import tmdb as tmdb_mod

KINDS = {'movie': 'Movies', 'tv': 'TV Shows', 'anime': 'Anime'}
FILTERS = {'all': 'All-time Top Rated', 'year': 'Top Rated This Year',
           'month': 'Top Rated This Month', 'voted': 'Most Voted',
           'watched': 'Most Watched This Month'}
STATUSES = (('Plan to Watch', 'plantowatch'), ('Watching', 'watching'),
            ('On Hold', 'hold'), ('Dropped', 'dropped'), ('Completed', 'completed'))


def context_items(meta, kind):
    """Build actions entirely from the catalog row; never read user state here."""
    payload = json.dumps(meta)
    items = [('View on Simkl', 'RunPlugin(%s)' % api._build_url(
        action='simkl_catalog_link', kind=kind, payload=payload))]
    if api.has_token():
        for operation, label in (
                ('watched', 'Mark as Watched on Simkl'),
                ('plan', 'Add to Simkl Plan to Watch'),
                ('status', 'Change Simkl Status...'),
                ('rate', 'Rate on Simkl...'),
                ('unrate', 'Remove Simkl Rating')):
            items.append((label, 'RunPlugin(%s)' % api._build_url(
                action='simkl_catalog_write', kind=kind, operation=operation,
                payload=payload)))
    return items


def write_action(params):
    """One explicit action, one ID-based write; no lookup or follow-up sync.

    Contract: /guides/sync and /api-reference/simkl/add-to-history.
    Anime remains in the anime catalog even when its subtype is a movie.
    """
    kind, operation = params.get('kind'), params.get('operation')
    if kind not in KINDS or operation not in ('watched', 'plan', 'status', 'rate', 'unrate'):
        raise ValueError('Invalid Simkl action')
    meta = json.loads(params.get('payload', '{}'))
    if not isinstance(meta, dict) or not isinstance(meta.get('ids'), dict):
        raise ValueError('Invalid Simkl item')
    sid = meta['ids'].get('simkl') or meta['ids'].get('simkl_id')
    if not str(sid or '').isdigit() or int(sid) <= 0:
        raise ValueError('Missing Simkl ID')
    # Normalize response-only simkl_id; never send slug or catalog metadata.
    item = {'ids': {'simkl': int(sid)}}
    section = {'movie': 'movies', 'tv': 'shows', 'anime': 'anime'}[kind]
    dialog = xbmcgui.Dialog()
    title = api._item_title(meta)
    movie = kind == 'movie' or (kind == 'anime' and meta.get('anime_type') == 'movie')
    endpoint = '/sync/history'
    message = 'Updated on Simkl'
    if operation == 'watched':
        if movie:
            item['status'] = 'completed'
        else:
            choice = dialog.select('Mark as Watched on Simkl',
                                   ['Mark entire title as watched', 'Mark a specific episode'])
            if choice < 0:
                return
            if choice == 0:
                item['status'] = 'completed'
            else:
                if kind == 'tv':
                    season_text = dialog.numeric(0, title + ' — Season number')
                    if not season_text:
                        return
                    season = int(season_text)
                    if season < 0:
                        raise ValueError('Invalid season')
                episode_text = dialog.numeric(0, title + ' — Episode number')
                if not episode_text:
                    return
                episode = int(episode_text)
                if episode < 1:
                    raise ValueError('Invalid episode')
                if kind == 'anime':
                    # Simkl anime uses absolute episode numbers, no TV seasons.
                    item['episodes'] = [{'number': episode}]
                else:
                    item['seasons'] = [{'number': season, 'episodes': [{'number': episode}]}]
        item['watched_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        message = 'Watch recorded on Simkl'
    elif operation in ('plan', 'status'):
        endpoint = '/sync/add-to-list'
        if operation == 'plan':
            item['to'] = 'plantowatch'
        else:
            choice = dialog.select('Change Simkl Status', [label for label, _ in STATUSES])
            if choice < 0:
                return
            item['to'] = STATUSES[choice][1]
        message = 'Simkl status updated'
    elif operation == 'rate':
        endpoint = '/sync/ratings'
        text = dialog.numeric(0, title + ' — Simkl rating (1-10)')
        if not text:
            return
        rating = int(text)
        if not 1 <= rating <= 10:
            raise ValueError('Rating must be from 1 to 10')
        item['rating'] = rating
        message = 'Rating saved on Simkl'
    else:
        endpoint = '/sync/ratings/remove'
        # The removal contract folds anime into shows[].
        section = 'movies' if kind == 'movie' else 'shows'
        message = 'Simkl rating removed'

    headers = api._auth_headers()
    if not headers:
        dialog.notification('Simkl', 'Sign in to Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    # Prevent overlapping context writes from separate Kodi plugin invocations.
    # The HTTP client supplies shared throttling, bounded retries and cooldowns.
    db = store.connect(api.DATA_PATH, 'simkl_catalog_actions.db')
    try:
        db.execute('PRAGMA busy_timeout=2000')
        db.execute('BEGIN IMMEDIATE')
        status, data, _ = api._http_json(endpoint, method='POST',
                                       payload={section: [item]}, headers=headers)
    finally:
        db.close()
    data = data if isinstance(data, dict) else {}
    not_found = data.get('not_found') or {}
    result = data.get('deleted' if operation == 'unrate' else 'added')
    unmatched = isinstance(not_found, dict) and any(not_found.values())
    if status not in (200, 201) or unmatched or not isinstance(result, dict):
        message = ('Simkl could not match this item' if unmatched else
                   api._LAST_API_ERROR or 'Simkl did not confirm this update')
        dialog.notification('Simkl', message, xbmcgui.NOTIFICATION_ERROR, 4000)
        return
    # Count-zero history responses are valid idempotent no-ops, not retries.
    statuses = result.get('statuses') or []
    if isinstance(statuses, list) and statuses and isinstance(statuses[0], dict):
        resolved = (statuses[0].get('response') or {}).get('status')
        if resolved:
            label = dict((value, label) for label, value in STATUSES).get(resolved, resolved)
            message += ' — ' + label
    dialog.notification('Simkl', message, xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin('Container.Refresh')


def cached(path, params=None, ttl=3600, cdn=False):
    """Cache catalog results; serialize misses across Kodi invocations.

    Failed refreshes retain the last good result and defer retries for 15 min.
    Bound stored queries so typed searches cannot grow the cache indefinitely.
    AUTH V2 searches require a bearer token and an account-specific cache;
    CDN and cached detail endpoints must remain anonymous.
    """
    url = api._build_api_url(path, params)
    if cdn:
        url = url.replace(api.API_BASE, 'https://data.simkl.in', 1)
    authenticated = not cdn and path.startswith('/search/')
    # Version the search key to bypass failures cached by the old anonymous
    # implementation. Never include access tokens in cache keys or records.
    cache_key = ('search-auth-v2:' + api._account_cache_key() + ':' + url
                 if authenticated else url)
    key = hashlib.sha256(cache_key.encode('utf-8')).hexdigest()
    db = store.connect(api.DATA_PATH, 'simkl_catalog.db')
    db.execute('PRAGMA busy_timeout=30000')
    try:
        db.execute('BEGIN IMMEDIATE')
        record = store.read(db, key)
        now = time.time()
        if now < record.get('retry_at', 0) or now - record.get('at', 0) < ttl:
            api._LAST_API_ERROR = record.get('error') or ''
            return record.get('data'), record.get('headers', {})
        if cdn:
            # Public CDN requests never carry a bearer token.
            headers = {'User-Agent': api.UA}
            if record.get('modified'):
                headers['If-Modified-Since'] = record['modified']
            try:
                with urlopen(Request(url, headers=headers), timeout=20) as response:
                    data = json.load(response)
                    status, response_headers = response.status, dict(response.headers.items())
            except Exception as exc:
                status = getattr(exc, 'code', 0)
                data, response_headers = None, {}
        else:
            headers = api._auth_headers() if authenticated else None
            if authenticated and not headers:
                # Refresh failed or no token exists: do not send an anonymous
                # request or convert it into another misleading API 401.
                api._LAST_API_ERROR = 'Simkl search could not obtain an access token; check your connection or account'
                status, data, response_headers = 401, None, {}
            else:
                status, data, response_headers = api._http_json(path, params=params, headers=headers)
        if status == 304 and 'data' in record:
            record['at'] = now
            record.pop('retry_at', None)
        elif status == 200 and (isinstance(data, (list, dict)) or data is None):
            record = {'at': now, 'data': data, 'headers': response_headers,
                      'modified': next((v for k, v in response_headers.items()
                                        if k.lower() == 'last-modified'), '')}
        else:
            record['retry_at'] = now + 900
            record['error'] = (api._LAST_API_ERROR if not cdn else '') or 'Simkl catalog unavailable; try again later'
        store.write(db, key, record)
        db.execute('DELETE FROM state WHERE key IN (SELECT key FROM state '
                   'ORDER BY rowid DESC LIMIT -1 OFFSET 200)')
        db.commit()
        return record.get('data'), record.get('headers', {})
    finally:
        db.close()


def finish():
    xbmcplugin.endOfDirectory(api._handle(), cacheToDisc=False)


def rows(data, kind, page=1, local=False, route=None):
    items = data if isinstance(data, list) else []
    if local:
        items = items[(page - 1) * 20:page * 20]
    for item in items:
        if not isinstance(item, dict):
            continue
        meta = api._get_item_meta(item)
        ids = meta.get('ids') or {}
        sid = ids.get('simkl') or ids.get('simkl_id')
        if not str(sid or '').isdigit():
            continue
        title, year = api._item_title(item), api._item_year(item)
        poster = meta.get('poster') or ''
        if poster and not poster.startswith('https://'):
            poster = 'https://simkl.in/posters/%s_m.jpg' % poster
        payload = json.dumps(meta)
        context = context_items(meta, kind)
        movie = kind == 'movie' or (kind == 'anime' and
                                    (meta.get('anime_type') == 'movie' or meta.get('type') == 'movie'))
        api._add_simkl_item(title + (' (%s)' % year if year else ''),
            api._build_url(action='simkl_catalog_item', kind=kind, payload=payload),
            is_folder=not movie, is_playable=movie,
            title=title, year=year, poster=poster, plot=api._item_plot(item),
            content='movie' if movie else 'tvshow',
            context_items=context)
    if not items:
        api._row(api._LAST_API_ERROR or 'No Simkl results available',
                 api._build_url(action='simkl_root'))
    if local and isinstance(data, list) and page * 20 < len(data):
        api._row('Next Page', api._build_url(page=page + 1, **route), is_folder=True)


def search(params):
    kind = params.get('kind', '')
    if kind not in KINDS:
        for key, label in KINDS.items():
            api._row('Search Simkl ' + label, api._build_url(action='simkl_search', kind=key), True)
        finish()
        return
    query = ' '.join(params.get('q', '').split())
    if not query:
        query = ' '.join(xbmcgui.Dialog().input('Search Simkl ' + KINDS[kind]).split())
    if not query:
        finish()
        return
    page = max(1, min(20, int(params.get('page', 1))))
    data, headers = cached('/search/' + kind,
                           {'q': query, 'page': page, 'limit': 20, 'extended': 'full'})
    rows(data, kind)
    count = next((v for k, v in headers.items() if k.lower() == 'x-pagination-page-count'), None)
    if page < 20 and ((count is not None and page < int(count)) or
                      (count is None and isinstance(data, list) and len(data) == 20)):
        api._row('Next Page', api._build_url(action='simkl_search', kind=kind,
                                            q=query, page=page + 1), True)
    finish()


def discover(params):
    kind, bucket = params.get('kind', ''), params.get('bucket', '')
    if kind not in KINDS:
        for key, label in KINDS.items():
            api._row('Discover ' + label + ' on Simkl',
                     api._build_url(action='simkl_discover', kind=key), True)
    elif not bucket:
        for period, label in [('today', 'Today'), ('week', 'This Week'), ('month', 'This Month')]:
            api._row('Simkl Trending ' + label, api._build_url(
                action='simkl_discover', kind=kind, bucket='trending:' + period), True)
        if kind != 'movie':
            for key, label in FILTERS.items():
                api._row(label + ' on Simkl', api._build_url(
                    action='simkl_discover', kind=kind, bucket='best:' + key), True)
    else:
        family, _, value = bucket.partition(':')
        if family == 'trending' and value in ('today', 'week', 'month'):
            section = 'movies' if kind == 'movie' else kind
            data, _ = cached('/discover/trending/%s/%s_100.json' % (section, value),
                             ttl=3600 if value == 'today' else 86400, cdn=True)
        elif family == 'best' and kind != 'movie' and value in FILTERS:
            data, _ = cached('/%s/best/%s' % (kind, value), ttl=21600)
        else:
            finish()
            return
        rows(data, kind, max(1, int(params.get('page', 1))), local=True,
             route={'action': 'simkl_discover', 'kind': kind, 'bucket': bucket})
    finish()


def _calendar_tmdb(kind, tmdb_id, season=None):
    """Cache TMDB show/season metadata across Kodi menu invocations."""
    if not str(tmdb_id or '').isdigit():
        return {} if kind == 'show' else []
    if kind == 'season' and (not isinstance(season, int) or season < 0):
        return []
    key = '%s:%s:%s' % (kind, tmdb_id, season if season is not None else '')
    db = store.connect(api.DATA_PATH, 'simkl_calendar_tmdb.db')
    try:
        record = store.read(db, key)
    finally:
        db.close()
    if time.time() - record.get('at', 0) < record.get('ttl', 0):
        return record.get('data') or ({} if kind == 'show' else [])
    data = (tmdb_mod.get_metadata(tmdb_id, 'tvshow') if kind == 'show'
            else tmdb_mod.get_tv_episodes(tmdb_id, season))
    if not isinstance(data, dict if kind == 'show' else list):
        data = {} if kind == 'show' else []
    db = store.connect(api.DATA_PATH, 'simkl_calendar_tmdb.db')
    try:
        store.write(db, key, {'at': time.time(),
                              'ttl': 24 * 3600 if data else 3600, 'data': data})
        db.commit()
    finally:
        db.close()
    return data


def calendar(params):
    """Browse Simkl's v2 rolling calendar from one cached CDN file per type."""
    kind = params.get('kind', '')
    if kind not in KINDS:
        for key, label in KINDS.items():
            api._row(label, api._build_url(action='simkl_calendar', kind=key), True)
        finish()
        return

    try:
        page = max(1, min(100, int(params.get('page', 1))))
    except (TypeError, ValueError):
        page = 1
    filename = {'movie': 'movie_release', 'tv': 'tv', 'anime': 'anime'}[kind]
    data, _ = cached('/calendar/v2/%s.json' % filename, ttl=5 * 3600, cdn=True)
    schedule = data.get('calendar') if isinstance(data, dict) else None
    metadata = data.get('metadata') if isinstance(data, dict) else None
    if not isinstance(schedule, list) or not isinstance(metadata, dict):
        api._row('Simkl calendar unavailable; try again later',
                 api._build_url(action='simkl_calendar'))
        finish()
        return

    now = datetime.now(timezone.utc)
    upcoming = []
    for entry in schedule:
        if not isinstance(entry, dict):
            continue
        try:
            airing = datetime.fromisoformat(str(entry['date']).replace('Z', '+00:00'))
        except (KeyError, TypeError, ValueError):
            continue
        if airing < now:
            continue
        meta = metadata.get(str(entry.get('simkl_id')))
        if not isinstance(meta, dict) or not isinstance(meta.get('ids'), dict):
            continue
        upcoming.append((airing, entry, meta))
    upcoming.sort(key=lambda row: row[0])
    page_size = 10 if kind in ('tv', 'anime') else 30
    page_items = upcoming[(page - 1) * page_size:page * page_size]
    # TVDB/TMDB seasons do not necessarily match Simkl's flat anime episode
    # numbers. Fetch each anime title's native episode list once instead of
    # looking up a possibly shared TMDB parent series.
    lookup_keys = set()
    for _airing, entry, meta in page_items:
        tmdb_id = str((meta.get('ids') or {}).get('tmdb') or '')
        episode = entry.get('episode')
        sid = (meta.get('ids') or {}).get('simkl_id') or entry.get('simkl_id')
        if kind == 'anime' and isinstance(episode, dict) and str(sid or '').isdigit():
            lookup_keys.add(('anime', str(sid), None))
        elif kind == 'tv' and tmdb_id and isinstance(episode, dict):
            season = episode.get('season')
            if isinstance(season, int) and season >= 0:
                lookup_keys.add(('season', tmdb_id, season))
    detail_rows = {}
    if lookup_keys:
        def lookup(key):
            if key[0] == 'anime':
                data, _ = cached('/anime/episodes/%s' % key[1], ttl=24 * 3600)
                return data if isinstance(data, list) else []
            return _calendar_tmdb(*key)

        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = {key: pool.submit(lookup, key) for key in lookup_keys}
            for key, future in futures.items():
                try:
                    detail_rows[key] = future.result()
                except (OSError, ValueError, TypeError, store.sqlite3.Error):
                    detail_rows[key] = []
    for airing, entry, meta in page_items:
        title = api._item_title(meta)
        ids = meta.get('ids') or {}
        tmdb_id = str(ids.get('tmdb') or '')
        episode = entry.get('episode')
        season = episode.get('season') if isinstance(episode, dict) else None
        number = episode.get('episode') if isinstance(episode, dict) else None
        episode_meta = {}
        if kind == 'anime' and isinstance(number, int):
            sid = ids.get('simkl_id') or entry.get('simkl_id')
            episodes = detail_rows.get(('anime', str(sid), None)) or []
            episode_meta = next((row for row in episodes if isinstance(row, dict)
                                 and row.get('episode') == number), {})
        elif kind == 'tv' and tmdb_id and isinstance(season, int) and isinstance(number, int):
            episodes = detail_rows.get(('season', tmdb_id, season)) or []
            episode_meta = next((row for row in episodes
                                 if row.get('number') == number), {})
        local_time = airing.astimezone().strftime('%a %d %b, %H:%M')
        label = '%s  ·  %s' % (local_time, title)
        if isinstance(episode, dict):
            if isinstance(number, int) and number > 0:
                label += '  ·  ' + ('S%02dE%02d' % (season, number)
                                     if isinstance(season, int) else 'Episode %d' % number)
            episode_title = (episode_meta.get('title') if kind == 'anime' else
                             episode_meta.get('name')) or episode.get('title')
            if episode_title:
                label += '  ·  ' + str(episode_title)
        poster = episode_meta.get('poster') or meta.get('poster') or ''
        if poster and not str(poster).startswith('https://'):
            poster = 'https://simkl.in/posters/%s_m.jpg' % poster
        fanart = episode_meta.get('still') or ''
        if kind == 'anime' and str(episode_meta.get('img') or '').startswith('https://'):
            fanart = episode_meta['img']
        plot = (episode_meta.get('description') if kind == 'anime' else
                episode_meta.get('overview')) or ''
        api._add_simkl_item(label,
            api._build_url(action='simkl_catalog_item', kind=kind,
                           payload=json.dumps(meta)),
            is_folder=kind != 'movie' and meta.get('anime_type') != 'movie',
            is_playable=kind == 'movie' or meta.get('anime_type') == 'movie',
            title=title, year=api._item_year(meta), poster=poster,
            fanart=fanart, plot=plot,
            content='episode' if isinstance(episode, dict) else 'movie',
            season=season, episode=number,
            episode_title=(episode_meta.get('title') if kind == 'anime' else
                           episode_meta.get('name')) or (episode.get('title') if isinstance(episode, dict) else ''),
            context_items=[('View on Simkl', 'RunPlugin(%s)' % api._build_url(
                action='simkl_catalog_link', kind=kind, payload=json.dumps(meta)))])
    if page > 1:
        api._row('Previous Page', api._build_url(
            action='simkl_calendar', kind=kind, page=page - 1), True)
    if page * page_size < len(upcoming) and page < 100:
        api._row('Next Page', api._build_url(
            action='simkl_calendar', kind=kind, page=page + 1), True)
    if not page_items:
        api._row('No upcoming releases found',
                 api._build_url(action='simkl_calendar', kind=kind))
    finish()


def selected(params, link=False):
    kind = params.get('kind')
    if kind not in KINDS:
        finish()
        return
    item = json.loads(params.get('payload', '{}'))
    ids = item.get('ids') or {}
    sid = ids.get('simkl') or ids.get('simkl_id')
    if not str(sid or '').isdigit():
        finish()
        return
    section = 'movies' if kind == 'movie' else kind
    if link:
        url = 'https://simkl.com/%s/%s/%s' % (section, sid, quote(str(ids.get('slug') or ''), safe=''))
        xbmcgui.Dialog().textviewer('View on Simkl', url)
        return
    # Only fetch a selected title if its browse response lacks usable IDs.
    if not ids.get('tmdb'):
        detail, _ = cached('/%s/%s' % (section, sid), {'extended': 'full'}, ttl=86400)
        if isinstance(detail, dict) and not detail.get('error'):
            item = dict(item, **detail)
            ids = item.get('ids') or {}
    from . import cosmos
    movie = kind == 'movie' or (kind == 'anime' and
                                (item.get('type') == 'movie' or item.get('anime_type') == 'movie'))
    poster, fanart = api._item_art(item, content='movie' if movie else kind)
    payload = {'title': api._item_title(item), 'year': api._item_year(item),
               'tmdb': str(ids.get('tmdb') or ''), 'imdb': str(ids.get('imdb') or ''),
               'content': 'movie' if movie else 'tvshow',
               'poster': poster, 'fanart': fanart}
    if movie:
        cosmos._link_zero(json.dumps(payload))
    elif ids.get('tmdb'):
        cosmos._tmdb_tv_seasons(payload['tmdb'], name=payload['title'],
                               year=payload['year'], imdb=payload['imdb'],
                               poster=poster, fanart=fanart)
    else:
        api._row('No episode mapping available for this Simkl title',
                 api._build_url(action='simkl_root'))
        finish()


def dispatch(action, params):
    is_write = action == 'simkl_catalog_write'
    if not api.has_token():
        if is_write:
            xbmcgui.Dialog().notification('Simkl', 'Sign in to Simkl first',
                                          xbmcgui.NOTIFICATION_WARNING, 3000)
            return
        api._row('Sign in to Simkl to search and discover', api._build_url(action='simkl_auth'))
        finish()
        return
    try:
        if is_write:
            write_action(params)
        elif action == 'simkl_search':
            search(params)
        elif action == 'simkl_discover':
            discover(params)
        elif action == 'simkl_calendar':
            calendar(params)
        else:
            selected(params, link=action == 'simkl_catalog_link')
    except (ValueError, TypeError, OSError, store.sqlite3.Error) as exc:
        api._log('Catalog unavailable: %s' % type(exc).__name__)
        if is_write:
            xbmcgui.Dialog().notification('Simkl',
                'Invalid item or Simkl busy; try again later', xbmcgui.NOTIFICATION_ERROR, 3500)
            return
        api._row('Simkl catalog unavailable; try again later', api._build_url(action='simkl_root'))
        finish()
