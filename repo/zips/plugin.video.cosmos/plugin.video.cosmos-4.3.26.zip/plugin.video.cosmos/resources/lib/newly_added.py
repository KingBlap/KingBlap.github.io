# -*- coding: utf-8 -*-
"""Newly-added tracker for C.O.S.M.O.S.

Scans enigma XML feeds once per hour while Kodi is running,
records the first time each content / tv-show item has ever been seen, and
exposes a "Newly Added" menu row that lists items whose ``first_seen``
timestamp is <= 7 days old.

New-item toast notification fires once per batch of new arrivals; it will
not repeat on subsequent opens until the next fresh batch is discovered.
The toast can be disabled in Settings -> General.

Storage is two JSON files in the addon profile directory:
  seen_items.json   -- the full item registry (keyed by stable logical id)
  na_state.json     -- scan timestamp + toast state
"""
import json
import os
import time
import uuid

import xbmc
import xbmcvfs


PROFILE_DIR = xbmcvfs.translatePath(
    'special://profile/addon_data/plugin.video.cosmos/'
)
SEEN_FILE = os.path.join(PROFILE_DIR, 'seen_items.json')
STATE_FILE = os.path.join(PROFILE_DIR, 'na_state.json')
SCAN_LOCK_FILE = os.path.join(PROFILE_DIR, 'na_scan.lock')
METADATA_FILE = os.path.join(PROFILE_DIR, 'na_metadata.json')

WINDOW_SECONDS = 7 * 24 * 3600
SCAN_INTERVAL = 3600  # 1 hour between XML scans
SCAN_VERSION = 5


# -- Internal helpers --------------------------------------------------------

def _ensure():
    if not os.path.isdir(PROFILE_DIR):
        try:
            os.makedirs(PROFILE_DIR)
        except OSError:
            pass


def _identity_number(value):
    value = str(value if value is not None else '').strip()
    return str(int(value)) if value.isdigit() else value


def _identity_content(item):
    content = str(item.get('content') or 'movie').strip().lower()
    if content in ('tv', 'series', 'show', 'tvshow'):
        return ('episode' if item.get('season') not in (None, '')
                and item.get('episode') not in (None, '') else 'tvshow')
    return content


def _key(item):
    """Match by TMDB ID; episodes also require season and episode numbers."""
    tmdb = str(item.get('tmdb') or '').strip()
    tmdb = _identity_number(tmdb)
    content = _identity_content(item)
    name = (item.get('name') or '').strip().lower()
    if content == 'episode':
        season = _identity_number(item.get('season'))
        episode = _identity_number(item.get('episode'))
        if tmdb and season and episode:
            return f'tmdb:episode:{tmdb}:{season}:{episode}'
        return f'name:{content}:{tmdb}:{name}'
    if tmdb:
        return f'tmdb:{content}:{tmdb}'
    return f'name:{content}:{name}'


def _load():
    _ensure()
    if not os.path.isfile(SEEN_FILE):
        return {}
    try:
        with open(SEEN_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp) or {}
        return data if isinstance(data, dict) else {}
    except (ValueError, OSError):
        return {}


def _save(data):
    _ensure()
    temporary = SEEN_FILE + '.' + uuid.uuid4().hex + '.tmp'
    try:
        with open(temporary, 'w', encoding='utf-8') as fp:
            json.dump(data, fp)
        os.replace(temporary, SEEN_FILE)
    except OSError as e:
        xbmc.log(f'COSMOS newly_added: save failed: {e}', xbmc.LOGWARNING)
    finally:
        try:
            os.remove(temporary)
        except OSError:
            pass


def _load_state():
    _ensure()
    if not os.path.isfile(STATE_FILE):
        return {}
    try:
        with open(STATE_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp) or {}
        return data if isinstance(data, dict) else {}
    except (ValueError, OSError):
        return {}


def _save_state(state):
    _ensure()
    try:
        with open(STATE_FILE, 'w', encoding='utf-8') as fp:
            json.dump(state, fp)
    except OSError as e:
        xbmc.log(f'COSMOS newly_added: state save failed: {e}', xbmc.LOGWARNING)


def _infer_section(feed_url):
    """Derive a friendly section name from a feed URL as a last resort."""
    if not feed_url:
        return ''
    name = feed_url.rstrip('/').split('/')[-1]
    name = name.replace('.xml', '').replace('.xmll', '').replace('-', ' ').replace('_', ' ')
    return name.title()


# -- Public API --------------------------------------------------------------

def observe(items, first_run_window=None, section='', baseline=False):
    """Record the current timestamp for any item we have never seen before.

    On first ever run we back-date every observed item to ``now -
    first_run_window`` seconds (default: WINDOW_SECONDS + 1) so the
    entire existing catalogue does NOT flood the Newly-Added row.

    :param items:             Iterable of item dicts from parser.parse_page().
    :param first_run_window:  Back-date offset in seconds (None = use default).
    :param section:           Human-readable section name, e.g. "Movies".
    """
    data = _load()
    # Migrate equivalent IDs without changing when a title was first seen.
    canonical = {}
    for old_key, row in data.items():
        if not isinstance(row, dict):
            continue
        key = _key(row)
        if key in canonical:
            previous = canonical[key]
            row = dict(row)
            row['first_seen'] = min(previous.get('first_seen', 0), row.get('first_seen', 0))
        canonical[key] = row
    data = canonical
    now = int(time.time())
    first_ever = not data
    backdate = now - (first_run_window if first_run_window is not None
                      else WINDOW_SECONDS + 1)

    for it in items or []:
        k = _key(it)
        if not k.split(':', 2)[-1]:
            continue
        if k not in data:
            data[k] = {
                'first_seen': backdate if (first_ever or baseline) else now,
                'name': it.get('name', ''),
                'tmdb': str(it.get('tmdb') or ''),
                'content': _identity_content(it),
                'season': it.get('season', ''),
                'episode': it.get('episode', ''),
                'section': section or _infer_section(it.get('feed', '')),
                'feed': it.get('feed', ''),
                'thumb': it.get('thumb', ''),
                'path': it.get('path', ''),
                'links': it.get('links') or [],
            }
        else:
            data[k]['content'] = _identity_content(it)
            if it.get('tmdb'):
                data[k]['tmdb'] = _identity_number(it['tmdb'])
            # Back-fill navigation fields on older entries that predate them.
            current_section = str(data[k].get('section') or '').strip().lower()
            generic_sections = {
                '', 'enigma shows', 'enigma tv', 'enigma tv shows',
                'tv show', 'tv shows',
            }
            if section and current_section in generic_sections:
                data[k]['section'] = section
            for field in ('feed', 'season', 'episode', 'thumb'):
                if not data[k].get(field) and it.get(field) not in (None, ''):
                    data[k][field] = it.get(field)
            if it.get('links'):
                data[k]['links'] = it.get('links')
    _save(data)


def list_recent(days=7, limit=100):
    """Return items first seen within the last ``days`` days, newest first."""
    cutoff = int(time.time()) - days * 24 * 3600
    data = _load()
    rows = []
    for key, value in data.items():
        if not isinstance(value, dict):
            continue
        try:
            first_seen = int(value.get('first_seen', 0) or 0)
        except (TypeError, ValueError, OverflowError):
            continue
        if first_seen >= cutoff:
            rows.append({**value, 'key': key})
    rows.sort(key=lambda r: r.get('first_seen', 0), reverse=True)
    return rows[:limit]


def has_any(days=7):
    return bool(list_recent(days=days, limit=1))


def metadata_key(row):
    """Share series metadata across show and episode rows."""
    kind = 'movie' if _identity_content(row) == 'movie' else 'tvshow'
    return kind + ':' + _identity_number(row.get('tmdb'))


def load_metadata():
    """Read prepared metadata locally; never contact a provider here."""
    try:
        with open(METADATA_FILE, encoding='utf-8') as source:
            data = json.load(source)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def prepare_metadata(budget_seconds=20):
    """Enrich recent items in the scan worker, keeping menu opens offline."""
    from . import tmdb
    rows = list_recent(limit=None)
    active = {metadata_key(row) for row in rows if row.get('tmdb')}
    saved = {key: value for key, value in load_metadata().items() if key in active}
    now = int(time.time())
    deadline = time.monotonic() + budget_seconds
    monitor = xbmc.Monitor()
    fetched = set()
    for row in rows:
        key = metadata_key(row)
        if not row.get('tmdb') or key in fetched:
            continue
        fetched.add(key)
        entry = saved.get(key) or {}
        try:
            fresh = now - int(entry.get('prepared_at', 0)) < 86400
        except (TypeError, ValueError, AttributeError):
            fresh = False
        if fresh:
            continue
        if monitor.abortRequested() or time.monotonic() >= deadline:
            break
        try:
            kind = 'movie' if row.get('content', 'movie') == 'movie' else 'tvshow'
            meta = tmdb.get_metadata(row['tmdb'], kind) or {}
            if meta:
                saved[key] = {'prepared_at': now, 'meta': meta}
        except Exception as exc:
            xbmc.log(f'COSMOS newly_added: metadata preparation failed: {exc}', xbmc.LOGWARNING)
    _ensure()
    temporary = METADATA_FILE + '.' + uuid.uuid4().hex + '.tmp'
    try:
        with open(temporary, 'w', encoding='utf-8') as output:
            json.dump(saved, output)
        os.replace(temporary, METADATA_FILE)
    except (OSError, TypeError, ValueError) as exc:
        xbmc.log(f'COSMOS newly_added: metadata save failed: {exc}', xbmc.LOGWARNING)
    finally:
        try:
            os.remove(temporary)
        except OSError:
            pass


def reset():
    _save({})


# -- Hourly XML scan ---------------------------------------------------------

def should_scan():
    """Return True if at least SCAN_INTERVAL seconds have passed since the
    last feed scan (or if a scan has never been run)."""
    state = _load_state()
    try:
        last = int(state.get('last_scan_ts', 0) or 0)
    except (TypeError, ValueError, OverflowError):
        last = 0
    return (state.get('scan_version') != SCAN_VERSION
            or (int(time.time()) - last) >= SCAN_INTERVAL)


def _mark_last_scan():
    state = _load_state()
    state['last_scan_ts'] = int(time.time())
    _save_state(state)


def _show_episode_items(shows, section, feed_url):
    """Flatten nested Enigma-show seasons into independently tracked rows."""
    rows = []
    for show in shows or []:
        show_name = show.get('name') or 'Untitled'
        tmdb = str(show.get('tmdb') or '')
        thumb = show.get('thumb') or ''
        for season in show.get('seasons') or []:
            season_no = season.get('seasonNo')
            for episode in season.get('episodes') or []:
                episode_no = episode.get('episode')
                if season_no in (None, '') or episode_no in (None, ''):
                    continue
                rows.append({
                    'name': f'{show_name} S{season_no}E{episode_no}',
                    'tmdb': tmdb,
                    'content': 'episode',
                    'season': season_no,
                    'episode': episode_no,
                    'links': episode.get('links') or [],
                    'section': section,
                    'feed': feed_url,
                    'thumb': thumb,
                })
    return rows


def scan_feeds(home_url, force=False):
    """Run a due scan, excluding overlapping service/menu scans."""
    _ensure()
    try:
        # Recover a lock left behind if Kodi was shut down during a scan.
        if os.path.exists(SCAN_LOCK_FILE) and time.time() - os.path.getmtime(SCAN_LOCK_FILE) > 3600:
            os.remove(SCAN_LOCK_FILE)
        descriptor = os.open(SCAN_LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except OSError:
        return {'status': 'busy'}
    try:
        os.close(descriptor)
        if force or should_scan():
            return _scan_feeds(home_url)
        return {'status': 'skipped'}
    finally:
        try:
            os.remove(SCAN_LOCK_FILE)
        except OSError:
            pass


def _scan_feeds(home_url):
    """BFS-scan every top-level section XML and call observe() with its items.

    Designed to run in a background daemon thread once per hour.
    Only the direct children of the home feed are scanned (one level deep)
    so the scan is fast and does not repeat the full universal-search crawl.
    """
    try:
        from . import parser as _parser
    except ImportError:
        try:
            from resources.lib import parser as _parser  # type: ignore
        except ImportError:
            xbmc.log('COSMOS newly_added: cannot import parser for scan',
                     xbmc.LOGWARNING)
            return {'status': 'partial', 'observed': 0, 'failed_feeds': [home_url]}

    xbmc.log(f'COSMOS newly_added: starting feed scan from {home_url}',
             xbmc.LOGINFO)
    failed_feeds = []
    try:
        body = _parser.fetch_url(home_url)
        if not body:
            xbmc.log('COSMOS newly_added: home XML fetch returned empty',
                     xbmc.LOGWARNING)
            return {'status': 'partial', 'observed': 0, 'failed_feeds': [home_url]}

        kind, sections = _parser.parse_page(body)
        if kind != 'directory':
            xbmc.log(
                f'COSMOS newly_added: home feed is not a directory (got {kind})',
                xbmc.LOGWARNING)
            return {'status': 'partial', 'observed': 0, 'failed_feeds': [home_url]}

        new_total = 0
        baseline_catalogue = not bool(_load())
        scan_state = _load_state()
        baseline_episodes = not bool(
            scan_state.get('episode_tracking_initialized'))
        for sec in sections:
            section_name = sec.get('name', 'Unknown')
            section_url = (sec.get('url') or '').strip()
            if not section_url:
                continue
            try:
                sec_body = _parser.fetch_url(section_url)
                if not sec_body:
                    failed_feeds.append(section_url)
                    continue
                sec_kind, sec_items = _parser.parse_page(sec_body)
                if sec_kind in ('content', 'tvshow', 'movie'):
                    for it in sec_items:
                        it['section'] = section_name
                        it['feed'] = section_url
                    observe(sec_items, section=section_name, baseline=baseline_catalogue)
                    new_total += len(sec_items)
                    if sec_kind == 'tvshow':
                        episode_items = _show_episode_items(
                            sec_items, section_name, section_url)
                        observe(
                            episode_items, section=section_name,
                            baseline=baseline_episodes,
                        )
                        new_total += len(episode_items)
                elif sec_kind == 'directory':
                    # One level deeper (e.g. "TV Shows" may list sub-genres)
                    for sub in sec_items:
                        # Preserve the real child XML category (for example
                        # Complete Seasons or New Episodes) instead of
                        # flattening every row to the parent Enigma Shows.
                        sub_name = sub.get('name') or section_name
                        sub_url = (sub.get('url') or '').strip()
                        if not sub_url:
                            continue
                        try:
                            sub_body = _parser.fetch_url(sub_url)
                            if not sub_body:
                                failed_feeds.append(sub_url)
                                continue
                            sub_kind, sub_items = _parser.parse_page(sub_body)
                            if sub_kind in ('content', 'tvshow', 'movie'):
                                for it in sub_items:
                                    it['section'] = sub_name
                                    it['feed'] = sub_url
                                observe(sub_items, section=sub_name, baseline=baseline_catalogue)
                                new_total += len(sub_items)
                                if sub_kind == 'tvshow':
                                    episode_items = _show_episode_items(
                                        sub_items, sub_name, sub_url)
                                    observe(
                                        episode_items, section=sub_name,
                                        baseline=baseline_episodes,
                                    )
                                    new_total += len(episode_items)
                        except Exception as e2:
                            failed_feeds.append(sub_url)
                            xbmc.log(
                                f'COSMOS newly_added: sub-section scan failed: {e2}',
                                xbmc.LOGWARNING)
            except Exception as e:
                failed_feeds.append(section_url)
                xbmc.log(
                    f'COSMOS newly_added: scan section "{section_name}" failed: {e}',
                    xbmc.LOGWARNING)

        scan_state = _load_state()
        scan_state['episode_tracking_initialized'] = True
        scan_state['scan_version'] = SCAN_VERSION
        scan_state['partial_scan'] = bool(failed_feeds)
        scan_state['failed_feeds'] = failed_feeds
        scan_state.pop('pending_feeds', None)
        _save_state(scan_state)
        _mark_last_scan()
        xbmc.log(f'COSMOS newly_added: scan complete, observed {new_total} items',
                 xbmc.LOGINFO)
        return {'status': 'partial' if failed_feeds else 'complete',
                'observed': new_total, 'failed_feeds': failed_feeds}

    except Exception as e:
        xbmc.log(f'COSMOS newly_added: scan_feeds failed: {e}', xbmc.LOGWARNING)

        return {'status': 'partial', 'observed': 0, 'failed_feeds': [home_url]}


# -- Toast state -------------------------------------------------------------

def get_untoasted_items():
    """Return the newest rows not covered by the previous toast count."""
    state = _load_state()
    try:
        last_toast_count = int(state.get('last_toast_count', -1))
    except (TypeError, ValueError, OverflowError):
        last_toast_count = -1

    recent = list_recent(days=7)
    current_count = len(recent)
    if last_toast_count < 0:
        state['last_toast_count'] = current_count
        _save_state(state)
        return []
    added = current_count - last_toast_count
    return recent[:added] if added > 0 else []


def get_untoasted_count():
    """Return number of items added since the toast was last shown.

    Returns 0 if no new items, or if this is the very first run (so we do
    not spam users who install the addon for the first time).
    """
    return len(get_untoasted_items())


def mark_toast_shown():
    """Record that the toast has been shown for the current batch of items."""
    state = _load_state()
    state['last_toast_count'] = len(list_recent(days=7))
    _save_state(state)


def show_notification(addon):
    """Show a one-time toast when new items have been detected since the last
    notification. The toast respects the 'newly_added_toast' setting."""
    import xbmcgui

    try:
        if (addon.getSetting('newly_added_toast') or 'true').lower() != 'true':
            return
    except Exception:
        return
    new_items = get_untoasted_items()
    if not new_items:
        return
    mark_toast_shown()
    counts = {}
    for item in new_items:
        kind = str(item.get('content') or 'item').lower()
        counts[kind] = counts.get(kind, 0) + 1
    labels = []
    for kind, singular, plural in (
            ('movie', 'film', 'films'),
            ('tvshow', 'show', 'shows'),
            ('episode', 'episode', 'episodes')):
        count = counts.pop(kind, 0)
        if count:
            labels.append(f'{count} {singular if count == 1 else plural}')
    remaining = sum(counts.values())
    if remaining:
        labels.append(f'{remaining} new item' if remaining == 1
                      else f'{remaining} new items')
    summary = ', '.join(labels) or f'{len(new_items)} new items'
    xbmcgui.Dialog().notification(
        'C.O.S.M.O.S',
        f'New Enigma content: {summary}',
        xbmcgui.NOTIFICATION_INFO,
        5000,
    )

