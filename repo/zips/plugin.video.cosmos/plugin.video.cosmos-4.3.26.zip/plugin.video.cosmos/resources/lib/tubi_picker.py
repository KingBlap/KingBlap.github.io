"""Tubi live channel and programme metadata in the Cosmos picker."""
from .rakuten_picker import RakutenLivePickerDialog
from .pluto_picker import channel_link as programme_link
from .source_finder_dialog import ADDON_PATH
from .tubi import _art


def _rating(programme):
    ratings = programme.get('ratings') or []
    if isinstance(ratings, dict):
        return ratings.get('value') or ratings.get('code') or ''
    return next((r.get('value') or r.get('code') for r in ratings
                 if isinstance(r, dict) and (r.get('value') or r.get('code'))), '')


def normalize(channel, icon):
    programmes = []
    for programme in channel.get('programs') or []:
        tags = programme.get('tags') or channel.get('tags') or []
        genre = ', '.join(str(t) for t in tags) if isinstance(tags, list) else tags
        programmes.append({'title': programme.get('title'),
            'subtitle': programme.get('episode_title'),
            'starts_at': programme.get('start_time'), 'ends_at': programme.get('end_time'),
            'description': programme.get('description'),
            'classification': {'name': _rating(programme)},
            'episode': {'genre': genre, 'clip': {
                'originalReleaseDate': str(programme.get('year') or ''),
                'actors': programme.get('actors') or [],
                'directors': programme.get('directors') or []}}})
    images = channel.get('images') or {}
    return {'id': str(channel.get('id') or channel['content_id']),
            'title': channel.get('title') or 'Tubi TV',
            'channel_number': channel.get('number'),
            'images': {'artwork': _art(images, 'thumbnail', _art(channel, 'thumbnails', icon))},
            'live_programs': programmes, 'source': channel}


def channel_link(channel, icon):
    link = programme_link(channel, icon)
    info = link['info']
    if not info.get('mpaa'):
        info['mpaa'] = _rating(channel['source'])
    if not info.get('genre'):
        info['genre'] = channel['source'].get('tags') or []
    return link


class TubiLivePickerDialog(RakutenLivePickerDialog):
    provider_title = 'Tubi TV'

    def make_link(self, channel):
        return channel_link(channel, self.channel_icon)


def show(channels, region, icon, refresh_channels):
    if not channels:
        return None
    def prepare(rows):
        return sorted((normalize(c, icon) for c in rows), key=lambda c: c['title'].casefold())
    dialog = TubiLivePickerDialog(
        'TubiLivePicker.xml', ADDON_PATH, 'Default', '720p',
        channels=prepare(channels), market=region, icon_path=icon,
        refresh_channels=lambda: prepare(refresh_channels()))
    try:
        dialog.doModal()
        index = dialog.selected_index
        return dialog.links[index]['channel'] if index is not None and 0 <= index < len(dialog.links) else None
    finally:
        del dialog
