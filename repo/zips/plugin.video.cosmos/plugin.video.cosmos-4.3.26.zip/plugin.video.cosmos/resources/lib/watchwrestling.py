"""Watch Wrestling navigation and public player-link extraction."""
import base64
import html
import json
import re
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit, urlencode, parse_qs
from urllib.request import Request, urlopen
from urllib.error import HTTPError

BASE = 'https://watchwrestling.bg/'
PAGE_SIZE = 20
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36'


class PlayerUnavailable(ValueError):
    """A video host explicitly reports that the requested player is gone."""


class Node:
    def __init__(self, tag='', attrs=()):
        self.tag, self.attrs, self.children = tag, dict(attrs), []

    def walk(self, tag=None):
        for child in self.children:
            if isinstance(child, Node):
                if tag is None or child.tag == tag:
                    yield child
                yield from child.walk(tag)

    def text(self):
        return ' '.join(c.text() if isinstance(c, Node) else c for c in self.children).strip()


class Document(HTMLParser):
    def __init__(self, body):
        super().__init__(convert_charrefs=True)
        self.root = Node()
        self.stack = [self.root]
        self.feed(body)

    def handle_starttag(self, tag, attrs):
        node = Node(tag, attrs)
        self.stack[-1].children.append(node)
        if tag not in ('img', 'input', 'meta', 'link', 'br', 'hr', 'source', 'area', 'wbr', 'embed', 'param', 'base', 'col'):
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.stack[-1].children.append(Node(tag, attrs))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        self.stack[-1].children.append(data)


def site_url(value, base=BASE):
    url = urljoin(base, html.unescape(value or ''))
    parsed = urlsplit(url)
    if parsed.scheme not in ('http', 'https') or parsed.hostname not in ('watchwrestling.bg', 'www.watchwrestling.bg'):
        raise ValueError('Invalid Watch Wrestling page')
    return url


def fetch(url, referer=BASE):
    request = Request(url, headers={'User-Agent': UA, 'Referer': referer})
    with urlopen(request, timeout=20) as response:
        return response.read(4 * 1024 * 1024).decode('utf-8', 'replace')


def sections(body=None):
    root = Document(fetch(BASE) if body is None else body).root
    rows, seen = [('Latest Events', BASE)], {BASE}
    seen_names = {'latest events'}
    # Category links are the actual archive URLs; /show/<name>/ can redirect home.
    navigation = next((n for n in root.walk('nav') if n.attrs.get('id') == 'main-menu'), root)
    for a in navigation.walk('a'):
        href = a.attrs.get('href', '')
        if not href or href.startswith('#'):
            continue
        try:
            url = site_url(href)
        except ValueError:
            continue
        path = urlsplit(url).path
        name = re.sub(r'\s+', ' ', a.text()).strip()
        if (a.attrs.get('itemprop') == 'url' and a.text() and
                path.count('/') == 2 and
                not path.startswith(('/show/', '/wp-', '/author/')) and
                not re.search(r'\d', path) and url not in seen and name.casefold() not in seen_names):
            rows.append((name, url))
            seen.add(url)
            seen_names.add(name.casefold())
    # Include categories featured on the home page but absent from its navigation.
    for name, slug in [('WWE PPV', 'wwe-ppv'), ('ROH Wrestling', 'roh-wrestling'),
                       ('TNA Wrestling', 'tna-wrestling'), ('NJPW', 'njpw')]:
        url = urljoin(BASE, slug + '/')
        if url not in seen and name.casefold() not in seen_names:
            rows.append((name, url))
            seen.add(url)
            seen_names.add(name.casefold())
    return rows


def catalogue(url, body=None):
    url = site_url(url)
    if body is None and urlsplit(url).path.startswith('/wp-json/wp/v2/posts'):
        return _archive_catalogue(url)
    if body is None:
        match = re.fullmatch(r'/(wwe|wwe-raw|wwe-smackdown|wwe-nxt|ufc|aew|other-wrestling|wwe-ppv|roh-wrestling|tna-wrestling|njpw)/(?:page/(\d+)/)?', urlsplit(url).path)
        if match:
            terms = json.loads(fetch(BASE + 'wp-json/wp/v2/categories?' + urlencode({'slug': match[1], '_fields': 'id'})))
            if not terms:
                return [], ''
            archive = BASE + 'wp-json/wp/v2/posts?' + urlencode({
                'categories': terms[0]['id'], 'per_page': PAGE_SIZE, 'page': match[2] or 1})
            return _archive_catalogue(archive)
    root = Document(fetch(url) if body is None else body).root
    # Sidebar recommendations repeat on every archive page and are not results.
    root = next((n for n in root.walk() if 'postbody' in n.attrs.get('class', '').split()), root)
    rows, seen, next_page = [], set(), ''
    for node in root.walk():
        if 'bsx' not in node.attrs.get('class', '').split():
            continue
        a = next(node.walk('a'), None)
        if a is None:
            continue
        try:
            link = site_url(a.attrs.get('href', ''), url)
        except ValueError:
            continue
        if link in seen or link == url:
            continue
        heading = next(a.walk('h2'), None)
        title = (heading.text() if heading else a.attrs.get('title', '')) or a.text()
        image = next(a.walk('img'), None)
        thumb = urljoin(url, (image.attrs.get('data-src') or image.attrs.get('src') or '')) if image else ''
        rows.append({'title': re.sub(r'\s+', ' ', title), 'url': link, 'thumb': thumb,
                     'folder': urlsplit(link).path.startswith('/show/')})
        seen.add(link)
    for a in root.walk('a'):
        if ('next' in a.attrs.get('class', '').split() or
                'next' in a.attrs.get('rel', '').split()):
            next_page = site_url(a.attrs.get('href', ''), url)
            break
    if not next_page:
        # Themes can render numbered links without a dedicated Next button.
        current = next((n.text() for n in root.walk()
                        if 'current' in n.attrs.get('class', '').split()
                        and 'page-numbers' in n.attrs.get('class', '').split()), '1')
        if current.isdigit():
            for a in root.walk('a'):
                if 'page-numbers' in a.attrs.get('class', '').split() and a.text() == str(int(current) + 1):
                    next_page = site_url(a.attrs.get('href', ''), url)
                    break
    # Series pages list their episodes as links rather than poster cards.
    for node in root.walk():
        if 'eplister' not in node.attrs.get('class', '').split():
            continue
        for a in node.walk('a'):
            link = site_url(a.attrs.get('href', ''), url)
            if link not in seen:
                rows.append({'title': re.sub(r'\s+', ' ', a.text()), 'url': link, 'thumb': '', 'folder': False})
                seen.add(link)
    return rows, next_page


def catalogue_page(url, offset=0):
    """Fill one Kodi page across site pages, retaining any unconsumed cards."""
    url = site_url(url)
    if urlsplit(url).path == '/' and not urlsplit(url).query:
        url = BASE + 'wp-json/wp/v2/posts?' + urlencode({'per_page': PAGE_SIZE, 'page': 1})
    try:
        offset = max(0, int(offset))
    except (TypeError, ValueError):
        offset = 0
    rows, seen, visited = [], set(), set()
    while url and url not in visited:
        visited.add(url)
        entries, next_url = catalogue(url)
        for index in range(min(offset, len(entries)), len(entries)):
            entry = entries[index]
            if entry['url'] in seen:
                continue
            seen.add(entry['url'])
            rows.append(entry)
            if len(rows) == PAGE_SIZE:
                if index + 1 < len(entries):
                    return rows, (url, index + 1)
                return rows, (next_url, 0) if next_url and next_url not in visited else None
        url, offset = next_url, 0
    return rows, None


def _archive_catalogue(url):
    """The homepage is a short showcase; use the public chronological archive."""
    with urlopen(Request(url, headers={'User-Agent': UA, 'Referer': BASE}), timeout=20) as response:
        posts = json.loads(response.read(4 * 1024 * 1024).decode('utf-8'))
        total_pages = int(response.headers.get('X-WP-TotalPages', '1'))
    rows = []
    query = parse_qs(urlsplit(url).query)
    for post in posts:
        title = html.unescape(re.sub(r'<[^>]+>', '', post['title']['rendered']))
        # The site's default category (id 1, labelled UFC) is assigned to
        # every wrestling post. Do not let UFC duplicate Latest Events.
        if query.get('categories') == ['1'] and not re.search(r'\bUFC\b', title, re.I):
            continue
        meta = post.get('yoast_head_json') or {}
        images = meta.get('og_image') or []
        rows.append({'title': title,
                     'url': site_url(post['link']),
                     'thumb': images[0].get('url', '') if images else '', 'folder': False})
    page = int(query.get('page', ['1'])[0])
    query['page'] = [str(page + 1)]
    next_page = urlsplit(url)._replace(query=urlencode(query, doseq=True)).geturl() if page < total_pages else ''
    return rows, next_page


def is_direct_stream(url):
    parsed = urlsplit(url.partition('|')[0])
    if parsed.scheme not in ('http', 'https'):
        return False
    query = parse_qs(parsed.query)
    if query.get('sabr') == ['1']:
        return False
    return (parsed.path.lower().endswith(('.mp4', '.m3u8', '.webm')) or
            ((parsed.hostname or '').endswith('.googlevideo.com') and
             parsed.path == '/videoplayback' and query.get('mime') == ['video/mp4']))


def jwplayer_sources(body, base):
    """Read literal JWPlayer source data without executing site JavaScript."""
    candidates = []
    decoder = json.JSONDecoder()
    for match in re.finditer(r'(?:\b(?:var|let|const)\s+sources\s*=|[\"\']?sources[\"\']?\s*:)\s*(?=\[)', body):
        try:
            entries, _ = decoder.raw_decode(body[match.end():])
        except ValueError:
            continue
        for entry in entries:
            if isinstance(entry, dict) and isinstance(entry.get('file'), str):
                label = re.search(r'\d+', str(entry.get('label', '')))
                candidates.append((int(label[0]) if label else 0, entry['file']))
    for match in re.finditer(r'(?:\bfileUrl\s*=|[\"\']?file[\"\']?\s*:)\s*("(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')', body):
        value = match[1]
        try:
            value = json.loads(value) if value.startswith('"') else value[1:-1].replace('\\/', '/').replace("\\'", "'")
        except ValueError:
            continue
        candidates.append((0, value))
    links = []
    for _, value in sorted(candidates, key=lambda item: item[0], reverse=True):
        url = urljoin(base, html.unescape(value))
        if is_direct_stream(url) and url not in links:
            links.append(url)
    return links


def _links(body, base):
    root = Document(body).root
    links = []
    for node in root.walk():
        if node.tag in ('iframe', 'source', 'video'):
            value = node.attrs.get('src') or node.attrs.get('data-src')
            if value:
                links.append(urljoin(base, html.unescape(value)))
    # Some hosts supply the Dailymotion player in a JS configuration.
    for value in re.findall(r'https?://[^\s\"\'<>]+', html.unescape(body).replace('\\/', '/')):
        host = (urlsplit(value).hostname or '').lower()
        if host == 'dai.ly' or host == 'dailymotion.com' or host.endswith('.dailymotion.com'):
            if '/video/' in value or '/embed/' in value or 'video=' in value or host == 'dai.ly':
                links.append(value)
    return list(dict.fromkeys(links))


def sources(url, body=None):
    url = site_url(url)
    body = fetch(url) if body is None else body
    root = Document(body).root
    rows, seen = [], set()
    for node in root.walk('button'):
        match = re.search(r"value\s*:\s*['\"]([^'\"]+)['\"]", node.attrs.get('onclick', ''))
        if not match:
            continue
        try:
            fragment = base64.b64decode(match[1]).decode('utf-8')
        except (ValueError, UnicodeError):
            continue
        for link in _links(fragment, url):
            if link not in seen:
                rows.append((node.text() or 'Server {}'.format(len(rows) + 1), link))
                seen.add(link)
    for link in _links(body, url):
        if link not in seen:
            rows.append(('Server {}'.format(len(rows) + 1), link))
            seen.add(link)
    return rows


def unwrap(url):
    """Follow only known player wrappers, leaving host resolution to Cosmos."""
    seen = set()
    for _ in range(4):
        if url in seen:
            raise ValueError('Player wrapper loop')
        seen.add(url)
        parsed = urlsplit(url)
        if parsed.scheme not in ('http', 'https'):
            raise ValueError('Invalid player URL')
        host = (parsed.hostname or '').lower()
        if host not in ('watchwrestling.bg', 'www.watchwrestling.bg'):
            return url
        try:
            body = fetch(url)
        except HTTPError as exc:
            if exc.code in (404, 410):
                raise PlayerUnavailable('Video host no longer serves this part; try another server') from exc
            raise
        streams = jwplayer_sources(body, url)
        if streams:
            return streams[0] + '|' + urlencode({'User-Agent': UA, 'Referer': url})
        links = _links(body, url)
        if not links:
            if ('invalid or missing source' in body.lower() or
                    'video not found' in body.lower() or
                    'source not found' in body.lower()):
                raise PlayerUnavailable('Site player has no usable video link; try another server')
            raise ValueError('No video link found in player')
        url = links[0]
    raise ValueError('Too many player wrappers')
