﻿"""Tubi regional catalogue, search, series and public HLS playback."""
import json
import os
import re
import sys
import uuid
from concurrent.futures import ThreadPoolExecutor
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urlparse
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
from . import tmdb as tmdb_mod

TUBI_URL = 'https://tubitv.com/'
API_URL = 'https://uapi.adrise.tv/cms/'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': TUBI_URL}
PAGE_SIZE = 40
LIVE_PAGE_SIZE = 20
DEVICE_ID = str(uuid.uuid4())
LIVE_CHANNEL_TIMEOUT = 8
ADDON = xbmcaddon.Addon()

try:
    import xbmcvfs
    CACHE_DIR = xbmcvfs.translatePath(
        'special://profile/addon_data/plugin.video.cosmos/tubi_cache/'
    )
except ImportError:
    CACHE_DIR = os.path.join(os.path.expanduser('~'), '.cosmos', 'tubi_cache')


def _region():
    """Choose the Tubi catalogue from Kodi's configured country automatically."""
    country_to_region = {
        'US': 'US', 'GB': 'GB', 'AU': 'AU', 'CA': 'CA', 'MX': 'MX',
        # Tubi's UK catalogue is the closest supported catalogue for Ireland.
        'IE': 'GB',
        # Tubi's Australian catalogue is the closest supported catalogue for NZ.
        'NZ': 'AU',
    }
    try:
        language = xbmc.getLanguage(xbmc.ISO_639_1, True) or ''
        country = language.rsplit('-', 1)[-1].strip().upper() if '-' in language else ''
    except Exception:
        country = ''
    return country_to_region.get(country, 'US')


def _catalogue_base():
    paths = {
        'US': '',
        'GB': 'en-gb',
        'AU': 'en-au',
        'CA': 'fr-ca',
        'MX': 'es-mx',
    }
    return TUBI_URL + paths.get(_region(), '')


def _request(url, timeout=25):
    """Fetch current Tubi data on every request without a local cache."""
    with urlopen(Request(url, headers=HEADERS), timeout=timeout) as response:
        return response.read().decode('utf-8-sig')


def _api(endpoint, **params):
    timeout = params.pop('_timeout', 25)
    params.update(app_id='tubitv', platform='web', device_id=DEVICE_ID,
                  region=_region())
    url = API_URL + endpoint + '?' + urlencode(params)
    return json.loads(_request(url, timeout=timeout))


def _parse_state(page):
    match = re.search(r'window\.__data\s*=\s*(.*?)</script>', page, re.S)
    if not match:
        raise ValueError('Tubi did not return catalogue data for this region.')
    # Replace JS undefined tokens without changing quoted titles/descriptions.
    raw = re.sub(r'"(?:\\.|[^"\\])*"|\bundefined\b',
                 lambda m: 'null' if m.group() == 'undefined' else m.group(),
                 match.group(1).strip().rstrip(';'))
    return json.loads(raw)


def _state(path, refresh=False):
    base = _catalogue_base().rstrip('/') + '/'
    return _parse_state(_request(base + path.lstrip('/')))


def _art(item, key, fallback):
    values = item.get(key) or []
    value = values[0] if isinstance(values, list) and values else values
    if not isinstance(value, str) or not value:
        return fallback
    return 'https:' + value if value.startswith('//') else value


def _series_id(value):
    value = str(value)
    return value if value.startswith('0') else '0' + value


def _tmdb_art(title, content, item):
    if (ADDON.getSetting('tubi_tmdb_artwork') or 'true').lower() != 'true':
        return {}
    if item.get('series_id') and item.get('type') != 's':
        return {}
    try:
        tmdb_id = item.get('tmdb_id') or item.get('tubi_fields', {}).get('tmdb_id')
        if tmdb_id:
            meta = tmdb_mod.get_metadata(str(tmdb_id), content) or {}
        else:
            meta = tmdb_mod.search_art_by_title(
                title, content, year=item.get('year')
            ) or {}
    except Exception as exc:
        xbmc.log('COSMOS Tubi: TMDB artwork lookup failed: %s' % exc, xbmc.LOGDEBUG)
        meta = {}
    return meta


def _content(content_id, timeout=25):
    if not re.fullmatch(r'\d+', str(content_id)):
        raise ValueError('Invalid Tubi content ID.')
    data = _api('content', content_id=content_id, video_resources='hlsv6',
                _timeout=timeout)
    if not isinstance(data, dict) or not data.get('id'):
        raise ValueError('Tubi returned no title information.')
    return data


def _catalogue(state, mode=''):
    container = state.get('contentMode', {}).get(mode, {}) if mode else state.get('container', {})
    by_id = state.get('video', {}).get('byId', {})
    ids = []
    keys = container.get('containersList') or [container.get('containerContext')]
    for key in keys:
        ids.extend(container.get('containerChildrenIdMap', {}).get(key, []))
    return [by_id[key] for key in dict.fromkeys(ids) if key in by_id]


def _live_channels(state, offset=0):
    """Hydrate the channel IDs exposed by Tubi's live EPG state."""
    groups = state.get('epg', {}).get('contentIdsByContainer', {}).get('tubitv_us_linear', [])
    channel_ids = []
    for group in groups:
        if isinstance(group, dict):
            channel_ids.extend(group.get('contents') or [])
    valid_ids = [content_id for content_id in dict.fromkeys(channel_ids)
                 if str(content_id).isdigit()]
    page_ids = valid_ids[offset:offset + LIVE_PAGE_SIZE]

    def load_channel(content_id):
        try:
            return _content(content_id, timeout=LIVE_CHANNEL_TIMEOUT)
        except (HTTPError, URLError, ValueError, KeyError, TypeError, OSError):
            return None

    # Channel metadata is independent; parallel requests prevent one slow
    # channel from blocking the entire Live TV directory.
    with ThreadPoolExecutor(max_workers=8) as executor:
        channels = [channel for channel in executor.map(load_channel, page_ids)
                    if channel]
    return channels, len(valid_ids)


def _epg_rows(ids):
    # EPG responses also contain signed stream URLs: keep them in memory only.
    url = TUBI_URL + 'oz/epg/programming?' + urlencode({'content_id': ','.join(ids)})
    with urlopen(Request(url, headers=HEADERS), timeout=25) as response:
        data = json.load(response)
    return data.get('rows') or []


def _live_guide(refresh=False):
    state = _state('live', refresh=refresh)
    groups = state.get('epg', {}).get('contentIdsByContainer', {})
    ids = list(dict.fromkeys(str(cid) for containers in groups.values()
               for group in containers if isinstance(group, dict)
               for cid in group.get('contents', []) if str(cid).isdigit()))
    rows = {}
    for offset in range(0, len(ids), 100):
        try:
            for row in _epg_rows(ids[offset:offset + 100]):
                cid = str(row.get('content_id') or '')
                if cid in ids:
                    rows[cid] = dict(row, id=cid)
        except (HTTPError, URLError, OSError, ValueError, KeyError, TypeError) as exc:
            xbmc.log('COSMOS: Tubi EPG unavailable: %s' % type(exc).__name__, xbmc.LOGWARNING)
    missing = [cid for cid in ids if cid not in rows]
    def fallback(cid):
        try:
            return _content(cid, timeout=LIVE_CHANNEL_TIMEOUT)
        except (HTTPError, URLError, OSError, ValueError, KeyError, TypeError):
            return None
    if missing:
        with ThreadPoolExecutor(max_workers=8) as executor:
            for row in executor.map(fallback, missing):
                if row:
                    rows[str(row['id'])] = row
    return [rows[cid] for cid in ids if cid in rows]


def _add_title(item, add_directory, build_url, icon, fanart, tmdb=None,
               live=False):
    content_id = str(item.get('id') or '')
    if not content_id.isdigit():
        return
    series = item.get('type') == 's'
    if series:
        content_id = _series_id(content_id)
    title = item.get('title') or 'Untitled'
    content = 'video' if live else ('tvshow' if series else 'movie')
    tmdb = tmdb if tmdb is not None else _tmdb_art(title, content, item)
    ratings = item.get('ratings') or {}
    genres = item.get('genres') or item.get('tags') or item.get('genre') or ''
    if isinstance(genres, (list, tuple)):
        genres = ', '.join(str(value) for value in genres if value)
    info = {
        'title': title,
        'plot': item.get('description') or '',
        'year': 0 if live else (item.get('year') or tmdb.get('year') or 0),
        'genre': '' if live else genres,
        'rating': 0 if live else (item.get('rating') or tmdb.get('rating') or 0),
        'duration': 0 if live else (item.get('duration') or tmdb.get('runtime') or 0),
        'mpaa': (item.get('content_rating') or ratings.get('value', '')
             if isinstance(ratings, dict) else item.get('content_rating', '')),
    }
    if not live:
        info['mediatype'] = content
    else:
        # Live channels are not finite video items. Explicitly clear any
        # playcount Kodi may have retained from older channel entries so the
        # skin cannot render them with a watched checkmark.
        info['playcount'] = 0
    for source, target in [('episode_number', 'episode')]:
        if str(item.get(source, '')).isdigit():
            info[target] = int(item[source])
    poster = tmdb.get('poster') or _art(item, 'posterarts', icon)
    fanart_image = tmdb.get('fanart') or _art(item, 'backgrounds', fanart)
    add_directory(title, build_url(action='tubi_series' if series and not live else 'tubi_play',
                                  content_id=content_id),
                  thumb=poster, fanart=fanart_image, info=info,
                  is_folder=series and not live, is_playable=True)


def _page_offset(params):
    try:
        return max(0, int(params.get('offset', 0)))
    except (TypeError, ValueError):
        return 0


def _page_links(total, params, action, add_directory, build_url, icon, fanart,
                page_size=PAGE_SIZE):
    offset = _page_offset(params)
    if offset:
        previous = dict(params, action=action, offset=str(max(0, offset - page_size)))
        previous_start = max(0, offset - page_size) + 1
        previous_end = min(offset, total)
        add_directory('Previous Page (%d-%d)' % (previous_start, previous_end),
                      build_url(**previous), thumb=icon, fanart=fanart)
    if offset + page_size < total:
        following = dict(params, action=action, offset=str(offset + page_size))
        next_start = offset + page_size + 1
        next_end = min(offset + (page_size * 2), total)
        add_directory('Next Page (%d-%d)' % (next_start, next_end),
                      build_url(**following), thumb=icon, fanart=fanart)


def _listing(items, params, action, add_directory, build_url, icon, fanart,
             total=None, page_size=PAGE_SIZE):
    offset = _page_offset(params)
    unique = {str(item['id']): item for item in items if isinstance(item, dict) and item.get('id')}
    items = list(unique.values())
    visible_items = items if total is not None else items[offset:offset + page_size]
    with ThreadPoolExecutor(max_workers=6) as executor:
        artwork = executor.map(
            lambda item: _tmdb_art(
                item.get('title') or 'Untitled',
                'tvshow' if item.get('type') == 's' else 'movie',
                item,
            ),
            visible_items,
        )
        for item, tmdb in zip(visible_items, artwork):
            _add_title(item, add_directory, build_url, icon, fanart, tmdb,
                        live=(action == 'tubi_live'))
    _page_links(total if total is not None else len(items), params, action,
                add_directory, build_url, icon, fanart, page_size=page_size)
    if not items:
        xbmcgui.Dialog().notification('Tubi TV', 'No titles available in this region.')


def _play(content_id, live_info=None):
    if live_info is not None:
        if not str(content_id).isdigit():
            raise ValueError('Invalid Tubi channel ID.')
        try:
            rows = _epg_rows([str(content_id)])
        except (HTTPError, URLError, OSError, ValueError, KeyError, TypeError):
            rows = []
        item = next((row for row in rows if str(row.get('content_id')) == str(content_id)), None)
        if item is None:
            item = _content(content_id)
    else:
        item = _content(content_id)
    if item.get('needs_login'):
        raise ValueError('This title requires signing in through the official Tubi app or website.')
    if item.get('policy_match') is False:
        raise ValueError('This title is not available in your region.')
    all_resources = [r for r in item.get('video_resources', [])
                     if isinstance(r, dict)]
    resources = [r for r in all_resources
                 if r.get('type') in ('hlsv6', 'hlsv3') and not r.get('license_server')
                 and not r.get('drm') and r.get('manifest', {}).get('url')]
    if not resources:
        if any(r.get('license_server') or r.get('drm') for r in all_resources):
            raise ValueError('This Tubi title is DRM-protected and requires Kodi InputStream Adaptive with Tubi license support or the official Tubi app.')
        raise ValueError('Tubi did not provide a playable HLS stream for this title in your region.')
    def quality(resource):
        numbers = re.findall(r'\d+', resource.get('resolution', ''))
        return int(numbers[0]) if numbers else 0
    resources.sort(key=quality, reverse=True)
    stream = resources[0]['manifest']['url']
    if urlparse(stream).scheme != 'https':
        raise ValueError('Tubi returned an invalid stream URL.')
    header_part = urlencode(HEADERS)
    # Native HLS receives HTTP headers through Kodi's URL options. Keep
    # on-demand playback on ISA with its separate manifest/media headers.
    live = live_info is not None
    li = xbmcgui.ListItem(path=stream + '|' + header_part if live else stream)
    info = dict(live_info or {'title': item.get('title', ''), 'plot': item.get('description', '')})
    if live:
        info.update(playcount=0, overlay=0, duration=0)
        li.setProperty('ResumeTime', '0')
        li.setProperty('TotalTime', '0')
    li.setInfo('video', info)
    images = item.get('images') or {}
    li.setArt({'thumb': _art(images, 'thumbnail', _art(item, 'thumbnails', '')),
               'fanart': _art(images, 'background', _art(item, 'backgrounds', ''))})
    li.setMimeType('application/vnd.apple.mpegurl')
    li.setContentLookup(False)
    if live:
        li.setProperty('inputstream', 'inputstream.ffmpeg')
        li.setProperty('IsPlayable', 'true')
    else:
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setProperty('inputstream.adaptive.manifest_headers', header_part)
        li.setProperty('inputstream.adaptive.stream_headers', header_part)
    subtitles = [s['url'] for s in item.get('subtitles', [])
                 if isinstance(s, dict) and str(s.get('url', '')).startswith('https://')]
    if subtitles:
        li.setSubtitles(subtitles)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)


def _refresh_cache():
    # Retain old saved routes; browsing always fetches current data.
    clear_cache()
    xbmc.executebuiltin('Container.Refresh')


def clear_cache():
    """Remove files left by older versions of the provider cache."""
    try:
        if os.path.isdir(CACHE_DIR):
            for filename in os.listdir(CACHE_DIR):
                if filename.endswith(('.json', '.tmp')):
                    try:
                        os.remove(os.path.join(CACHE_DIR, filename))
                    except OSError:
                        pass
    except OSError:
        pass


def run(action, params, add_directory, build_url, icon, fanart):
    clear_cache()
    handle = int(sys.argv[1])
    playing = action in ('tubi_play', 'tubi_live')
    succeeded = False
    try:
        if action == 'tubi_live':
            from . import tubi_picker
            selected = tubi_picker.show(_live_guide(), _region(), icon,
                                        lambda: _live_guide(refresh=True))
            if selected is None:
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                return
            _play(selected['id'], live_info=tubi_picker.channel_link(selected, icon)['info'])
            return
        if action == 'tubi_play':
            _play(params.get('content_id', ''))
            return
        xbmcplugin.setContent(handle, 'videos')
        if action == 'tubi_refresh_cache':
            _refresh_cache()
        elif action == 'tubi_root':
            entries = [
                    ('Movies', 'Browse free movies available on Tubi.',
                     'tubi_browse', {'mode': 'movie'}, True),
                    ('TV Shows', 'Browse free TV shows, seasons, and episodes on Tubi.',
                     'tubi_browse', {'mode': 'tv'}, True),
                    ('Categories', 'Explore Tubi by genre and curated catalogue.',
                     'tubi_categories', {}, True),
                    ('Live TV', 'Watch supported free live channels from Tubi.',
                     'tubi_live', {}, False),
                    ('Search Tubi', 'Search Tubi movies and TV shows by title.',
                     'tubi_search', {}, True)]
            for title, plot, target, extra, is_folder in entries:
                add_directory('[B]' + title + '[/B]', build_url(action=target, **extra),
                              thumb=icon, fanart=fanart,
                              info={'title': title, 'plot': plot}, is_folder=is_folder,
                              is_playable=target == 'tubi_live', live=target == 'tubi_live')
            notice = 'Content could be Geo Locked and require a VPN to access!'
            add_directory('[COLOR gold]' + notice + '[/COLOR]', '', thumb=icon, fanart=fanart,
                          info={'title': notice}, is_folder=False)
        elif action == 'tubi_categories':
            container = _state('')['container']
            categories = []
            for key in container.get('containerMenuList', []):
                item = container.get('containerIdMap', {}).get(key, {})
                if item.get('slug'):
                    categories.append((key, item))
            offset = _page_offset(params)
            for key, item in categories[offset:offset + PAGE_SIZE]:
                add_directory(item.get('title', key),
                              build_url(action='tubi_category', slug=item['slug']),
                              thumb=_art(item, 'thumbnail', icon), fanart=fanart,
                              info={'plot': item.get('description') or ''})
            _page_links(len(categories), params, action, add_directory,
                        build_url, icon, fanart)
        elif action in ('tubi_browse', 'tubi_category'):
            mode = params.get('mode', '')
            if action == 'tubi_browse':
                if mode not in ('movie', 'tv'):
                    raise ValueError('Invalid Tubi catalogue.')
                state = _state('movies' if mode == 'movie' else 'tv-shows')
            elif action == 'tubi_category':
                state = _state('category/' + quote(params.get('slug', ''), safe=''))
                mode = ''
            items = _catalogue(state, mode)
            _listing(items, params, action, add_directory, build_url, icon, fanart)
        elif action == 'tubi_search':
            query = params.get('query')
            if query is None:
                query = xbmcgui.Dialog().input('Search Tubi').strip()
            if query:
                items = _api('search', search=query)
                if not isinstance(items, list):
                    raise ValueError('Tubi returned an unexpected search response.')
                _listing(items, dict(params, query=query), action,
                         add_directory, build_url, icon, fanart)
        elif action == 'tubi_series':
            content_id = _series_id(params.get('content_id', ''))
            data = _content(content_id)
            seasons = data.get('children') or []
            selected = params.get('season')
            if selected is None:
                offset = _page_offset(params)
                for season in seasons[offset:offset + PAGE_SIZE]:
                    add_directory(season.get('title') or 'Season ' + str(season['id']),
                                  build_url(action=action, content_id=content_id, season=season['id']),
                                  thumb=_art(data, 'posterarts', icon), fanart=fanart)
                _page_links(len(seasons), params, action, add_directory,
                            build_url, icon, fanart)
            else:
                season = next((s for s in seasons if str(s.get('id')) == str(selected)), {})
                _listing(season.get('children') or [], params, action,
                         add_directory, build_url, icon, fanart)
        elif action == 'tubi_open':
            # Migrate old website menu favourites to the native catalogue.
            path = urlparse(params.get('url') or TUBI_URL).path
            mode = {'/movies': 'movie', '/tv-shows': 'tv'}.get(path)
            target = 'tubi_browse' if mode else {'/live': 'tubi_live', '/search': 'tubi_search'}.get(path, 'tubi_root')
            xbmc.executebuiltin('Container.Update(%s)' % build_url(action=target, **({'mode': mode} if mode else {})))
        else:
            raise ValueError('Unknown Tubi action.')
        succeeded = True
    except (HTTPError, URLError, ValueError, KeyError, TypeError, OSError) as exc:
        # Do not log signed URLs, device IDs or response bodies.
        if isinstance(exc, HTTPError):
            message = 'Tubi request failed (HTTP %s).' % exc.code
        elif isinstance(exc, (URLError, OSError)):
            message = 'Could not connect to Tubi. Please try again.'
        else:
            message = str(exc) if isinstance(exc, ValueError) and not isinstance(exc, json.JSONDecodeError) else 'Tubi returned an unexpected response.'
        xbmc.log('[Cosmos Tubi] ' + message, xbmc.LOGWARNING)
        xbmcgui.Dialog().ok('Tubi TV', message)
        if playing:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
    finally:
        if not playing:
            xbmcplugin.endOfDirectory(handle, succeeded=succeeded, cacheToDisc=False)
