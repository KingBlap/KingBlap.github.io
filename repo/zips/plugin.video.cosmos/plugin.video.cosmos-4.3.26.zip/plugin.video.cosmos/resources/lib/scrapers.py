"""
Torrent Scrapers Module

This addon and code was created by Zeus768 for Cosmos.
Author: Zeus768

Uses native urllib (no external requests module)
"""
import json
import re
import base64
import xbmc
import xbmcaddon
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from urllib.parse import quote_plus, unquote_plus
from html import unescape
from html.parser import HTMLParser

ADDON = xbmcaddon.Addon()
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'

# Quality detection patterns
QUALITY_PATTERNS = {
    '2160p': r'(?:2160p|4k|uhd)',
    '1080p': r'(?:1080p|1080i|fhd)',
    '720p': r'(?:720p|hd)',
    '480p': r'(?:480p|sd)',
    '360p': r'(?:360p)'
}

QUALITY_ORDER = ['2160p', '1080p', '720p', '480p', '360p']
SEARCH_ALL_TIMEOUT_SECONDS = 25.0

# Seed-count icon used by Torrentio / Comet / MediaFusion in stream descriptions.
# Stored as a string constant so we can build raw regex patterns around it without
# triggering the Python 3.12 SyntaxWarning on invalid escape sequences.
_SEED_ICON = '\U0001F464'  # 👤


def _setting_enabled(setting_id):
    """Require both the scraper's switch and the master torrent switch."""
    return (
        ADDON.getSetting('enable_torrent_scrapers') == 'true'
        and ADDON.getSetting(setting_id) == 'true'
    )


def _extract_seed_count(text):
    """Read seeder counts used by current Stremio torrent providers."""
    text = text or ''
    for pattern in (
        _SEED_ICON + r'\s*([0-9][0-9,]*)',
        r'▶(?:️)?\s*([0-9][0-9,]*)',
        r'(?i)\b(?:seeders?|seeds?)\s*[:=]?\s*([0-9][0-9,]*)',
    ):
        match = re.search(pattern, text)
        if match:
            try:
                return int(match.group(1).replace(',', ''))
            except (TypeError, ValueError):
                pass
    return 0


def _normalise_stremio_base_url(value, default):
    """Accept an instance, configure URL, or copied manifest URL."""
    base = (value or '').strip().rstrip('/') or default
    base = re.sub(r'/(?:manifest\.json|configure|app)$', '', base, flags=re.I)
    if not re.match(r'^https?://', base, re.I):
        base = 'https://' + base.lstrip('/')
    return base.rstrip('/')


def _normalise_mirror_url(value):
    """Return a user-supplied scraper mirror as a safe HTTP(S) base URL."""
    base = (value or '').strip().rstrip('/')
    if not base:
        return ''
    if not re.match(r'^https?://', base, re.I):
        base = 'https://' + base.lstrip('/')
    # Users commonly copy the site's browser landing page. Scraper routes
    # must be joined to the domain root, not beneath /home.
    return re.sub(r'/home$', '', base, flags=re.I).rstrip('/')


def _configured_mirrors(setting_id, defaults):
    custom = _normalise_mirror_url(ADDON.getSetting(setting_id))
    return ([custom] if custom else []) + [url for url in defaults if url != custom]


_DEFAULT_TRACKERS = (
    'udp://tracker.opentrackr.org:1337/announce',
    'udp://open.stealth.si:80/announce',
    'udp://tracker.torrent.eu.org:451/announce',
    'udp://tracker.bittor.pw:1337/announce',
)


def _clean_tracker_sources(raw_sources):
    """Normalize Stremio tracker fields into valid magnet tracker URLs."""
    trackers = []
    seen = set()
    for raw in raw_sources or ():
        source = unquote_plus(str(raw or '').strip())
        if source.startswith('tracker:'):
            source = source[len('tracker:'):]
        if source.startswith('?tr='):
            source = source[len('?tr='):]
        if source.startswith('dht:') or not source:
            continue
        if not re.match(r'^(?:udp|https?)://', source, re.I):
            # Current Comet responses sometimes omit udp:// while retaining
            # the conventional tracker host:port/announce shape.
            if re.match(r'^[A-Za-z0-9.-]+(?::\d+)?/announce(?:\?.*)?$', source):
                source = 'udp://' + source
            else:
                continue
        key = source.lower()
        if key not in seen:
            trackers.append(source)
            seen.add(key)
    return trackers or list(_DEFAULT_TRACKERS)


def extract_hash(magnet):
    """Extract info hash from magnet link"""
    if not magnet:
        return ''
    match = re.search(r'btih:([a-fA-F0-9]{40})', magnet)
    if match:
        return match.group(1).lower()
    # Also support base32 encoded hashes (32 chars)
    match = re.search(r'btih:([a-zA-Z2-7]{32})', magnet)
    if match:
        return match.group(1).lower()
    return ''


def _is_game_source(result):
    """Reject game releases without treating movie titles as game keywords."""
    title = str(result.get('title') or '')
    category = str(result.get('category') or '').strip().lower()
    if re.search(r'\b(?:games?|software|applications)\b', category):
        return True
    if result.get('source') == 'PirateBay' and re.fullmatch(r'[34]\d{2}', category):
        return True
    if re.search(r'\.(?:exe|msi|nsp|xci|cia|pkg)(?:\s|$)', title, re.I):
        return True
    if re.search(r'\b(?:fitgirl|dodi[ ._-]*repack|steamrip|gog[ ._-]*games|'
                 r'elamigos|kaoskrew|skidrow|tenoke|'
                 r'ps[345]|playstation|xbox|nintendo[ ._-]*switch)\b', title, re.I):
        return True
    # REPACK alone is also a legitimate video-release tag. Require gaming
    # context, and avoid interpreting an ordinary title as a scene group.
    video = re.search(r'\b(?:2160p|1080p|720p|480p|bluray|webrip|hdtv)\b|'
                      r'web[ ._-]*dl|\.(?:mkv|mp4|avi|m4v)\b', title, re.I)
    if not video and re.search(r'(?:[-\[])\s*(?:codex|rune|flt|goldberg|plaza|reloaded)\b|'
                               r'\b(?:pc[ ._-]*(?:game|repack)|'
                               r'(?:gog|steam)[ ._-]*(?:rip|release)|'
                               r'(?:game|dlc)[ ._-]*(?:update|crack)|'
                               r'cracked|crackfix)\b', title, re.I):
        return True
    return False


def _http_get(url, headers=None, timeout=10):
    """HTTP GET request using urllib, returns response text or None"""
    hdrs = {'User-Agent': USER_AGENT}
    if headers:
        hdrs.update(headers)
    
    try:
        req = Request(url, headers=hdrs, method='GET')
        response = urlopen(req, timeout=timeout)
        return response.read().decode('utf-8', errors='replace')
    except HTTPError as e:
        xbmc.log(f'Scraper HTTP Error: {e.code}', xbmc.LOGWARNING)
        return None
    except URLError as e:
        xbmc.log(f'Scraper URL Error: {e.reason}', xbmc.LOGERROR)
        return None
    except Exception as e:
        xbmc.log(f'Scraper Request Error: {e}', xbmc.LOGERROR)
        return None


def _http_get_json(url, headers=None, timeout=10):
    """HTTP GET request using urllib, returns json data or None"""
    body = _http_get(url, headers, timeout)
    if body:
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            return None
    return None


def detect_quality(title):
    """Detect quality from torrent title"""
    title_lower = title.lower()
    for quality, pattern in QUALITY_PATTERNS.items():
        if re.search(pattern, title_lower):
            return quality
    return '480p'  # Default if not detected


def sort_by_quality(results, preferred_quality='1080p'):
    """Sort results by quality, prioritizing preferred and falling back to lower"""
    if not results:
        return []
    
    # Find the index of preferred quality
    try:
        pref_idx = QUALITY_ORDER.index(preferred_quality)
    except ValueError:
        pref_idx = 1  # Default to 1080p index
    
    # Create quality groups
    quality_groups = {q: [] for q in QUALITY_ORDER}
    unknown = []
    
    for result in results:
        quality = result.get('quality', detect_quality(result.get('title', '')))
        result['quality'] = quality
        if quality in quality_groups:
            quality_groups[quality].append(result)
        else:
            unknown.append(result)
    
    # Build sorted list: preferred quality first, then lower qualities
    sorted_results = []
    
    # Start from preferred quality and go down
    for i in range(pref_idx, len(QUALITY_ORDER)):
        quality = QUALITY_ORDER[i]
        # Sort by seeds within same quality
        sorted_results.extend(sorted(quality_groups[quality], 
                                     key=lambda x: x.get('seeds', 0), reverse=True))
    
    # Add higher qualities at the end (user might want them too)
    for i in range(pref_idx):
        quality = QUALITY_ORDER[i]
        sorted_results.extend(sorted(quality_groups[quality], 
                                     key=lambda x: x.get('seeds', 0), reverse=True))
    
    sorted_results.extend(unknown)
    return sorted_results


class PirateBayScraper:
    """The Pirate Bay torrent scraper"""
    
    # Multiple mirrors for redundancy
    MIRRORS = [
        "https://apibay.org",
        "https://piratebay.party",
        "https://thepiratebay.org"
    ]
    
    def __init__(self):
        self.enabled = _setting_enabled('enable_piratebay')
    
    def search(self, query, category='video'):
        """Search for torrents"""
        if not self.enabled:
            xbmc.log('COSMOS [SCRAPER] PirateBay  disabled — skipping', xbmc.LOGDEBUG)
            return []
        
        xbmc.log(f'COSMOS [SCRAPER] PirateBay  query={query!r}', xbmc.LOGDEBUG)
        results = []
        cat_num = '200'  # Video category
        
        for mirror in self.MIRRORS:
            try:
                xbmc.log(f'COSMOS [SCRAPER] PirateBay  trying mirror {mirror}', xbmc.LOGDEBUG)
                url = f"{mirror}/q.php?q={quote_plus(query)}&cat={cat_num}"
                res = _http_get_json(url)
                
                if res and res[0].get('id') != '0':  # Valid results
                    for item in res[:20]:  # Limit results
                        if item.get('id') == '0':
                            continue
                        
                        name = item.get('name', '')
                        info_hash = item.get('info_hash', '')
                        seeds = int(item.get('seeders', 0))
                        size = int(item.get('size', 0))
                        
                        # Build magnet link
                        magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={quote_plus(name)}"
                        
                        # Add common trackers
                        trackers = [
                            "udp://tracker.opentrackr.org:1337/announce",
                            "udp://open.stealth.si:80/announce",
                            "udp://tracker.torrent.eu.org:451/announce",
                            "udp://tracker.bittor.pw:1337/announce",
                            "udp://public.popcorn-tracker.org:6969/announce"
                        ]
                        for tracker in trackers:
                            magnet += f"&tr={quote_plus(tracker)}"
                        
                        results.append({
                            'title': name,
                            'magnet': magnet,
                            'seeds': seeds,
                            'size': size,
                            'quality': detect_quality(name),
                            'source': 'PirateBay',
                            'category': item.get('category', ''),
                        })
                    
                    xbmc.log(f'COSMOS [SCRAPER] PirateBay  {len(results)} results from {mirror}', xbmc.LOGDEBUG)
                    break  # Success, no need to try other mirrors
                else:
                    xbmc.log(f'COSMOS [SCRAPER] PirateBay  no valid results from {mirror}', xbmc.LOGDEBUG)
                    
            except Exception as e:
                xbmc.log(f"COSMOS [SCRAPER] PirateBay  mirror {mirror} failed: {e}", xbmc.LOGWARNING)
                continue
        
        xbmc.log(f'COSMOS [SCRAPER] PirateBay  total={len(results)}', xbmc.LOGDEBUG)
        return results


class TorrentGalaxy:
    """TorrentGalaxy scraper — searches by seeders descending."""

    MIRRORS = [
        'https://torrentgalaxy.to',
        'https://tgx.rs',
        'https://torrentgalaxy.mx',
        'https://torrentgalaxy.st',
    ]

    def __init__(self):
        self.enabled = _setting_enabled('enable_torrentgalaxy')
        self.mirrors = _configured_mirrors('torrentgalaxy_url', self.MIRRORS)

    def search(self, query):
        if not self.enabled:
            return []

        for mirror in self.mirrors:
            try:
                url = (f'{mirror}/torrents.php?search={quote_plus(query)}'
                       f'&sort=seeders&order=desc&lang=0&nox=2')
                html = _http_get(url, timeout=6)
                if not html:
                    continue

                # Each result row is a tgxtablerow div.  Within each row:
                #   title  — <a class="txlight" href="/torrent/...">Name</a>
                #   magnet — <a href="magnet:?xt=urn:btih:...">
                #   seeds  — green-coloured span immediately after the seeders label:
                #            <font color="green"><b>N</b></font>  or
                #            <span class="badge badge-success">N</span>

                # Split into rows first so title/magnet/seeds stay aligned
                rows = re.split(r'<div[^>]+class="[^"]*tgxtablerow[^"]*"', html)[1:]
                if not rows:
                    # Fallback: pair magnets with titles positionally
                    magnets = re.findall(r'href="(magnet:\?[^"]+)"', html)
                    titles  = re.findall(r'class="[^"]*txlight[^"]*"[^>]*>([^<]+)</a>', html)
                    rows_fallback = list(zip(titles, magnets))
                    if not rows_fallback:
                        continue
                    results = []
                    for title, magnet in rows_fallback[:25]:
                        title = title.strip()
                        results.append({
                            'title': title, 'magnet': magnet, 'seeds': 0,
                            'quality': detect_quality(title), 'source': 'TorrentGalaxy',
                        })
                    xbmc.log(f'COSMOS TorrentGalaxy: {len(results)} results (fallback)', xbmc.LOGDEBUG)
                    return results

                results = []
                for row in rows[:25]:
                    mag_m   = re.search(r'href="(magnet:\?[^"]+)"', row)
                    title_m = re.search(r'class="[^"]*txlight[^"]*"[^>]*>([^<]{4,})</a>', row)
                    if not mag_m or not title_m:
                        continue
                    magnet = mag_m.group(1)
                    title  = title_m.group(1).strip()

                    # Seeds: green badge / font tag right before leechers
                    seeds = 0
                    s_m = re.search(
                        r'(?:<font[^>]+green[^>]*><b>|<span[^>]+badge-success[^>]*>)(\d+)',
                        row)
                    if not s_m:
                        # broader fallback: first standalone number in a green context
                        s_m = re.search(r'color[=:\s"\']*green[^>]*>\s*(?:<b>)?(\d+)', row)
                    if s_m:
                        try:
                            seeds = int(s_m.group(1))
                        except ValueError:
                            pass

                    results.append({
                        'title': title, 'magnet': magnet, 'seeds': seeds,
                        'quality': detect_quality(title), 'source': 'TorrentGalaxy',
                    })

                xbmc.log(f'COSMOS TorrentGalaxy: {len(results)} results from {mirror}', xbmc.LOGDEBUG)
                return results

            except Exception as e:
                xbmc.log(f'COSMOS TorrentGalaxy {mirror} failed: {e}', xbmc.LOGWARNING)

        return []


class _L337xResultsParser(HTMLParser):
    """Keep torrent titles and seed counts attached to their own table row."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.results = []
        self.row = None
        self.cell = ''
        self.anchor = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'tr':
            self.row = {'links': [], 'seeds': ''}
        elif self.row is not None:
            if tag == 'td':
                classes = set((attrs.get('class') or '').split())
                self.cell = 'name' if 'name' in classes else 'seeds' if 'seeds' in classes else ''
            elif tag == 'a' and self.cell == 'name':
                path = attrs.get('href') or ''
                if re.match(r'^/torrent/\d+/[^?#]*', path):
                    self.anchor = {'path': path, 'text': ''}

    def handle_data(self, data):
        if self.row is not None:
            if self.cell == 'seeds':
                self.row['seeds'] += data
            if self.anchor is not None:
                self.anchor['text'] += data

    def handle_endtag(self, tag):
        if tag == 'a' and self.anchor is not None:
            if self.row is not None:
                self.row['links'].append(self.anchor)
            self.anchor = None
        elif tag == 'td':
            self.cell = ''
        elif tag == 'tr' and self.row is not None:
            links = [link for link in self.row['links'] if link['text'].strip()]
            if links:
                link = links[-1]
                seeds = re.sub(r'[\s,]', '', self.row['seeds'])
                self.results.append({
                    'path': link['path'], 'title': link['text'].strip(),
                    'seeds': int(seeds) if seeds.isdigit() else 0,
                })
            self.row = None
            self.cell = ''
            self.anchor = None


class L337xScraper:
    """1337x torrent scraper.

    Strategy:
      1. Fetch the search results page — parse titles, seeds, and torrent
         page paths from the HTML without any additional requests.
      2. Sort the candidates by seed count descending.
      3. Fetch ONLY the top-5 torrent pages in parallel (via ThreadPoolExecutor)
         to extract their magnet links.
      This caps total HTTP requests at 6 (1 search + 5 torrent pages) regardless
      of how many results the search page returns.
    """

    MIRRORS = [
        'https://1337x.to',
        'https://x1337x.cc',
        'https://x1337x.eu',
        'https://x1337x.se',
        'https://1337x.st',
        'https://1337x.gd',
        'https://x1337x.ws',
    ]

    def __init__(self):
        self.enabled = _setting_enabled('enable_1337x')
        self.mirrors = _configured_mirrors('1337x_url', self.MIRRORS)

    @staticmethod
    def _get_magnet(mirror, path, timeout=12):
        """Fetch a single torrent page and return its magnet link or ''."""
        html = _http_get(f'{mirror}{path}', timeout=timeout)
        if not html:
            return ''
        for match in re.finditer(r'''href\s*=\s*(["'])(magnet:\?[^"']+)\1''', html, re.I):
            magnet = unescape(match.group(2))
            if extract_hash(magnet):
                return magnet
        return ''

    @staticmethod
    def _parse_search_results(html):
        parser = _L337xResultsParser()
        parser.feed(html)
        parser.close()
        seen = set()
        results = []
        for result in parser.results:
            if result['path'] not in seen:
                seen.add(result['path'])
                results.append(result)
        return results

    def search(self, query):
        if not self.enabled:
            return []

        import concurrent.futures

        for mirror in self.mirrors:
            try:
                search_url = f'{mirror}/search/{quote_plus(query)}/1/'
                html = _http_get(search_url, timeout=6)
                if not html:
                    continue

                # ── Parse the search-results page ──────────────────────────
                # Title + torrent-page link live together inside .coll-1.name:
                #   <td class="coll-1 name">
                #     <a href="/torrent/NNN/name/">…icon…</a>
                #     <a href="/torrent/NNN/name/">Title Text</a>
                #   </td>
                # Seeds are in:  <td class="coll-2 seeds">NNN</td>

                candidates = self._parse_search_results(html)

                xbmc.log(f'COSMOS 1337x: {len(candidates)} candidates from {mirror}', xbmc.LOGDEBUG)
                if not candidates:
                    continue

                # Sort by seeds, take top 5 only — avoids serial waterfall of requests
                candidates.sort(key=lambda x: x['seeds'], reverse=True)
                top = candidates[:5]

                # ── Fetch the top torrent pages in parallel ─────────────
                results = []
                with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
                    futures = {
                        pool.submit(self._get_magnet, mirror, c['path']): c
                        for c in top
                    }
                    for fut in concurrent.futures.as_completed(futures):
                        c = futures[fut]
                        try:
                            magnet = fut.result()
                        except Exception:
                            magnet = ''
                        if not magnet:
                            continue
                        results.append({
                            'title':   c['title'],
                            'magnet':  magnet,
                            'seeds':   c['seeds'],
                            'quality': detect_quality(c['title']),
                            'source':  '1337x',
                        })

                xbmc.log(f'COSMOS 1337x: {len(results)} results with magnets', xbmc.LOGDEBUG)
                if results:
                    return results
                # No magnets resolved on this mirror — try next

            except Exception as e:
                xbmc.log(f'COSMOS 1337x {mirror} failed: {e}', xbmc.LOGWARNING)

        return []


class TorrentioScraper:
    """Torrentio (Stremio-style public community API) scraper.

    Docs: https://torrentio.strem.fun/
    Endpoint pattern:
        /stream/movie/{imdb_id}.json
        /stream/series/{imdb_id}:{season}:{episode}.json
    """

    BASE_URL = "https://torrentio.strem.fun"

    def __init__(self):
        self.enabled = _setting_enabled('enable_torrentio')

    def _parse_stream(self, stream):
        """Convert a Torrentio stream record into a standard result dict."""
        if not isinstance(stream, dict):
            return None
        info_hash = str(stream.get('infoHash') or stream.get('info_hash') or '').strip()
        if not re.fullmatch(r'(?:[A-Fa-f0-9]{40}|[A-Za-z2-7]{32})', info_hash):
            return None

        # Clean title: prefer behaviorHints.filename (no emoji), fall back to
        # first non-empty line of the title/description field.
        hints   = stream.get('behaviorHints') or {}
        if not isinstance(hints, dict):
            hints = {}
        filename = (hints.get('filename') or '').strip()
        raw_title = stream.get('title', '') or stream.get('name', '')
        if filename:
            display_title = filename
        else:
            first_line = raw_title.split('\n')[0].strip()
            # Strip leading emoji / special chars
            display_title = re.sub(r'^[\U00010000-\U0010ffff\u2000-\u3300\s]+', '', first_line).strip() or first_line

        quality = detect_quality(display_title + ' ' + raw_title)

        # Seeds: Torrentio puts "👤 N" in the title field
        seeds = _extract_seed_count(raw_title)

        # Provider label (first line of the name field)
        provider = stream.get('name', '').split('\n')[0].strip() or 'Torrentio'

        trackers = _clean_tracker_sources(stream.get('sources'))
        tr_query = '&'.join(f'tr={quote_plus(t)}' for t in trackers)
        magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={quote_plus(display_title)}&{tr_query}"
        file_idx = stream.get('fileIdx')
        if type(file_idx) is int and file_idx >= 0:
            magnet += f'&so={file_idx}'

        return {
            'title': display_title,
            'magnet': magnet,
            'seeds': seeds,
            'quality': quality,
            'source': f'Torrentio/{provider}',
        }

    def search_imdb(self, imdb_id, content='movie', season=None, episode=None):
        """Primary search method using IMDB id (preferred by Torrentio)."""
        if not self.enabled or not imdb_id:
            return []
        imdb_id = str(imdb_id).strip()
        if not imdb_id.startswith('tt'):
            imdb_id = f'tt{imdb_id}'

        if content == 'movie':
            url = f"{self.BASE_URL}/stream/movie/{imdb_id}.json"
        else:
            if season is None or episode is None:
                return []
            url = f"{self.BASE_URL}/stream/series/{imdb_id}:{season}:{episode}.json"

        data = _http_get_json(url, timeout=25)
        if not isinstance(data, dict) or not isinstance(data.get('streams'), list):
            xbmc.log(f'COSMOS Torrentio: no streams in response for {url}', xbmc.LOGDEBUG)
            return []

        results = []
        for stream in data.get('streams', [])[:60]:
            try:
                r = self._parse_stream(stream)
            except (TypeError, ValueError, AttributeError):
                continue
            if r:
                results.append(r)
        xbmc.log(f'COSMOS Torrentio: got {len(results)} results', xbmc.LOGDEBUG)
        return results

    def search(self, query):
        """Torrentio requires IMDB id - this text search fallback returns nothing."""
        return []


def _is_tv_match(title, season, episode):
    """Return True if a torrent title matches the requested season+episode
    (single episode OR a valid season pack / complete series pack).

    Accepts patterns like:
        S01E01, s01.e01, s01 e01, 1x01, Season 1 Episode 1
        Season 1, S01 (pack), Complete Series / Complete Season
    """
    if not title:
        return False
    t = title.lower()

    try:
        s = int(season)
        e = int(episode)
    except (TypeError, ValueError):
        return True  # Can't validate - keep it

    # Exact episode patterns
    ep_patterns = [
        rf's0*{s}\s*[\.\-_ ]?\s*e0*{e}\b',
        rf's0*{s}e0*{e}\b',
        rf'\b{s}\s*x\s*0*{e}\b',
        rf'season[\s\.\-_]*0*{s}[\s\.\-_]*episode[\s\.\-_]*0*{e}\b',
    ]
    for pat in ep_patterns:
        if re.search(pat, t):
            return True

    # Season-pack / complete-series patterns (no episode marker in title)
    has_episode_marker = re.search(r's\d{1,2}\s*[\.\-_ ]?\s*e\d{1,3}|\d{1,2}x\d{1,3}|episode\s*\d+', t)
    if not has_episode_marker:
        # If the title mentions an explicit season number, it must match.
        season_nums = [int(n) for n in re.findall(r's(\d{1,2})(?!\d)', t)]
        season_nums += [int(n) for n in re.findall(r'season[\s\.\-_]*(\d{1,2})', t)]
        season_nums += [int(n) for n in re.findall(r'(\d{1,2})(?:st|nd|rd|th)[\s\.\-_]*season', t)]
        if season_nums:
            return s in season_nums
        # No explicit season -> accept only complete-series packs
        if re.search(r'\bcomplete[\s\.\-_]*(series|collection|seasons?)\b', t) or \
           re.search(r'\bseasons?\b[\s\.\-_]*\bcomplete\b', t) or \
           re.search(r'\ball[\s\.\-_]*seasons?\b', t):
            return True

    return False


class CometScraper:
    """Comet (Stremio-style public torrent API) scraper.

    Docs: https://github.com/g0ldyy/comet/blob/main/docs/advanced/06-http-api-reference.md
    Endpoint pattern:
        /stream/movie/{imdb_id}.json
        /stream/series/{imdb_id}:{season}:{episode}.json

    Returns infoHash + trackers (sources) + optional fileIdx, same shape as
    Torrentio but with richer quality labels in the stream name.
    """

    # The former comet.feels.legal endpoint currently presents a certificate
    # for the wrong hostname. Do not weaken TLS verification to use it.
    # Midnight's maintained public mirror speaks the same Comet v2 protocol
    # and is verified against Kodi's Python/OpenSSL networking stack.
    BASE_URLS = (
        'https://cometfortheweebs.midnightignite.me',
    )

    def __init__(self):
        self.enabled = _setting_enabled('enable_comet')
        self.base_url = _normalise_stremio_base_url(
            ADDON.getSetting('comet_url'), self.BASE_URLS[0])

    def _parse_stream(self, stream):
        """Convert a Comet stream record into a standard result dict."""
        if not isinstance(stream, dict):
            return None
        name = stream.get('name', '')        # e.g. "[TORRENT🧲] Comet 1080p"
        desc = stream.get('description', '') # codec, size, seeders lines
        info_hash = stream.get('infoHash', '')
        if not isinstance(info_hash, str) or not re.fullmatch(r'[a-fA-F0-9]{40}', info_hash):
            return None
        info_hash = info_hash.lower()

        # Clean title: prefer behaviorHints.filename (clean, no emoji).
        # Fall back to stripping emoji prefix off the first description line.
        hints    = stream.get('behaviorHints') or {}
        if not isinstance(hints, dict):
            hints = {}
        filename = (hints.get('filename') or '').strip()
        if filename:
            title = filename
        else:
            raw_line = desc.split('\n')[0].strip() if desc else name
            title = re.sub(r'^[\U00010000-\U0010ffff\u2000-\u3300\s]+', '', raw_line).strip() or raw_line

        # Filter before applying Comet's per-quality limits as well as the
        # shared Link Zero filter. A release title can differ from filename.
        game_category = stream.get('category', '')
        if any(_is_game_source({'title': candidate, 'category': game_category})
               for candidate in (title, stream.get('title') or '')):
            return None

        # Quality from name label (most reliable for Comet)
        quality = detect_quality(name + ' ' + title)

        # Seeds: Comet puts "👤 N" anywhere in the description
        seeds = _extract_seed_count(desc)

        # Trackers — Comet provides clean udp:// URLs directly
        trackers = _clean_tracker_sources(stream.get('sources'))
        tr_query = '&'.join(f'tr={quote_plus(t)}' for t in trackers)
        magnet = f"magnet:?xt=urn:btih:{info_hash}&dn={quote_plus(title)}&{tr_query}"

        file_idx = stream.get('fileIdx')
        if type(file_idx) is int and file_idx >= 0:
            magnet += f'&so={file_idx}'

        try:
            size = max(0, int(hints.get('videoSize') or 0))
        except (TypeError, ValueError, OverflowError):
            size = 0

        return {
            'title': title,
            'magnet': magnet,
            'seeds': seeds,
            'quality': quality,
            'source': 'Comet',
            'size': size,
            'size_label': f'{size / 1073741824:.1f} GB' if size else '',
        }

    def search_imdb(self, imdb_id, content='movie', season=None, episode=None):
        """Fetch streams from Comet by IMDB id."""
        if not self.enabled or not imdb_id:
            return []
        if not imdb_id.startswith('tt'):
            imdb_id = f'tt{imdb_id}'

        if content != 'movie' and (season is None or episode is None):
            return []

        data = None
        url = ''
        for base_url in (self.base_url,):
            if content == 'movie':
                url = f'{base_url}/stream/movie/{imdb_id}.json'
            else:
                url = f'{base_url}/stream/series/{imdb_id}:{season}:{episode}.json'
            data = _http_get_json(url, timeout=12)
            if isinstance(data, dict) and isinstance(data.get('streams'), list):
                break
            xbmc.log('COSMOS Comet: endpoint unavailable or invalid response', xbmc.LOGDEBUG)
        if not isinstance(data, dict) or not isinstance(data.get('streams'), list):
            return []

        results = []
        quality_counts = {}
        seen = set()
        for stream in data.get('streams', []):
            r = self._parse_stream(stream)
            if r:
                if r['magnet'] in seen or quality_counts.get(r['quality'], 0) >= 60:
                    continue
                seen.add(r['magnet'])
                quality_counts[r['quality']] = quality_counts.get(r['quality'], 0) + 1
                results.append(r)
        xbmc.log(f'COSMOS Comet: got {len(results)} results', xbmc.LOGDEBUG)
        return results

    def search(self, query):
        """Comet requires an IMDB id — text search is not supported."""
        return []


class MediaFusionScraper:
    """MediaFusion (Stremio-compatible) scraper.

    Works with any public or self-hosted MediaFusion instance.
    The base URL is configurable in Settings → Scrapers.

    Endpoint pattern (no auth token required for public instances):
        /stream/movie/{imdb_id}.json
        /stream/series/{imdb_id}:{season}:{episode}.json

    Cosmos uses infoHash torrent streams with its own Debrid resolver.
    URL-only provider streams and status messages are not torrent sources.
    """

    DEFAULT_URL = 'https://mediafusionfortheweebs.midnightignite.me'

    def __init__(self):
        self.enabled = _setting_enabled('enable_mediafusion')
        self.base_url = _normalise_stremio_base_url(
            ADDON.getSetting('mediafusion_url'), self.DEFAULT_URL)

    @staticmethod
    def _clean_sources(raw_sources):
        """Strip the 'tracker:' prefix MediaFusion adds, drop dht: entries."""
        return _clean_tracker_sources(raw_sources)

    def _parse_stream(self, stream):
        """Convert a MediaFusion stream record into a standard result dict."""
        if not isinstance(stream, dict):
            return None
        name       = stream.get('name', '')
        desc       = stream.get('description', '') or stream.get('title', '')
        info_hash  = stream.get('infoHash', '')
        if not isinstance(info_hash, str) or not re.fullmatch(r'[a-fA-F0-9]{40}', info_hash):
            return None
        info_hash = info_hash.lower()

        # Clean title: behaviorHints.filename is always present and emoji-free
        hints    = stream.get('behaviorHints') or {}
        if not isinstance(hints, dict):
            hints = {}
        filename = (hints.get('filename') or '').strip()
        if filename:
            title = filename
        else:
            raw_line = desc.split('\n')[0].strip() if desc else name
            title = re.sub(r'^[\U00010000-\U0010ffff\u2000-\u3300\s]+', '', raw_line).strip() or raw_line

        quality = detect_quality(name + ' ' + title)

        # Seeds: "👤 N" anywhere in description
        seeds = _extract_seed_count(desc)

        if info_hash:
            trackers = self._clean_sources(stream.get('sources'))
            tr_query = '&'.join(f'tr={quote_plus(t)}' for t in trackers)
            link = f'magnet:?xt=urn:btih:{info_hash}&dn={quote_plus(title)}&{tr_query}'
            file_idx = stream.get('fileIdx')
            if type(file_idx) is int and file_idx >= 0:
                link += f'&so={file_idx}'

        try:
            size = max(0, int(hints.get('videoSize') or 0))
        except (TypeError, ValueError, OverflowError):
            size = 0

        return {
            'title':   title,
            'magnet':  link,
            'seeds':   seeds,
            'quality': quality,
            'source':  'MediaFusion',
            'size': size,
            'size_label': f'{size / 1073741824:.1f} GB' if size else '',
        }

    def search_imdb(self, imdb_id, content='movie', season=None, episode=None):
        """Fetch streams from MediaFusion by IMDB id."""
        if not self.enabled or not imdb_id:
            return []
        if not imdb_id.startswith('tt'):
            imdb_id = f'tt{imdb_id}'

        if content == 'movie':
            url = f'{self.base_url}/stream/movie/{imdb_id}.json'
        else:
            if season is None or episode is None:
                return []
            url = f'{self.base_url}/stream/series/{imdb_id}:{season}:{episode}.json'

        data = _http_get_json(url, timeout=25)
        if not isinstance(data, dict) or not isinstance(data.get('streams'), list):
            xbmc.log('COSMOS MediaFusion: invalid or missing streams response', xbmc.LOGDEBUG)
            return []

        results = []
        quality_counts = {}
        seen = set()
        for stream in data.get('streams', []):
            r = self._parse_stream(stream)
            if r:
                if r['magnet'] in seen or quality_counts.get(r['quality'], 0) >= 60:
                    continue
                seen.add(r['magnet'])
                quality_counts[r['quality']] = quality_counts.get(r['quality'], 0) + 1
                results.append(r)
        xbmc.log(f'COSMOS MediaFusion: got {len(results)} results', xbmc.LOGDEBUG)
        return results

    def search(self, query):
        """MediaFusion requires an IMDB id — text search is not supported."""
        return []


class AIOStreamsScraper:
    """AIOStreams REST API integration using a saved UUID and password.

    The API returns already filtered and sorted results from the user's
    configured sources. Cosmos requests hash-backed entries so they continue
    through its normal debrid resolver and file-selection flow.
    """

    def __init__(self):
        self.enabled = (
            ADDON.getSetting('aio_auth_done') == 'true'
            and ADDON.getSetting('aio_enabled') == 'true'
        )
        self.base_url = self._normalise_url(ADDON.getSetting('aio_url'))
        self.username = (ADDON.getSetting('aio_username') or '').strip()
        self.password = ADDON.getSetting('aio_password') or ''

    @staticmethod
    def _normalise_url(value):
        base = (value or '').strip().rstrip('/')
        if not base:
            return ''
        if not re.match(r'^https?://', base, re.I):
            base = 'https://' + base.lstrip('/')
        # Accept the instance root as well as URLs copied from the API or
        # Stremio configuration pages.
        base = re.sub(r'/api/v1$', '', base, flags=re.I)
        base = re.sub(r'/stremio/configure$', '', base, flags=re.I)
        base = re.sub(r'/(?:configure|manifest\.json)$', '', base, flags=re.I)
        return base.rstrip('/')

    def _auth_headers(self):
        token = base64.b64encode(
            f'{self.username}:{self.password}'.encode('utf-8')).decode('ascii')
        return {'Authorization': f'Basic {token}'}

    @classmethod
    def validate_credentials(cls, base_url, username, password):
        """Check a saved configuration without running a media search or saving it."""
        base = cls._normalise_url(base_url)
        username = (username or '').strip()
        if not base or not username or not password:
            return False, 'Enter server URL, UUID/alias and password'
        token = base64.b64encode(
            f'{username}:{password}'.encode('utf-8')).decode('ascii')
        try:
            request = Request(base + '/api/v1/user', headers={
                'User-Agent': USER_AGENT, 'Authorization': f'Basic {token}',
            }, method='GET')
            with urlopen(request, timeout=15) as response:
                data = json.loads(response.read().decode('utf-8'))
        except HTTPError as error:
            if error.code in (400, 401, 403):
                return False, 'Login rejected: check UUID/alias and password'
            if error.code == 404:
                return False, 'Configuration or AIO Streams API not found: check server and UUID/alias'
            return False, 'AIO Streams server error; try again later'
        except (URLError, OSError):
            return False, 'Cannot reach AIO Streams server; check URL and connection'
        except (ValueError, TypeError, UnicodeError):
            return False, 'Invalid AIO Streams server response; check server URL'
        if (isinstance(data, dict) and data.get('success') is True
                and isinstance(data.get('data'), dict)
                and isinstance(data['data'].get('userData'), dict)):
            return True, ''
        return False, 'AIO Streams login failed: check server, UUID/alias and password'

    @staticmethod
    def _parse_result(stream):
        info_hash = str(stream.get('infoHash') or '').strip()
        if not re.fullmatch(r'(?:[A-Fa-f0-9]{40}|[A-Za-z2-7]{32})', info_hash):
            return None

        parsed = stream.get('parsedFile') or {}
        filename = str(stream.get('filename') or '').strip()
        folder = str(stream.get('folderName') or '').strip()
        title = filename or folder or str(stream.get('message') or '').strip()
        if not title:
            title = f'AIOStreams {info_hash[:8]}'

        quality_context = ' '.join((
            title,
            str(parsed.get('resolution') or '') if isinstance(parsed, dict) else '',
            str(parsed.get('quality') or '') if isinstance(parsed, dict) else '',
        ))
        trackers = _clean_tracker_sources(stream.get('sources'))
        magnet = (
            f'magnet:?xt=urn:btih:{info_hash}'
            f'&dn={quote_plus(title)}'
            + ''.join(f'&tr={quote_plus(t)}' for t in trackers)
        )
        file_idx = stream.get('fileIdx')
        if isinstance(file_idx, int) and file_idx >= 0:
            magnet += f'&so={file_idx}'

        provider = str(stream.get('addon') or stream.get('indexer') or '').strip()
        source = 'AIOStreams' + (f'/{provider}' if provider else '')
        return {
            'title': title,
            'magnet': magnet,
            'seeds': int(stream.get('seeders') or 0),
            'quality': detect_quality(quality_context),
            'source': source,
            'cached': bool(stream.get('cached')),
            'size': int(stream.get('size') or 0),
        }

    def search_imdb(self, imdb_id, content='movie', season=None, episode=None):
        if not self.enabled or not self.base_url or not self.username or not self.password:
            return []
        media_id = str(imdb_id or '').strip()
        if not media_id:
            return []
        if not media_id.startswith('tt'):
            media_id = 'tt' + media_id
        media_type = 'movie' if content == 'movie' else 'series'
        if media_type == 'series':
            if season is None or episode is None:
                return []
            media_id = f'{media_id}:{season}:{episode}'

        url = (
            f'{self.base_url}/api/v1/search?type={media_type}'
            f'&id={quote_plus(media_id)}&requiredFields=infoHash&format=true'
        )
        data = _http_get_json(url, headers=self._auth_headers(), timeout=25)
        if not isinstance(data, dict) or not data.get('success'):
            error = data.get('error') if isinstance(data, dict) else None
            if isinstance(error, dict):
                error = error.get('message') or error.get('code') or error
            elif not error and isinstance(data, dict):
                error = data.get('detail')
            xbmc.log(f'COSMOS AIOStreams: search failed: {error}', xbmc.LOGWARNING)
            return []
        payload = data.get('data') or {}
        results = []
        for stream in (payload.get('results') or [])[:100]:
            if not isinstance(stream, dict):
                continue
            try:
                parsed = self._parse_result(stream)
            except (TypeError, ValueError, AttributeError) as error:
                xbmc.log(f'COSMOS AIOStreams: skipped malformed result: {error}', xbmc.LOGWARNING)
                continue
            if parsed:
                results.append(parsed)
        xbmc.log(f'COSMOS AIOStreams: got {len(results)} results', xbmc.LOGDEBUG)
        return results


class EasynewsScraper:
    """EasyNews scraper based on Redlight's implementation."""

    def __init__(self):
        self.enabled = ADDON.getSetting('easynews_enabled') == 'true'
        self.sources = []
        self.extras = ('sample', 'extra', 'extras', 'deleted', 'password', 'trailer')

    def _clean_title(self, title):
        return re.sub(r'[^A-Za-z0-9\s]+', '', title).lower()

    def _search_name(self):
        if self.media_type == 'movie':
            return f'{self.search_title} {self.year}'
        return f'{self.search_title} S{self.season:02d}E{self.episode:02d}'

    def _add_query(self, queries, seen, query):
        if query and query not in seen:
            seen.add(query)
            queries.append(query)

    def _search_queries(self):
        primary = self._search_name()
        seen = {primary}
        queries = [primary]
        if self.media_type == 'movie':
            self._add_query(queries, seen, self.search_title)
        else:
            self._add_query(queries, seen, f'{self.search_title} S{self.season:02d}')
        if self.media_type != 'movie':
            self._add_query(queries, seen, self.search_title)
        for alias in self.aliases:
            name = self._clean_title(alias).replace('&', 'and')
            if name == self.search_title: continue
            if self.media_type == 'movie':
                self._add_query(queries, seen, f'{name} {self.year}')
                self._add_query(queries, seen, name)
            else:
                self._add_query(queries, seen, f'{name} S{self.season:02d}E{self.episode:02d}')
                self._add_query(queries, seen, f'{name} S{self.season:02d}')
        return queries

    def _merge_searches(self, queries):
        from resources.lib.easynews import EasyNews
        files = []
        seen = set()
        for query in queries:
            for item in EasyNews.search(query) or []:
                url = item.get('url_dl')
                if url and url not in seen:
                    seen.add(url)
                    files.append(item)
        return files

    def _quality_estimate(self, width):
        if width > 1920: return '2160p'
        if 1280 < width <= 1920: return '1080p'
        if 720 < width <= 1280: return '720p'
        return '480p'

    def search(self, query, season='', episode=''):
        if not self.enabled:
            return []
        # A scraper instance may be reused by callers; never leak results
        # from a previous title into the next search.
        self.sources = []
        self.media_type = 'episode' if season else 'movie'
        self.season = int(season) if season else 0
        self.episode = int(episode) if episode else 0
        match = re.search(r'\s(\d{4})$', query)
        if match:
            self.year = int(match.group(1))
            self.search_title = self._clean_title(query[:match.start()])
        else:
            self.year = 0
            self.search_title = self._clean_title(query)
        self.aliases = []
        files = self._merge_searches(self._search_queries())
        for item in files:
            item_name = item.get('name') or ''
            if item.get('short_vid', False) or any(x in item_name.lower() for x in self.extras): continue
            source = {
                'title': item_name,
                'url': item.get('url_dl', ''),
                'quality': self._quality_estimate(int(item.get('width', 0) or 0)),
                'size': round(float(item.get('rawSize', 0) or 0) / 1073741824, 2),
                'source': 'EasyNews',
            }
            # Keep an NZB URL, when the upstream result provides one, for the
            # optional SABnzbd/NZBGet path.  Direct Easynews playback remains
            # the fallback when this field is absent.
            nzb_url = item.get('nzb_url') or item.get('nzbURL') or item.get('nzbUrl')
            if nzb_url:
                source['nzb_url'] = nzb_url
            for key in ('hash', 'fileId', 'filename', 'ext', 'sig'):
                if item.get(key) not in (None, ''):
                    source[key] = item[key]
            self.sources.append(source)
        return self.sources

def search_all(query, preferred_quality='1080p', imdb_id=None, content='movie', season=None, episode=None):
    """Search all enabled scrapers in parallel and return sorted results.

    IMDB-based scrapers (AIOStreams, Torrentio, Comet, MediaFusion) fire when an IMDB id
    is available.  Text scrapers (PirateBay, TorrentGalaxy, 1337x) fire
    simultaneously via ThreadPoolExecutor so every source is queried at once.

    For TV content, text-scraper results are filtered to only keep torrents
    that match the requested season+episode (or a valid season/complete pack).
    """
    import queue
    import threading
    import time

    xbmc.log(
        f'COSMOS [SCRAPER] search_all  query={query!r}  preferred={preferred_quality!r}'
        f'  imdb={imdb_id!r}  content={content!r}'
        f'  season={season!r}  episode={episode!r}',
        xbmc.LOGDEBUG,
    )

    is_tv = content and str(content).lower() != 'movie'

    # ── Build task list (name, callable, args) ────────────────────────────
    _IMDB = 'imdb'
    _TEXT = 'text'
    _USENET = 'usenet' # New category for Usenet sources

    tasks = []
    if imdb_id:
        tasks.append((_IMDB, 'AIOStreams',   AIOStreamsScraper().search_imdb,  (imdb_id, content, season, episode)))
        tasks.append((_IMDB, 'Torrentio',    TorrentioScraper().search_imdb,   (imdb_id, content, season, episode)))
        tasks.append((_IMDB, 'Comet',         CometScraper().search_imdb,       (imdb_id, content, season, episode)))
        tasks.append((_IMDB, 'MediaFusion',   MediaFusionScraper().search_imdb, (imdb_id, content, season, episode)))

    tasks.append((_TEXT, 'PirateBay',     PirateBayScraper().search,  (query,)))
    tasks.append((_TEXT, 'TorrentGalaxy', TorrentGalaxy().search,     (query,)))
    tasks.append((_TEXT, '1337x',         L337xScraper().search,      (query,)))
    
    # Add EasyNews scraper
    tasks.append((_USENET, 'EasyNews', EasynewsScraper().search, (query, season, episode)))

    # ── Run every scraper in parallel ─────────────────────────────────────
    imdb_results = []
    text_results = []
    usenet_results = [] # New list for Usenet results
    xbmc.log(
        f'COSMOS [SCRAPER] search_all  dispatching {len(tasks)} scrapers:'
        f' {[n for _,n,_,_ in tasks]}',
        xbmc.LOGDEBUG,
    )

    # Executor workers are non-daemon and are joined during interpreter
    # shutdown. A stalled provider could therefore keep default.py alive until
    # Kodi forcibly killed it. Bounded daemon workers preserve parallelism
    # without letting one provider block an episode transition.
    completed = queue.Queue()

    def _run_scraper(kind, name, fn, args):
        try:
            completed.put((kind, name, fn(*args) or [], None))
        except Exception as exc:
            completed.put((kind, name, [], exc))

    for kind, name, fn, args in tasks:
        threading.Thread(
            target=_run_scraper,
            args=(kind, name, fn, args),
            name=f'cosmos-scraper-{name.lower()}',
            daemon=True,
        ).start()

    pending = len(tasks)
    deadline = time.monotonic() + SEARCH_ALL_TIMEOUT_SECONDS
    monitor = xbmc.Monitor()
    while pending and time.monotonic() < deadline:
        if monitor.abortRequested():
            xbmc.log('COSMOS [SCRAPER] abort requested; leaving provider workers', xbmc.LOGDEBUG)
            break
        try:
            kind, name, results, error = completed.get(
                timeout=min(0.25, max(0.01, deadline - time.monotonic())))
        except queue.Empty:
            continue
        pending -= 1
        if error is not None:
            xbmc.log(f'COSMOS [SCRAPER] {name}  FAILED: {error}', xbmc.LOGWARNING)
            continue
        xbmc.log(
            f'COSMOS [SCRAPER] {name}  returned {len(results)} results  kind={kind}',
            xbmc.LOGDEBUG,
        )
        if kind == _IMDB:
            imdb_results.extend(results)
        elif kind == _USENET:
            usenet_results.extend(results)
        else:
            text_results.extend(results)

    if pending:
        xbmc.log(
            f'COSMOS [SCRAPER] timed out waiting for {pending} provider(s)',
            xbmc.LOGWARNING,
        )

    # ── TV episode filtering for text scrapers ────────────────────────────
    imdb_hashes = set()
    for r in imdb_results:
        h = extract_hash(r.get('magnet', ''))
        if h:
            imdb_hashes.add(h)

    if is_tv and season is not None and episode is not None:
        filtered = []
        for r in text_results:
            h = extract_hash(r.get('magnet', ''))
            if h and h in imdb_hashes:
                continue  # already returned by an IMDB scraper
            if _is_tv_match(r.get('title', ''), season, episode):
                filtered.append(r)
            else:
                xbmc.log(
                    f"COSMOS: skip wrong-episode torrent: {r.get('title', '')[:80]}",
                    xbmc.LOGDEBUG,
                )
        text_results = filtered
        
        # Apply TV episode filtering for Usenet results as well
        filtered_usenet = []
        for r in usenet_results:
            if _is_tv_match(r.get('title', ''), season, episode):
                filtered_usenet.append(r)
            else:
                xbmc.log(
                    f"COSMOS: skip wrong-episode EasyNews: {r.get('title', '')[:80]}",
                    xbmc.LOGDEBUG,
                )
        usenet_results = filtered_usenet

    all_results = imdb_results + text_results + usenet_results # Combine all results

    xbmc.log(
        f'COSMOS [SCRAPER] search_all  pre-dedup: imdb={len(imdb_results)}'
        f'  text={len(text_results)}  total={len(all_results)}',
        xbmc.LOGDEBUG,
    )

    # ── Deduplicate by info hash ──────────────────────────────────────────
    # EasyNews results don't have info hashes, so we don't deduplicate them this way.
    seen   = set()
    unique = []
    for r in all_results:
        if _is_game_source(r):
            xbmc.log(f"COSMOS: skip game/software source: {r.get('title', '')[:80]}",
                     xbmc.LOGDEBUG)
            continue
        if r.get('magnet'): # Only deduplicate torrents
            h = extract_hash(r.get('magnet', ''))
            if h and h in seen:
                continue
            if h:
                seen.add(h)
        unique.append(r)

    final = sort_by_quality(unique, preferred_quality)
    xbmc.log(
        f'COSMOS [SCRAPER] search_all  DONE unique={len(unique)}'
        f'  after_sort={len(final)}  preferred={preferred_quality!r}',
        xbmc.LOGDEBUG,
    )
    return final
