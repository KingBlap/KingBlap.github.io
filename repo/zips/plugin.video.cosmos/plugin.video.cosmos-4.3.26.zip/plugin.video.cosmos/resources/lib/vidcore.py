"""TMDB catalogue with a modal Vidcore provider picker and Kodi playback."""
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import re
import json
import base64
import uuid
from datetime import date as calendar_date

import xbmcgui
import xbmcplugin
import xbmc

from . import tmdb
from .aesgcm import aes_gcm_decrypt
from . import cinetaro
from . import vidnest
from . import vidlove
from . import srstop
from . import lulustream
from . import streamtape
from . import doodstream
from . import byse
from . import voe
from . import morencius
from . import vidara
from . import streamplay
from . import hdhub
from . import twoembed
from . import dulo

VIDROCK_AES_KEY = bytes.fromhex('7f3e9c2a8b5d1f4e6a9c3b7d2e5f8a1c4b6d9e2f5a8c1b4d7e9f2a5c8b1d4e7f')
STREAM_HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://vidrock.net/',
                  'Origin': 'https://vidrock.net', 'Accept': '*/*'}
ADAPTIVE_PROVIDERS = frozenset(('luna', 'nova', 'vidnest', 'orion', 'vidlove', 'nest', 'jupiter', 'savefiles (hls)', 'lulustream', 'streamtape', 'hdhub'))
ADAPTIVE_PROVIDERS = ADAPTIVE_PROVIDERS | {'2embed', 'doodstream', 'byse', 'voe', 'dulo', 'morencius', 'vidara', 'streamplay'}


def _has_aired(entry, today):
    """Only advertise episodes with a confirmed air date up to today."""
    try:
        return calendar_date.fromisoformat(entry.get('air_date') or '') <= today
    except (ValueError, TypeError):
        return False


def _pick_source(sources, kind, tmdb_id, season=0, episode=0, host_picker=False):
    """Use the Cosmos picker clone while retaining provider tuple indices."""
    from .source_finder_dialog import LinkPickerDialog, ADDON_PATH

    try:
        meta = tmdb.get_metadata(tmdb_id, 'movie' if kind == 'movie' else 'tvshow') or {}
    except Exception:
        meta = {}
    title = meta.get('title') or ('Movie' if kind == 'movie' else 'TV show')
    context = 'Movie' if kind == 'movie' else 'S%02d E%02d' % (season, episode)
    links = [
        {'label': 'SaveFiles' if name == 'SaveFiles (HLS)' else name,
         'meta': ('Hosts listed for %s on SRStop' % context
                  if name == 'SRStop' else '%s / %s' % (
                      context, 'Via SRStop' if host_picker else 'Checked stream')),
         'format_label': {'hls': 'HLS', 'mp4': 'MP4', 'hosts': 'HOSTS'}.get(str(stream_type).lower(), 'AUTO')}
        for name, _stream, stream_type in sources
    ]
    dialog = LinkPickerDialog(
        'SRStopHostPicker.xml' if host_picker else 'VidCoreSourcePicker.xml',
        ADDON_PATH, 'Default', '720p',
        quality_label=title, poster=meta.get('poster', ''), links=links)
    try:
        dialog.doModal()
        selected = dialog.selected_index
        return selected if selected is not None and 0 <= selected < len(sources) else -1
    finally:
        del dialog


def _pick_provider(sources, kind, tmdb_id, season, episode, srstop_hosts=()):
    """Browse SRStop hosts separately; Back returns to the provider picker."""
    types = {'SaveFiles (HLS)': 'api', 'LuluStream': 'hls',
             'Streamtape': 'mp4', 'DoodStream': 'mp4', 'Byse': 'hls', 'VOE': 'hls',
             'Morencius': 'auto', 'Vidara': 'auto', 'Streamplay': 'auto'}
    hosts = [(name, '', types[name]) for name in srstop_hosts if name in types]
    while True:
        index = _pick_source(sources, kind, tmdb_id, season, episode)
        if index < 0:
            return None
        source = sources[index]
        if source[0] != 'SRStop':
            return source
        if not hosts:
            continue
        index = _pick_source(hosts, kind, tmdb_id, season, episode, host_picker=True)
        if index >= 0:
            return hosts[index]


def _debug_bundle_event(tag, detail):
    """Write VidCore source diagnostics to the optional Cosmos debug bundle."""
    try:
        from . import debug_bundle
        if debug_bundle.is_enabled():
            debug_bundle.log('VidCore ' + str(tag), detail)
    except Exception:
        pass


def _check_picker_sources(sources, kind, tmdb_id, season, episode,
                          dulo_servers, srstop_hosts):
    """Check Vidcore providers; retain SRStop's existing host discovery."""
    from .vidcore_availability import check_sources
    jobs, groups = [], {'Dulo': [], 'HDHub': []}
    from .vidcore_scan_dialog import create_progress
    progress = create_progress()
    try:
        for name, stream, stream_type in sources:
            if name == 'SRStop':
                continue
            if name == 'Dulo':
                for index, row in enumerate(dulo_servers):
                    key = ('Dulo', index)
                    groups[name].append((key, row['label']))
                    jobs.append((key, lambda row=row: dulo.resolve_server(row['url'])))
                continue
            if name == 'HDHub':
                try:
                    candidates = hdhub.discover(tmdb_id, kind, season, episode)
                except Exception:
                    candidates = []
                for index, row in enumerate(candidates):
                    key = ('HDHub', index)
                    groups[name].append((key, row['label']))
                    jobs.append((key, lambda row=row: row))
                continue
            if name in ('VidNest', 'VidLove', '2Embed'):
                resolver = {'VidNest': vidnest, 'VidLove': vidlove, '2Embed': twoembed}[name]
                job = lambda resolver=resolver, stream=stream: resolver.resolve(stream)
            elif name == 'Nest':
                job = lambda: cinetaro.resolve(tmdb_id, kind, season, episode)
            elif name == 'Jupiter':
                job = lambda: _jupiter_source(kind, tmdb_id, season, episode)
            else:
                job = lambda stream=stream, stream_type=stream_type: {
                    'url': stream, 'type': stream_type, 'headers': dict(STREAM_HEADERS)}
            jobs.append((name, job))
        checked = check_sources(jobs, progress, xbmc.Monitor())
        if checked is None:
            return None
        hosts = list(srstop_hosts)
        groups = {name: [(key, label) for key, label in rows if key in checked]
                  for name, rows in groups.items()}
        available = []
        for name, stream, stream_type in sources:
            if name == 'SRStop':
                if hosts:
                    available.append((name, stream, 'hosts'))
            elif name in groups:
                if groups[name]:
                    available.append((name, stream, 'hosts'))
            elif name in checked:
                available.append((name, stream, checked[name]['type']))
            _debug_bundle_event('AVAILABILITY', '%s provider=%s result=%s' % (
                _media_context(kind, tmdb_id, season, episode), _safe_source_name(name),
                'available' if available and available[-1][0] == name else 'hidden'))
        return available, checked, groups, hosts
    finally:
        progress.close()


def _media_context(kind, tmdb_id, season, episode):
    return (f'media={kind} tmdb_id={tmdb_id} '
            f'season={season} episode={episode}')


def _safe_source_name(value):
    """Keep provider labels compact and single-line in exported diagnostics."""
    return re.sub(r'[^A-Za-z0-9_. -]', '?', str(value or ''))[:60]


def _jupiter_source(kind, tmdb_id, season=0, episode=0):
    """Resolve VidCore's Jupiter (Movy Phoenix) using the current TMDB ID."""
    query = {'id': tmdb_id, 'type': kind}
    if kind == 'tv':
        query.update(season=season, episode=episode)
    endpoint = 'https://vidrack.created.app/api/sources/movy?' + urlencode(query)
    with urlopen(Request(endpoint, headers={'User-Agent': 'Mozilla/5.0',
                                           'Accept': 'application/json'}), timeout=20) as response:
        data = json.loads(response.read(2 * 1024 * 1024).decode('utf-8'))
    sources = data.get('sources', []) if isinstance(data, dict) else []
    sources = [s for s in sources if isinstance(s, dict)] if isinstance(sources, list) else []
    preferred = [s for s in sources if 'phoenix-1080p' in str(s.get('provider', ''))
                 or ('Phoenix' in str(s.get('label', ''))
                     and '1080' in str(s.get('quality', '')))]
    source = next(iter(preferred), sources[1] if len(sources) > 1 else sources[0] if sources else {})
    url = source.get('url', '')
    if not isinstance(url, str) or not url.startswith(('https://', 'http://')):
        return None
    headers = {'User-Agent': 'Mozilla/5.0'}
    if isinstance(source.get('headers'), dict):
        headers.update({k: v for k, v in source['headers'].items()
                        if isinstance(k, str) and isinstance(v, str)})
    with urlopen(Request(url, headers=headers), timeout=15) as response:
        sample = response.read(4096)
        final_url = response.geturl()
    if not sample.lstrip().startswith(b'#EXTM3U'):
        return None
    return {'url': final_url, 'type': 'hls', 'headers': headers}


def _vidrock_sources(kind, tmdb_id, season=0, episode=0):
    path = 'tv/%s/%s/%s' % (tmdb_id, season, episode) if kind == 'tv' else 'movie/%s' % tmdb_id
    request = Request('https://vidrock.net/api/' + path,
                      headers={'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json'})
    data = json.loads(urlopen(request, timeout=15).read().decode('utf-8', errors='replace'))
    out = []
    for name, entry in data.items() if isinstance(data, dict) else []:
        if str(name).strip().casefold() in ('astra', 'atlas'):
            continue
        if not isinstance(entry, dict) or not entry.get('url'):
            continue
        try:
            encoded = entry['url'].replace('-', '+').replace('_', '/')
            encoded += '=' * ((4 - len(encoded) % 4) % 4)
            blob = base64.b64decode(encoded)
            url = aes_gcm_decrypt(VIDROCK_AES_KEY, blob[:12], blob[12:])
            if isinstance(url, bytes):
                url = url.decode('utf-8')
            if url.startswith(('http://', 'https://')):
                out.append((name, url, entry.get('type', 'hls')))
        except Exception as exc:
            xbmc.log('COSMOS Vidrock source %s failed: %s' % (name, exc), xbmc.LOGWARNING)
    return out


def _track_playback(li, url, params):
    """Attach TMDB identity and use the shared Cosmos playback scrobbler."""
    tmdb_id = str(params.get('tmdb_id') or '').strip()
    kind = params.get('kind', 'movie')
    if not tmdb_id.isdigit() or kind not in ('movie', 'tv'):
        return
    try:
        season = max(0, int(params.get('season') or 0))
        episode = max(0, int(params.get('episode') or 0))
    except (TypeError, ValueError):
        return
    if kind == 'tv' and episode < 1:
        return
    from . import resume as resume_mod
    try:
        details = tmdb.get_metadata(tmdb_id, 'movie' if kind == 'movie' else 'tvshow') or {}
    except Exception:
        details = {}
    content = 'movie' if kind == 'movie' else 'episode'
    meta = dict(details, tmdb=tmdb_id, content=content,
                season=str(season) if kind == 'tv' else '',
                episode=str(episode) if kind == 'tv' else '',
                imdb=details.get('imdb_id', ''), tvdb=details.get('tvdb_id', ''),
                url=url, source='vidcore')
    route = {'action': 'vidcore_episodes' if kind == 'tv' else 'vidcore_menu',
             'kind': kind, 'tmdb_id': tmdb_id}
    if kind == 'tv':
        route['season'] = season
    meta['return_url'] = 'plugin://plugin.video.cosmos/?' + urlencode(route)
    try:
        tmdb.apply_to_listitem(li, details, content=content)
        tag = li.getVideoInfoTag()
        tag.setMediaType(content)
        tag.setUniqueIDs({'tmdb': tmdb_id}, 'tmdb')
        if kind == 'tv':
            tag.setTvShowTitle(details.get('title', ''))
            tag.setSeason(season)
            tag.setEpisode(episode)
    except Exception:
        pass
    key = resume_mod.key_for(tmdb=tmdb_id, content=content,
                             season=meta['season'], episode=meta['episode'])
    resume_mod.start_tracker(key, meta=meta)


def _play_stream(handle, url, source_type='hls', provider='', stream_headers=None,
                 refresh_source='', tracking_params=None, proxy_opener=None,
                 proxy_refresh_tokens=False, native_hls=False):
    """Start a source with the headers/properties Kodi needs."""
    provider_name = str(provider or '').strip().casefold()
    stream_kind = str(source_type or '').strip().casefold()
    is_hls = stream_kind == 'hls' or '.m3u8' in url.lower()
    is_dash = stream_kind == 'dash' or '.mpd' in url.lower()
    use_adaptive = provider_name in ADAPTIVE_PROVIDERS and (is_hls or is_dash) and not (is_hls and native_hls)
    if use_adaptive and not xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
        xbmcgui.Dialog().ok(
            'Vidcore',
            'This source requires Kodi InputStream Adaptive. '
            'Please install or enable it.')
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    proxy = None
    headers_source = STREAM_HEADERS if stream_headers is None else stream_headers
    if provider_name in ('nova', 'vidnest', 'nest') or provider_name == 'dulo' and is_hls:
        from .vidcore_proxy import Proxy
        refresh_callback = None
        proxy = Proxy(
            url,
            headers_source,
            refresh_tokens=proxy_refresh_tokens if provider_name == 'dulo' else provider_name != 'nest',
            refresh_callback=refresh_callback,
            request_opener=proxy_opener)
        url = proxy.url
    headers = urlencode(headers_source)
    li = xbmcgui.ListItem(path=url if use_adaptive else url + '|' + headers)
    li.setProperty('IsPlayable', 'true')
    li.setContentLookup(False)
    if is_hls or is_dash:
        li.setMimeType('application/dash+xml' if is_dash else 'application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        if use_adaptive:
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type',
                           'mpd' if is_dash else 'hls')
            li.setProperty('inputstream.adaptive.manifest_headers', headers)
            li.setProperty('inputstream.adaptive.stream_headers', headers)
    else:
        li.setMimeType('video/x-matroska' if stream_kind == 'mkv' else 'video/mp4')
    if tracking_params:
        _track_playback(li, url, tracking_params)
    xbmcplugin.setResolvedUrl(handle, True, li)
    if proxy:
        proxy.keep_alive()


def run(action, params, handle, add_directory, build_url, icon, fanart):
    def _play_tracked_stream(*args, **kwargs):
        kwargs['tracking_params'] = params
        return _play_stream(*args, **kwargs)

    def finish(content='files', succeeded=True):
        xbmcplugin.setContent(handle, content)
        xbmcplugin.endOfDirectory(handle, succeeded=succeeded, cacheToDisc=False)

    if action == 'vidcore_play':
        kind = params.get('kind', 'movie')
        tmdb_id = str(params.get('tmdb_id', ''))
        if kind == 'movie':
            page_url = 'https://vidrock.net/movie/%s' % tmdb_id
        else:
            page_url = 'https://vidrock.net/tv/%s/%s/%s' % (
                tmdb_id, params.get('season', 0), params.get('episode', 0))
        stream = ''
        try:
            sources = _vidrock_sources(kind, tmdb_id, params.get('season', 0), params.get('episode', 0))
            if sources:
                stream = sources[0][1]
        except Exception as exc:
            xbmc.log('COSMOS Vidrock API resolver failed: %s' % exc, xbmc.LOGWARNING)
        try:
            if stream:
                raise StopIteration
            request = Request(page_url, headers={'User-Agent': 'Mozilla/5.0'})
            body = urlopen(request, timeout=15).read().decode('utf-8', errors='replace')
            candidates = re.findall(r'https?://[^\"\'<> ]+\.(?:m3u8|mp4)(?:\?[^\"\'<> ]*)?', body, re.I)
            stream = candidates[0] if candidates else ''
        except StopIteration:
            pass
        except Exception as exc:
            xbmc.log('COSMOS Vidrock resolver failed: %s' % exc, xbmc.LOGWARNING)
        if stream:
            _play_tracked_stream(handle, stream)
        else:
            # Vidrock's documented endpoint is itself the player route. Keep
            # it as the fallback so Kodi/browser-capable setups open Vidrock
            # immediately even when the site hides the final HLS URL behind JS.
            item = xbmcgui.ListItem(path=page_url)
            item.setProperty('IsPlayable', 'true')
            _track_playback(item, item.getPath(), params)
            xbmcplugin.setResolvedUrl(handle, True, item)
        return

    if action == 'vidcore_provider_play':
        stream = params.get('stream_url', '')
        if stream.startswith(('http://', 'https://')):
            item = xbmcgui.ListItem(path=stream)
            item.setProperty('IsPlayable', 'true')
            _track_playback(item, item.getPath(), params)
            xbmcplugin.setResolvedUrl(handle, True, item)
        else:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return

    def item(label, target, info=None, thumb='', folder=True, **values):
        add_directory(label, build_url(action=target, **values),
                      thumb=thumb or icon, fanart=fanart,
                      info=info or {'title': label}, is_folder=folder,
                      is_playable=target == 'vidcore_sources')

    if action == 'vidcore_root':
        item('Movies', 'vidcore_menu', kind='movie')
        item('TV Shows', 'vidcore_menu', kind='tv')
        item('Popular People', 'vidcore_people')
        finish()
        return

    if action == 'vidcore_unavailable':
        xbmcgui.Dialog().ok('Vidcore', 'Playback sources are not enabled yet.')
        return

    kind = params.get('kind', 'movie')
    if kind not in ('movie', 'tv'):
        finish(succeeded=False)
        return

    if action == 'vidcore_menu':
        item('Search Movies' if kind == 'movie' else 'Search TV Shows',
             'vidcore_search', kind=kind, search_id=uuid.uuid4().hex)
        menu_categories = [('Popular', 'popular'), ('Top Rated', 'top_rated')]
        if kind == 'movie':
            menu_categories.insert(0, ('Now Playing', 'now_playing'))
            menu_categories.insert(1, ('Upcoming', 'upcoming'))
        else:
            menu_categories.insert(0, ('On the Air', 'on_the_air'))
            menu_categories.insert(1, ('Airing Today', 'airing_today'))
        for label, category in menu_categories:
            item(label, 'vidcore_list', kind=kind, category=category)
        finish()
        return

    if action == 'vidcore_people':
        try:
            page = max(1, min(500, int(params.get('page', 1))))
        except (TypeError, ValueError):
            page = 1
        people = tmdb.get_popular_people(page)
        if not people:
            xbmcgui.Dialog().notification('Vidcore', 'Unable to load popular people. Please try again.')
            finish(succeeded=False)
            return
        for person in people:
            name = person.get('name', 'Unknown')
            person_id = person.get('id', '')
            known_for = person.get('known_for', [])
            known_for_titles = ', '.join(
                item.get('title') or item.get('name') or '' 
                for item in known_for[:3]
            ) if known_for else ''
            label = name + (f' ({known_for_titles})' if known_for_titles else '')
            info = {'title': name, 'plot': f'Known for: {known_for_titles}' if known_for_titles else ''}
            thumb = tmdb._img(person.get('profile_path'), 'w185')
            item(label, 'vidcore_person_credits', info=info, thumb=thumb,
                 person_id=person_id, person_name=name)
        if page < 500:
            item('Next Page', 'vidcore_people', page=page + 1)
        finish('actors')
        return

    if action == 'vidcore_person_credits':
        person_id = params.get('person_id', '')
        person_name = params.get('person_name', 'Unknown')
        if not person_id:
            finish(succeeded=False)
            return
        credits = tmdb.get_person_credits(person_id)
        cast_items = credits.get('cast', [])
        if not cast_items:
            xbmcgui.Dialog().notification('Vidcore', f'No credits found for {person_name}.')
            finish(succeeded=True)
            return
        for item_data in cast_items:
            if not item_data.get('id'):
                continue
            title = item_data.get('title') or item_data.get('name') or 'Untitled'
            date = item_data.get('release_date') or item_data.get('first_air_date') or ''
            year = date[:4] if date else ''
            label = title + (f' ({year})' if year else '')
            character = item_data.get('character', '')
            plot = f'as {character}' if character else ''
            media_type = 'movie' if item_data.get('media_type') == 'movie' else 'tvshow'
            kind = 'movie' if item_data.get('media_type') == 'movie' else 'tv'
            info = {'title': title, 'plot': plot, 'mediatype': media_type}
            thumb = tmdb._img(item_data.get('poster_path'))
            item(label, 'vidcore_seasons' if kind == 'tv' else 'vidcore_sources',
                 info=info, thumb=thumb, folder=kind == 'tv', kind=kind,
                 tmdb_id=item_data['id'])
        finish('movies')
        return

    if action in ('vidcore_list', 'vidcore_search'):
        query = params.get('query', '').strip()
        if action == 'vidcore_search' and not query:
            # Kodi may rerun the original directory URL after playback or Back.
            # Store the query against that search's URL token, not a global
            # last-query value which would mix separate searches or media types.
            window = xbmcgui.Window(10000)
            key = 'Cosmos.Vidcore.SearchSessions'
            try:
                sessions = json.loads(window.getProperty(key) or '{}')
                if not isinstance(sessions, dict):
                    sessions = {}
            except (ValueError, TypeError):
                sessions = {}
            session = kind + ':' + params.get('search_id', 'legacy')
            query = sessions.get(session, '')
            if not query:
                query = xbmcgui.Dialog().input('Search Vidcore — Movies' if kind == 'movie'
                                              else 'Search Vidcore — TV Shows').strip()
                if query:
                    sessions[session] = query
                    while len(sessions) > 50:
                        del sessions[next(iter(sessions))]
                    window.setProperty(key, json.dumps(sessions))
            if not query:
                finish(succeeded=False)
                return
            # Continue directly into the result request after the dialog.
            # Redirecting the container here can discard the newly entered
            # query on Kodi builds that reuse the old plugin URL.
            action = 'vidcore_list'
        try:
            page = max(1, min(500, int(params.get('page', 1))))
        except (TypeError, ValueError):
            page = 1
        category = params.get('category', 'popular')
        allowed_categories = ('popular', 'top_rated', 'now_playing', 'upcoming') if kind == 'movie' else ('popular', 'top_rated', 'on_the_air', 'airing_today')
        if category not in allowed_categories:
            category = 'popular'
        endpoint = 'search/' + kind if query else kind + '/' + category
        arguments = {'api_key': tmdb._api_key(), 'page': page,
                     'language': 'en-US', 'include_adult': 'false'}
        if query:
            arguments['query'] = query
        data = tmdb._fetch('https://api.themoviedb.org/3/' + endpoint + '?' + urlencode(arguments))
        if not isinstance(data, dict):
            xbmcgui.Dialog().notification('Vidcore', 'Unable to load TMDB titles. Please try again.')
            finish(succeeded=False)
            return
        for row in data.get('results') or []:
            if not row.get('id'):
                continue
            title = row.get('title') or row.get('name') or 'Untitled'
            date = row.get('release_date') or row.get('first_air_date') or ''
            label = title + (' (%s)' % date[:4] if date else '')
            info = {'title': title, 'plot': row.get('overview') or '',
                    'mediatype': 'movie' if kind == 'movie' else 'tvshow'}
            item(label, 'vidcore_seasons' if kind == 'tv' else 'vidcore_sources',
                 info=info, thumb=tmdb._img(row.get('poster_path')),
                 folder=kind == 'tv', kind=kind, tmdb_id=row['id'])
        if not data.get('results'):
            xbmcgui.Dialog().notification('Vidcore', 'No titles found.')
        if page < min(int(data.get('total_pages') or 0), 500):
            item('Next Page', action, kind=kind, category=category, query=query, page=page + 1)
        finish('movies' if kind == 'movie' else 'tvshows')
        return

    tmdb_id = str(params.get('tmdb_id', ''))
    if not tmdb_id.isdigit():
        finish(succeeded=False)
        return
    if action == 'vidcore_seasons':
        today = calendar_date.today()
        for season in tmdb.get_tv_seasons(tmdb_id):
            if not _has_aired(season, today):
                # Specials and older seasons sometimes lack a season date.
                # Keep them only when they contain a confirmed aired episode.
                if season.get('air_date') or not any(
                        _has_aired(episode, today) for episode in
                        tmdb.get_tv_episodes(tmdb_id, season['number'])):
                    continue
            item(season['name'], 'vidcore_episodes',
                 info={'title': season['name'], 'plot': season['overview'],
                       'mediatype': 'season', 'season': season['number']},
                 thumb=season['poster'], kind='tv', tmdb_id=tmdb_id,
                 season=season['number'])
        finish('seasons')
        return
    if action == 'vidcore_sources':
        season, episode = 0, 0
        try:
            season = max(0, int(params.get('season', 0)))
            episode = max(0, int(params.get('episode', 0)))
            sources = _vidrock_sources(kind, tmdb_id, season, episode)
        except Exception as exc:
            xbmc.log('COSMOS Vidrock source picker failed: %s' % exc, xbmc.LOGWARNING)
            _debug_bundle_event('SOURCE ERROR',
                                f'{_media_context(kind, tmdb_id, season, episode)} '
                                f'Vidrock lookup failed ({type(exc).__name__})')
            sources = []
        vidrock_mappings = [_safe_source_name(source[0]) for source in sources]
        embed = vidnest.embed_url(tmdb_id, kind, season, episode)
        if embed:
            sources.append(('VidNest', embed, 'hls'))
        embed = vidlove.embed_url(tmdb_id, kind, season, episode)
        if embed:
            sources.append(('VidLove', embed, 'hls'))
        embed = twoembed.embed_url(tmdb_id, kind, season, episode)
        if embed:
            sources.append(('2Embed', embed, 'hls'))
        embed = cinetaro.embed_url(tmdb_id, kind, season, episode)
        if embed:
            sources.append(('Nest', embed, 'hls'))
        if kind == 'movie' or episode > 0:
            sources.append(('Jupiter', '', 'hls'))
            sources.append(('HDHub', '', 'api'))
        dulo_servers = []
        if kind == 'movie' or episode > 0:
            try:
                dulo_servers = dulo.discover(tmdb_id, kind, season, episode)
            except Exception as exc:
                xbmc.log('COSMOS Dulo server discovery failed (%s)' %
                         type(exc).__name__, xbmc.LOGWARNING)
            if dulo_servers:
                sources.append(('Dulo', '', 'hosts'))
        srstop_hosts = {}
        if kind == 'tv' and episode > 0:
            try:
                meta = tmdb.get_metadata(tmdb_id, 'tv') or {}
                srstop_hosts = srstop.discover_hosts(meta, season, episode)
            except Exception as exc:
                reason = str(exc) if isinstance(exc, srstop.SourceError) else type(exc).__name__
                xbmc.log('COSMOS SRStop availability check failed (%s)' %
                         reason, xbmc.LOGWARNING)
            if srstop_hosts:
                sources.append(('SRStop', '', 'hosts'))
        _debug_bundle_event(
            'SOURCE MAP',
            f'{_media_context(kind, tmdb_id, season, episode)} '
            f'mapped=Vidrock(dynamic:{",".join(vidrock_mappings) or "none"}); '
            'VidNest; VidLove; Nest(Cinetaro); Dulo(movie/TV servers); '
            'Jupiter(Movy Phoenix); HDHub(CineWave); SaveFiles, LuluStream, Streamtape, DoodStream, Byse and VOE via SRStop (TV only)',
        )
        availability = _check_picker_sources(
            sources, kind, tmdb_id, season, episode, dulo_servers, srstop_hosts)
        if availability is None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        sources, checked_sources, checked_groups, checked_hosts = availability
        source_list = ','.join(
            '%s:%s' % (_safe_source_name(name), _safe_source_name(source_type))
            for name, _stream, source_type in sources) or 'none'
        _debug_bundle_event(
            'SOURCES',
            f'{_media_context(kind, tmdb_id, season, episode)} '
            f'available={source_list}',
        )
        if not sources:
            xbmcgui.Dialog().notification('Vidcore', 'No playback providers are available.')
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        choice = _pick_provider(sources, kind, tmdb_id, season, episode, checked_hosts)
        if choice is None:
            _debug_bundle_event('SOURCE',
                                f'{_media_context(kind, tmdb_id, season, episode)} selection cancelled')
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        provider, stream, source_type = choice
        _debug_bundle_event('SOURCE',
                            f'{_media_context(kind, tmdb_id, season, episode)} '
                            f'selected={_safe_source_name(provider)}')
        srstop_resolvers = {'SaveFiles (HLS)': srstop, 'LuluStream': lulustream,
                            'Streamtape': streamtape, 'DoodStream': doodstream,
                            'Byse': byse, 'VOE': voe, 'Morencius': morencius,
                            'Vidara': vidara, 'Streamplay': streamplay}
        if provider in checked_hosts and provider in srstop_resolvers:
            resolved = srstop_resolvers[provider].resolve(tmdb_id, season, episode)
            if not resolved or not resolved.get('url') or resolved.get('error'):
                if resolved and resolved.get('error'):
                    xbmcgui.Dialog().ok(provider, resolved['error'])
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                return
        elif provider in checked_groups:
            rows = checked_groups[provider]
            index = _pick_source(
                [(label, '', checked_sources[key]['type']) for key, label in rows],
                kind, tmdb_id, season, episode)
            if index < 0:
                xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                return
            resolved = checked_sources[rows[index][0]]
        else:
            resolved = checked_sources[provider]
        _debug_bundle_event('RESOLVE', '%s provider=%s result=playable type=%s' % (
            _media_context(kind, tmdb_id, season, episode), _safe_source_name(provider),
            _safe_source_name(resolved['type'])))
        _play_tracked_stream(
            handle, resolved['url'], resolved['type'], provider,
            stream_headers=resolved.get('headers'), refresh_source=stream,
            proxy_opener=resolved.get('opener'),
            proxy_refresh_tokens=resolved.get('refresh_tokens', False),
            native_hls=resolved.get('native_hls', False))
        return
    if action == 'vidcore_episodes':
        try:
            season = max(0, int(params.get('season', 0)))
        except (TypeError, ValueError):
            finish(succeeded=False)
            return
        today = calendar_date.today()
        episodes = [episode for episode in tmdb.get_tv_episodes(tmdb_id, season)
                    if _has_aired(episode, today)]
        page_size = 50
        page_count = max(1, (len(episodes) + page_size - 1) // page_size)
        try:
            page = max(1, min(page_count, int(params.get('page', 1))))
        except (TypeError, ValueError):
            page = 1
        start = (page - 1) * page_size
        if page > 1:
            item('Previous Page (%d/%d)' % (page - 1, page_count),
                 'vidcore_episodes', kind='tv', tmdb_id=tmdb_id,
                 season=season, page=page - 1)
        for episode in episodes[start:start + page_size]:
            item('%02d. %s' % (episode['number'], episode['name']), 'vidcore_sources',
                 info={'title': episode['name'], 'plot': episode['overview'],
                       'mediatype': 'episode', 'season': season,
                       'episode': episode['number'], 'duration': episode['runtime']},
                 thumb=episode['still'], folder=False, kind='tv', tmdb_id=tmdb_id,
                 season=season, episode=episode['number'])
        if page < page_count:
            item('Next Page (%d/%d)' % (page + 1, page_count),
                 'vidcore_episodes', kind='tv', tmdb_id=tmdb_id,
                 season=season, page=page + 1)
        finish('episodes')
        return
    finish(succeeded=False)
