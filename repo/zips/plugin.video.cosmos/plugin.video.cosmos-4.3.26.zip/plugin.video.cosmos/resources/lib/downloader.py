# -*- coding: utf-8 -*-
"""Download manager for C.O.S.M.O.S.

* Accepts direct http(s) URLs, debrid Search tokens (Search4k / ...) and
  filehost URLs.
* Resolves debrid / filehost links to a direct http stream before
  streaming the bytes to disk.
* Shows a cancellable progress dialog with % / speed / ETA.
* Keeps a JSON index of completed downloads so the "Downloads" menu can
  list them as playable local files.
"""
import json
import os
import re
import tempfile
import threading
import time
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from . import debrid
from . import filehost
from . import scrapers


ADDON = xbmcaddon.Addon()
PROFILE_DIR = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/')
INDEX_FILE = os.path.join(PROFILE_DIR, 'downloads.json')
ACTIVE_FILE = os.path.join(PROFILE_DIR, 'active_downloads.json')
CHUNK = 256 * 1024
USER_AGENT = 'COSMOS-Downloader/1.0'

_SAFE_RE = re.compile(r'[^\w\-\. \(\)\[\]]+', re.UNICODE)
_index_lock = threading.RLock()


def _ensure_profile():
    if not os.path.isdir(PROFILE_DIR):
        try:
            os.makedirs(PROFILE_DIR)
        except OSError:
            pass


def _safe_name(text, fallback='download'):
    cleaned = _SAFE_RE.sub('_', (text or '').strip())
    cleaned = cleaned.strip('._ ') or fallback
    return cleaned[:160]


def _root_path():
    """Return configured download root (local filesystem path)."""
    p = (ADDON.getSetting('download_path') or '').strip()
    if not p:
        # Default inside profile/downloads
        p = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/downloads/')
    else:
        # xbmcvfs translated for smb:// / nfs:// special paths
        p = xbmcvfs.translatePath(p)
    if not p.endswith(os.sep) and not p.endswith('/'):
        p += os.sep
    return p


def _target_dir(content):
    root = _root_path()
    if content == 'movie':
        sub = (ADDON.getSetting('download_movies_subfolder') or 'Movies').strip() or 'Movies'
    elif content in ('episode', 'tvshow'):
        sub = (ADDON.getSetting('download_tv_subfolder') or 'TV Shows').strip() or 'TV Shows'
    else:
        sub = 'Other'
    path = os.path.join(root, sub)
    try:
        if not os.path.isdir(path):
            os.makedirs(path)
    except OSError as e:
        xbmc.log(f'COSMOS downloader: cannot create {path}: {e}', xbmc.LOGERROR)
    return path


def _extension_from_url(url, content_type=''):
    # Strip query/frag, try extension
    clean = url.split('?')[0].split('#')[0]
    ext = os.path.splitext(clean)[1].lower()
    if ext and len(ext) <= 5:
        return ext
    if content_type:
        ct = content_type.lower()
        if 'matroska' in ct or 'mkv' in ct:
            return '.mkv'
        if 'mp4' in ct:
            return '.mp4'
        if 'webm' in ct:
            return '.webm'
        if 'x-msvideo' in ct:
            return '.avi'
    return '.mp4'


def _format_size(n):
    if n is None or n <= 0:
        return '?'
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if n < 1024:
            return f'{n:.1f} {unit}'
        n /= 1024
    return f'{n:.1f} PB'


def _format_eta(seconds):
    if seconds is None or seconds <= 0 or seconds > 24 * 3600:
        return '--:--'
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h:
        return f'{h:d}:{m:02d}:{s:02d}'
    return f'{m:02d}:{s:02d}'


# ── Index of completed downloads ─────────────────────────────────────────

def _load_index():
    _ensure_profile()
    if not os.path.isfile(INDEX_FILE):
        return []
    try:
        with open(INDEX_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp)
        return [item for item in data if isinstance(item, dict)] if isinstance(data, list) else []
    except (ValueError, OSError):
        return []


def _save_index(items):
    _ensure_profile()
    safe_items = [item for item in (items or []) if isinstance(item, dict)]
    with _index_lock:
        temp_path = None
        try:
            fd, temp_path = tempfile.mkstemp(
                prefix='.downloads-', suffix='.tmp', dir=PROFILE_DIR
            )
            with os.fdopen(fd, 'w', encoding='utf-8') as fp:
                json.dump(safe_items, fp, indent=2)
            os.replace(temp_path, INDEX_FILE)
            temp_path = None
        except (OSError, TypeError, ValueError) as e:
            xbmc.log(f'COSMOS downloader: save index failed: {e}', xbmc.LOGWARNING)
        finally:
            if temp_path:
                try:
                    os.remove(temp_path)
                except OSError:
                    pass


def list_downloads():
    """Return completed downloads whose files still exist on disk."""
    with _index_lock:
        items = _load_index()
        alive = [it for it in items if os.path.isfile(str(it.get('path') or ''))]
        if len(alive) != len(items):
            _save_index(alive)
        return alive


def _add_to_index(entry):
    with _index_lock:
        items = _load_index()
        # de-dup by path
        items = [i for i in items if i.get('path') != entry.get('path')]
        items.insert(0, entry)
        _save_index(items)


def remove_download(path, delete_file=False):
    with _index_lock:
        current = _load_index()
        items = [i for i in current if i.get('path') != path]
        changed = len(items) != len(current)
        _save_index(items)
        file_removed = False
        if delete_file:
            try:
                if os.path.isfile(path):
                    os.remove(path)
                    file_removed = True
            except OSError as exc:
                xbmc.log(f'COSMOS downloader: delete failed: {exc}', xbmc.LOGWARNING)
        return changed or file_removed


# ── Active jobs index (concurrent / background) ─────────────────────────

_active_lock = threading.Lock()


def _load_active():
    _ensure_profile()
    if not os.path.isfile(ACTIVE_FILE):
        return []
    try:
        with open(ACTIVE_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp)
        return [item for item in data if isinstance(item, dict)] if isinstance(data, list) else []
    except (ValueError, OSError):
        return []


def _save_active(items):
    _ensure_profile()
    try:
        with open(ACTIVE_FILE, 'w', encoding='utf-8') as fp:
            json.dump(items, fp)
    except OSError:
        pass


def list_active():
    return _load_active()


def _sidecar_path(part_path):
    return part_path + '.json' if part_path else ''


def _write_sidecar(part_path, meta):
    """Persist the original job metadata (url, title, content, season,
    episode, imdb, tmdb, year, label) next to the .part file so a paused
    download can be resumed in one click without the user having to
    navigate back to the original item."""
    if not part_path:
        return
    try:
        with open(_sidecar_path(part_path), 'w', encoding='utf-8') as fp:
            json.dump(meta, fp)
    except OSError as e:
        xbmc.log(f'COSMOS downloader: sidecar write failed: {e}', xbmc.LOGWARNING)


def _read_sidecar(part_path):
    sp = _sidecar_path(part_path)
    if not sp or not os.path.isfile(sp):
        return None
    try:
        with open(sp, 'r', encoding='utf-8') as fp:
            data = json.load(fp)
        return data if isinstance(data, dict) else {}
    except (ValueError, OSError):
        return None


def _delete_sidecar(part_path):
    sp = _sidecar_path(part_path)
    try:
        if sp and os.path.isfile(sp):
            os.remove(sp)
    except OSError:
        pass


def list_interrupted():
    """Return a list of .part files left behind in any configured download
    folder so the user can resume them from the Downloads menu.
    Each entry is ``{'path', 'part_path', 'bytes', 'title', 'sidecar'}``.
    """
    roots = set()
    try:
        roots.add(_target_dir('movie'))
        roots.add(_target_dir('episode'))
        roots.add(_target_dir('other'))
    except Exception:
        pass
    try:
        roots.add(_root_path())
    except Exception:
        pass

    seen = set()
    rows = []
    for root in roots:
        if not root or not os.path.isdir(root):
            continue
        for dirpath, _dirs, files in os.walk(root):
            for fname in files:
                if not fname.endswith('.part'):
                    continue
                full = os.path.join(dirpath, fname)
                if full in seen:
                    continue
                seen.add(full)
                try:
                    size = os.path.getsize(full)
                except OSError:
                    size = 0
                final = full[:-5]
                sidecar = _read_sidecar(full)
                rows.append({
                    'part_path': full,
                    'path': final,
                    'bytes': size,
                    'title': (sidecar or {}).get('title') or os.path.splitext(os.path.basename(final))[0],
                    'sidecar': sidecar or {},
                })
    rows.sort(key=lambda r: r.get('bytes', 0), reverse=True)
    return rows


def delete_interrupted(part_path):
    try:
        if part_path and os.path.isfile(part_path) and part_path.endswith('.part'):
            os.remove(part_path)
            _delete_sidecar(part_path)
            return True
    except OSError:
        pass
    return False


def _active_upsert(job_id, **fields):
    with _active_lock:
        items = _load_active()
        found = False
        for it in items:
            if it.get('id') == job_id:
                it.update(fields)
                found = True
                break
        if not found:
            items.append({'id': job_id, **fields})
        _save_active(items)


def _active_remove(job_id):
    with _active_lock:
        items = _load_active()
        items = [i for i in items if i.get('id') != job_id]
        _save_active(items)


def clear_active():
    _save_active([])


# ── Source resolution ────────────────────────────────────────────────────

def _resolve_source(url, title='', content='movie', season=None, episode=None,
                    imdb_id='', tmdb_id='', year=''):
    """Given any playlist link, return (direct_stream_url, via_name).

    Handles direct http(s) filehost URLs, debrid Search tokens and magnet links.
    """
    if not url:
        return None, None
    low = url.strip().lower()

    # Magnet -> debrid unrestrict
    if low.startswith('magnet:'):
        return debrid.resolve_magnet(url)

    # Search tokens -> pick best cached torrent source via scrapers + debrid
    if low in filehost.SEARCH_TOKENS:
        quality = filehost.SEARCH_TOKENS[low]
        query = f'{title} {year}'.strip()
        try:
            results = scrapers.search_all(
                query, preferred_quality=quality, imdb_id=imdb_id,
                content=content, season=season, episode=episode,
            )
        except Exception:
            results = []
        if not results:
            return None, None
        # Cache check
        hashes = []
        for r in results:
            h = scrapers.extract_hash(r.get('magnet', ''))
            if h:
                hashes.append(h)
                r['hash'] = h
        try:
            cached_set = debrid.check_cache_all(hashes) if hashes else set()
        except Exception:
            cached_set = set()
        for r in results:
            r['cached'] = r.get('hash', '').lower() in cached_set
        # Prefer cached + matching quality + high seeds
        results.sort(key=lambda s: (
            0 if s.get('cached') else 1,
            0 if s.get('quality') == quality else 1,
            -(s.get('seeds') or 0),
        ))
        for src in results[:10]:
            magnet = src.get('magnet', '')
            if not magnet:
                continue
            stream, via = debrid.resolve_magnet(magnet)
            if stream:
                return stream, via
        return None, None

    # Everything else: filehost / http URL
    return filehost.resolve_filehost_link(url)


# ── Streaming downloader ─────────────────────────────────────────────────

class _Download:
    def __init__(self, url, dest_path, display_title):
        self.url = url
        self.dest_path = dest_path
        self.display_title = display_title
        self.total = 0
        self.received = 0
        self.resumed_from = 0
        self.done = False
        self.error = None
        self.cancelled = False
        self.started = time.time()
        self._thread = None

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def cancel(self):
        self.cancelled = True

    def _open_connection(self, tmp_path):
        """Open an HTTP connection honouring an existing .part file's size
        with a Range header. Returns (response, write_mode, start_offset,
        total_bytes).
        """
        existing = 0
        if os.path.isfile(tmp_path):
            try:
                existing = os.path.getsize(tmp_path)
            except OSError:
                existing = 0

        hdrs = {'User-Agent': USER_AGENT}
        if existing > 0:
            hdrs['Range'] = f'bytes={existing}-'

        req = Request(self.url, headers=hdrs)
        resp = urlopen(req, timeout=30)
        status = getattr(resp, 'status', None) or resp.getcode()

        cl = resp.headers.get('Content-Length')
        try:
            cl_int = int(cl) if cl else 0
        except ValueError:
            cl_int = 0

        if existing > 0 and status == 206:
            # Server granted our range request -> append.
            # total = existing (already on disk) + remaining bytes reported
            total = existing + cl_int if cl_int else 0
            # Prefer the authoritative Content-Range end+1 if available
            cr = resp.headers.get('Content-Range') or ''
            m = re.search(r'/(\d+)\s*$', cr)
            if m:
                try:
                    total = int(m.group(1))
                except ValueError:
                    pass
            return resp, 'ab', existing, total

        # No resume — either no .part, or server ignored the Range header
        if existing > 0 and status != 206:
            # Server sent a full 200 despite our Range request -> restart
            try:
                os.remove(tmp_path)
            except OSError:
                pass
            existing = 0
        return resp, 'wb', 0, cl_int

    def _run(self):
        tmp_path = self.dest_path + '.part'
        attempts = 0
        max_attempts = 4
        while attempts < max_attempts:
            attempts += 1
            resp = None
            try:
                resp, mode, start_offset, total = self._open_connection(tmp_path)

                self.resumed_from = start_offset
                self.received = start_offset
                if total:
                    self.total = total

                # Derive extension if missing (only on first attempt, when no .part)
                if mode == 'wb' and not os.path.splitext(self.dest_path)[1]:
                    ext = _extension_from_url(self.url,
                                              resp.headers.get('Content-Type', ''))
                    self.dest_path = self.dest_path + ext
                    tmp_path = self.dest_path + '.part'

                with open(tmp_path, mode) as out:
                    while True:
                        if self.cancelled:
                            raise InterruptedError('cancelled')
                        buf = resp.read(CHUNK)
                        if not buf:
                            break
                        out.write(buf)
                        self.received += len(buf)

                # Finished
                os.replace(tmp_path, self.dest_path)
                self.done = True
                return
            except InterruptedError:
                # User cancelled — keep .part so next time we can resume
                self.error = 'cancelled'
                return
            except (HTTPError, URLError, OSError, ValueError) as e:
                self.error = str(e)
                # Retry with exponential back-off unless cancelled
                if attempts >= max_attempts or self.cancelled:
                    # Leave the .part on disk so a future Download() call
                    # can resume — do NOT wipe it.
                    return
                self.error = None  # transient, retry
                time.sleep(min(2 ** attempts, 15))
            except Exception as e:
                # An unexpected worker exception must still publish an error;
                # otherwise the foreground progress loop waits forever for a
                # job that has already died.
                self.error = str(e) or e.__class__.__name__
                xbmc.log(f'COSMOS downloader: worker failed: {e}', xbmc.LOGERROR)
                return
            finally:
                if resp is not None:
                    try:
                        resp.close()
                    except Exception:
                        pass


def download(url, title, content='movie', season=None, episode=None,
             imdb_id='', tmdb_id='', year='', label=''):
    """User-facing download entry point. Resolves the source, then streams
    it to disk in the background using a non-blocking ``DialogProgressBG``
    notification so the user can keep browsing / queue more downloads.
    Because each ``RunPlugin(?action=download_item...)`` invocation runs
    in its own Kodi plugin process, multiple downloads triggered from the
    context menu are genuinely concurrent.
    """
    _ensure_profile()

    # Normalize legacy TV payloads at the persistence boundary. This keeps
    # completed downloads and their sidecars compatible with local watched
    # and resume tracking, which key episodes separately from shows.
    content = str(content or 'movie').strip().lower()
    if content in ('tv', 'tvshow', 'series') and season not in (None, '') and episode not in (None, ''):
        content = 'episode'

    # Show an initial "resolving" notification
    xbmcgui.Dialog().notification('C.O.S.M.O.S',
                                  f'Queued: {title}',
                                  xbmcgui.NOTIFICATION_INFO, 2500)

    try:
        stream_url, via = _resolve_source(
            url, title=title, content=content, season=season, episode=episode,
            imdb_id=imdb_id, tmdb_id=tmdb_id, year=year,
        )
    except Exception as e:
        stream_url, via = None, None
        xbmc.log(f'COSMOS downloader: resolve error: {e}', xbmc.LOGERROR)

    if not stream_url:
        xbmcgui.Dialog().notification('C.O.S.M.O.S',
                                      f'Could not resolve: {title}',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return False

    if '|' in stream_url:
        stream_url = stream_url.split('|', 1)[0]

    # Build filename
    parts = [title]
    if content in ('episode', 'tvshow') and season and episode:
        try:
            parts.append(f'S{int(season):02d}E{int(episode):02d}')
        except (TypeError, ValueError):
            parts.append(f'S{season}E{episode}')
    if year:
        parts.append(f'({year})')
    if label:
        parts.append(f'- {label}')
    base_name = _safe_name(' '.join(str(p) for p in parts if p))

    target_dir = _target_dir(content)
    if not os.path.isdir(target_dir):
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'Download folder is not available',
            xbmcgui.NOTIFICATION_ERROR, 4000
        )
        return False
    base_path = os.path.join(target_dir, base_name)
    ext = _extension_from_url(stream_url)
    dest_path = base_path + ext
    if os.path.isfile(dest_path):
        i = 2
        while os.path.isfile(f'{base_path} ({i}){ext}'):
            i += 1
        dest_path = f'{base_path} ({i}){ext}'

    job = _Download(stream_url, dest_path, title)
    job_id = f'{int(time.time()*1000)}-{os.path.basename(dest_path)[:20]}'

    # Persist job metadata alongside the .part file so a paused download
    # can be resumed from the Downloads menu in one click, even after a
    # Kodi restart, without the user re-navigating to the original item.
    _write_sidecar(dest_path + '.part', {
        'url': url,
        'title': title,
        'content': content,
        'season': season,
        'episode': episode,
        'imdb_id': str(imdb_id or ''),
        'tmdb_id': str(tmdb_id or ''),
        'year': str(year or ''),
        'label': label,
        'dest_path': dest_path,
        'stream_url': stream_url,
        'started': int(time.time()),
    })

    _active_upsert(job_id, title=title, label=label, dest=dest_path,
                   started=int(time.time()), pct=0, status='starting',
                   via=via or '')

    job.start()

    bg = xbmcgui.DialogProgressBG()
    try:
        bg.create('C.O.S.M.O.S Download', title)
    except Exception:
        bg = None

    last_bytes = 0
    last_ts = time.time()
    speed = 0.0
    resumed_announced = False
    try:
        while not job.done and job.error is None:
            if job._thread is not None and not job._thread.is_alive():
                job.error = 'download worker stopped unexpectedly'
                break
            now = time.time()
            elapsed = now - last_ts
            if elapsed >= 0.7:
                delta = job.received - last_bytes
                speed = delta / elapsed if elapsed > 0 else 0
                last_bytes = job.received
                last_ts = now

            if not resumed_announced and job.resumed_from > 0:
                xbmcgui.Dialog().notification(
                    'C.O.S.M.O.S',
                    f'Resuming: {_format_size(job.resumed_from)} on disk',
                    xbmcgui.NOTIFICATION_INFO, 3000,
                )
                resumed_announced = True

            if job.total:
                pct = int(job.received * 100 / job.total)
                line = (f'{_format_size(job.received)} / {_format_size(job.total)}'
                        f' · {_format_size(speed)}/s')
            else:
                pct = 0
                line = f'{_format_size(job.received)} · {_format_size(speed)}/s'
            if job.resumed_from > 0:
                line = f'[resumed] {line}'

            _active_upsert(job_id, pct=pct,
                           received=job.received, total=job.total,
                           resumed_from=job.resumed_from,
                           status='running')
            if bg is not None:
                try:
                    bg.update(pct, title, line)
                except Exception:
                    pass
            time.sleep(1.0)
    finally:
        if bg is not None:
            try:
                bg.close()
            except Exception:
                pass
        _active_remove(job_id)

    if job.error == 'cancelled':
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S',
            f'Paused: {title} — resume later',
            xbmcgui.NOTIFICATION_WARNING, 3500,
        )
        return False
    if job.error:
        xbmcgui.Dialog().notification('C.O.S.M.O.S',
                                      f'Download failed: {job.error[:60]}',
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        return False

    final_path = job.dest_path
    # Clean up the sidecar companion that tracked this .part file
    _delete_sidecar(final_path + '.part')
    entry = {
        'title': title,
        'label': label,
        'path': final_path,
        'size': job.total or job.received,
        'content': content,
        'tmdb': str(tmdb_id or ''),
        'imdb': str(imdb_id or ''),
        'year': str(year or ''),
        'season': season,
        'episode': episode,
        'added': int(time.time()),
        'via': via or '',
    }
    _add_to_index(entry)

    xbmcgui.Dialog().notification('C.O.S.M.O.S',
                                  f'Downloaded: {os.path.basename(final_path)}',
                                  xbmcgui.NOTIFICATION_INFO, 4000)
    return True
