# -*- coding: utf-8 -*-
"""9anime section embedded in the C.O.S.M.O.S root menu."""

from __future__ import absolute_import, division, print_function, unicode_literals

import threading
import time
from urllib.parse import parse_qs, urlencode, urlparse

import xbmc
import xbmcgui
import xbmcplugin

from .nineanime_client import NineAnimeClient, NineAnimeError, media_type, normalize_language
from .nineanime_anidb import find_source as find_anidb_source
from .nineanime_aniwatch import find_sources as find_aniwatch_sources, resolve as resolve_aniwatch
from .nineanime_yoanime import (
    find_embed_source as find_yoanime_embed_source,
    find_source as find_yoanime_source,
    find_vidplay_source as find_yoanime_vidplay_source,
    source_is_playable as yoanime_source_is_playable,
    sources_match_duration as yoanime_sources_match_duration,
)
from . import nineanime_picker as nineanime_picker_mod
from .nineanime_resolvers import resolver_name
from . import resume as resume_mod
from . import watched as watched_mod


_BYFMS_STREAM_CACHE = {}
_BYFMS_STREAM_CACHE_LOCK = threading.Lock()
_BYFMS_STREAM_CACHE_TTL = 10 * 60


def _cosmos():
    # Imported lazily to avoid a circular import while cosmos.py loads.
    from . import cosmos
    return cosmos


def _handle():
    return _cosmos()._handle()


def _url(action, **params):
    values = {"action": "nineanime_" + action}
    values.update({key: value for key, value in params.items() if value is not None})
    return _cosmos().build_url(**values)


def _art():
    cosmos = _cosmos()
    return (
        cosmos.ADDON_PATH + "resources/media/icon_9anime.png",
        cosmos.ADDON_PATH + "resources/media/fanart_9anime.png",
    )


def _source_icon(server):
    """Return the custom source badge for the 9Anime picker only."""
    cosmos = _cosmos()
    name = (server.get("name") or "").lower()
    if server.get("source_kind") in ("YOANIME", "YOANIME_EMBED", "YOANIME_VIDPLAY") or "yoanime" in name:
        filename = "icon_9anime_yoanime.png"
    elif server.get("source_kind") == "ANIDB" or "anidb" in name:
        filename = "icon_9anime_anidb.png"
    elif resolver_name(server.get("url")) == "BYFMS" or "byfms" in name:
        filename = "icon_9anime_byfms.png"
    elif resolver_name(server.get("url")) == "DGHG" or "dghg" in name:
        filename = "icon_9anime_dghg.png"
    else:
        filename = "icon_9anime.png"
    return cosmos.ADDON_PATH + "resources/media/" + filename


def _enabled_sources(servers):
    """Exclude unreliable BYFMS hosts for both SUB and DUB playback."""
    return [server for server in servers
            if 'BYFMS' not in str(server.get('name') or '').upper()
            and resolver_name(server.get('url') or '') != 'BYFMS']


def _source_priority(server):
    """Put fast native sources ahead of BYFMS' expensive challenge."""
    if resolver_name(server.get("url")) == "DGHG":
        return 0
    if server.get("source_kind") == "YOANIME":
        return 1
    if server.get("source_kind") == "YOANIME_EMBED":
        return 2
    if server.get("source_kind") == "YOANIME_VIDPLAY":
        return 3
    if server.get("source_kind") == "ANIDB":
        return 4
    if resolver_name(server.get("url")) == "BYFMS":
        return 5
    return 4


def _watched_id(slug):
    """Stable local watched-ledger ID for a 9Anime title."""
    return "9anime:" + (slug or "").strip()


def _watched_indicator(watched):
    """Match Cosmos' font-safe episode watched indicator."""
    if watched:
        return "[COLOR green][v][/COLOR]"
    return "[COLOR grey][ ][/COLOR]"


def _client():
    cosmos = _cosmos()
    base_url = (cosmos.ADDON.getSetting("nineanime_base_url") or "https://9anime.tech").strip()
    return NineAnimeClient(base_url)


def _item(label, url, folder=False, info=None, thumb="", playable=False, context_items=None):
    _, fanart = _art()
    _cosmos()._add_directory(
        label,
        url,
        thumb=thumb,
        is_folder=folder,
        info=info,
        is_playable=playable,
        fanart=fanart,
        context_items=context_items,
    )


def _end(succeeded=True):
    xbmcplugin.endOfDirectory(_handle(), succeeded=succeeded)


def _inputstream_adaptive_available():
    """Return whether Kodi has the adaptive inputstream addon enabled."""
    try:
        return bool(xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"))
    except Exception:
        try:
            import xbmcaddon
            xbmcaddon.Addon("inputstream.adaptive")
            return True
        except Exception:
            return False


def install_inputstream_adaptive():
    """Ask Kodi to install the platform-correct ISA package from its repo."""
    if _inputstream_adaptive_available():
        xbmcgui.Dialog().notification(
            "C.O.S.M.O.S",
            "InputStream Adaptive is already enabled",
            xbmcgui.NOTIFICATION_INFO,
            3500,
        )
    else:
        # Kodi selects the correct Windows/Android/Shield binary from the
        # enabled official repository. Do not copy a desktop binary into the
        # addon, because that would break other Kodi platforms.
        xbmc.executebuiltin("InstallAddon(inputstream.adaptive)")
    _end(False)


def _cached_byfms_stream(provider_url):
    now = time.time()
    with _BYFMS_STREAM_CACHE_LOCK:
        entry = _BYFMS_STREAM_CACHE.get(provider_url)
        if entry and entry["expires"] > now:
            return dict(entry["stream"])
        if entry:
            _BYFMS_STREAM_CACHE.pop(provider_url, None)
    return None


def _cache_byfms_stream(provider_url, stream):
    with _BYFMS_STREAM_CACHE_LOCK:
        _BYFMS_STREAM_CACHE[provider_url] = {
            "expires": time.time() + _BYFMS_STREAM_CACHE_TTL,
            "stream": dict(stream),
        }


def _clear_video_playlist():
    """Prevent Kodi from treating the 9Anime episode list as a queue."""
    try:
        video_playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        if video_playlist.size() > 0:
            video_playlist.clear()
    except Exception:
        pass


def _cancel_playback():
    """Complete a cancelled 9Anime playback callback.

    Returning from a picker without resolving the plugin URL leaves Kodi's
    playable item pending. Kodi can then invoke the same episode URL again,
    which reopens the language picker after the user backs out of the source
    picker.
    """
    _clear_video_playlist()
    try:
        handle = _handle()
        if handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
    except Exception as exc:
        xbmc.log("COSMOS 9anime: failed to cancel playback callback: {0}".format(exc),
                 xbmc.LOGDEBUG)


def add_catalog(anime_list, page, path, title):
    xbmcplugin.setPluginCategory(_handle(), title)
    xbmcplugin.setContent(_handle(), "movies")
    for anime in anime_list:
        info = {
            "title": anime["title"],
            "mediatype": "tvshow" if anime.get("type") == "TV" else "movie",
        }
        if anime.get("plot"):
            info["plot"] = anime["plot"]
        poster = anime.get("poster", "")
        _item(
            anime["title"],
            _url("anime", slug=anime["slug"]),
            folder=True,
            info=info,
            thumb=poster,
        )
    if anime_list:
        next_page = page + 1
        _item("Next page ({0})".format(next_page), _url("browse", path=path, page=next_page), folder=True)
    _end()


def root():
    xbmcplugin.setPluginCategory(_handle(), "9anime")
    icon, _ = _art()
    entries = [
        ("Search", "search", None),
        ("Popular", "browse", "/browse/popular"),
        ("Newest", "browse", "/browse/new"),
        ("Updated", "browse", "/browse/new"),
        ("Ongoing", "browse", "/browse/ongoing"),
        ("TV Series", "browse", "/browse/tv"),
        ("Movies", "browse", "/browse/movies"),
        ("OVAs", "browse", "/browse/ovas"),
        ("ONAs", "browse", "/browse/onas"),
        ("Specials", "browse", "/browse/specials"),
        ("Genres", "genres", None),
        ("Advanced Browse", "advanced", None),
        ("Random Anime", "random", None),
    ]
    if not _inputstream_adaptive_available():
        entries.insert(
            0,
            ("Install InputStream Adaptive (required for HLS)", "install_isa", None),
        )
    for label, action, path in entries:
        _item(label, _url(action, path=path), folder=action != "open", thumb=icon)
    _end()


def genres():
    icon, _ = _art()
    for slug, label in NineAnimeClient.genres:
        _item(label, _url("browse", path="/genre/" + slug), folder=True, thumb=icon)
    _end()


def advanced_browse(client):
    dialog = xbmcgui.Dialog()
    keyword = dialog.input("Title contains", type=xbmcgui.INPUT_ALPHANUM)
    if keyword is None:
        _end(False)
        return
    params = {"q": keyword.strip()} if keyword.strip() else {}
    types = ["All", "TV", "Movie", "OVA", "ONA", "Special"]
    selected_type = dialog.select("Type", types)
    if selected_type > 0:
        params["type"] = types[selected_type].lower()
    statuses = ["Any", "Ongoing", "Completed", "Upcoming"]
    selected_status = dialog.select("Status", statuses)
    if selected_status > 0:
        params["status"] = statuses[selected_status].lower()
    target = "/browse?" + urlencode(params) if params else "/browse"
    browse(client, target, 1, "Advanced Browse")


def search(client):
    keyword = xbmcgui.Dialog().input("Search 9anime", type=xbmcgui.INPUT_ALPHANUM)
    if not keyword or not keyword.strip():
        _end(False)
        return
    catalog = client.search(keyword.strip(), 1)
    add_catalog(catalog, 1, "/search?keyword=" + keyword.strip(), "Search: " + keyword.strip())


def browse(client, path, page, title=None):
    path = path or "/home"
    if not path.startswith("/"):
        path = "/" + path
    if path.startswith("/search"):
        params = parse_qs(urlparse(path).query)
        keyword = params.get("keyword", params.get("q", [""]))[0]
        catalog = client.search(keyword, page)
        add_catalog(catalog, page, path, title or "Search")
        return
    catalog = client.catalog(path, page)
    add_catalog(catalog, page, path, title or client.title_for_path(path))


def anime(client, slug):
    details = client.anime(slug)
    watched_id = _watched_id(slug)
    # 9Anime is intentionally local-only and must not follow the selected
    # TMDB scrobbler indicator.
    watched_episodes = watched_mod.get_local_watched_set(watched_id)
    is_movie = details.get("kind") == "Movie"
    xbmcplugin.setPluginCategory(_handle(), details["title"])
    xbmcplugin.setContent(_handle(), "movies" if is_movie else "episodes")
    info = {
        "title": details["title"],
        "plot": details.get("plot", ""),
        "genre": ", ".join(details.get("genres", [])),
        "year": details.get("year", 0),
        "mediatype": "tvshow" if details.get("kind") == "TVSeries" else "movie",
    }
    poster = details.get("poster", "")
    for episode in details["episodes"]:
        if is_movie:
            base_label = details["title"]
            if len(details["episodes"]) > 1:
                base_label += " - Part {0}".format(episode["number"])
        else:
            base_label = "Episode {0}".format(episode["number"])
        if not is_movie and episode.get("title"):
            base_label += " - " + episode["title"]
        episode_watched = (1, int(episode["number"])) in watched_episodes
        label = "{0}  {1}".format(_watched_indicator(episode_watched), base_label)
        if is_movie:
            episode_info = dict(info)
            episode_info.update({
                "title": base_label,
                "mediatype": "movie",
                "playcount": 1 if episode_watched else 0,
            })
        else:
            episode_info = {
                "title": base_label,
                "tvshowtitle": details["title"],
                "season": 1,
                "episode": episode["number"],
                "mediatype": "episode",
                "playcount": 1 if episode_watched else 0,
            }
        toggle_action = "mark_unwatched" if episode_watched else "mark_watched"
        toggle_label = "Mark as Unwatched" if episode_watched else "Mark as Watched"
        toggle_url = _url(
            toggle_action,
            slug=slug,
            episode=episode["number"],
        )
        _item(
            label,
            _url("play", slug=slug, episode=episode["number"]),
            info=episode_info,
            thumb=poster,
            playable=True,
            context_items=[(
                "[COLOR yellow]{0}[/COLOR]".format(toggle_label),
                "RunPlugin({0})".format(toggle_url),
            )],
        )
    _end()


def about(client, slug):
    details = client.anime(slug)
    text = details.get("plot") or "No description was provided by the site."
    if details.get("genres"):
        text += "\n\nGenres: " + ", ".join(details["genres"])
    xbmcgui.Dialog().textviewer(details["title"], text)
    _end(False)


def set_episode_watched(slug, episode, watched):
    """Change watched state using only 9Anime's own local ledger."""
    if not slug:
        xbmc.log("COSMOS 9anime: watched action missing slug", xbmc.LOGWARNING)
        return
    watched_id = _watched_id(slug)
    try:
        episode_number = int(episode)
    except (TypeError, ValueError):
        xbmc.log("COSMOS 9anime: watched action received invalid episode", xbmc.LOGWARNING)
        return
    if watched:
        watched_mod.mark_watched(watched_id, 1, episode_number)
    else:
        watched_mod.mark_unwatched(watched_id, 1, episode_number)
    # This is invoked by Kodi's RunPlugin context action, not as a directory
    # listing.  Updating the title's episode container directly ensures the
    # freshly written 9Anime-only marker is rendered as a tick immediately.
    xbmc.executebuiltin(
        "Container.Update({0})".format(_url("anime", slug=slug)))


def _start_native_playback(client, details, number, ordered_servers):
    """Resolve and complete the 9Anime Kodi callback synchronously.

    ``setResolvedUrl`` must run while the plugin handle is still alive.  A
    daemon worker may appear to work on desktop Kodi, but Android/Shield can
    tear down the language-invoker callback as soon as ``play()`` returns,
    leaving the player on an endless spinner.  This route remains local to
    9Anime and does not use ResolveURL.
    """
    ordered_servers = _enabled_sources(ordered_servers)
    if not ordered_servers:
        _cancel_playback()
        return
    attempted = []
    selected_candidate = None
    stream = {"direct": False, "url": ordered_servers[0]["url"]}
    for candidate in ordered_servers:
        candidate_url = candidate["url"]
        candidate_stream = _cached_byfms_stream(candidate_url)
        if candidate_stream:
            xbmc.log("COSMOS 9anime: reusing cached BYFMS HLS URL", xbmc.LOGINFO)
        else:
            if candidate.get("source_kind") in ("YOANIME", "YOANIME_EMBED", "YOANIME_VIDPLAY") and not yoanime_source_is_playable(candidate_url):
                candidate_stream = {
                    "direct": False,
                    "url": candidate_url,
                    "error": "YoAnime media server did not pass its playback health check.",
                }
                xbmc.log(
                    "COSMOS 9anime: skipping stale YoAnime Direct stream and trying the next source",
                    xbmc.LOGWARNING,
                )
            elif candidate.get("source_kind") == "ANIWATCH":
                candidate_stream = resolve_aniwatch(candidate_url)
            elif candidate.get("source_kind") == "ANIDB":
                candidate_stream = client.resolve_anidb(candidate_url)
            else:
                candidate_stream = client.resolve_stream(candidate_url)
        attempted.append((candidate, candidate_stream))
        if candidate_stream.get("direct"):
            stream = candidate_stream
            selected_candidate = candidate
            if resolver_name(candidate_url) == "BYFMS" and not _cached_byfms_stream(candidate_url):
                _cache_byfms_stream(candidate_url, candidate_stream)
            break
    if not stream.get("direct"):
        message = "No native HLS/MP4 stream was returned by the selected 9Anime source."
        if stream.get("error"):
            message += " " + stream["error"]
        xbmc.log("COSMOS 9anime: " + message, xbmc.LOGERROR)
        xbmc.executebuiltin(
            'Notification("C.O.S.M.O.S / 9anime","{0}",5000)'.format(
                message.replace('"', "'").replace("\n", " ")[:240]
            )
        )
        _cancel_playback()
        return

    stream_url = stream["url"]
    url_part, header_part = (stream_url.split("|", 1) + [""])[:2] if "|" in stream_url else (stream_url, "")
    stream_type = stream.get("media_type") or media_type(stream_url)
    # Match Cosmos' normal direct-link handoff: ISA receives a bare manifest
    # URL and the headers separately, while MP4 keeps headers on its path.
    listing = xbmcgui.ListItem(path=url_part if stream_type in ("hls", "mpd") else stream_url)
    listing.setProperty("IsPlayable", "true")
    if stream.get("subtitles"):
        listing.setSubtitles(stream["subtitles"])
    if stream_type in ("hls", "mpd"):
        listing.setMimeType("application/vnd.apple.mpegurl" if stream_type == "hls" else "application/dash+xml")
        listing.setContentLookup(False)
    elif header_part:
        listing.setMimeType("video/mp4")
        listing.setContentLookup(False)
    listing.setInfo(
        "video",
        {
            "title": "{0} - Episode {1}".format(details["title"], number),
            "tvshowtitle": details["title"],
            "episode": number,
        },
    )
    if stream_type in ("hls", "mpd"):
        listing.setProperty("inputstream", "inputstream.adaptive")
        listing.setProperty("inputstream.adaptive.manifest_type", stream_type)
        if header_part:
            listing.setProperty(
                "inputstream.adaptive.manifest_headers",
                header_part,
            )
            listing.setProperty(
                "inputstream.adaptive.stream_headers",
                header_part,
            )
    resolver_label = (
        selected_candidate.get("name") or resolver_name(selected_candidate.get("url")) or "9ANIME"
        if selected_candidate else "9ANIME"
    )
    xbmc.log("COSMOS 9anime: {0} {1} resolved; completing plugin URL".format(
        resolver_label, stream_type or "video"
    ), xbmc.LOGINFO)
    # Use Cosmos' normal completion tracker with a synthetic local-only ID.
    # resume.py recognises the provider marker, blocks remote scrobbling and
    # Continue Watching rows, then refreshes this exact episode container.
    slug = details.get("slug", "")
    watched_id = _watched_id(slug)
    tracker_meta = {
        "title": details.get("title", "9Anime"),
        "content": "episode",
        "tmdb": watched_id,
        "season": "1",
        "episode": str(number),
        "poster": details.get("poster", ""),
        "source": "9anime",
        "provider": "9anime",
        "slug": slug,
        "return_url": _url("anime", slug=slug),
    }
    tracker_key = resume_mod.key_for(
        tmdb=watched_id,
        content="episode",
        season=1,
        episode=number,
    )
    resume_mod.start_tracker(tracker_key, meta=tracker_meta)
    # Clear any queued episode items before handing the resolved stream back
    # to Kodi. Clearing at completion is too late: Kodi may already be
    # resolving the next episode by then.
    _clear_video_playlist()
    xbmcplugin.setResolvedUrl(_handle(), True, listing)


def play(client, slug, episode):
    # An episode click must not inherit a queued video playlist. In
    # particular, backing out of a picker must not cause Kodi to replay the
    # same unresolved episode URL.
    _clear_video_playlist()
    details = client.anime(slug)
    number = int(episode)
    selected = next((ep for ep in details["episodes"] if ep["number"] == number), None)
    if not selected:
        raise NineAnimeError("Episode {0} was not found.".format(number))
    try:
        servers = list(client.episode_servers(slug, number) or selected.get("servers", []))
    except NineAnimeError as exc:
        xbmc.log("COSMOS 9anime: episode providers unavailable: {0}".format(exc), xbmc.LOGDEBUG)
        servers = list(selected.get("servers", []))
    try:
        servers.extend(find_aniwatch_sources(details.get("title", ""), number, details.get("year")))
    except Exception as exc:
        xbmc.log("COSMOS 9anime: Aniwatch unavailable: {0}".format(exc), xbmc.LOGDEBUG)
    if not servers:
        raise NineAnimeError("No stream server is currently listed for this episode.")

    languages = [language for language in ("sub", "dub") if any(
        normalize_language(server.get("type")) == language for server in servers
    )]
    # Some genre titles expose only one language. The old route only assigned
    # ``language`` inside the two-choice dialog, so those titles raised an
    # uncaught UnboundLocalError when an episode was clicked.
    language = languages[0] if languages else normalize_language(servers[0].get("type"))
    if len(languages) > 1:
        # Let the episode-opening click/key release finish before creating the
        # modal. Otherwise Kodi can carry that same input into the dialog and
        # immediately choose its first row (SUB) without showing the choice.
        xbmc.sleep(300)
        language_choice = xbmcgui.Dialog().select(
            "Choose language", ["SUB - Subbed", "DUB - Dubbed"]
        )
        if language_choice < 0:
            _cancel_playback()
            return
        language = languages[language_choice]
    servers = [server for server in servers if normalize_language(server.get("type")) == language]
    if not servers:
        raise NineAnimeError("That episode has no server for the selected language.")

    try:
        anidb_source = find_anidb_source(details.get("title", ""), number, language)
        if anidb_source:
            servers.append(anidb_source)
    except Exception as exc:
        xbmc.log("COSMOS 9anime: AniDB source unavailable: {0}".format(exc), xbmc.LOGDEBUG)

    yoanime_source = None
    try:
        yoanime_source = find_yoanime_source(details.get("title", ""), number, language)
        if yoanime_source:
            servers.append(yoanime_source)
    except Exception as exc:
        xbmc.log("COSMOS 9anime: YoAnime Direct source unavailable: {0}".format(exc), xbmc.LOGDEBUG)

    try:
        yoanime_embed_source = find_yoanime_embed_source(details.get("title", ""), number, language)
        if (yoanime_source and yoanime_embed_source and
                yoanime_sources_match_duration(yoanime_source["url"], yoanime_embed_source["url"])):
            servers.append(yoanime_embed_source)
        elif yoanime_embed_source:
            xbmc.log(
                "COSMOS 9anime: suppressing Vidstream-2 because its duration does not match YoAnime Direct",
                xbmc.LOGWARNING,
            )
    except Exception as exc:
        xbmc.log("COSMOS 9anime: YoAnime Vidstream-2 source unavailable: {0}".format(exc), xbmc.LOGDEBUG)

    try:
        yoanime_vidplay_source = find_yoanime_vidplay_source(details.get("title", ""), number, language)
        if (yoanime_source and yoanime_vidplay_source and
                yoanime_sources_match_duration(yoanime_source["url"], yoanime_vidplay_source["url"])):
            servers.append(yoanime_vidplay_source)
        elif yoanime_vidplay_source:
            xbmc.log(
                "COSMOS 9anime: suppressing VidPlay-1 because its duration does not match YoAnime Direct",
                xbmc.LOGWARNING,
            )
    except Exception as exc:
        xbmc.log("COSMOS 9anime: YoAnime VidPlay-1 source unavailable: {0}".format(exc), xbmc.LOGDEBUG)

    servers = _enabled_sources(servers)
    if not servers:
        raise NineAnimeError("No supported source is available for this episode and language.")
    servers.sort(key=_source_priority)
    # Always let the user review and confirm the source, even when only one
    # provider (such as Yuki) is available for the selected language.
    for candidate in servers:
        candidate["icon"] = _source_icon(candidate)
    picker = nineanime_picker_mod.NineAnimeSourcePickerDialog(
        "NineAnimeSourcePicker.xml",
        _cosmos().ADDON_PATH,
        "Default",
        "720p",
        servers=servers,
        title=details.get("title", "9Anime"),
        poster=details.get("poster", ""),
        language=language,
        episode=number,
    )
    picker.doModal()
    choice = picker.selected_index
    if choice is None or choice < 0:
        _cancel_playback()
        return
    server = servers[choice]

    ordered_servers = [server] + [candidate for candidate in servers if candidate is not server]
    # Keep resolution and setResolvedUrl inside the live Kodi plugin callback.
    # This is required on Android/Shield, where a daemon thread can outlive
    # (or lose) the language-invoker handle and leave playback spinning.
    _start_native_playback(client, details, number, ordered_servers)


def open_page(client, path):
    xbmc.executebuiltin('System.OpenURL("{0}")'.format(client.absolute(path).replace('"', "")))
    _end(False)


def dispatch(params):
    action = params.get("action", "nineanime_root")
    if action.startswith("nineanime_"):
        action = action[len("nineanime_"):]
    client = _client()
    try:
        if not action or action == "root":
            root()
        elif action == "browse":
            browse(client, params.get("path"), int(params.get("page", "1")))
        elif action == "genres":
            genres()
        elif action == "advanced":
            advanced_browse(client)
        elif action == "search":
            search(client)
        elif action == "anime":
            anime(client, params["slug"])
        elif action == "about":
            about(client, params["slug"])
        elif action == "play":
            play(client, params["slug"], params["episode"])
        elif action in ("mark_watched", "mark_unwatched"):
            set_episode_watched(
                params["slug"], params["episode"], action == "mark_watched")
        elif action == "random":
            anime(client, client.random_slug())
        elif action == "open":
            open_page(client, params.get("path", "/contact"))
        elif action == "install_isa":
            install_inputstream_adaptive()
    except (NineAnimeError, ValueError, KeyError) as exc:
        xbmc.log("COSMOS 9anime: {0}".format(exc), xbmc.LOGERROR)
        xbmcgui.Dialog().ok("C.O.S.M.O.S / 9anime", str(exc))
        try:
            if action == "play":
                _cancel_playback()
            else:
                xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        except Exception:
            pass
    except Exception as exc:
        # Keep a route-specific failure from bubbling into Cosmos' generic
        # addon-startup dialog. This also leaves Kodi's plugin handle closed
        # when a live site markup change hits a submenu parser.
        message = "{0}: {1}".format(exc.__class__.__name__, str(exc).strip())
        xbmc.log("COSMOS 9anime unexpected error: {0}".format(message), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "C.O.S.M.O.S / 9anime",
            "This 9Anime menu could not be opened.\n\n{0}".format(message[:400]),
        )
        try:
            if action == "play":
                _cancel_playback()
            else:
                xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        except Exception:
            pass
