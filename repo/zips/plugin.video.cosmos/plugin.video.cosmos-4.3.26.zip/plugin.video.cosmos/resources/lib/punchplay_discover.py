"""Public PunchPlay search and discovery, fetched only on user interaction."""
import json
import os
import sqlite3
import time
from urllib.parse import urlencode

import xbmcgui
import xbmcplugin

from . import punchplay as api

TYPES = {'movie': 'Movies', 'show': 'Shows', 'anime': 'Anime'}
CATEGORIES = {'popular': 'Popular', 'now_playing': 'Now Playing',
              'upcoming': 'Upcoming', 'top_rated': 'Top Rated'}
CACHE_TTL = 3600


def catalog(media_type, category='', query=None):
    """Serialize misses, cache for an hour and retain stale results on errors."""
    if media_type not in TYPES:
        raise ValueError('Invalid catalog type')
    if query is not None:
        query = ' '.join(str(query).split())
        if not 2 <= len(query) <= 100:
            raise ValueError('Search must contain 2 to 100 characters')
        path = '/catalog/search?' + urlencode({'type': media_type, 'q': query})
    else:
        if category not in CATEGORIES:
            raise ValueError('Invalid discovery category')
        path = '/catalog/discover?' + urlencode({'type': media_type, 'category': category})
    os.makedirs(api.DATA_PATH, exist_ok=True)
    db = sqlite3.connect(os.path.join(api.DATA_PATH, 'punchplay_discover.db'), timeout=30)
    try:
        db.execute('CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, value TEXT)')
        db.execute('BEGIN IMMEDIATE')

        def read(key):
            row = db.execute('SELECT value FROM cache WHERE key=?', (key,)).fetchone()
            return json.loads(row[0]) if row else {}

        def save(key, value):
            db.execute('INSERT OR REPLACE INTO cache VALUES (?,?)', (key, json.dumps(value)))

        record, limits = read(path), read('limits')
        now = time.time()
        if now - record.get('at', 0) < CACHE_TTL:
            return record.get('items', []), ''
        if now < max(record.get('retry_at', 0), limits.get('until', 0)):
            return record.get('items', []), record.get('error') or limits.get('error', '')
        # One miss in flight across Kodi invocations, at most one per second.
        time.sleep(max(0, 1 - (now - limits.get('last', 0))))
        status, data, headers = api._http_json(path, method='GET', api_base=api.PUBLIC_API_BASE)
        limits['last'] = time.time()
        valid = status == 200 and isinstance(data, dict) and isinstance(data.get('items'), list)
        if valid:
            record = {'at': time.time(), 'items': data['items']}
        else:
            record.update(retry_at=time.time() + 300,
                          error='PunchPlay catalog unavailable; try again later')
        if status == 429:
            try:
                wait = max(1, int(api._header(headers, 'Retry-After') or 60))
            except (ValueError, OverflowError):
                wait = 60
            limits.update(until=time.time() + wait,
                          error='PunchPlay catalog rate limit reached; try again later')
            record.update(retry_at=limits['until'], error=limits['error'])
        elif api._header(headers, 'X-RateLimit-Remaining') == '0':
            try:
                limits['until'] = max(time.time() + 1, float(api._header(headers, 'X-RateLimit-Reset')))
            except (ValueError, OverflowError):
                limits['until'] = time.time() + 60
            limits['error'] = 'PunchPlay catalog rate limit reached; try again later'
        save(path, record)
        save('limits', limits)
        # Bound typed-query storage while retaining discovery and rate state.
        db.execute("DELETE FROM cache WHERE key IN (SELECT key FROM cache "
                   "WHERE key LIKE '/catalog/search?%' ORDER BY rowid DESC "
                   "LIMIT -1 OFFSET 100)")
        db.commit()
        return record.get('items', []), record.get('error', '')
    finally:
        db.close()


def folder(label, action='punchplay_discover', **params):
    item = xbmcgui.ListItem(label=label)
    item.setArt({'icon': api._submenu_icon(), 'thumb': api._submenu_icon()})
    xbmcplugin.addDirectoryItem(api._handle(), api._url(action=action, **params),
                               item, isFolder=True)


def title_row(source):
    """Use returned artwork and metadata without fetching each title again."""
    if not isinstance(source, dict) or source.get('type') not in ('movie', 'show'):
        return
    try:
        tmdb = int(source.get('tmdbId') or 0)
    except (TypeError, ValueError):
        return
    if tmdb <= 0:
        return
    title = str(source.get('name') or 'Untitled')
    year = str(source.get('year') or '')
    movie = source['type'] == 'movie'
    poster = api._collection_art(source.get('posterUrl') or source.get('posterPath'))
    fanart = api._collection_art(source.get('backdropUrl') or source.get('backdropPath'))
    item = xbmcgui.ListItem(label=title + (' (%s)' % year if year else ''))
    from . import punchplay_actions
    actions = punchplay_actions.context_items(source)
    if actions:
        item.addContextMenuItems(actions)
    item.setArt({'poster': poster, 'thumb': poster, 'icon': poster or api._icon(), 'fanart': fanart})
    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(title)
        tag.setMediaType('movie' if movie else 'tvshow')
        tag.setPlot(str(source.get('overview') or ''))
        if year.isdigit():
            tag.setYear(int(year))
    except AttributeError:
        pass
    if movie:
        item.setProperty('IsPlayable', 'true')
        payload = json.dumps({'title': title, 'year': year, 'tmdb': str(tmdb),
                              'content': 'movie', 'poster': poster, 'fanart': fanart})
        target = api._url(action='link_zero', payload=payload)
    else:
        target = api._url(action='tmdb_tv_seasons', tmdb=str(tmdb), name=title,
                          year=year, poster=poster, fanart=fanart)
    xbmcplugin.addDirectoryItem(api._handle(), target, item, isFolder=not movie)


def menu(media_type='', category=''):
    if not api.has_token():
        api.menu_root()
        return
    if not media_type:
        for kind, label in TYPES.items():
            folder(label, type=kind)
    elif media_type in TYPES and not category:
        for key, label in CATEGORIES.items():
            folder(label, type=media_type, category=key)
    elif media_type in TYPES and category in CATEGORIES:
        try:
            items, error = catalog(media_type, category)
        except (OSError, ValueError, sqlite3.Error):
            items, error = [], 'PunchPlay Discover unavailable; try again later'
        if error:
            xbmcgui.Dialog().notification('PunchPlay Discover', error,
                                          xbmcgui.NOTIFICATION_WARNING, 4000)
        for source in items:
            title_row(source)
        if not items:
            api._row(error or 'No titles available in this category', 'punchplay_discover')
        xbmcplugin.setContent(api._handle(), 'movies' if media_type == 'movie' else 'videos')
    else:
        api._row('Invalid discovery category', 'punchplay_discover')
    # Public discovery returns a bounded selection, without API pagination.
    xbmcplugin.endOfDirectory(api._handle(), succeeded=True, cacheToDisc=False)


def search_menu(media_type='', query=''):
    """Submit user text to the public search endpoint, without live polling."""
    if not api.has_token():
        api.menu_root()
        return
    if not media_type:
        for kind, label in TYPES.items():
            folder('Search ' + label, action='punchplay_search', type=kind)
    elif media_type in TYPES:
        if not query:
            query = xbmcgui.Dialog().input('Search PunchPlay ' + TYPES[media_type])
        query = ' '.join(str(query or '').split())
        if query:
            if not 2 <= len(query) <= 100:
                xbmcgui.Dialog().notification('PunchPlay Search',
                    'Enter between 2 and 100 characters', xbmcgui.NOTIFICATION_WARNING, 3000)
            else:
                try:
                    items, error = catalog(media_type, query=query)
                except (OSError, ValueError, sqlite3.Error):
                    items, error = [], 'PunchPlay Search unavailable; try again later'
                if error:
                    xbmcgui.Dialog().notification('PunchPlay Search', error,
                                                  xbmcgui.NOTIFICATION_WARNING, 4000)
                for source in items:
                    title_row(source)
                if not items:
                    api._row(error or 'No matching titles found', 'punchplay_search')
                xbmcplugin.setContent(api._handle(), 'movies' if media_type == 'movie' else 'videos')
    else:
        api._row('Invalid search type', 'punchplay_search')
    xbmcplugin.endOfDirectory(api._handle(), succeeded=True, cacheToDisc=False)
