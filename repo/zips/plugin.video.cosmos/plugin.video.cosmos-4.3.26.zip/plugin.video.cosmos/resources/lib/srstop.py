"""Find SRStop TV episode links and probe SaveFiles MP4 streams."""
import json
import re
import time
import unicodedata
from html import unescape
from html.parser import HTMLParser
from urllib.parse import urlencode, urljoin, urlsplit
from urllib.request import Request, urlopen

BASE = 'https://srstop.link'
API = 'https://savefiles.com/api/file/direct_link'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': BASE + '/'}


def _log(message, level=None):
    """Log safe SaveFiles diagnostics without URLs, file codes or API keys."""
    try:
        import xbmc
        xbmc.log('COSMOS SaveFiles: ' + message,
                 xbmc.LOGINFO if level is None else level)
    except Exception:
        pass


class SourceError(Exception):
    """A safe user-facing source resolution error."""


class _Links(HTMLParser):
    def __init__(self, body):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.current = None
        self.feed(body)

    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            self.current = [dict(attrs), '']

    def handle_data(self, data):
        if self.current is not None:
            self.current[1] += data

    def handle_endtag(self, tag):
        if tag == 'a' and self.current is not None:
            self.links.append(self.current)
            self.current = None


def _fetch(url, timeout=15):
    try:
        with urlopen(Request(url, headers=HEADERS), timeout=timeout) as response:
            body = response.read(4 * 1024 * 1024 + 1)
        if len(body) > 4 * 1024 * 1024:
            raise ValueError('Oversized response')
        return body.decode('utf-8', errors='replace')
    except Exception:
        # Network exception text may contain the configured API key or a
        # signed media URL, so only expose a fixed message.
        raise SourceError('Unable to contact SRStop or SaveFiles. Please try again.') from None


def _json(url, timeout=15):
    try:
        return json.loads(_fetch(url, timeout))
    except (ValueError, TypeError):
        raise SourceError('The source returned an unexpected response.') from None


def _site_url(value):
    url = urljoin(BASE + '/', str(value or ''))
    parts = urlsplit(url)
    if (parts.scheme == 'https' and parts.netloc == 'srstop.link'
            and parts.path.startswith('/show/')):
        return url
    return ''


def _normal(value):
    value = unicodedata.normalize('NFKD', unescape(str(value or ''))).casefold()
    return ''.join(char for char in value if char.isalnum())


def match_show(rows, meta):
    """Match by external ID, or one unique exact title and year."""
    if not isinstance(rows, list):
        raise SourceError('SRStop returned an unexpected search response.')
    matches, fallback = [], []
    names = {_normal(meta.get(key)) for key in ('title', 'originaltitle')}
    names.discard('')
    for row in rows:
        if not isinstance(row, dict) or not _site_url(row.get('permalink')):
            continue
        pairs = [(str(meta.get(a) or ''), str(row.get(b) or ''))
                 for a, b in (('imdb_id', 'imdb_id'), ('tvdb_id', 'ttvdb_id'))]
        if any(left and right and left != right for left, right in pairs):
            continue
        if any(left and left == right for left, right in pairs):
            matches.append(row['permalink'])
        elif (_normal(row.get('title')) in names and meta.get('year')
              and str(row.get('year')) == str(meta['year'])):
            fallback.append(row['permalink'])
    candidates = list(dict.fromkeys(matches or fallback))
    if len(candidates) != 1:
        raise SourceError('No unambiguous matching show was found on SRStop.')
    return candidates[0]



def _find_show(meta):
    """Retry a shortened search, retaining strict ID/title-year matching."""
    titles = list(dict.fromkeys(str(meta.get(key) or '').strip()
                                for key in ('title', 'originaltitle')))
    titles = [title for title in titles if title]
    if not titles:
        raise SourceError('Show metadata is unavailable.')
    queries = list(dict.fromkeys(titles + [' '.join(title.split()[:3])
                                          for title in titles
                                          if len(title.split()) > 3]))
    for query in queries:
        rows = _json(BASE + '/ajax/search.php?' + urlencode({'q': query}))
        try:
            return match_show(rows, meta)
        except SourceError:
            if not isinstance(rows, list):
                raise
    raise SourceError('No unambiguous matching show was found on SRStop.')


def episode_url(body, season, episode, show=''):
    suffix = '/season/%d/episode/%d' % (season, episode)
    show_path = urlsplit(_site_url(show)).path.rstrip('/') if show else ''
    for attrs, _text in _Links(body).links:
        url = _site_url(attrs.get('href'))
        path = urlsplit(url).path.rstrip('/')
        if not url or not path.endswith(suffix):
            continue
        if show:
            prefix = path[:-len(suffix)]
            # SRStop uses both the show slug and episode-specific slugs,
            # e.g. /show/the-simpsons-s37e01/season/37/episode/1.
            tagged = re.fullmatch(re.escape(show_path) + r'-s(\d+)e(\d+)', prefix, re.I)
            if prefix != show_path and not (
                    tagged and int(tagged[1]) == season and int(tagged[2]) == episode):
                continue
        return url
    raise SourceError('This episode is not listed on SRStop.')


def _decode_link(value):
    """Decode SRStop's hex character-offset links without executing scripts."""
    match = re.search(r"dbneg\(['\"]([0-9a-fA-F-]+)['\"]\)", value or '')
    if not match:
        return ''
    try:
        numbers = [int(part, 16) for part in match[1].split('-')]
        offset = numbers[0] - ord('h')
        result = ''.join(chr(number - offset) for number in numbers)
        return result if result.startswith(('https://', 'http://')) else ''
    except (ValueError, OverflowError, IndexError):
        return ''


def savefiles_links(body):
    found = []
    for attrs, text in _Links(body).links:
        url = _decode_link(attrs.get('onclick')) or attrs.get('href', '')
        parts = urlsplit(url)
        if parts.scheme not in ('http', 'https') or parts.netloc not in ('savefiles.com', 'www.savefiles.com'):
            continue
        code = re.fullmatch(r'/(?:embed-)?([a-zA-Z0-9]{12})(?:\.html)?/?', parts.path)
        if not code or any(item['code'] == code[1] for item in found):
            continue
        quality = re.search(r'\b(2160|1080|720|480|360)\b', text)
        found.append({'code': code[1], 'quality': int(quality[1]) if quality else 0})
    return sorted(found, key=lambda item: item['quality'], reverse=True)


def lulustream_links(body):
    """Return LuluStream file codes linked from an SRStop episode page."""
    found = []
    for attrs, text in _Links(body).links:
        url = _decode_link(attrs.get('onclick')) or attrs.get('href', '')
        parts = urlsplit(url)
        if parts.scheme not in ('http', 'https') or parts.netloc.casefold() not in (
                'lulustream.com', 'www.lulustream.com',
                'luluvdo.com', 'www.luluvdo.com',
                'lulust.com', 'www.lulust.com'):
            continue
        match = re.fullmatch(r'/(?:embed-|e/|d/)?([a-zA-Z0-9]{6,})(?:\.html)?/?', parts.path)
        if not match or any(item['code'] == match[1] for item in found):
            continue
        quality = re.search(r'\b(2160|1080|720|480|360)\b', text)
        found.append({'code': match[1], 'url': url,
                      'quality': int(quality[1]) if quality else 0})
    return sorted(found, key=lambda item: item['quality'], reverse=True)


def streamtape_links(body):
    """Return Streamtape embed links from an SRStop episode page."""
    mirror_prefixes = ('streamta.pe', 'shavetape.', 'strcloud.',
                       'strtape.', 'streamadblocker.')
    found = []
    for attrs, text in _Links(body).links:
        url = _decode_link(attrs.get('onclick')) or attrs.get('href', '')
        parts = urlsplit(url)
        host = (parts.hostname or '').casefold()
        if host.startswith('www.'):
            host = host[4:]
        is_streamtape = (host.startswith('streamtape.') or
                         host == 'streamta.pe' or
                         any(host == prefix.rstrip('.') or host.startswith(prefix)
                             for prefix in mirror_prefixes))
        if parts.scheme not in ('http', 'https') or not is_streamtape:
            continue
        # SRStop currently links /e/ embeds, while mirrors also use /v/ and
        # /embed/ routes. Retain the actual page URL and query parameters.
        if not re.fullmatch(r'/(?:e|v|embed)/[A-Za-z0-9_-]+(?:\.html)?(?:/[^?#]*)?',
                            parts.path, re.I):
            continue
        if any(item['url'] == url for item in found):
            continue
        quality = re.search(r'\b(2160|1080|720|480|360)\b', text)
        found.append({'url': url, 'quality': int(quality[1]) if quality else 0})
    return sorted(found, key=lambda item: item['quality'], reverse=True)


def discover_hosts(meta, season, episode):
    """List only supported hosts linked on the exact matched show episode."""
    season, episode = int(season), int(episode)
    if season < 0 or episode < 1:
        raise SourceError('A valid season and episode are required.')
    show = _find_show(meta)
    page = _fetch(show.rstrip('/') + '/season/%d' % season)
    url = episode_url(page, season, episode, show)
    body = _fetch(url)
    parsers = (('SaveFiles (HLS)', savefiles_links),
               ('LuluStream', lulustream_links),
               ('Streamtape', streamtape_links),
               ('DoodStream', doodstream_links), ('Byse', byse_links), ('VOE', voe_links),
               ('Morencius', morencius_links), ('Vidara', vidara_links),
               ('Streamplay', streamplay_links))
    return {name: links for name, parser in parsers
            for links in [parser(body)] if links}


def discover(meta, season, episode):
    show = _find_show(meta)
    page = _fetch(show.rstrip('/') + '/season/%d' % season)
    url = episode_url(page, season, episode, show)
    links = savefiles_links(_fetch(url))
    if not links:
        _log('SRStop episode has no SaveFiles links (season=%s episode=%s)' %
             (season, episode), _warning_level())
        raise SourceError('No SaveFiles links are listed for this episode.')
    qualities = ','.join('%sp' % link['quality'] if link['quality'] else 'unknown'
                         for link in links)
    _log('SRStop episode links found (season=%s episode=%s count=%d qualities=%s)' %
         (season, episode, len(links), qualities))
    return links


def doodstream_links(body):
    """Detect plain and SRStop-obfuscated DoodStream/Playmogo links."""
    from .doodstream import is_url
    found = []
    for attrs, text in _Links(body).links:
        url = _decode_link(attrs.get('onclick')) or unescape(attrs.get('href', ''))
        if not is_url(url) or any(item['url'] == url for item in found):
            continue
        quality = re.search(r'\b(2160|1080|720|480|360)\b', text)
        found.append({'url': url, 'quality': int(quality[1]) if quality else 0})
    return sorted(found, key=lambda item: item['quality'], reverse=True)


def discover_doodstream(meta, season, episode):
    """Find DoodStream/Playmogo links for the exact matched show episode."""
    show = _find_show(meta)
    page = _fetch(show.rstrip('/') + '/season/%d' % season)
    url = episode_url(page, season, episode, show)
    links = doodstream_links(_fetch(url))
    if not links:
        raise SourceError('No DoodStream or Playmogo links are listed for this episode.')
    return links


def discover_lulustream(meta, season, episode):
    """Find LuluStream links on the SRStop episode page."""
    show = _find_show(meta)
    page = _fetch(show.rstrip('/') + '/season/%d' % season)
    url = episode_url(page, season, episode, show)
    links = lulustream_links(_fetch(url))
    if not links:
        raise SourceError('No LuluStream links are listed for this episode.')
    _log('SRStop LuluStream links found (season=%s episode=%s count=%d)' %
         (season, episode, len(links)))
    return links


def discover_streamtape(meta, season, episode):
    """Find Streamtape links on the matched SRStop episode page."""
    show = _find_show(meta)
    page = _fetch(show.rstrip('/') + '/season/%d' % season)
    url = episode_url(page, season, episode, show)
    links = streamtape_links(_fetch(url))
    if not links:
        raise SourceError('No Streamtape links are listed for this episode.')
    _log('SRStop Streamtape links found (season=%s episode=%s count=%d)' %
         (season, episode, len(links)))
    return links


def byse_links(body):
    """Extract supported Byse embeds, including SRStop-obfuscated links."""
    found = []
    for attrs, text in _Links(body).links:
        url = _decode_link(attrs.get('onclick')) or unescape(attrs.get('href', ''))
        parts = urlsplit(url)
        host = (parts.hostname or '').casefold()
        host = host[4:] if host.startswith('www.') else host
        if (parts.scheme not in ('http', 'https') or parts.username
                or host not in ('bysesayeveum.com', 'bysesukior.com', 'bysewihe.com', 'bysekoze.com', 'byseraguci.com')
                or not re.fullmatch(r'/(?:d|e)/[A-Za-z0-9]+/?', parts.path)):
            continue
        if any(link['url'] == url for link in found):
            continue
        quality = re.search(r'\b(2160|1080|720|480|360)\b', text)
        found.append({'url': url, 'quality': int(quality[1]) if quality else 0})
    return sorted(found, key=lambda link: link['quality'], reverse=True)


def discover_byse(meta, season, episode):
    """Find Byse sources for the matched show and exact episode."""
    show = _find_show(meta)
    page = _fetch(show.rstrip('/') + '/season/%d' % season)
    url = episode_url(page, season, episode, show)
    links = byse_links(_fetch(url))
    if not links:
        raise SourceError('No Byse links are listed for this episode.')
    return links


def voe_links(body):
    """Detect VOE and its hidden mirror on the matched episode page."""
    from .voe import is_url
    found = []
    for attrs, text in _Links(body).links:
        url = _decode_link(attrs.get('onclick')) or unescape(attrs.get('href', ''))
        if not is_url(url) or any(link['url'] == url for link in found):
            continue
        quality = re.search(r'\b(2160|1080|720|480|360)\b', text)
        found.append({'url': url, 'quality': int(quality[1]) if quality else 0})
    return sorted(found, key=lambda link: link['quality'], reverse=True)


def morencius_links(body):
    """Detect plain and obfuscated Morencius episode links."""
    from .morencius import is_url
    found = []
    for attrs, text in _Links(body).links:
        url = _decode_link(attrs.get('onclick')) or unescape(attrs.get('href', ''))
        if not is_url(url) or any(link['url'] == url for link in found):
            continue
        quality = re.search(r'\b(2160|1080|720|480|360)\b', text)
        found.append({'url': url, 'quality': int(quality[1]) if quality else 0})
    return sorted(found, key=lambda link: link['quality'], reverse=True)


def discover_morencius(meta, season, episode):
    show = _find_show(meta)
    page = _fetch(show.rstrip('/') + '/season/%d' % season)
    url = episode_url(page, season, episode, show)
    links = morencius_links(_fetch(url))
    if not links:
        raise SourceError('No Morencius links are listed for this episode.')
    return links


def discover_voe(meta, season, episode):
    show = _find_show(meta)
    page = _fetch(show.rstrip('/') + '/season/%d' % season)
    url = episode_url(page, season, episode, show)
    links = voe_links(_fetch(url))
    if not links:
        raise SourceError('No VOE links are listed for this episode.')
    return links


def vidara_links(body):
    """Collect original and mirror links listed on the SRStop episode."""
    from .vidara import is_url
    found = []
    for attrs, text in _Links(body).links:
        url = _decode_link(attrs.get('onclick')) or unescape(attrs.get('href', ''))
        if not is_url(url) or any(link['url'] == url for link in found):
            continue
        quality = re.search(r'\b(2160|1080|720|480|360)(?:p)?\b', text, re.I)
        found.append({'url': url, 'quality': int(quality[1]) if quality else 0})
    return sorted(found, key=lambda link: link['quality'], reverse=True)


def streamplay_links(body):
    from .streamplay import is_url
    found = []
    for attrs, text in _Links(body).links:
        url = _decode_link(attrs.get('onclick')) or unescape(attrs.get('href', ''))
        if not is_url(url) or any(link['url'] == url for link in found):
            continue
        quality = re.search(r'\b(2160|1080|720|480|360)(?:p)?\b', text, re.I)
        found.append({'url': url, 'quality': int(quality[1]) if quality else 0})
    return sorted(found, key=lambda link: link['quality'], reverse=True)


def discover_streamplay(meta, season, episode):
    show = _find_show(meta)
    page = _fetch(show.rstrip('/') + '/season/%d' % season)
    url = episode_url(page, season, episode, show)
    links = streamplay_links(_fetch(url))
    if not links:
        raise SourceError('No Streamplay links are listed for this episode.')
    return links


def discover_vidara(meta, season, episode):
    show = _find_show(meta)
    page = _fetch(show.rstrip('/') + '/season/%d' % season)
    url = episode_url(page, season, episode, show)
    links = vidara_links(_fetch(url))
    if not links:
        raise SourceError('No Vidara links are listed for this episode.')
    return links


def _warning_level():
    try:
        import xbmc
        return xbmc.LOGWARNING
    except Exception:
        return None


def probe_stream(stream, timeout=8):
    """Read a small validation sample from a real candidate; never play it."""
    stream_type = stream.get('type')
    if stream_type not in ('hls', 'mp4'):
        _log('validation sample rejected (unsupported stream type)')
        return False
    _log('reading validation sample from real %s candidate (playback uses the resolved stream URL)' %
         stream_type)
    headers = dict(stream.get('headers') or {})
    headers.update({'Range': 'bytes=0-16383', 'Accept-Encoding': 'identity'})
    try:
        with urlopen(Request(stream['url'], headers=headers), timeout=timeout) as response:
            if response.status not in (200, 206):
                _log('validation sample failed (type=%s http_status=%s)' %
                     (stream_type, response.status), _warning_level())
                return False
            if response.status == 206 and not re.match(
                    r'bytes 0-\d+/\d+', response.headers.get('Content-Range', '')):
                _log('validation sample failed (type=%s invalid_range_response)' %
                     stream_type, _warning_level())
                return False
            sample = response.read(16384)
        if stream_type == 'hls':
            valid = sample.lstrip().startswith(b'#EXTM3U') and b'#EXT-X-' in sample
        else:
            valid = False
            offset = 0
            while offset + 16 <= len(sample):
                size = int.from_bytes(sample[offset:offset + 4], 'big')
                box = sample[offset + 4:offset + 8]
                if size < 8:
                    break
                if box == b'ftyp':
                    valid = size >= 16 and offset + size <= len(sample) and len(sample) > offset + size
                    break
                if box not in (b'free', b'skip', b'wide'):
                    break
                offset += size
        _log('validation sample %s (type=%s bytes=%d; sample is not played)' %
             ('passed' if valid else 'failed', stream_type, len(sample)),
             None if valid else _warning_level())
        return valid
    except Exception as exc:
        _log('validation sample request failed (type=%s error=%s)' %
             (stream_type, type(exc).__name__), _warning_level())
        return False


def direct_stream(key, code, deadline=None):
    timeout = min(12, max(1, deadline - time.monotonic())) if deadline else 12
    # SaveFiles' API docs require hls=1 to request an HLS manifest.
    data = _json(API + '?' + urlencode({'key': key, 'file_code': code, 'hls': '1'}), timeout)
    if not isinstance(data, dict) or str(data.get('status')) != '200':
        raise SourceError('SaveFiles could not resolve this file. Check API access or try another link.')
    result = data.get('result')
    if not isinstance(result, dict):
        raise SourceError('SaveFiles returned no playable file.')
    # SaveFiles only returns its HLS manifest when HLS is enabled for the
    # account. Prefer this so Kodi can use InputStream Adaptive. If that
    # option is unavailable, retain the already-tested native MP4 path.
    hls_url = result.get('hls_direct')
    if isinstance(hls_url, str) and urlsplit(hls_url).scheme in ('http', 'https') and urlsplit(hls_url).netloc:
        stream = {'url': hls_url, 'type': 'hls', 'headers': {'User-Agent': 'Mozilla/5.0'}}
        probe_timeout = min(8, max(1, deadline - time.monotonic())) if deadline else 8
        if probe_stream(stream, probe_timeout):
            _log('real candidate accepted (type=hls); returning resolved playback URL')
            return stream
        _log('HLS candidate rejected; checking available MP4 versions', _warning_level())
    versions = result.get('versions') or []
    if not isinstance(versions, list):
        versions = []
    ranks = {'o': 4, 'h': 3, 'n': 2, 'l': 1}
    versions = sorted((item for item in versions if isinstance(item, dict)),
                      key=lambda item: ranks.get(item.get('name'), 0), reverse=True)
    for index, version in enumerate(versions, 1):
        if deadline is not None and time.monotonic() >= deadline:
            break
        url = version.get('url')
        if not isinstance(url, str) or urlsplit(url).scheme not in ('http', 'https') or not urlsplit(url).netloc:
            continue
        stream = {'url': url, 'type': 'mp4', 'headers': {'User-Agent': 'Mozilla/5.0'}}
        probe_timeout = min(8, max(1, deadline - time.monotonic())) if deadline else 8
        if probe_stream(stream, probe_timeout):
            _log('real candidate accepted (type=mp4 version_rank=%d); returning resolved playback URL' % index)
            return stream
        _log('MP4 version candidate rejected (rank=%d)' % index, _warning_level())
    raise SourceError('No accessible MP4 version was found for this file.')


def working_stream(key, links):
    """Try ranked SaveFiles files until an HLS or MP4 probe passes."""
    deadline = time.monotonic() + 60
    _log('checking %d real SaveFiles episode candidate(s); no test media is used for playback' %
         len(links))
    for index, link in enumerate(links, 1):
        if time.monotonic() >= deadline:
            break
        try:
            stream = direct_stream(key, link['code'], deadline)
            _log('episode candidate %d/%d selected for playback (type=%s)' %
                 (index, len(links), stream.get('type', 'unknown')))
            return stream
        except SourceError:
            _log('episode candidate %d/%d could not be resolved' %
                 (index, len(links)), _warning_level())
            continue
    raise SourceError('No SaveFiles source passed the playback check. Files may be unavailable or account access may be restricted.')


def resolve(tmdb_id, season, episode):
    import xbmcaddon
    from . import tmdb

    key = xbmcaddon.Addon('plugin.video.cosmos').getSetting('savefiles_api_key').strip()
    if not key:
        _log('resolution stopped (API key is not configured)', _warning_level())
        return {'error': 'Enter your SaveFiles API key in Cosmos Settings > Playback.'}
    _log('resolving real episode stream (tmdb_id=%s season=%s episode=%s)' %
         (tmdb_id, season, episode))
    try:
        meta = tmdb.get_metadata(tmdb_id, 'tv')
        stream = working_stream(key, discover(meta, season, episode))
        _log('resolution complete (type=%s; selected real episode stream)' % stream['type'])
        return stream
    except SourceError as exc:
        _log('resolution failed (%s)' % str(exc), _warning_level())
        return {'error': str(exc)}
    except Exception as exc:
        _log('resolution failed (unexpected error=%s)' % type(exc).__name__, _warning_level())
        return {'error': 'SRStop / SaveFiles could not resolve this episode. Please try again.'}
