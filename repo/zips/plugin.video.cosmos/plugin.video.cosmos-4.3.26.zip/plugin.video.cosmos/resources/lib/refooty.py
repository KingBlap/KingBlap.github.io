# -*- coding: utf-8 -*-
"""Small ReFooty catalogue client for the Cosmos Sports Hub."""
import html
import re
from urllib.parse import urljoin
from urllib.request import Request, urlopen


BASE_URL = 'https://refooty.com/'
FULL_MATCHES_URL = urljoin(BASE_URL, 'full-matches')
_PAGE_CACHE = {}
_META_CACHE = {}

COUNTRIES = {
    'England': ('england', ('Premier League', 'FA Cup', 'Championship', 'League One', 'League Two')),
    'Spain': ('spain', ('La Liga', 'Segunda Division', 'Copa del Rey')),
    'France': ('france', ('Ligue 1', 'Ligue 2', 'Coupe de France')),
    'Germany': ('germany', ('Bundesliga', '2. Bundesliga', 'DFB-Pokal')),
    'Italy': ('italy', ('Serie A', 'Serie B', 'Coppa Italia')),
    'USA': ('usa', ('Major League Soccer', 'USL Championship', 'US Open Cup')),
    'Other Leagues': ('other-leagues', ('A-League', 'Eredivisie', 'Primeira Liga', 'Brasileirao', 'Super Lig')),
    'European': ('european', ('UEFA Champions League', 'UEFA Europa League', 'UEFA Europa Conference League')),
    'International': ('international', ('World Cup 2026', 'World Cup Qualifiers', 'FIFA Club World Cup', 'CONMEBOL Libertadores')),
}


def _get(url):
    if url in _PAGE_CACHE:
        return _PAGE_CACHE[url]
    request = Request(url, headers={'User-Agent': 'Mozilla/5.0 Cosmos Kodi addon'})
    with urlopen(request, timeout=20) as response:
        body = response.read().decode('utf-8', 'replace')
    _PAGE_CACHE[url] = body
    return body


def metadata(page_url, fallback_title=''):
    """Extract Kodi-friendly metadata from a ReFooty video page."""
    if page_url in _META_CACHE:
        return dict(_META_CACHE[page_url])
    try:
        body = html.unescape(_get(page_url))
    except Exception:
        body = ''
    def first(patterns):
        for pattern in patterns:
            match = re.search(pattern, body, re.I | re.S)
            if match:
                value = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', match.group(1))).strip()
                if value:
                    return value
        return ''
    title = first((r'<meta[^>]+(?:property|name)=["\'](?:og:title|title|headline)["\'][^>]+content=["\']([^"\']+)', r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\'](?:og:title|title|headline)["\']', r'<h1[^>]*>(.*?)</h1>')) or fallback_title
    description = first((r'<meta[^>]+(?:name|property)=["\'](?:description|og:description)["\'][^>]+content=["\']([^"\']+)', r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:name|property)=["\'](?:description|og:description)["\']'))
    thumb = first((r'<meta[^>]+(?:property|name)=["\']og:image["\'][^>]+content=["\']([^"\']+)', r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\']og:image["\']'))
    published = first((r'<meta[^>]+(?:property|name)=["\'](?:article:published_time|date|uploadDate)["\'][^>]+content=["\']([^"\']+)', r'"(?:datePublished|uploadDate)"\s*:\s*"([^"]+)'))
    duration = first((r'<meta[^>]+(?:property|name)=["\'](?:video:duration|duration)["\'][^>]+content=["\']([^"\']+)', r'"duration"\s*:\s*"([^"]+)'))
    duration_match = re.fullmatch(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?', duration or '', re.I)
    runtime = int(float(duration_match.group(1) or 0) * 3600 + float(duration_match.group(2) or 0) * 60 + float(duration_match.group(3) or 0)) if duration_match else 0
    meta = {'title': title, 'plot': description, 'premiered': published[:10] if re.match(r'\d{4}-\d{2}-\d{2}', published) else published, 'year': int(published[:4]) if re.match(r'\d{4}', published) else 0, 'runtime': runtime, 'genre': 'Football, Sports', 'studio': 'ReFooty', 'thumb': thumb, 'fanart': thumb, 'mediatype': 'video'}
    _META_CACHE[page_url] = dict(meta)
    return meta


def _video_catalogue(page_url, page=1):
    """Return one page of ReFooty video links from a catalogue page."""
    try:
        page = max(int(page or 1), 1)
    except (TypeError, ValueError):
        page = 1
    request_url = page_url if page == 1 else f'{page_url}?page={page}'
    body = _get(request_url)
    found = []
    seen = set()
    pattern = re.compile(
        r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
        re.I | re.S,
    )
    anchors = pattern.findall(body)
    # ReFooty sometimes renders the match cards through client-side markup,
    # leaving the URL in JSON/attribute data instead of a normal anchor.
    known_links = re.findall(
        r'''(?:https?:\\?/\\?/refooty\.com|https?:\\?/\\?/www\.refooty\.com|^|["'])
        (\\?/video\\?/[A-Za-z0-9_./-]+)''', body, re.I | re.X,
    )
    anchors += [(href, '') for href in known_links]
    for href, raw_title in anchors:
        href = href.replace('\\/', '/')
        title = re.sub(r'<[^>]+>', ' ', raw_title)
        title = re.sub(r'\s+', ' ', html.unescape(title)).strip()
        link = urljoin(FULL_MATCHES_URL, href)
        if not title or title.casefold() in {'hd', 'full match hd', 'watch'}:
            slug = link.rstrip('/').rsplit('/', 1)[-1]
            title = re.sub(r'[-_]+', ' ', slug)
            title = re.sub(r'\s+\d{4}.*$', '', title).strip().title()
        if not title or link in seen:
            continue
        if '/video/' not in link.lower():
            continue
        if title.lower() in {'full match hd', 'full matches'}:
            continue
        seen.add(link)
        found.append((title, link))
    return found


def full_matches(page=1):
    """Return one page of full-match videos."""
    return _video_catalogue(FULL_MATCHES_URL, page)


def latest_highlights(page=1):
    """Return one page of latest highlight videos."""
    return _video_catalogue(BASE_URL, page)


def resolve_video(page_url):
    """Extract the first playable media URL from a ReFooty video page."""
    body = _get(page_url)
    candidates = re.findall(
        r'''(?:src|data-src|data-video|data-url)=["']([^"']+)["']''',
        body, re.I,
    )
    candidates += re.findall(
        r'''https?://[^"'\s<>]+(?:\.m3u8|\.mp4)(?:\?[^"'\s<>]*)?''',
        body, re.I,
    )
    for value in candidates:
        value = html.unescape(value).replace('\\/', '/')
        if any(ext in value.lower() for ext in ('.m3u8', '.mp4', '.webm')):
            return urljoin(page_url, value)
    return ''
