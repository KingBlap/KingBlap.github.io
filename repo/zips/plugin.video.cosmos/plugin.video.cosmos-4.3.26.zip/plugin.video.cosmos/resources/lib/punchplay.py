# -*- coding: utf-8 -*-
"""PunchPlay authentication, catalog browsing and account integration."""
import json
import hashlib
import datetime
import os
import sys
import threading
import time
import uuid
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from .auth_dialog import AuthDialog
from . import tmdb as tmdb_mod


ADDON_ID = 'plugin.video.cosmos'
ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/')
DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
TOKEN_FILE = os.path.join(DATA_PATH, 'punchplay_token.json')
DEVICE_FILE = os.path.join(DATA_PATH, 'punchplay_device_id.txt')
PARTNER_SYNC_FILE = os.path.join(DATA_PATH, 'punchplay_partner_sync.json')
ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'icon_punchplay.png')
SUBMENU_ICON = os.path.join(
    ADDON_PATH, 'resources', 'media', 'submenus', 'icon_punchplay.png',
)
API_BASE = 'https://punchplay.tv/api/platform/v1'
PUBLIC_API_BASE = 'https://punchplay.tv/api/public/v1'
CLIENT_ID = 'ppc_479ac5086652cd1a93658a33'
UA = f'COSMOS-Kodi/{ADDON.getAddonInfo("version")}'
_refresh_lock = threading.Lock()
_partner_sync_lock = threading.Lock()
_LAST_ERROR = ''

HTTP_ERROR_MEANINGS = {
    400: 'Invalid request, parameter, scope, or device-code state',
    401: 'Credentials are missing, expired, revoked, invalid, or mismatched',
    403: 'The token does not have access to this PunchPlay surface',
    404: 'The route or requested resource was not found',
    408: 'PunchPlay did not receive the request body within 10 seconds',
    409: 'The request conflicts with current playback or idempotency state',
    413: 'The request body exceeds PunchPlay\'s size limit',
    422: 'PunchPlay could not resolve the playback media identity',
    429: 'PunchPlay rate limit exceeded',
    500: 'Temporary PunchPlay server failure',
}

ERROR_CODE_MEANINGS = {
    'authorization_pending': 'The device code is waiting for user approval',
    'conflict': 'The request conflicts with the current state',
    'expired': 'The device code is invalid or expired',
    'first_party_only': 'This endpoint is reserved for official PunchPlay clients',
    'idempotency_conflict': 'The idempotency key was reused with a different body',
    'idempotency_indeterminate': 'The earlier write may or may not have completed',
    'invalid_client': 'The PunchPlay client ID is invalid or inactive',
    'invalid_grant': 'The refresh token is invalid, expired, revoked, or already used',
    'invalid_request': 'Required request fields are missing or malformed',
    'invalid_scope': 'A requested scope is not allowed for this app',
    'invalid_token': 'The bearer token cannot use the PunchPlay Platform API',
    'invalid_title_id': 'The supplied partner title identifier is malformed or contradictory',
    'insufficient_scope': 'The token is missing a scope required by this endpoint',
    'not_found': 'The requested PunchPlay resource does not exist',
    'media_not_found': 'PunchPlay could not match the supplied media identifiers',
    'playback_state_conflict': 'This playback action has no valid active session',
    'rate_limited': 'The current PunchPlay request limit was exceeded',
    'request_in_progress': 'A request with this idempotency key is still running',
    'server_error': 'PunchPlay encountered a temporary server error',
    'service_unavailable': 'PunchPlay event streaming is temporarily unavailable',
    'title_id_unavailable': 'PunchPlay could not resolve the title identifier right now',
    'title_not_found': 'No PunchPlay title matches the supplied identifier',
    'unauthorized_client': 'The app is inactive or unavailable for this OAuth flow',
    'unsupported_grant_type': 'The requested OAuth grant type is unsupported',
    'unsupported_response_type': 'The requested OAuth response type is unsupported',
}


def _log(message, level=xbmc.LOGINFO):
    xbmc.log(f'[COSMOS PunchPlay] {message}', level)


def _debug_bundle_error(detail):
    try:
        from . import debug_bundle
        if debug_bundle.is_enabled():
            debug_bundle.log('PunchPlay ERROR', detail)
    except Exception:
        pass


def _header(headers, name):
    wanted = str(name).lower()
    return next((str(v) for k, v in (headers or {}).items()
                 if str(k).lower() == wanted), '')


def _record_error(path, status, data, headers=None):
    """Log actionable PunchPlay diagnostics without credentials or payloads."""
    global _LAST_ERROR
    data = data if isinstance(data, dict) else {}
    code = str(data.get('error') or '').strip().lower()
    if code == 'authorization_pending':
        return
    message = ' '.join(str(data.get('message') or '').split())[:300]
    request_id = str(
        data.get('request_id') or _header(headers, 'X-PunchPlay-Request-Id') or ''
    )[:100]
    required_scope = str(data.get('required_scope') or '')[:100]
    retry_after = _header(headers, 'Retry-After')[:40]
    meaning = ERROR_CODE_MEANINGS.get(code) or HTTP_ERROR_MEANINGS.get(status) or 'PunchPlay request failed'
    fields = [f'HTTP {status}', str(path), f'cause={meaning}']
    if code:
        fields.append(f'error={code}')
    if message:
        fields.append(f'message={message}')
    if required_scope:
        fields.append(f'required_scope={required_scope}')
    if retry_after:
        fields.append(f'retry_after={retry_after}s')
    if request_id:
        fields.append(f'request_id={request_id}')
    _LAST_ERROR = '; '.join(fields)
    _log(_LAST_ERROR, xbmc.LOGWARNING)
    _debug_bundle_error(_LAST_ERROR)


def get_last_error():
    return _LAST_ERROR


def _icon():
    return ICON if xbmcvfs.exists(ICON) else os.path.join(ADDON_PATH, 'icon.png')


def _submenu_icon():
    return SUBMENU_ICON if xbmcvfs.exists(SUBMENU_ICON) else _icon()


def _ensure_dir():
    if not xbmcvfs.exists(DATA_PATH):
        xbmcvfs.mkdirs(DATA_PATH)


def _save_token(data):
    token = dict(data or {})
    token['stored_at'] = int(time.time())
    _ensure_dir()
    with open(TOKEN_FILE, 'w', encoding='utf-8') as stream:
        json.dump(token, stream)
    try:
        os.chmod(TOKEN_FILE, 0o600)
    except OSError:
        pass
    ADDON.setSetting('punchplay_auth_done', 'true')
    ADDON.setSetting('punchplay_username', str(token.get('username') or ''))


def _load_token():
    try:
        with open(TOKEN_FILE, 'r', encoding='utf-8') as stream:
            data = json.load(stream)
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def _delete_token():
    try:
        if os.path.isfile(TOKEN_FILE):
            os.remove(TOKEN_FILE)
    except OSError as exc:
        _log(f'Could not remove saved token: {exc}', xbmc.LOGWARNING)
    ADDON.setSetting('punchplay_auth_done', 'false')
    ADDON.setSetting('punchplay_username', '')


def has_token():
    token = _load_token()
    authorized = bool(token and token.get('access_token'))
    # Keep the read-only settings status aligned for accounts authorized by
    # versions that predate the PunchPlay settings category.
    try:
        ADDON.setSetting('punchplay_auth_done', 'true' if authorized else 'false')
        ADDON.setSetting(
            'punchplay_username',
            str((token or {}).get('username') or '') if authorized else '',
        )
    except Exception:
        pass
    return authorized


def _http_json(path, payload=None, access_token=None, method='POST',
               extra_headers=None, api_base=None):
    global _LAST_ERROR
    url = (api_base or API_BASE) + path
    method = str(method or 'POST').upper()
    body = json.dumps(payload).encode('utf-8') if payload is not None else None
    headers = {'Content-Type': 'application/json', 'User-Agent': UA}
    if access_token:
        headers['Authorization'] = f'Bearer {access_token}'
    for name, value in (extra_headers or {}).items():
        if value not in (None, ''):
            headers[str(name)] = str(value)
    request = Request(
        url, data=body, method=method, headers=headers,
    )
    try:
        with urlopen(request, timeout=20) as response:
            raw = response.read().decode('utf-8', errors='replace')
            try:
                data = json.loads(raw) if raw else {}
            except ValueError:
                data = {'message': 'PunchPlay returned a non-JSON response'}
            _LAST_ERROR = ''
            return response.getcode(), data, dict(response.headers.items())
    except HTTPError as exc:
        try:
            raw = exc.read().decode('utf-8', errors='replace')
            data = json.loads(raw) if raw else {}
        except (OSError, ValueError):
            data = {}
        headers = dict(exc.headers.items()) if exc.headers else {}
        _record_error(path, exc.code, data, headers)
        return exc.code, data, headers
    except (URLError, OSError) as exc:
        _log(f'POST {path} failed: {exc}', xbmc.LOGWARNING)
        data = {'error': 'network_error', 'message': str(exc.reason if isinstance(exc, URLError) else exc)}
        _record_error(path, 0, data, {})
        return 0, data, {}


def _device_id():
    try:
        with open(DEVICE_FILE, 'r', encoding='utf-8') as stream:
            value = stream.read().strip()
    except OSError:
        value = ''
    if not value:
        value = 'cosmos-' + uuid.uuid4().hex
        _ensure_dir()
        try:
            with open(DEVICE_FILE, 'w', encoding='utf-8') as stream:
                stream.write(value)
        except OSError as exc:
            _log(f'Could not persist device ID: {exc}', xbmc.LOGWARNING)
    return value


def _run_auth_window(user_code, verification_url, expires_in, interval, poll_fn):
    try:
        dialog = AuthDialog(
            'AuthDialog.xml', ADDON_PATH, 'Default', '720p',
            service_name='PunchPlay', user_code=user_code,
            verification_url=verification_url,
            verification_label='',
            expires_in=expires_in, icon_path=_icon(),
            qr_path=os.path.join(ADDON_PATH, 'resources', 'media', 'punchplay_link_qr.png'),
        )
    except Exception as exc:
        _log(f'Authorization dialog failed to load: {exc}', xbmc.LOGWARNING)
        return False

    result = [False]

    def poll():
        started = time.time()
        delay = interval
        while not dialog.canceled:
            time.sleep(delay)
            remaining = expires_in - (time.time() - started)
            if remaining <= 0 or dialog.canceled:
                dialog.close()
                return
            dialog.update_remaining(remaining)
            outcome = poll_fn()
            if outcome == 'success':
                result[0] = True
                dialog.mark_authorized()
                return
            if outcome == 'denied':
                dialog.mark_denied()
                return
            if outcome == 'slow_down':
                delay += 5

    worker = threading.Thread(target=poll, daemon=True)
    worker.start()
    dialog.doModal()
    worker.join(timeout=10)
    return result[0]


def authorize():
    # Omitting scope asks PunchPlay for this public app's configured allowed
    # scopes, as specified by its device-flow documentation.
    status, data, _ = _http_json('/auth/device/code', {'client_id': CLIENT_ID})
    if status != 200 or not isinstance(data, dict) or not data.get('device_code'):
        detail = get_last_error() or data.get('message') or data.get('error') or f'HTTP {status}'
        xbmcgui.Dialog().notification(
            'PunchPlay', f'Could not start authorization: {detail}',
            xbmcgui.NOTIFICATION_ERROR, 5000,
        )
        return False

    device_code = data['device_code']
    user_code = str(data.get('user_code') or '')
    verification_url = (
        data.get('verification_uri')
        or data.get('verification_uri_complete')
        or 'https://punchplay.tv'
    )
    try:
        expires_in = max(1, int(data.get('expires_in') or 600))
    except (TypeError, ValueError):
        expires_in = 600

    def poll_token():
        poll_status, token, _ = _http_json('/auth/device/token', {
            'client_id': CLIENT_ID,
            'device_code': device_code,
            'device_name': 'COSMOS Kodi',
            'device_id': _device_id(),
        })
        error = str(token.get('error') or '').lower() if isinstance(token, dict) else ''
        if poll_status == 200 and isinstance(token, dict) and token.get('access_token'):
            _save_token(token)
            return 'success'
        if error == 'authorization_pending':
            return None
        if error == 'slow_down':
            return 'slow_down'
        if error or poll_status >= 400:
            _log(f'Device token request ended with HTTP {poll_status}: {error or "unknown_error"}', xbmc.LOGWARNING)
            return 'denied'
        return None

    ok = _run_auth_window(user_code, verification_url, expires_in, 5, poll_token)
    xbmcgui.Dialog().notification(
        'PunchPlay',
        'Authorization successful' if ok else 'Authorization timed out, failed, or was cancelled',
        xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_WARNING,
        4000,
    )
    if ok:
        # The authorization action is launched from this directory with
        # RunPlugin. Refresh it immediately so the signed-in controls replace
        # the authorization prompt without requiring the user to navigate out.
        xbmc.executebuiltin('Container.Refresh')
    return ok


def refresh_token():
    """Refresh a saved token and immediately persist PunchPlay's rotation."""
    with _refresh_lock:
        current = _load_token() or {}
        refresh = current.get('refresh_token')
        if not refresh:
            return False
        status, data, _ = _http_json('/auth/refresh', {
            'client_id': CLIENT_ID,
            'refresh_token': refresh,
        })
        if status == 200 and isinstance(data, dict) and data.get('access_token'):
            if not data.get('username') and current.get('username'):
                data['username'] = current['username']
            _save_token(data)
            return True
        _log(f'Token refresh failed with HTTP {status}', xbmc.LOGWARNING)
        return False


def _access_token():
    token = _load_token() or {}
    try:
        stored_at = int(token.get('stored_at') or 0)
        expires_in = int(token.get('expires_in') or 3600)
    except (TypeError, ValueError):
        stored_at, expires_in = 0, 3600
    if (not token.get('access_token') or
            (stored_at and time.time() >= stored_at + max(60, expires_in - 60))):
        if token.get('refresh_token') and refresh_token():
            token = _load_token() or {}
    return str(token.get('access_token') or '')


def _number(value, integer=False):
    try:
        return int(value) if integer else float(value)
    except (TypeError, ValueError, OverflowError):
        return None


def _playback_payload(meta, progress, position_seconds, duration_seconds,
                      playback_session_id, watched_threshold):
    meta = dict(meta or {})
    content = str(meta.get('content') or 'movie').lower()
    is_episode = content in (
        'episode', 'tv', 'tvshow', 'show', 'anime', 'anime_episode',
    )
    title = str(meta.get('title') or '').strip()
    if not title:
        return None

    payload = {
        'event_id': 'evt_' + uuid.uuid4().hex,
        'event_created_at': int(time.time() * 1000),
        'media_type': 'episode' if is_episode else 'movie',
        'title': title,
        'device_id': _device_id(),
        'playback_session_id': str(playback_session_id),
        'client_version': UA,
    }
    ids = meta.get('ids') if isinstance(meta.get('ids'), dict) else {}
    for source, target, integer in (
            ('tmdb', 'tmdb_id', True), ('tvdb', 'tvdb_id', True),
            ('imdb', 'imdb_id', False), ('punchplay', 'punchplay_id', False)):
        value = meta.get(source) or meta.get(f'{source}_id') or ids.get(source)
        if value in (None, ''):
            continue
        converted = _number(value, integer=True) if integer else str(value).strip()
        if converted not in (None, ''):
            payload[target] = converted

    year = _number(meta.get('year'), integer=True)
    if year is not None:
        payload['year'] = year
    if is_episode:
        season = _number(meta.get('season'), integer=True)
        episode = _number(meta.get('episode'), integer=True)
        if season is None or episode is None:
            return None
        payload.update(season=season, episode=episode)
        episode_title = str(meta.get('episode_title') or '').strip()
        if episode_title:
            payload['episode_title'] = episode_title
        if 'anime' in content:
            payload['anime'] = True

    position = max(0.0, _number(position_seconds) or 0.0)
    duration = max(0.0, _number(duration_seconds) or 0.0)
    payload['position_seconds'] = round(position, 3)
    if duration > 0:
        payload['duration_seconds'] = round(duration, 3)
        payload['progress'] = round(max(0.0, min(1.0, position / duration)), 6)
    else:
        ratio = max(0.0, min(1.0, (_number(progress) or 0.0) / 100.0))
        # PunchPlay requires duration whenever progress supplies a resume
        # position, so omit the ratio when Kodi has not exposed duration yet.
        if ratio <= 0:
            payload.pop('position_seconds', None)
    threshold = _number(watched_threshold)
    if threshold is not None:
        payload['watched_threshold'] = max(0.01, min(1.0, threshold))
    return payload


def scrobble(action, meta, progress=0.0, position_seconds=0.0,
             duration_seconds=0.0, playback_session_id='',
             watched_threshold=0.85):
    """Send one ordered playback lifecycle event to PunchPlay."""
    if action not in ('start', 'pause', 'resume', 'stop', 'progress'):
        return False
    token = _access_token()
    if not token:
        _log(f'Playback {action} skipped: not authorized', xbmc.LOGWARNING)
        return False
    payload = _playback_payload(
        meta, progress, position_seconds, duration_seconds,
        playback_session_id, watched_threshold,
    )
    if not payload:
        _log(f'Playback {action} skipped: incomplete media metadata', xbmc.LOGWARNING)
        return False

    path = f'/playback/{action}'
    status, data, headers = _http_json(path, payload, access_token=token)
    if status == 401 and refresh_token():
        token = _access_token()
        if token:
            # Reuse the same event_id and timestamp: this is a retry of the
            # same logical event and PunchPlay deduplicates by event_id.
            status, data, headers = _http_json(
                path, payload, access_token=token,
            )
    if status == 429:
        try:
            retry_after = max(1, min(30, int(float(_header(headers, 'Retry-After') or 1))))
        except (TypeError, ValueError):
            retry_after = 1
        _log(f'Playback {action} rate limited; retrying once in {retry_after}s', xbmc.LOGWARNING)
        time.sleep(retry_after)
        status, data, headers = _http_json(path, payload, access_token=token)
    if status == 500:
        # PunchPlay recommends retrying unexpected playback-processing
        # failures with backoff. Reuse the original event id and provider
        # timestamp so the retry remains the same idempotent logical event.
        _log(f'Playback {action} server failure; retrying once in 2s',
             xbmc.LOGWARNING)
        time.sleep(2)
        status, data, headers = _http_json(path, payload, access_token=token)
    if 200 <= status < 300:
        _log(f'Playback {action} accepted (HTTP {status})')
        return True
    # _http_json already logged the endpoint, friendly error meaning, required
    # scope, retry delay, and PunchPlay request ID for support correlation.
    return False


def _authorized_request(path, method='GET', payload=None, retry_auth=True,
                        extra_headers=None):
    token = _access_token()
    if not token:
        return 401, {'error': 'invalid_token', 'message': 'PunchPlay is not authorized'}, {}
    status, data, headers = _http_json(
        path, payload=payload, access_token=token, method=method,
        extra_headers=extra_headers,
    )
    if status == 401 and retry_auth and refresh_token():
        token = _access_token()
        if token:
            return _http_json(
                path, payload=payload, access_token=token, method=method,
                extra_headers=extra_headers,
            )
    return status, data, headers


def _partner_identity():
    token = _load_token() or {}
    owner = (token.get('user_id') or token.get('sub') or
             token.get('username') or '')
    scope = token.get('scope') or token.get('scopes') or ''
    if isinstance(scope, list):
        scope = ' '.join(sorted(str(value) for value in scope))
    return f'{owner}|{scope}' if owner or scope else ''


def _empty_partner_state():
    return {'version': 1, 'identity': _partner_identity(), 'cursor': '',
            'resources': {}, 'updated': 0}


def _load_partner_state():
    try:
        with open(PARTNER_SYNC_FILE, 'r', encoding='utf-8') as stream:
            state = json.load(stream)
        if not isinstance(state, dict):
            return _empty_partner_state()
        state.setdefault('version', 1)
        state.setdefault('identity', '')
        state.setdefault('cursor', '')
        state.setdefault('resources', {})
        state.setdefault('updated', 0)
        if not isinstance(state['resources'], dict):
            state['resources'] = {}
        return state
    except (OSError, ValueError):
        return _empty_partner_state()


def _save_partner_state(state):
    """Commit mirror data before advancing its durable change-feed cursor."""
    _ensure_dir()
    temporary = PARTNER_SYNC_FILE + '.tmp'
    try:
        with open(temporary, 'w', encoding='utf-8') as stream:
            json.dump(state, stream, separators=(',', ':'))
        os.replace(temporary, PARTNER_SYNC_FILE)
        return True
    except OSError as exc:
        _log(f'Partner sync state save failed: {exc}', xbmc.LOGWARNING)
        try:
            if os.path.isfile(temporary):
                os.remove(temporary)
        except OSError:
            pass
        return False


def _partner_item_key(item, fallback=''):
    if isinstance(item, dict):
        for name in ('resourceId', 'resource_id', 'id', '_id',
                     'historyId', 'history_id'):
            value = item.get(name)
            if value not in (None, ''):
                return str(value)
    if fallback:
        return str(fallback)
    canonical = json.dumps(item, sort_keys=True, separators=(',', ':'),
                           ensure_ascii=False)
    return 'sha256:' + hashlib.sha256(canonical.encode('utf-8')).hexdigest()


def _sync_snapshot(resource):
    """Download one complete resource snapshot, up to 500 rows per page."""
    rows = {}
    after = 0
    while True:
        query = urlencode({'resource': resource, 'after': after, 'limit': 500})
        status, data, _headers = _authorized_request(
            '/me/sync/snapshot?' + query,
        )
        if status != 200 or not isinstance(data, dict):
            return None
        for item in data.get('items') or []:
            if item is not None:
                rows[_partner_item_key(item)] = item
        if not data.get('hasMore'):
            return rows
        next_after = data.get('nextAfter')
        if next_after in (None, '') or str(next_after) == str(after):
            _log(f'Partner snapshot {resource} returned a stalled cursor',
                 xbmc.LOGWARNING)
            return None
        after = next_after


def _apply_partner_changes(state, changes):
    resources = state.setdefault('resources', {})
    for change in changes or []:
        if not isinstance(change, dict):
            continue
        resource = str(change.get('resource') or '').strip()
        resource_id = str(change.get('resourceId') or '').strip()
        if not resource or not resource_id:
            continue
        bucket = resources.setdefault(resource, {})
        if not isinstance(bucket, dict):
            bucket = resources[resource] = {}
        if (str(change.get('operation') or '').lower() == 'delete' or
                change.get('data') is None):
            bucket.pop(resource_id, None)
        else:
            bucket[resource_id] = change.get('data')


def sync_partner_mirror(max_pages=20):
    """Snapshot once, then apply PunchPlay's ordered at-least-once feed.

    The cursor is persisted only after the corresponding data page has been
    committed locally. Replayed changes are harmless because resources are
    keyed by (resource, resourceId), as required by the Partner Sync guide.
    """
    if not has_token():
        return False
    with _partner_sync_lock:
        state = _load_partner_state()
        identity = _partner_identity()
        if identity and state.get('identity') not in ('', identity):
            state = _empty_partner_state()
        elif identity:
            state['identity'] = identity
        cursor = str(state.get('cursor') or '')
        for _page in range(max(1, int(max_pages or 1))):
            query = {'limit': 500}
            if cursor:
                query['cursor'] = cursor
            status, data, _headers = _authorized_request(
                '/me/sync/changes?' + urlencode(query),
            )
            if status != 200 or not isinstance(data, dict):
                return False

            if data.get('resetRequired'):
                rebuilt = {}
                for resource in data.get('resources') or []:
                    resource = str(resource or '').strip()
                    if not resource:
                        continue
                    snapshot = _sync_snapshot(resource)
                    if snapshot is None:
                        return False
                    rebuilt[resource] = snapshot
                # Retain the supplied high-water cursor while the snapshot is
                # downloaded so writes made during backfill arrive next.
                state = _empty_partner_state()
                state['resources'] = rebuilt
                state['cursor'] = str(data.get('nextCursor') or '')
                state['updated'] = int(time.time())
                if not _save_partner_state(state):
                    return False
                cursor = state['cursor']
                if not cursor:
                    return True
                continue

            _apply_partner_changes(state, data.get('changes') or [])
            next_cursor = str(data.get('nextCursor') or cursor)
            state['cursor'] = next_cursor
            state['updated'] = int(time.time())
            if not _save_partner_state(state):
                return False
            cursor = next_cursor
            if not data.get('hasMore'):
                return True
        return True


def get_partner_resource(resource, refresh=True):
    """Return a copy of one locally mirrored Partner Sync resource."""
    if refresh:
        sync_partner_mirror()
    bucket = _load_partner_state().get('resources', {}).get(str(resource), {})
    return [item for item in bucket.values() if isinstance(item, dict)] \
        if isinstance(bucket, dict) else []


def partner_bulk_write(resource, items, idempotency_key=''):
    """Write one documented Partner Sync batch with safe size limits."""
    paths = {
        'history': '/sync/history',
        'ratings': '/sync/ratings',
        'watchlist': '/sync/watchlist',
    }
    path = paths.get(str(resource or '').lower())
    batch = [dict(item) for item in (items or []) if isinstance(item, dict)]
    if not path or not 1 <= len(batch) <= 100:
        return 400, {'error': 'invalid_request',
                     'message': 'Partner sync batches require 1 to 100 items'}
    payload = {'items': batch}
    if len(json.dumps(payload, separators=(',', ':')).encode('utf-8')) > 512 * 1024:
        return 413, {'error': 'payload_too_large',
                     'message': 'Partner sync batch exceeds 512 KiB'}
    key = str(idempotency_key or ('cosmos-' + uuid.uuid4().hex))
    status, data, _headers = _authorized_request(
        path, method='POST', payload=payload,
        extra_headers={'Idempotency-Key': key},
    )
    return status, data


def get_in_progress():
    """Return PunchPlay's live, non-cacheable resumable playback queue."""
    status, data, _ = _authorized_request('/playback/in-progress')
    if not 200 <= status < 300:
        return []
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    if not isinstance(data, dict):
        return []
    candidates = data.get('items') or data.get('results') or data.get('data') or []
    if isinstance(candidates, dict):
        candidates = candidates.get('items') or candidates.get('results') or []
    return [item for item in candidates if isinstance(item, dict)]


def get_now_playing():
    """Return PunchPlay's single most relevant active playback item."""
    status, data, _ = _authorized_request('/playback/now-playing')
    if not 200 <= status < 300 or not isinstance(data, dict):
        return None
    candidate = data.get('item') or data.get('data') or data
    return candidate if isinstance(candidate, dict) and candidate else None


def get_continue_watching():
    """Return PunchPlay's live show-level Continue Watching summaries."""
    status, data, _ = _authorized_request('/me/continue-watching')
    if not 200 <= status < 300:
        return []
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    if not isinstance(data, dict):
        return []
    candidates = data.get('items') or data.get('results') or data.get('data') or []
    if isinstance(candidates, dict):
        candidates = candidates.get('items') or candidates.get('results') or []
    return [item for item in candidates if isinstance(item, dict)]


def get_collection(media_type, cursor=''):
    """Return one cursor-paginated PunchPlay collection page."""
    media_type = str(media_type or '').lower()
    if media_type not in ('movie', 'show'):
        return [], ''
    query = {'type': media_type, 'limit': 20}
    if cursor:
        query['cursor'] = str(cursor)
    status, data, _ = _authorized_request(
        '/me/collection?' + urlencode(query),
    )
    if not 200 <= status < 300 or not isinstance(data, dict):
        return [], ''
    items = data.get('items') or []
    return ([item for item in items if isinstance(item, dict)],
            str(data.get('nextCursor') or ''))


def get_lists(cursor='', limit=50):
    """Return one official cursor-paginated PunchPlay list-summary page."""
    query = {'limit': max(1, min(100, int(limit or 50)))}
    if cursor:
        query['cursor'] = str(cursor)
    status, data, _headers = _authorized_request(
        '/me/lists?' + urlencode(query),
    )
    if status != 200 or not isinstance(data, dict):
        return [], ''
    items = data.get('items') or []
    return ([item for item in items if isinstance(item, dict)],
            str(data.get('nextCursor') or ''))


def get_calendar(month=''):
    """Return saved-title releases for a calendar month (YYYY-MM)."""
    month = str(month or datetime.date.today().strftime('%Y-%m'))
    try:
        if len(month) != 7 or month[4] != '-':
            return None
        parsed = datetime.date(int(month[:4]), int(month[5:]), 1)
        if parsed.strftime('%Y-%m') != month:
            return None
    except ValueError:
        return None
    status, data, _headers = _authorized_request(
        '/calendar?' + urlencode({'month': month}),
    )
    return data if status == 200 and isinstance(data, dict) else None


def _calendar_episode_is_aired(day_date, air_time_utc):
    """Avoid treating an undated release today as already available."""
    if air_time_utc:
        try:
            release = datetime.datetime.fromisoformat(
                str(air_time_utc).replace('Z', '+00:00'),
            )
            if release.tzinfo is not None:
                return release <= datetime.datetime.now(datetime.timezone.utc)
        except (TypeError, ValueError):
            pass
    try:
        release_day = datetime.date.fromisoformat(str(day_date))
        return release_day < datetime.date.today()
    except (TypeError, ValueError):
        return False


def menu_calendar(month=''):
    """Show the official PunchPlay saved-titles calendar, one month at a time."""
    if not has_token():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    month = str(month or datetime.date.today().strftime('%Y-%m'))
    try:
        if len(month) != 7 or month[4] != '-':
            raise ValueError('Invalid month')
        current = datetime.date(int(month[:4]), int(month[5:]), 1)
        if current.strftime('%Y-%m') != month:
            raise ValueError('Invalid month')
    except ValueError:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    year, number = current.year, current.month
    previous = f'{year - 1:04d}-12' if number == 1 else f'{year:04d}-{number - 1:02d}'
    following = f'{year + 1:04d}-01' if number == 12 else f'{year:04d}-{number + 1:02d}'
    for label, target in (('« Previous Month', previous), ('Next Month »', following)):
        item = xbmcgui.ListItem(label=label)
        item.setArt({'icon': _submenu_icon(), 'thumb': _submenu_icon()})
        xbmcplugin.addDirectoryItem(
            _handle(), _url(action='punchplay_calendar', month=target),
            item, isFolder=True,
        )

    data = get_calendar(month)
    days = data.get('days') if isinstance(data, dict) else None
    found = False
    for day in sorted((day for day in (days or []) if isinstance(day, dict)),
                      key=lambda entry: str(entry.get('date') or '')):
        date = str(day.get('date') or '')
        for source in day.get('items') or []:
            if not isinstance(source, dict):
                continue
            found = True
            title = str(source.get('title') or 'Untitled')
            kind = str(source.get('kind') or '')
            episode = source.get('nextEpisode') or {}
            if not isinstance(episode, dict):
                episode = {}
            detail = ''
            if kind == 'episode':
                try:
                    detail = 'S%02dE%02d' % (int(episode.get('season')),
                                            int(episode.get('episode')))
                except (TypeError, ValueError):
                    pass
                if episode.get('name'):
                    detail = (detail + ' · ' if detail else '') + str(episode['name'])
            elif kind == 'movie-digital':
                detail = 'Digital release'
            else:
                detail = 'Movie'
            label = f'{date} · {title}'
            if detail:
                label += f' · {detail}'
            if source.get('tag'):
                label += f' · {str(source["tag"]).replace("-", " ").title()}'
            poster = _collection_art(source.get('posterUrl'))
            item = xbmcgui.ListItem(label=label)
            tmdb = str(source.get('tmdbId') or '')
            poster, _fanart = _enrich_item(
                item, tmdb, 'tvshow' if kind == 'episode' else 'movie',
                source.get('posterUrl') or '',
            )
            try:
                tag = item.getVideoInfoTag()
                tag.setTitle(title)
                tag.setMediaType('tvshow' if kind == 'episode' else 'movie')
            except AttributeError:
                pass
            if kind == 'episode':
                try:
                    season = int(episode.get('season'))
                    number = int(episode.get('episode'))
                    valid_episode = season >= 0 and number >= 1 and int(tmdb) > 0
                except (TypeError, ValueError):
                    valid_episode = False
                if valid_episode and _calendar_episode_is_aired(
                    episode.get('airDate') or date, source.get('airTimeUtc'),
                ):
                    payload = json.dumps({
                        'title': title, 'tmdb': tmdb, 'content': 'episode',
                        'season': season, 'episode': number,
                        'episode_title': str(episode.get('name') or ''),
                        'poster': poster, 'fanart': _fanart,
                        'return_url': _url(action='punchplay_calendar', month=month),
                    })
                    url = _url(action='link_zero', payload=payload)
                    item.setProperty('IsPlayable', 'true')
                    is_folder = False
                    try:
                        tag = item.getVideoInfoTag()
                        tag.setMediaType('episode')
                        tag.setSeason(season)
                        tag.setEpisode(number)
                    except (AttributeError, TypeError, ValueError):
                        pass
                else:
                    url = _url(action='tmdb_tv_seasons', tmdb=tmdb,
                               name=title, poster=poster)
                    is_folder = True
            else:
                payload = json.dumps({'title': title, 'tmdb': tmdb,
                                      'content': 'movie', 'poster': poster})
                url = _url(action='link_zero', payload=payload)
                item.setProperty('IsPlayable', 'true')
                is_folder = False
            xbmcplugin.addDirectoryItem(_handle(), url, item, isFolder=is_folder)
    if not found:
        label = ('PunchPlay request failed — check the Kodi log' if get_last_error()
                 else f'No saved-title releases in {month}')
        placeholder = xbmcgui.ListItem(label=f'[COLOR grey]{label}[/COLOR]')
        xbmcplugin.addDirectoryItem(
            _handle(), _url(action='punchplay_calendar', month=month),
            placeholder, isFolder=False,
        )
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def get_list_details(list_id):
    """Return one PunchPlay list and its non-dynamic items."""
    try:
        list_id = int(list_id)
    except (TypeError, ValueError):
        return None
    if list_id < 1:
        return None
    status, data, _headers = _authorized_request(f'/lists/{list_id}')
    return data if status == 200 and isinstance(data, dict) else None


def get_dynamic_list_items(list_id, offset=0, limit=50):
    """Return one offset-paginated page from a PunchPlay dynamic list."""
    try:
        list_id = int(list_id)
        offset = max(0, int(offset or 0))
        limit = max(1, min(500, int(limit or 50)))
    except (TypeError, ValueError):
        return [], None, 0
    if list_id < 1:
        return [], None, 0
    query = urlencode({'offset': offset, 'limit': limit})
    status, data, _headers = _authorized_request(
        f'/lists/{list_id}/items?{query}',
    )
    if status != 200 or not isinstance(data, dict):
        return [], None, 0
    items = data.get('items') or []
    next_offset = data.get('nextOffset')
    try:
        next_offset = int(next_offset) if next_offset is not None else None
    except (TypeError, ValueError):
        next_offset = None
    return ([item for item in items if isinstance(item, dict)], next_offset,
            int(data.get('total') or 0))


def delete_in_progress(progress_id):
    progress_id = str(progress_id or '').strip()
    if not progress_id or '/' in progress_id:
        return False
    status, _data, _headers = _authorized_request(
        f'/playback/in-progress/{quote(progress_id, safe="")}', method='DELETE',
    )
    return 200 <= status < 300


def _first(item, *names):
    for name in names:
        value = item.get(name)
        if value not in (None, ''):
            return value
    return ''


def _enrich_item(list_item, tmdb_id, content, poster='', fanart=''):
    """Add TMDB details to a PunchPlay row without replacing its identity."""
    meta = {}
    if tmdb_id:
        try:
            meta = tmdb_mod.get_metadata(tmdb_id, content) or {}
            tmdb_mod.apply_to_listitem(list_item, meta, content)
        except Exception as exc:
            _log(f'TMDB enrichment failed for {content}/{tmdb_id}: {exc}',
                 xbmc.LOGWARNING)
    poster = (meta.get('poster') or _icon()) if not poster or poster == _icon() else _collection_art(poster)
    fanart = _collection_art(fanart) if fanart else (meta.get('fanart') or poster)
    list_item.setArt({'icon': poster, 'thumb': poster, 'poster': poster,
                      'fanart': fanart})
    return poster, fanart


def _progress_row(item):
    media = item.get('media') if isinstance(item.get('media'), dict) else {}
    episode_data = item.get('episode') if isinstance(item.get('episode'), dict) else {}

    def value(*names):
        return _first(item, *names) or _first(media, *names)

    media_type = str(value('type', 'mediaType', 'media_type') or 'movie').lower()
    season = value('season', 'seasonNumber', 'season_number') or _first(
        episode_data, 'season', 'seasonNumber', 'season_number')
    episode = value('episode', 'episodeNumber', 'episode_number') or _first(
        episode_data, 'number', 'episode', 'episodeNumber', 'episode_number')
    if season not in (None, '') and episode not in (None, ''):
        media_type = 'episode'
    duration = _number(value('durationSeconds', 'duration_seconds', 'duration')) or 0
    position = _number(value('progressSeconds', 'positionSeconds',
                             'position_seconds', 'progress_seconds')) or 0
    raw_progress = _number(value('progressPercent', 'progress_percent', 'progress')) or 0
    ratio = raw_progress / 100.0 if raw_progress > 1 else raw_progress
    if position <= 0 and duration > 0 and ratio > 0:
        position = duration * ratio
    if ratio <= 0 and duration > 0:
        ratio = position / duration
    return {
        'id': str(value('id', 'progressId', 'progress_id') or ''),
        'title': str(value('title', 'showTitle', 'show_title') or 'Untitled'),
        'year': value('year'),
        'tmdb': value('tmdbId', 'tmdb_id', 'tmdb'),
        'imdb': value('imdbId', 'imdb_id', 'imdb'),
        'tvdb': value('tvdbId', 'tvdb_id', 'tvdb'),
        'content': 'episode' if media_type == 'episode' else 'movie',
        'season': season,
        'episode': episode,
        'episode_title': str(value('episodeTitle', 'episode_title') or
                             _first(episode_data, 'title', 'name') or ''),
        'position': max(0.0, position),
        'duration': max(0.0, duration),
        'progress': max(0.0, min(1.0, ratio)),
        'poster': str(value('poster', 'posterUrl', 'poster_url', 'image') or ''),
        'fanart': str(value('fanart', 'fanartUrl', 'fanart_url',
                            'backdrop', 'backdropUrl') or ''),
    }


def menu_in_progress(page='1'):
    if not has_token():
        xbmcgui.Dialog().notification(
            'PunchPlay', 'Authorize PunchPlay first',
            xbmcgui.NOTIFICATION_WARNING, 3500,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    items = [_progress_row(item) for item in get_in_progress()]
    items = [item for item in items if item.get('title')]
    if not items:
        message = get_last_error()
        label = '[COLOR grey]No PunchPlay items are currently in progress[/COLOR]'
        if message:
            label = '[COLOR orange]PunchPlay request failed — check the Kodi log[/COLOR]'
        _row(label, 'punchplay_root')
        xbmcplugin.setContent(_handle(), 'videos')
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return

    try:
        page_number = max(1, int(page or 1))
    except (TypeError, ValueError):
        page_number = 1
    page_size = 20
    start = (page_number - 1) * page_size
    visible = items[start:start + page_size]
    for row in visible:
        title = row['title']
        label = title
        if row['content'] == 'episode':
            try:
                label += f' — S{int(row["season"]):02d}E{int(row["episode"]):02d}'
            except (TypeError, ValueError):
                pass
        label += f'  [COLOR gold]· {int(row["progress"] * 100)}%[/COLOR]'
        item = xbmcgui.ListItem(label=label)
        art, fanart = _enrich_item(
            item, row['tmdb'], 'tvshow' if row['content'] == 'episode' else 'movie',
            row['poster'], row['fanart'],
        )
        item.setProperty('IsPlayable', 'true')
        try:
            tag = item.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType(row['content'])
            tag.setResumePoint(float(row['position']), float(row['duration']))
        except Exception:
            item.setProperty('ResumeTime', str(int(row['position'])))
            item.setProperty('TotalTime', str(int(row['duration'])))
        payload = json.dumps({
            'title': title, 'year': row['year'], 'tmdb': row['tmdb'],
            'imdb': row['imdb'], 'tvdb': row['tvdb'],
            'content': row['content'], 'season': row['season'],
            'episode': row['episode'], 'episode_title': row['episode_title'],
            'poster': art, 'fanart': fanart,
        })
        play_url = _url(
            action='punchplay_play_in_progress', payload=payload,
            position=str(row['position']), duration=str(row['duration']),
        )
        if row['id']:
            remove_url = _url(
                action='punchplay_delete_in_progress', progress_id=row['id'],
            )
            item.addContextMenuItems([(
                '[COLOR red]Remove from PunchPlay In Progress[/COLOR]',
                f'RunPlugin({remove_url})',
            )])
        xbmcplugin.addDirectoryItem(_handle(), play_url, item, isFolder=False)

    if start + page_size < len(items):
        next_item = xbmcgui.ListItem(label=f'[B]Next Page ({page_number + 1}) »[/B]')
        xbmcplugin.addDirectoryItem(
            _handle(), _url(action='punchplay_in_progress', page=page_number + 1),
            next_item, isFolder=True,
        )
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def menu_now_playing():
    if not has_token():
        xbmcgui.Dialog().notification(
            'PunchPlay', 'Authorize PunchPlay first',
            xbmcgui.NOTIFICATION_WARNING, 3500,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    raw = get_now_playing()
    if not raw:
        label = '[COLOR grey]Nothing is currently playing on PunchPlay[/COLOR]'
        if get_last_error():
            label = '[COLOR orange]PunchPlay request failed — check the Kodi log[/COLOR]'
        _row(label, 'punchplay_root')
        xbmcplugin.setContent(_handle(), 'videos')
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return

    row = _progress_row(raw)
    title = row['title']
    label = title
    if row['content'] == 'episode':
        try:
            label += f' — S{int(row["season"]):02d}E{int(row["episode"]):02d}'
        except (TypeError, ValueError):
            pass
    label += f'  [COLOR gold]· {int(row["progress"] * 100)}%[/COLOR]'
    state = str(_first(raw, 'playbackState', 'playback_state') or '').strip()
    if state:
        label += f'  [COLOR springgreen]· {state.title()}[/COLOR]'
    item = xbmcgui.ListItem(label=label)
    art, fanart = _enrich_item(
        item, row['tmdb'], 'tvshow' if row['content'] == 'episode' else 'movie',
        row['poster'], row['fanart'],
    )
    item.setProperty('IsPlayable', 'true')
    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(title)
        tag.setMediaType(row['content'])
        tag.setResumePoint(float(row['position']), float(row['duration']))
    except Exception:
        item.setProperty('ResumeTime', str(int(row['position'])))
        item.setProperty('TotalTime', str(int(row['duration'])))
    payload = json.dumps({
        'title': title, 'year': row['year'], 'tmdb': row['tmdb'],
        'imdb': row['imdb'], 'tvdb': row['tvdb'],
        'content': row['content'], 'season': row['season'],
        'episode': row['episode'], 'episode_title': row['episode_title'],
        'poster': art, 'fanart': fanart,
    })
    play_url = _url(
        action='punchplay_play_in_progress', payload=payload,
        position=str(row['position']), duration=str(row['duration']),
    )
    xbmcplugin.addDirectoryItem(_handle(), play_url, item, isFolder=False)
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _continue_watching_row(item):
    show = item.get('show') if isinstance(item.get('show'), dict) else {}
    current = item.get('currentEpisode') or item.get('current_episode') or item.get('episode') or {}
    current = current if isinstance(current, dict) else {'number': current}

    def value(*names):
        return (_first(item, *names) or _first(show, *names) or
                _first(current, *names))

    season = (_first(item, 'nextSeason', 'next_season',
                     'currentSeasonNumber', 'current_season_number',
                     'currentSeason', 'current_season',
                     'seasonNumber', 'season_number', 'season') or
              _first(current, 'season', 'seasonNumber', 'season_number'))
    episode = (_first(item, 'nextEpisode', 'next_episode',
                      'currentEpisodeNumber', 'current_episode_number',
                      'episodeNumber', 'episode_number') or
               _first(current, 'number', 'episode', 'episodeNumber',
                      'episode_number'))
    source_season = (_first(item, 'nextSourceSeason', 'next_source_season') or
                     season)
    source_episode = (_first(item, 'nextSourceEpisode', 'next_source_episode') or
                      episode)
    progress = _number(value('overallPercent', 'overall_percent',
                             'completionPercent', 'completion_percent',
                             'progressPercent', 'progress_percent', 'progress')) or 0
    if progress > 1:
        progress /= 100.0
    return {
        'title': str(value('title', 'showTitle', 'show_title', 'name') or 'Untitled'),
        'year': value('year'),
        # Continue Watching summaries use showTmdbId (not tmdbId).  Passing
        # the old empty value into the TMDB seasons route produced the
        # misleading "No seasons found" notification.
        'tmdb': value('showTmdbId', 'show_tmdb_id',
                      'tmdbId', 'tmdb_id', 'tmdb'),
        'imdb': value('imdbId', 'imdb_id', 'imdb'),
        'tvdb': value('tvdbId', 'tvdb_id', 'tvdb'),
        'season': season,
        'episode': episode,
        # PunchPlay exposes provider coordinates separately for cases such as
        # anime episode-order mappings. These are the coordinates clients
        # should use when building a playable episode link.
        'source_season': source_season,
        'source_episode': source_episode,
        'episode_title': str(value('nextEpisodeTitle', 'next_episode_title') or
                             _first(current, 'title', 'name', 'episodeTitle',
                                    'episode_title') or ''),
        'progress': max(0.0, min(1.0, progress)),
        # status is the provider's series lifecycle (for example
        # "Returning Series"), not a schedule-aware state. Never use it as
        # an Airing/Ended badge; PunchPlay exposes releasePhase for that.
        'completion_state': str(value('completionState', 'completion_state') or ''),
        'release_phase': str(value('releasePhase', 'release_phase') or '').lower(),
        'provider_status': str(value('status') or ''),
        'poster': str(value('poster', 'posterUrl', 'poster_url', 'image') or ''),
        'fanart': str(value('fanart', 'fanartUrl', 'fanart_url',
                            'backdrop', 'backdropUrl') or ''),
    }


def menu_continue_watching(page='1'):
    if not has_token():
        xbmcgui.Dialog().notification(
            'PunchPlay', 'Authorize PunchPlay first',
            xbmcgui.NOTIFICATION_WARNING, 3500,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    rows = [_continue_watching_row(item) for item in get_continue_watching()]
    rows = [row for row in rows if row.get('title')]
    if not rows:
        label = '[COLOR grey]Nothing is currently in PunchPlay Continue Watching[/COLOR]'
        if get_last_error():
            label = '[COLOR orange]PunchPlay request failed — check the Kodi log[/COLOR]'
        _row(label, 'punchplay_root')
        xbmcplugin.setContent(_handle(), 'videos')
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return

    try:
        page_number = max(1, int(page or 1))
    except (TypeError, ValueError):
        page_number = 1
    page_size = 20
    start = (page_number - 1) * page_size
    for row in rows[start:start + page_size]:
        title = row['title']
        label = f'[COLOR cyan]▶ Next: [/COLOR]{title}'
        try:
            label += f' — S{int(row["season"]):02d}E{int(row["episode"]):02d}'
        except (TypeError, ValueError):
            pass
        if row['progress']:
            label += f'  [COLOR gold]· {int(row["progress"] * 100)}%[/COLOR]'
        if row['completion_state']:
            completion = row['completion_state'].replace('_', ' ').title()
            label += f'  [COLOR grey]· {completion}[/COLOR]'
        phase_labels = {
            'airing': 'Airing',
            'returning': 'Returning',
            'upcoming': 'Upcoming',
            'season_complete': 'Season complete',
            'schedule_pending': 'Schedule pending',
            'ended': 'Ended',
            'canceled': 'Canceled',
            'unknown': 'Schedule unknown',
        }
        phase = phase_labels.get(row['release_phase'])
        if phase:
            phase_color = 'springgreen' if row['release_phase'] == 'airing' else 'grey'
            label += f'  [COLOR {phase_color}]· {phase}[/COLOR]'
        list_item = xbmcgui.ListItem(label=label)
        art, fanart = _enrich_item(
            list_item, row['tmdb'], 'tvshow', row['poster'], row['fanart'],
        )
        try:
            tag = list_item.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType('episode')
            if row['source_season'] not in (None, ''):
                tag.setSeason(int(row['source_season']))
            if row['source_episode'] not in (None, ''):
                tag.setEpisode(int(row['source_episode']))
        except Exception:
            pass
        playable = (row['source_season'] not in (None, '') and
                    row['source_episode'] not in (None, ''))
        if playable:
            list_item.setProperty('IsPlayable', 'true')
            payload = json.dumps({
                'title': title,
                'year': row['year'],
                'tmdb': row['tmdb'],
                'imdb': row['imdb'],
                'tvdb': row['tvdb'],
                'content': 'episode',
                'season': row['source_season'],
                'episode': row['source_episode'],
                'episode_title': row['episode_title'],
                'poster': art,
                'fanart': fanart,
                'return_url': _url(action='punchplay_continue_watching'),
            })
            target = _url(action='link_zero', payload=payload)
        else:
            # Caught-up shows can remain in Continue Watching while a future
            # episode is announced. Do not launch Link Zero until PunchPlay
            # supplies currently playable next-source coordinates.
            list_item.setProperty('IsPlayable', 'false')
            target = _url(action='punchplay_continue_watching', page=page_number)
        xbmcplugin.addDirectoryItem(
            _handle(), target, list_item, isFolder=not playable,
        )
    if start + page_size < len(rows):
        next_item = xbmcgui.ListItem(label=f'[B]Next Page ({page_number + 1}) »[/B]')
        xbmcplugin.addDirectoryItem(
            _handle(), _url(action='punchplay_continue_watching', page=page_number + 1),
            next_item, isFolder=True,
        )
    xbmcplugin.setContent(_handle(), 'episodes')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def menu_collection():
    if not has_token():
        xbmcgui.Dialog().notification(
            'PunchPlay', 'Authorize PunchPlay first',
            xbmcgui.NOTIFICATION_WARNING, 3500,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    _row('[COLOR white]Movies[/COLOR]', 'punchplay_collection_movies', is_folder=True)
    _row('[COLOR white]Shows[/COLOR]', 'punchplay_collection_shows', is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _collection_art(path):
    path = str(path or '').strip()
    if not path:
        return _icon()
    if path.startswith(('http://', 'https://')):
        return path
    return 'https://image.tmdb.org/t/p/w500/' + path.lstrip('/')


def menu_collection_items(media_type, cursor=''):
    if not has_token():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    items, next_cursor = get_collection(media_type, cursor=cursor)
    items.sort(key=lambda item: str(
        _first(item, 'title', 'name') or ''
    ).casefold())
    if not items:
        label = f'[COLOR grey]No {media_type} collection items found[/COLOR]'
        if get_last_error():
            label = '[COLOR orange]PunchPlay request failed — check the Kodi log[/COLOR]'
        _row(label, 'punchplay_collection')
        xbmcplugin.setContent(_handle(), 'videos')
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return

    for source in items:
        item_type = str(_first(source, 'type', 'kind') or media_type).lower()
        title = str(_first(source, 'title', 'name') or 'Untitled')
        year = _first(source, 'year')
        tmdb = _first(source, 'tmdbId', 'tmdb_id', 'tmdb')
        if not tmdb and str(source.get('mediaSource') or '').lower() == 'tmdb':
            tmdb = source.get('sourceId') or ''
        poster = _collection_art(_first(source, 'posterPath', 'poster_path',
                                        'poster', 'posterUrl'))
        label = f'{title} ({year})' if year else title
        list_item = xbmcgui.ListItem(label=label)
        poster, fanart = _enrich_item(
            list_item, tmdb, 'movie' if item_type == 'movie' else 'tvshow',
            poster,
        )
        try:
            tag = list_item.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType('movie' if item_type == 'movie' else 'tvshow')
            if year:
                tag.setYear(int(year))
        except (TypeError, ValueError, AttributeError):
            pass

        if item_type == 'movie':
            list_item.setProperty('IsPlayable', 'true')
            payload = json.dumps({
                'title': title, 'year': year, 'tmdb': tmdb,
                'content': 'movie', 'poster': poster,
            })
            url = _url(action='link_zero', payload=payload)
            is_folder = False
        else:
            url = _url(
                action='tmdb_tv_seasons', tmdb=str(tmdb or ''), name=title,
                year=str(year or ''), poster=poster,
            )
            is_folder = True
        xbmcplugin.addDirectoryItem(
            _handle(), url, list_item, isFolder=is_folder,
        )

    if next_cursor:
        next_item = xbmcgui.ListItem(label='[B]Next Page »[/B]')
        next_item.setArt({'icon': _icon(), 'thumb': _icon()})
        action = ('punchplay_collection_movies' if media_type == 'movie'
                  else 'punchplay_collection_shows')
        xbmcplugin.addDirectoryItem(
            _handle(), _url(action=action, cursor=next_cursor),
            next_item, isFolder=True,
        )
    xbmcplugin.setContent(_handle(), 'movies' if media_type == 'movie' else 'tvshows')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def menu_my_lists(cursor=''):
    """Render the authenticated user's cursor-paginated PunchPlay lists."""
    if not has_token():
        xbmcgui.Dialog().notification(
            'PunchPlay', 'Authorize PunchPlay first',
            xbmcgui.NOTIFICATION_WARNING, 3500,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    lists, next_cursor = get_lists(cursor=cursor, limit=50)
    lists.sort(key=lambda item: str(item.get('name') or '').casefold())
    if not lists:
        label = '[COLOR grey]No PunchPlay lists found[/COLOR]'
        if get_last_error():
            label = '[COLOR orange]PunchPlay request failed — check the Kodi log[/COLOR]'
        _row(label, 'punchplay_root')
        xbmcplugin.setContent(_handle(), 'files')
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return

    for source in lists:
        list_id = source.get('id')
        try:
            if int(list_id) < 1:
                continue
        except (TypeError, ValueError):
            continue
        name = str(source.get('name') or 'Untitled List')
        count = int(source.get('itemCount') or 0)
        badges = []
        if source.get('isWatchlist'):
            badges.append('Watchlist')
        if source.get('isDynamicList'):
            badges.append('Dynamic')
        if source.get('isCollaborative'):
            badges.append('Collaborative')
        if source.get('externalSource'):
            badges.append(str(source.get('externalSource')))
        label = f'[B]{name}[/B]  [COLOR grey]{count} items[/COLOR]'
        if badges:
            label += '  [COLOR cyan]· ' + ' · '.join(badges) + '[/COLOR]'
        previews = source.get('previewPosters') or []
        preview = previews[0] if previews and isinstance(previews[0], dict) else {}
        art = _collection_art(preview.get('posterPath'))
        item = xbmcgui.ListItem(label=label)
        item.setArt({'icon': art, 'thumb': art, 'poster': art, 'fanart': art})
        try:
            tag = item.getVideoInfoTag()
            tag.setTitle(name)
            tag.setMediaType('video')
            if source.get('description'):
                tag.setPlot(str(source.get('description')))
        except Exception:
            pass
        xbmcplugin.addDirectoryItem(
            _handle(), _url(
                action='punchplay_list_items', list_id=str(list_id),
                name=name,
                dynamic='1' if source.get('isDynamicList') else '0',
                offset='0',
            ), item, isFolder=True,
        )

    if next_cursor:
        next_item = xbmcgui.ListItem(label='[B]Next Page »[/B]')
        next_item.setArt({'icon': _submenu_icon(), 'thumb': _submenu_icon()})
        xbmcplugin.addDirectoryItem(
            _handle(), _url(action='punchplay_my_lists', cursor=next_cursor),
            next_item, isFolder=True,
        )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _add_list_media_item(source):
    item_type = str(_first(source, 'type', 'kind') or 'movie').lower()
    is_movie = item_type in ('movie', 'movies', 'film')
    title = str(_first(source, 'title', 'name') or 'Untitled')
    tmdb = _first(source, 'tmdbId', 'tmdb_id', 'tmdb')
    release_date = str(_first(source, 'releaseDate', 'release_date') or '')
    year = _first(source, 'year') or (release_date[:4] if len(release_date) >= 4 else '')
    poster = _collection_art(_first(
        source, 'posterPath', 'poster_path', 'poster', 'posterUrl',
    ))
    label = f'{title} ({year})' if year else title
    if source.get('watched'):
        label += '  [COLOR springgreen]✓ Watched[/COLOR]'
    item = xbmcgui.ListItem(label=label)
    poster, fanart = _enrich_item(
        item, tmdb, 'movie' if is_movie else 'tvshow', poster,
    )
    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(title)
        tag.setMediaType('movie' if is_movie else 'tvshow')
        if year:
            tag.setYear(int(year))
    except (TypeError, ValueError, AttributeError):
        pass
    if is_movie:
        item.setProperty('IsPlayable', 'true')
        payload = json.dumps({
            'title': title, 'year': year, 'tmdb': tmdb,
            'content': 'movie', 'poster': poster,
        })
        target = _url(action='link_zero', payload=payload)
        is_folder = False
    else:
        target = _url(
            action='tmdb_tv_seasons', tmdb=str(tmdb or ''), name=title,
            year=str(year or ''), poster=poster,
        )
        is_folder = True
    xbmcplugin.addDirectoryItem(_handle(), target, item, isFolder=is_folder)


def menu_list_items(list_id, name='', dynamic='0', offset='0'):
    """Open regular and dynamic PunchPlay lists through their proper routes."""
    if not has_token():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    is_dynamic = str(dynamic or '').lower() in ('1', 'true', 'yes')
    try:
        offset_number = max(0, int(offset or 0))
    except (TypeError, ValueError):
        offset_number = 0
    next_offset = None
    total = 0
    if is_dynamic:
        items, next_offset, total = get_dynamic_list_items(
            list_id, offset=offset_number, limit=50,
        )
    else:
        details = get_list_details(list_id)
        if details and details.get('isDynamicList'):
            is_dynamic = True
            items, next_offset, total = get_dynamic_list_items(
                list_id, offset=offset_number, limit=50,
            )
        else:
            items = details.get('items') or [] if details else []
            items = [item for item in items if isinstance(item, dict)]
            total = len(items)

    if not items:
        label = f'[COLOR grey]No items found in {name or "this list"}[/COLOR]'
        if get_last_error():
            label = '[COLOR orange]PunchPlay request failed — check the Kodi log[/COLOR]'
        _row(label, 'punchplay_my_lists')
        xbmcplugin.setContent(_handle(), 'videos')
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return
    for source in items:
        _add_list_media_item(source)

    if is_dynamic and next_offset is not None:
        next_item = xbmcgui.ListItem(
            label=f'[B]Next Page »[/B]  [COLOR grey]{min(next_offset, total)}/{total}[/COLOR]'
        )
        next_item.setArt({'icon': _submenu_icon(), 'thumb': _submenu_icon()})
        xbmcplugin.addDirectoryItem(
            _handle(), _url(
                action='punchplay_list_items', list_id=str(list_id),
                name=name, dynamic='1', offset=str(next_offset),
            ), next_item, isFolder=True,
        )
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def play_in_progress(payload_json, position=0, duration=0):
    """Seed the exact remote resume point, then use normal source discovery."""
    try:
        meta = json.loads(payload_json or '{}')
    except ValueError:
        meta = {}
    if not isinstance(meta, dict) or not meta.get('title'):
        return False
    from . import resume as resume_mod
    from . import cosmos as cosmos_mod
    key = resume_mod.key_for(
        tmdb=meta.get('tmdb'), content=meta.get('content'),
        season=meta.get('season'), episode=meta.get('episode'),
    )
    resume_mod.put(key, _number(position) or 0, _number(duration) or 0, meta=meta)
    cosmos_mod._link_zero(payload_json)
    return True


def action_delete_in_progress(progress_id):
    ok = delete_in_progress(progress_id)
    xbmcgui.Dialog().notification(
        'PunchPlay',
        'Removed from In Progress' if ok else 'Could not remove In Progress item',
        xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR,
        3500,
    )
    if ok:
        xbmc.executebuiltin('Container.Refresh')


def _token_stream_lifetime():
    token = _load_token() or {}
    try:
        stored_at = float(token.get('stored_at') or 0)
        expires_in = float(token.get('expires_in') or 3600)
    except (TypeError, ValueError, OverflowError):
        return 300
    if not stored_at:
        return 300
    # Reconnect before the bearer expires, leaving the same refresh margin
    # used by normal authenticated requests.
    return max(1, int(stored_at + expires_in - 60 - time.time()))


def _live_playback_visible():
    try:
        folder = str(xbmc.getInfoLabel('Container.FolderPath') or '').lower()
        return ('plugin.video.cosmos' in folder and
                ('punchplay_in_progress' in folder or
                 'punchplay_now_playing' in folder or
                 'punchplay_continue_watching' in folder))
    except Exception:
        return False


def _refresh_visible_in_progress():
    if _live_playback_visible():
        xbmc.executebuiltin('Container.Refresh')


def run_event_listener(stop_event):
    """Listen for PunchPlay SSE invalidations from Kodi's background service."""
    backoff = 2
    while not stop_event.is_set():
        # The stream exists to invalidate this live directory. Do not hold an
        # SSE connection or consume event quota when that view is not open.
        if not _live_playback_visible():
            stop_event.wait(5)
            continue
        if not has_token():
            stop_event.wait(15)
            continue
        token = _access_token()
        if not token:
            stop_event.wait(15)
            continue

        path = '/playback/events'
        request = Request(
            API_BASE + path,
            headers={
                'Accept': 'text/event-stream',
                'Authorization': f'Bearer {token}',
                'Cache-Control': 'no-cache',
                'User-Agent': UA,
            },
            method='GET',
        )
        reconnect_for_token = False
        try:
            # A bounded read timeout lets Kodi shutdown and token rotation
            # interrupt a quiet stream without treating it as permanent.
            timeout = max(10, min(60, _token_stream_lifetime()))
            with urlopen(request, timeout=timeout) as response:
                backoff = 2
                token_deadline = time.time() + _token_stream_lifetime()
                event_name = ''
                data_lines = []
                for raw_line in response:
                    if stop_event.is_set() or time.time() >= token_deadline:
                        reconnect_for_token = True
                        break
                    line = raw_line.decode('utf-8', errors='replace').rstrip('\r\n')
                    if not line:
                        if event_name == 'playback-update':
                            # SSE is only an invalidation signal. Reconcile
                            # by refreshing the directory; its render path
                            # fetches the non-cacheable read endpoint.
                            _refresh_visible_in_progress()
                        event_name = ''
                        data_lines = []
                        continue
                    if line.startswith(':'):
                        continue
                    field, _, value = line.partition(':')
                    value = value.lstrip()
                    if field == 'event':
                        event_name = value
                    elif field == 'data':
                        data_lines.append(value)
        except HTTPError as exc:
            try:
                raw = exc.read().decode('utf-8', errors='replace')
                data = json.loads(raw) if raw else {}
            except (OSError, ValueError):
                data = {}
            headers = dict(exc.headers.items()) if exc.headers else {}
            _record_error(path, exc.code, data, headers)
            if exc.code == 401 and refresh_token():
                backoff = 2
                continue
            if exc.code == 503:
                try:
                    delay = max(1, min(300, int(float(_header(headers, 'Retry-After') or backoff))))
                except (TypeError, ValueError):
                    delay = backoff
            else:
                delay = backoff
        except TimeoutError:
            # Expected bounded reconnect for quiet streams and Kodi shutdown.
            _refresh_visible_in_progress()
            delay = 1
        except (URLError, OSError) as exc:
            _record_error(path, 0, {
                'error': 'stream_disconnected', 'message': str(exc),
            }, {})
            delay = backoff
        except Exception as exc:
            _record_error(path, 0, {
                'error': 'stream_error', 'message': str(exc),
            }, {})
            delay = backoff
        else:
            if reconnect_for_token:
                # _access_token refreshes when the current bearer is within
                # its final minute, then the loop opens a newly authorized SSE.
                _access_token()
            # Reconcile after reconnect/normal stream closure because SSE is
            # not a durable delivery queue and an update may have been missed.
            _refresh_visible_in_progress()
            delay = 1

        if stop_event.wait(delay):
            return
        backoff = min(60, max(2, backoff * 2))


def disconnect():
    _delete_token()
    # A cursor and snapshot belong to one PunchPlay account/scope set. Never
    # reuse that mirror after the account is disconnected or changed.
    try:
        if os.path.isfile(PARTNER_SYNC_FILE):
            os.remove(PARTNER_SYNC_FILE)
    except OSError as exc:
        _log(f'Could not remove Partner Sync state: {exc}', xbmc.LOGWARNING)
    xbmcgui.Dialog().notification(
        'PunchPlay', 'PunchPlay account disconnected from COSMOS',
        xbmcgui.NOTIFICATION_INFO, 3500,
    )
    xbmc.executebuiltin('Container.Refresh')


def _refresh_menu_sources():
    """Reconcile every signed-in PunchPlay folder with its official endpoint."""
    endpoints = (
        ('Now Playing', '/playback/now-playing'),
        ('In Progress', '/playback/in-progress'),
        ('Continue Watching', '/me/continue-watching'),
        ('Calendar', '/calendar?' + urlencode({
            'month': datetime.date.today().strftime('%Y-%m'),
        })),
        ('My Lists', '/me/lists?' + urlencode({'limit': 50})),
        ('Movie Collection', '/me/collection?' + urlencode({
            'type': 'movie', 'limit': 20,
        })),
        ('Show Collection', '/me/collection?' + urlencode({
            'type': 'show', 'limit': 20,
        })),
    )
    failures = []
    for label, path in endpoints:
        status, _data, _headers = _authorized_request(path, method='GET')
        if not 200 <= status < 300:
            failures.append(f'{label} (HTTP {status})')
    return not failures, failures


def action_sync():
    """Synchronize the mirror and every PunchPlay-backed Kodi folder."""
    if not has_token():
        xbmcgui.Dialog().notification(
            'PunchPlay', 'Authorize PunchPlay first',
            xbmcgui.NOTIFICATION_WARNING, 3500,
        )
        return False
    try:
        # Import lazily because watched imports PunchPlay for its remote
        # history provider. sync_remote_now follows the Partner Sync cursor
        # and then rebuilds the menu-facing watched cache from the mirror.
        from . import watched
        partner_success = bool(watched.sync_remote_now('punchplay', force=True))
    except Exception as exc:
        _log(f'Manual Partner Sync failed: {exc}', xbmc.LOGWARNING)
        partner_success = False

    menu_success, failures = _refresh_menu_sources()

    if menu_success and partner_success:
        message = 'PunchPlay sync completed; all folders updated'
        level = xbmcgui.NOTIFICATION_INFO
    elif menu_success:
        message = 'PunchPlay folders updated; account mirror could not sync'
        level = xbmcgui.NOTIFICATION_WARNING
    else:
        detail = get_last_error()
        failed = ', '.join(failures)
        message = detail or f'PunchPlay folder refresh failed: {failed}'
        level = xbmcgui.NOTIFICATION_ERROR
    xbmcgui.Dialog().notification('PunchPlay', message[:300], level, 5000)
    # Every PunchPlay directory uses cacheToDisc=False and fetches its own
    # endpoint when opened. Refreshing here redraws an already-open directory;
    # entering another folder afterwards performs a new live GET as well.
    xbmc.executebuiltin('Container.Refresh')
    return menu_success


def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def _url(**kwargs):
    return f'{sys.argv[0]}?{urlencode(kwargs)}'


def _row(label, action, is_folder=False):
    item = xbmcgui.ListItem(label=label)
    art = _submenu_icon()
    item.setArt({'icon': art, 'thumb': art, 'poster': art})
    xbmcplugin.addDirectoryItem(
        _handle(), _url(action=action), item, isFolder=is_folder,
    )


def menu_root():
    """Render sign-in controls or the authorized PunchPlay menus."""
    if not has_token():
        _row('[COLOR yellow][B]Authorize PunchPlay[/B][/COLOR]', 'punchplay_auth')
        _row('[COLOR grey]Sign in using a PunchPlay device code[/COLOR]', 'punchplay_root')
    else:
        username = str((_load_token() or {}).get('username') or '').strip()
        label = f'Signed in as {username}' if username else 'PunchPlay is authorized'
        _row(f'[COLOR springgreen][B]{label}[/B][/COLOR]', 'punchplay_root')
        _row('[COLOR white]Now Playing[/COLOR]', 'punchplay_now_playing', is_folder=True)
        _row('[COLOR white]In Progress[/COLOR]', 'punchplay_in_progress', is_folder=True)
        _row('[COLOR white]Continue Watching[/COLOR]', 'punchplay_continue_watching', is_folder=True)
        _row('[COLOR white]Calendar[/COLOR]', 'punchplay_calendar', is_folder=True)
        _row('[COLOR white]Collection[/COLOR]', 'punchplay_collection', is_folder=True)
        _row('[COLOR white]My Lists[/COLOR]', 'punchplay_my_lists', is_folder=True)
        _row('[COLOR white]Search[/COLOR]', 'punchplay_search', is_folder=True)
        _row('[COLOR white]Discover[/COLOR]', 'punchplay_discover', is_folder=True)
        _row('[COLOR cyan][B]Sync PunchPlay[/B][/COLOR]', 'punchplay_sync')
        _row('[COLOR red]Disconnect PunchPlay[/COLOR]', 'punchplay_disconnect')
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
