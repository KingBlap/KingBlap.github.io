# -*- coding: utf-8 -*-
"""Small local HTTP proxy for public Mega files.

Mega's public file endpoint returns encrypted bytes.  Kodi can play the
decrypted media, but it cannot apply Mega's AES-CTR file-key transform itself.
This module keeps the key in memory and exposes a localhost URL which accepts
the byte-range requests Kodi normally makes for MP4 playback.
"""
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from .aesgcm import AES


_UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
       '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
_TOKEN_RE = re.compile(r'^/mega/([A-Za-z0-9_-]+)\.mp4$')
_LOCK = threading.Lock()
_SERVER = None
_THREAD = None
_FILES = {}


def _ctr_key(file_key):
    """Return Mega's AES key and initial counter from a 32-byte file key."""
    words = [int.from_bytes(file_key[i:i + 4], 'big')
             for i in range(0, 32, 4)]
    aes_key = b''.join((words[i] ^ words[i + 4]).to_bytes(4, 'big')
                       for i in range(4))
    counter = ((words[4] << 32) | words[5]) << 64
    return aes_key, counter


class _CTR:
    def __init__(self, file_key, offset):
        aes_key, counter = _ctr_key(file_key)
        self._aes = AES(aes_key)
        self._counter = counter + (offset // 16)
        self._carry = b''

    def transform(self, data):
        if not data:
            return b''
        out = bytearray()
        pos = 0
        if self._carry:
            take = min(len(data), len(self._carry))
            out.extend(a ^ b for a, b in zip(data[:take], self._carry[:take]))
            self._carry = self._carry[take:]
            pos = take
        while pos < len(data):
            pad = self._aes.encrypt_block(self._counter.to_bytes(16, 'big'))
            self._counter += 1
            chunk = data[pos:pos + 16]
            out.extend(a ^ b for a, b in zip(chunk, pad))
            if len(chunk) < 16:
                self._carry = pad[len(chunk):]
            pos += len(chunk)
        return bytes(out)


def _parse_range(value, size):
    if not value:
        return 0, size - 1
    match = re.match(r'^bytes=(\d*)-(\d*)$', value.strip())
    if not match:
        return None
    first, last = match.groups()
    if not first:
        length = int(last or 0)
        if length <= 0:
            return None
        return max(0, size - length), size - 1
    start = int(first)
    if start >= size:
        return None
    end = min(size - 1, int(last)) if last else size - 1
    return (start, end) if end >= start else None


class _Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    server_version = 'CosmosMega/1.0'

    def log_message(self, *_args):
        return

    def do_HEAD(self):
        self._serve(head_only=True)

    def do_GET(self):
        self._serve(head_only=False)

    def _serve(self, head_only=False):
        match = _TOKEN_RE.match(urlparse(self.path).path)
        if not match:
            self.send_error(404)
            return
        item = _FILES.get(match.group(1))
        if not item:
            self.send_error(404)
            return
        file_url, file_size, file_key = item
        requested = _parse_range(self.headers.get('Range'), file_size)
        if requested is None:
            self.send_error(416)
            return
        start, end = requested
        aligned_start = (start // 16) * 16
        headers = {'User-Agent': _UA, 'Accept': '*/*',
                   'Range': f'bytes={aligned_start}-{end}'}
        try:
            response = urlopen(Request(file_url, headers=headers), timeout=30)
            status = getattr(response, 'status', 200)
            if status == 200 and aligned_start:
                response.close()
                self.send_error(502, 'Mega CDN did not honour byte range')
                return
        except (HTTPError, URLError, OSError):
            self.send_error(502, 'Mega CDN request failed')
            return

        length = end - start + 1
        self.send_response(206 if (start != 0 or end != file_size - 1) else 200)
        self.send_header('Content-Type', 'video/mp4')
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Content-Length', str(length))
        if start != 0 or end != file_size - 1:
            self.send_header('Content-Range', f'bytes {start}-{end}/{file_size}')
        self.end_headers()
        if head_only:
            response.close()
            return

        decryptor = _CTR(file_key, aligned_start)
        skip = start - aligned_start
        remaining = length
        try:
            while remaining > 0:
                encrypted = response.read(min(1024 * 1024, remaining + skip))
                if not encrypted:
                    break
                plain = decryptor.transform(encrypted)
                if skip:
                    drop = min(skip, len(plain))
                    plain = plain[drop:]
                    skip -= drop
                if plain:
                    plain = plain[:remaining]
                    self.wfile.write(plain)
                    self.wfile.flush()
                    remaining -= len(plain)
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            response.close()


def _serve_forever(server):
    try:
        server.serve_forever(poll_interval=0.5)
    except Exception:
        pass


def start(file_url, file_size, file_key):
    """Register a Mega file and return a Kodi-playable localhost URL."""
    global _SERVER, _THREAD
    if not file_url or not file_size or len(file_key) != 32:
        return None
    with _LOCK:
        if _SERVER is None:
            _SERVER = ThreadingHTTPServer(('127.0.0.1', 0), _Handler)
            _THREAD = threading.Thread(target=_serve_forever,
                                       args=(_SERVER,), daemon=True)
            _THREAD.start()
        token = f'{len(_FILES):x}{abs(hash((file_url, file_size, file_key))):x}'
        _FILES[token] = (file_url, int(file_size), file_key)
        port = _SERVER.server_address[1]
    return f'http://127.0.0.1:{port}/mega/{token}.mp4'
