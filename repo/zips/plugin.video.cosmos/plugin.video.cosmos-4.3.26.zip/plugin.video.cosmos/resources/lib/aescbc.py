"""AES-CBC with PKCS#7 padding, using Cosmos' existing AES key schedule."""
from .aesgcm import Sbox, _key_expansion, _add_round_key, _mul


def decrypt(key, iv, ciphertext):
    if len(key) not in (16, 24, 32) or len(iv) != 16 or not ciphertext or len(ciphertext) % 16:
        raise ValueError('Invalid AES-CBC input')
    inverse = [0] * 256
    for index, value in enumerate(Sbox):
        inverse[value] = index
    words, rounds = _key_expansion(key)
    output = bytearray()
    previous = iv
    for offset in range(0, len(ciphertext), 16):
        block = ciphertext[offset:offset + 16]
        state = [[block[row + 4 * col] for col in range(4)] for row in range(4)]
        _add_round_key(state, words, rounds)
        for rnd in range(rounds - 1, -1, -1):
            for row in range(1, 4):
                state[row] = state[row][-row:] + state[row][:-row]
            state = [[inverse[value] for value in row] for row in state]
            _add_round_key(state, words, rnd)
            if rnd:
                for col in range(4):
                    values = [state[row][col] for row in range(4)]
                    for row in range(4):
                        state[row][col] = (_mul(values[row], 14) ^
                                           _mul(values[(row + 1) % 4], 11) ^
                                           _mul(values[(row + 2) % 4], 13) ^
                                           _mul(values[(row + 3) % 4], 9))
        plain = bytes(state[row][col] for col in range(4) for row in range(4))
        output.extend(a ^ b for a, b in zip(plain, previous))
        previous = block
    padding = output[-1]
    if not 1 <= padding <= 16 or output[-padding:] != bytes([padding]) * padding:
        raise ValueError('Invalid AES-CBC padding')
    return bytes(output[:-padding])
