# -*- coding: utf-8 -*-
"""Dedicated 9Anime source picker using the Cosmos Link Picker interaction."""

from __future__ import absolute_import, division, print_function, unicode_literals

from .source_finder_dialog import LinkPickerDialog


class NineAnimeSourcePickerDialog(LinkPickerDialog):
    def __init__(self, *args, **kwargs):
        servers = kwargs.pop("servers", [])
        title = kwargs.pop("title", "9Anime")
        language = (kwargs.pop("language", "") or "").upper()
        episode = kwargs.pop("episode", "")
        links = []
        for server in servers:
            description = self._meta(server)
            format_label = ('HLS' if 'HLS' in description else
                            'MP4' if 'MP4' in description else 'AUTO')
            links.append({
                'label': self._label(server),
                'meta': 'Episode {0} / {1} / {2}'.format(episode, language, description),
                'preview_meta': 'Episode {0} / {1}\n{2}'.format(
                    episode, language,
                    'Allow up to 30s to connect' if 'BYFMS' in (server.get('name') or '').upper()
                    else 'Resolve on play' if server.get('source_kind') == 'YOANIME'
                    else 'Native Kodi playback'),
                'icon': server.get('icon', ''),
                'format_label': format_label,
            })
        kwargs['links'] = links
        kwargs['quality_label'] = title
        super(NineAnimeSourcePickerDialog, self).__init__(*args, **kwargs)
        self.language = language
        self.episode = episode

    def onInit(self):
        self.setProperty('na_context', 'EP {0} / {1}'.format(self.episode, self.language))
        super(NineAnimeSourcePickerDialog, self).onInit()

    def _refresh_selection_banner(self):
        super(NineAnimeSourcePickerDialog, self)._refresh_selection_banner()
        if self.links:
            context, _, note = self.links[self.current_index]['preview_meta'].partition('\n')
            self.setProperty('na_preview_context', context)
            self.setProperty('na_preview_note', note)

    @staticmethod
    def _label(server):
        name = server.get("name") or "Server"
        if "BYFMS" in name.upper():
            name += " (Slow fallback)"
        return "{0}  •  {1}".format(server.get("type", "").upper(), name)

    @staticmethod
    def _meta(server):
        if server.get("source_kind") == "ANIWATCH":
            return "Aniwatch Yuki HLS  •  resolve on play"
        if server.get("source_kind") == "YOANIME":
            return "YoAnime Direct HLS  •  health checked on play"
        if server.get("source_kind") == "YOANIME_EMBED":
            return "YoAnime Vidstream-2 HLS  •  episode duration verified"
        if server.get("source_kind") == "YOANIME_VIDPLAY":
            return "YoAnime VidPlay-1 HLS  •  identity and duration verified"
        if server.get("source_kind") == "ANIDB":
            return "Native HLS  •  InputStream Adaptive"
        if "BYFMS" in (server.get("name") or "").upper():
            return "Native HLS  •  protected stream  •  up to 30s"
        if "DGHG" in (server.get("name") or "").upper():
            return "Native MP4  •  direct Kodi playback"
        return "9Anime provider source"

