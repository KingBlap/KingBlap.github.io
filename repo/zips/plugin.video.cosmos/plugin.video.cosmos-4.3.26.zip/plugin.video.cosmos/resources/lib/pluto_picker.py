"""Pluto live guide in the Cosmos custom channel picker."""
from datetime import datetime, timezone

from .rakuten_picker import RakutenLivePickerDialog
from .rakuten_picker import channel_link as base_channel_link
from .source_finder_dialog import ADDON_PATH
from .pluto import _image


def normalize(channel, icon):
    programmes = []
    for event in channel.get('timelines') or []:
        episode = event.get('episode') or {}
        programmes.append({'title': event.get('title') or episode.get('name'),
                           'starts_at': event.get('start'), 'ends_at': event.get('stop'),
                           'description': episode.get('description') or episode.get('summary'),
                           'classification': {'name': episode.get('rating') or ''},
                           'episode': episode})
    return {'id': channel.get('_id') or channel['id'],
            'title': channel.get('name') or 'Pluto TV',
            'channel_number': channel.get('number'),
            'images': {'artwork': _image(channel, icon)},
            'live_programs': programmes, 'source': channel}


def channel_link(channel, icon):
    link = base_channel_link(channel, icon)
    info = link['info']
    source = channel['source']
    description = source.get('summary') or source.get('description') or ''
    if description:
        info['plot'] += '\n\n' + description
    number = channel.get('channel_number')
    if number is not None:
        link['label'] = '%s  |  %s' % (number, link['label'])
    now = datetime.now(timezone.utc)
    for programme in channel['live_programs']:
        try:
            start = datetime.fromisoformat(programme['starts_at'].replace('Z', '+00:00'))
            end = datetime.fromisoformat(programme['ends_at'].replace('Z', '+00:00'))
            if not start <= now < end:
                continue
        except (ValueError, TypeError, AttributeError):
            continue
        episode = programme['episode']
        clip = episode.get('clip') or {}
        info['genre'] = episode.get('genre') or ''
        info['cast'] = clip.get('actors') or []
        info['director'] = clip.get('directors') or []
        release = clip.get('originalReleaseDate') or ''
        if release[:4].isdigit():
            info['year'] = int(release[:4])
        details = [str(info[k]) for k in ('genre', 'mpaa', 'year') if info.get(k)]
        if details:
            link['preview_meta'] += '\n\n' + ' / '.join(details)
        if info['cast']:
            link['preview_meta'] += '\n\nCast: ' + ', '.join(info['cast'])
        break
    if description:
        link['preview_meta'] += '\n\n' + description
    return link


class PlutoLivePickerDialog(RakutenLivePickerDialog):
    provider_title = 'Pluto TV'

    def make_link(self, channel):
        return channel_link(channel, self.channel_icon)


def show(channels, region, icon, refresh_channels):
    if not channels:
        return None
    def prepare(rows):
        return sorted((normalize(c, icon) for c in rows),
                      key=lambda c: int(c.get('channel_number') or 0))
    dialog = PlutoLivePickerDialog(
        'PlutoLivePicker.xml', ADDON_PATH, 'Default', '720p',
        channels=prepare(channels), market=region, icon_path=icon,
        refresh_channels=lambda: prepare(refresh_channels()))
    try:
        dialog.doModal()
        index = dialog.selected_index
        return dialog.links[index]['channel'] if index is not None and 0 <= index < len(dialog.links) else None
    finally:
        del dialog
