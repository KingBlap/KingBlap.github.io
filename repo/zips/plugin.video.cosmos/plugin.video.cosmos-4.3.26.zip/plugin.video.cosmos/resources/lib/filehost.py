# -*- coding: utf-8 -*-
"""File-host / link resolution for C.O.S.M.O.S.

Non-debrid (direct) links (1fichier, uptobox, rapidgator, ...) are resolved
via the standard Kodi ``script.module.resolveurl`` addon. If ResolveURL is
missing or cannot resolve the URL we fall back to trying the authorized
debrid services in priority order (unrestrict_link).

Some "Non Debrid" links already point straight at a raw media file on an
origin/CDN file server (e.g. ``http://1.2.3.4/shows/.../S01E02.mp4``) rather
than at a file-host embed/download page. Those need no resolver at all --
see ``_is_direct_media_url`` -- and are played back as-is.

The Search4k / Search1080 / Search720 tokens trigger the torrent scrapers
and the normal debrid auto-play pipeline.
"""
import sys
import time
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from urllib.parse import urlparse, urlencode
from urllib.request import Request, urlopen
import json

from . import debrid
from . import scrapers
from . import cosmos_resolvers

ADDON = xbmcaddon.Addon()

# Debug bundler — optional; no-ops when disabled
try:
    from . import debug_bundle as _db
    def _dblog(tag, detail): _db.log(tag, detail)
except Exception:
    def _dblog(tag, detail): pass


QUALITY_ORDER = ['2160p', '1080p', '720p', '480p', '360p']

# Token to quality mapping for the <link> placeholders used by the playlist.
SEARCH_TOKENS = {
    'search4k': '2160p',
    'search1080': '1080p',
    'search720': '720p',
    'search480': '480p',
}

# File extensions that indicate a URL is already a raw, directly-playable
# media stream rather than a file-host page that needs scraping/resolving.
_DIRECT_MEDIA_EXT_RE = re.compile(
    r'\.(mp4|mkv|avi|mov|webm|flv|ts|m3u8|mpd|m4v|wmv)$',
    re.IGNORECASE,
)

# Known file-hosting domains that should always go through resolution,
# even if their URL path ends with a media extension.
_KNOWN_FILE_HOST_DOMAINS = {
    'uploadgig.com', 'uploady.io', 'rapidgator.net', 'nitroflare.com', '1fichier.com',
    'uploaded.net', 'ul.to', 'katfile.com', 'filefactory.com', 'turbobit.net',
    'depositfiles.com', 'datafile.com', 'filejoker.net', 'ddownload.com',
    'fboom.me', 'keep2share.cc', 'k2s.cc', 'worldbytez.com', 'hotlink.cc',
    'filefox.cc', 'mega.nz', 'mediafire.com', 'google.com', 'drive.google.com',
    'dropbox.com', 'multiup.org', 'multiup.io', 'extabit.com', 'filespace.com',
    'novafile.com', 'solidfiles.com', 'zippyshare.com', 'file.al', 'filer.net',
    'hitfile.net', 'filepost.com', 'tusfiles.com', 'userscloud.com',
    'fastfile.cc', 'prefiles.com', 'icerbox.com', 'share-online.biz',
    # Domains from cosmos_resolvers that are file hosts/embeds
    'mixdrop.co', 'mixdrop.to', 'mixdrop.club', 'mixdrop.top', 'mixdrop.gl',
    'mixdrop.cv', 'mixdrop.my', 'mixdrop.ag', 'mixdrop.ps', 'mixdrop.sx',
    'mixdrop.bz', 'mixdrop.is', 'mixdrop.lol', 'mixdrop.si', 'mixdrop.live',
    'doodstream.com', 'd000d.com', 'dood.li', 'ds2play.com', 'ds2video.com',
    'streamtape.com', 'streamta.pe', 'shavetape.com', 'strcloud.link',
    'strtape.com', 'streamadblocker.com', 'ok.ru', 'odnoklassniki.ru',
    'soccerfull.net', 'thematchrecap.xyz', 'bysesukior.com', 'bysewihe.com', 'byseraguci.com', 'filemoon.sx',
    'filemoon.cc', 'fmoon.sx', 'vidara.so', 'megaplay.su',
    'streamhide.com', 'voe.sx', 'vidoza.net', 'streamwish.ws', 'embedwish.com', 'filelions.com',
    'hexupload.net', 'streamruby.com', 'mp4upload.com', 'playerwish.com',
    'swdyu.com', 'vidcloud.co', 'playembed.com', 'vidmoly.com', 'fembed.com',
    'tubeembed.com', 'sblanh.com', 'wolfstream.tv', 'streamlare.com',
    'smoothpre.com', 'hxfile.net', 'listeamed.com', 'feurl.com', 'd000d.com',
    'kerolaunoch.com', 'vk.com', 'vk.ru', 'vkvideo.ru', 'dailymotion.com', 'geo.dailymotion.com', 'dai.ly',
    'youtu.be', 'youtube.com', 'rugby24stream.com', 'rugbystream.com',
    'rugbyreplay.com', 'footballfull.net', 'footballstream.com',
    'footballreplay.com', 'watchwrestling.bg', 'streameast7.org',
    'shd247.world', 'shd247.site', 'obplay.live',
    'ripplestream.cyou', 'rippleplays.cfd', 'hamis.romponalis.st',
    'prostreams.best', 'prostreams.shop',
    'streamsify.xyz', 'streamify.cfd',
    'eagle-streams.shop', 'flyembed.click', 'epic.cdx-08192.website',
    'watchwrestling.ae',
    'megaplay.su', # Added megaplay.su to known file hosts
}


def _is_direct_media_url(url):
    """True if ``url`` itself already points at a raw media file (an
    origin file-server / CDN link, plain IP host, etc.) instead of a
    file-host embed/download page. Kodi can play these as-is -- running
    them through debrid unrestrict / ResolveURL / the built-in resolvers
    only wastes time and, since none of those recognize a random origin
    server, ultimately fails and gets the item marked unplayable.
    """
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    if parsed.scheme not in ('http', 'https'):
        return False
    
    host = parsed.netloc.lower().replace('www.', '')
    if host in _KNOWN_FILE_HOST_DOMAINS:
        _dblog('DIRECT-MEDIA-SKIP-FILEHOST', f'Host {host} is a known file host, not a direct media URL.')
        return False
    return bool(_DIRECT_MEDIA_EXT_RE.search(parsed.path or ''))


def _is_easynews_url(url):
    """Identify Easynews download URLs without inspecting embedded credentials."""
    try:
        host = (urlparse(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return host == 'easynews.com' or host.endswith('.easynews.com')


def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def _try_resolveurl(url):
    """Resolve a direct file-host link through ResolveURL addon.

    Returns a playable URL or None.
    """
    try:
        import resolveurl  # provided by script.module.resolveurl
    except ImportError:
        xbmc.log('COSMOS: script.module.resolveurl not installed', xbmc.LOGWARNING)
        return None

    try:
        from .filehost_credentials import sync_credentials
        sync_credentials()
        hmf = resolveurl.HostedMediaFile(url=url, include_disabled=False, include_universal=True)
        if hmf.valid_url():
            return hmf.resolve()
    except Exception as e:
        xbmc.log(f'COSMOS: ResolveURL failed for {url}: {e}', xbmc.LOGERROR)
    return None


def _resolve_uploady(url):
    """Resolve an Uploady file URL through Uploady's documented API."""
    api_key = (ADDON.getSetting('uploady_api_key') or '').strip()
    if not api_key:
        _dblog('UPLOADY-NO-KEY', 'Uploady API key is not configured')
        return None
    path = (urlparse(url).path or '').strip('/')
    parts = [part for part in path.split('/') if part]
    # Uploady links use /<12-char-file-code>/<filename>; older links may
    # use /<12-char-file-code>. Never use the filename as the API code.
    file_code = next(
        (part for part in parts if re.match(r'^[A-Za-z0-9]{12}$', part)),
        '',
    )
    if not file_code:
        _dblog('UPLOADY-BAD-URL', url)
        return None
    endpoint = 'https://uploady.io/api/file/direct_link?' + urlencode({
        'key': api_key, 'file_code': file_code,
    })
    try:
        req = Request(endpoint, headers={'User-Agent': 'COSMOS-Kodi/4.0.0', 'Accept': 'application/json'})
        with urlopen(req, timeout=20) as response:
            data = json.loads(response.read().decode('utf-8', errors='replace'))
        direct = ((data.get('result') or {}).get('url') if isinstance(data, dict) else '')
        if direct:
            _dblog('UPLOADY-OK', 'Uploady direct link returned')
            return direct
        _dblog('UPLOADY-NONE', str((data or {}).get('msg', 'no direct link'))[:120])
    except Exception as exc:
        xbmc.log(f'COSMOS: Uploady API failed: {exc}', xbmc.LOGWARNING)
        _dblog('UPLOADY-FAIL', str(exc))
    return None


def _resolve_multiup_link(url):
    """Expand a MultiUp mirror index and resolve its mirrors in order."""
    mirrors = cosmos_resolvers.get_multiup_mirrors(url)
    if not mirrors:
        return None, None

    for mirror in mirrors:
        # Do not recurse through nested mirror indexes indefinitely.
        if cosmos_resolvers._is_multiup(mirror):
            continue
        _dblog('MULTIUP-MIRROR-TRY', mirror)
        stream, via = resolve_filehost_link(mirror)
        if stream:
            _dblog('MULTIUP-MIRROR-OK', f'{mirror} via {via}')
            return stream, f'MultiUp/{via}'

    cosmos_resolvers._last_resolver_error = 'multiup_mirrors_unresolved'
    _dblog('MULTIUP-MIRRORS-FAILED', f'{len(mirrors)} mirror(s) tried')
    return None, None


def resolve_filehost_link(url):
    """Resolve a single filehost URL. Tries debrid unrestrict first (if
    available), then falls back to ResolveURL, and finally to the bundled
    built-in resolvers (mixdrop / doodstream / streamtape / ok.ru / youtube).

    Returns a tuple (stream_url, via_name) or (None, None).
    """
    # Site wrappers are opened only by the dedicated Watch Wrestling menus.
    # Those menus unwrap the player before handing its media host here.
    if (urlparse(url).hostname or '').lower().rstrip('.') in (
            'watchwrestling.bg', 'www.watchwrestling.bg',
            'watchwrestling.ae', 'www.watchwrestling.ae'):
        return None, None
    # Easynews download URLs are already authenticated direct media links.
    # Sending them through debrid/ResolveURL loses the Basic-auth URL and
    # makes an otherwise valid Usenet result fail to play.
    if _is_easynews_url(url):
        _dblog('EASYNEWS-DIRECT', 'credentialed download URL passed through')
        return url, 'Easynews'

    # Fast path: the link is already a raw, directly-playable media file
    # (origin/CDN server, plain IP host, ...) -- nothing to resolve.
    if _is_direct_media_url(url):
        _dblog('DIRECT-MEDIA', url)
        return url, 'Direct'

    host = (urlparse(url or '').hostname or '').lower().rstrip('.')
    is_uploady = host == 'uploady.io' or host.endswith('.uploady.io')

    # Uploady is resolved directly through its own API.  Do not send Uploady
    # credentials or links through debrid services: the Uploady API key plus
    # an account with Direct Links enabled is the complete requirement.
    if is_uploady:
        resolved = _resolve_uploady(url)
        if resolved:
            return resolved, 'Uploady'
        return None, None

    # MultiUp is a mirror index. Expand it first, then send each validated
    # mirror through the normal debrid/ResolveURL/native resolver pipeline;
    # never hand the MultiUp HTML page itself to Kodi as a media URL.
    if cosmos_resolvers._is_multiup(url):
        return _resolve_multiup_link(url)

    services = debrid.get_debrid_services()
    for name, svc in services:
        try:
            if hasattr(svc, 'unrestrict_link'):
                _dblog('DEBRID-TRY', name)
                res = svc.unrestrict_link(url)
                if res:
                    _dblog('DEBRID-OK', f'{name} → {res[:80]}')
                    return res, name
                _dblog('DEBRID-SKIP', f'{name} returned nothing')
        except Exception as e:
            xbmc.log(f'COSMOS: {name} unrestrict_link failed: {e}', xbmc.LOGDEBUG)
            _dblog('DEBRID-FAIL', f'{name}: {e}')
            continue

    # Fallback 1: built-in regex/JSON resolvers, for hosts we have a
    # dedicated, freshness-tested resolver for (ok.ru, mixdrop, doodstream,
    # streamtape, youtube, dailymotion, bysesukior, vidara, soccerfull).
    # ResolveURL's bundled plugins for these hosts can silently return a
    # stale/expired URL instead of None, which would prevent us from
    # reaching our own working fallback - so try ours first.
    # If our resolver owns the host (even if it returned None), we also skip
    # ResolveURL for that URL: ResolveURL would just produce a duplicate
    # error for the same content failure (e.g. a deleted Dailymotion video).
    builtin = None
    cosmos_owns_url = cosmos_resolvers.is_owned(url)
    _dblog('BUILTIN-TRY', f'owned={cosmos_owns_url}  url={url}')
    try:
        builtin = cosmos_resolvers.resolve(url)
    except Exception as e:
        xbmc.log(f'COSMOS: built-in resolver error for {url}: {e}', xbmc.LOGERROR)
        _dblog('BUILTIN-CRASH', str(e))
    if builtin:
        _dblog('BUILTIN-OK', f'{builtin[:120]}')
        return builtin, 'COSMOS-builtin'
    else:
        _dblog('BUILTIN-NONE', f'cosmos_resolvers.resolve returned None for {url}')

    # Fallback 2: generic ResolveURL (covers everything else - 1fichier,
    # uptobox, rapidgator, streamwish, filemoon, etc.).
    # Skip if one of our native resolvers already handled the host and
    # returned None (content gone / geo-blocked at the source, not a
    # resolver gap) — calling ResolveURL would just repeat the same error.
    if cosmos_owns_url:
        xbmc.log(f'COSMOS: native resolver returned None for owned host, '
                 f'skipping ResolveURL for {url}', xbmc.LOGINFO)
        _dblog('BUILTIN-NONE', 'owned host returned None — skipping ResolveURL')
        return None, None

    _dblog('RESOLVEURL-TRY', url)
    resolved = _try_resolveurl(url)
    if resolved:
        _dblog('RESOLVEURL-OK', resolved[:120])
        return resolved, 'ResolveURL'

    _dblog('RESOLVEURL-NONE', 'no result')
    return None, None


def _play_stream(stream_url, use_player=False):
    """Hand a resolved stream URL back to Kodi for playback.

    ``use_player=True`` must be set whenever the plugin handle has already
    been consumed by a prior ``endOfDirectory`` call — this is always the
    case for sport sections (boxing / rugby / football / combat) which show
    a picker dialog within the same invocation and close the directory before
    playing.  In that context ``setResolvedUrl`` is a silent no-op because
    the handle is dead; ``xbmc.Player().play()`` works regardless.

    For direct-click playback of movies / shows (``action=play_link``) the
    handle is still alive so ``setResolvedUrl`` (the default) is used.

    HLS notes
    ---------
    The ListItem path is always the bare URL (no ``|headers`` suffix).
    We unconditionally request inputstream.adaptive (ISA): if it is
    installed Kodi will honour the manifest_headers / stream_headers
    properties so the CDN sees the correct Referer on every manifest,
    sub-playlist and segment request; if ISA is absent Kodi falls back to
    its built-in player automatically.
    """
    # Plugin URLs (e.g. YouTube via ResolveURL) — hand off as-is.
    if stream_url.startswith('plugin://'):
        xbmc.Player().play(stream_url)
        return

    # Split URL and pipe-headers.
    if '|' in stream_url:
        url_part, header_part = stream_url.split('|', 1)
    else:
        url_part, header_part = stream_url, ''

    is_hls = '.m3u8' in url_part.lower()

    li = xbmcgui.ListItem(path=url_part)
    li.setProperty('IsPlayable', 'true')

    if is_hls:
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        # Request ISA unconditionally.  getCondVisibility is unreliable
        # from plugin threads; setting these properties is harmless when
        # ISA is absent — Kodi just ignores them and uses its own player.
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        if header_part:
            li.setProperty('inputstream.adaptive.manifest_headers', header_part)
            li.setProperty('inputstream.adaptive.stream_headers', header_part)
    elif header_part:
        # MP4 / direct media: embed headers in path for Kodi's curl player.
        li = xbmcgui.ListItem(path=f'{url_part}|{header_part}')
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp4')
        li.setContentLookup(False)

    if use_player:
        # Handle already consumed — bypass setResolvedUrl entirely.
        xbmc.Player().play(url_part, li)
    else:
        xbmcplugin.setResolvedUrl(_handle(), True, li)


def _set_failed():
    xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())


def play_direct_link(url, title='', use_player=False):
    """Resolve a literal http(s) filehost URL and play.

    ``use_player`` must be True when calling from a sport section (rugby /
    boxing / combat / football) because those sections close the plugin
    directory handle before calling here, making ``setResolvedUrl``
    a silent no-op.  See ``_play_stream`` for full details.
    """
    # Begin a debug session if the bundler is enabled
    try:
        from . import debug_bundle as _debug_mod
        _debug_mod.begin_session(url, title)
    except Exception:
        _debug_mod = None

    dlg = xbmcgui.DialogProgressBG()
    dlg.create('C.O.S.M.O.S', f'Resolving {title or url}...')
    _dblog('PLAY-START', f'title={title!r}  url={url}')
    try:
        stream, via = resolve_filehost_link(url)
        if stream:
            dlg.close()
            _dblog('PLAY-STREAM', f'via={via}  stream={stream}')
            xbmcgui.Dialog().notification('C.O.S.M.O.S', f'Playing via {via}',
                                          xbmcgui.NOTIFICATION_INFO, 2000)
            _play_stream(stream, use_player=use_player)
            try:
                if _debug_mod:
                    _debug_mod.end_session(stream_url=stream)
            except Exception:
                pass
            return True
        dlg.close()
        _dblog('PLAY-FAIL', 'resolve_filehost_link returned None')
        # Choose toast message: "Removed by host" when the resolver confirmed
        # the content has been deleted/taken down; generic message otherwise.
        _resolver_err = getattr(cosmos_resolvers, '_last_resolver_error', '')
        if _resolver_err == 'host_unavailable':
            _fail_msg = 'Video host no longer serves this part. Try another server.'
            _fail_icon = xbmcgui.NOTIFICATION_WARNING
        elif _resolver_err == 'removed':
            _fail_msg = 'Removed by host'
            _fail_icon = xbmcgui.NOTIFICATION_WARNING
        elif _resolver_err == 'debrid_required_rapidgator':
            _fail_msg = 'Rapidgator link found. Please ensure your debrid service is active or add a premium Rapidgator account.'
            _fail_icon = xbmcgui.NOTIFICATION_INFO
        elif _resolver_err == 'debrid_required_nitroflare':
            _fail_msg = 'Nitroflare link found. Please ensure your debrid service is active or add a premium Nitroflare account.'
            _fail_icon = xbmcgui.NOTIFICATION_INFO
        elif _resolver_err == 'debrid_required_uploadgig':
            _fail_msg = 'Uploadgig requires a premium account or supported debrid service; free CAPTCHA playback is unavailable in Kodi.'
            _fail_icon = xbmcgui.NOTIFICATION_INFO
        elif _resolver_err == 'multiup_fetch_failed':
            _fail_msg = 'MultiUp could not be reached.'
            _fail_icon = xbmcgui.NOTIFICATION_INFO
        elif _resolver_err in ('multiup_mirror_form_missing', 'multiup_no_mirrors'):
            _fail_msg = 'MultiUp returned no usable mirrors.'
            _fail_icon = xbmcgui.NOTIFICATION_INFO
        elif _resolver_err == 'multiup_mirrors_unresolved':
            _fail_msg = 'MultiUp mirrors found, but none could be resolved. Check your debrid or ResolveURL accounts.'
            _fail_icon = xbmcgui.NOTIFICATION_INFO
        else:
            _fail_msg = 'Could not resolve link'
            _fail_icon = xbmcgui.NOTIFICATION_ERROR
        xbmcgui.Dialog().notification('C.O.S.M.O.S', _fail_msg,
                                      _fail_icon, 5000)
        if not use_player:
            _set_failed()
        try:
            if _debug_mod:
                _debug_mod.end_session(error='resolve_filehost_link returned None')
        except Exception:
            pass
        return False
    except Exception as e:
        dlg.close()
        xbmc.log(f'COSMOS: play_direct_link error: {e}', xbmc.LOGERROR)
        _dblog('PLAY-EXCEPTION', str(e))
        if not use_player:
            _set_failed()
        try:
            if _debug_mod:
                _debug_mod.end_session(error=str(e))
        except Exception:
            pass
        return False


def _auto_play_direct_link(sources):
    """Iterate over direct link sources (like EasyNews) and play the first that resolves."""
    xbmc.log(
        f'COSMOS [FLOW] auto_play_direct_link  candidates={len(sources)}',
        xbmc.LOGDEBUG,
    )
    for i, source in enumerate(sources):
        url = source.get('url', '')
        if not url:
            xbmc.log(
                f'COSMOS [FLOW] auto_play_direct_link  [{i}] skip — no URL'
                f'  title={source.get("title","")[:60]!r}',
                xbmc.LOGDEBUG,
            )
            continue
        xbmc.log(
            f'COSMOS [FLOW] auto_play_direct_link  [{i}] trying'
            f'  source={source.get("source")!r}'
            f'  title={source.get("title","")[:60]!r}',
            xbmc.LOGDEBUG,
        )
        stream, name = resolve_filehost_link(url) # Use existing resolver
        if stream:
            xbmc.log(
                f'COSMOS [FLOW] auto_play_direct_link  [{i}] resolved via {name!r}',
                xbmc.LOGDEBUG,
            )
            xbmcgui.Dialog().notification(
                'C.O.S.M.O.S',
                f"Playing via {name} [{source.get('quality', '?')}]",
                xbmcgui.NOTIFICATION_INFO,
                2500,
            )
            _play_stream(stream)
            return True
    return False


def _auto_play_torrent(sources, preferred_quality):
    """Iterate over sorted torrent sources and play first that resolves."""
    try:
        pref_idx = QUALITY_ORDER.index(preferred_quality)
    except ValueError:
        pref_idx = 1

    def sort_key(s):
        q = s.get('quality', '480p')
        try:
            q_idx = QUALITY_ORDER.index(q)
        except ValueError:
            q_idx = 4
        cached = 0 if s.get('cached') else 1
        qprio = (0, q_idx) if q_idx >= pref_idx else (1, q_idx)
        seeds = s.get('seeds', 0) or 0
        return (cached, qprio[0], qprio[1], -seeds)

    sources.sort(key=sort_key)

    xbmc.log(
        f'COSMOS [FLOW] auto_play_torrent  preferred={preferred_quality!r}'
        f'  candidates={min(12, len(sources))}  total={len(sources)}',
        xbmc.LOGDEBUG,
    )

    for i, source in enumerate(sources[:12]):
        magnet = source.get('magnet', '')
        if not magnet:
            xbmc.log(
                f'COSMOS [FLOW] auto_play_torrent  [{i}] skip — no magnet'
                f'  title={source.get("title","")[:60]!r}',
                xbmc.LOGDEBUG,
            )
            continue
        xbmc.log(
            f'COSMOS [FLOW] auto_play_torrent  [{i}] trying'
            f'  quality={source.get("quality")!r}'
            f'  cached={source.get("cached")}  seeds={source.get("seeds")}'
            f'  source={source.get("source")!r}'
            f'  title={source.get("title","")[:60]!r}',
            xbmc.LOGDEBUG,
        )
        stream_url, name = debrid.resolve_magnet(magnet)
        if stream_url:
            xbmc.log(
                f'COSMOS [FLOW] auto_play_torrent  [{i}] resolved via {name!r}'
                f'  quality={source.get("quality")!r}',
                xbmc.LOGDEBUG,
            )
            xbmcgui.Dialog().notification(
                'C.O.S.M.O.S',
                f"Playing via {name} [{source.get('quality', '?')}]",
                xbmcgui.NOTIFICATION_INFO,
                2500,
            )
            _play_stream(stream_url)
            return True
        xbmc.log(
            f'COSMOS [FLOW] auto_play_torrent  [{i}] resolve failed'
            f'  source={source.get("source")!r}',
            xbmc.LOGDEBUG,
        )
        time.sleep(0.2)

    xbmc.log('COSMOS [FLOW] auto_play_torrent  all candidates exhausted — no playable source', xbmc.LOGWARNING)
    return False


def play_search_token(token, title, year='', tmdb_id='', imdb_id='',
                       content='movie', season=None, episode=None):
    """Handle Search4k / Search1080 / Search720 playback.

    Runs the torrent scrapers (Torrentio + TPB + 1337x), filters by the
    preferred quality derived from the token, checks debrid cache and
    auto-plays the best cached / highest-seeded source.
    """
    target_quality = SEARCH_TOKENS.get(token.lower(), '1080p')
    xbmc.log(
        f'COSMOS [FLOW] play_search_token  token={token!r}'
        f'  target_quality={target_quality!r}'
        f'  title={title!r}  year={year!r}'
        f'  imdb={imdb_id!r}  tmdb={tmdb_id!r}'
        f'  content={content!r}  season={season!r}  episode={episode!r}',
        xbmc.LOGDEBUG,
    )

    services = debrid.get_debrid_services()
    easynews_ready = False
    try:
        from . import easynews as easynews_mod
        easynews_ready = (
            easynews_mod.EasyNews.addon.getSetting('easynews_enabled') != 'false'
            and easynews_mod.EasyNews.has_credentials()
        )
    except Exception:
        pass
    if not services and not easynews_ready:
        xbmc.log('COSMOS [ERROR] play_search_token  no debrid services configured', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No debrid service configured',
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        _set_failed()
        return False

    xbmc.log(f'COSMOS [FLOW] play_search_token  debrid services: {[n for n, _ in services]}', xbmc.LOGDEBUG)
    dlg = xbmcgui.DialogProgressBG()
    dlg.create('C.O.S.M.O.S', f'Searching torrents: {title}')

    # For TV content, include SxxExx in the text query so PirateBay / 1337x
    # / RARBG / TorrentGalaxy (which are text-search only) return the right
    # episode. Torrentio is already IMDB+S+E accurate and ignores the query.
    is_tv = content and str(content).lower() != 'movie'
    query = f'{title} {year}'.strip()
    if is_tv and season is not None and episode is not None:
        try:
            query = f'{title} S{int(season):02d}E{int(episode):02d}'.strip()
        except (TypeError, ValueError):
            pass

    try:
        results = scrapers.search_all(
            query,
            preferred_quality=target_quality,
            imdb_id=imdb_id,
            content=content,
            season=season,
            episode=episode,
        )
    except Exception as e:
        xbmc.log(f'COSMOS: scrapers error: {e}', xbmc.LOGERROR)
        results = []

    xbmc.log(
        f'COSMOS [FLOW] play_search_token  scrapers returned {len(results)} results '
        f'(including EasyNews if enabled)'
        f'  query={query!r}',
        xbmc.LOGDEBUG,
    )

    if not results:
        dlg.close()
        xbmc.log('COSMOS [FLOW] play_search_token  no sources found — aborting', xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No sources found', xbmcgui.NOTIFICATION_WARNING, 4000)
        _set_failed()
        return False

    # Separate EasyNews results from torrents
    easynews_results = [r for r in results if r.get('source') == 'EasyNews']
    torrent_results = [r for r in results if r.get('source') != 'EasyNews']

    # Keep sources that match requested quality first; then fallback
    filtered_torrents = [r for r in torrent_results if r.get('quality') == target_quality] + \
                        [r for r in torrent_results if r.get('quality') != target_quality]
    torrent_results = filtered_torrents

    # Sort EasyNews results by size (largest first)
    easynews_results.sort(key=lambda s: s.get('size', 0), reverse=True)

    # Try EasyNews first
    if easynews_results:
        dlg.update(40, f'Found {len(easynews_results)} EasyNews sources. Trying to play...')
        # Optional queue hand-off.  This only runs for a configured downloader
        # and a genuine NZB URL; ordinary Easynews media URLs are never sent
        # to SABnzbd/NZBGet.  If no NZB URL exists, preserve direct playback.
        try:
            from . import usenet_clients
            queued, queue_message = usenet_clients.maybe_submit_result(
                easynews_results[0], name=title
            )
            if queued:
                dlg.close()
                xbmcgui.Dialog().notification(
                    'C.O.S.M.O.S', queue_message,
                    xbmcgui.NOTIFICATION_INFO, 4000,
                )
                return True
            if queue_message and 'direct playback' not in queue_message.lower():
                xbmc.log(f'COSMOS Usenet queue fallback: {queue_message}', xbmc.LOGWARNING)
        except Exception as exc:
            # The optional integration must never prevent normal playback.
            xbmc.log(f'COSMOS Usenet queue hand-off skipped: {exc}', xbmc.LOGWARNING)
        if _auto_play_direct_link(easynews_results):
            dlg.close()
            return True

    xbmc.log(
        f'COSMOS [FLOW] play_search_token  after quality sort'
        f'  target={target_quality!r}  preferred_count={sum(1 for r in results if r.get("quality")==target_quality)}',
        xbmc.LOGDEBUG,
    )

    # Cache check
    dlg.update(60, f'Found {len(torrent_results)} torrent sources. Checking debrid cache...')
    hashes = []
    for r in results:
        h = scrapers.extract_hash(r.get('magnet', ''))
        if h:
            hashes.append(h)
            r['hash'] = h
    try:
        cached_set = debrid.check_cache_all(hashes) if hashes else set()
    except Exception:
        cached_set = set()
    xbmc.log(
        f'COSMOS [FLOW] play_search_token  cache check'
        f'  hashes={len(hashes)}  cached_hits={len(cached_set)}',
        xbmc.LOGDEBUG,
    ) # This loop is for torrents
    for r in torrent_results:
        if r.get('hash', '').lower() in cached_set:
            r['cached'] = True

    dlg.update(80, 'Resolving best torrent source via debrid...')
    try:
        ok = _auto_play_torrent(torrent_results, target_quality)
    finally:
        dlg.close()

    if not ok:
        xbmc.log('COSMOS [ERROR] play_search_token  auto_play_torrent returned False — no playable source', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No playable source', xbmcgui.NOTIFICATION_ERROR, 4000)
        _set_failed()
    else:
        xbmc.log('COSMOS [FLOW] play_search_token  playback started successfully', xbmc.LOGDEBUG)
    return ok
