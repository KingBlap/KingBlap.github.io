# -*- coding: utf-8 -*-
"""Search history for C.O.S.M.O.S.

A lightweight JSON-backed store of recent user search queries. When the
Universal Search entry is opened, the history is shown first so users
can re-run a recent query with one click; entering a new query saves it
to the top of the list and trims to MAX_ENTRIES.
"""
import json
import os
import time

import xbmc
import xbmcvfs


PROFILE_DIR = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/')
HISTORY_FILE = os.path.join(PROFILE_DIR, 'search_history.json')
MAX_ENTRIES = 25


def _ensure():
    if not os.path.isdir(PROFILE_DIR):
        try:
            os.makedirs(PROFILE_DIR)
        except OSError:
            pass


def load():
    _ensure()
    if not os.path.isfile(HISTORY_FILE):
        return []
    try:
        with open(HISTORY_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp) or []
        if not isinstance(data, list):
            return []
        # Backwards-compat: allow plain string list
        return [i if isinstance(i, dict) else {'q': str(i), 'ts': 0} for i in data]
    except (ValueError, OSError):
        return []


def save(items):
    _ensure()
    try:
        with open(HISTORY_FILE, 'w', encoding='utf-8') as fp:
            json.dump(items[:MAX_ENTRIES], fp, indent=2)
    except OSError as e:
        xbmc.log(f'COSMOS search_history: save failed: {e}', xbmc.LOGWARNING)
    try:
        from . import sync as _sync
        _sync.maybe_autosync()
    except Exception:
        pass


def add(query):
    q = (query or '').strip()
    if not q:
        return
    items = load()
    items = [i for i in items if (i.get('q') or '').lower() != q.lower()]
    items.insert(0, {'q': q, 'ts': int(time.time())})
    save(items)


def remove(query):
    q = (query or '').strip().lower()
    items = load()
    new = [i for i in items if (i.get('q') or '').lower() != q]
    if len(new) == len(items):
        return False
    save(new)
    return True


def clear():
    save([])
