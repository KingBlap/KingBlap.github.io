"""Plex's regional free VOD/live catalogue and adaptive playback."""
import json
import os
import re
import sys
import uuid
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urljoin, urlsplit
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from . import tmdb as tmdb_mod


PLEX_TV = 'https://plex.tv/'
DISCOVER_API = 'https://discover.provider.plex.tv/'
VOD_API = 'https://vod.provider.plex.tv/'
EPG_API = 'https://epg.provider.plex.tv/'
WATCH_TV = 'https://watch.plex.tv/'
PAGE_SIZE = 40
PROVIDER_VERSION = '7.6.0'
INPUTSTREAM_ADAPTIVE_ID = 'inputstream.adaptive'
ADDON = xbmcaddon.Addon()
CLIENT_ID = str(uuid.uuid4())
TOKEN = None
try:
    import xbmcvfs
    CACHE_DIR = xbmcvfs.translatePath(
        'special://profile/addon_data/plugin.video.cosmos/plex_cache/'
    )
except ImportError:
    CACHE_DIR = os.path.join(os.path.expanduser('~'), '.cosmos', 'plex_cache')


def _locale():
    """Choose Plex's regional English catalogue from Kodi's country setting."""
    country_to_locale = {
        'US': 'en-US', 'AU': 'en-AU', 'CA': 'en-CA',
        'GB': 'en-GB', 'IE': 'en-GB', 'NZ': 'en-GB',
    }
    try:
        language = xbmc.getLanguage(xbmc.ISO_639_1, True) or ''
        country = language.rsplit('-', 1)[-1].strip().upper() if '-' in language else ''
    except Exception:
        country = ''
    return country_to_locale.get(country, 'en-GB')


def _headers(token=True):
    platform = (xbmc.getInfoLabel('System.Platform') or '').strip().lower()
    android = platform == 'android' or 'android' in platform
    values = {
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0',
        'Referer': 'https://watch.plex.tv/',
        'X-Plex-Client-Identifier': CLIENT_ID,
        # The anonymous endpoint is restricted to Plex's recognised web
        # client profile.  Custom product/platform values receive a misleading
        # 404 before the catalogue request is ever made.
        'X-Plex-Product': 'Plex Web',
        'X-Plex-Version': '4.150.0',
        'X-Plex-Platform': 'Android' if android else 'Chrome',
        'X-Plex-Device': 'Android' if android else 'Windows',
        'X-Plex-Device-Name': 'Kodi Android' if android else 'Chrome',
        'X-Plex-Provider-Version': PROVIDER_VERSION,
        'X-Plex-Language': _locale(),
    }
    if token and TOKEN:
        values['X-Plex-Token'] = TOKEN
    return values


def _https(url, allowed):
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or parsed.hostname not in allowed:
        raise ValueError('Plex returned an invalid service URL.')
    return url


def _anonymous_token():
    global TOKEN
    if TOKEN:
        return TOKEN
    request = Request(PLEX_TV + 'api/v2/users/anonymous', data=b'{}',
                      headers=dict(_headers(False), **{'Content-Type': 'application/json'}),
                      method='POST')
    try:
        with urlopen(request, timeout=25) as response:
            data = json.load(response)
    except HTTPError as exc:
        raise ValueError('Plex could not start an anonymous session (HTTP %s).'
                         % exc.code) from exc
    token = str(data.get('authToken') or '')
    if not token:
        raise ValueError('Plex did not create an anonymous playback session.')
    TOKEN = token
    return token


def _plex_token():
    """Return the user's Plex token, falling back to an anonymous session."""
    global TOKEN
    saved = (ADDON.getSetting('plex_token') or '').strip()
    if saved:
        TOKEN = saved
        return TOKEN
    username = (ADDON.getSetting('plex_username') or '').strip()
    password = ADDON.getSetting('plex_password') or ''
    if username and password:
        request = Request(
            PLEX_TV + 'users/sign_in.json',
            data=json.dumps({'login': username, 'password': password}).encode('utf-8'),
            headers=dict(_headers(False), **{'Content-Type': 'application/json'}),
            method='POST',
        )
        try:
            with urlopen(request, timeout=25) as response:
                data = json.load(response)
            token = str(data.get('authToken') or '')
            if token:
                TOKEN = token
                ADDON.setSetting('plex_token', token)
                return TOKEN
        except (HTTPError, URLError, ValueError, TypeError, OSError) as exc:
            xbmc.log('[Cosmos Plex] account sign-in failed: %s' % exc, xbmc.LOGWARNING)
    return _anonymous_token()


def _api(base, path, params=None, start=None, size=None):
    _plex_token()
    url = urljoin(base, path.lstrip('/'))
    if params:
        url += ('&' if '?' in url else '?') + urlencode(params)
    allowed = {'discover.provider.plex.tv', 'vod.provider.plex.tv'}
    url = _https(url, allowed)
    headers = _headers()
    if start is not None:
        headers['X-Plex-Container-Start'] = str(max(0, int(start)))
    if size is not None:
        headers['X-Plex-Container-Size'] = str(max(1, int(size)))
    with urlopen(Request(url, headers=headers), timeout=25) as response:
        data = json.load(response)
    return data


def _container(data):
    value = data.get('MediaContainer') if isinstance(data, dict) else None
    if not isinstance(value, dict):
        raise ValueError('Plex returned an unexpected catalogue response.')
    return value


def _offset(params):
    try:
        return max(0, int(params.get('offset', 0)))
    except (TypeError, ValueError):
        return 0


def _image(item, kind, fallback):
    for image in item.get('Image') or []:
        if isinstance(image, dict) and image.get('type') == kind:
            value = image.get('url')
            if str(value).startswith('https://'):
                return value
    key = 'thumb' if kind == 'coverPoster' else 'art'
    value = item.get(key)
    return value if str(value).startswith('https://') else fallback


def _tags(item, name):
    return ', '.join(str(value.get('tag')) for value in item.get(name) or []
                     if isinstance(value, dict) and value.get('tag'))


def _info(item):
    media_type = item.get('type') or 'movie'
    info = {
        'title': item.get('title') or 'Untitled',
        'plot': item.get('summary') or '',
        'year': item.get('year') or 0,
        'genre': _tags(item, 'Genre'),
        'rating': item.get('rating') or item.get('audienceRating') or 0,
        'duration': int(item.get('duration') or 0) // 1000,
        'mpaa': item.get('contentRating') or '',
        'mediatype': {'show': 'tvshow', 'season': 'season',
                      'episode': 'episode'}.get(media_type, 'movie'),
    }
    for source, target in (('index', 'episode'), ('parentIndex', 'season')):
        if str(item.get(source, '')).isdigit():
            info[target] = int(item[source])
    return info


def _tmdb_episode_still(item):
    """Return a current TMDB still for a Plex episode."""
    if item.get('type') != 'episode':
        return ''
    show_title = str(item.get('grandparentTitle') or '').strip()
    season_number = item.get('parentIndex')
    episode_number = item.get('index')
    try:
        season_number = int(season_number)
        episode_number = int(episode_number)
    except (TypeError, ValueError):
        return ''
    if not show_title or season_number < 0 or episode_number < 1:
        return ''
    year = item.get('grandparentYear') or ''
    try:
        show = tmdb_mod.search_art_by_title(show_title, 'tv', year=year) or {}
        tmdb_id = str(show.get('tmdb_id') or '')
        if not tmdb_id:
            return ''
        episodes = tmdb_mod.get_tv_episodes(tmdb_id, season_number) or []
        match = next((episode for episode in episodes
                      if int(episode.get('number') or 0) == episode_number), {})
        still = str(match.get('still') or '')
        return still if still.startswith('https://') else ''
    except Exception as exc:
        xbmc.log('[Cosmos Plex] TMDB episode still lookup failed: %s' % exc,
                 xbmc.LOGDEBUG)
        return ''


def _add_item(item, add, build_url, icon, fanart):
    rating_key = str(item.get('ratingKey') or '')
    if not re.fullmatch(r'[A-Za-z0-9._-]+', rating_key):
        return
    media_type = item.get('type') or 'movie'
    folder = media_type in ('show', 'season')
    action = 'plex_children' if folder else 'plex_play'
    episode_still = _tmdb_episode_still(item)
    add(item.get('title') or 'Untitled',
        build_url(action=action, rating_key=rating_key, media_type=media_type),
        thumb=episode_still or _image(item, 'coverPoster', icon),
        fanart=_image(item, 'background', fanart), info=_info(item),
        is_folder=folder, is_playable=not folder)


def _page_links(total, params, action, add, build_url, icon, fanart):
    offset = _offset(params)
    if offset:
        previous = dict(params, action=action,
                        offset=str(max(0, offset - PAGE_SIZE)))
        add('Previous Page (%d-%d)' % (max(0, offset - PAGE_SIZE) + 1, offset),
            build_url(**previous), thumb=icon, fanart=fanart)
    if offset + PAGE_SIZE < total:
        following = dict(params, action=action, offset=str(offset + PAGE_SIZE))
        add('Next Page (%d-%d)' % (offset + PAGE_SIZE + 1,
                                   min(total, offset + PAGE_SIZE * 2)),
            build_url(**following), thumb=icon, fanart=fanart)


def _listing(container, params, action, add, build_url, icon, fanart):
    items = container.get('Metadata') or []
    for item in items:
        if isinstance(item, dict):
            _add_item(item, add, build_url, icon, fanart)
    total = int(container.get('totalSize') or container.get('size') or len(items))
    _page_links(total, params, action, add, build_url, icon, fanart)
    if not items:
        xbmcgui.Dialog().notification('Plex', 'No free titles are available in this region.')


def _browse(params):
    media_type = params.get('mode', 'movie')
    type_id = '2' if media_type == 'show' else '1'
    query = {'type': type_id, 'availabilityType': 'free',
             'sort': 'ratingCount:desc'}
    if params.get('genre'):
        query['genre'] = params['genre']
    return _container(_api(VOD_API, 'library/sections/movies/all', query,
                           start=_offset(params), size=PAGE_SIZE))


def _search(params):
    query = params.get('query', '').strip()
    data = _container(_api(DISCOVER_API, 'library/search', {
        'searchTypes': 'movies,tv', 'searchProviders': 'plexAVOD',
        'includeMetadata': '1', 'limit': '100', 'query': query,
    }))
    groups = data.get('SearchResults') or []
    results = []
    for group in groups:
        if not isinstance(group, dict):
            continue
        provider_id = str(group.get('id') or '').casefold()
        provider_name = str(group.get('title') or group.get('name') or '').casefold()
        if provider_id not in ('plex', 'plexavod') and 'plex' not in provider_name:
            continue
        for result in group.get('SearchResult') or []:
            if not isinstance(result, dict):
                continue
            # Plex has returned both {Metadata: {...}} and
            # {Metadata: [{...}, ...]} here.  Accept either shape; a search
            # result must retain its ratingKey so _add_item can wire it to
            # plex_play or plex_children.
            metadata = result.get('Metadata')
            if isinstance(metadata, dict):
                results.append(metadata)
            elif isinstance(metadata, list):
                results.extend(item for item in metadata
                               if isinstance(item, dict))
            elif result.get('ratingKey'):
                results.append(result)
    offset = _offset(params)
    return {'Metadata': results[offset:offset + PAGE_SIZE],
            'size': min(PAGE_SIZE, max(0, len(results) - offset)),
            'totalSize': len(results)}


def _children(rating_key):
    if not re.fullmatch(r'[A-Za-z0-9._-]+', str(rating_key)):
        raise ValueError('Invalid Plex content ID.')
    return _container(_api(VOD_API,
                           'library/metadata/%s/children' % rating_key,
                           start=0, size=200))


def _metadata(rating_key, base=VOD_API):
    if not re.fullmatch(r'[A-Za-z0-9._-]+', str(rating_key)):
        raise ValueError('Invalid Plex content ID.')
    container = _container(_api(base, 'library/metadata/%s' % rating_key))
    items = container.get('Metadata') or []
    if not items:
        raise ValueError('This Plex title is no longer available.')
    return items[0]


def _play_queue(rating_key):
    """Create Plex's DRM playback decision and return its selected item."""
    if not re.fullmatch(r'[A-Za-z0-9._-]+', str(rating_key)):
        raise ValueError('Invalid Plex content ID.')
    _anonymous_token()
    playable = ('provider://tv.plex.provider.vod/library/metadata/' +
                str(rating_key))
    url = urljoin(VOD_API, 'playQueues') + '?' + urlencode({
        'uri': playable, 'type': 'video', 'continuous': '1',
    })
    headers = _headers()
    headers['X-Plex-Drm'] = 'widevine'
    request = Request(url, data=b'', headers=headers, method='POST')
    with urlopen(request, timeout=25) as response:
        container = _container(json.load(response))
    selected = container.get('playQueueSelectedItemID')
    items = container.get('Metadata') or []
    item = next((value for value in items
                 if str(value.get('playQueueItemID')) == str(selected)), None)
    if not item:
        raise ValueError('Plex did not select a playable item.')
    return item


def _play(rating_key):
    if not _ensure_playback_components():
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        return
    item = _play_queue(rating_key)
    if item.get('requiresConsent'):
        xbmc.log('COSMOS Plex: title requests advertising consent', xbmc.LOGDEBUG)
    choices = []
    for media in item.get('Media') or []:
        if not isinstance(media, dict):
            continue
        for part in media.get('Part') or []:
            if isinstance(part, dict) and str(part.get('key') or '').startswith('/'):
                choices.append((media, part))
    # Prefer Widevine DASH for encrypted titles.  A large part of Plex's
    # catalogue is intentionally clear and therefore has no DRM/license
    # fields; use its HLS variant first, with clear DASH as a fallback.
    selected = next(((media, part) for media, part in choices
                     if media.get('protocol') == 'dash'
                     and part.get('drm') == 'widevine'
                     and part.get('license')), None)
    encrypted = selected is not None
    if not selected:
        selected = next(((media, part) for media, part in choices
                         if media.get('protocol') == 'hls'
                         and not media.get('drm') and not part.get('drm')), None)
    if not selected:
        selected = next(((media, part) for media, part in choices
                         if media.get('protocol') == 'dash'
                         and not media.get('drm') and not part.get('drm')), None)
    if not selected:
        raise ValueError('Plex did not provide a supported stream for this title.')
    media, part = selected
    manifest_path = str(part.get('key') or '')
    license_path = str(part.get('license') or '')
    if not manifest_path.startswith('/') or (encrypted and not license_path.startswith('/')):
        raise ValueError('Plex returned incomplete Widevine playback information.')
    playback_params = {
        'X-Plex-Token': _anonymous_token(),
    }
    if encrypted:
        playback_params['x-plex-drm'] = 'widevine'
    manifest_params = dict(playback_params)
    manifest_params.update({
        'includeAllStreams': '1',
        'X-Plex-Product': 'Plex Mediaverse',
    })
    manifest = (urljoin(VOD_API, manifest_path.lstrip('/')) + '?' +
                urlencode(manifest_params))
    license_url = ((urljoin(VOD_API, license_path.lstrip('/')) + '?' +
                    urlencode(playback_params)) if encrypted else '')
    _https(manifest, {'vod.provider.plex.tv'})
    if encrypted:
        _https(license_url, {'vod.provider.plex.tv'})
    _anonymous_token()
    headers = _headers()
    header_part = urlencode(headers)
    item_headers = {'Content-Type': 'application/octet-stream'}
    li = xbmcgui.ListItem(path=manifest)
    li.setInfo('video', _info(item))
    li.setArt({'thumb': _image(item, 'coverPoster', ''),
               'fanart': _image(item, 'background', '')})
    protocol = media.get('protocol')
    li.setMimeType('application/vnd.apple.mpegurl' if protocol == 'hls'
                   else 'application/dash+xml')
    li.setContentLookup(False)
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type',
                   'hls' if protocol == 'hls' else 'mpd')
    li.setProperty('inputstream.adaptive.manifest_headers', header_part)
    li.setProperty('inputstream.adaptive.stream_headers', header_part)
    if encrypted:
        li.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        li.setProperty('inputstream.adaptive.license_key',
                       license_url + '|' + urlencode(item_headers) + '|R{SSM}|')
        li.setProperty('inputstream.adaptive.license_data', '')
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)


def _addon_available(addon_id):
    """Return whether an installed Kodi component is currently enabled."""
    try:
        return bool(xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id))
    except Exception:
        try:
            xbmcaddon.Addon(addon_id)
            return True
        except Exception:
            return False


def _ensure_playback_components():
    """Offer to install InputStream Adaptive when playback needs it."""
    missing = []
    if not _addon_available(INPUTSTREAM_ADAPTIVE_ID):
        missing.append(('InputStream Adaptive', INPUTSTREAM_ADAPTIVE_ID))
    if not missing:
        return True
    names = ' and '.join(value[0] for value in missing)
    message = ('Plex playback needs %s. Set up the missing Kodi '
               'component%s now?' % (names, 's' if len(missing) > 1 else ''))
    if not xbmcgui.Dialog().yesno(
            'Plex playback setup', message,
            yeslabel='Set up', nolabel='Cancel'):
        return False
    for unused_name, addon_id in missing:
        xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
    xbmcgui.Dialog().notification(
        'Plex', 'Playback component installation requested. Try the title again when installation finishes.',
        xbmcgui.NOTIFICATION_INFO, 6500)
    return False


def _json_text(value):
    """Decode JSON escapes embedded in Plex's server-rendered guide."""
    try:
        return json.loads('"' + value + '"')
    except (TypeError, ValueError):
        return value.replace(r'\u0026', '&').replace(r'\/', '/')


def _live_channels():
    """Read the regional channel records rendered by Plex's public guide."""
    locale = _locale()
    url = urljoin(WATCH_TV, locale + '/live-tv')
    request = Request(url, headers=_headers(False))
    with urlopen(request, timeout=35) as response:
        page = response.read().decode('utf-8', 'replace')
    pattern = re.compile(
        r'\\"id\\":\\"(?P<id>[A-Za-z0-9-]+)\\",'
        r'\\"slug\\":\\"(?P<slug>[^\\"]+)\\",'
        r'\\"title\\":\\"(?P<title>[^\\"]+)\\",'
        r'\\"thumb\\":\\"(?P<thumb>https:[^\\"]+)\\"'
        r'.{0,5000}?\\"key\\":\\"(?P<key>/library/parts/[^\\"]+\.m3u8)\\"',
        re.DOTALL)
    channels = []
    seen = set()
    for match in pattern.finditer(page):
        channel_id = match.group('id')
        if channel_id in seen or not re.fullmatch(r'[A-Za-z0-9-]+', channel_id):
            continue
        seen.add(channel_id)
        channels.append({
            'id': channel_id,
            'title': _json_text(match.group('title')),
            'thumb': _json_text(match.group('thumb')),
        })
    if not channels:
        raise ValueError('Plex returned no Live TV channels for this region.')
    return channels


def _live_listing(params, add, build_url, icon, fanart):
    channels = _live_channels()
    offset = _offset(params)
    for channel in channels[offset:offset + PAGE_SIZE]:
        title = channel['title'] or 'Plex Live TV'
        add(title,
            build_url(action='plex_live_play', channel_id=channel['id'],
                      title=title, thumb=channel['thumb']),
            thumb=channel['thumb'] or icon, fanart=fanart,
            info={'title': title, 'plot': 'Watch this free live channel on Plex.',
                  # Do not assign a video media type: Kodi otherwise treats
                  # the live channel like a library video and offers watched
                  # state/playcount handling for it.
                  },
            is_folder=False, is_playable=True)
    _page_links(len(channels), params, 'plex_live', add, build_url, icon, fanart)


def _live_play(params):
    if not _ensure_playback_components():
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        return
    channel_id = str(params.get('channel_id') or '')
    if not re.fullmatch(r'[A-Za-z0-9-]+', channel_id):
        raise ValueError('Invalid Plex Live TV channel ID.')
    _anonymous_token()
    tune_url = urljoin(EPG_API, 'channels/%s/tune' % channel_id) + '?autoPreview=0'
    tune_data = b''
    with urlopen(Request(tune_url, data=b'', headers=_headers(), method='POST'),
                 timeout=25) as response:
        # Plex may return a session-specific manifest/token here.  Keeping it
        # avoids the fixed anonymous URL expiring during long live sessions.
        tune_data = response.read()
    manifest = ''
    live_token = ''
    try:
        tuned = json.loads(tune_data.decode('utf-8', 'replace'))
        candidates = []
        def _walk(value):
            nonlocal live_token
            if isinstance(value, dict):
                for key, child in value.items():
                    if key.lower() in ('url', 'streamurl', 'manifest', 'manifesturl', 'key'):
                        candidates.append(str(child))
                    if key.lower() in ('token', 'plextoken', 'x-plex-token') and child:
                        live_token = str(child)
                    _walk(child)
            elif isinstance(value, list):
                for child in value:
                    _walk(child)
        _walk(tuned)
        manifest = next((urljoin(EPG_API, value.lstrip('/')) for value in candidates
                         if '.m3u8' in value), '')
    except (TypeError, ValueError, UnicodeDecodeError):
        pass
    if not manifest:
        manifest = urljoin(EPG_API, 'library/parts/%s.m3u8' % channel_id)
    separator = '&' if '?' in manifest else '?'
    manifest += separator + urlencode({'X-Plex-Token': live_token or _anonymous_token()})
    _https(manifest, {'epg.provider.plex.tv'})
    # The catalogue headers advertise JSON, which is useful for Plex API
    # calls but can make an adaptive HLS request negotiate the wrong
    # representation.  Keep playback headers focused on media delivery.
    stream_headers = _headers()
    stream_headers['Accept'] = '*/*'
    if live_token:
        stream_headers['X-Plex-Token'] = live_token
    header_part = urlencode(stream_headers)
    li = xbmcgui.ListItem(path=manifest)
    title = str(params.get('title') or 'Plex Live TV')
    li.setInfo('video', {'title': title, 'mediatype': 'video'})
    li.setArt({'thumb': str(params.get('thumb') or '')})
    li.setMimeType('application/vnd.apple.mpegurl')
    li.setContentLookup(False)
    li.setProperty('inputstream', INPUTSTREAM_ADAPTIVE_ID)
    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    # Plex Live TV uses a sliding HLS window.  Force complete playlist
    # refreshes so ISA does not lose the live edge after a long session when
    # a server rotates or omits delta updates.
    li.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
    li.setProperty('inputstream.adaptive.manifest_headers', header_part)
    li.setProperty('inputstream.adaptive.stream_headers', header_part)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)


def _refresh():
    # Retain old saved routes; browsing always fetches current data.
    clear_cache()
    xbmc.executebuiltin('Container.Refresh')


def clear_cache():
    """Remove files left by older versions of the Plex cache."""
    try:
        if os.path.isdir(CACHE_DIR):
            for name in os.listdir(CACHE_DIR):
                if name.endswith(('.json', '.tmp')):
                    try:
                        os.remove(os.path.join(CACHE_DIR, name))
                    except OSError:
                        pass
    except OSError:
        pass


def _inputstream_adaptive_available():
    """Return whether Kodi has InputStream Adaptive enabled."""
    try:
        return _addon_available(INPUTSTREAM_ADAPTIVE_ID)
    except Exception:
        return False


def _install_inputstream_adaptive():
    """Ask Kodi to install the platform-correct package from its repository."""
    if _inputstream_adaptive_available():
        xbmcgui.Dialog().notification(
            'Plex', 'InputStream Adaptive is already enabled',
            xbmcgui.NOTIFICATION_INFO, 3500)
        xbmc.executebuiltin('Container.Refresh')
        return
    # Kodi selects the correct package for the current platform from its
    # enabled official repository.
    xbmc.executebuiltin('InstallAddon(%s)' % INPUTSTREAM_ADAPTIVE_ID)
    xbmcgui.Dialog().notification(
        'Plex', 'InputStream Adaptive installation requested',
        xbmcgui.NOTIFICATION_INFO, 5000)
    # Rebuild the Plex root after Kodi finishes the install.  The menu itself
    # also checks System.HasAddon every time it is rendered, so the entry
    # disappears as soon as Kodi reports the dependency as enabled.
    xbmc.executebuiltin('Container.Refresh')


def run(action, params, add, build_url, icon, fanart):
    global TOKEN
    TOKEN = None
    clear_cache()
    handle = int(sys.argv[1])
    playing = action in ('plex_play', 'plex_live_play')
    succeeded = False
    try:
        if playing:
            if action == 'plex_live_play':
                _live_play(params)
            else:
                _play(params.get('rating_key', ''))
            return
        xbmcplugin.setContent(handle, 'videos')
        if action == 'plex_root':
            entries = [
                ('Movies', 'Browse free ad-supported movies on Plex.', 'plex_browse', {'mode': 'movie'}, True),
                ('TV Shows', 'Browse free ad-supported shows on Plex.', 'plex_browse', {'mode': 'show'}, True),
                ('Movie Categories', 'Browse free Plex movies by genre.', 'plex_categories', {'mode': 'movie'}, True),
                ('TV Categories', 'Browse free Plex shows by genre.', 'plex_categories', {'mode': 'show'}, True),
                ('Search Plex', 'Search the free Plex catalogue.', 'plex_search_prompt', {}, True),
            ]
            if not _inputstream_adaptive_available():
                entries.insert(
                    -1,
                    ('Install InputStream Adaptive',
                     'Install InputStream Adaptive from the Kodi repository for Plex playback.',
                     'plex_install_inputstream_adaptive', {}, False),
                )
            for title, plot, target, extra, folder in entries:
                add('[B]' + title + '[/B]', build_url(action=target, **extra),
                    thumb=icon, fanart=fanart, info={'title': title, 'plot': plot},
                    is_folder=folder)
            notice = 'Plex content is ad-supported, DRM-protected, and region dependent.'
            add('[COLOR gold]' + notice + '[/COLOR]', '', thumb=icon,
                fanart=fanart, info={'title': notice}, is_folder=False)
        elif action == 'plex_browse':
            _listing(_browse(params), params, action, add, build_url, icon, fanart)
        elif action == 'plex_live':
            _live_listing(params, add, build_url, icon, fanart)
        elif action == 'plex_categories':
            mode = params.get('mode', 'movie')
            type_id = '2' if mode == 'show' else '1'
            container = _container(_api(VOD_API, 'library/sections/movies/genre',
                                        {'type': type_id, 'availabilityType': 'free'},
                                        start=0, size=100))
            for category in container.get('Directory') or []:
                genre = str(category.get('value') or '')
                if re.fullmatch(r'[A-Za-z0-9._-]+', genre):
                    add(category.get('title') or 'Category',
                        build_url(action='plex_browse', mode=mode, genre=genre),
                        thumb=category.get('icon') or icon, fanart=fanart)
        elif action == 'plex_search_prompt':
            query = str(xbmcgui.Dialog().input('Search Plex') or '').strip()
            if query:
                # Render in this invocation. Container.Update followed by
                # endOfDirectory can race on Kodi and discard the results.
                _listing(_search({'query': query}),
                         {'query': query}, 'plex_search_results',
                         add, build_url, icon, fanart)
        elif action == 'plex_search_results':
            _listing(_search(params), params, action, add, build_url, icon, fanart)
        elif action == 'plex_children':
            container = _children(params.get('rating_key', ''))
            _listing(container, params, action, add, build_url, icon, fanart)
        elif action == 'plex_refresh':
            _refresh()
        elif action == 'plex_install_inputstream_adaptive':
            _install_inputstream_adaptive()
        else:
            raise ValueError('Unknown Plex action.')
        succeeded = True
    except HTTPError as exc:
        message = ('This Plex title is unavailable in your region.'
                   if exc.code in (403, 404, 451)
                   else 'Plex request failed (HTTP %s).' % exc.code)
        xbmc.log('[Cosmos Plex] ' + message, xbmc.LOGWARNING)
        xbmcgui.Dialog().ok('Plex', message)
    except URLError:
        xbmcgui.Dialog().ok('Plex', 'Could not connect to Plex. Please try again.')
    except Exception as exc:
        message = str(exc) if isinstance(exc, ValueError) else 'Plex returned an unexpected response.'
        xbmc.log('[Cosmos Plex] %s: %s' % (message, exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok('Plex', message)
    finally:
        if not playing:
            # Fetch listings afresh when the user opens them.
            xbmcplugin.endOfDirectory(handle, succeeded=succeeded,
                                      cacheToDisc=False)
