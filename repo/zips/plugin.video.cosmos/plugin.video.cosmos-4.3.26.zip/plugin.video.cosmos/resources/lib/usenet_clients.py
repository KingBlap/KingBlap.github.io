# -*- coding: utf-8 -*-
"""Optional SABnzbd/NZBGet submission helpers.

Cosmos does not implement an NNTP client.  This module submits NZB URLs or
bytes to a locally configured downloader.  Easynews direct playback stays
available whenever queue hand-off is unavailable.
"""
import base64
import json
from urllib.parse import urlencode, urlparse, urlunparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

import xbmc
import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon('plugin.video.cosmos')


def _setting(name, default=''):
    value = ADDON.getSetting(name)
    return value.strip() if isinstance(value, str) else default


def _valid_http_url(value):
    """Allow only configured HTTP(S) endpoints and reject userinfo."""
    parsed = urlparse((value or '').strip())
    return (
        parsed.scheme in ('http', 'https')
        and bool(parsed.hostname)
        and not parsed.username
        and not parsed.password
    )


def _request_json(url, params=None, headers=None, timeout=12):
    if params:
        separator = '&' if '?' in url else '?'
        url = f'{url}{separator}{urlencode(params)}'
    request = Request(url, headers=headers or {})
    with urlopen(request, timeout=timeout) as response:
        body = response.read().decode('utf-8', 'replace')
    return json.loads(body)


def _client_name():
    # type=select stores the selected zero-based index in Kodi settings.
    selected = _setting('usenet_download_client', '0')
    return {'1': 'sabnzbd', '2': 'nzbget'}.get(selected, '')


def is_configured():
    client = _client_name()
    if client == 'sabnzbd':
        return _valid_http_url(_setting('sabnzbd_url')) and bool(_setting('sabnzbd_api_key'))
    if client == 'nzbget':
        return (
            _valid_http_url(_setting('nzbget_url'))
            and bool(_setting('nzbget_username'))
            and bool(_setting('nzbget_password'))
        )
    return False


def _sab_url():
    """Return SABnzbd's API endpoint from either a root or API URL."""
    value = _setting('sabnzbd_url').rstrip('/')
    if not value:
        return value
    parsed = urlparse(value)
    path = parsed.path.rstrip('/')
    if path in ('', '/'):
        path = '/api'
    elif path.casefold() == '/sabnzbd':
        path = '/sabnzbd/api'
    elif not path.casefold().endswith('/api'):
        path += '/api'
    return urlunparse((parsed.scheme, parsed.netloc, path, '', parsed.query, ''))


def _sab_call(params):
    params = dict(params)
    params.update({
        'output': 'json',
        'apikey': _setting('sabnzbd_api_key'),
    })
    return _request_json(_sab_url(), params=params)


def _sab_upload(nzb_data, name, category):
    """Upload NZB bytes using SABnzbd's documented multipart addfile API."""
    boundary = '----CosmosNZBFormBoundary'
    chunks = []

    def field(key, value):
        chunks.append(f'--{boundary}\r\n'.encode('ascii'))
        chunks.append(f'Content-Disposition: form-data; name="{key}"\r\n\r\n'.encode('ascii'))
        chunks.append(str(value).encode('utf-8'))
        chunks.append(b'\r\n')

    field('mode', 'addfile')
    field('output', 'json')
    field('apikey', _setting('sabnzbd_api_key'))
    field('nzbname', name or 'Cosmos')
    field('cat', category or '*')
    chunks.append(f'--{boundary}\r\n'.encode('ascii'))
    chunks.append(
        f'Content-Disposition: form-data; name="nzbfile"; filename="cosmos.nzb"\r\n'
        'Content-Type: application/x-nzb\r\n\r\n'.encode('ascii')
    )
    chunks.append(nzb_data)
    chunks.append(b'\r\n')
    chunks.append(f'--{boundary}--\r\n'.encode('ascii'))
    request = Request(_sab_url(), data=b''.join(chunks), headers={
        'Content-Type': f'multipart/form-data; boundary={boundary}',
    })
    with urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode('utf-8', 'replace'))


def _nzbget_call(method, params=None):
    url = _setting('nzbget_url').rstrip('/')
    credentials = f"{_setting('nzbget_username')}:{_setting('nzbget_password')}"
    auth = base64.b64encode(credentials.encode('utf-8')).decode('ascii')
    payload = json.dumps({
        'jsonrpc': '2.0',
        'id': 'cosmos',
        'method': method,
        'params': params or [],
    }).encode('utf-8')
    request = Request(url, data=payload, headers={
        'Content-Type': 'application/json',
        'Authorization': f'Basic {auth}',
    })
    with urlopen(request, timeout=12) as response:
        result = json.loads(response.read().decode('utf-8', 'replace'))
    if result.get('error'):
        raise RuntimeError(str(result['error'].get('message') or result['error']))
    return result.get('result')


def test_connection():
    """Test the selected downloader without adding a queue item."""
    client = _client_name()
    if not client:
        return False, 'Downloader disabled'
    if not is_configured():
        return False, 'Complete the downloader settings first'
    try:
        if client == 'sabnzbd':
            # Version is public and cannot prove that the API key is accepted.
            result = _sab_call({'mode': 'queue', 'limit': 0})
            if not isinstance(result, dict) or not isinstance(result.get('queue'), dict):
                return False, 'SABnzbd login failed; check API URL and full API key'
            return True, 'SABnzbd authenticated'
        version = _nzbget_call('version')
        if not isinstance(version, str) or not version.strip():
            return False, 'Invalid NZBGet response; check JSON-RPC URL'
        return True, f'NZBGet {version}'
    except HTTPError as exc:
        xbmc.log(f'COSMOS SABnzbd test failed: HTTP {exc.code} at {_sab_url()}', xbmc.LOGWARNING)
        return False, f'{client.upper()} HTTP error {exc.code}; check URL and credentials'
    except (URLError, ValueError, RuntimeError) as exc:
        xbmc.log(f'COSMOS Usenet downloader test failed: {exc}', xbmc.LOGWARNING)
        return False, 'Connection failed; check URL and credentials'
    except Exception as exc:
        xbmc.log(f'COSMOS Usenet downloader test failed unexpectedly: {exc}', xbmc.LOGWARNING)
        return False, 'Connection failed; check downloader settings'


def submit_nzb_url(nzb_url, name='Cosmos', category=''):
    """Submit an NZB URL to the selected downloader.

    The URL is intentionally not accepted unless it is HTTP(S).  In
    particular, Easynews media URLs are not NZB URLs and must not be queued.
    """
    if not _valid_http_url(nzb_url) or not is_configured():
        return False, 'No valid NZB URL or downloader is not configured'
    client = _client_name()
    category = category or '*'
    try:
        if client == 'sabnzbd':
            result = _sab_call({
                'mode': 'addurl',
                'name': nzb_url,
                'nzbname': name or 'Cosmos',
                'cat': category,
            })
            if isinstance(result, dict) and result.get('error'):
                return False, str(result['error'])
            if not isinstance(result, dict) or result.get('status') is not True or not result.get('nzo_ids'):
                return False, 'SABnzbd rejected the NZB'
            return True, 'NZB sent to SABnzbd'

        filename = name or 'Cosmos'
        if not filename.lower().endswith('.nzb'):
            filename += '.nzb'
        job_id = _nzbget_call('append', [filename, nzb_url,
            '' if category == '*' else category, 0, False, False, '', 0, 'SCORE', False, []])
        if type(job_id) is not int or job_id <= 0:
            return False, 'NZBGet rejected the NZB'
        return True, 'NZB sent to NZBGet'
    except (HTTPError, URLError, ValueError, RuntimeError) as exc:
        xbmc.log(f'COSMOS Usenet submit failed: {exc}', xbmc.LOGWARNING)
        return False, 'Downloader rejected the NZB or could not be reached'
    except Exception as exc:
        xbmc.log(f'COSMOS Usenet submit failed unexpectedly: {exc}', xbmc.LOGWARNING)
        return False, 'Unable to send NZB to downloader'


def submit_nzb_data(nzb_data, name='Cosmos', category=''):
    """Submit NZB bytes to the selected downloader."""
    if not isinstance(nzb_data, bytes) or not nzb_data or not is_configured():
        return False, 'Downloader is not configured'
    client = _client_name()
    category = category or '*'
    try:
        if client == 'sabnzbd':
            result = _sab_upload(nzb_data, name, category)
            if isinstance(result, dict) and result.get('error'):
                return False, str(result['error'])
            if not isinstance(result, dict) or result.get('status') is not True or not result.get('nzo_ids'):
                return False, 'SABnzbd rejected the NZB'
            return True, 'NZB sent to SABnzbd'

        encoded = base64.b64encode(nzb_data).decode('ascii')
        filename = name or 'Cosmos'
        if not filename.lower().endswith('.nzb'):
            filename += '.nzb'
        job_id = _nzbget_call('append', [filename, encoded,
            '' if category == '*' else category, 0, False, False, '', 0, 'SCORE', False, []])
        if type(job_id) is not int or job_id <= 0:
            return False, 'NZBGet rejected the NZB'
        return True, 'NZB sent to NZBGet'
    except (HTTPError, URLError, ValueError, RuntimeError) as exc:
        xbmc.log(f'COSMOS Usenet NZB upload failed: {exc}', xbmc.LOGWARNING)
        return False, 'Downloader rejected the NZB or could not be reached'
    except Exception as exc:
        xbmc.log(f'COSMOS Usenet NZB upload failed unexpectedly: {exc}', xbmc.LOGWARNING)
        return False, 'Unable to send NZB to downloader'


def maybe_submit_result(result, name='Cosmos'):
    """Submit a result only when it exposes usable NZB metadata.

    Returns ``(handled, message)``.  ``handled=False`` means the caller
    should continue with its normal direct-playback path.
    """
    if not is_configured():
        return False, ''
    nzb_url = result.get('nzb_url') or result.get('nzbURL') or result.get('nzbUrl')
    display_name = name or result.get('title') or result.get('name') or 'Cosmos'
    category = _setting('usenet_category') or '*'
    if nzb_url:
        return submit_nzb_url(nzb_url, name=display_name, category=category)

    # Easynews exposes search metadata rather than an NZB URL.  Ask its
    # official API for the NZB, then hand the bytes to the configured client.
    if result.get('hash'):
        try:
            from resources.lib.easynews import EasyNews
            nzb_data = EasyNews.download_nzb(result, title=display_name)
            if nzb_data:
                return submit_nzb_data(nzb_data, name=display_name, category=category)
        except Exception as exc:
            xbmc.log(f'COSMOS Easynews NZB generation skipped: {exc}', xbmc.LOGWARNING)
        return False, 'Easynews could not create an NZB; using direct playback'
    return False, 'This result has no NZB data; using direct playback'


def action_test_connection():
    success, message = test_connection()
    xbmcgui.Dialog().notification(
        'Usenet Downloader',
        message,
        xbmcgui.NOTIFICATION_INFO if success else xbmcgui.NOTIFICATION_ERROR,
        4000,
    )
    return success
