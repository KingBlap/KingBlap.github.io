"""VidLove player embed and API resolver for the Vidcore source picker."""
import html
import json
import re
from urllib.parse import urljoin, urlsplit
from urllib.request import Request, urlopen

import xbmc

BASE_URL = 'https://player.vidlove.cc'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': BASE_URL + '/',
           'Accept': 'text/html,application/xhtml+xml,application/json,*/*'}


def embed_url(tmdb_id, content='movie', season=None, episode=None):
    """Build the documented VidLove embed URL."""
    tmdb_id = str(tmdb_id or '').strip()
    if not tmdb_id.isdigit() or int(tmdb_id) < 1:
        return ''
    if content == 'movie':
        return '%s/embed/movie/%s' % (BASE_URL, tmdb_id)
    try:
        season, episode = int(season), int(episode)
    except (TypeError, ValueError):
        return ''
    if season >= 0 and episode > 0:
        return '%s/embed/tv/%s/%s/%s' % (BASE_URL, tmdb_id, season, episode)
    return ''


def _urls(body, page):
    text = html.unescape(body).replace('\\/', '/')
    pattern = r'''(?:https?:)?//[^\s"'<>\\]+?(?:\.m3u8|\.mp4)(?:\?[^\s"'<>\\]*)?'''
    for raw in re.findall(pattern, text, re.I):
        value = urljoin(page, raw)
        if value.startswith(('http://', 'https://')):
            yield value


def _json_urls(value):
    """Yield media URLs from the player API's nested source response."""
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, str) and item.startswith(('http://', 'https://')):
                # VidLove has used url, file, source, link and provider-specific
                # field names. Keep any URL here; verification below rejects
                # posters, pages and non-media responses.
                yield item
            else:
                yield from _json_urls(item)
    elif isinstance(value, list):
        for item in value:
            yield from _json_urls(item)


def resolve(url):
    """Follow the embed's iframe/player layers and verify HLS or MP4 output."""
    parsed = urlsplit(url)
    if parsed.hostname != 'player.vidlove.cc' or not re.fullmatch(
            r'/embed/(?:movie/\d+|tv/\d+/\d+/\d+)', parsed.path):
        return None
    parts = parsed.path.strip('/').split('/')
    if parts[1] == 'movie':
        api_url = 'https://api.vidlove.cc/movie?id=%s&mode=json' % parts[2]
    else:
        api_url = 'https://api.vidlove.cc/tv?id=%s&season=%s&episode=%s&mode=json' % (
            parts[2], parts[3], parts[4])
    queue, seen = [(api_url, BASE_URL + '/')], set()
    while queue and len(seen) < 20:
        page, referer = queue.pop(0)
        if page in seen:
            continue
        seen.add(page)
        try:
            with urlopen(Request(page, headers=dict(HEADERS, Referer=referer)), timeout=15) as response:
                raw_body = response.read()
                body = raw_body.decode('utf-8', errors='replace')
                page = response.geturl()
            try:
                data = json.loads(body)
            except (TypeError, ValueError):
                data = None
            xbmc.log('COSMOS VidLove API response: %s bytes' % len(raw_body), xbmc.LOGINFO)
            source = data.get('source') if isinstance(data, dict) else None
            if not isinstance(source, dict) or not source.get('url'):
                xbmc.log('COSMOS VidLove: API returned no source', xbmc.LOGWARNING)
                return None
            for candidate in [source['url']]:
                try:
                    with urlopen(Request(candidate, headers=HEADERS), timeout=12) as response:
                        sample = response.read(4096)
                        final = response.geturl()
                        content_type = (response.headers.get('Content-Type') or '').lower()
                    if sample.lstrip().startswith(b'#EXTM3U') or 'mpegurl' in content_type:
                        xbmc.log('COSMOS VidLove: verified HLS', xbmc.LOGINFO)
                        return {'url': final, 'type': 'hls', 'headers': dict(HEADERS)}
                    if len(sample) >= 12 and sample[4:8] == b'ftyp':
                        return {'url': final, 'type': 'mp4', 'headers': dict(HEADERS)}
                except Exception as exc:
                    xbmc.log('COSMOS VidLove probe failed: %s status=%s' % (type(exc).__name__, getattr(exc, 'code', '')), xbmc.LOGWARNING)
            return None
            for candidate in _urls(body, page):
                with urlopen(Request(candidate, headers=dict(HEADERS, Referer=page)), timeout=12) as response:
                    sample = response.read(4096)
                    final = response.geturl()
                    content_type = (response.headers.get('Content-Type') or '').lower()
                if sample.lstrip().startswith(b'#EXTM3U') or 'mpegurl' in content_type:
                    return {'url': final, 'type': 'hls', 'headers': {'User-Agent': HEADERS['User-Agent'], 'Referer': page}}
                if len(sample) >= 12 and sample[4:8] == b'ftyp':
                    return {'url': final, 'type': 'mp4', 'headers': {'User-Agent': HEADERS['User-Agent'], 'Referer': page}}
            for raw in re.findall(r'''<(?:iframe|source)[^>]+(?:src|data-src)=['"]([^'"]+)''', body, re.I):
                child = urljoin(page, html.unescape(raw))
                if urlsplit(child).scheme in ('http', 'https'):
                    queue.append((child, page))
        except Exception as exc:
            xbmc.log('COSMOS VidLove resolver failed: %s' % type(exc).__name__, xbmc.LOGWARNING)
    xbmc.log('COSMOS VidLove: no verified media URL returned', xbmc.LOGWARNING)
    return None
