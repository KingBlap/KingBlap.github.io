"""Dedicated LuluStream player resolver. No API key or ResolveURL required."""
import re
import time
from html import unescape
from http.cookiejar import CookieJar
from urllib.parse import urljoin, urlsplit
from urllib.request import Request, build_opener, HTTPCookieProcessor

from . import srstop

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
HOSTS = frozenset(('lulustream.com', 'www.lulustream.com', 'luluvdo.com',
                   'www.luluvdo.com', 'lulust.com', 'www.lulust.com'))
PACKED = re.compile(
    r"eval\(function\(p,a,c,k,e,(?:r|d)\)\{.*?\}\s*\('((?:\\.|[^'\\])*)',"
    r"\s*(\d+)\s*,\s*(\d+)\s*,\s*'((?:\\.|[^'\\])*)'\.split\('\|'\)", re.S)
SOURCE = re.compile(r'''["']?(?:file|src)["']?\s*[:=]\s*(["'])(.*?)\1''', re.I)


def _log(message):
    try:
        import xbmc
        xbmc.log('COSMOS LuluStream: ' + message, xbmc.LOGINFO)
    except Exception:
        pass


def _unescape_js(value):
    # Decode string escapes only; never evaluate the player or its ad scripts.
    value = re.sub(r'\\x([0-9a-fA-F]{2})|\\u([0-9a-fA-F]{4})',
                   lambda m: chr(int(m[1] or m[2], 16)), value)
    return re.sub(r'''\\([\\/'"])''', r'\1', value)


def _unpack(body):
    for match in list(PACKED.finditer(body))[:8]:
        payload, radix, count, table = match.groups()
        radix, count = int(radix), int(count)
        if not 2 <= radix <= 62 or count > 10000:
            continue
        words = table.split('|')
        digits = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        mapping = {}
        for index, word in enumerate(words[:count]):
            if not word:
                continue
            number, token = index, ''
            while number:
                number, digit = divmod(number, radix)
                token = digits[digit] + token
            mapping[token or '0'] = word
        # One substitution pass prevents replacing tokens inside decoded words.
        yield _unescape_js(re.sub(r'\b[0-9A-Za-z]+\b',
                                  lambda m: mapping.get(m[0], m[0]), payload))


def _candidates(body, page_url):
    found = []
    for text in [body] + list(_unpack(body)):
        for match in SOURCE.finditer(text):
            url = urljoin(page_url, unescape(_unescape_js(match[2])))
            parts = urlsplit(url)
            if parts.scheme not in ('http', 'https') or not parts.netloc:
                continue
            path = parts.path.lower()
            kind = 'hls' if '.m3u8' in path else 'dash' if '.mpd' in path else 'mp4' if '.mp4' in path else ''
            if kind and not any(item['url'] == url for item in found):
                found.append({'url': url, 'type': kind})
    return sorted(found, key=lambda item: {'hls': 0, 'dash': 1, 'mp4': 2}[item['type']])


def _timeout(deadline):
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise srstop.SourceError('LuluStream resolution timed out. Please try again.')
    return min(12, remaining)


def _resolve_host_page(url, deadline=None):
    """Decode a host player and return a checked stream with playback headers."""
    deadline = deadline or time.monotonic() + 45
    jar = CookieJar()
    opener = build_opener(HTTPCookieProcessor(jar))
    pages, seen = [(url, srstop.BASE + '/')], set()
    while pages and len(seen) < 3:
        page_url, referer = pages.pop(0)
        if page_url in seen or urlsplit(page_url).hostname not in HOSTS:
            continue
        seen.add(page_url)
        try:
            with opener.open(Request(page_url, headers={'User-Agent': UA, 'Referer': referer}),
                             timeout=_timeout(deadline)) as response:
                final_page = response.geturl()
                body = response.read(2 * 1024 * 1024 + 1)
            if len(body) > 2 * 1024 * 1024 or urlsplit(final_page).hostname not in HOSTS:
                continue
            body = body.decode('utf-8', errors='replace')
            origin = urlsplit(final_page)
            headers = {'User-Agent': UA, 'Referer': final_page,
                       'Origin': origin.scheme + '://' + origin.netloc}
            candidates = _candidates(body, final_page)
            _log('player decoded (%d media candidates)' % len(candidates))
            for candidate in candidates:
                try:
                    request = Request(candidate['url'], headers=headers)
                    jar.add_cookie_header(request)
                    with opener.open(request, timeout=_timeout(deadline)) as response:
                        sample = response.read(16384)
                        stream_url = response.geturl()
                    kind = candidate['type']
                    valid = (sample.lstrip().startswith(b'#EXTM3U') if kind == 'hls'
                             else b'<MPD' in sample if kind == 'dash'
                             else sample[4:8] == b'ftyp')
                    if not valid:
                        continue
                    playback_headers = dict(headers)
                    # Only forward cookies applicable to the final media URL.
                    media_request = Request(stream_url)
                    jar.add_cookie_header(media_request)
                    cookie = media_request.get_header('Cookie')
                    if cookie:
                        playback_headers['Cookie'] = cookie
                    _log('resolved verified %s stream' % kind)
                    return {'url': stream_url, 'type': kind, 'headers': playback_headers}
                except Exception as exc:
                    _log('candidate failed (%s)' % type(exc).__name__)
            for frame in re.findall(r'''<iframe\b[^>]*\bsrc\s*=\s*["']([^"']+)''', body, re.I):
                target = urljoin(final_page, unescape(frame))
                if urlsplit(target).scheme in ('http', 'https') and urlsplit(target).hostname in HOSTS:
                    pages.append((target, final_page))
        except Exception as exc:
            _log('player request failed (%s)' % type(exc).__name__)
    return None


def resolve(tmdb_id, season, episode):
    from . import tmdb
    try:
        links = srstop.discover_lulustream(tmdb.get_metadata(tmdb_id, 'tv'), season, episode)
        deadline = time.monotonic() + 60
        for link in links:
            if time.monotonic() >= deadline:
                break
            stream = _resolve_host_page(link['url'], deadline)
            if stream:
                return stream
        return {'error': 'No playable LuluStream stream was found for this episode. Try another source or try again later.'}
    except srstop.SourceError as exc:
        return {'error': str(exc)}
    except Exception as exc:
        _log('resolution failed (%s)' % type(exc).__name__)
        return {'error': 'SRStop / LuluStream could not resolve this episode. Please try again.'}
