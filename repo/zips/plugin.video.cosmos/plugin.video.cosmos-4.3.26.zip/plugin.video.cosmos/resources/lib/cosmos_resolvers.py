# -*- coding: utf-8 -*-
"""Built-in fallback resolvers for C.O.S.M.O.S.

ResolveURL (script.module.resolveurl) is the primary path, but its host
patterns lag behind the mirror-domain churn used by free file hosts
(mixdrop.top, d000d.com, dood.li, streamwish.cx, etc.). When ResolveURL
returns nothing we try these light-weight, regex-based resolvers as a
fallback.  No external dependencies — only urllib + re.

Each resolver returns a playable URL (mp4 / m3u8) or ``None``.
The returned URL may include a ``|`` followed by request headers
(Kodi inputstream syntax).
"""
import re
import json
import base64
from html import unescape
from urllib.parse import (unquote, urlparse, urlunparse, urljoin, urlencode,
                          parse_qs)
from urllib.request import urlopen, Request
from urllib.error import HTTPError, URLError

import xbmc

from .aesgcm import aes_gcm_decrypt
from . import mega_proxy

# Debug bundler — optional; no-ops gracefully when disabled or not installed
try:
    from . import debug_bundle as _db
    def _dblog(tag, detail): _db.log(tag, detail)
except Exception:
    def _dblog(tag, detail): pass

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')

# Failure reason for the last resolve() call.  Set to 'removed' when a
# resolver can confirm the content has been deleted/taken down by the host
# (e.g. Dailymotion "removed due to Terms of Use").  filehost.py reads this
# to show a more informative toast instead of the generic "Could not resolve
# link" message.  Always reset to '' at the start of each resolve() call.
_last_resolver_error = ''


def _post(url, data, referer=None, timeout=20, extra_headers=None):
    """POST form-data to *url*. *data* is a dict encoded as application/x-www-form-urlencoded."""
    from urllib.parse import urlencode as _urlencode
    headers = {
        'User-Agent': UA,
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Requested-With': 'XMLHttpRequest',
    }
    if referer:
        headers['Referer'] = referer
        p = urlparse(referer)
        if p.netloc:
            headers['Origin'] = f'{p.scheme}://{p.netloc}'
    if extra_headers:
        headers.update(extra_headers)
    post_data = _urlencode(data).encode('utf-8') if isinstance(data, dict) else data
    short_data = (data if isinstance(data, str) else str(data))[:120]
    _dblog('POST→', f'{url}  data={short_data}')
    try:
        req = Request(url, data=post_data, headers=headers)
        with urlopen(req, timeout=timeout) as r:
            body = r.read().decode('utf-8', errors='replace')
            _dblog('POST←', f'{len(body)}B  preview={body[:200]}')
            return body, r.url
    except (HTTPError, URLError) as e:
        xbmc.log(f'COSMOS resolver POST failed {url}: {e}', xbmc.LOGWARNING)
        _dblog('POST-FAIL', f'{url}  error={e}')
        return '', url


def _post_json(url, data, referer=None, timeout=20):
    """POST a JSON payload to a resolver API and return ``(body, url)``."""
    headers = {
        'User-Agent': UA,
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/json',
    }
    if referer:
        headers['Referer'] = referer
        p = urlparse(referer)
        if p.netloc:
            headers['Origin'] = f'{p.scheme}://{p.netloc}'
    try:
        req = Request(url, data=json.dumps(data).encode('utf-8'),
                      headers=headers)
        with urlopen(req, timeout=timeout) as r:
            return r.read().decode('utf-8', errors='replace'), r.url
    except (HTTPError, URLError) as e:
        xbmc.log(f'COSMOS resolver JSON POST failed {url}: {e}', xbmc.LOGWARNING)
        return '', url
    except Exception as e:
        xbmc.log(f'COSMOS resolver JSON POST error {url}: {e}', xbmc.LOGERROR)
        return '', url
    except Exception as e:
        xbmc.log(f'COSMOS resolver POST error {url}: {e}', xbmc.LOGERROR)
        _dblog('POST-ERR', f'{url}  error={e}')
        return '', url


def _fetch(url, referer=None, timeout=20, extra_headers=None):
    headers = {
        'User-Agent': UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
    }
    if referer:
        headers['Referer'] = referer
    if extra_headers:
        headers.update(extra_headers)
    _dblog('GET→', url)
    try:
        req = Request(url, headers=headers)
        with urlopen(req, timeout=timeout) as r:
            body = r.read().decode('utf-8', errors='replace')
            _dblog('GET←', f'{len(body)}B  final={r.url}')
            return body, r.url
    except (HTTPError, URLError) as e:
        xbmc.log(f'COSMOS resolver fetch failed {url}: {e}', xbmc.LOGWARNING)
        _dblog('GET-FAIL', f'{url}  error={e}')
        return '', url
    except Exception as e:
        xbmc.log(f'COSMOS resolver fetch error {url}: {e}', xbmc.LOGERROR)
        _dblog('GET-ERR', f'{url}  error={e}')
        return '', url


# ── Packed JS unpacker (Dean Edwards p,a,c,k,e,d) ─────────────────────────
_PACKED_RE = re.compile(
    r"eval\(function\(p,a,c,k,e,(?:r|d)\)\{.*?\}\s*\('(.*?)',\s*(\d+)\s*,"
    r"\s*(\d+)\s*,\s*'(.*?)'\.split\('\|'\)",
    re.DOTALL,
)


def _unpack(packed_js):
    """Unpack a Dean Edwards p.a.c.k.e.r packed JS payload."""
    m = _PACKED_RE.search(packed_js)
    if not m:
        return ''
    payload, _radix, _count, symtab = m.groups()
    radix = int(_radix)
    count = int(_count)
    words = symtab.split('|')

    def _b(n):
        # base36+ encoder – mirrors the JS p,a,c,k,e,d encoder.
        digits = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        if n == 0:
            return '0'
        r = []
        num = n
        while num:
            num, d = divmod(num, radix)
            r.append(digits[d])
        return ''.join(reversed(r))

    out = payload
    # Replace word tokens — must process longer first to avoid prefix collisions.
    for i in range(count - 1, -1, -1):
        sym = _b(i)
        if not sym:
            continue
        word = words[i] if i < len(words) else ''
        if word == '':
            continue
        out = re.sub(r'\b' + re.escape(sym) + r'\b', word, out)
    # Decode escapes
    out = out.replace('\\\\', '\\').replace("\\'", "'").replace('\\"', '"')
    return out


# ── Mixdrop ───────────────────────────────────────────────────────────────
# All mirrors share the same /e/<id> embed and the same packed JS player.
# Common mirrors (2024-2026): .co .to .club .top .gl .cv .my .ag .ps .sx
_MIXDROP_HOSTS = (
    'mixdrop.co', 'mixdrop.to', 'mixdrop.club', 'mixdrop.top', 'mixdrop.gl',
    'mixdrop.cv', 'mixdrop.my', 'mixdrop.ag', 'mixdrop.ps', 'mixdrop.sx',
    'mixdrop.bz', 'mixdrop.is', 'mixdrop.lol', 'mixdrop.si', 'mixdrop.live',
)

_MIXDROP_DIRECT_RE = re.compile(r'wurl\s*=\s*[\'"]([^\'"]+)[\'"]')


def _is_mixdrop(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h.startswith('mixdrop.')


def resolve_mixdrop(url):
    """Resolve a mixdrop /e/ID or /f/ID URL to a direct mp4."""
    parsed = urlparse(url)
    # Force /e/ embed path (some inputs come as /f/ download page)
    path = parsed.path or '/'
    m = re.search(r'/(?:e|f)/([A-Za-z0-9_\-]+)', path)
    if not m:
        return None
    vid = m.group(1)

    # Try active mirrors in order, starting with the one in the input URL.
    primary = (parsed.netloc or 'mixdrop.co').lower().replace('www.', '')
    candidates = [primary] + [h for h in _MIXDROP_HOSTS if h != primary]

    for host in candidates:
        embed = f'https://{host}/e/{vid}'
        html, _ = _fetch(embed, referer=f'https://{host}/')
        if not html:
            continue
        unpacked = _unpack(html) or html
        m2 = _MIXDROP_DIRECT_RE.search(unpacked)
        if not m2:
            # fallback — direct .mp4 with ?s=… inside the HTML
            m2 = re.search(r'(https?:)?(//[^\s\'"<>]+\.mp4[^\s\'"<>]*)', unpacked)
            if m2:
                stream = m2.group(0)
                if stream.startswith('//'):
                    stream = 'https:' + stream
                return f'{stream}|User-Agent={UA}&Referer={embed}'
            continue
        stream = m2.group(1)
        if stream.startswith('//'):
            stream = 'https:' + stream
        elif stream.startswith('/'):
            stream = f'https://{host}{stream}'
        return f'{stream}|User-Agent={UA}&Referer={embed}'
    return None


# ── Doodstream / d000d / dood-mirror ──────────────────────────────────────
def _is_doodstream(url):
    from .doodstream import is_url
    return is_url(url)


def resolve_doodstream(url):
    """Use the checked DoodStream/Playmogo resolver for generic host links too."""
    from .doodstream import _resolve_host_page
    try:
        stream = _resolve_host_page(url)
    except Exception:
        return None
    if not stream:
        return None
    return stream['url'] + '|' + urlencode(stream.get('headers') or {})


# ── Streamtape ────────────────────────────────────────────────────────────
def _is_streamtape(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h.startswith('streamtape.') or h.startswith('streamta.pe') or \
        h.startswith('shavetape.') or h.startswith('strcloud.') or \
        h.startswith('strtape.') or h.startswith('streamadblocker.')


def _streamtape_expression(expression):
    """Decode only string concatenation and numeric substring/slice calls."""
    rest, chunks = expression.strip(), []
    while rest:
        wrapped = rest.startswith('(')
        if wrapped:
            rest = rest[1:].lstrip()
        match = re.match(r"""(["'])((?:\\.|(?!\1).)*)\1""", rest, re.S)
        if not match:
            return ''
        value = re.sub(r'\\([/\\\x27"])', r'\1', match[2])
        rest = rest[match.end():].lstrip()
        if wrapped:
            if not rest.startswith(')'):
                return ''
            rest = rest[1:].lstrip()
        while rest.startswith('.'):
            operation = re.match(r'\.(?:substring|slice)\(\s*(\d+)\s*\)', rest)
            if not operation:
                return ''
            value = value[int(operation[1]):]
            rest = rest[operation.end():].lstrip()
        chunks.append(value)
        if not rest:
            break
        if not rest.startswith('+'):
            return ''
        rest = rest[1:].lstrip()
        if not rest:
            return ''
    return unescape(''.join(chunks))


def _streamtape_media_url(body):
    # Later assignments replace earlier decoy values. Do not execute page JS.
    assignments = re.findall(
        r"""document\.getElementById\(\s*['"](?:robotlink|ideoolink|videolink|botlink)['"]\s*\)\.innerHTML\s*=\s*([^;]+);""",
        body)
    for expression in reversed(assignments):
        value = _streamtape_expression(expression)
        if value.startswith('//'):
            value = 'https:' + value
        parts = urlparse(value)
        if (parts.scheme in ('http', 'https') and _is_streamtape(value)
                and parts.path == '/get_video' and parse_qs(parts.query).get('id')
                and parse_qs(parts.query).get('token')):
            if 'stream' not in parse_qs(parts.query):
                value += '&stream=1'
            return value
    return None


def resolve_streamtape(url):
    global _last_resolver_error
    _last_resolver_error = ''
    parsed = urlparse(url)
    path = parsed.path or '/'
    m = re.search(r'/(?:e|v|embed)/([A-Za-z0-9_\-]+)', path, re.I)
    if not m:
        return None
    vid = m.group(1)
    host = parsed.netloc
    embed = f'https://{host}/e/{vid}'
    try:
        with urlopen(Request(embed, headers={'User-Agent': UA,
                                             'Referer': f'https://{host}/'}),
                     timeout=12) as response:
            html = response.read(2 * 1024 * 1024 + 1).decode('utf-8', errors='replace')
            embed = response.geturl()
    except HTTPError as exc:
        if exc.code in (404, 410):
            _last_resolver_error = 'removed'
        return None
    except (URLError, OSError):
        return None
    if not html:
        return None
    if re.search(r'Video\s+(?:not found|has been (?:removed|deleted))', html, re.I):
        _last_resolver_error = 'removed'
        return None
    media = _streamtape_media_url(html)
    if media:
        return media + '|' + urlencode({'User-Agent': UA, 'Referer': embed})
    return None


# ── EmbedWish / StreamWish family ────────────────────────────────────────
def _is_embedwish(url):
    try:
        parsed = urlparse(url or '')
        host = (parsed.netloc or '').lower().replace('www.', '')
        return host == 'embedwish.com' and (parsed.path or '/') != '/'
    except ValueError:
        return False


def _embedwish_id(url):
    path = (urlparse(url or '').path or '').rstrip('/')
    match = re.search(r'/(?:e|f)/([A-Za-z0-9_-]+)$', path, re.IGNORECASE)
    if match:
        return match.group(1)
    match = re.search(r'/([A-Za-z0-9_-]+)$', path)
    return match.group(1) if match else ''


def _embedwish_stream(value, base_url):
    """Normalize an EmbedWish source value and reject non-media URLs."""
    value = unescape((value or '').strip())
    value = (value.replace('\\/', '/')
                  .replace('\\u0026', '&')
                  .replace('\\x26', '&'))
    if value.startswith('//'):
        value = 'https:' + value
    elif value.startswith('/'):
        value = urljoin(base_url, value)
    if not value.startswith(('http://', 'https://')):
        return None
    parsed = urlparse(value)
    path = (parsed.path or '').lower()
    if not ('.m3u8' in path or '.mp4' in path or
            any(token in path for token in ('/hls/', '/playlist/', '/stream/'))):
        return None
    return value


_EMBEDWISH_ASSIGN_RE = re.compile(
    r'(?:file|src|source|stream|url)\s*[:=]\s*["\']([^"\']+)["\']',
    re.IGNORECASE,
)
_EMBEDWISH_DIRECT_RE = re.compile(
    r'https?://[^\s"\'<>]+(?:\.m3u8|\.mp4)(?:\?[^\s"\'<>]*)?',
    re.IGNORECASE,
)


def _embedwish_find_stream(text, base_url):
    if not text:
        return None
    normalized = (text.replace('\\/', '/')
                       .replace('\\u0026', '&')
                       .replace('\\x26', '&'))
    # Prefer player configuration fields, then fall back to any direct media
    # URL left in the page or unpacked script.
    for match in _EMBEDWISH_ASSIGN_RE.finditer(normalized):
        stream = _embedwish_stream(match.group(1), base_url)
        if stream:
            return stream
    for match in _EMBEDWISH_DIRECT_RE.finditer(normalized):
        stream = _embedwish_stream(match.group(0), base_url)
        if stream:
            return stream
    return None


def resolve_embedwish(url):
    """Resolve an EmbedWish ``/e/<id>`` page to a direct MP4/HLS stream."""
    video_id = _embedwish_id(url)
    if not video_id:
        xbmc.log(f'COSMOS embedwish: no video id in {url}', xbmc.LOGWARNING)
        return None

    origin = 'https://embedwish.com'
    pages = [f'{origin}/{video_id}', f'{origin}/e/{video_id}']
    seen = set()
    for page in pages:
        if page in seen:
            continue
        seen.add(page)
        html, final = _fetch(page, referer=f'{origin}/')
        if not html:
            continue
        if re.search(r'file is no longer available|expired|deleted', html,
                     re.IGNORECASE):
            xbmc.log(f'COSMOS embedwish: file expired or deleted for {url}',
                     xbmc.LOGWARNING)
            continue
        unpacked = _unpack(html)
        for text in (unpacked, html):
            stream = _embedwish_find_stream(text, final or page)
            if stream:
                xbmc.log(f'COSMOS embedwish: stream found for {url}', xbmc.LOGINFO)
                _dblog('EMBEDWISH-OK', stream[:160])
                return f'{stream}|User-Agent={UA}&Referer={final or page}'

    xbmc.log(f'COSMOS embedwish: no MP4/HLS source found for {url}',
             xbmc.LOGWARNING)
    return None


# ── ok.ru ─────────────────────────────────────────────────────────────────
def _is_okru(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h in ('ok.ru', 'odnoklassniki.ru')

def resolve_okru(url):
    """Resolve ok.ru video → highest quality mp4."""
    parsed = urlparse(url)
    host = parsed.netloc.replace('www.', '') or 'ok.ru'
    origin = f'https://{host}'

    xbmc.log(f'COSMOS okru: fetching HTML for {url}', xbmc.LOGINFO)
    html, _ = _fetch(url, referer=f'{origin}/')
    
    if not html:
        xbmc.log(f'COSMOS okru: fetch failed or returned empty HTML for {url}', xbmc.LOGWARNING)
        return None
        
    m = re.search(r'data-options="([^"]+)"', html)
    if not m:
        xbmc.log(f'COSMOS okru: data-options not found in HTML for {url}', xbmc.LOGWARNING)
        return None
        
    raw = m.group(1).replace('&quot;', '"').replace('&amp;', '&')
    try:
        cfg = json.loads(raw)
        flash = json.loads(cfg.get('flashvars', {}).get('metadata', '{}'))
    except (ValueError, AttributeError, TypeError) as e:
        xbmc.log(f'COSMOS okru: JSON parse failed for {url}: {e}', xbmc.LOGWARNING)
        return None
        
    urls = flash.get('videos', []) or []
    if not urls:
        xbmc.log(f'COSMOS okru: no videos found in metadata for {url}', xbmc.LOGWARNING)
        return None

    quality_order = ['full', 'hd', 'sd', 'low', 'lowest', 'mobile']
    urls.sort(key=lambda v: quality_order.index(v.get('name', 'lowest'))
              if v.get('name', 'lowest') in quality_order else 99)
              
    stream = urls[0].get('url')
    if stream:
        xbmc.log(f'COSMOS okru: stream found → {stream[:80]} for {url}', xbmc.LOGINFO)
        return (f"{stream}"
                f"|User-Agent={UA}"
                f"&Referer={origin}/"
                f"&Origin={origin}")
                
    xbmc.log(f'COSMOS okru: stream extraction failed for {url}', xbmc.LOGWARNING)
    return None

# ── soccerfull.net ─────────────────────────────────────────────────────────
# /play/<id> pages embed an Artplayer instance pointed at a same-origin
# HLS manifest: ``var m3u8Url ="/hls/<id>.m3u8";``. No ResolveURL plugin
# covers this host, so we extract the manifest path directly.
def _is_soccerfull(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h == 'soccerfull.net'


_SOCCERFULL_M3U8_RE = re.compile(
    r'm3u8Url\s*=\s*["\'](?P<path>[^"\']+\.m3u8[^"\']*)["\']',
    re.IGNORECASE,
)


def resolve_soccerfull(url):
    """Resolve a soccerfull.net /play/<id> page to its HLS manifest."""
    html, final = _fetch(url, referer='https://soccerfull.net/')
    if not html:
        return None
    m = _SOCCERFULL_M3U8_RE.search(html)
    if not m:
        return None
    manifest = urljoin(final or url, m.group('path'))
    # Use the specific page URL as Referer, keep Origin as base domain.
    return (f'{manifest}'
            f'|User-Agent={UA}'
            f'&Referer={url}'
            f'&Origin=https://soccerfull.net')


# ── thematchrecap.xyz ──────────────────────────────────────────────────────
# Similar to soccerfull.net, these pages embed a video player that points
# to an HLS manifest or a direct MP4. We extract the stream URL directly.
def _is_thematchrecap(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h == 'thematchrecap.xyz'


_THEMATCHRECAP_VIDEO_RE = re.compile(
    r'(?:file|src|url|videoUrl|sourceUrl|streamUrl)\s*[:=]\s*["\'](?P<path>(?:https?:)?//[^"\']+\.(?:m3u8|mp4)[^"\']*)["\']',
    re.IGNORECASE,
)
_THEMATCHRECAP_EMBED_RE = re.compile(
    r'data-embed\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)


def _thematchrecap_embeds(html, base_url):
    """Decode static data-embed iframes from a MatchRecap replay page."""
    for match in _THEMATCHRECAP_EMBED_RE.finditer(html or ''):
        try:
            encoded = unescape(match.group(1))
            padding = '=' * (-len(encoded) % 4)
            decoded = base64.urlsafe_b64decode(
                (encoded + padding).encode('ascii')).decode('utf-8', 'replace')
        except (ValueError, TypeError, UnicodeError, base64.binascii.Error):
            _dblog('THEMATCHRECAP-EMBED-FAIL', 'base64 decode failed')
            continue
        iframe = re.search(
            r'<iframe[^>]+\bsrc\s*=\s*["\']([^"\']+)["\']',
            decoded, re.IGNORECASE)
        if not iframe:
            continue
        child = urljoin(base_url, unescape(iframe.group(1).strip()))
        # Only hand off to resolver families already implemented by Cosmos.
        if (_is_mixdrop(child) or _is_streamtape(child) or
                _is_doodstream(child) or _is_embedwish(child)):
            yield child


def resolve_thematchrecap(url):
    """Resolve a thematchrecap.xyz page to its HLS or MP4 stream."""
    html, final = _fetch(url, referer='https://thematchrecap.xyz/')
    if not html:
        xbmc.log(f'COSMOS thematchrecap: fetch failed or returned empty HTML for {url}', xbmc.LOGWARNING)
        return None
    m = _THEMATCHRECAP_VIDEO_RE.search(html)
    if m:
        stream_url = m.group('path') if 'path' in m.groupdict() else m.group(1)
        if stream_url.startswith('//'):
            stream_url = 'https:' + stream_url
        elif not stream_url.startswith('http'):
            stream_url = urljoin(final or url, stream_url)
        return (f'{stream_url}'
                f'|User-Agent={UA}'
                f'&Referer={url}'
                f'&Origin=https://thematchrecap.xyz')

    # Current pages store their player iframe as base64 in data-embed.
    # Resolve recognized child hosts through their existing native handlers.
    for child in _thematchrecap_embeds(html, final or url):
        xbmc.log(f'COSMOS thematchrecap: trying embedded player {child}',
                 xbmc.LOGINFO)
        _dblog('THEMATCHRECAP-EMBED', child)
        if _is_mixdrop(child):
            child_result = resolve_mixdrop(child)
        elif _is_streamtape(child):
            child_result = resolve_streamtape(child)
        elif _is_doodstream(child):
            child_result = resolve_doodstream(child)
        else:
            child_result = resolve_embedwish(child)
        if child_result:
            _dblog('THEMATCHRECAP-CHILD-OK', child)
            return child_result
        _dblog('THEMATCHRECAP-CHILD-NONE', child)

    xbmc.log(f'COSMOS thematchrecap: primary and embedded player scans failed for {url}', xbmc.LOGWARNING)
    return None

# ── StreamHD247 / shd247.world ────────────────────────────────────────────
# StreamHD247 pages are a small wrapper chain: the public page points to a
# same-site source page, which embeds obplay.live. The obplay player exposes
# its current HLS URL in a static ``streamUrls``/``streamUrl`` assignment.
# Read only those assignments; do not execute the page's JavaScript or follow
# unrelated advertising frames.
def _is_streamhd247(url):
    try:
        host = (urlparse(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return host in ('shd247.world', 'www.shd247.world',
                    'shd247.site', 'www.shd247.site')


_STREAMHD247_IFRAME_RE = re.compile(
    r'<iframe[^>]+\bsrc\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
_STREAMHD247_STREAM_RE = re.compile(
    r'(?:streamUrls\s*=\s*\[[^\]]*?|streamUrl\s*=\s*)'
    r'["\']((?:https?:)?(?:/{2}|(?:\\?/){2})[^"\']+\.(?:m3u8|mp4)'
    r'(?:\?[^"\']*)?)["\']',
    re.IGNORECASE | re.DOTALL)
_STREAMHD247_DIRECT_RE = re.compile(
    r'((?:https?:)?(?:/{2}|(?:\\?/){2})[^\s"\'<>\\]+\.(?:m3u8|mp4)'
    r'(?:\?[^\s"\'<>\\]*)?)',
    re.IGNORECASE)


def _streamhd247_clean(value, base_url):
    value = unescape((value or '').strip())
    value = value.replace('\\/', '/').replace('\\u0026', '&')
    if value.startswith('//'):
        value = 'https:' + value
    return urljoin(base_url, value)


def resolve_streamhd247(url):
    """Resolve a StreamHD247 page to the HLS stream exposed by obplay."""
    allowed_hosts = {'shd247.world', 'www.shd247.world', 'shd247.site',
                     'www.shd247.site', 'obplay.live', 'www.obplay.live'}
    queue = [(url, url, 0)]
    seen = set()

    while queue:
        current, referer, depth = queue.pop(0)
        if current in seen or depth > 2:
            continue
        seen.add(current)
        try:
            host = (urlparse(current).hostname or '').lower().rstrip('.')
        except ValueError:
            continue
        if host not in allowed_hosts:
            _dblog('STREAMHD247-SKIP', f'blocked child host={host}')
            continue

        html, final = _fetch(current, referer=referer, timeout=20)
        if not html:
            _dblog('STREAMHD247-FETCH-FAIL', current)
            continue
        _dblog('STREAMHD247-FETCH', f'{current} {len(html)}B')

        candidates = []
        for match in _STREAMHD247_STREAM_RE.finditer(html):
            candidates.append(_streamhd247_clean(match.group(1), final or current))
        if not candidates:
            candidates.extend(
                _streamhd247_clean(match.group(1), final or current)
                for match in _STREAMHD247_DIRECT_RE.finditer(html))

        for stream in candidates:
            if not stream.lower().split('?', 1)[0].endswith(('.m3u8', '.mp4')):
                continue
            page = urlparse(current)
            origin = f'{page.scheme}://{page.netloc}' if page.netloc else ''
            xbmc.log(f'COSMOS streamhd247: stream found for {url}', xbmc.LOGINFO)
            _dblog('STREAMHD247-OK', f'{stream[:120]} referer={current}')
            headers = f'|User-Agent={UA}&Referer={current}'
            if origin:
                headers += f'&Origin={origin}'
            return stream + headers

        if depth >= 2:
            continue
        for match in _STREAMHD247_IFRAME_RE.finditer(html):
            child = _streamhd247_clean(match.group(1), final or current)
            child_host = (urlparse(child).hostname or '').lower().rstrip('.')
            if child_host in allowed_hosts:
                queue.append((child, current, depth + 1))

    xbmc.log(f'COSMOS streamhd247: no static playable stream found for {url}',
             xbmc.LOGWARNING)
    _dblog('STREAMHD247-NONE', 'no static HLS/MP4 URL')
    return None


# ── Ripplestream / rippleplays ────────────────────────────────────────────
# Ripplestream pages use a bounded wrapper chain and the final player stores
# its HLS URL in window.atob('...'). Decode only URL-shaped media values and
# follow only the known player hosts; never execute the page JavaScript.
def _is_ripplestream(url):
    try:
        host = (urlparse(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return host in ('ripplestream.cyou', 'www.ripplestream.cyou',
                    'rippleplays.cfd', 'www.rippleplays.cfd',
                    'hamis.romponalis.st', 'www.hamis.romponalis.st')


_RIPPLE_IFRAME_RE = re.compile(
    r'<iframe[^>]+\bsrc\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
_RIPPLE_ATOB_RE = re.compile(
    r'(?:window\.)?atob\s*\(\s*["\']([A-Za-z0-9+/=_-]+)["\']\s*\)',
    re.IGNORECASE)
_RIPPLE_DIRECT_RE = re.compile(
    r'((?:https?:)?(?:/{2}|(?:\\?/){2})[^\s"\'<>\\]+\.(?:m3u8|mp4)'
    r'(?:\?[^\s"\'<>\\]*)?)', re.IGNORECASE)


def _ripple_clean(value, base_url):
    value = unescape((value or '').strip())
    value = value.replace('\\/', '/').replace('\\u0026', '&')
    if value.startswith('//'):
        value = 'https:' + value
    return urljoin(base_url, value)


def resolve_ripplestream(url):
    """Resolve Ripplestream wrapper pages to their current HLS stream."""
    allowed_hosts = {
        'ripplestream.cyou', 'www.ripplestream.cyou',
        'rippleplays.cfd', 'www.rippleplays.cfd',
        'hamis.romponalis.st', 'www.hamis.romponalis.st',
    }
    queue = [(url, url, 0)]
    seen = set()

    while queue:
        current, referer, depth = queue.pop(0)
        if current in seen or depth > 3:
            continue
        seen.add(current)
        host = (urlparse(current).hostname or '').lower().rstrip('.')
        if host not in allowed_hosts:
            _dblog('RIPPLE-SKIP', f'blocked child host={host}')
            continue

        html, final = _fetch(current, referer=referer, timeout=25)
        if not html:
            _dblog('RIPPLE-FETCH-FAIL', current)
            continue
        page_url = final or current
        _dblog('RIPPLE-FETCH', f'{current} {len(html)}B')

        candidates = []
        for match in _RIPPLE_ATOB_RE.finditer(html):
            try:
                encoded = match.group(1)
                padding = '=' * (-len(encoded) % 4)
                decoded = base64.urlsafe_b64decode(
                    (encoded + padding).encode('ascii')).decode('utf-8', 'replace')
            except (ValueError, TypeError, UnicodeError, base64.binascii.Error):
                continue
            if decoded.startswith(('http://', 'https://', '//')):
                candidates.append(_ripple_clean(decoded, page_url))
        candidates.extend(
            _ripple_clean(match.group(1), page_url)
            for match in _RIPPLE_DIRECT_RE.finditer(html))

        for stream in candidates:
            if not stream.lower().split('?', 1)[0].endswith(('.m3u8', '.mp4')):
                continue
            page = urlparse(page_url)
            origin = f'{page.scheme}://{page.netloc}' if page.netloc else ''
            xbmc.log(f'COSMOS ripplestream: stream found for {url}', xbmc.LOGINFO)
            _dblog('RIPPLE-OK', f'{stream[:120]} referer={page_url}')
            headers = f'|User-Agent={UA}&Referer={page_url}'
            if origin:
                headers += f'&Origin={origin}'
            return stream + headers

        if depth >= 3:
            continue
        for match in _RIPPLE_IFRAME_RE.finditer(html):
            child = _ripple_clean(match.group(1), page_url)
            child_host = (urlparse(child).hostname or '').lower().rstrip('.')
            if child_host in allowed_hosts:
                queue.append((child, page_url, depth + 1))

    xbmc.log(f'COSMOS ripplestream: no static playable stream found for {url}',
             xbmc.LOGWARNING)
    _dblog('RIPPLE-NONE', 'no static HLS/MP4 URL')
    return None

# ── ProStreams / prostreams.best ─────────────────────────────────────────
# ProStreams uses the same style of bounded wrapper chain as Ripplestream,
# but has its own outer and relay pages. Keep it as a separate resolver so
# diagnostics identify the source site correctly.
def _is_prostreams(url):
    try:
        host = (urlparse(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return host in ('prostreams.best', 'www.prostreams.best',
                    'prostreams.shop', 'www.prostreams.shop')


def resolve_prostreams(url):
    """Resolve ProStreams wrapper pages to their current HLS stream."""
    allowed_hosts = {
        'prostreams.best', 'www.prostreams.best',
        'prostreams.shop', 'www.prostreams.shop',
        'hamis.romponalis.st', 'www.hamis.romponalis.st',
    }
    queue = [(url, url, 0)]
    seen = set()

    while queue:
        current, referer, depth = queue.pop(0)
        if current in seen or depth > 3:
            continue
        seen.add(current)
        host = (urlparse(current).hostname or '').lower().rstrip('.')
        if host not in allowed_hosts:
            _dblog('PROSTREAMS-SKIP', f'blocked child host={host}')
            continue

        html, final = _fetch(current, referer=referer, timeout=30)
        if not html:
            _dblog('PROSTREAMS-FETCH-FAIL', current)
            continue
        page_url = final or current
        _dblog('PROSTREAMS-FETCH', f'{current} {len(html)}B')

        candidates = []
        for match in _RIPPLE_ATOB_RE.finditer(html):
            try:
                encoded = match.group(1)
                padding = '=' * (-len(encoded) % 4)
                decoded = base64.urlsafe_b64decode(
                    (encoded + padding).encode('ascii')).decode('utf-8', 'replace')
            except (ValueError, TypeError, UnicodeError, base64.binascii.Error):
                _dblog('PROSTREAMS-ATOB-FAIL', current)
                continue
            if decoded.startswith(('http://', 'https://', '//')):
                candidates.append(_ripple_clean(decoded, page_url))
        candidates.extend(
            _ripple_clean(match.group(1), page_url)
            for match in _RIPPLE_DIRECT_RE.finditer(html))

        for stream in candidates:
            if not stream.lower().split('?', 1)[0].endswith(('.m3u8', '.mp4')):
                continue
            page = urlparse(page_url)
            origin = f'{page.scheme}://{page.netloc}' if page.netloc else ''
            xbmc.log(f'COSMOS prostreams: stream found for {url}', xbmc.LOGINFO)
            _dblog('PROSTREAMS-OK', f'{stream[:120]} referer={page_url}')
            headers = f'|User-Agent={UA}&Referer={page_url}'
            if origin:
                headers += f'&Origin={origin}'
            return stream + headers

        if depth >= 3:
            continue
        for match in _RIPPLE_IFRAME_RE.finditer(html):
            child = _ripple_clean(match.group(1), page_url)
            child_host = (urlparse(child).hostname or '').lower().rstrip('.')
            if child_host in allowed_hosts:
                queue.append((child, page_url, depth + 1))

    xbmc.log(f'COSMOS prostreams: no static playable stream found for {url}',
             xbmc.LOGWARNING)
    _dblog('PROSTREAMS-NONE', 'no static HLS/MP4 URL')
    return None


# ── Streamsify / streamsify.xyz ──────────────────────────────────────────
def _is_streamsify(url):
    try:
        host = (urlparse(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return host in ('streamsify.xyz', 'www.streamsify.xyz',
                    'streamify.cfd', 'www.streamify.cfd')


def resolve_streamsify(url):
    """Resolve Streamsify wrapper pages to their current HLS stream."""
    allowed_hosts = {
        'streamsify.xyz', 'www.streamsify.xyz',
        'streamify.cfd', 'www.streamify.cfd',
        'hamis.romponalis.st', 'www.hamis.romponalis.st',
    }
    queue = [(url, url, 0)]
    seen = set()

    while queue:
        current, referer, depth = queue.pop(0)
        if current in seen or depth > 3:
            continue
        seen.add(current)
        host = (urlparse(current).hostname or '').lower().rstrip('.')
        if host not in allowed_hosts:
            _dblog('STREAMSIFY-SKIP', f'blocked child host={host}')
            continue

        html, final = _fetch(current, referer=referer, timeout=30)
        if not html:
            _dblog('STREAMSIFY-FETCH-FAIL', current)
            continue
        page_url = final or current
        _dblog('STREAMSIFY-FETCH', f'{current} {len(html)}B')

        candidates = []
        for match in _RIPPLE_ATOB_RE.finditer(html):
            try:
                encoded = match.group(1)
                padding = '=' * (-len(encoded) % 4)
                decoded = base64.urlsafe_b64decode(
                    (encoded + padding).encode('ascii')).decode('utf-8', 'replace')
            except (ValueError, TypeError, UnicodeError, base64.binascii.Error):
                _dblog('STREAMSIFY-ATOB-FAIL', current)
                continue
            if decoded.startswith(('http://', 'https://', '//')):
                candidates.append(_ripple_clean(decoded, page_url))
        candidates.extend(
            _ripple_clean(match.group(1), page_url)
            for match in _RIPPLE_DIRECT_RE.finditer(html))

        for stream in candidates:
            if not stream.lower().split('?', 1)[0].endswith(('.m3u8', '.mp4')):
                continue
            page = urlparse(page_url)
            origin = f'{page.scheme}://{page.netloc}' if page.netloc else ''
            xbmc.log(f'COSMOS streamsify: stream found for {url}', xbmc.LOGINFO)
            _dblog('STREAMSIFY-OK', f'{stream[:120]} referer={page_url}')
            headers = f'|User-Agent={UA}&Referer={page_url}'
            if origin:
                headers += f'&Origin={origin}'
            return stream + headers

        if depth >= 3:
            continue
        for match in _RIPPLE_IFRAME_RE.finditer(html):
            child = _ripple_clean(match.group(1), page_url)
            child_host = (urlparse(child).hostname or '').lower().rstrip('.')
            if child_host in allowed_hosts:
                queue.append((child, page_url, depth + 1))

    xbmc.log(f'COSMOS streamsify: no static playable stream found for {url}',
             xbmc.LOGWARNING)
    _dblog('STREAMSIFY-NONE', 'no static HLS/MP4 URL')
    return None


# ── Eagle Streams / flyembed ─────────────────────────────────────────────
# Eagle Streams pages embed flyembed.click, which in turn embeds a player
# page. The player keeps its signed HLS URL inside a small XOR-obfuscated
# JavaScript array. Decode only that known data block and follow only the
# Eagle/flyembed/player hosts; never execute the page JavaScript.
def _is_eagle_streams(url):
    try:
        host = (urlparse(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return host in (
        'eagle-streams.shop', 'www.eagle-streams.shop',
        'flyembed.click', 'www.flyembed.click',
        'epic.cdx-08192.website',
    )


_EAGLE_IFRAME_RE = re.compile(
    r'<iframe[^>]+\bsrc\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
_EAGLE_MEDIA_RE = re.compile(
    r'((?:https?:)?(?:/{2}|(?:\\?/){2})[^\s"\'<>\\]+\.(?:m3u8|mp4)'
    r'(?:\?[^\s"\'<>\\]*)?)', re.IGNORECASE)
_EAGLE_OBFUSCATED_RE = re.compile(
    r'var\s+[A-Za-z_$][\w$]*\s*=\s*\[([^\]]+)\]\s*,\s*'
    r'[A-Za-z_$][\w$]*\s*=\s*(\d+)\s*,\s*'
    r'[A-Za-z_$][\w$]*\s*=\s*(\d+)',
    re.IGNORECASE | re.DOTALL)


def _eagle_clean(value, base_url):
    value = unescape((value or '').strip())
    value = value.replace('\\/', '/').replace('\\u0026', '&')
    if value.startswith('//'):
        value = 'https:' + value
    return urljoin(base_url, value)


def _eagle_decode_player_js(html):
    """Decode Eagle's bounded XOR array without evaluating JavaScript."""
    match = _EAGLE_OBFUSCATED_RE.search(html or '')
    if not match:
        return ''
    try:
        numbers = [int(value) for value in re.findall(r'-?\d+', match.group(1))]
        td5 = int(match.group(2))
        kq7 = int(match.group(3))
        if not numbers or len(numbers) > 20000:
            raise ValueError('invalid obfuscated array length')
        return ''.join(chr(((number ^ td5) - kq7) % 256)
                       for number in numbers)
    except (TypeError, ValueError):
        _dblog('EAGLE-DECODE-FAIL', 'invalid obfuscated player block')
        return ''


def resolve_eagle_streams(url):
    """Resolve an Eagle Streams page to its signed HLS URL."""
    allowed_hosts = {
        'eagle-streams.shop', 'www.eagle-streams.shop',
        'flyembed.click', 'www.flyembed.click',
        'epic.cdx-08192.website',
    }
    queue = [(url, url, 0)]
    seen = set()

    while queue:
        current, referer, depth = queue.pop(0)
        if current in seen or depth > 3:
            continue
        seen.add(current)
        host = (urlparse(current).hostname or '').lower().rstrip('.')
        if host not in allowed_hosts:
            _dblog('EAGLE-SKIP', f'blocked child host={host}')
            continue

        html, final = _fetch(current, referer=referer, timeout=30)
        if not html:
            _dblog('EAGLE-FETCH-FAIL', current)
            continue
        page_url = final or current
        _dblog('EAGLE-FETCH', f'{current} {len(html)}B')

        decoded = _eagle_decode_player_js(html)
        candidates = [
            _eagle_clean(match.group(1), page_url)
            for match in _EAGLE_MEDIA_RE.finditer(html)
        ]
        candidates.extend(
            _eagle_clean(match.group(1), page_url)
            for match in _EAGLE_MEDIA_RE.finditer(decoded)
        )

        for stream in candidates:
            parsed = urlparse(stream)
            stream_host = (parsed.hostname or '').lower().rstrip('.')
            if not parsed.path.lower().endswith(('.m3u8', '.mp4')):
                continue
            if not (stream_host == 'timst.cfd' or
                    stream_host.endswith('.timst.cfd')):
                _dblog('EAGLE-MEDIA-SKIP', f'blocked media host={stream_host}')
                continue
            page = urlparse(page_url)
            origin = f'{page.scheme}://{page.netloc}' if page.netloc else ''
            xbmc.log(f'COSMOS eagle-streams: stream found for {url}',
                     xbmc.LOGINFO)
            _dblog('EAGLE-OK', f'{stream[:160]} referer={page_url}')
            headers = f'|User-Agent={UA}&Referer={page_url}'
            if origin:
                headers += f'&Origin={origin}'
            return stream + headers

        if depth >= 3:
            continue
        for match in _EAGLE_IFRAME_RE.finditer(html):
            child = _eagle_clean(match.group(1), page_url)
            child_host = (urlparse(child).hostname or '').lower().rstrip('.')
            if child_host in allowed_hosts:
                queue.append((child, page_url, depth + 1))
                _dblog('EAGLE-QUEUE', child)

    xbmc.log(f'COSMOS eagle-streams: no signed HLS/MP4 stream found for {url}',
             xbmc.LOGWARNING)
    _dblog('EAGLE-NONE', 'no signed HLS/MP4 URL')
    return None


# ── Rapidgator ───────────────────────────────────────────────────────────
def _is_rapidgator(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h == 'rapidgator.net'


# ── Nitroflare ───────────────────────────────────────────────────────────
def _is_nitroflare(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h == 'nitroflare.com'


# ── Uploadgig ───────────────────────────────────────────────────────────
def _is_uploadgig(url):
    """Return True for Uploadgig file pages and its generated CDN hosts."""
    try:
        host = (urlparse(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return host == 'uploadgig.com' or host.endswith('.uploadgig.com')


def _is_uploadgig_direct(url):
    """Return True for a generated Uploadgig download URL."""
    try:
        parsed = urlparse(url or '')
        host = (parsed.hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return (
        parsed.scheme in ('http', 'https')
        and (host == 'uploadgig.com' or host.endswith('.uploadgig.com'))
        and parsed.path.lower().startswith('/start/')
    )


# ── MultiUp mirror index ────────────────────────────────────────────────
def _is_multiup(url):
    """Return True only for MultiUp mirror-index URLs."""
    try:
        host = (urlparse(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return host in ('multiup.io', 'multiup.org')


def _multiup_attr(attrs, name):
    """Read one quoted/unquoted HTML attribute from an opening tag."""
    match = re.search(
        rf'\b{re.escape(name)}\s*=\s*(?:(["\'])(.*?)\1|([^\s>]+))',
        attrs or '', re.I | re.S,
    )
    if not match:
        return ''
    return unescape((match.group(2) or match.group(3) or '').strip())


def _multiup_mirror_endpoint(html, base_url):
    """Find MultiUp's current mirror POST endpoint from the page form."""
    for match in re.finditer(r'<form\b([^>]*)>', html or '', re.I | re.S):
        action = _multiup_attr(match.group(1), 'action')
        if '/mirror/' in action.lower():
            return urljoin(base_url, action)
    return ''


def _multiup_csrf_token(html):
    """Extract the CSRF token from the public MultiUp download page."""
    for match in re.finditer(r'<input\b([^>]*)>', html or '', re.I | re.S):
        attrs = match.group(1)
        if _multiup_attr(attrs, 'name').lower() == '_csrf_token':
            return _multiup_attr(attrs, 'value')
    return ''


def _multiup_mirror_candidates(html, base_url):
    """Extract validated external links from a MultiUp mirror response."""
    mirrors = []
    for match in re.finditer(r'<a\b([^>]*)>', html or '', re.I | re.S):
        attrs = match.group(1)
        host_label = _multiup_attr(attrs, 'nameHost')
        raw_link = _multiup_attr(attrs, 'link') or _multiup_attr(attrs, 'href')
        if not host_label or not raw_link:
            continue
        candidate = urljoin(base_url, raw_link.strip())
        try:
            parsed = urlparse(candidate)
            link_host = (parsed.hostname or '').lower().rstrip('.')
        except ValueError:
            continue
        if parsed.scheme not in ('http', 'https') or not link_host:
            continue
        if _is_multiup(candidate):
            continue
        # The label and link must identify the same host.  This prevents
        # unrelated anchors or misleading query/path text from entering the
        # source pipeline.
        label_host = (urlparse(host_label).hostname or host_label).lower().rstrip('.')
        if label_host and not (
            link_host == label_host or link_host.endswith('.' + label_host)
        ):
            continue
        if candidate not in mirrors:
            mirrors.append(candidate)
    return mirrors


def get_multiup_mirrors(url):
    """Return MultiUp's current external mirror links for *url*.

    MultiUp's download page is an index, not a playable media URL.  The site
    currently requires a CSRF-protected POST to reveal the mirror list.  This
    helper only performs that public form flow and returns validated links;
    callers must resolve each mirror through its own host resolver.
    """
    global _last_resolver_error
    _last_resolver_error = ''
    if not _is_multiup(url):
        return []

    html, final_url = _fetch(url, referer='https://multiup.io/')
    if not html:
        _last_resolver_error = 'multiup_fetch_failed'
        _dblog('MULTIUP-GET-NONE', url)
        return []

    page_url = final_url or url
    token = _multiup_csrf_token(html)
    endpoint = _multiup_mirror_endpoint(html, page_url)
    if not token or not endpoint:
        _last_resolver_error = 'multiup_mirror_form_missing'
        _dblog('MULTIUP-FORM-NONE', 'missing CSRF token or mirror endpoint')
        return []

    mirror_html, mirror_url = _post(
        endpoint, {'_csrf_token': token}, referer=page_url,
    )
    mirrors = _multiup_mirror_candidates(mirror_html, mirror_url or endpoint)
    if not mirrors:
        _last_resolver_error = 'multiup_no_mirrors'
        _dblog('MULTIUP-MIRRORS-NONE', endpoint)
        return []
    _dblog('MULTIUP-MIRRORS', f'{len(mirrors)} validated mirror(s)')
    return mirrors


def resolve_uploadgig(url):
    """Require a premium/debrid resolver for Uploadgig.

    Uploadgig's free flow requires an interactive CAPTCHA, which is not
    available in Kodi's normal playback path.  Do not fetch the page or accept
    a generated ``/start/`` URL here: doing so could allow an unauthenticated
    free link to bypass the premium-only policy.  Returning ``None`` while
    leaving this host unowned makes ``filehost.py`` continue to ResolveURL
    after the configured debrid services have been tried.
    """
    global _last_resolver_error
    _last_resolver_error = 'debrid_required_uploadgig'
    xbmc.log('COSMOS uploadgig: premium/debrid credentials required; '
             'free interactive CAPTCHA flow is disabled in Kodi',
             xbmc.LOGWARNING)
    _dblog('UPLOADGIG-PREMIUM-ONLY', 'delegating to debrid/ResolveURL')
    return None


# ── Fullraces.com ────────────────────────────────────────────────────────
def _is_fullraces(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h == 'fullraces.com'

# ── Watchwrestling.bg ────────────────────────────────────────────────────────

# ── Mega.nz public files ─────────────────────────────────────────────────
def _is_mega(url):
    try:
        host = (urlparse(url or '').netloc or '').lower().replace('www.', '')
    except ValueError:
        return False
    return host in ('mega.nz', 'mega.co.nz') and (
        '/embed/' in (urlparse(url or '').path or '')
        or '/file/' in (urlparse(url or '').path or '')
        or '/#!' in (url or '')
    )


def _mega_parts(url):
    """Return (public handle, base64url file key) for Mega public links."""
    raw = unescape(url or '').strip()
    if '/embed/' in raw:
        path = urlparse(raw).path
        handle = path.split('/embed/', 1)[1].split('/', 1)[0]
        key = raw.split('#', 1)[1] if '#' in raw else ''
    elif '/file/' in raw:
        path = urlparse(raw).path
        handle = path.split('/file/', 1)[1].split('#', 1)[0].split('/', 1)[0]
        key = raw.split('#', 1)[1] if '#' in raw else ''
    elif '/#!' in raw:
        fragment = raw.split('/#!', 1)[1]
        handle, _, key = fragment.partition('!')
    else:
        return '', ''
    return handle.strip(), key.strip()


def resolve_mega(url):
    """Resolve a public Mega embed to a localhost-decrypted MP4 URL."""
    handle, key_text = _mega_parts(url)
    if not handle or not key_text:
        xbmc.log(f'COSMOS mega: missing public handle/key for {url}', xbmc.LOGWARNING)
        return None
    try:
        padding = '=' * (-len(key_text) % 4)
        file_key = base64.urlsafe_b64decode((key_text + padding).encode('ascii'))
        if len(file_key) != 32:
            raise ValueError('Mega public key is not 32 bytes')
    except (ValueError, TypeError, base64.binascii.Error) as exc:
        xbmc.log(f'COSMOS mega: invalid public key: {exc}', xbmc.LOGWARNING)
        return None

    api_id = int(__import__('time').time() * 1000) & 0x7fffffff
    body, _ = _post_json(
        f'https://g.api.mega.co.nz/cs?id={api_id}',
        [{'a': 'g', 'g': 1, 'p': handle}],
        referer=url,
    )
    try:
        payload = json.loads(body)
        file_info = payload[0] if isinstance(payload, list) else None
        file_url = file_info.get('g') if isinstance(file_info, dict) else None
        file_size = int(file_info.get('s', 0)) if file_info else 0
    except (ValueError, TypeError, AttributeError, IndexError):
        file_url, file_size = None, 0
    if not file_url or file_size <= 0:
        xbmc.log(f'COSMOS mega: public file API returned no playable object for {url}',
                 xbmc.LOGWARNING)
        return None

    # The API sometimes returns http:// CDN URLs; use HTTPS where available.
    parsed = urlparse(file_url)
    if parsed.scheme == 'http':
        file_url = urlunparse(('https', parsed.netloc, parsed.path,
                               parsed.params, parsed.query, parsed.fragment))
    stream = mega_proxy.start(file_url, file_size, file_key)
    if stream:
        xbmc.log(f'COSMOS mega: decrypted playback proxy ready for {url}', xbmc.LOGINFO)
        _dblog('MEGA-OK', f'{file_size}B → {stream}')
        return f'{stream}|User-Agent={UA}'
    xbmc.log(f'COSMOS mega: could not start playback proxy for {url}', xbmc.LOGWARNING)
    return None


# ── Megaplay.su ──────────────────────────────────────────────────────────
def _is_megaplay(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h == 'megaplay.su'


# New regex for direct <video> tag
_MEGAPLAY_HTML5_VIDEO_RE = re.compile(
    r'<video[^>]+src=["\']?(https?://[^"\'<>\s]+\.(?:mp4|m3u8)[^"\'<>\s]*)["\']?',
    re.IGNORECASE
)

# New regex for a common pattern where video URL is in a JS variable like 'var video_url = "..."'
_MEGAPLAY_JS_VAR_RE = re.compile(
    r'(?:var|const|let)\s+(?:video_url|source_url|stream_url)\s*=\s*["\'](https?://[^"\'<>\s]+\.(?:mp4|m3u8)[^"\'<>\s]*)["\']',
    re.IGNORECASE
)

_MEGAPLAY_JW_FILE_RE = re.compile(
    r'(?:file|src)\s*:\s*["\']?(https?://[^"\'<>\s]+\.mp4[^"\'<>\s]*)["\']?',
    re.IGNORECASE
)

_MEGAPLAY_DIRECT_VIDEO_RE = re.compile(
    r'(https?://[^\s"\'<>]+\.(?:mp4|m3u8)(?:\?[^\s"\'<>]*)?)',
    re.IGNORECASE
)


def _is_megavid(url):
    return (urlparse(url).hostname or '').lower().rstrip('.') in ('megavid.buzz', 'www.megavid.buzz')


def resolve_megavid(url):
    """Resolve readable MegaVid player sources; old /embed routes may be gone."""
    global _last_resolver_error
    from . import watchwrestling
    try:
        request = Request(url, headers={'User-Agent': UA, 'Referer': 'https://watchwrestling.bg/'})
        with urlopen(request, timeout=20) as response:
            body = response.read(4 * 1024 * 1024).decode('utf-8', 'replace')
            player_url = response.url
    except HTTPError as exc:
        if exc.code in (404, 410):
            _last_resolver_error = 'host_unavailable'
        xbmc.log(f'COSMOS megavid: player HTTP {exc.code}', xbmc.LOGWARNING)
        return None
    except (URLError, OSError):
        xbmc.log('COSMOS megavid: player request failed', xbmc.LOGWARNING)
        return None
    body = (_unpack(body) or '') + body
    streams = watchwrestling.jwplayer_sources(body, player_url)
    if not streams:
        streams = [link for link in watchwrestling._links(body, player_url)
                   if watchwrestling.is_direct_stream(link)]
    if streams:
        xbmc.log('COSMOS megavid: direct media source extracted', xbmc.LOGINFO)
        return streams[0] + '|' + urlencode({'User-Agent': UA, 'Referer': player_url})
    xbmc.log('COSMOS megavid: no supported media configuration found', xbmc.LOGWARNING)
    return None


def resolve_megaplay(url):
    """Resolve a megaplay.su embed URL to a direct mp4/m3u8 stream."""
    xbmc.log(f'COSMOS megaplay: resolving {url}', xbmc.LOGINFO)
    html, _ = _fetch(url, referer='https://megaplay.su/')
    if not html:
        xbmc.log(f'COSMOS megaplay: fetch failed or returned empty HTML for {url}', xbmc.LOGWARNING)
        return None

    # Try unpacking JS first
    unpacked_html = _unpack(html) or html
    search_content = unpacked_html + html # Search both original and unpacked

    # Strategy 1: Look for direct <video> tag
    direct = _MEGAPLAY_HTML5_VIDEO_RE.search(search_content)
    if direct:
        stream = direct.group(1).strip()
        xbmc.log(f'COSMOS megaplay: HTML5 video tag stream found → {stream[:80]} for {url}', xbmc.LOGINFO)
        return f'{stream}|User-Agent={UA}&Referer={url}'

    # Strategy 2: Try to find JWPlayer file configuration
    direct = _MEGAPLAY_JW_FILE_RE.search(search_content)
    if direct:
        stream = direct.group(1).strip()
        xbmc.log(f'COSMOS megaplay: JWPlayer stream found → {stream[:80]} for {url}', xbmc.LOGINFO)
        return f'{stream}|User-Agent={UA}&Referer={url}'

    # Strategy 3: Look for common JS variable assignments
    direct = _MEGAPLAY_JS_VAR_RE.search(search_content)
    if direct:
        stream = direct.group(1).strip()
        xbmc.log(f'COSMOS megaplay: JS variable stream found → {stream[:80]} for {url}', xbmc.LOGINFO)
        return f'{stream}|User-Agent={UA}&Referer={url}'

    # Strategy 4: Fallback to broad direct video URL search
    vids = _MEGAPLAY_DIRECT_VIDEO_RE.findall(search_content)
    if vids:
        stream = vids[0].strip()
        xbmc.log(f'COSMOS megaplay: broad direct video stream found → {stream[:80]} for {url}', xbmc.LOGINFO)
        return f'{stream}|User-Agent={UA}&Referer={url}'

    xbmc.log(f'COSMOS megaplay: no stream found for {url}', xbmc.LOGWARNING)
    return None
# ── StreamEast fixture pages ─────────────────────────────────────────────
def _is_streameast(url):
    try:
        host = (urlparse(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return bool(re.fullmatch(r'(?:www\.)?streameast\d*\.org(?:fixture)?', host))


def _streameast_parts(url):
    fixed = re.sub(
        r'^(https?://(?:www\.)?streameast\d*\.org)fixture/',
        r'\1/fixture/', url or '', flags=re.IGNORECASE)
    path = unquote(urlparse(fixed).path)
    match = re.search(r'/fixture/(.+)', path, re.IGNORECASE)
    if not match:
        return '', '', fixed
    teams = match.group(1).strip('/').replace('+', ' ')
    if '-vs-' not in teams.lower():
        return '', '', fixed
    left, right = re.split(r'-vs-', teams, maxsplit=1, flags=re.IGNORECASE)
    return left.replace('-', ' ').strip(), right.replace('-', ' ').strip(), fixed


def _streameast_links(value):
    if isinstance(value, str):
        return [value] if value.startswith(('http://', 'https://')) else []
    if isinstance(value, dict):
        value = value.get('data') or value.get('streamerLinks') or []
    if isinstance(value, dict):
        value = [value]
    links = []
    for item in value or []:
        if isinstance(item, str):
            candidate = item
        elif isinstance(item, dict):
            candidate = (item.get('websiteLink') or item.get('link') or
                         item.get('url') or '')
        else:
            candidate = ''
        if candidate and candidate.startswith(('http://', 'https://')):
            if candidate not in links:
                links.append(candidate)
    return links


_STREAMEAST_DIRECT_RE = re.compile(
    r'https?://[^\s"\'<>\\]+\.(?:m3u8|mp4|mpd)(?:\?[^\s"\'<>\\]*)?',
    re.IGNORECASE)
_STREAMEAST_IFRAME_RE = re.compile(
    r'<iframe\b[^>]+(?:src|data-src)=["\']([^"\']+)',
    re.IGNORECASE)
_STREAMEAST_SKIP_PAGE_HOSTS = frozenset({'sportsfeed24.pk', 'sportsfeed24.cx'})


def _streameast_clean_url(value, base_url=''):
    value = unescape((value or '').replace('\\u0026', '&').replace('\\/', '/'))
    value = value.strip().rstrip('\\')
    return urljoin(base_url, value)


def _streameast_stream_url(url, referer=''):
    """Return a direct media URL with Kodi request headers, if applicable."""
    if not re.search(r'\.(?:m3u8|mp4|mpd)(?:$|\?)', url or '', re.IGNORECASE):
        return None
    return f'{url}|User-Agent={UA}&Referer={referer or url}'


def _probe_streameast_page(url, referer='', depth=0, seen=None):
    """Follow a small iframe chain until a direct stream is found."""
    if not url or depth > 3:
        return None
    parsed = urlparse(url)
    host = (parsed.hostname or '').lower().rstrip('.')
    if host in _STREAMEAST_SKIP_PAGE_HOSTS:
        return None
    direct = _streameast_stream_url(url, referer)
    if direct:
        return direct

    seen = seen or set()
    key = url.split('|', 1)[0]
    if key in seen:
        return None
    seen.add(key)
    html, final_url = _fetch(url, referer=referer or None)
    if not html:
        return None
    body = unescape(html.replace('\\u0026', '&').replace('\\/', '/'))

    for match in _STREAMEAST_DIRECT_RE.findall(body):
        stream = _streameast_stream_url(_streameast_clean_url(match, final_url), final_url)
        if stream:
            return stream

    for match in _STREAMEAST_IFRAME_RE.findall(body):
        child = _streameast_clean_url(match, final_url)
        if not child or child == final_url or '${' in child or '}' in child:
            continue
        stream = _probe_streameast_page(
            child, referer=final_url, depth=depth + 1, seen=seen)
        if stream:
            return stream
    return None


def resolve_streameast(url):
    """Resolve a StreamEast fixture page to a direct player/media URL."""
    team_a, team_b, fixed = _streameast_parts(url)
    if not team_a or not team_b:
        return None

    base = 'https://streameast7.org'
    body, _ = _post_json(
        base + '/api/xrhs', {'teamA': team_a, 'teamB': team_b},
        referer=fixed)
    try:
        data = json.loads(body or '{}')
    except (TypeError, ValueError):
        data = {}

    game = data.get('game') if isinstance(data, dict) else None
    game = game if isinstance(game, dict) else {}
    links = _streameast_links(game.get('streamerLinks'))
    for key in ('websiteLink', 'player2', 'trendy'):
        links.extend(x for x in _streameast_links(game.get(key))
                     if x not in links)

    if not links:
        live_body, _ = _post_json(
            base + '/api/getLiveStreams', {
                'categoryName': data.get('categoryName', 'Streams today'),
                'subCat': data.get('subCategoryName', ''),
                'teamA': team_a,
                'teamB': team_b,
                'link': game.get('sourceLink', ''),
            }, referer=fixed)
        try:
            links = _streameast_links(json.loads(live_body or '[]'))
        except (TypeError, ValueError):
            links = []

    # StreamEast's API returns website/fixture handoffs, not necessarily media
    # URLs. Probe those pages and follow iframe chains; never return a wrapper
    # page as if it were a playable stream.
    for candidate in links[:20]:
        if _is_streameast(candidate):
            continue
        stream = _probe_streameast_page(candidate, referer=fixed)
        if stream:
            xbmc.log(f'COSMOS streameast: playable stream found for {team_a} vs {team_b}',
                     xbmc.LOGINFO)
            return stream

    xbmc.log(f'COSMOS streameast: no live player links for {team_a} vs {team_b}',
             xbmc.LOGINFO)
    return None


# ── bysesukior.com ("Fiilemoon") ───────────────────────────────────────────
# fullfightreplays.com's "Fiilemoon" mirror buttons link to
# ``https://bysesukior.com/d/<code>``. The page itself is an empty SPA
# shell — the real stream comes from ``GET /api/videos/<code>``, whose
# JSON body has an AES-256-GCM-encrypted ``playback`` blob:
#   {"algorithm": "AES-256-GCM", "iv": <b64url>, "payload": <b64url>,
#    "key_parts": [<30 b64url chunks>], "version": "12"}
# The frontend JS only uses 2 of the 30 key_parts chunks as the raw
# AES-256 key; which 2 depends on ``version`` via a fixed permutation
# table (``Qa`` in the minified bundle): for version N (1-20), the two
# 1-indexed slots are ``N`` and ``31 - N``. Concatenating those two
# base64url-decoded chunks (16 bytes each) gives the 32-byte key.
# Decrypting the payload (ciphertext + 16-byte GCM tag, WebCrypto style)
# yields JSON with a ``sources`` list of direct HLS/mp4 URLs.
#
# UPDATE 2026: The site periodically extends its version table beyond 20.
# We now also try a "mirror" formula of [v, (n_parts+1-v)] when v > 20,
# and fall back to scanning adjacent slot pairs on decrypt failure.
def _is_bysesukior(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h in ('bysesukior.com', 'bysesayeveum.com', 'bysewihe.com', 'bysekoze.com', 'byseraguci.com') or 'filemoon.' in h or h.startswith('fmoon.')


def _byse_b64url_decode(s):
    s = s.replace('-', '+').replace('_', '/')
    s += '=' * ((-len(s)) % 4)
    return base64.b64decode(s)


def _byse_key_slots(version, n_parts):
    """Return the two 1-based slot indices for the AES key.

    Original scheme (versions 1-20): slots are [v, 31-v].
    Extended scheme (versions 21+): slots are [v, (n_parts+1-v)], which
    generalises the mirror pattern to arbitrary table sizes.
    """
    try:
        v = int(str(version).strip())
    except (TypeError, ValueError):
        return []

    # ── Original scheme: version 1-20, table of exactly 30 parts ──────────
    if 1 <= v <= 20:
        a, b = v, 31 - v
        if 1 <= a <= n_parts and 1 <= b <= n_parts:
            return [a, b]

    # ── Extended scheme: generalised mirror for larger tables ──────────────
    if 1 <= v <= n_parts:
        a = v
        b = n_parts + 1 - v
        if a != b and 1 <= b <= n_parts:
            return [a, b]

    return []


def _byse_try_decrypt(key_parts, slots, iv_b64, payload_b64):
    """Attempt decryption with given 1-based slots. Returns plaintext or None."""
    try:
        key = b''.join(_byse_b64url_decode(key_parts[i - 1]) for i in slots)
        iv = _byse_b64url_decode(iv_b64)
        payload = _byse_b64url_decode(payload_b64)
        return aes_gcm_decrypt(key, iv, payload)
    except Exception:
        return None


def _byse_pick_source(sources):
    """From a Fiilemoon /api/source data list, return the best (stream, type) pair.

    Prefers MP4 over HLS — MP4 is a single request so Kodi's header
    propagation issues in adaptive-stream chains do not apply.
    Returns (url_string, type_string) or ('', '').
    """
    if not isinstance(sources, list) or not sources:
        return ('', '')
    mp4s = [s for s in sources
            if (s.get('type') or '').lower() in ('mp4', 'video/mp4')
            and s.get('file')]
    hls  = [s for s in sources
            if (s.get('type') or '').lower() in ('hls', 'm3u8', 'application/x-mpegurl')
            or '.m3u8' in (s.get('file') or '')]
    others = [s for s in sources if s.get('file')]
    if mp4s:
        mp4s.sort(key=lambda s: int(re.search(r'\d+', s.get('label') or '0').group()),
                  reverse=True)
        return (mp4s[0]['file'], 'mp4')
    if hls:
        f = hls[0].get('file') or ''
        return (f, 'hls') if f else ('', '')
    if others:
        return (others[0].get('file') or '', 'unknown')
    return ('', '')


def resolve_bysesukior(url):
    """Resolve a bysesukior.com (Fiilemoon) /d/<code> or /e/<code> link.

    Strategy:
      1. POST /api/source/<code>  — Fiilemoon player-facing API; returns
         plain (unencrypted) MP4/HLS URLs per-request.  These have fresh
         CDN tokens and do not suffer from HLS header-propagation issues.
      2. GET  /api/videos/<code>  — backend API returning AES-encrypted
         playback blob; decrypt and extract HLS URL (original approach).
         Used as fallback when the POST returns nothing useful.
    """
    m = re.search(r'/(?:d|e)/([A-Za-z0-9]+)', urlparse(url).path)
    if not m:
        return None
    code   = m.group(1)
    host = (urlparse(url).hostname or '').lower()
    host = host[4:] if host.startswith('www.') else host
    host = host if host in ('bysesukior.com', 'bysesayeveum.com', 'bysewihe.com', 'bysekoze.com', 'byseraguci.com') else 'bysesukior.com'
    origin = 'https://' + host
    embed = f'{origin}/e/{code}'

    # ── Step 1: POST /api/source/<code> (Fiilemoon player API) ────────────
    xbmc.log(f'COSMOS bysesukior: POSTing to /api/source/{code}', xbmc.LOGINFO)
    post_body, _ = _post(
        f'{origin}/api/source/{code}',
        data={'r': embed, 'd': host},
        referer=embed,
    )
    xbmc.log('COSMOS bysesukior: POST response received', xbmc.LOGINFO)
    if post_body:
        try:
            pdata = json.loads(post_body)
            if pdata.get('success') and pdata.get('data'):
                sources = pdata['data']
                xbmc.log('COSMOS bysesukior: usable POST source data received',
                         xbmc.LOGINFO)
                stream, stype = _byse_pick_source(sources)
                if stream:
                    xbmc.log(
                        f'COSMOS bysesukior: POST {stype} stream selected',
                        xbmc.LOGINFO)
                    return (f'{stream}'
                            f'|User-Agent={UA}'
                            f'&Referer={embed}'
                            f'&Origin={origin}')
                else:
                    xbmc.log(
                        f'COSMOS bysesukior: POST returned no usable source '
                        '(response contained no usable source)', xbmc.LOGWARNING)
            else:
                xbmc.log(
                    f'COSMOS bysesukior: POST success={pdata.get("success")} '
                    f'msg={pdata.get("msg")} — falling back to AES path',
                    xbmc.LOGWARNING)
        except ValueError as e:
            xbmc.log(f'COSMOS bysesukior: POST JSON parse failed: {e}',
                     xbmc.LOGWARNING)
    else:
        xbmc.log(f'COSMOS bysesukior: POST returned empty body, '
                 f'falling back to AES path', xbmc.LOGWARNING)

    # ── Step 2: GET /api/videos/<code> + AES decrypt (fallback) ───────────
    xbmc.log(f'COSMOS bysesukior: trying AES path for {url}', xbmc.LOGINFO)
    api_url = f'{origin}/api/videos/{code}'
    body, _final = _fetch(api_url, referer=embed,
                          extra_headers={'Accept': 'application/json'})
    if not body:
        body, _final = _fetch(f'{origin}/api/source/{code}',
                              referer=embed,
                              extra_headers={'Accept': 'application/json'})
    if not body:
        xbmc.log(f'COSMOS bysesukior: AES API returned empty body for {url}',
                 xbmc.LOGWARNING)
        return None

    try:
        data = json.loads(body)
    except ValueError as e:
        xbmc.log(f'COSMOS bysesukior: JSON parse failed for {url}: {e}',
                 xbmc.LOGWARNING)
        return None

    # ── Locate the playback blob (handle both flat and nested layouts) ──────
    playback = data.get('playback') or data.get('data', {}) or {}
    if not isinstance(playback, dict):
        playback = {}

    # Some API revisions nest it one level deeper under 'video'
    if not playback.get('key_parts') and isinstance(data.get('video'), dict):
        playback = data['video'].get('playback') or {}

    key_parts = playback.get('key_parts') or []
    iv_b64    = playback.get('iv', '')
    payload_b64 = playback.get('payload', '')

    if not key_parts or not iv_b64 or not payload_b64:
        xbmc.log(
            f'COSMOS bysesukior: missing playback fields for {url}. '
            f'Keys present: {list(playback.keys())}',
            xbmc.LOGWARNING,
        )
        return None

    n_parts = len(key_parts)
    version  = playback.get('version', '')

    # ── Primary: use the documented version→slots formula ──────────────────
    slots = _byse_key_slots(version, n_parts)
    if slots:
        plaintext = _byse_try_decrypt(key_parts, slots, iv_b64, payload_b64)
        if plaintext is None:
            xbmc.log(
                f'COSMOS bysesukior: decrypt failed (version={version}, '
                f'slots={slots}, n_parts={n_parts}) for {url}',
                xbmc.LOGWARNING,
            )
    else:
        plaintext = None
        xbmc.log(
            f'COSMOS bysesukior: no valid slots for version={version}, '
            f'n_parts={n_parts} — will try brute-force for {url}',
            xbmc.LOGWARNING,
        )

    # ── Fallback: scan mirror pairs when the formula yields nothing ─────────
    if plaintext is None:
        xbmc.log(f'COSMOS bysesukior: brute-forcing slot pairs for {url}',
                 xbmc.LOGINFO)
        for a in range(1, n_parts + 1):
            b = n_parts + 1 - a
            if b <= a or b > n_parts:
                continue
            candidate = _byse_try_decrypt(key_parts, [a, b], iv_b64, payload_b64)
            if candidate is not None:
                xbmc.log(
                    f'COSMOS bysesukior: brute-force found slots [{a},{b}] '
                    f'for version={version}',
                    xbmc.LOGINFO,
                )
                plaintext = candidate
                break

    if plaintext is None:
        xbmc.log(f'COSMOS bysesukior: all decryption attempts failed for {url}',
                 xbmc.LOGERROR)
        return None

    try:
        info = json.loads(plaintext)
    except (ValueError, TypeError) as e:
        xbmc.log(f'COSMOS bysesukior: plaintext JSON parse failed for {url}: {e}',
                 xbmc.LOGWARNING)
        return None

    sources = info.get('sources') or []
    if not sources:
        xbmc.log(f'COSMOS bysesukior: no sources in decrypted payload for {url}',
                 xbmc.LOGWARNING)
        return None

    xbmc.log(f'COSMOS bysesukior: AES sources={sources}', xbmc.LOGINFO)
    sources.sort(key=lambda s: int(s.get('height') or 0), reverse=True)
    stream = sources[0].get('url')
    if not stream:
        xbmc.log(f'COSMOS bysesukior: sources[0] has no url key for {url}',
                 xbmc.LOGWARNING)
        return None
    xbmc.log(f'COSMOS bysesukior: AES stream → {stream} for {url}', xbmc.LOGINFO)
    return (f'{stream}'
            f'|User-Agent={UA}'
            f'&Referer={embed}'
            f'&Origin={origin}')


# ── Dailymotion ───────────────────────────────────────────────────────────
# Handles both geo.dailymotion.com/player.html?video=<id> (the embed player
# URL used by sports sites) and standard dailymotion.com/video/<id> URLs.
# ResolveURL's Dailymotion plugin returns "Content rejected" for geo-region
# player embed URLs, so we bypass it entirely and query the metadata API
# directly for an HLS stream.
#
# Metadata API:
#   GET https://www.dailymotion.com/player/metadata/video/<id>
#       ?embedder=<origin>&locale=en&hd=1
# Response JSON: { "qualities": { "auto": [...], "1080": [...], ... } }
# Each entry: { "type": "application/x-mpegURL", "url": "https://..." }
def _is_dailymotion(url):
    try:
        h = (urlparse(url).hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return h == 'dai.ly' or h == 'dailymotion.com' or h.endswith('.dailymotion.com')


def _dm_extract_id(url):
    """Extract the video ID from any Dailymotion URL variant."""
    parsed = urlparse(url)
    # geo.dailymotion.com/player.html?video=xaayx20
    qs = {}
    for part in (parsed.query or '').split('&'):
        if '=' in part:
            k, _, v = part.partition('=')
            qs[k] = v
    if 'video' in qs:
        return qs['video']
    # dailymotion.com/video/<id> or /embed/video/<id>
    m = re.search(r'/(?:video|embed/video)/([A-Za-z0-9]+)', parsed.path or '')
    if m:
        return m.group(1)
    # Short links use https://dai.ly/<id>.
    if (parsed.hostname or '').lower().rstrip('.') == 'dai.ly':
        m = re.match(r'/([A-Za-z0-9]+)', parsed.path or '')
        if m:
            return m.group(1)
    # Bare 7-char ID in path: /player.html only has query, handled above
    return ''


def _dm_player_urls(url, vid):
    """Alternate public player endpoints for the same upload (not new uploads)."""
    candidates = [
        url if _is_dailymotion(url) and urlparse(url).hostname != 'dai.ly' else '',
        'https://geo.dailymotion.com/player.html?' + urlencode({'video': vid}),
        'https://www.dailymotion.com/embed/video/' + vid,
        'https://www.dailymotion.com/video/' + vid,
    ]
    return list(dict.fromkeys(candidate for candidate in candidates if candidate))


def _dm_pick_stream(data, referer_origin):
    """Extract the best playable stream from a DM metadata/player JSON blob.

    Returns a Kodi-ready URL string or None.
    Works on both the /player/metadata/video/<id> response format
    (qualities dict with 'url' keys) and the geo-player page __PLAYER_CONFIG__
    format (qualities dict with 'url' keys, same structure).
    """
    qualities = data.get('qualities') or {}
    quality_order = ['auto', '2160', '1440', '1080', '720', '480', '380', '240', '144']

    for q in quality_order:
        streams = qualities.get(q) or qualities.get(str(q)) or []
        for s in streams:
            stream_url = s.get('url', '')
            if not stream_url or not stream_url.startswith('http'):
                continue
            mime = s.get('type', '')
            if 'mpegURL' in mime or 'x-mpegURL' in mime or '.m3u8' in stream_url:
                return (f'{stream_url}'
                        f'|User-Agent={UA}'
                        f'&Referer={referer_origin}/'
                        f'&Origin={referer_origin}')
            if 'mp4' in mime or stream_url.endswith('.mp4'):
                return (f'{stream_url}'
                        f'|User-Agent={UA}'
                        f'&Referer={referer_origin}/')

    # Last resort: any URL present in any quality tier
    for streams in qualities.values():
        for s in (streams or []):
            stream_url = s.get('url', '')
            if stream_url and stream_url.startswith('http'):
                return f'{stream_url}|User-Agent={UA}&Referer={referer_origin}/'

    return None


def resolve_dailymotion(url):
    """Resolve a Dailymotion URL to a direct HLS or mp4 stream.

    Works for both geo.dailymotion.com/player.html?video=<id> embeds and
    standard dailymotion.com/video/<id> URLs.

    Strategy:
      1. Metadata API with the URL's own origin as embedder
         (e.g. embedder=https://geo.dailymotion.com).
      2. If that returns an API error, retry with embedder=https://www.dailymotion.com.
      3. If still failing, retry with no embedder parameter at all.
      4. Try the original, geo and standard player pages for embedded streams.

    Alternate player endpoints can help with embed failures; they share the
    upload's geographic restrictions and do not provide independent mirrors.
    """
    vid = _dm_extract_id(url)
    if not vid:
        xbmc.log(f'COSMOS dailymotion: could not extract ID from {url}',
                 xbmc.LOGWARNING)
        return None

    parsed = urlparse(url)
    origin = f'{parsed.scheme}://{parsed.netloc}' if parsed.netloc else 'https://www.dailymotion.com'

    # ── 1-3. Metadata API — three embedder variants ───────────────────────
    _embedder_variants = [
        origin,                         # original (e.g. https://geo.dailymotion.com)
        'https://www.dailymotion.com',  # standard DM origin — often unblocks geo content
        '',                             # no embedder param at all
    ]
    _embedder_variants = list(dict.fromkeys(_embedder_variants))
    _removed_count = 0  # explicit removed/deleted responses only
    for _emb in _embedder_variants:
        if _emb:
            api_url = (f'https://www.dailymotion.com/player/metadata/video/{vid}'
                       f'?embedder={_emb}&locale=en&hd=1')
        else:
            api_url = (f'https://www.dailymotion.com/player/metadata/video/{vid}'
                       f'?locale=en&hd=1')
        body, _ = _fetch(
            api_url,
            referer=url,
            extra_headers={'Accept': 'application/json, text/javascript, */*; q=0.01'},
        )
        if not body:
            xbmc.log(f'COSMOS dailymotion: metadata API empty (embedder={_emb!r}) '
                     f'for {url}', xbmc.LOGWARNING)
            continue
        try:
            data = json.loads(body)
        except ValueError as e:
            xbmc.log(f'COSMOS dailymotion: JSON parse failed (embedder={_emb!r}): {e}',
                     xbmc.LOGWARNING)
            continue

        if data.get('error'):
            err = data['error']
            err_msg = (err.get('message') or '').lower()
            xbmc.log(
                f'COSMOS dailymotion: API error (embedder={_emb!r}) for {url}: '
                f'{err.get("type")} — {err.get("message")}',
                xbmc.LOGWARNING,
            )
            # Track explicit "removed/deleted" responses so we can show the
            # right toast even after all embedder variants are exhausted.
            if ('removed' in err_msg or 'terms of use' in err_msg
                    or 'deleted' in err_msg):
                _removed_count += 1
            # Don't give up immediately — try next embedder variant
            # but also check if qualities are present despite the error flag
        ref_origin = _emb if _emb else 'https://www.dailymotion.com'
        stream = _dm_pick_stream(data, ref_origin)
        if stream:
            xbmc.log(f'COSMOS dailymotion: metadata API (embedder={_emb!r}) → '
                     f'{stream[:80]} for {url}', xbmc.LOGINFO)
            return stream

    # Try alternate public player pages only after metadata attempts fail.
    for player_url in _dm_player_urls(url, vid):
        player_origin = '{0.scheme}://{0.netloc}'.format(urlparse(player_url))
        xbmc.log(f'COSMOS dailymotion: trying player endpoint {player_url}',
                 xbmc.LOGINFO)
        page_html, _ = _fetch(
            player_url,
            referer=url,
            extra_headers={'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8'},
        )
        if page_html:
            # Look for embedded JSON config blobs containing 'qualities'
            for _cfg_pat in (
                r'__(?:PLAYER_CONFIG|DM_PLAYER|INITIAL_STATE)__\s*=\s*(\{.*?\})\s*;',
                r'window\.__(?:PLAYER_CONFIG|DM_PLAYER)__\s*=\s*(\{.*?\})\s*[;\n]',
                r'"qualities"\s*:\s*\{.*?"auto"\s*:\s*\[.*?\]',
            ):
                _cm = re.search(_cfg_pat, page_html, re.DOTALL)
                if _cm:
                    try:
                        _cfg = json.loads(_cm.group(1) if _cm.lastindex else
                                          '{' + _cm.group(0).split('{', 1)[1])
                        # Flatten nested structures to find qualities
                        for _key in ('qualities', 'player', 'video', 'config'):
                            _sub = _cfg.get(_key) or {}
                            if isinstance(_sub, dict) and _sub.get('qualities'):
                                _cfg = _sub
                                break
                        stream = _dm_pick_stream(_cfg, player_origin)
                        if stream:
                            xbmc.log(f'COSMOS dailymotion: geo page scrape → '
                                     f'{stream[:80]} for {url}', xbmc.LOGINFO)
                            return stream
                    except Exception:
                        pass

            # Also try a broad HLS URL scan on the geo player page
            _hls_m = re.search(
                r'(https?://[^\s"\'<>\\]+\.m3u8(?:\?[^\s"\'<>\\]*)?)',
                page_html, re.IGNORECASE,
            )
            if _hls_m:
                stream = (_hls_m.group(1) +
                          f'|User-Agent={UA}&Referer={player_origin}/')
                xbmc.log(f'COSMOS dailymotion: geo page HLS scan → '
                         f'{stream[:80]} for {url}', xbmc.LOGINFO)
                return stream

    if _removed_count == len(_embedder_variants):
        global _last_resolver_error
        _last_resolver_error = 'removed'

    xbmc.log(f'COSMOS dailymotion: all strategies exhausted for {url}',
             xbmc.LOGWARNING)
    return None


# ── VK Video ───────────────────────────────────────────────────────────────
_VK_MEDIA_RE = re.compile(
    r'"(?P<kind>hls(?:_fmp4)?|mp4_\d+)"\s*:\s*"(?P<url>[^"]+)"',
    re.IGNORECASE)


def _is_vkvideo(url):
    try:
        host = (urlparse(url or '').hostname or '').lower().rstrip('.')
    except ValueError:
        return False
    return host in ('vkvideo.ru', 'vk.ru', 'vk.com') and '/video' in (urlparse(url or '').path or '').lower()


def _vk_video_ids(url):
    parsed = urlparse(url or '')
    query = parse_qs(parsed.query or '')
    candidates = [parsed.path, query.get('z', [''])[0]]
    for candidate in candidates:
        match = re.search(r'(?:^|[/=])video(-?\d+)_(-?\d+)', candidate or '', re.IGNORECASE)
        if match:
            return match.group(1), match.group(2)
    oid = query.get('oid', [''])[0]
    video_id = query.get('id', [''])[0]
    if re.fullmatch(r'-?\d+', oid or '') and re.fullmatch(r'-?\d+', video_id or ''):
        return oid, video_id
    return '', ''


def _vk_unescape(value):
    try:
        return json.loads('"' + value + '"')
    except (TypeError, ValueError):
        return (value or '').replace('\\/', '/').replace('\\u0026', '&')


def resolve_vkvideo(url):
    """Resolve a public VK Video URL to a signed HLS or MP4 CDN URL."""
    oid, video_id = _vk_video_ids(url)
    if not oid or not video_id:
        xbmc.log(f'COSMOS vkvideo: no video id in {url}', xbmc.LOGWARNING)
        return None

    embeds = (
        f'https://vk.com/video_ext.php?oid={oid}&id={video_id}&hd=3',
        f'https://vk.ru/video_ext.php?oid={oid}&id={video_id}&hd=3',
    )
    html = ''
    embed_url = embeds[0]
    for candidate in embeds:
        html, _ = _fetch(candidate, referer=url)
        if html:
            embed_url = candidate
            break
    if not html:
        xbmc.log(f'COSMOS vkvideo: embed fetch failed for {url}', xbmc.LOGWARNING)
        return None

    found = {}
    for match in _VK_MEDIA_RE.finditer(html):
        kind = match.group('kind').lower()
        media_url = _vk_unescape(match.group('url'))
        if media_url.startswith(('http://', 'https://')):
            found[kind] = media_url

    # Prefer progressive MP4: VK's HLS master can advertise variant paths
    # that some Kodi inputstream.adaptive versions request as HTTP 400.
    # Keep HLS as a fallback when VK does not advertise MP4 files.
    ordered = []
    mp4_keys = sorted(
        (key for key in found if key.startswith('mp4_')),
        key=lambda key: int(re.search(r'\d+', key).group()),
        reverse=True)
    ordered.extend(found[key] for key in mp4_keys)
    for key in ('hls', 'hls_fmp4'):
        if found.get(key):
            ordered.append(found[key])
    if ordered:
        stream = ordered[0]
        xbmc.log(f'COSMOS vkvideo: playable stream found for {url}', xbmc.LOGINFO)
        return f'{stream}|User-Agent={UA}&Referer={embed_url}'

    xbmc.log(f'COSMOS vkvideo: no media URLs in embed for {url}', xbmc.LOGWARNING)
    return None


# ── YouTube (Invidious-style fallback) ────────────────────────────────────
# When plugin.video.youtube is unavailable we hit a public Piped/Invidious
# instance and grab the first 720p mp4 progressive stream.
_PIPED_INSTANCES = (
    'https://pipedapi.kavin.rocks',
    'https://api-piped.mha.fi',
    'https://pipedapi.tokhmi.xyz',
    'https://pipedapi.adminforge.de',
)


def _is_youtube(url):
    h = (urlparse(url).netloc or '').lower()
    return ('youtube.com' in h) or ('youtu.be' in h)


def _yt_extract_id(url):
    parsed = urlparse(url)
    if 'youtu.be' in (parsed.netloc or ''):
        return parsed.path.lstrip('/').split('/')[0]
    qs = dict(p.split('=', 1) for p in (parsed.query or '').split('&') if '=' in p)
    if 'v' in qs:
        return qs['v']
    m = re.search(r'/embed/([A-Za-z0-9_\-]+)', parsed.path or '')
    if m:
        return m.group(1)
    return ''


def resolve_youtube_via_piped(url_or_id):
    """Resolve a YouTube URL or 11-char ID to a direct mp4 via Piped."""
    vid = url_or_id if re.fullmatch(r'[A-Za-z0-9_\-]{11}', url_or_id or '') \
        else _yt_extract_id(url_or_id)
    if not vid:
        return None
    for base in _PIPED_INSTANCES:
        body, _ = _fetch(f'{base}/streams/{vid}')
        if not body:
            continue
        try:
            data = json.loads(body)
        except ValueError:
            continue
        # videoStreams contains mp4/webm progressive (audio+video) only when
        # videoOnly=False.  Pick highest resolution progressive mp4.
        progs = [s for s in (data.get('videoStreams') or [])
                 if not s.get('videoOnly') and s.get('format') in
                 ('MPEG_4', 'WEBM', 'MP4')]
        if not progs:
            # audio+video may be split – fall back to dash hls if provided
            if data.get('hls'):
                return data['hls']
            continue
        progs.sort(key=lambda s: int(s.get('quality', '0p').rstrip('p') or 0),
                   reverse=True)
        return progs[0].get('url')
    return None


# ── vidara.so ─────────────────────────────────────────────────────────────
# Sports streaming sites embed video via https://vidara.so/e/<ID>.
# The page uses a JWPlayer-style setup with a `sources` array containing
# an HLS manifest (or mp4). We try several extraction patterns in order:
#   1. Unpacked JS: file/src key pointing at .m3u8 or .mp4
#   2. JSON API: /api/videos/<id>  →  {"sources":[{"file":"..."}]}
#   3. Generic iframe/src scan as last resort
def _is_vidara(url):
    h = (urlparse(url).netloc or '').lower().replace('www.', '')
    return h in ('vidara.so', 'vidara.to', 'gbsagbo.com')


_VIDARA_STREAM_RE = re.compile(
    r'["\']?(?:file|src|url)["\']?\s*[:=]\s*["\']'
    r'(https?://[^"\']+\.(?:m3u8|mp4)[^"\']*)["\']',
    re.IGNORECASE,
)


def _vidara_pick_best(sources):
    """Pick the best stream from a Filelions-style sources list.

    Prefers HLS (type='hls' or .m3u8 URL) then highest-label mp4.
    Returns the chosen ``file`` URL string, or '' if nothing usable.
    """
    if not isinstance(sources, list) or not sources:
        return ''
    hls = [s for s in sources if 'hls' in (s.get('type') or '')
           or '.m3u8' in (s.get('file') or '')]
    if hls:
        return hls[0].get('file') or ''
    # Sort mp4 sources by numeric label descending (e.g. "1080", "720")
    mp4 = [s for s in sources if s.get('file')]
    mp4.sort(key=lambda s: int(re.search(r'\d+', s.get('label', '0') or '0').group()), reverse=True)
    return mp4[0].get('file') or '' if mp4 else ''


def resolve_vidara(url):
    """Resolve a vidara.so /e/<ID> embed page to a direct HLS or mp4 stream.

    Tries strategies in order:
      1. POST /api/stream — JSON body {filecode, device:"web"} → streaming_url
         (the real player API discovered by reading the inline JS; this is what
         the browser uses and it returns a signed HLS URL directly)
      2. POST /api/source/<code> — form-encoded (legacy Filelions API)
      3. POST /api/source/<code> — JSON body (newer Filelions variant)
      4. GET  /api/videos/<code>, /api/embed/<code>, /api/play/<code>
      5. GET  /api/source/<code> — AES blob fallback
      6. Scrape the embed page HTML:
           a. JWPlayer .setup() sources array extraction
           b. Named regex for file/src/url keys pointing at .m3u8/.mp4
           c. Broad scan for .m3u8/.mp4 URLs anywhere in the page
           d. CDN-path scan for HLS-style paths without an explicit extension
    """
    parsed = urlparse(url)
    m = re.search(r'/(?:e|d)/([A-Za-z0-9_\-]+)', parsed.path)
    if not m:
        xbmc.log(f'COSMOS vidara: no embed ID in {url}', xbmc.LOGWARNING)
        return None
    code = m.group(1)
    host = (parsed.hostname or '').lower()
    host = host[4:] if host.startswith('www.') else host
    if host not in ('vidara.so', 'vidara.to', 'gbsagbo.com'):
        return None
    origin = 'https://' + host
    embed = f'{origin}/e/{code}'

    def _return_stream(stream, strategy):
        xbmc.log(f'COSMOS vidara: {strategy} → {stream[:80]} for {url}',
                 xbmc.LOGINFO)
        return (f'{stream}'
                f'|User-Agent={UA}'
                f'&Referer={embed}'
                f'&Origin={origin}')

    def _try_sources(data, label):
        sources = (data.get('data') or data.get('sources')
                   or (data.get('video') or {}).get('sources') or [])
        s = _vidara_pick_best(sources)
        if s:
            return _return_stream(s, label)
        # Also try AES decrypt (Filelions bysesukior-style playback blob)
        playback = data.get('playback') or (data.get('data') or {}) if not isinstance(data.get('data'), list) else {}
        if not isinstance(playback, dict):
            playback = {}
        kp  = playback.get('key_parts') or []
        iv  = playback.get('iv', '')
        pay = playback.get('payload', '')
        if kp and iv and pay:
            plaintext = _byse_try_decrypt(kp, _byse_key_slots(playback.get('version', ''), len(kp)), iv, pay)
            if plaintext is None:
                for a in range(1, len(kp) + 1):
                    b = len(kp) + 1 - a
                    if b <= a or b > len(kp):
                        continue
                    plaintext = _byse_try_decrypt(kp, [a, b], iv, pay)
                    if plaintext:
                        break
            if plaintext:
                try:
                    info = json.loads(plaintext)
                    srcs = info.get('sources') or []
                    if srcs:
                        srcs.sort(key=lambda x: int(x.get('height') or 0), reverse=True)
                        s2 = srcs[0].get('url') or srcs[0].get('file') or ''
                        if s2:
                            return _return_stream(s2, f'{label}+AES')
                except Exception:
                    pass
        return None

    # ── 1. POST /api/stream — the real player API ─────────────────────────
    # Discovered by reading the inline JS on the embed page:
    #   fetch("/api/stream", {method:"POST",
    #     headers:{"Content-Type":"application/json"},
    #     body: JSON.stringify({filecode: filecode, device: "web"})})
    # Response: {"streaming_url": "https://...", "thumbnail": "...", ...}
    _stream_body = json.dumps({'filecode': code, 'device': 'web'}).encode('utf-8')
    _stream_resp, _ = _post(
        f'{origin}/api/stream',
        data=_stream_body,
        referer=embed,
        extra_headers={
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Origin': origin,
        },
    )
    if _stream_resp:
        try:
            _stream_data = json.loads(_stream_resp)
            _su = _stream_data.get('streaming_url', '')
            if _su and _su.startswith('http'):
                xbmc.log(f'COSMOS vidara: /api/stream → {_su[:80]} for {url}',
                         xbmc.LOGINFO)
                _dblog('VIDARA-STREAM-API', _su)
                return _return_stream(_su, '/api/stream')
        except ValueError:
            pass

    # ── 2. POST /api/source/<code> — form-encoded (3 referrer variants) ───
    _referers = ['https://rugby24.net/', '', embed]
    for _vi, _r in enumerate(_referers):
        api_url = f'{origin}/api/source/{code}'
        body, _ = _post(api_url, data={'r': _r, 'd': host}, referer=embed)
        xbmc.log(f'COSMOS vidara: POST-form{_vi+1} response received', xbmc.LOGINFO)
        if body:
            try:
                result = _try_sources(json.loads(body), f'POST-form{_vi+1}')
                if result:
                    return result
            except ValueError:
                pass

    # ── 2. POST /api/source/<code> — JSON body ────────────────────────────
    for _r in ['https://rugby24.net/', '', embed]:
        json_body = json.dumps({'r': _r, 'd': host}).encode('utf-8')
        body_j, _ = _post(
            f'{origin}/api/source/{code}',
            data=json_body,
            referer=embed,
            extra_headers={'Content-Type': 'application/json',
                           'Accept': 'application/json'},
        )
        xbmc.log(f'COSMOS vidara: POST-json response received', xbmc.LOGINFO)
        if body_j:
            try:
                result = _try_sources(json.loads(body_j), 'POST-json')
                if result:
                    return result
            except ValueError:
                pass

    # ── 3. GET /api/videos/<code> ─────────────────────────────────────────
    for api_path in (f'/api/videos/{code}', f'/api/embed/{code}', f'/api/play/{code}'):
        body3, _ = _fetch(
            f'{origin}{api_path}',
            referer=embed,
            extra_headers={'Accept': 'application/json',
                           'X-Requested-With': 'XMLHttpRequest'},
        )
        if body3:
            try:
                result = _try_sources(json.loads(body3), f'GET{api_path}')
                if result:
                    return result
            except ValueError:
                pass

    # ── 4. GET /api/source/<code> — AES blob fallback ────────────────────
    body4, _ = _fetch(
        f'{origin}/api/source/{code}',
        referer=embed,
        extra_headers={'Accept': 'application/json',
                       'X-Requested-With': 'XMLHttpRequest'},
    )
    if body4:
        try:
            result = _try_sources(json.loads(body4), 'GET-api-source')
            if result:
                return result
        except ValueError:
            pass

    # ── 5. Scrape the embed page HTML ─────────────────────────────────────
    xbmc.log(f'COSMOS vidara: API failed, falling back to page scrape for {url}',
             xbmc.LOGINFO)
    html, _ = _fetch(embed, referer=origin + '/',
                     extra_headers={'Origin': origin})
    if not html:
        xbmc.log(f'COSMOS vidara: embed page fetch also failed for {url}',
                 xbmc.LOGWARNING)
        return None

    unpacked = _unpack(html) or ''
    search_text = unpacked + html
    xbmc.log(f'COSMOS vidara: HTML preview (first 600): {html[:600]}',
             xbmc.LOGINFO)
    _dblog('VIDARA-HTML', f'first 400: {html[:400]}')

    # 5a. JWPlayer sources array — grab the JSON array from .setup({sources:[...]})
    #     or from a standalone  var sources = [...]  declaration.
    for _src_pat in (
        r'\.setup\s*\(\s*\{[^}]{0,500}["\']sources["\']?\s*:\s*(\[.*?\])',
        r'(?:var\s+)?sources\s*=\s*(\[(?:[^[\]]|\[[^\[\]]*\]){1,2000}\])',
        r'["\']sources["\']?\s*:\s*(\[.*?\])',
    ):
        _sm = re.search(_src_pat, search_text, re.DOTALL | re.IGNORECASE)
        if _sm:
            try:
                _srcs = json.loads(_sm.group(1))
                _s = _vidara_pick_best(_srcs)
                if _s:
                    return _return_stream(_s, 'HTML-jwp-sources')
            except Exception:
                pass

    # 5b. Named key regex — file/src/url → .m3u8 or .mp4
    m2 = _VIDARA_STREAM_RE.search(search_text)
    if m2:
        return _return_stream(m2.group(1), 'HTML-key-regex')

    # 5c. Broad scan — any .m3u8 or .mp4 URL anywhere in the page
    m3 = re.search(
        r'(https?://[^\s"\'<>\\]+\.(?:m3u8|mp4)(?:\?[^\s"\'<>\\]*)?)',
        search_text, re.IGNORECASE,
    )
    if m3:
        return _return_stream(m3.group(1), 'HTML-broad-scan')

    # 5d. CDN-path scan — HLS-style URLs without an explicit .m3u8 extension
    #     (some Filelions CDNs serve manifests at paths like /hls2/<id>/master)
    m4 = re.search(
        r'(https?://[^\s"\'<>\\]+/(?:hls|hls2|m3u8|master|stream|playlist)'
        r'(?:/[^\s"\'<>\\]*)?(?:\?[^\s"\'<>\\]*)?)',
        search_text, re.IGNORECASE,
    )
    if m4:
        return _return_stream(m4.group(1), 'HTML-cdn-path-scan')

    xbmc.log(f'COSMOS vidara: all strategies exhausted for {url}',
             xbmc.LOGWARNING)
    return None


# ── Ownership check ───────────────────────────────────────────────────────
def is_owned(url):
    """Return True if one of our native resolvers claims this URL.

    Used by filehost.py to decide whether to skip ResolveURL after our
    resolver returns None (content gone / geo-blocked at the source),
    preventing a duplicate noisy error from ResolveURL for the same URL.
    """
    if not url:
        return False
    return (
        _is_mixdrop(url)
        or _is_doodstream(url)
        or _is_streamtape(url)
        or _is_embedwish(url)
        or _is_okru(url)
        or _is_soccerfull(url)
        or _is_bysesukior(url)
        or _is_vidara(url)
        or _is_dailymotion(url)
        or _is_megaplay(url)
        or _is_megavid(url)
        or _is_vkvideo(url)
        or _is_streameast(url)
        or _is_streamhd247(url)
        or _is_ripplestream(url)
        or _is_prostreams(url)
        or _is_streamsify(url)
        or _is_eagle_streams(url)
        or _is_mega(url)
        # Rapidgator and Nitroflare have no native Cosmos resolver. They are
        # deliberately left out so filehost.py can continue to ResolveURL,
        # which is where the user's premium credentials are configured.
        or _is_thematchrecap(url)
        or _is_fullraces(url)
        or _is_youtube(url)
    )


# ── Master resolver ───────────────────────────────────────────────────────
def resolve(url):
    """Try built-in resolvers in order. Returns playable URL or None."""
    global _last_resolver_error
    _last_resolver_error = ''          # clear before each attempt
    if not url:
        return None
    xbmc.log(f'COSMOS built-in resolver: checking {url}', xbmc.LOGDEBUG)
    _dblog('RESOLVER-CHECK', url)
    try:
        resolver_name = None
        result = None
        if _is_mixdrop(url):
            resolver_name = 'mixdrop'
            result = resolve_mixdrop(url)
        elif _is_doodstream(url):
            resolver_name = 'doodstream'
            result = resolve_doodstream(url)
        elif _is_streamtape(url):
            resolver_name = 'streamtape'
            result = resolve_streamtape(url)
        elif _is_embedwish(url):
            resolver_name = 'embedwish'
            result = resolve_embedwish(url)
        elif _is_okru(url):
            resolver_name = 'okru'
            result = resolve_okru(url)
        elif _is_soccerfull(url):
            resolver_name = 'soccerfull'
            result = resolve_soccerfull(url)
        elif _is_bysesukior(url):
            resolver_name = 'bysesukior'
            xbmc.log(f'COSMOS built-in resolver: routing to bysesukior for {url}',
                     xbmc.LOGINFO)
            _dblog('RESOLVER-DISPATCH', 'bysesukior')
            result = resolve_bysesukior(url)
        elif _is_vidara(url):
            resolver_name = 'vidara'
            xbmc.log(f'COSMOS built-in resolver: routing to vidara for {url}',
                     xbmc.LOGINFO)
            _dblog('RESOLVER-DISPATCH', 'vidara')
            result = resolve_vidara(url)
        elif _is_dailymotion(url):
            resolver_name = 'dailymotion'
            result = resolve_dailymotion(url)
        elif _is_vkvideo(url):
            resolver_name = 'vkvideo'
            result = resolve_vkvideo(url)
        elif _is_streameast(url):
            resolver_name = 'streameast'
            result = resolve_streameast(url)
        elif _is_streamhd247(url):
            resolver_name = 'streamhd247'
            _dblog('RESOLVER-DISPATCH', 'streamhd247')
            result = resolve_streamhd247(url)
        elif _is_ripplestream(url):
            resolver_name = 'ripplestream'
            _dblog('RESOLVER-DISPATCH', 'ripplestream')
            result = resolve_ripplestream(url)
        elif _is_prostreams(url):
            resolver_name = 'prostreams'
            _dblog('RESOLVER-DISPATCH', 'prostreams')
            result = resolve_prostreams(url)
        elif _is_streamsify(url):
            resolver_name = 'streamsify'
            _dblog('RESOLVER-DISPATCH', 'streamsify')
            result = resolve_streamsify(url)
        elif _is_eagle_streams(url):
            resolver_name = 'eagle-streams'
            _dblog('RESOLVER-DISPATCH', 'eagle-streams')
            result = resolve_eagle_streams(url)
        elif _is_mega(url):
            resolver_name = 'mega'
            result = resolve_mega(url)
        elif _is_thematchrecap(url):
            resolver_name = 'thematchrecap'
            xbmc.log(f'COSMOS built-in resolver: routing to thematchrecap for {url}', xbmc.LOGINFO)
            result = resolve_thematchrecap(url)
        elif _is_youtube(url):
            resolver_name = 'youtube'
            result = resolve_youtube_via_piped(url)
        elif _is_megavid(url):
            resolver_name = 'megavid'
            _dblog('RESOLVER-DISPATCH', 'megavid')
            result = resolve_megavid(url)
        elif _is_megaplay(url):
            resolver_name = 'megaplay'
            xbmc.log(f'COSMOS built-in resolver: routing to megaplay for {url}', xbmc.LOGINFO)
            _dblog('RESOLVER-DISPATCH', 'megaplay')
            result = resolve_megaplay(url)
            
        elif _is_rapidgator(url):
            resolver_name = 'rapidgator'
            _last_resolver_error = 'debrid_required_rapidgator'
            xbmc.log(f'COSMOS built-in resolver: identified Rapidgator link {url} (handled by debrid)', xbmc.LOGINFO)
            _dblog('RESOLVER-IDENTIFIED', 'Rapidgator (handled by debrid)')
            result = None  # Handled by debrid, no built-in resolution
            
        elif _is_nitroflare(url):
            resolver_name = 'nitroflare'
            _last_resolver_error = 'debrid_required_nitroflare'
            xbmc.log(f'COSMOS built-in resolver: identified Nitroflare link {url} (handled by debrid)', xbmc.LOGINFO)
            _dblog('RESOLVER-IDENTIFIED', 'Nitroflare (handled by debrid)')
            result = None  # Handled by debrid, no built-in resolution

        elif _is_uploadgig(url):
            resolver_name = 'uploadgig'
            xbmc.log(f'COSMOS built-in resolver: routing to Uploadgig for {url}', xbmc.LOGINFO)
            _dblog('RESOLVER-DISPATCH', 'uploadgig')
            result = resolve_uploadgig(url)
            
        elif _is_fullraces(url):
            resolver_name = 'fullraces'
            # No specific resolve_fullraces function, as racing.py handles scraping
            xbmc.log(f'COSMOS built-in resolver: identified fullraces.com link (handled by racing.py)', xbmc.LOGINFO)
            _dblog('RESOLVER-IDENTIFIED', 'fullraces.com (handled by racing.py)')
            result = None

        if resolver_name:
            if result:
                _dblog('RESOLVER-OK', f'{resolver_name} → {result[:120]}')
            else:
                _dblog('RESOLVER-NONE', f'{resolver_name} returned None')
        else:
            _dblog('RESOLVER-SKIP', 'no built-in resolver matched')
        return result
    except Exception as e:
        xbmc.log(f'COSMOS built-in resolver crashed for {url}: {e}',
                 xbmc.LOGERROR)
        _dblog('RESOLVER-CRASH', f'{e}')
    return None
