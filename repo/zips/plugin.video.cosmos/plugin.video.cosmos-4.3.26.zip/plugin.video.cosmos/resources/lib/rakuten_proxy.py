"""Stable local Rakuten HLS URLs with cookie retention and bounded renewal."""
import re
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit
from urllib.request import Request


class Relay:
    def __init__(self, resolve, headers, opener):
        self.resolve = resolve
        self.headers = dict(headers)
        self.opener = opener
        self.lock = threading.RLock()
        self.renew_lock = threading.Lock()
        self.stop = threading.Event()
        self.root = resolve()
        self.renewed = time.monotonic()
        self.last_attempt = float('-inf')
        self.last_access = self.renewed
        self.generation = 0
        self.routes = {}
        self.route_ids = {}
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                try:
                    with owner.lock:
                        owner.last_access = time.monotonic()
                        route = owner.routes.get(self.path)
                        if route is None:
                            self.send_error(404)
                            return
                        data, mime, status, headers = owner.fetch(route, self.headers.get('Range'))
                    self.send_response(status)
                    self.send_header('Content-Type', mime)
                    self.send_header('Content-Length', str(len(data)))
                    self.send_header('Cache-Control', 'no-store')
                    for name in ('Content-Range', 'Accept-Ranges'):
                        if headers.get(name):
                            self.send_header(name, headers[name])
                    self.end_headers()
                    self.wfile.write(data)
                except Exception as exc:
                    import xbmc
                    xbmc.log('COSMOS: Rakuten relay failed: %s' % type(exc).__name__, xbmc.LOGWARNING)
                    try:
                        self.send_error(502, 'Live stream temporarily unavailable')
                    except OSError:
                        pass

        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.server.daemon_threads = True
        self.url = self.register((), None, self.root, True)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.refresh_thread = threading.Thread(target=self.refresh_loop,
                                               name='cosmos-rakuten-token', daemon=True)
        self.refresh_thread.start()

    def renew(self, force=False):
        # Never wait behind a background renewal while holding the route lock.
        if not self.renew_lock.acquire(blocking=False):
            return False
        try:
            return self._renew(force)
        finally:
            self.renew_lock.release()

    def _renew(self, force=False):
        now = time.monotonic()
        # Serialize refreshes and suppress repeated API calls during an outage.
        if (not force and now - self.renewed < 120) or now - self.last_attempt < (5 if force else 30):
            return False
        self.last_attempt = now
        try:
            fresh = self.resolve()
            if not fresh.startswith('https://'):
                raise ValueError('Invalid Rakuten stream URL')
            # Keep the working session until its replacement is playable.
            data, _, _, _ = self.read(fresh)
            if not data.lstrip().startswith(b'#EXTM3U'):
                raise ValueError('Rakuten returned an invalid playlist')
            with self.lock:
                if self.stop.is_set():
                    return False
                self.root = fresh
                self.generation += 1
                self.renewed = time.monotonic()
            import xbmc
            xbmc.log('COSMOS: Rakuten playback token refreshed', xbmc.LOGDEBUG)
            return True
        except Exception as exc:
            import xbmc
            xbmc.log('COSMOS: Rakuten renewal failed: %s' % type(exc).__name__, xbmc.LOGWARNING)
            return False

    def refresh_loop(self):
        # Refresh independently of Kodi's playlist polling and buffering.
        while not self.stop.wait(1):
            self.renew()

    def register(self, chain, resource, upstream, playlist=False):
        # Media/key URLs must remain immutable for already-buffered playlists.
        # In particular Kodi caches keys/maps by URL across advert boundaries.
        key = (chain, resource) if playlist else (chain, resource, upstream)
        path = self.route_ids.get(key)
        if path is None:
            ext = '.m3u8' if playlist else '.' + urlsplit(upstream).path.rsplit('.', 1)[-1]
            if ext not in ('.m3u8', '.ts', '.mp4', '.m4s', '.aac', '.key'):
                ext = '.ts'
            path = '/' + secrets.token_urlsafe(24) + ext
            self.route_ids[key] = path
        self.routes[path] = (chain, resource, upstream, playlist, self.generation)
        # Bound bookkeeping for an indefinitely running channel.
        if len(self.routes) > 4000:
            for old in list(self.routes)[:1000]:
                old_route = self.routes[old]
                if old_route[1] is not None:
                    del self.routes[old]
                    self.route_ids.pop((old_route[0], old_route[1], old_route[2]), None)
        return 'http://127.0.0.1:%d%s' % (self.server.server_port, path)

    def read(self, url, byte_range=None):
        headers = dict(self.headers)
        if byte_range:
            headers['Range'] = byte_range
        with self.opener.open(Request(url, headers=headers), timeout=15) as response:
            data = response.read(32 * 1024 * 1024 + 1)
            if len(data) > 32 * 1024 * 1024:
                raise ValueError('Rakuten response too large')
            return data, response.geturl(), response.status, response.headers

    @staticmethod
    def entries(text):
        """Identify variants by ordinal and media by sequence, not session URL."""
        master = '#EXT-X-STREAM-INF:' in text
        match = re.search(r'^#EXT-X-MEDIA-SEQUENCE:(\d+)', text, re.M)
        sequence = int(match[1]) if match else 0
        match = re.search(r'^#EXT-X-DISCONTINUITY-SEQUENCE:(\d+)', text, re.M)
        discontinuity = int(match[1]) if match else 0
        variant = 0
        entries = []
        for index, line in enumerate(text.splitlines()):
            if line.strip() == '#EXT-X-DISCONTINUITY':
                discontinuity += 1
            if line and not line.startswith('#'):
                key = ('variant', variant) if master else ('segment', sequence, discontinuity)
                entries.append((index, line.strip(), key, master))
                variant += 1
                sequence += 1
            elif 'URI="' in line:
                for uri in re.findall(r'URI="([^"]+)"', line):
                    # Renditions keep their language/name identity across sessions.
                    identity = re.sub(r'URI="[^"]+"', 'URI=""', line)
                    playlist = line.startswith(('#EXT-X-MEDIA:', '#EXT-X-I-FRAME-STREAM-INF:'))
                    # Do not collapse distinct ad/programme keys or fMP4 maps
                    # just because their attributes (apart from URI) match.
                    key = ('tag', identity) if playlist else ('tag', identity, discontinuity, uri)
                    entries.append((index, uri, key, playlist))
        return entries

    def locate(self, chain, resource):
        url = self.root
        for key in chain + ((resource,) if resource is not None else ()):
            data, base, _, _ = self.read(url)
            if not data.lstrip().startswith(b'#EXTM3U'):
                raise ValueError('Rakuten returned an invalid playlist')
            entries = self.entries(data.decode('utf-8-sig'))
            match = next((e for e in entries if e[2] == key), None)
            if match is None:
                # Do not substitute an unrelated segment or encryption key.
                raise ValueError('Requested media is outside the fresh live window')
            url = urljoin(base, match[1])
        return url

    def fetch(self, route, byte_range=None):
        chain, resource, upstream, playlist, generation = route
        for attempt in range(3):
            try:
                # Buffered media can still belong to the previous session.
                # Only remap it if that URL actually fails.
                if (playlist and generation != self.generation) or attempt:
                    upstream = self.locate(chain, resource)
                    generation = self.generation
                data, base, status, headers = self.read(upstream, byte_range)
                if playlist:
                    if not data.lstrip().startswith(b'#EXTM3U'):
                        raise ValueError('Rakuten returned an invalid playlist')
                    text = data.decode('utf-8-sig')
                    lines = text.splitlines()
                    for index, uri, key, child_playlist in self.entries(text):
                        child_chain = chain + (key,) if child_playlist else chain
                        local = self.register(child_chain, None if child_playlist else key,
                                              urljoin(base, uri), child_playlist)
                        if lines[index].startswith('#'):
                            lines[index] = lines[index].replace('URI="%s"' % uri, 'URI="%s"' % local)
                        else:
                            lines[index] = local
                    data = ('\n'.join(lines) + '\n').encode('utf-8')
                    path = self.route_ids.get((chain, resource))
                    if path is not None:
                        self.routes[path] = (chain, resource, upstream, playlist, generation)
                    return data, 'application/vnd.apple.mpegurl', 200, {}
                return data, headers.get('Content-Type', 'application/octet-stream'), status, headers
            except (HTTPError, URLError, OSError, ValueError) as exc:
                if attempt == 2 or isinstance(exc, HTTPError) and exc.code not in (401, 403, 404, 408, 429, 500, 502, 503, 504):
                    raise
                self.renew(force=True)
                time.sleep(0.25 * (attempt + 1))

    def close(self):
        self.stop.set()
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.refresh_thread.join(timeout=2)

    def keep_alive(self):
        import xbmc
        monitor = xbmc.Monitor()
        player = xbmc.Player()
        try:
            while not monitor.abortRequested():
                idle = time.monotonic() - self.last_access
                if idle > 45:
                    current = player.getPlayingFile() if player.isPlayingVideo() else ''
                    if not current.startswith('http://127.0.0.1:%d/' % self.server.server_port):
                        break
                if idle > 180:
                    break
                if monitor.waitForAbort(1):
                    break
        finally:
            self.close()
