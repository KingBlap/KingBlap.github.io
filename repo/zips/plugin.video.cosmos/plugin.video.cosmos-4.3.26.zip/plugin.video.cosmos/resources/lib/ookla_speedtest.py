# -*- coding: utf-8 -*-
"""Standalone Cosmos entry point for the bundled wizard speed tester."""
from .speedtester.addon import run


__all__ = ('run',)
