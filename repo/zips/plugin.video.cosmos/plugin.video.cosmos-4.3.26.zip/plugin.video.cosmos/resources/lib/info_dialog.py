# -*- coding: utf-8 -*-
"""
CosmosInfoDialog — full-screen metadata overlay for C.O.S.M.O.S.

Opens a WindowXMLDialog showing poster, fanart, title, plot, cast,
rating, genres, runtime, and director for any content item.

Usage
-----
    from . import info_dialog as info_mod
    info_mod.open_info_dialog(meta, poster=url, fanart=url)
"""
import xbmcgui
import xbmcvfs

_ADDON_ID   = 'plugin.video.cosmos'
_ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{_ADDON_ID}/')

# Action IDs that should close the dialog
_CLOSE_IDS  = (9, 10, 92, 216, 247, 257, 13)


class CosmosInfoDialog(xbmcgui.WindowXMLDialog):
    """Full-screen metadata info dialog."""

    def __new__(cls, *args, **kwargs):
        return super().__new__(cls, *args[:4])

    def __init__(self, *args, **kwargs):
        self.meta    = kwargs.get('meta')    or {}
        self.poster  = kwargs.get('poster')  or ''
        self.fanart  = kwargs.get('fanart')  or ''

    def onInit(self):
        m = self.meta

        self.setProperty('ci_title',    m.get('title')    or '')
        self.setProperty('ci_tagline',  m.get('tagline')  or '')
        self.setProperty('ci_year',     str(m.get('year') or ''))

        rating = m.get('rating') or 0
        self.setProperty('ci_rating',   f'{float(rating):.1f}' if rating else '')

        runtime = m.get('runtime') or 0
        if runtime:
            mins = int(runtime / 60) if runtime > 120 else int(runtime)
            self.setProperty('ci_runtime', f'{mins} min')
        else:
            self.setProperty('ci_runtime', '')

        self.setProperty('ci_genre',    m.get('genre')    or '')
        self.setProperty('ci_plot',     m.get('plot')     or '')
        self.setProperty('ci_director', m.get('director') or '')

        cast = m.get('cast') or []
        if isinstance(cast, list):
            cast_str = ', '.join(cast[:8])
        else:
            cast_str = str(cast)
        self.setProperty('ci_cast',      cast_str)
        self.setProperty('ci_premiered', m.get('premiered') or '')
        self.setProperty('ci_imdb',      m.get('imdb_id')   or '')

        poster  = self.poster  or m.get('poster')  or ''
        fanart  = self.fanart  or m.get('fanart')  or ''
        self.setProperty('ci_poster',  poster)
        self.setProperty('ci_fanart',  fanart)

        try:
            self.setFocusId(9001)
        except Exception:
            pass

    def onClick(self, controlID):
        if controlID == 9001:
            self.close()

    def onAction(self, action):
        if action.getId() in _CLOSE_IDS:
            self.close()


def open_info_dialog(meta, poster='', fanart=''):
    """Create and modally show the full-screen info dialog."""
    dlg = CosmosInfoDialog(
        'CosmosInfo.xml',
        _ADDON_PATH,
        'Default',
        '720p',
        meta=meta,
        poster=poster or meta.get('poster') or '',
        fanart=fanart or meta.get('fanart') or '',
    )
    dlg.doModal()
    del dlg
