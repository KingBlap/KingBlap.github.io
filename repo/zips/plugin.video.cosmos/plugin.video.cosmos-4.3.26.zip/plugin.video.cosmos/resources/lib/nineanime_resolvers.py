# -*- coding: utf-8 -*-
"""Resolvers used only by the 9Anime addon.

These handlers are intentionally kept inside the 9Anime package.  They are
not registered with Cosmos' general resolver system and cannot affect other
Cosmos menu items.
"""

from __future__ import absolute_import, division, print_function, unicode_literals

import random
import re
import string
import time
from urllib.parse import urljoin
from urllib.request import Request
from urllib.parse import urlparse


def resolver_name(provider_url):
    host = urlparse((provider_url or "").split("|", 1)[0]).netloc.lower()
    # 9Anime currently labels these sources BYFMS/DGHG while rotating the
    # actual embed hostnames. Keep the live hosts alongside the label names.
    if "byfms" in host or "gn1r5n" in host:
        return "BYFMS"
    if "dghg" in host or "playmogo" in host:
        return "DGHG"
    return ""


def resolve(client, provider_url, provider_origin, code):
    """Resolve a known 9Anime source, or return None for unknown providers."""
    name = resolver_name(provider_url)
    if name == "BYFMS":
        return resolve_byfms(client, provider_origin, code)
    if name == "DGHG":
        return resolve_dghg(client, provider_origin, code)
    return None


def resolve_byfms(client, provider_origin, code):
    """BYFMS resolver profile used only by 9Anime source entries."""
    return client._provider_sources(
        provider_origin,
        code,
        endpoint_variants=(
            "/api/videos/{0}/embed/".format(code),
            "/api/video/{0}/embed/".format(code),
        ),
        resolver_name="BYFMS",
        pow_timeout=30.0,
    )


def resolve_dghg(client, provider_origin, code):
    """Resolve the current DGHG/Playmogo embed through its DoodStream flow."""
    try:
        return _resolve_doodstream(client, provider_origin, code)
    except Exception as dood_error:
        # Keep the former API profile as a compatibility fallback for a future
        # DGHG host rotation. The current Playmogo host no longer exposes it.
        try:
            return client._provider_sources(
                provider_origin,
                code,
                endpoint_variants=(
                    "/api/videos/{0}/embed/".format(code),
                    "/api/videos/{0}/".format(code),
                    "/api/video/{0}/embed/".format(code),
                ),
                resolver_name="DGHG",
                pow_timeout=180.0,
            )
        except Exception as api_error:
            raise RuntimeError("DGHG resolver failed: DoodStream {0}; API {1}".format(
                _short_error(dood_error), _short_error(api_error)
            ))


def _resolve_doodstream(client, provider_origin, code):
    embed_url = provider_origin.rstrip("/") + "/e/" + code
    page_request = Request(embed_url, headers={
        "User-Agent": "Kodi 9anime plugin/1.0",
        "Accept": "text/html,application/xhtml+xml",
        "Referer": "https://9anime.tech/",
    })
    with client._provider_opener.open(page_request, timeout=client.timeout) as response:
        page = response.read().decode("utf-8", "replace")

    pass_match = re.search(r"pass_md5/([^\"'?#\s]+)", page, re.I)
    if not pass_match:
        raise RuntimeError("DoodStream pass_md5 URL was not found")
    token_match = re.search(
        r"token=([A-Za-z0-9_-]{8,})",
        page[pass_match.start():pass_match.start() + 5000],
        re.I,
    )
    if not token_match:
        raise RuntimeError("DoodStream playback token was not found")

    pass_url = urljoin(embed_url, "/pass_md5/" + pass_match.group(1))
    pass_request = Request(pass_url, headers={
        "User-Agent": "Kodi 9anime plugin/1.0",
        "Accept": "*/*",
        "Referer": embed_url,
    })
    with client._provider_opener.open(pass_request, timeout=client.timeout) as response:
        media_base = response.read().decode("utf-8", "replace").strip()
    if not media_base or media_base == "RELOAD":
        raise RuntimeError("DoodStream did not return a media path")

    media_base = urljoin(embed_url, media_base)
    suffix = "".join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
    media_url = media_base + suffix + "?token={0}&expiry={1}".format(
        token_match.group(1), int(time.time() * 1000)
    )
    headers = "User-Agent=Kodi 9anime plugin/1.0&Referer={0}&Origin={1}".format(
        embed_url, provider_origin.rstrip("/")
    )
    return [media_url + "|" + headers]


def _short_error(error):
    message = str(error).replace("\r", " ").replace("\n", " ").strip()
    return message[:180] or error.__class__.__name__
