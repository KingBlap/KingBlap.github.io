# -*- coding: utf-8 -*-
"""Free WWE.com video catalogue with direct-source-only filtering."""
import html
import re
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin
from urllib.request import Request, urlopen

ARCHIVE = 'https://www.wwe.com/shows/archive'
VIDEO_CATALOGUE = 'https://www.wwe.com/videos'
BLOCKED_HOSTS = ('watch.wwe.com', 'network.wwe.com', 'peacocktv.com', 'netflix.com', 'sonyliv.com')
_SOURCE_CACHE = {}
_VIDEO_CACHE = None
_HTML_CACHE = {}
_META_CACHE = {}


def _fetch(url):
    if url in _HTML_CACHE:
        return _HTML_CACHE[url]
    request = Request(url, headers={
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-GB,en;q=0.9', 'Referer': 'https://www.wwe.com/',
    })
    with urlopen(request, timeout=8) as response:
        body = response.read().decode('utf-8', 'replace')
    _HTML_CACHE[url] = body
    return body


def _site_title(url):
    try:
        body = html.unescape(_fetch(url))
    except Exception:
        return ''
    patterns = (
        r'<meta[^>]+(?:property|name)=["\'](?:og:title|title|headline)["\'][^>]+content=["\']([^"\']+)',
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\'](?:og:title|title|headline)["\']',
        r'<h1[^>]*>(.*?)</h1>',
        r'"(?:headline|name|title|videoTitle|displayName|label)"\s*:\s*"([^"\\]{8,})"',
        r'<meta[^>]+(?:name|property)=["\'](?:description|og:description)["\'][^>]+content=["\']([^"\']+)',
        r'\'(?:headline|name|title)\'\s*:\s*\'(.*?)[\']',
        r'<title[^>]*>(.*?)</title>',
    )
    for pattern in patterns:
        match = re.search(pattern, body, re.I | re.S)
        if match:
            value = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', match.group(1))).strip()
            value = re.sub(r'\s*\|\s*WWE\s*$', '', value, flags=re.I).strip()
            if value and not re.fullmatch(r'\d+', value):
                return value
    return ''


def metadata(url, fallback_title=''):
    """Return Kodi-friendly metadata for a public WWE video page."""
    if url in _META_CACHE:
        return dict(_META_CACHE[url])
    try:
        body = html.unescape(_fetch(url))
    except Exception:
        body = ''

    def first(patterns):
        for pattern in patterns:
            match = re.search(pattern, body, re.I | re.S)
            if match:
                value = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', match.group(1))).strip()
                if value:
                    return value
        return ''

    title = _kodi_title(first((
        r'<meta[^>]+(?:property|name)=["\'](?:og:title|title|headline)["\'][^>]+content=["\']([^"\']+)',
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\'](?:og:title|title|headline)["\']',
    )) or fallback_title, url)
    plot = first((
        r'<meta[^>]+(?:name|property)=["\'](?:description|og:description)["\'][^>]+content=["\']([^"\']+)',
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:name|property)=["\'](?:description|og:description)["\']',
    ))
    thumb = first((
        r'<meta[^>]+(?:property|name)=["\']og:image["\'][^>]+content=["\']([^"\']+)',
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\']og:image["\']',
    ))
    premiered = first((
        r'<meta[^>]+(?:property|name)=["\'](?:article:published_time|date|uploadDate)["\'][^>]+content=["\']([^"\']+)',
        r'"(?:datePublished|uploadDate)"\s*:\s*"([^"]+)',
    ))
    duration = first((
        r'<meta[^>]+(?:property|name)=["\'](?:video:duration|duration)["\'][^>]+content=["\']([^"\']+)',
        r'"duration"\s*:\s*"([^"]+)',
    ))
    duration_match = re.fullmatch(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?', duration or '', re.I)
    runtime = 0
    if duration_match:
        runtime = int(float(duration_match.group(1) or 0) * 3600 +
                      float(duration_match.group(2) or 0) * 60 +
                      float(duration_match.group(3) or 0))
    meta = {
        'title': title,
        'plot': plot,
        'premiered': (premiered[:10] if re.match(r'\d{4}-\d{2}-\d{2}', premiered) else premiered),
        'year': int(premiered[:4]) if re.match(r'\d{4}', premiered) else 0,
        'runtime': runtime,
        'genre': 'Wrestling, Sports',
        'studio': 'WWE',
        'thumb': thumb,
        'fanart': thumb,
        'mediatype': 'video',
    }
    _META_CACHE[url] = dict(meta)
    return meta


def _kodi_title(title, url):
    """Keep titles readable with Kodi skins that lack a Unicode font."""
    title = re.sub(r'\s+', ' ', str(title or '')).strip()
    folded = unicodedata.normalize('NFKD', title)
    ascii_title = folded.encode('ascii', 'ignore').decode('ascii')
    ascii_title = re.sub(r"[^A-Za-z0-9&()\[\]:'.,!?+\-/ ]+", ' ', ascii_title)
    ascii_title = re.sub(r'\s+', ' ', ascii_title).strip(' -')
    # If the site title is mostly unsupported symbols, the WWE slug is the
    # most useful compatible match/fight name available to Kodi.
    if len(ascii_title) < 8 or len(ascii_title) < len(title) * 0.45:
        ascii_title = re.sub(r'[-_]+', ' ', url.rstrip('/').rsplit('/', 1)[-1])
        ascii_title = re.sub(r'[^A-Za-z0-9 ]+', ' ', ascii_title)
        ascii_title = re.sub(r'\s+', ' ', ascii_title).strip().title()
    return ascii_title or 'WWE Video'


def sources(page_url):
    """Return only direct playable media links found on a public WWE page."""
    if page_url in _SOURCE_CACHE:
        return list(_SOURCE_CACHE[page_url])
    body = html.unescape(_fetch(page_url)).replace('\\/', '/')
    found = []
    patterns = (
        r'https?://[^"\'<>\s]+?\.m3u8(?:\?[^"\'<>\s]*)?',
        r'https?://[^"\'<>\s]+?\.mp4(?:\?[^"\'<>\s]*)?',
        r'(?:contentUrl|streamUrl|videoUrl|file|src)["\'\s:=]+["\'](https?://[^"\']+?\.(?:m3u8|mp4)(?:\?[^"\']*)?)["\']',
        r'(?:youtube\.com/(?:embed/|watch\?v=)|youtu\.be/)[A-Za-z0-9_-]{6,}',
    )
    for pattern in patterns:
        for value in re.findall(pattern, body, re.I):
            value = value.rstrip('.,;)')
            if not value.startswith('http'):
                value = 'https://' + value
            if any(host in value.lower() for host in BLOCKED_HOSTS):
                continue
            if value not in found:
                found.append(value)
    _SOURCE_CACHE[page_url] = tuple(found)
    return found


def videos():
    """Return only catalogue entries that have at least one direct source."""
    global _VIDEO_CACHE
    # Rebuild when the addon is reloaded so title/parser changes are visible;
    # the source and page HTML caches still avoid duplicate network requests.
    bodies = []
    def load(page):
        try:
            return _fetch(page)
        except Exception:
            return ''
    with ThreadPoolExecutor(max_workers=1) as executor:
        bodies = list(executor.map(load, (VIDEO_CATALOGUE,)))
    candidates, seen = [], set()
    for body in bodies:
        anchors = re.findall(r'<a([^>]+href=["\']([^"\']*?/videos/[^"\']+)["\'][^>]*)>(.*?)</a>', body, re.I | re.S)
        for attrs, href, raw in anchors:
            url = urljoin(VIDEO_CATALOGUE, html.unescape(href).replace('\\/', '/'))
            if '/videos/' not in url or url in seen:
                continue
            # WWE sometimes publishes numeric placeholder links that resolve
            # to a 404 page (for example /videos/50011192), not a real video.
            slug = url.rstrip('/').rsplit('/', 1)[-1]
            if re.fullmatch(r'\d+', slug):
                continue
            title = re.sub(r'<[^>]+>', ' ', raw)
            title = re.sub(r'\s+', ' ', html.unescape(title)).strip()
            if not title or re.fullmatch(r'\d{1,3}:\d{2}', title) or re.fullmatch(r'\d+', title):
                attribute_title = re.search(
                    r'(?:title|aria-label|data-title)=["\']([^"\']+)["\']',
                    attrs, re.I,
                )
                if attribute_title:
                    title = html.unescape(attribute_title.group(1)).strip()
            if (not title or re.fullmatch(r'\d{1,3}:\d{2}', title)
                    or re.fullmatch(r'\d+', title)):
                title = _site_title(url)
            if not title:
                title = re.sub(r'[-_]+', ' ', url.rstrip('/').rsplit('/', 1)[-1]).title()
            title = _kodi_title(title, url)
            if re.fullmatch(r'\d+', title) or re.fullmatch(r'\d+', slug):
                continue
            seen.add(url)
            candidates.append((title, url))
    def playable(entry):
        try:
            return bool(sources(entry[1]))
        except Exception:
            return False
    with ThreadPoolExecutor(max_workers=16) as executor:
        playable_flags = list(executor.map(playable, candidates))
    _VIDEO_CACHE = tuple(entry for entry, ok in zip(candidates, playable_flags) if ok)
    return list(_VIDEO_CACHE)
