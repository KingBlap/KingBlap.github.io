"""Samsung TV Plus regional live-channel catalogue and HLS playback."""
import gzip
import json
from io import BytesIO
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
CHANNELS_URL = 'https://i.mjh.nz/SamsungTVPlus/.channels.json.gz'
PLAYBACK_URL = 'https://jmp2.uk/{slug}'
ICON = 'https://www.samsung.com/etc/designs/samsung/global/imgs/icon-favicon-96x96.png'

def _region():
    """Select Samsung TV Plus using Kodi's configured country automatically."""
    supported = {'US', 'GB', 'CA', 'AU', 'DE', 'AT', 'CH', 'FR', 'IT', 'ES'}
    aliases = {'IE': 'GB', 'NZ': 'AU'}
    try:
        language = xbmc.getLanguage(xbmc.ISO_639_1, True) or ''
        country = language.rsplit('-', 1)[-1].strip().upper() if '-' in language else ''
    except Exception:
        country = ''
    country = aliases.get(country, country)
    return country if country in supported else 'GB'

def _channels():
    request = Request(CHANNELS_URL, headers={'User-Agent': 'Mozilla/5.0'})
    with urlopen(request, timeout=25) as response:
        payload = gzip.GzipFile(fileobj=BytesIO(response.read())).read()
    return json.loads(payload.decode('utf-8'))


def _playback_item(data, key, channel):
    # The catalogue owns the CDN headers; individual channels may override them.
    headers = {name.lower(): value for name, value in data.get('headers', {}).items()}
    headers.update({name.lower(): value for name, value in channel.get('headers', {}).items()})
    headers.setdefault('user-agent', 'Mozilla/5.0')
    encoded_headers = urlencode(headers)
    stream = PLAYBACK_URL.format(slug=data['slug'].format(id=key))
    li = xbmcgui.ListItem(label=channel.get('name') or key,
                         path=stream + '|' + encoded_headers)
    li.setProperty('IsPlayable', 'true')
    li.setMimeType('application/vnd.apple.mpegurl')
    li.setContentLookup(False)
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_headers', encoded_headers)
    li.setProperty('inputstream.adaptive.stream_headers', encoded_headers)
    logo = channel.get('logo') or ICON
    li.setArt({'thumb': logo, 'icon': logo})
    return li


def play(handle, channel_id, region=None):
    """Resolve fresh catalogue data, including previously saved plugin links."""
    try:
        data = _channels()
        regions = data.get('regions', {})
        candidates = list(regions.values())
        if region:
            matched = next((value for key, value in regions.items()
                            if key.upper() == region.upper()), None)
            if matched is not None:
                candidates = [matched]
        channel = next((value.get('channels', {}).get(channel_id)
                        for value in candidates
                        if channel_id in value.get('channels', {})), None)
        if channel is None:
            raise ValueError('Channel is no longer in the Samsung TV Plus catalogue')
        if channel.get('license_url'):
            raise ValueError('This channel requires unsupported DRM playback')
        xbmcplugin.setResolvedUrl(handle, True, _playback_item(data, channel_id, channel))
    except Exception as exc:
        xbmc.log('COSMOS: Samsung TV Plus playback failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Samsung TV Plus', 'Unable to play this live channel.',
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def _guide(data, wanted, icon):
    from .samsungtvplus_picker import normalize
    regions = data.get('regions', {})
    region_key = next((key for key in regions if key.upper() == wanted.upper()), None)
    if region_key is None:
        region_key = next((key for key in regions if key.upper() == 'GB'), None)
    records = regions.get(region_key, {}).get('channels', {}) if region_key else {}
    channels = [normalize(key, channel, icon) for key, channel in records.items()
                if not channel.get('license_url')]
    if not channels:
        raise ValueError('No playable Samsung TV Plus channels for region %s' % wanted)
    return region_key, sorted(channels, key=lambda c: int(c.get('channel_number') or 99999))


def root(handle, icon=ICON):
    try:
        from . import samsungtvplus_picker
        data = _channels()
        region, channels = _guide(data, _region(), icon)

        def refresh():
            nonlocal data
            updated = _channels()
            _, rows = _guide(updated, region, icon)
            data = updated
            return rows

        selected = samsungtvplus_picker.show(channels, region, icon, refresh)
        if selected is None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        item = _playback_item(data, selected['id'], selected['source'])
        item.setInfo('video', samsungtvplus_picker.channel_link(selected, icon)['info'])
        xbmcplugin.setResolvedUrl(handle, True, item)
    except Exception as exc:
        xbmc.log('COSMOS: Samsung TV Plus failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Samsung TV Plus', 'Unable to load live channels.', xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
