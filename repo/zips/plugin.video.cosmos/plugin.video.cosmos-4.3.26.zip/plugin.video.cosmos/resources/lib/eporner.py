# -*- coding: utf-8 -*-
"""Eporner catalogue and direct-source parser for the protected Adult Lounge."""
import html
import json
import re
import time
from urllib.parse import quote_plus, urlencode, urljoin
from urllib.request import Request, urlopen

BASE_URL = 'https://www.eporner.com/'
# Use a high-resolution logo for Kodi skins; the site favicon is only a tiny
# bitmap and becomes visibly pixelated when used as poster/icon artwork.
ICON = 'https://images.seeklogo.com/logo-png/52/1/eporner-logo-png_seeklogo-527177.png'
FAVICON = 'https://www.eporner.com/favicon.ico'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36'
_CACHE = {}
_META_CACHE = {}


def clear_cache():
    _CACHE.clear()
    _META_CACHE.clear()


def fetch(url, referer=BASE_URL, timeout=20):
    cached = _CACHE.get(url)
    if cached and time.time() - cached[0] < 180:
        return cached[1]
    request = Request(url, headers={'User-Agent': USER_AGENT, 'Referer': referer or BASE_URL,
                                    'Accept-Language': 'en-GB,en;q=0.8'})
    with urlopen(request, timeout=timeout) as response:
        body = response.read().decode('utf-8', 'replace')
    _CACHE[url] = (time.time(), body)
    return body


def _api_search(page=1, order='latest'):
    """Use the public API when available; return [] if the site requires a key."""
    url = ('https://www.eporner.com/api/v2/video/search/?format=json&per_page=24'
           '&thumbsize=big&query=all&page=%d&order=%s' % (max(int(page), 1), order))
    try:
        data = json.loads(fetch(url))
    except Exception:
        return []
    rows = data.get('videos') if isinstance(data, dict) else data
    if not isinstance(rows, list):
        return []
    result = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        video_url = row.get('url') or row.get('embed') or row.get('embed_url')
        if not video_url:
            video_id = row.get('id') or row.get('video_id')
            if video_id:
                video_url = BASE_URL + 'video-' + str(video_id) + '/'
        if video_url:
            result.append({'title': html.unescape(str(row.get('title') or 'Eporner video')).strip(),
                           'url': urljoin(BASE_URL, video_url),
                           'thumb': row.get('default_thumb') or row.get('thumb') or row.get('thumbnail') or '',
                           'duration': str(row.get('length') or row.get('duration') or '')})
    return result


def parse_listing(document, page_url=BASE_URL):
    items, seen = [], set()
    for href, raw in re.findall(r'<a\b[^>]+href=["\']([^"\']+)["\'][^>]*>([\s\S]*?)</a>', document or '', re.I):
        url = urljoin(page_url, html.unescape(href))
        if not re.search(r'/video(?:s)?[-/]', url, re.I) or url in seen:
            continue
        body = raw
        image = re.search(r'<img\b[^>]*(?:src|data-src)=["\']([^"\']+)', body, re.I)
        title = re.sub(r'<[^>]+>', ' ', body)
        title = re.sub(r'\s+', ' ', html.unescape(title)).strip()
        if not title:
            title = re.sub(r'[-_]+', ' ', url.rstrip('/').rsplit('/', 1)[-1]).title()
        if title.casefold() in {
                'français', 'francais', 'español', 'espanol',
                'português', 'portugues', 'italiano', 'english',
                'filipino', 'deutsch', 'women', 'men', 'next', 'previous'}:
            continue
        if not re.search(r'[A-Za-z0-9]', title) or title.isdigit():
            continue
        seen.add(url)
        items.append({'title': title, 'url': url,
                      'thumb': urljoin(page_url, html.unescape(image.group(1))) if image else '',
                      'duration': ''})
    return items[:24], bool(items)


def parse_categories(document, page_url=BASE_URL):
    categories, seen = [], set()
    for href, raw in re.findall(r'<a\b[^>]+href=["\']([^"\']+)["\'][^>]*>([\s\S]*?)</a>', document or '', re.I):
        url = urljoin(page_url, html.unescape(href))
        if '/cats/' not in url.lower() or url.rstrip('/').lower().endswith('/cats') or url in seen:
            continue
        title = re.sub(r'<[^>]+>', ' ', raw)
        title = re.sub(r'\s+', ' ', html.unescape(title)).strip()
        slug = url.rstrip('/').rsplit('/', 1)[-1]
        # The index contains A-Z navigation folders; those are not content
        # categories and should not appear in the addon submenu.
        if (not title or len(title) > 80 or title.casefold() in {'categories', 'more'}
                or (len(slug) == 1 and slug.isalpha())
                or (len(title) == 1 and title.isalpha())):
            continue
        seen.add(url)
        categories.append({'title': title, 'url': url})
    return categories


def parse_pornstars(document, page_url=BASE_URL):
    performers, seen = [], set()
    for href, raw in re.findall(r'<a\b[^>]+href=["\']([^"\']+)["\'][^>]*>([\s\S]*?)</a>', document or '', re.I):
        url = urljoin(page_url, html.unescape(href))
        if '/pornstar' not in url.lower() or url.rstrip('/').lower().endswith('pornstar-list') or url in seen:
            continue
        title = re.sub(r'<[^>]+>', ' ', raw)
        title = re.sub(r'\s+', ' ', html.unescape(title)).strip()
        # The index appends numeric rank values and chevrons to names.
        title = re.sub(r'\d+', '', title)
        title = re.sub(r'\s+', ' ', title).strip(' »>')
        image = re.search(r'<img\b[^>]*(?:src|data-src)=["\']([^"\']+)', raw, re.I)
        image = re.search(r'<img\b[^>]*(?:src|data-src)=["\']([^"\']+)', raw, re.I)
        slug = url.rstrip('/').rsplit('/', 1)[-1]
        navigation_titles = {
            'pornstars', 'pornstar list', 'suggest new pornstar',
            'women', 'men', 'all', 'next', 'previous',
            'english', 'filipino',
            'français', 'francais', 'español', 'espanol', 'português', 'portugues',
            'deutsch', 'italiano', 'italiano', 'русский', '日本語', '中文', '한국어',
        }
        language_slug = slug.casefold()
        if (not title or title.isdigit() or len(title) > 100 or title.casefold() in navigation_titles
                or not re.search(r'[A-Za-z0-9]', title)
                or title in {'×', 'x'} or language_slug in {
                    'francais', 'français', 'espanol', 'español',
                    'portugues', 'português', 'italiano', 'deutsch',
                    'russian', 'japanese', 'chinese', 'korean'}
                or (len(slug) == 1 and slug.isalpha())):
            continue
        seen.add(url)
        performers.append({'title': title, 'url': url,
                           'thumb': urljoin(page_url, html.unescape(image.group(1))) if image else ''})
    return performers


def parse_channels(document, page_url=BASE_URL):
    channels, seen = [], set()
    for href, raw in re.findall(r'<a\b[^>]+href=["\']([^"\']+)["\'][^>]*>([\s\S]*?)</a>', document or '', re.I):
        url = urljoin(page_url, html.unescape(href))
        if '/channel' not in url.lower() or url.rstrip('/').lower().endswith('channels') or url in seen:
            continue
        title = re.sub(r'<[^>]+>', ' ', raw)
        title = re.sub(r'\s+', ' ', html.unescape(title)).strip()
        title = re.sub(r'\d+', '', title)
        title = re.sub(r'\s+', ' ', title).strip(' »>')
        image = re.search(r'<img\b[^>]*(?:src|data-src)=["\']([^"\']+)', raw, re.I)
        if (not title or len(title) > 100 or not re.search(r'[A-Za-z0-9]', title)
                or title.casefold() in {'channels', 'channel list', 'next', 'previous'}):
            continue
        seen.add(url)
        channels.append({'title': title, 'url': url,
                         'thumb': urljoin(page_url, html.unescape(image.group(1))) if image else ''})
    return channels


def listing(page=1, order='latest'):
    api_items = _api_search(page, order)
    if api_items:
        return api_items, page < 1000
    url = BASE_URL if int(page or 1) == 1 else urljoin(BASE_URL, 'latest/%d/' % int(page))
    items, has_items = parse_listing(fetch(url), url)
    return items, has_items


def metadata(page_url, fallback_title=''):
    if page_url in _META_CACHE:
        return dict(_META_CACHE[page_url])
    try:
        body = html.unescape(fetch(page_url))
    except Exception:
        body = ''
    def first(patterns):
        for pattern in patterns:
            match = re.search(pattern, body, re.I | re.S)
            if match:
                value = re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', match.group(1))).strip()
                if value:
                    return value
        return ''
    title = first((r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']+)', r'<h1[^>]*>(.*?)</h1>')) or fallback_title
    thumb = first((r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)',))
    plot = first((r'<meta[^>]+(?:name|property)=["\'](?:description|og:description)["\'][^>]+content=["\']([^"\']+)',))
    duration = first((r'<meta[^>]+(?:property|name)=["\'](?:video:duration|duration)["\'][^>]+content=["\']([^"\']+)',
                      r'"duration"\s*:\s*"([^"]+)',
                      r'class=["\'][^"\']*(?:duration|video-length)[^"\']*["\'][^>]*>(.*?)</'))
    duration_match = re.fullmatch(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?', duration or '', re.I)
    if duration_match:
        duration = int(float(duration_match.group(1) or 0) * 3600 +
                      float(duration_match.group(2) or 0) * 60 +
                      float(duration_match.group(3) or 0))
    else:
        clock = re.fullmatch(r'(\d+):([0-5]\d)(?::([0-5]\d))?', str(duration or '').strip())
        duration = (int(clock.group(1)) * 60 + int(clock.group(2)) if clock and not clock.group(3)
                    else int(clock.group(1)) * 3600 + int(clock.group(2)) * 60 + int(clock.group(3))
                    if clock else 0)
    published = first((r'<meta[^>]+(?:property|name)=["\'](?:article:published_time|datePublished|uploadDate)["\'][^>]+content=["\']([^"\']+)',
                       r'"(?:datePublished|uploadDate)"\s*:\s*"([^"]+)'))
    rating = first((r'"(?:ratingValue|rating)"\s*:\s*"?([0-9]+(?:\.[0-9]+)?)',
                    r'(?:rating|score)["\'\s:=]+([0-9]+(?:\.[0-9]+)?)'))
    meta = {'title': title, 'plot': plot, 'genre': 'Adult', 'studio': 'Eporner',
            'thumb': thumb, 'fanart': thumb, 'mediatype': 'video',
            'runtime': duration, 'duration': duration,
            'premiered': published[:10] if re.match(r'\d{4}-\d{2}-\d{2}', published) else published,
            'year': int(published[:4]) if re.match(r'\d{4}', published) else 0,
            'rating': float(rating) if rating else 0.0}
    _META_CACHE[page_url] = dict(meta)
    return meta


def sources(page_url):
    body = html.unescape(fetch(page_url)).replace('\\/', '/')
    found = []
    # Eporner's player requests signed source data through its xhr endpoint.
    # Those URLs are time/entry dependent; prefer them over the older inline
    # gvideo URLs, which commonly return HTTP 403 in Kodi.
    video_id = re.search(r'/(?:video-|embed/|hd-porn/)([A-Za-z0-9_-]+)', page_url, re.I)
    page_hash = re.search(r'\bhash\s*[:=]\s*["\']([0-9a-f]{32})', body, re.I)
    if video_id and page_hash:
        def base36(value):
            alphabet = '0123456789abcdefghijklmnopqrstuvwxyz'
            result = ''
            while value:
                value, remainder = divmod(value, 36)
                result = alphabet[remainder] + result
            return result or '0'
        digest = page_hash.group(1)
        encoded_hash = ''.join(base36(int(digest[offset:offset + 8], 16)) for offset in range(0, 32, 8))
        xhr_url = 'https://www.eporner.com/xhr/video/%s?%s' % (
            video_id.group(1), urlencode({'hash': encoded_hash, 'device': 'generic',
                                          'domain': 'www.eporner.com', 'fallback': 'false'}))
        try:
            payload = json.loads(fetch(xhr_url, referer=page_url))
            xhr_sources = payload.get('sources', {}) if isinstance(payload, dict) else {}
            for kind, formats in xhr_sources.items():
                if not isinstance(formats, dict):
                    continue
                for format_data in formats.values():
                    if not isinstance(format_data, dict):
                        continue
                    value = format_data.get('src') or format_data.get('url') or ''
                    if value.startswith('http') and value not in found:
                        found.append(value)
            if found:
                return found
        except Exception:
            pass
    patterns = (r'https?://[^"\'<>\s]+?\.m3u8(?:\?[^"\'<>\s]*)?',
                r'https?://[^"\'<>\s]+?\.mp4(?:\?[^"\'<>\s]*)?',
                r'(?:file|src|video_url|videoUrl|contentUrl)["\'\s:=]+["\'](https?://[^"\']+)["\']')
    for pattern in patterns:
        for value in re.findall(pattern, body, re.I):
            value = html.unescape(value).rstrip('.,;)')
            if value not in found and re.search(r'\.(?:m3u8|mp4)(?:\?|$)', value, re.I):
                found.append(value)
    # Current Eporner pages can put the player in an iframe/embed document;
    # follow that document when the outer page contains no direct media URL.
    if not found:
        embeds = re.findall(
            r'<iframe[^>]+src=["\']([^"\']+)|(?:embedUrl|embed_url|embed)["\']?\s*[:=]\s*["\']([^"\']+)',
            body, re.I)
        for pair in embeds:
            embed = next((html.unescape(value) for value in pair if value), '')
            if not embed:
                continue
            embed = urljoin(page_url, embed.replace('\\/', '/'))
            try:
                embedded_body = html.unescape(fetch(embed, referer=page_url)).replace('\\/', '/')
            except Exception:
                continue
            for pattern in patterns:
                for value in re.findall(pattern, embedded_body, re.I):
                    value = html.unescape(value).rstrip('.,;)')
                    if value not in found and re.search(r'\.(?:m3u8|mp4)(?:\?|$)', value, re.I):
                        found.append(value)
    return found


def kodi_stream_url(url, referer):
    return '%s|User-Agent=%s&Referer=%s' % (url, quote_plus(USER_AGENT), quote_plus(referer))
