"""Native MusicMP3.ru catalogue browser for Cosmos.

The module only follows MusicMP3.ru pages and hands site-provided audio URLs
to Kodi; it does not mirror or cache the catalogue.
"""
import html
import json
import os
import re
from urllib.parse import urlencode, urljoin, urlparse, parse_qs, urlunparse
from urllib.request import Request, build_opener, HTTPCookieProcessor
from http.cookiejar import CookieJar
import xbmcvfs

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

BASE = 'https://musicmp3.ru/'
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36')
_COOKIES = CookieJar()
_OPENER = build_opener(HTTPCookieProcessor(_COOKIES))
_SEARCH_RETURN = False
_WINDOW_STATE = xbmcgui.Window(10000)

def _library_path():
    path = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/musicmp3_library.json')
    folder = os.path.dirname(path)
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    return path

def _library():
    try:
        with open(_library_path(), 'r', encoding='utf-8') as stream:
            data = json.load(stream)
        return {'favorites': data.get('favorites', []), 'recent': data.get('recent', []),
                'search_history': data.get('search_history', [])}
    except Exception:
        return {'favorites': [], 'recent': [], 'search_history': []}

def _save_library(data):
    with open(_library_path(), 'w', encoding='utf-8') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)

def _clear_library(kind):
    data = _library(); data[kind] = []; _save_library(data)

def _add_search_history(query, category):
    data = _library(); key = (query.casefold(), category)
    history = [item for item in data.get('search_history', [])
               if (item.get('query', '').casefold(), item.get('category', 'songs')) != key]
    history.insert(0, {'query': query, 'category': category})
    data['search_history'] = history[:30]
    _save_library(data)

def _library_key(row):
    return str(row.get('track_id') or row.get('rel') or row.get('url') or row.get('title') or '').strip()

def _toggle_favorite(row):
    data = _library(); key = _library_key(row)
    was_favorite = any(_library_key(item) == key for item in data['favorites'])
    data['favorites'] = [item for item in data['favorites'] if _library_key(item) != key]
    if not was_favorite:
        data['favorites'].insert(0, row)
    _save_library(data)

def _remember_play(row):
    data = _library(); key = _library_key(row)
    data['recent'] = [item for item in data['recent'] if _library_key(item) != key]
    data['recent'].insert(0, row)
    data['recent'] = data['recent'][:50]
    _save_library(data)

def _get(url):
    request = Request(url, headers={'User-Agent': UA, 'Referer': BASE})
    with _OPENER.open(request, timeout=15) as response:
        return response.read().decode('utf-8', 'replace')

def _boo(value):
    """Port MusicMP3's JavaScript boo() hash exactly enough for URLs."""
    mask = 0xffffffff
    a, c, b = 1234554321, 7, 305419896
    value = value[5:] if value.startswith(('track', 'song_')) else value
    for char in value:
        f = ord(char) & 255
        a = (a ^ (((a & 63) + c) * f + (a << 8))) & mask
        b = (b + ((b << 8) ^ a)) & mask
        c = (c + f) & mask
    a &= 0x7fffffff
    b &= 0x7fffffff
    ah, bh = format(a, 'x'), format(b, 'x')
    # The JavaScript uses substring(d.length - 4) on a four-zero-prefixed
    # value, yielding eight characters per half (not four).
    return ('00000000' + ah)[-8:] + ('00000000' + bh)[-8:]

def _signed_stream(page, track_id, token):
    host = next(iter(re.findall(r'<table[^>]+class=["\'][^"\']*tracklist[^"\']*["\'][^>]+data-url=["\']([^"\']+)', page, re.I)), 'https://listen.musicmp3.ru')
    session = next((c.value for c in _COOKIES if c.name == 'SessionId'), '')
    if not session or not token:
        return ''
    stream = host.rstrip('/') + '/' + _boo(track_id + session[8:]) + '/' + token
    # Kodi invokes the playback route separately, so preserve the session
    # cookie on the media URL instead of relying on this module's memory.
    return stream

def _clean(value):
    value = re.sub(r'<[^>]+>', ' ', value or '')
    return re.sub(r'\s+', ' ', html.unescape(value)).strip()

def _url(value):
    return urljoin(BASE, html.unescape(value or '').replace('\\/', '/'))

def _content_key(value):
    parsed = urlparse(value)
    path = parsed.path.rstrip('/').casefold()
    return path or '/'

def _rows(page, pattern):
    return re.findall(pattern, page, re.I | re.S)

def _items(page, mode):
    """Extract the stable class names used by MusicMP3.ru's markup."""
    output = []
    if mode == 'search' or re.search(r'(?:<tr[^>]+class=["\'][^"\']*song|song__name|song__play_button)', page, re.I):
        for block in _rows(page, r'<tr[^>]+class=["\'][^"\']*song[^"\']*["\'][\s\S]*?</tr>'):
            row_id = next(iter(_rows(block, r'<tr[^>]+id=["\']([^"\']+)["\']')), '')
            artist = _clean(next(iter(_rows(block, r'class=["\'][^"\']*song__artist(?:--search)?[^"\']*["\'][^>]*>(.*?)</')), ''))
            title = _clean(next(iter(_rows(block, r'class=["\'][^"\']*song__name(?:--search)?[^"\']*["\'][^>]*>(.*?)</')), ''))
            # Search results expose the player URL through the anchor's
            # ``rel`` attribute; newer markup may use data-url/data-src.
            play_cell = next(iter(_rows(block, r'<[^>]+class=["\'][^"\']*song__play_button[^"\']*["\'][^>]*>([\s\S]*?)</(?:td|div)>')), block)
            if not play_cell:
                play_cell = block
            stream = next(iter(_rows(play_cell, r'(?:rel|data-url|data-src)=["\']([^"\']+)["\']')), '')
            if not stream:
                stream = next(iter(_rows(block, r'(?:rel|data-url|data-src)=["\']([^"\']+)["\']')), '')
            stream = stream.strip()
            if not re.search(r'\.(?:mp3|m4a|aac)(?:$|[?#])', stream, re.I):
                stream = next(iter(_rows(play_cell, r'(https?[^"\' ]+\.(?:mp3|m4a|aac)(?:\?[^"\']*)?)')), '')
            if title or artist:
                # ``rel`` is the listener token, not a musicmp3.ru page URL.
                # The site's compatible stream endpoint is listen.musicmp3.ru.
                # Search rows use the rel token as the authoritative ID.
                # The resolver expects the same five-character prefix used by
                # the site's search implementation, then hashes the suffix.
                if mode == 'search' and re.fullmatch(r'[0-9a-f]{16}', stream or '', re.I):
                    track_id = 'song_' + stream
                elif not row_id and stream:
                    track_id = 'song_' + stream
                else:
                    track_id = row_id if row_id.startswith(('track', 'song_')) else 'track' + str(len(output) + 1)
                if re.fullmatch(r'[0-9a-f]{16}', stream or '', re.I):
                    stream_url = _signed_stream(page, track_id, stream)
                else:
                    stream_url = _url(stream)
                album = _clean(next(iter(_rows(block, r'itemprop=["\']inAlbum["\'][^>]*content=["\']([^"\']+)')), ''))
                output.append({'title': title or artist, 'artist': artist,
                               'album': album, 'url': stream_url,
                               'stream': bool(stream), 'track_id': track_id,
                               'rel': stream})
    else:
        # Album pages expose the album and artist as separate anchors inside
        # one card. Build one Kodi row from the album URL and its nearby
        # artist link instead of showing duplicate-looking entries.
        album_links = _rows(page, r'<a[^>]+href=["\']([^"\']*__album_[^"\']+)["\'][^>]*>(.*?)</a>')
        seen = set()
        for href, label in album_links:
            full = _url(href)
            if full in seen:
                continue
            seen.add(full)
            pos = page.find(href)
            nearby = page[pos:pos + 1800] if pos >= 0 else ''
            artist = next(iter(_rows(nearby, r'<a[^>]+href=["\']/artist[^"\']+["\'][^>]*>(.*?)</a>')), '')
            album = _clean(label)
            artist = _clean(artist)
            output.append({'title': '%s - %s' % (artist, album) if artist else album,
                           'url': full})
        if output:
            return output
        seen = set()
        for href, label in _rows(page, r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>'):
            label = _clean(label)
            full = _url(href)
            # Ignore the site's repeated header navigation; only expose
            # content links from the current catalogue page.
            if (label and href not in ('/artists.html', '/genres.html',
                                       '/new_albums.html', '/top.html') and
                    (mode != 'artists' or (href.startswith('/artist_') and '__album_' not in href)) and
                    href.startswith(('/artist', '/album', '/music')) and full not in seen):
                seen.add(full)
                output.append({'title': label, 'url': full})
    if (not output or not any(row.get('stream') for row in output)) and re.search(r'itemprop=["\']name["\']', page, re.I):
        # Current album markup: the play anchor carries only a 16-character
        # token while the title is a schema.org itemprop name.
        output = []
        for block in re.findall(r'<tr[^>]*class=["\'][^"\']*song[^"\']*["\'][\s\S]*?</tr>', page, re.I):
            row_id = next(iter(re.findall(r'<tr[^>]+id=["\']([^"\']+)["\']', block, re.I)), '')
            token = next(iter(re.findall(r'(?:rel|data-rel)=["\']([0-9a-f]{16})["\']', block, re.I)), '')
            title = _clean(next(iter(re.findall(r'itemprop=["\']name["\'][^>]*>(.*?)</', block, re.I | re.S)), ''))
            artist = _clean(next(iter(re.findall(r'itemprop=["\']byArtist["\'][^>]*content=["\']([^"\']+)', block, re.I)), ''))
            if not artist:
                artist = _clean(next(iter(re.findall(r'class=["\'][^"\']*song__artist--search[^"\']*["\'][^>]*>(.*?)</', block, re.I | re.S)), ''))
            album = _clean(next(iter(re.findall(r'itemprop=["\']inAlbum["\'][^>]*content=["\']([^"\']+)', block, re.I)), ''))
            if not title:
                title = _clean(next(iter(re.findall(r'class=["\'][^"\']*song__name(?:--search)?[^"\']*["\'][^>]*>[\s\S]*?(?:<a[^>]*>)?([^<]+)', block, re.I)), ''))
            if not album:
                album = _clean(next(iter(re.findall(r'class=["\'][^"\']*song__album--search[^"\']*["\'][^>]*>[\s\S]*?(?:<a[^>]*>)?([^<]+)', block, re.I)), ''))
            if title:
                if not row_id and token:
                    row_id = 'song_' + token
                track_id = row_id if row_id.startswith(('track', 'song_')) else 'track' + str(len(output) + 1)
                output.append({'title': title, 'artist': artist, 'album': album,
                               'url': _signed_stream(page, track_id, token) if token else '',
                               'stream': bool(token), 'track_id': track_id, 'rel': token})
    return output

# MusicMP3's catalogue groups artists by these stable genre IDs.
GENRES = {
    'World': [('World','0'),('Celtic','3'),('Jewish','14'),('African','23'),('Arabic','79'),('Latin','268')],
    'Classical': [('Classical','313'),('Baroque Period','314'),('Chamber','315'),('Opera','343'),('Orchestral','348')],
    'Metal': [('Metal','355'),('Alternative Metal','356'),('Black Metal','360'),('Death Metal','365'),('Heavy Metal','387'),('Power Metal','396'),('Progressive Metal','397')],
    'Alternative': [('Alternative','408'),('Britpop','409'),('Grunge','412'),('Indie Rock','414'),('Punk Rock','436')],
    'Rock': [('Rock','473'),('Art Rock','474'),('Christian Rock','481'),('Comedy Rock','482'),('Folk Rock','483'),('Glam Rock','489'),('Hard Rock','491'),('Progressive Rock','494'),('Psychedelic Rock','500'),('Rock & Roll','507'),('Southern Rock','515'),('Rockabilly','516')],
    'R&B': [('R&B','517'),('Contemporary R&B','518'),('Funk','520'),('Soul','525'),('Neo-Soul','538')],
    'Dance': [('Dance','539'),('Dance Pop','543'),('Disco','551'),('Eurodance','557')],
    'Pop': [('Pop','558'),('Adult Contemporary','559'),('Euro Pop','562'),('Indie Pop','567'),('Pop Rock','571'),('New Wave','582')],
    'Jazz': [('Jazz','596'),('Acid Jazz','597'),('Bebop','600'),('Big Band','603'),('Jazz Fusion','607'),('Vocal Jazz','613')],
    'Hip Hop': [('Hip Hop','623'),('Alternative Hip Hop','624'),('East Coast Hip Hop','630'),('Pop Rap','639'),('UK Hip Hop','652'),('West Coast Hip Hop','653')],
    'Electronic': [('Electronic','654'),('Breakbeat','655'),('Drum and Bass','664'),('House','698'),('Techno','720'),('Trance','728'),('Dubstep','749')],
    'Country': [('Country','750'),('Alternative Country','751'),('Country Pop','756'),('Traditional Country','759'),('Country Rock','770')],
    'Blues': [('Blues','774'),('Acoustic Blues','775'),('Electric Blues','780'),('Blues Rock','786')],
    'Soundtracks': [('Soundtracks','0'),('Movie Soundtracks','789'),('TV Soundtracks','792'),('Game Soundtracks','794')],
}

def _artist_rows(url):
    page = _get(url)
    rows, seen = [], set()
    for href, label in re.findall(r'<a[^>]+href=["\']([^"\']*?/artist_[^"\']+)["\'][^>]*>(.*?)</a>', page, re.I | re.S):
        full = _url(href)
        name = _clean(label)
        if name and full not in seen:
            seen.add(full)
            pos = page.find(href)
            nearby = page[max(0, pos - 1200):pos + 1200] if pos >= 0 else ''
            image = next(iter(re.findall(r'<img[^>]+(?:src|data-src)=["\']([^"\']+)["\']', nearby, re.I)), '')
            rows.append({'title': name, 'url': full, 'image': _url(image) if image else ''})
    return rows

def _page_url(url, page):
    parsed = urlparse(url)
    query = parse_qs(parsed.query)
    query['page'] = [str(page)]
    return urlunparse(parsed._replace(query=urlencode(query, doseq=True)))

def _artist_album_rows(url):
    page = _get(url)
    artist = _clean(next(iter(re.findall(r'<[^>]+class=["\'][^"\']*page_title__h1[^"\']*["\'][^>]*>(.*?)</', page, re.I | re.S)), ''))
    if not artist:
        artist = _clean(next(iter(re.findall(r'<title[^>]*>(.*?)</title>', page, re.I | re.S)), ''))
        artist = re.sub(r'\s*[-|].*$', '', artist).strip()
    rows, seen = [], set()
    # Keep the title and URL inside the same album_report link. Parsing all
    # anchors on the page causes adjacent album cards to be merged together.
    pattern = (r'<a(?=[^>]*class=["\'][^"\']*album_report__link[^"\']*["\'])'
               r'(?=[^>]*href=["\'])(?:[^>])*href=["\']([^"\']+)["\'][^>]*>([\s\S]*?)</a>')
    for href, body in re.findall(pattern, page, re.I):
        full = _url(href)
        name = _clean(next(iter(re.findall(r'class=["\'][^"\']*album_report__name[^"\']*["\'][^>]*>(.*?)</', body, re.I | re.S)), body))
        key = _content_key(full)
        if key in seen or not name:
            continue
        seen.add(key)
        rows.append({'title': ('%s — %s' % (artist, name)) if artist else name,
                     'url': full})
    return rows

def _search_rows(page, category):
    if category == 'songs':
        rows, seen = [], set()
        for block in re.findall(r'<tr[^>]+class=["\'][^"\']*song[^"\']*["\'][\s\S]*?</tr>', page, re.I):
            token = next(iter(re.findall(r'(?:rel|data-rel)=["\']([^"\']+)["\']', block, re.I)), '').strip()
            if not token or token.lower().startswith(('http://', 'https://')):
                continue
            track_id = next(iter(re.findall(r'<tr[^>]+id=["\']([^"\']+)["\']', block, re.I)), '')
            if not track_id:
                track_id = 'song_' + token
            title = _clean(next(iter(re.findall(r'itemprop=["\']name["\'][^>]*>(.*?)</', block, re.I | re.S)), ''))
            if not title:
                title = _clean(next(iter(re.findall(r'class=["\'][^"\']*song__name(?:--search)?[^"\']*["\'][^>]*>[\s\S]*?(?:<a[^>]*>)?([^<]+)', block, re.I)), ''))
            artist = _clean(next(iter(re.findall(r'itemprop=["\']byArtist["\'][^>]*content=["\']([^"\']+)', block, re.I)), ''))
            if not artist:
                artist = _clean(next(iter(re.findall(r'class=["\'][^"\']*song__artist--search[^"\']*["\'][^>]*>[\s\S]*?(?:<a[^>]*>)?([^<]+)', block, re.I)), ''))
            album = _clean(next(iter(re.findall(r'itemprop=["\']inAlbum["\'][^>]*content=["\']([^"\']+)', block, re.I)), ''))
            key = (track_id.casefold(), token.casefold())
            if title and key not in seen:
                seen.add(key)
                rows.append({'title': title, 'artist': artist, 'album': album,
                             'url': '', 'stream': True, 'track_id': track_id,
                             'rel': token})
        return rows
    rows, seen = [], set()
    if category == 'artists':
        pattern = r'<[^>]+class=["\'][^"\']*artist_preview[^"\']*["\'][\s\S]*?<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>'
        for href, label in re.findall(pattern, page, re.I):
            if '__album_' in href or not re.search(r'(?:/artist[_/]|artist_)', href, re.I):
                continue
            full = _url(href); key = _content_key(full); name = _clean(label)
            if name and key not in seen:
                seen.add(key); rows.append({'title': name, 'url': full})
    else:
        pattern = (r'<[^>]+class=["\'][^"\']*album_report[^"\']*["\'][\s\S]*?'
                   r'class=["\'][^"\']*album_report__name[^"\']*["\'][^>]*>(.*?)</')
        for block in re.findall(r'<[^>]+class=["\'][^"\']*album_report[^"\']*["\'][\s\S]*?</(?:li|div)>', page, re.I):
            href = next(iter(re.findall(r'class=["\'][^"\']*album_report__link[^"\']*["\'][^>]*href=["\']([^"\']+)', block, re.I)), '')
            name = _clean(next(iter(re.findall(r'class=["\'][^"\']*album_report__name[^"\']*["\'][^>]*>(.*?)</', block, re.I | re.S)), ''))
            artist = _clean(next(iter(re.findall(r'class=["\'][^"\']*album_report__artist[^"\']*["\'][^>]*>(.*?)</', block, re.I | re.S)), ''))
            if href and name:
                full = _url(href)
                key = _content_key(full)
                if key not in seen:
                    seen.add(key); rows.append({'title': ('%s — %s' % (artist, name)) if artist else name, 'url': full})
    return rows

def run(action, params, handle, build_url, icon, fanart):
    try:
        if action == 'musicmp3_root':
            rows = [('Search', 'musicmp3_search_menu', {}),
                    ('Artists', 'musicmp3_artists_root', {}),
                    ('Top albums', 'musicmp3_page', {'url': BASE + 'genres.html'}),
                    ('New albums', 'musicmp3_page', {'url': BASE + 'new_albums.html'}),
                    ('Favorites', 'musicmp3_library', {'kind': 'favorites'}),
                    ('Recently Played', 'musicmp3_library', {'kind': 'recent'}),
                    ('Search History', 'musicmp3_history', {}),
                    ('Remove All Favorites', 'musicmp3_clear_library', {'kind': 'favorites'}),
                    ('Clear Search History', 'musicmp3_clear_library', {'kind': 'search_history'}),
                    ('Clear Recently Played', 'musicmp3_clear_library', {'kind': 'recent'}),
                    ('Clear Cache', 'musicmp3_clear_cache', {})]
            for label, target, values in rows:
                li = xbmcgui.ListItem(label='[B]%s[/B]' % label)
                li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
                if label == 'Favorites':
                    li.addContextMenuItems([
                        ('Sort favorites by title', 'Container.Update(%s)' % build_url(action=target, kind='favorites', sort='title')),
                        ('Sort favorites by artist', 'Container.Update(%s)' % build_url(action=target, kind='favorites', sort='artist')),
                        ('Sort favorites by date added', 'Container.Update(%s)' % build_url(action=target, kind='favorites', sort='date'))])
                xbmcplugin.addDirectoryItem(handle, build_url(action=target, **values), li,
                                             isFolder=(target not in ('musicmp3_clear_cache', 'musicmp3_clear_library')))
        elif action == 'musicmp3_clear_library':
            kind = params.get('kind', 'favorites')
            _clear_library(kind)
            xbmcgui.Dialog().notification('MusicMP3', 'Library cleared', xbmcgui.NOTIFICATION_INFO, 1800)
            xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
            return
        elif action == 'musicmp3_library':
            kind = params.get('kind', 'favorites')
            rows = list(_library().get(kind, []))
            sort_by = params.get('sort', 'date')
            if sort_by in ('title', 'artist'):
                rows.sort(key=lambda item: item.get(sort_by, '').casefold())
            return _render(rows, handle, build_url, icon, fanart)
        elif action == 'musicmp3_history':
            for item in _library().get('search_history', []):
                label = '%s: %s' % (item.get('category', 'songs').title(), item.get('query', ''))
                li = xbmcgui.ListItem(label=label); li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
                xbmcplugin.addDirectoryItem(handle, build_url(action='musicmp3_search_' + item.get('category', 'songs'), query=item.get('query', '')), li, isFolder=True)
            xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
            return
        elif action == 'musicmp3_toggle_favorite':
            row = {key: params.get(key, '') for key in ('title', 'artist', 'album', 'url', 'track_id', 'rel', 'page_url')}
            _toggle_favorite(row)
            xbmcgui.Dialog().notification('MusicMP3', 'Favorite updated', xbmcgui.NOTIFICATION_INFO, 1800)
            xbmc.executebuiltin('Container.Refresh')
            xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
            return
        elif action == 'musicmp3_clear_cache':
            global _SEARCH_RETURN
            _COOKIES.clear()
            _SEARCH_RETURN = False
            _WINDOW_STATE.clearProperty('COSMOS_MUSICMP3_SEARCH_RETURN')
            xbmcgui.Dialog().notification('MusicMP3', 'Cache cleared', xbmcgui.NOTIFICATION_INFO, 2500)
            xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
            return
        elif action == 'musicmp3_search_menu':
            for label, category in (('Search Songs', 'songs'), ('Search Albums', 'albums'), ('Search Artists', 'artists')):
                li = xbmcgui.ListItem(label=label)
                xbmcplugin.addDirectoryItem(handle, build_url(action='musicmp3_search_input_' + category), li, isFolder=True)
        elif action == 'musicmp3_artists_root':
            for name in GENRES:
                li = xbmcgui.ListItem(label=name); li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
                xbmcplugin.addDirectoryItem(handle, build_url(action='musicmp3_artists_genre', genre=name), li, isFolder=True)
        elif action == 'musicmp3_artists_genre':
            for name, gid in GENRES.get(params.get('genre'), []):
                li = xbmcgui.ListItem(label=name); li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
                xbmcplugin.addDirectoryItem(handle, build_url(action='musicmp3_artists_page', gid=gid, start='0', genre=name), li, isFolder=True)
        elif action == 'musicmp3_artists_page':
            gid = params.get('gid', '0'); start = int(params.get('start', '0'))
            target = BASE + 'main_artists.html?' + urlencode({'type': 'artist', 'gnr_id': gid, 'page': str(start // 20 + 1)})
            rows = _artist_rows(target)
            has_next = len(rows) > 20
            for row in rows[:20]:
                artist_art = row.get('image') or icon
                li = xbmcgui.ListItem(label=row['title']); li.setArt({'icon': artist_art, 'thumb': artist_art, 'fanart': fanart})
                xbmcplugin.addDirectoryItem(handle, build_url(action='musicmp3_artist_albums', url=row['url'], artist=row['title']), li, isFolder=True)
            if has_next:
                li = xbmcgui.ListItem(label='Next page'); li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
                xbmcplugin.addDirectoryItem(handle, build_url(action='musicmp3_artists_page', gid=gid, start=str(start + 20), genre=params.get('genre','')), li, isFolder=True)
        elif action == 'musicmp3_artist_albums':
            rows = _artist_album_rows(params.get('url', ''))
            for row in rows: row['page_url'] = row['url']
            return _render(rows, handle, build_url, icon, fanart)
        elif action in ('musicmp3_search', 'musicmp3_search_songs', 'musicmp3_search_albums', 'musicmp3_search_artists',
                        'musicmp3_search_input_songs', 'musicmp3_search_input_albums', 'musicmp3_search_input_artists'):
            # Kodi can revisit the search URL while unwinding its directory
            # history. Return to the existing Search menu instead of opening
            # a second keyboard dialog or rebuilding duplicate rows.
            if not params.get('query') and (_SEARCH_RETURN or
                    _WINDOW_STATE.getProperty('COSMOS_MUSICMP3_SEARCH_RETURN') == '1'):
                _SEARCH_RETURN = False
                _WINDOW_STATE.clearProperty('COSMOS_MUSICMP3_SEARCH_RETURN')
                xbmc.executebuiltin('Action(Back)')
                xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
                return
            _SEARCH_RETURN = False
            _WINDOW_STATE.clearProperty('COSMOS_MUSICMP3_SEARCH_RETURN')
            category = {'musicmp3_search_songs': 'songs',
                        'musicmp3_search_albums': 'albums',
                        'musicmp3_search_artists': 'artists',
                        'musicmp3_search_input_songs': 'songs',
                        'musicmp3_search_input_albums': 'albums',
                        'musicmp3_search_input_artists': 'artists'}.get(action, params.get('cat', 'songs'))
            if not params.get('query') and not action.startswith('musicmp3_search_input_'):
                for label, child_category in (('Search Songs', 'songs'), ('Search Albums', 'albums'), ('Search Artists', 'artists')):
                    li = xbmcgui.ListItem(label=label)
                    xbmcplugin.addDirectoryItem(handle, build_url(action='musicmp3_search_input_' + child_category), li, isFolder=True)
                xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
                return
            query = (params.get('query') or xbmcgui.Dialog().input('Search')).strip()
            if not query:
                xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
                return
            _add_search_history(query, category)
            target = BASE + 'search.html?' + urlencode({'text': query, 'all': category})
            page_number = int(params.get('page', '1'))
            if page_number > 1:
                target = _page_url(target, page_number)
            rows = _search_rows(_get(target), category)
            if category == 'songs':
                terms = [word.casefold() for word in re.findall(r'\w+', query) if len(word) > 1]
                rows = [row for row in rows if all(
                    term in (' '.join((row.get('title', ''), row.get('artist', ''), row.get('album', '')))).casefold()
                    for term in terms)]
            for row in rows: row['page_url'] = target
            for row in rows:
                if category == 'albums' and row.get('url'):
                    row['title'] = row.get('title', '')
                if category == 'artists':
                    row['title'] = row.get('title', '')
            return _render(rows, handle, build_url, icon, fanart, query, target, page_number, category)
        elif action == 'musicmp3_page':
            target = params.get('url') or BASE
            page_number = int(params.get('page', '1'))
            if page_number > 1:
                target = _page_url(target, page_number)
            mode = 'artists' if target.rstrip('/').endswith('/artists.html') else 'links'
            rows = _items(_get(target), mode)
            if any(row.get('stream') or row.get('rel') for row in rows):
                for row in rows:
                    row['album_context'] = True
            for row in rows: row['page_url'] = target
            return _render(rows, handle, build_url, icon, fanart, '', params.get('url') or target, page_number)
        elif action == 'musicmp3_play':
            url = params.get('url', '')
            token = params.get('rel', '')
            track_id = params.get('track_id', '')
            referer = params.get('page_url', '')
            if token and track_id and referer:
                # Refresh the session in this playback invocation, then
                # generate the signed URL with the same inputs as the site player.
                page = _get(referer)
                url = _signed_stream(page, track_id, token)
            if not url or url.rstrip('/') == BASE.rstrip('/'):
                raise ValueError('No MusicMP3.ru stream was extracted')
            if '|' not in url:
                from urllib.parse import quote
                url += '|seekable=0&verifypeer=false&User-Agent=%s&Referer=%s' % (quote(UA), quote(BASE))
            # History is best-effort only; never let local library I/O block
            # Kodi from receiving an otherwise valid resolved stream.
            try:
                _remember_play({'title': params.get('title', 'MusicMP3.ru'),
                                'artist': params.get('artist', ''), 'album': params.get('album', ''),
                                'url': url, 'track_id': track_id, 'rel': token, 'page_url': referer,
                                'stream': True})
            except Exception as history_error:
                xbmc.log('COSMOS MusicMP3: unable to save playback history: %s' % history_error, xbmc.LOGWARNING)
            item = xbmcgui.ListItem(label=params.get('title', 'MusicMP3.ru'), path=url)
            item.setProperty('IsPlayable', 'true')
            item.setInfo('music', {'mediatype': 'song', 'title': params.get('title', 'MusicMP3.ru')})
            item.setMimeType('audio/mpeg')
            item.setContentLookup(False)
            xbmcplugin.setResolvedUrl(handle, True, item)
            return
        xbmcplugin.setContent(handle, 'files')
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
    except Exception as exc:
        xbmc.log('COSMOS MusicMP3: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('MusicMP3.ru', 'Unable to load catalogue.', xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.endOfDirectory(handle, succeeded=False)

def _render(rows, handle, build_url, icon, fanart, query='', source_url='', page_number=1, category=''):
    global _SEARCH_RETURN
    has_next = len(rows) > 20
    rows = rows[:20]
    if not rows:
        empty = xbmcgui.ListItem(label='[COLOR grey]No MusicMP3.ru results found[/COLOR]')
        empty.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        xbmcplugin.addDirectoryItem(handle, build_url(action='musicmp3_root'), empty, isFolder=True)
    for row in rows:
        playable = bool(row.get('stream') or row.get('rel') or
                        (row.get('url') and re.search(r'\.(mp3|m4a|aac)(?:$|\?)', row['url'], re.I)))
        favorite = any(_library_key(item) == _library_key(row) for item in _library().get('favorites', []))
        label = ('★ ' if favorite else '') + row['title']
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': row.get('image') or icon, 'thumb': row.get('image') or icon, 'fanart': fanart})
        favorite_url = build_url(action='musicmp3_toggle_favorite', **{
            key: row.get(key, '') for key in ('title', 'artist', 'album', 'url', 'track_id', 'rel', 'page_url')})
        li.addContextMenuItems([('Add/remove favorite', 'RunPlugin(%s)' % favorite_url)])
        if playable:
            li.setProperty('IsPlayable', 'true')
            li.setInfo('music', {'mediatype': 'song', 'title': row['title'],
                                 'artist': row.get('artist', ''),
                                 'album': row.get('album', '')})
        folder_action = 'musicmp3_artist_albums' if (category == 'artists' and not playable) else 'musicmp3_page'
        target = build_url(action='musicmp3_play' if playable else folder_action, url=row['url'], title=row['title'], artist=row.get('artist', row.get('title', '')), album=row.get('album', ''), query=query, track_id=row.get('track_id', ''), rel=row.get('rel', ''), page_url=row.get('page_url', ''))
        xbmcplugin.addDirectoryItem(handle, target, li, isFolder=not playable)
    if has_next and source_url:
        li = xbmcgui.ListItem(label='Next page')
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        next_action = 'musicmp3_search_' + category if query and category else ('musicmp3_search' if query else 'musicmp3_page')
        xbmcplugin.addDirectoryItem(handle, build_url(action=next_action, url=source_url, query=query, page=str(page_number + 1)), li, isFolder=True)
    xbmcplugin.setContent(handle, 'songs' if any(re.search(r'\.(mp3|m4a|aac)', r.get('url',''), re.I) for r in rows) else 'files')
    if query and category:
        _SEARCH_RETURN = True
        _WINDOW_STATE.setProperty('COSMOS_MUSICMP3_SEARCH_RETURN', '1')
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
