# -*- coding: utf-8 -*-
"""
Kodi UI handlers that render the Trakt menu tree inside C.O.S.M.O.S.

This addon and code was created by Zeus768 for Cosmos.
Author: Zeus768

Kept as a separate module so the Trakt router additions in cosmos.py stay
small. Every function assumes cosmos.py has already called
``xbmcplugin.addDirectoryItem`` with its own ``build_url`` helper — we
re-import those lazily to avoid circular imports at load time.
"""
import json
import os
import sys
import functools
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import xbmcaddon

from . import trakt as trakt_mod
from . import tmdb as tmdb_mod


ADDON = xbmcaddon.Addon()
ADDON_ID = 'plugin.video.cosmos'
ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/')
ICON = f'{ADDON_PATH}icon.png'
FANART = f'{ADDON_PATH}fanart.jpg'
ICON_TRAKT = os.path.join(ADDON_PATH, 'resources', 'media', 'icon_trakt.png')


def _show_vip_notice(notice):
    if not notice:
        return
    if notice['status'] == 426:
        message = 'This Trakt feature requires VIP membership.'
    else:
        message = 'Your Trakt account limit has been reached.'
        if notice['limit']:
            message += '\nAllowed limit: %s.' % notice['limit']
        if notice['vip']:
            message += '\nYou already have VIP. Reduce the number of items or lists, or contact Trakt support.'
    url = notice['upgrade_url']
    if not url:
        xbmcgui.Dialog().ok('Trakt account limit', message)
        return
    if xbmcgui.Dialog().yesno('Trakt VIP', message + '\nOpen the Trakt VIP page in your browser?'):
        try:
            import webbrowser
            opened = webbrowser.open(url)
        except Exception:
            opened = False
        if not opened:
            xbmcgui.Dialog().ok('Trakt VIP', 'Open this address in your browser:\n' + url)


def _vip_ui_action(function):
    """Present at most one VIP notice after a foreground menu/action."""
    @functools.wraps(function)
    def wrapped(*args, **kwargs):
        trakt_mod.take_vip_notice()
        try:
            return function(*args, **kwargs)
        finally:
            _show_vip_notice(trakt_mod.take_vip_notice())
    return wrapped


def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def _build_url(**kwargs):
    return f'{sys.argv[0]}?{urlencode(kwargs)}'


def _trakt_icon():
    """Return the path to the Trakt icon, falling back to the default addon icon."""
    return ICON_TRAKT if xbmcvfs.exists(ICON_TRAKT) else ICON


def _row(label, url, is_folder=True, thumb=None, plot='', context_items=None):
    if not is_folder and trakt_mod.get_last_error():
        plot = '\n'.join(filter(None, (plot, trakt_mod.get_last_error())))
        if any(text in label.lower() for text in ('failed to load', 'no liked lists',
                                                  'not following anyone', 'no public lists',
                                                  'this list is empty')):
            label = '[COLOR white]Trakt request failed — see item information[/COLOR]'
    li = xbmcgui.ListItem(label=label)
    t = thumb or _trakt_icon()
    li.setArt({'icon': t, 'thumb': t, 'poster': t, 'fanart': FANART})
    if plot:
        try:
            li.getVideoInfoTag().setPlot(plot)
        except Exception:
            pass
    if context_items:
        li.addContextMenuItems(context_items)
    xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=is_folder)


def _require_auth():
    if trakt_mod.is_authorized():
        return True
    xbmcgui.Dialog().notification(
        'Trakt', 'Please authorize Trakt in Settings first',
        xbmcgui.NOTIFICATION_WARNING, 3500,
    )
    return False


# ── Root menu ────────────────────────────────────────────────────────────

@_vip_ui_action
def menu_root():
    authed = trakt_mod.is_authorized()
    if not authed:
        _row('[COLOR yellow][B]Authorize Trakt[/B][/COLOR]',
             _build_url(action='trakt_auth'), is_folder=False)
        _row('[COLOR grey]Sign in to view your Trakt lists[/COLOR]',
             _build_url(action='trakt_root'), is_folder=False)
        _row('[COLOR cyan]After authorization, restart Kodi or refresh this menu[/COLOR]',
             _build_url(action='trakt_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    uname = (ADDON.getSetting('trakt_username') or '').strip()
    header = f'[COLOR springgreen][B]Signed in as @{uname}[/B][/COLOR]' if uname \
        else '[COLOR springgreen][B]Signed in[/B][/COLOR]'
    _row(header, _build_url(action='trakt_root'), is_folder=False)

    _row('[COLOR white]Search[/COLOR]',
         _build_url(action='trakt_search'), is_folder=True)
    _row('[COLOR white]Discover[/COLOR]',
         _build_url(action='trakt_discover'), is_folder=True)
    _row('[COLOR white]Continue Watching[/COLOR]',
         _build_url(action='trakt_continue_watching'), is_folder=True)
    _row('[COLOR white]My Watchlist[/COLOR]',
         _build_url(action='trakt_watchlist'), is_folder=True)
    _row('[COLOR white]My History[/COLOR]',
         _build_url(action='trakt_history'), is_folder=True)
    _row('[COLOR white]My Custom Lists[/COLOR]',
         _build_url(action='trakt_my_lists'), is_folder=True)
    _row('[COLOR white]Lists I Follow (Liked)[/COLOR]',
         _build_url(action='trakt_liked_lists'), is_folder=True)
    _row('[COLOR white]Users I Follow[/COLOR]',
         _build_url(action='trakt_following'), is_folder=True)
    _row('[COLOR white]Follow all lists from users I follow[/COLOR]',
         _build_url(action='trakt_follow_all'), is_folder=False)
    _row('[COLOR white]Test Trakt Connection[/COLOR]',
         _build_url(action='trakt_test'), is_folder=False)
    _row('[COLOR red]Unlink Trakt[/COLOR]',
         _build_url(action='trakt_revoke'), is_folder=False)

    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


@_vip_ui_action
def menu_search():
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    for kind, label in (('movie,show', 'Movies and TV Shows'),
                        ('movie', 'Movies'), ('show', 'TV Shows')):
        _row('[COLOR white]%s[/COLOR]' % label,
             _build_url(action='trakt_search_items', kind=kind))
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


@_vip_ui_action
def menu_search_items(kind='movie,show', query=None, page=1):
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if query is None:
        query = xbmcgui.Dialog().input('Search Trakt', type=xbmcgui.INPUT_ALPHANUM)
    query = ' '.join(str(query or '').split())
    if not query:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    items = trakt_mod.search_items(query, kind, page)
    if not items:
        _row('[COLOR grey]No results or failed to load[/COLOR]',
             _build_url(action='trakt_search'), is_folder=False,
             plot=trakt_mod.get_last_error() or '')
    _render_items(items, page_action='trakt_search_items', page=page,
                  page_params={'kind': kind, 'query': query}, hydrate=False, trakt_actions=True)


@_vip_ui_action
def menu_discover():
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    for kind, label in (('movies', 'Movies'), ('shows', 'TV Shows')):
        _row('[COLOR white]%s[/COLOR]' % label,
             _build_url(action='trakt_discover_kind', kind=kind))
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


@_vip_ui_action
def menu_discover_kind(kind='movies'):
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    kind = 'shows' if kind == 'shows' else 'movies'
    for category, name in (('trending', 'Trending'), ('popular', 'Popular'),
                           ('anticipated', 'Most Anticipated'),
                           ('watched', 'Most Watched This Week')):
        _row('[COLOR white]%s[/COLOR]' % name,
             _build_url(action='trakt_discover_items', kind=kind, category=category))
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


@_vip_ui_action
def menu_discover_items(kind='movies', category='trending', page=1):
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    items = trakt_mod.get_discover_items(kind, category, page)
    if not items:
        _row('[COLOR grey]No results or failed to load[/COLOR]',
             _build_url(action='trakt_discover'), is_folder=False,
             plot=trakt_mod.get_last_error() or '')
    _render_items(items, page_action='trakt_discover_items', page=page,
                  page_params={'kind': kind, 'category': category}, hydrate=False, trakt_actions=True)


def _trakt_context_items(payload, kind):
    """Build explicit actions without fetching remote watch/list state."""
    if not trakt_mod.is_authorized():
        return []
    watched_label = ('Mark entire show as watched on Trakt'
                     if kind == 'show' else 'Mark as watched on Trakt')
    unwatched_label = ('Mark entire show as unwatched on Trakt'
                       if kind == 'show' else 'Mark as unwatched on Trakt')
    return [(label, 'RunPlugin(%s)' % _build_url(action=action, payload=payload))
            for label, action in (
                (watched_label, 'trakt_mark_watched'),
                (unwatched_label, 'trakt_remove_from_history'),
                ('Add to Trakt Watchlist', 'trakt_add_watchlist'),
                ('Remove from Trakt Watchlist', 'trakt_remove_watchlist'))]


# ── Content renderers ────────────────────────────────────────────────────

def _render_items(items, content='movies', is_history=False,
                  page_action=None, page=1, page_params=None, hydrate=True, trakt_actions=False):
    from . import cosmos as cosmos_mod
    """Render a Trakt response array as playable rows.

    - Movies → click plays via the existing Link-Zero scraper flow.
    - Shows  → click opens a TMDB-backed seasons picker.
    - Episodes (e.g. history) → click plays that specific S/E via Link Zero.

    Every row also carries context-menu actions to add/remove from the
    Trakt Watchlist and open the item on trakt.tv.
    """
    rendered_types = set()
    for it in items:
        kind = None
        node = None
        ep = None
        show = None
        if 'movie' in it:
            kind, node = 'movie', it['movie']
        elif 'season' in it and 'show' in it:
            kind, node = 'season', it['show']
        elif 'show' in it and 'episode' not in it:
            kind, node = 'show', it['show']
        elif 'episode' in it:
            kind = 'episode'
            ep = it['episode']
            show = it.get('show') or {}
            node = show  # use show as carrier (tmdb id etc.)
        else:
            continue
        if not node:
            continue

        # List/history media are snapshots. Hydrate display metadata only;
        # retain the enclosing response's membership and activity state.
        snapshot_ids = node.get('ids') or {}
        summary_id = snapshot_ids.get('trakt') or snapshot_ids.get('slug')
        fresh = (trakt_mod.get_summary('movie' if kind == 'movie' else 'show', summary_id)
                 if hydrate else {})
        node = dict(node, **fresh)
        node['ids'] = dict(snapshot_ids, **(fresh.get('ids') or {}))
        if kind == 'episode':
            show = node
            fresh_episode = trakt_mod.get_summary(
                'episode', summary_id, ep.get('season'), ep.get('number'))
            ep = dict(ep, **fresh_episode)

        title = (show.get('title') if kind == 'episode' and show
                 else node.get('title')) or 'Untitled'
        year = (show.get('year') if kind == 'episode' and show
                else node.get('year'))
        ids = node.get('ids') or {}
        ep_ids = (ep or {}).get('ids') or {}

        tmdb_id = str(ids.get('tmdb') or '')
        imdb_id = str(ids.get('imdb') or '')
        trakt_id = str(ids.get('trakt') or '')

        # Trakt does not always include a TMDB id in list/history responses.
        # Resolve the show id through TMDB so show rows can still open the
        # TMDB-backed season picker and episode rows can use TMDB metadata.
        if not tmdb_id and imdb_id:
            tmdb_id = str(tmdb_mod.find_by_imdb_id(
                imdb_id, 'show' if kind in ('show', 'season', 'episode') else 'movie'
            ) or '')

        if kind == 'episode':
            s_no = int(ep.get('season', 0) or 0)
            e_no = int(ep.get('number', 0) or 0)
            label = (f'{title} ({year}) — S{s_no:02d}E{e_no:02d}' if year
                     else f'{title} — S{s_no:02d}E{e_no:02d}')
            if ep.get('title'):
                label = f'{label} · {ep["title"]}'
        else:
            label = f'{title} ({year})' if year else title
            if kind == 'show':
                label = f'{label}  [COLOR grey][TV][/COLOR]'
            elif kind == 'season':
                label = f'{label} — Season {it["season"].get("number", 0)}'

        # Build the Trakt web URL (for context menu).
        if kind == 'movie':
            web_url = f'https://trakt.tv/movies/{ids.get("slug") or trakt_id}'
        elif kind in ('show', 'episode'):
            web_url = f'https://trakt.tv/shows/{(show or node).get("ids", {}).get("slug") or ids.get("slug") or trakt_id}'
        else:
            web_url = 'https://trakt.tv'

        meta = tmdb_mod.get_metadata(tmdb_id, 'movie' if kind == 'movie' else 'tvshow') if tmdb_id else {}
        episode_meta = {}
        if kind == 'episode' and tmdb_id:
            episode_meta = tmdb_mod.get_episode_meta(tmdb_id, s_no, e_no) or {}
        poster = meta.get('poster', '')
        fanart = meta.get('fanart', FANART)
        if episode_meta.get('still'):
            poster = episode_meta['still']
        if episode_meta.get('name') and not ep.get('title'):
            label = f'{title} ({year}) — S{s_no:02d}E{e_no:02d} · {episode_meta["name"]}' if year else f'{title} — S{s_no:02d}E{e_no:02d} · {episode_meta["name"]}'
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': poster or _trakt_icon(), 'thumb': poster or _trakt_icon(), 'poster': poster, 'fanart': fanart})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            if year:
                tag.setYear(int(year))
            plot = ((ep or node).get('overview') or episode_meta.get('overview')
                    or node.get('overview') or meta.get('plot') or '')
            tag.setPlot(plot)
            tag.setMediaType(
                'movie' if kind == 'movie'
                else 'tvshow' if kind == 'show'
                else 'episode' if kind == 'episode'
                else 'season' if kind == 'season'
                else 'video'
            )
            if kind in ('show', 'season', 'episode'):
                tag.setTvShowTitle(title)
            if kind == 'episode':
                tag.setTitle(ep.get('title') or episode_meta.get('name') or title)
                tag.setSeason(s_no)
                tag.setEpisode(e_no)
            if kind == 'season':
                tag.setSeason(int(it['season'].get('number', 0)))
        except Exception:
            pass

        payload_dict = {
            'title': title,
            'tmdb': tmdb_id,
            'imdb': imdb_id,
            'trakt': trakt_id,
            'year': str(year or ''),
            'content': 'movie' if kind == 'movie' else ('episode' if kind == 'episode' else 'show'),
            'poster': poster,
            'fanart': fanart,
        }

        # Target URL based on kind
        if kind == 'movie':
            li.setProperty('IsPlayable', 'true')
            payload = json.dumps({
                'title': title,
                'tmdb': tmdb_id,
                'imdb': imdb_id,
                'year': year or '',
                'content': 'movie',
                'poster': poster,
                'fanart': fanart,
            })
            target = _build_url(action='link_zero', payload=payload)
            is_folder = False
        elif kind == 'season':
            target = _build_url(
                action='trakt_tv_episodes', tmdb=tmdb_id, imdb=imdb_id,
                trakt=trakt_id, title=title, year=str(year or ''),
                season=str(it['season'].get('number', 0)),
            )
            is_folder = True
        elif kind == 'show':
            target = _build_url(
                action='trakt_tv_seasons',
                tmdb=tmdb_id, imdb=imdb_id, trakt=trakt_id,
                title=title, year=str(year or ''),
            )
            is_folder = True
        elif kind == 'episode':
            li.setProperty('IsPlayable', 'true')
            s_no = int(ep.get('season', 0) or 0)
            e_no = int(ep.get('number', 0) or 0)
            payload = json.dumps({
                'title': title,
                'tmdb': tmdb_id,
                'imdb': imdb_id,
                'year': year or '',
                'content': 'episode',
                'season': s_no,
                'episode': e_no,
                'poster': poster,
                'show_poster': meta.get('poster', ''),
                'fanart': fanart,
            })
            payload_dict.update({'season': s_no, 'episode': e_no})
            target = _build_url(action='link_zero', payload=payload)
            is_folder = False
        else:
            target = web_url
            is_folder = False

        # Context menu: watchlist and tracking actions
        payload_json = json.dumps(payload_dict)
        ctx = []
        if trakt_actions:
            ctx.extend(_trakt_context_items(payload_json, kind))
        ctx.extend(cosmos_mod._fav_ctx_items(payload_json, tmdb_id, payload_dict['content'], title))
        ctx.extend(cosmos_mod._info_ctx_items(title, tmdb_id, payload_dict['content'], poster, fanart))
        ctx.extend(cosmos_mod._scrobbler_ctx_items(payload_json, tmdb_id, payload_dict['content'], title, season=payload_dict.get('season'), episode=payload_dict.get('episode')))
        ctx.extend(cosmos_mod._extras_ctx_items(title, tmdb_id, payload_dict['content'], poster, fanart))
        ctx.extend(cosmos_mod._trailer_ctx_items(tmdb_id, payload_dict['content']))
        ctx.extend(cosmos_mod._opensubtitles_ctx_items(payload_json, tmdb_id, payload_dict['content'], title, season=payload_dict.get('season'), episode=payload_dict.get('episode')))

        if is_history:
            remove_url = _build_url(action='trakt_remove_from_history', payload=payload_json)
            ctx.append(('[COLOR red]Remove from History[/COLOR]', f'RunPlugin({remove_url})'))

        li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(_handle(), target, li, isFolder=is_folder)
        rendered_types.add({'movie': 'movies', 'show': 'tvshows',
                            'season': 'seasons', 'episode': 'episodes'}[kind])

    if page_action:
        _page_rows(page_action, page, len(items), **(page_params or {}))
    xbmcplugin.setContent(_handle(), next(iter(rendered_types))
                          if len(rendered_types) == 1 else 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _page_rows(action, page, item_count, **params):
    """Add fixed-size paging controls without making an extra API request."""
    if page > 1:
        _row('[COLOR yellow]Previous page[/COLOR]',
             _build_url(action=action, page=str(page - 1), **params),
             is_folder=True)
    if item_count == 20:
        _row('[COLOR yellow]Next page[/COLOR]',
             _build_url(action=action, page=str(page + 1), **params),
             is_folder=True)


@_vip_ui_action
def menu_watchlist():
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    _row('[COLOR white]Movies[/COLOR]',
         _build_url(action='trakt_watchlist_kind', kind='movies'), is_folder=True)
    _row('[COLOR white]Shows[/COLOR]',
         _build_url(action='trakt_watchlist_kind', kind='shows'), is_folder=True)
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


@_vip_ui_action
def menu_watchlist_kind(kind, page=1):
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    xbmc.log(f'Trakt UI: Fetching watchlist for {kind}', xbmc.LOGINFO)
    items = trakt_mod.get_watchlist(kind, page=page, limit=20)
    xbmc.log(f'Trakt UI: Received {len(items) if items else 0} watchlist items', xbmc.LOGINFO)
    if not items:
        _row('[COLOR orange]Watchlist is empty or failed to load[/COLOR]', 
             _build_url(action='trakt_root'), is_folder=False)
        _row('[COLOR grey]Check Kodi log for errors or authorize again[/COLOR]',
             _build_url(action='trakt_root'), is_folder=False)
        _page_rows('trakt_watchlist_kind', page, 0, kind=kind)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    _render_items(items, page_action='trakt_watchlist_kind', page=page,
                  page_params={'kind': kind})


@_vip_ui_action
def menu_history():
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    _row('[COLOR white]Movies[/COLOR]',
         _build_url(action='trakt_history_kind', kind='movies'), is_folder=True)
    _row('[COLOR white]Shows[/COLOR]',
         _build_url(action='trakt_history_kind', kind='shows'), is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


@_vip_ui_action
def menu_history_kind(kind, page=1):
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    kind = 'shows' if kind == 'shows' else 'movies'
    page = max(1, int(page))
    xbmc.log(f'Trakt UI: Fetching watched titles for {kind}', xbmc.LOGINFO)
    # Watched returns one entry per title. History/shows returns individual
    # episode play events, which duplicates shows and opens episode playback.
    watched = trakt_mod.get_watched(kind) or []
    watched = sorted(watched, key=lambda item: item.get('last_watched_at') or '',
                     reverse=True)
    start = (page - 1) * 20
    items = watched[start:start + 20]
    xbmc.log(f'Trakt UI: Received {len(items) if items else 0} history items', xbmc.LOGINFO)
    if not items:
        _row('[COLOR orange]History is empty or failed to load[/COLOR]', 
             _build_url(action='trakt_root'), is_folder=False)
        _row('[COLOR grey]Check Kodi log for errors or authorize again[/COLOR]',
             _build_url(action='trakt_root'), is_folder=False)
        _page_rows('trakt_history_kind', page, 0, kind=kind)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    _render_items(items, is_history=True,
                  page_action='trakt_history_kind', page=page,
                  page_params={'kind': kind})


@_vip_ui_action
def menu_my_lists(page=1):
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    xbmc.log('Trakt UI: Fetching my custom lists', xbmc.LOGINFO)
    lists = trakt_mod.get_my_lists(page=page, limit=20)
    xbmc.log(f'Trakt UI: Received {len(lists) if lists else 0} custom lists', xbmc.LOGINFO)
    if not lists:
        _row('[COLOR orange]You have no custom lists or failed to load[/COLOR]',
             _build_url(action='trakt_root'), is_folder=False)
        _row('[COLOR grey]Check Kodi log for errors or create lists on trakt.tv[/COLOR]',
             _build_url(action='trakt_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    uname = (ADDON.getSetting('trakt_username') or 'me').strip()
    for lst in lists:
        name = lst.get('name') or 'Untitled'
        lid = (lst.get('ids') or {}).get('trakt', '')
        count = lst.get('item_count', 0)
        label = f'{name}  [COLOR grey]· {count} items[/COLOR]'
        import_url = _build_url(
            action='trakt_import_list_to_simkl', user=uname,
            list_id=str(lid), list_name=name,
        )
        _row(f'[COLOR cyan]{label}[/COLOR]',
             _build_url(action='trakt_list_items', user=uname, list_id=str(lid)),
             is_folder=True,
             context_items=[
                 ('[COLOR cyan]Import this list to Simkl[/COLOR]',
                  f'RunPlugin({import_url})'),
             ])
    _page_rows('trakt_my_lists', page, len(lists))
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


@_vip_ui_action
def menu_liked_lists(page=1):
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    rows = trakt_mod.get_liked_lists(page=page, limit=20)
    if not rows:
        _row('[COLOR grey]No liked lists yet[/COLOR]',
             _build_url(action='trakt_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    for row in rows:
        lst = row.get('list') or {}
        owner = (lst.get('user') or {}).get('username', '') or \
                ((lst.get('user') or {}).get('ids') or {}).get('slug', '')
        slug = ((lst.get('user') or {}).get('ids') or {}).get('slug', '') or owner
        name = lst.get('name') or 'Untitled'
        lid = (lst.get('ids') or {}).get('trakt', '')
        count = lst.get('item_count', 0)
        label = f'{name}  [COLOR grey]by @{owner} · {count} items[/COLOR]'
        li = xbmcgui.ListItem(label=f'[COLOR magenta]{label}[/COLOR]')
        li.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': FANART})
        unlike_url = _build_url(action='trakt_unlike_list', user=slug, list_id=str(lid))
        li.addContextMenuItems([
            ('[COLOR red]Unfollow this list[/COLOR]', f'RunPlugin({unlike_url})'),
            ('[COLOR cyan]Import this list to Simkl[/COLOR]',
             f'RunPlugin({_build_url(action="trakt_import_list_to_simkl", user=slug, list_id=str(lid), list_name=name)})'),
        ])
        url = _build_url(action='trakt_list_items', user=slug, list_id=str(lid))
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)

    _page_rows('trakt_liked_lists', page, len(rows))
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


@_vip_ui_action
def menu_following(page=1):
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    rows = trakt_mod.get_following(page=page, limit=20)
    if not rows:
        _row('[COLOR grey]You are not following anyone[/COLOR]',
             _build_url(action='trakt_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    for row in rows:
        u = row.get('user') or {}
        slug = (u.get('ids') or {}).get('slug', '') or u.get('username', '')
        label = f'@{slug}'
        name = u.get('name', '')
        if name:
            label = f'{label}  [COLOR grey]· {name}[/COLOR]'
        _row(f'[COLOR magenta]{label}[/COLOR]',
             _build_url(action='trakt_user_lists', user=slug), is_folder=True)
    _page_rows('trakt_following', page, len(rows))
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


@_vip_ui_action
def menu_user_lists(user, page=1):
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    lists = trakt_mod.get_user_lists(user, page=page, limit=20)
    if not lists:
        _row(f'[COLOR grey]@{user} has no public lists[/COLOR]',
             _build_url(action='trakt_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    _row(f'[COLOR orange][B]Follow ALL lists from @{user}[/B][/COLOR]',
         _build_url(action='trakt_follow_user', user=user), is_folder=False)
    for lst in lists:
        name = lst.get('name') or 'Untitled'
        lid = (lst.get('ids') or {}).get('trakt', '')
        count = lst.get('item_count', 0)
        label = f'{name}  [COLOR grey]· {count} items[/COLOR]'
        li = xbmcgui.ListItem(label=f'[COLOR magenta]{label}[/COLOR]')
        li.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': FANART})
        like_url = _build_url(action='trakt_like_list', user=user, list_id=str(lid))
        li.addContextMenuItems([
            ('[COLOR lime]Follow this list[/COLOR]', f'RunPlugin({like_url})'),
            ('[COLOR cyan]Import this list to Simkl[/COLOR]',
             f'RunPlugin({_build_url(action="trakt_import_list_to_simkl", user=user, list_id=str(lid), list_name=name)})'),
        ])
        url = _build_url(action='trakt_list_items', user=user, list_id=str(lid))
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)

    _page_rows('trakt_user_lists', page, len(lists), user=user)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


@_vip_ui_action
def menu_list_items(user, list_id, page=1):
    if not _require_auth():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    items = trakt_mod.get_list_items(user, list_id, page=page, limit=20)
    if not items:
        _row('[COLOR grey]This list is empty[/COLOR]',
             _build_url(action='trakt_root'), is_folder=False)
        _page_rows('trakt_list_items', page, 0,
               user=user, list_id=list_id)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    _render_items(items, page_action='trakt_list_items', page=page,
                  page_params={'user': user, 'list_id': list_id})


# ── Actions ──────────────────────────────────────────────────────────────

@_vip_ui_action
def action_import_list_to_simkl(user, list_id, list_name=''):
    """Copy a Trakt custom list into a Simkl built-in status bucket."""
    if not _require_auth():
        return

    from . import simkl as simkl_mod
    if not simkl_mod.is_authorized():
        xbmcgui.Dialog().notification(
            'Trakt → Simkl',
            'Authorize Simkl in Settings first',
            xbmcgui.NOTIFICATION_WARNING,
            3500,
        )
        return

    destinations = simkl_mod.TRAKT_IMPORT_DESTINATIONS
    choice = xbmcgui.Dialog().select(
        f'Import "{list_name or "Trakt list"}" to Simkl',
        [label for label, _value in destinations],
    )
    if choice < 0:
        return
    destination = destinations[choice][1]

    items = trakt_mod.get_list_items(user, list_id, all_pages=True) or []
    if not items:
        xbmcgui.Dialog().notification(
            'Trakt → Simkl', 'This Trakt list is empty or could not be loaded',
            xbmcgui.NOTIFICATION_WARNING, 3500,
        )
        return

    progress = xbmcgui.DialogProgressBG()
    progress.create('Trakt → Simkl', f'Preparing "{list_name or "Trakt list"}"...')

    def _update(percent, message):
        try:
            progress.update(percent, 'Trakt → Simkl', message)
        except Exception:
            pass

    try:
        result = simkl_mod.import_trakt_list(
            items,
            destination,
            source_user=user,
            list_id=list_id,
            list_name=list_name,
            progress_callback=_update,
        )
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if result.get('error') == 'not_authorized':
        xbmcgui.Dialog().notification(
            'Trakt → Simkl', 'Authorize Simkl in Settings first',
            xbmcgui.NOTIFICATION_WARNING, 3500,
        )
        return
    if result.get('error') == 'invalid_destination':
        xbmcgui.Dialog().notification(
            'Trakt → Simkl', 'Invalid Simkl destination',
            xbmcgui.NOTIFICATION_ERROR, 3500,
        )
        return

    record = result.get('record') or {}
    destination_label = dict(destinations).get(destination, destination)
    status = 'completed' if result.get('ok') else 'completed with errors'
    xbmcgui.Dialog().ok(
        'Trakt → Simkl',
        f'List: {list_name or "Untitled"}\n'
        f'Destination: {destination_label}\n\n'
        f'Imported: {record.get("added", 0)}\n'
        f'Not found: {record.get("not_found", 0)}\n'
        f'Skipped: {record.get("skipped", 0)}\n'
        f'Failed: {record.get("failed", 0)}\n\n'
        f'Status: {status}',
    )
    xbmc.executebuiltin('Container.Refresh')


@_vip_ui_action
def action_auth():
    trakt_mod.authorize()
    xbmc.executebuiltin('Container.Refresh')


@_vip_ui_action
def action_revoke():
    if xbmcgui.Dialog().yesno('Trakt', 'Unlink your Trakt account?'):
        trakt_mod.revoke()
        xbmc.executebuiltin('Container.Refresh')


@_vip_ui_action
def action_like_list(user, list_id):
    if trakt_mod.like_list(user, list_id):
        xbmcgui.Dialog().notification('Trakt', 'List followed',
                                      xbmcgui.NOTIFICATION_INFO, 2500)
    else:
        xbmcgui.Dialog().notification('Trakt', 'Follow failed',
                                      xbmcgui.NOTIFICATION_ERROR, 2500)
    xbmc.executebuiltin('Container.Refresh')


@_vip_ui_action
def action_unlike_list(user, list_id):
    if trakt_mod.unlike_list(user, list_id):
        xbmcgui.Dialog().notification('Trakt', 'List unfollowed',
                                      xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')

@_vip_ui_action
def action_mark_watched(payload_str):
    if not _require_auth():
        return

    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification('Trakt', 'Invalid item data', xbmcgui.NOTIFICATION_ERROR)
        return

    content = meta.get('content', 'movie')
    season = meta.get('season')
    episode = meta.get('episode')

    if content in ('show', 'tvshow') and season in (None, '') and episode in (None, ''):
        dlg = xbmcgui.Dialog()
        choice = dlg.select('Mark as Watched on Trakt', ['Mark entire show as watched', 'Mark a specific episode'])
        
        if choice == 0:
            season, episode = None, None
        elif choice == 1:
            title = meta.get('title') or 'TV Show'
            season_str = dlg.numeric(0, f'{title} \u2014 Season number')
            if not season_str: return
            try: season = int(season_str)
            except ValueError:
                xbmcgui.Dialog().notification('Trakt', 'Invalid season number', xbmcgui.NOTIFICATION_ERROR)
                return

            episode_str = dlg.numeric(0, f'{title} S{season:02d} \u2014 Episode number')
            if not episode_str: return
            try: episode = int(episode_str)
            except ValueError:
                xbmcgui.Dialog().notification('Trakt', 'Invalid episode number', xbmcgui.NOTIFICATION_ERROR)
                return
            if season < 0 or episode < 1:
                xbmcgui.Dialog().notification('Trakt', 'Invalid season or episode number', xbmcgui.NOTIFICATION_ERROR)
                return
        else:
            return

    ok = trakt_mod.add_to_history(content, tmdb=meta.get('tmdb'), imdb=meta.get('imdb'), trakt_id=meta.get('trakt'), season=season, episode=episode)
    if ok:
        xbmcgui.Dialog().notification('Trakt', 'Marked as Watched', xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin('Container.Refresh')
    else: xbmcgui.Dialog().notification('Trakt', 'Failed to mark as watched', xbmcgui.NOTIFICATION_ERROR, 3000)

@_vip_ui_action
def action_remove_from_history(payload_str):
    if not _require_auth():
        return
    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification('Trakt', 'Invalid item data', xbmcgui.NOTIFICATION_ERROR)
        return

    if not isinstance(meta, dict):
        return
    if meta.get('content') in ('show', 'tvshow') and meta.get('season') in (None, ''):
        if not xbmcgui.Dialog().yesno(
                'Trakt', 'Mark the entire show as unwatched? This removes all its Trakt watch history.'):
            return

    ok = trakt_mod.remove_from_history(
        meta.get('content'),
        tmdb=meta.get('tmdb'),
        imdb=meta.get('imdb'),
        trakt_id=meta.get('trakt'),
        season=meta.get('season'),
        episode=meta.get('episode'),
    )
    if ok:
        xbmcgui.Dialog().notification('Trakt', 'Removed from History', xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcgui.Dialog().notification('Trakt', 'Failed to remove from History', xbmcgui.NOTIFICATION_ERROR, 3000)

@_vip_ui_action
def action_clear_history():
    """Clear all items from Trakt history."""
    if not _require_auth():
        return

    if xbmcgui.Dialog().yesno('Trakt', 'Are you sure you want to clear your entire Trakt watch history? This cannot be undone.'):
        prog = xbmcgui.DialogProgress()
        prog.create('Trakt', 'Clearing history...')
        try:
            prog.update(50, 'Removing all watched items...')
            if trakt_mod.clear_history():
                xbmcgui.Dialog().notification('Trakt', 'History Cleared', xbmcgui.NOTIFICATION_INFO, 2500)
                xbmc.executebuiltin('Container.Refresh')
            else:
                xbmcgui.Dialog().notification('Trakt', 'Failed to clear history', xbmcgui.NOTIFICATION_ERROR, 3000)
        finally:
            prog.close()

@_vip_ui_action
def action_follow_user(user):
    """Follow every public list of a single user."""
    if not _require_auth():
        return
    lists = trakt_mod.get_user_lists(user, all_pages=True) or []
    if not lists:
        xbmcgui.Dialog().notification('Trakt', f'No lists for @{user}',
                                      xbmcgui.NOTIFICATION_INFO, 2500)
        return
    prog = xbmcgui.DialogProgressBG()
    prog.create('Trakt', f'Following lists from @{user}...')
    liked = failed = 0
    import time as _t
    for i, lst in enumerate(lists):
        lid = (lst.get('ids') or {}).get('trakt', '')
        if not lid:
            continue
        prog.update(int((i / max(1, len(lists))) * 100), 'Trakt',
                    lst.get('name', '')[:40])
        if trakt_mod.like_list(user, lid):
            liked += 1
        else:
            failed += 1
        _t.sleep(1.1)
    try:
        prog.close()
    except Exception:
        pass
    xbmcgui.Dialog().ok('Trakt',
                        f'Followed {liked} list(s) from @{user}.\n'
                        f'Failed: {failed}')
    xbmc.executebuiltin('Container.Refresh')


@_vip_ui_action
def action_follow_all():
    """Follow every public list of every user I follow."""
    if not _require_auth():
        return
    if not xbmcgui.Dialog().yesno(
        'Trakt - Follow all lists',
        'This will LIKE every public custom list of every user you follow.\n\n'
        'Due to Trakt rate limits this can take several minutes if you follow '
        'many users. Continue?'
    ):
        return
    liked, skipped, failed = trakt_mod.follow_all_lists_from_following()
    xbmcgui.Dialog().ok(
        'Trakt - Follow all lists',
        f'Lists followed: {liked}\n'
        f'Already followed (skipped): {skipped}\n'
        f'Failed: {failed}'
    )
    xbmc.executebuiltin('Container.Refresh')


def action_open_web(url):
    """No-op display: show the URL in a Dialog so users on Kodi w/o a
    browser can copy it. On desktop-ish Kodi builds Kodi cannot directly
    launch a system browser, so we just surface the URL."""
    xbmcgui.Dialog().ok('Trakt', f'Open in your browser:\n\n{url}')


@_vip_ui_action
def action_test_connection():
    """Test Trakt connection and display user info."""
    if not trakt_mod.is_authorized():
        xbmcgui.Dialog().ok('Trakt Test',
                           'Not authorized!\n\n'
                           'Please go to Settings -> Trakt -> Authorize Trakt first.')
        return
    
    xbmc.log('Trakt Test: Fetching user info...', xbmc.LOGINFO)
    me = trakt_mod.get_me()
    if me and me.get('user'):
        user = me['user']
        username = user.get('username', 'Unknown')
        name = user.get('name', '')
        vip = user.get('vip', False)
        private = user.get('private', False)
        
        msg = f'[B]Connection Successful![/B]\n\n'
        msg += f'Username: {username}\n'
        if name:
            msg += f'Name: {name}\n'
        msg += f'VIP: {"Yes" if vip else "No"}\n'
        msg += f'Private: {"Yes" if private else "No"}\n\n'
        msg += 'Scrobbling should work correctly.'
        
        xbmcgui.Dialog().ok('Trakt Test', msg)
        xbmc.log(f'Trakt Test: SUCCESS - User {username}', xbmc.LOGINFO)
    else:
        xbmcgui.Dialog().ok('Trakt Test',
                           '[B]Connection Failed![/B]\n\n'
                           'Could not fetch user info.\n' +
                           (trakt_mod.get_last_error() or 'Check Kodi log for details.') + '\n\n' +
                           'See the diagnostic above before retrying.')
        xbmc.log('Trakt Test: FAILED - Could not fetch user info', xbmc.LOGERROR)



# ── TMDB-backed playback menus for Trakt items ───────────────────────────

@_vip_ui_action
def menu_tv_seasons(tmdb_id, imdb='', trakt_id='', title='', year=''):
    """Render seasons for a Trakt show via TMDB /tv/{id}."""
    if not tmdb_id:
        xbmcgui.Dialog().notification('Trakt', 'Missing TMDB id',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    seasons = tmdb_mod.get_tv_seasons(tmdb_id) or []
    if not seasons:
        xbmcgui.Dialog().notification('Trakt', 'No seasons found',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    for s in seasons:
        s_no = int(s.get('number', 0) or 0)
        name = s.get('name') or f'Season {s_no}'
        count = s.get('episode_count', 0)
        label = f'{name}  [COLOR grey]· {count} ep[/COLOR]'
        li = xbmcgui.ListItem(label=f'[COLOR cyan]{label}[/COLOR]')
        poster = s.get('poster') or ICON
        li.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': FANART})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(name)
            tag.setPlot(s.get('overview') or '')
            tag.setMediaType('season')
        except Exception:
            pass
        # Watchlist action at the season scope uses the SHOW id
        wl_url = _build_url(
            action='trakt_add_watchlist', payload=json.dumps({
                'content': 'show', 'tmdb': str(tmdb_id), 'imdb': imdb,
                'trakt': trakt_id, 'title': title,
            }),
        )
        li.addContextMenuItems([
            ('[COLOR lime]Add show to Trakt Watchlist[/COLOR]',
             f'RunPlugin({wl_url})'),
        ])
        url = _build_url(
            action='trakt_tv_episodes',
            tmdb=str(tmdb_id), imdb=imdb, trakt=trakt_id,
            title=title, year=str(year or ''), season=str(s_no),
        )
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)
    xbmcplugin.setContent(_handle(), 'seasons')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


@_vip_ui_action
def menu_tv_episodes(tmdb_id, season, imdb='', trakt_id='', title='', year=''):
    """Render episodes for a Trakt show/season via TMDB. Each plays via
    Link Zero scraper flow."""
    if not tmdb_id:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    try:
        s_no = int(str(season))
    except (TypeError, ValueError):
        s_no = 0
    eps = tmdb_mod.get_tv_episodes(tmdb_id, s_no) or []
    if not eps:
        xbmcgui.Dialog().notification('Trakt', 'No episodes found',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    show_meta = tmdb_mod.get_metadata(tmdb_id, 'tvshow') or {}
    for e in eps:
        e_no = int(e.get('number', 0) or 0)
        name = e.get('name') or f'Episode {e_no}'
        label = f'S{s_no:02d}E{e_no:02d}  ·  {name}'
        li = xbmcgui.ListItem(label=label)
        still = e.get('still') or ICON
        li.setArt({'icon': still, 'thumb': still, 'poster': still, 'fanart': FANART})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(name)
            tag.setPlot(e.get('overview') or '')
            if e.get('air_date'):
                tag.setPremiered(e['air_date'])
            if e.get('runtime'):
                tag.setDuration(e['runtime'])
            if e.get('rating'):
                tag.setRating(float(e['rating']))
            tag.setSeason(s_no)
            tag.setEpisode(e_no)
            tag.setMediaType('episode')
        except Exception:
            pass
        li.setProperty('IsPlayable', 'true')
        payload = json.dumps({
            'title': title or '',
            'tmdb': str(tmdb_id),
            'content': 'episode',
            'imdb': imdb,
            'year': str(year or ''),
            'season': s_no,
            'episode': e_no,
            'poster': still,
            'show_poster': show_meta.get('poster', ''),
            'fanart': '',
        })
        wl_url = _build_url(
            action='trakt_add_watchlist', payload=json.dumps({
                'content': 'episode', 'tmdb': str(tmdb_id), 'imdb': imdb,
                'trakt': trakt_id, 'title': title,
                'season': s_no, 'episode': e_no,
            }),
        )
        li.addContextMenuItems([
            ('[COLOR lime]Add episode to Trakt Watchlist[/COLOR]',
             f'RunPlugin({wl_url})'),
        ])
        url = _build_url(action='link_zero', payload=payload)
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=False)
    xbmcplugin.setContent(_handle(), 'episodes')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── Watchlist one-tap actions (P2) ───────────────────────────────────────

@_vip_ui_action
def action_add_watchlist(payload_str):
    if not _require_auth():
        return
    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification('Trakt', 'Invalid item data', xbmcgui.NOTIFICATION_ERROR)
        return

    content = meta.get('content', 'movie')
    if content in ('show', 'tvshow', 'episode'):
        kind = 'episode' if meta.get('season') and meta.get('episode') else 'show'
    else:
        kind = 'movie'

    ok = trakt_mod.add_to_watchlist(
        kind,
        tmdb=meta.get('tmdb'),
        imdb=meta.get('imdb'),
        trakt_id=meta.get('trakt'),
        season=meta.get('season'),
        episode=meta.get('episode'),
    )
    if ok:
        xbmcgui.Dialog().notification(
            'Trakt', f'Added to Watchlist: {meta.get("title") or "item"}',
            xbmcgui.NOTIFICATION_INFO, 2500,
        )
    else:
        xbmcgui.Dialog().notification(
            'Trakt', 'Failed to add to Watchlist',
            xbmcgui.NOTIFICATION_ERROR, 2500,
        )


@_vip_ui_action
def action_remove_watchlist(payload_str):
    if not _require_auth():
        return
    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification('Trakt', 'Invalid item data', xbmcgui.NOTIFICATION_ERROR)
        return

    content = meta.get('content', 'movie')
    if content in ('show', 'tvshow', 'episode'):
        kind = 'episode' if meta.get('season') and meta.get('episode') else 'show'
    else:
        kind = 'movie'

    ok = trakt_mod.remove_from_watchlist(
        kind,
        tmdb=meta.get('tmdb'),
        imdb=meta.get('imdb'),
        trakt_id=meta.get('trakt'),
        season=meta.get('season'),
        episode=meta.get('episode'),
    )
    if ok:
        xbmcgui.Dialog().notification(
            'Trakt', f'Removed from Watchlist: {meta.get("title") or "item"}',
            xbmcgui.NOTIFICATION_INFO, 2500,
        )
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcgui.Dialog().notification(
            'Trakt', 'Failed to remove from Watchlist',
            xbmcgui.NOTIFICATION_ERROR, 2500,
        )
