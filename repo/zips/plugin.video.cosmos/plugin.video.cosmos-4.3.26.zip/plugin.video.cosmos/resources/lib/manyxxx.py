# -*- coding: utf-8 -*-
"""Small, self-contained many.xxx catalogue and stream parser."""
import html
import re
import time
from urllib.parse import urljoin
from urllib.request import Request, urlopen


BASE_URL = 'https://many.xxx/'
USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'
)
_PAGE_CACHE = {}
_PAGE_CACHE_TTL = 180


def clear_cache():
    _PAGE_CACHE.clear()


def fetch(url, referer=BASE_URL, timeout=20):
    cached = _PAGE_CACHE.get(url)
    if cached and time.time() - cached[0] < _PAGE_CACHE_TTL:
        return cached[1]
    request = Request(url, headers={
        'User-Agent': USER_AGENT,
        'Referer': referer or BASE_URL,
        'Accept-Language': 'en-GB,en;q=0.8',
    })
    with urlopen(request, timeout=timeout) as response:
        document = response.read().decode('utf-8', 'replace')
    _PAGE_CACHE[url] = (time.time(), document)
    # Keep memory bounded if Kodi stays open for a long session.
    if len(_PAGE_CACHE) > 80:
        oldest = sorted(_PAGE_CACHE, key=lambda key: _PAGE_CACHE[key][0])[:20]
        for key in oldest:
            _PAGE_CACHE.pop(key, None)
    return document


def parse_listing(document, page_url=BASE_URL):
    """Return unique video cards and the next page URL from a KVS listing."""
    items = []
    seen = set()
    pattern = re.compile(
        r'<a\b[^>]*class=["\'][^"\']*thumb_img[^"\']*["\'][^>]*'
        r'href=["\']([^"\']*/videos/[^"\']+)["\'][^>]*'
        r'(?:title=["\']([^"\']*)["\'])?[^>]*>([\s\S]*?)</a>', re.I)
    for match in pattern.finditer(document or ''):
        url = urljoin(page_url, html.unescape(match.group(1)))
        if url in seen:
            continue
        seen.add(url)
        body = match.group(3)
        image = re.search(r'<img\b[^>]*(?:src|data-src)=["\']([^"\']+)', body, re.I)
        duration = re.search(r'class=["\'][^"\']*duration[^"\']*["\'][^>]*>([\s\S]*?)</', body, re.I)
        raw_title = match.group(2) or ''
        if not raw_title:
            alt = re.search(r'<img\b[^>]*alt=["\']([^"\']+)', body, re.I)
            raw_title = alt.group(1) if alt else ''
        title = re.sub(r'\s+', ' ', html.unescape(raw_title)).strip() or 'many.xxx video'
        length = re.sub(r'<[^>]+>', '', duration.group(1) if duration else '')
        items.append({
            'title': title,
            'url': url,
            'thumb': urljoin(page_url, html.unescape(image.group(1))) if image else '',
            'duration': re.sub(r'\s+', ' ', html.unescape(length)).strip(),
        })

    next_url = ''
    current = re.search(r'/(\d+)/?(?:[?#]|$)', page_url.rstrip('/'))
    target_page = (int(current.group(1)) + 1) if current else 2
    for href in re.findall(r'href=["\']([^"\']+)["\']', document or '', re.I):
        absolute = urljoin(page_url, html.unescape(href))
        if re.search(r'/%d/?(?:[?#]|$)' % target_page, absolute):
            next_url = absolute
            break
    return items, next_url


def parse_categories(document, page_url=BASE_URL):
    categories, seen = [], set()
    blocked = ('teen', 'school', '18 years', 'young')
    for attrs, href, body in re.findall(r'<a\b([^>]*href=["\']([^"\']+)["\'][^>]*)>([\s\S]*?)</a>', document or '', re.I):
        url = urljoin(page_url, html.unescape(href))
        if '/categories/' not in url or url.rstrip('/').endswith('/categories') or url in seen:
            continue
        title_match = re.search(r'\btitle=["\']([^"\']+)', attrs, re.I)
        title = title_match.group(1) if title_match else re.sub(r'<[^>]+>', ' ', body)
        title = re.sub(r'\s+', ' ', html.unescape(title)).strip()
        if not title or title.isdigit() or any(word in title.casefold() for word in blocked):
            continue
        seen.add(url)
        categories.append({'title': title, 'url': url})
    return categories




def parse_sources(document, page_url):
    """Extract the site's signed MP4 URLs in highest-quality-first order."""
    sources = []
    seen = set()
    for tag in re.findall(r'<source\b[^>]*>', document or '', re.I):
        src = re.search(r'\bsrc=["\']([^"\']+)', tag, re.I)
        if not src:
            continue
        url = urljoin(page_url, html.unescape(src.group(1)))
        if url in seen or not re.search(r'\.mp4(?:/|\?|$)', url, re.I):
            continue
        seen.add(url)
        label_match = re.search(r'\blabel=["\']([^"\']*)', tag, re.I)
        label = html.unescape(label_match.group(1) if label_match else '').strip()
        if not label:
            quality = re.search(r'_(\d+)[mp]\.mp4', url, re.I)
            label = (quality.group(1) + 'p') if quality else 'MP4'
        sources.append({'label': label, 'url': url})
    sources.sort(
        key=lambda item: int((re.search(r'(\d+)', item['label']) or ['0'])[0]),
        reverse=True)
    return sources


def kodi_stream_url(url, referer):
    from urllib.parse import quote_plus
    return '%s|User-Agent=%s&Referer=%s' % (
        url, quote_plus(USER_AGENT), quote_plus(referer))
