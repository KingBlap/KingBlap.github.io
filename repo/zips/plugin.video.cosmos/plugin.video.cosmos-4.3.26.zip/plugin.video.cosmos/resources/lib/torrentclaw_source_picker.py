"""Independent TorrentClaw source picker; no shared picker modifications."""
import xbmc
import xbmcgui
import xbmcvfs

ADDON_PATH = xbmcvfs.translatePath('special://home/addons/plugin.video.cosmos/')
_LP_LIST = 4001
_LP_PLAY = 4003


class TorrentClawSourcePickerDialog(xbmcgui.WindowXMLDialog):
    """Scrollable stream list for TorrentClaw torrents.

    Uses ``TorrentClawSourcePicker.xml`` which shares control IDs with
    ``SportLinkPicker.xml`` so the same click / key handlers apply.

    ``links`` is a list of dicts: ``{label, meta, icon}`` where ``icon``
    is an absolute file path for the host icon.
    """

    def __init__(self, *args, **kwargs):
        self.quality_label = kwargs.pop('quality_label', '')
        self.section_icon  = kwargs.pop('section_icon', '')
        self.links = kwargs.pop('links', [])
        self.current_index = 0
        self.selected_index = None
        super().__init__(*args, **kwargs)

    def _refresh_banner(self):
        if not self.links:
            return
        item = self.links[self.current_index]
        try:
            self.setProperty('lp_sel_icon',  item.get('icon') or self.section_icon or '')
            self.setProperty('lp_sel_title', item.get('label', ''))
            self.setProperty('lp_sel_meta',  item.get('meta', ''))
        except Exception as e:
            xbmc.log(f'TorrentClawSourcePickerDialog banner error: {e}', xbmc.LOGERROR)

    def onInit(self):
        try:
            self.setProperty('lp_quality_label', self.quality_label)
            self.setProperty('lp_count', str(len(self.links)))
        except Exception as e:
            xbmc.log(f'TorrentClawSourcePickerDialog header error: {e}', xbmc.LOGERROR)

        try:
            listctl = self.getControl(_LP_LIST)
            listctl.reset()
            for i, item in enumerate(self.links):
                li = xbmcgui.ListItem(label=item.get('label', ''))
                li.setProperty('meta', item.get('meta', ''))
                li.setProperty('icon', item.get('icon') or self.section_icon or '')
                li.setProperty('selected', 'true' if i == self.current_index else 'false')
                listctl.addItem(li)
            if self.links:
                listctl.selectItem(self.current_index)
        except Exception as e:
            xbmc.log(f'TorrentClawSourcePickerDialog list error: {e}', xbmc.LOGERROR)

        self._refresh_banner()

        try:
            self.setFocusId(_LP_LIST if self.links else _LP_PLAY)
        except Exception as e:
            xbmc.log(f'TorrentClawSourcePickerDialog focus error: {e}', xbmc.LOGERROR)

    def _mark_current(self, new_index):
        try:
            listctl = self.getControl(_LP_LIST)
            for i in range(listctl.size()):
                listctl.getListItem(i).setProperty(
                    'selected', 'true' if i == new_index else 'false')
        except Exception as e:
            xbmc.log(f'TorrentClawSourcePickerDialog mark error: {e}', xbmc.LOGERROR)
        self.current_index = new_index
        self._refresh_banner()

    def onClick(self, controlId):
        if controlId == _LP_LIST:
            try:
                pos = self.getControl(_LP_LIST).getSelectedPosition()
            except Exception:
                pos = -1
            if 0 <= pos < len(self.links):
                self._mark_current(pos)
                self.selected_index = pos
                self.close()
        elif controlId == _LP_PLAY:
            if self.links:
                self.selected_index = self.current_index
            self.close()

    def onAction(self, action):
        if action.getId() in (
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_PREVIOUS_MENU,
        ):
            self.selected_index = None
            self.close()


def show(links, title='', section_icon=''):
    """Return the chosen TorrentClaw source, or None on Back/cancel."""
    if not links:
        return None
    dialog = TorrentClawSourcePickerDialog(
        'TorrentClawSourcePicker.xml', ADDON_PATH, 'Default', '720p',
        links=links, quality_label=title, section_icon=section_icon,
    )
    dialog.doModal()
    selected = dialog.selected_index
    del dialog
    if selected is None or not 0 <= selected < len(links):
        return None
    return links[selected]
