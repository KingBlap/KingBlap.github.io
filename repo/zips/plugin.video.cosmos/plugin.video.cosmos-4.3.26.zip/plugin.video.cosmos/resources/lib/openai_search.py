# -*- coding: utf-8 -*-
"""Optional AI query expansion for Universal Search."""
import json
import re
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon


HORDE_API_URL = 'https://aihorde.net/api/v2/generate/text'
HORDE_MODELS_URL = 'https://aihorde.net/api/v2/status/models?type=text'
HORDE_ANONYMOUS_KEY = '0000000000'
HORDE_WAIT_SECONDS = 25
MAX_VARIANTS = 8


def _parse_queries(content, query):
    """Extract and normalize the query list from a model response."""
    content = (content or '').strip()
    fenced = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', content, re.I | re.S)
    if fenced:
        content = fenced.group(1)
    object_start = content.find('{')
    if object_start < 0:
        return []
    parsed, _ = json.JSONDecoder().raw_decode(content[object_start:])
    values = parsed.get('queries', [])
    if not isinstance(values, list):
        return []
    seen = {query.lower()}
    result = []
    for value in values:
        value = str(value).strip()
        key = value.lower()
        if value and key not in seen:
            seen.add(key)
            result.append(value)
    return result[:MAX_VARIANTS]


def _instruction(query):
    return (
        '### Instruction:\nIdentify movies or television shows from the '
        'description. Return only compact valid JSON in this form: '
        '{"queries":["Exact Famous Title 1","Exact Famous Title 2"]}. '
        'Entries must primarily be real likely titles, not genres. Include up to '
        '8, with the strongest match first. Supply no commentary and do not '
        f'include adult content. Description: {query}\n### Response:\n'
    )


def _request_json(url, payload=None, headers=None, method=None, timeout=12):
    body = None if payload is None else json.dumps(payload).encode('utf-8')
    request = Request(url, data=body, headers=headers or {}, method=method)
    with urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode('utf-8', errors='replace'))


def _horde_models(headers):
    """Choose currently online instruction-following text models."""
    available = _request_json(HORDE_MODELS_URL, headers={
        'Client-Agent': headers['Client-Agent'],
        'User-Agent': headers['User-Agent'],
    }, timeout=8)
    ranked = []
    for item in available if isinstance(available, list) else []:
        name = str(item.get('name') or '').strip()
        lower = name.lower()
        if not name:
            continue
        # Tiny models frequently ignore the JSON contract and turn the prompt
        # into free-form story continuation, which is unusable for TMDB.
        if re.search(r'(?:^|[-_/])(?:\d{2,3}m|0\.\d+b|1b)(?:[-_/.]|$)', lower):
            continue
        if 'instruct' in lower or 'instruction' in lower:
            suitability = 3
        elif 'qwen' in lower or re.search(r'(?:^|[-_/])it(?:[-_/]|$)', lower):
            suitability = 2
        else:
            continue
        try:
            workers = int(item.get('count') or 0)
            queued = float(item.get('queued') or 0)
        except (ValueError, TypeError):
            workers, queued = 0, 0
        ranked.append((suitability, workers, -queued, name))
    ranked.sort(reverse=True)
    return [entry[3] for entry in ranked[:6]]


def _horde_expand(query):
    """Generate query variants using AI Horde's anonymous asynchronous API."""
    headers = {
        'apikey': HORDE_ANONYMOUS_KEY,
        'Client-Agent': 'COSMOS:4.1.93:github.com/zeus768',
        'Content-Type': 'application/json',
        'User-Agent': 'COSMOS Universal Search',
    }
    payload = {
        'prompt': _instruction(query),
        'params': {
            'n': 1,
            'max_length': 120,
            'max_context_length': 1024,
            'temperature': 0.1,
            'top_p': 0.9,
            'top_k': 40,
            'rep_pen': 1.05,
        },
        'models': _horde_models(headers),
        'trusted_workers': False,
        'slow_workers': True,
    }
    if not payload['models']:
        raise ValueError('AI Horde has no instruction-following model online')
    queued = _request_json(
        HORDE_API_URL + '/async', payload, headers, 'POST', 12,
    )
    request_id = str(queued.get('id') or '').strip()
    if not re.fullmatch(r'[0-9a-fA-F-]{32,36}', request_id):
        raise ValueError('AI Horde returned no valid request ID')

    status_url = HORDE_API_URL + '/status/' + request_id
    deadline = time.monotonic() + HORDE_WAIT_SECONDS
    while time.monotonic() < deadline:
        time.sleep(1)
        status = _request_json(status_url, headers={
            'Client-Agent': headers['Client-Agent'],
            'User-Agent': headers['User-Agent'],
        }, timeout=6)
        generations = status.get('generations') or []
        if generations:
            values = _parse_queries(generations[0].get('text'), query)
            if values:
                xbmc.log(
                    'COSMOS AI Horde search expansion succeeded with ' +
                    str(generations[0].get('model') or 'an anonymous model'),
                    xbmc.LOGDEBUG,
                )
            return values
        if status.get('faulted'):
            raise ValueError('AI Horde generation faulted')
        if status.get('done'):
            return []

    # Avoid leaving a queued anonymous request behind after Cosmos gives up.
    try:
        _request_json(status_url, headers={
            'Client-Agent': headers['Client-Agent'],
            'User-Agent': headers['User-Agent'],
        }, method='DELETE', timeout=4)
    except (HTTPError, URLError, OSError, ValueError, TypeError, AttributeError):
        pass
    raise TimeoutError('AI Horde did not respond within 25 seconds')


def expand_query(query):
    """Return likely movie/TV title queries for a natural-language prompt."""
    query = (query or '').strip()
    enabled = (xbmcaddon.Addon().getSetting('ai_search_enabled') or 'true').lower()
    if not query or enabled != 'true':
        return []

    try:
        return _horde_expand(query)
    except (HTTPError, URLError, OSError, ValueError, TypeError, AttributeError) as error:
        xbmc.log(f'COSMOS AI Horde search expansion failed: {error}', xbmc.LOGWARNING)
        return []
