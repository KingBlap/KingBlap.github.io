import xbmcgui


class TelegramQrDialog(xbmcgui.WindowXMLDialog):
    def onInit(self):
        self.setFocusId(9001)

    def onClick(self, control_id):
        if control_id == 9001:
            self.close()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.close()
        elif action.getId() in (7, 100) and self.getFocusId() == 9001:
            self.close()
        else:
            super().onAction(action)
