# -*- coding: utf-8 -*-
"""Universal search for C.O.S.M.O.S.

Crawls the configured playlist tree (starting at the menu base URL) and
indexes every content / tv-show item it finds. The query is matched (case
insensitive, substring) against the item name plus any year. Results are
returned with all their labelled links (both direct / non-debrid and the
Search4k / Search1080 / Search720 debrid tokens) so the caller can show
them mixed together with a clear "Direct" / "Debrid" label.

A JSON disk cache keeps the crawled index hot for 30 minutes so repeated
searches don't re-download every feed on the network.
"""
import json
import os
import re
import time

import xbmc
import xbmcvfs

from . import parser
from . import filehost


PROFILE_DIR = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/')
CACHE_FILE = os.path.join(PROFILE_DIR, 'search_index.json')
CACHE_TTL = 30 * 60  # 30 min
MAX_DEPTH = 4        # hard upper bound even if setting says larger
MAX_FEEDS = 400      # safety net: never crawl more than N feeds


def _ensure_profile():
    if not os.path.isdir(PROFILE_DIR):
        try:
            os.makedirs(PROFILE_DIR)
        except OSError:
            pass


def _load_cache():
    _ensure_profile()
    if not os.path.isfile(CACHE_FILE):
        return None
    try:
        with open(CACHE_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp)
        if not isinstance(data, dict):
            return None
        if time.time() - data.get('_ts', 0) > CACHE_TTL:
            return None
        return data
    except (ValueError, OSError):
        return None


def _save_cache(data):
    _ensure_profile()
    data['_ts'] = time.time()
    try:
        with open(CACHE_FILE, 'w', encoding='utf-8') as fp:
            json.dump(data, fp)
    except OSError as e:
        xbmc.log(f'COSMOS search: cache write failed: {e}', xbmc.LOGWARNING)


def clear_cache():
    try:
        if os.path.isfile(CACHE_FILE):
            os.remove(CACHE_FILE)
            return True
    except OSError:
        pass
    return False


def _classify_link(url):
    """Return ('direct' | 'debrid' | 'magnet', quality_str)."""
    if not url:
        return 'direct', ''
    u = url.strip().lower()
    if u in filehost.SEARCH_TOKENS:
        return 'debrid', filehost.SEARCH_TOKENS[u]
    if u.startswith('magnet:'):
        return 'magnet', ''
    return 'direct', ''


def _label_for_link(raw_label, url):
    """Return a display label prefixed with [Direct] / [Debrid] / [Magnet]."""
    kind, quality = _classify_link(url)
    base = (raw_label or '').strip()
    if kind == 'debrid':
        tag = f'[COLOR gold][Debrid{(" " + quality) if quality else ""}][/COLOR]'
    elif kind == 'magnet':
        tag = '[COLOR orange][Magnet][/COLOR]'
    else:
        tag = '[COLOR lime][Direct][/COLOR]'
    return f'{tag} {base}' if base else tag


# ── Crawl ────────────────────────────────────────────────────────────────

def _build_index(base_url, progress_cb=None, max_depth=MAX_DEPTH):
    """BFS-crawl the feed tree, collecting every content item found.

    Returns a dict:
        {
          'items': [
            {'name', 'tmdb', 'content', 'links': [{'label','url'}],
             'feed', 'path', 'season'(opt), 'episode'(opt)},
            ...
          ]
        }
    """
    seen = set()
    queue = [(base_url, 0, '')]
    items = []
    feeds_done = 0

    while queue and feeds_done < MAX_FEEDS:
        url, depth, path = queue.pop(0)
        if not url or url in seen:
            continue
        seen.add(url)
        feeds_done += 1

        if progress_cb:
            progress_cb(feeds_done, path or url)

        body = parser.fetch_url(url)
        if not body:
            continue
        kind, entries = parser.parse_page(body)

        if kind == 'directory':
            if depth + 1 > max_depth:
                continue
            for it in entries:
                child = (it.get('url') or '').strip()
                if child:
                    new_path = f"{path} / {it.get('name', '')}".strip(' /')
                    queue.append((child, depth + 1, new_path))
        elif kind == 'tvshow':
            for show in entries:
                flat_links = []
                for season in show.get('seasons', []):
                    for ep in season.get('episodes', []):
                        for lk in ep.get('links', []):
                            flat_links.append({
                                'label': f"S{season.get('seasonNo','?')}E{ep.get('episode','?')} {lk.get('label','')}",
                                'url': lk.get('url', ''),
                            })
                items.append({
                    'name': show.get('name', ''),
                    'tmdb': show.get('tmdb', ''),
                    'content': 'tvshow',
                    'links': flat_links,
                    'feed': url,
                    'path': path,
                    'seasons': show.get('seasons', []),
                    'thumb': show.get('thumb', ''),
                })
        else:  # content
            for it in entries:
                items.append({
                    'name': it.get('name', ''),
                    'tmdb': it.get('tmdb', ''),
                    'content': it.get('content', 'movie'),
                    'links': it.get('links', []),
                    'feed': url,
                    'path': path,
                    'thumb': it.get('thumb', ''),
                    'season': it.get('season', ''),
                    'episode': it.get('episode', ''),
                })

    return {'items': items}


def get_index(base_url, force_refresh=False, progress_cb=None, max_depth=MAX_DEPTH):
    if not force_refresh:
        cached = _load_cache()
        if cached and cached.get('base') == base_url:
            return cached
    data = _build_index(base_url, progress_cb=progress_cb, max_depth=max_depth)
    data['base'] = base_url
    _save_cache(data)
    # Feed the newly-added tracker so the 7-day row stays up to date.
    try:
        from . import newly_added as _na
        _na.observe(data.get('items') or [])
    except Exception as _e:
        xbmc.log(f'COSMOS search: newly_added.observe failed: {_e}',
                 xbmc.LOGWARNING)
    return data


# ── Search ───────────────────────────────────────────────────────────────

_WORD_RE = re.compile(r"[A-Za-z0-9]+")


def _tokens(text):
    return [t.lower() for t in _WORD_RE.findall(text or '')]


def search(index, query):
    """Return a scored list of matching items. Higher score = better match."""
    if not isinstance(index, dict):
        return []
    q_lower = query.lower()
    q_tokens = _tokens(query)
    if not q_tokens:
        return []
    q_joined = ' '.join(q_tokens)

    results = []
    for it in index.get('items', []):
        name = parser.strip_bbcode(it.get('name', ''))
        name_lower = name.lower()
        name_tokens = _tokens(name)
        name_joined = ' '.join(name_tokens)

        score = 0
        # 1. Exact phrase match (case-insensitive, punctuation-agnostic)
        if q_lower == name_lower:
            score = 10000 # Highest score for perfect match
        elif q_joined == name_joined: # Exact token sequence match
            score = 9000
        
        # 2. All query tokens present as whole words, in order
        elif all(q_token in name_tokens for q_token in q_tokens):
            current_name_token_idx = 0
            all_found_in_order = True
            for q_t in q_tokens:
                try:
                    # Find q_t in name_tokens starting from current_name_token_idx
                    idx_in_name = name_tokens.index(q_t, current_name_token_idx)
                    current_name_token_idx = idx_in_name + 1
                except ValueError:
                    all_found_in_order = False
                    break
            
            if all_found_in_order:
                score = 8000 + len(q_tokens) * 100 # Boost for longer, ordered matches
            else:
                score = 7000 + len(q_tokens) * 50 # All tokens present, but not necessarily in order

        # 3. Query phrase is a substring of the name phrase (tokenized)
        elif q_joined in name_joined:
            score = 5000 + max(0, 100 - len(name_joined)) # Bonus for shorter name

        # 4. Significant token overlap (at least 50% of query tokens)
        else:
            hits = sum(1 for t in q_tokens if t in name_tokens)
            if hits >= len(q_tokens) / 2 and len(q_tokens) > 1: # Only if more than one token
                score = 2000 + hits * 100
            elif hits > 0: # Any token match
                score = 500 + hits * 50

        # 5. Fallback: full query substring inside raw name (covers punctuation)
        if score < 500 and q_lower.replace(' ', '') in name_lower.replace(' ', ''):
            score = max(score, 100) # Ensure it's not too low if other methods failed

        # Add a small penalty for very short queries that match common words broadly
        if len(q_tokens) == 1 and len(q_tokens[0]) <= 3 and score > 500:
            # If it's a single, short, common word, and not an exact match, reduce score
            if q_joined != name_joined and q_lower != name_lower:
                score = score // 2 # Halve the score
        if score > 0:
            results.append((score, it))

    results.sort(key=lambda x: (-x[0], x[1].get('name', '')))
    return [it for _, it in results]
