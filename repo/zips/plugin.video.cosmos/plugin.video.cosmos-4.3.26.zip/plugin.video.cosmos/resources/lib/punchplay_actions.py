"""Explicit PunchPlay catalog actions using official scoped Platform APIs."""
import datetime
import json
import os
import sqlite3
import time
from urllib.parse import urlencode

import xbmc
import xbmcgui

from . import punchplay as api

OPERATIONS = {
    'watched': ('Mark as Watched on PunchPlay...', 'history:write'),
    'unwatched': ('Mark as Unwatched on PunchPlay...', 'history:write'),
    'plan': ('Plan to Watch on PunchPlay', 'ratings:write'),
    'unplan': ('Clear PunchPlay Plan to Watch', 'ratings:write'),
    'rate': ('Rate on PunchPlay...', 'ratings:write'),
    'unrate': ('Remove PunchPlay Rating', 'ratings:write'),
    'favourite': ('Favourite on PunchPlay', 'ratings:write'),
    'unfavourite': ('Remove PunchPlay Favourite', 'ratings:write'),
    'status': ('Set PunchPlay Show Status...', 'ratings:write'),
}
STATUSES = [('Watched', 'WATCHED'), ('Watching', 'WATCHING'), ('Planning', 'PLANNING'),
            ('On Hold', 'ON_HOLD'), ('Dropped', 'DROPPED'), ('Clear status', None)]


def scopes():
    token = api._load_token() or {}
    value = token.get('scope', token.get('scopes'))
    if isinstance(value, str):
        return set(value.split())
    if isinstance(value, list):
        return set(value)
    return None  # Older token records: let the server enforce access.


def context_items(source):
    if not api.has_token():
        return []
    granted = scopes()
    payload = json.dumps({key: source.get(key) for key in
                          ('tmdbId', 'type', 'name', 'year', 'posterPath')})
    items = []
    for operation, (label, scope) in OPERATIONS.items():
        if operation == 'status' and source.get('type') != 'show':
            continue
        required = {scope}
        if operation == 'unwatched':
            required.add('ratings:write')
        if source.get('type') == 'show' and operation == 'watched':
            required.add('profile:read')
        if granted is not None and not required.issubset(granted):
            continue
        items.append((label, 'RunPlugin(%s)' % api._url(
            action='punchplay_catalog_action', operation=operation, payload=payload)))
    return items


def request(path, method='GET', payload=None):
    """Serialize actions, pace requests, and persist account quota cooldowns.

    Never retry a failed history POST automatically: it may have been recorded.
    The existing authorized client refreshes once only on a definitive 401.
    """
    os.makedirs(api.DATA_PATH, exist_ok=True)
    db = sqlite3.connect(os.path.join(api.DATA_PATH, 'punchplay_actions.db'), timeout=2)
    try:
        db.execute('CREATE TABLE IF NOT EXISTS limits (key TEXT PRIMARY KEY, value TEXT)')
        db.execute('BEGIN IMMEDIATE')
        account = api._partner_identity()
        row = db.execute('SELECT value FROM limits WHERE key=?', (account,)).fetchone()
        state = json.loads(row[0]) if row else {}
        now = time.time()
        if now < state.get('until', 0):
            raise ValueError('PunchPlay request limit reached; try again after the cooldown')
        time.sleep(max(0, 1 - (now - state.get('last', 0))))
        status, data, headers = api._authorized_request(path, method=method, payload=payload)
        state['last'] = time.time()
        if status == 429:
            try:
                wait = max(1, int(api._header(headers, 'Retry-After') or 60))
            except (ValueError, OverflowError):
                wait = 60
            state['until'] = time.time() + wait
        elif api._header(headers, 'X-RateLimit-Remaining') == '0':
            try:
                state['until'] = max(time.time() + 1, float(api._header(headers, 'X-RateLimit-Reset')))
            except (ValueError, OverflowError):
                state['until'] = time.time() + 60
        db.execute('INSERT OR REPLACE INTO limits VALUES (?,?)', (account, json.dumps(state)))
        db.commit()
    finally:
        db.close()
    if status not in (200, 201) or not isinstance(data, dict) or data.get('error'):
        data = data if isinstance(data, dict) else {}
        if status == 403 and data.get('required_scope'):
            raise ValueError('PunchPlay permission required: ' + str(data['required_scope']))
        raise ValueError(str((data or {}).get('message') or 'PunchPlay did not confirm this action'))
    return data


def patch(path, payload):
    result = request(path + '/interact', 'PATCH', payload)
    if result.get('ok') is not True:
        raise ValueError('PunchPlay did not confirm this update')


def episode_watch(source, path, dialog):
    season_text = dialog.numeric(0, 'PunchPlay — Season number (0 for specials)')
    if not season_text:
        return False
    season = int(season_text)
    if season < 0:
        raise ValueError('Invalid season number')
    choice = dialog.select('Mark Watched on PunchPlay', ['One episode', 'All aired episodes in this season'])
    if choice < 0:
        return False
    episode = None
    if choice == 0:
        text = dialog.numeric(0, 'PunchPlay — Episode number')
        if not text:
            return False
        episode = int(text)
        if episode < 1:
            raise ValueError('Invalid episode number')
    detail = request(path + '/season/' + str(season))
    today = datetime.datetime.now(datetime.timezone.utc).date().isoformat()
    episodes = []
    for row in detail.get('episodes') or []:
        if not isinstance(row, dict) or (episode is not None and row.get('episodeNumber') != episode):
            continue
        air_date = str(row.get('airDate') or '')[:10]
        # Future or undated episodes are not silently marked watched.
        if not air_date or air_date > today:
            continue
        episodes.append({key: row[key] for key in
                         ('episodeNumber', 'name', 'runtime', 'communityRating', 'airDate') if key in row})
    if not episodes:
        raise ValueError('No matching aired episodes found in this PunchPlay season')
    body = {'title': source['name'], 'year': int(source['year']), 'episodes': episodes,
            'allowRewatches': False, 'allowUnreleased': False}
    if len(json.dumps(body).encode('utf-8')) > 64 * 1024:
        raise ValueError('Season exceeds PunchPlay request size; select one episode')
    result = request(path + '/season/' + str(season) + '/watch', 'POST', body)
    if not isinstance(result.get('inserted'), int):
        raise ValueError('PunchPlay did not confirm the episode watches')
    return True


def action(operation, payload):
    dialog = xbmcgui.Dialog()
    try:
        if not api.has_token():
            raise ValueError('Sign in to PunchPlay first')
        if operation not in OPERATIONS:
            raise ValueError('Invalid PunchPlay action')
        source = json.loads(payload)
        if not isinstance(source, dict) or source.get('type') not in ('movie', 'show'):
            raise ValueError('Invalid PunchPlay title')
        tmdb = int(source.get('tmdbId') or 0)
        if tmdb <= 0:
            raise ValueError('Missing title ID')
        required = {OPERATIONS[operation][1]}
        if operation == 'unwatched':
            required.add('ratings:write')
        granted = scopes()
        if granted is not None and not required.issubset(granted):
            raise ValueError('PunchPlay permission required: ' + ', '.join(sorted(required - granted)))
        path = '/title/%s/%s' % (source['type'], tmdb)
        show = source['type'] == 'show'
        if operation == 'watched':
            if show:
                if not episode_watch(source, path, dialog):
                    return
            else:
                result = request(path + '/history', 'POST',
                    {'title': source['name'], 'year': int(source['year']),
            'watchedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()})
                if not result.get('id'):
                    raise ValueError('PunchPlay did not confirm the movie watch')
        elif operation == 'unwatched':
            if not dialog.yesno('Mark Unwatched on PunchPlay',
                    'Remove all recorded watches for this title and clear its watched status?'):
                return
            result = request(path + '/history', 'DELETE')
            if result.get('ok') is not True:
                raise ValueError('PunchPlay did not confirm history removal')
            try:
                patch(path, {'watchedAt': None, **({'showStatus': None} if show else {})})
            except (ValueError, OSError, sqlite3.Error) as exc:
                raise ValueError('Watch history removed; watched-status clearing failed: ' + str(exc))
        elif operation == 'status':
            if not show:
                raise ValueError('Show status is only available for shows')
            choice = dialog.select('PunchPlay Show Status', [label for label, _ in STATUSES])
            if choice < 0:
                return
            patch(path, {'showStatus': STATUSES[choice][1]})
        elif operation == 'rate':
            text = dialog.numeric(0, 'PunchPlay rating (1-10)')
            if not text:
                return
            rating = int(text)
            if not 1 <= rating <= 10:
                raise ValueError('Rating must be from 1 to 10')
            patch(path, {'rating': rating})
        else:
            body = {'plan': {'wantToWatch': True}, 'unplan': {'wantToWatch': False},
                    'favourite': {'isFavourite': True}, 'unfavourite': {'isFavourite': False},
                    'unrate': {'rating': None}}[operation]
            patch(path, body)
        # Refresh this directory from the public cache, without pulling all
        # account resources after each action or claiming private state in rows.
        dialog.notification('PunchPlay', 'Action saved on PunchPlay', xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('Container.Refresh')
    except (ValueError, TypeError, KeyError, OSError, sqlite3.Error) as exc:
        dialog.notification('PunchPlay', str(exc)[:300], xbmcgui.NOTIFICATION_ERROR, 5000)
