"""BBC live television channels for the Freebie TV hub."""
import re
import os
from urllib.request import Request, urlopen
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ICON = xbmcvfs.translatePath(os.path.join(
    xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'icon_freebie_tv.png'))
LIVE_PAGES = {
    'BBC One': 'bbcone', 'BBC Two': 'bbctwo', 'BBC Three': 'bbcthree',
    'BBC Four': 'bbcfour', 'BBC News': 'bbcnews', 'BBC Scotland': 'bbcscotland',
    'CBBC': 'cbbc', 'CBeebies': 'cbeebies',
}
FALLBACKS = {
    'BBC One': 'bbc_one_london', 'BBC Two': 'bbc_two_hd', 'BBC Three': 'bbc_three_hd',
    'BBC Four': 'bbc_four_hd', 'BBC News': 'bbc_news_channel_hd', 'CBBC': 'cbbc_hd',
    'CBeebies': 'cbeebies_hd', 'BBC Scotland': 'bbc_scotland_hd',
}
FALLBACK_URL = 'https://vs-hls-push-uk-live.akamaized.net/x=4/i=urn:bbc:pips:service:{}/iptv_hd_abr_v1.m3u8'
FALLBACK_PUSHB = 'https://vs-hls-pushb-uk-live.akamaized.net/x=4/i=urn:bbc:pips:service:{}/iptv_hd_abr_v1.m3u8'
PUSHB_CHANNELS = {'BBC Three', 'BBC Four', 'CBBC', 'CBeebies', 'BBC Scotland'}

def _stream(name, slug):
    try:
        req = Request('https://www.bbc.co.uk/iplayer/live/' + slug,
                      headers={'User-Agent': 'Mozilla/5.0 (Kodi Cosmos)'})
        html = urlopen(req, timeout=15).read().decode('utf-8', 'ignore')
        matches = re.findall(r'https?[^"\\ ]+?\.m3u8(?:\?[^"\\ ]*)?', html)
        if matches:
            return matches[0].replace('\\u0026', '&')
    except Exception as exc:
        xbmc.log('COSMOS: BBC scrape failed for %s: %s' % (name, exc), xbmc.LOGDEBUG)
    template = FALLBACK_PUSHB if name in PUSHB_CHANNELS else FALLBACK_URL
    return template.format(FALLBACKS.get(name, ''))

def root(handle):
    count = 0
    for name, slug in LIVE_PAGES.items():
        stream = _stream(name, slug)
        if not stream:
            continue
        li = xbmcgui.ListItem(label=name, path=stream)
        # Live channels are not episodes or films.  Explicitly clear Kodi's
        # playback counters so completing a live stream cannot add a watched
        # checkmark or resume overlay to the channel row.
        li.setInfo('video', {'title': name, 'mediatype': 'video', 'playcount': 0})
        li.setProperty('ResumeTime', '0')
        li.setProperty('TotalTime', '0')
        li.setProperty('IsPlayable', 'true')
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        headers = 'User-Agent=Mozilla/5.0&Referer=https://www.bbc.co.uk/iplayer/&Origin=https://www.bbc.co.uk'
        li.setProperty('inputstream.adaptive.manifest_headers', headers)
        li.setProperty('inputstream.adaptive.stream_headers', headers)
        li.setArt({'thumb': ICON, 'icon': ICON, 'poster': ICON, 'fanart': ICON})
        xbmcplugin.addDirectoryItem(handle, stream, li, isFolder=False)
        count += 1
    if not count:
        xbmcgui.Dialog().notification('BBC Channels', 'No live channels are available in this region.', xbmcgui.NOTIFICATION_ERROR, 3500)
    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle, succeeded=bool(count), cacheToDisc=False)
