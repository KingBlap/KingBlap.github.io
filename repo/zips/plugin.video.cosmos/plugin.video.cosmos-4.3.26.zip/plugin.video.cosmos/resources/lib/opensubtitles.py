# -*- coding: utf-8 -*-
"""
OpenSubtitles.com REST API integration for C.O.S.M.O.S.

Handles subtitle search, download, and optional user authentication
using the OpenSubtitles.com v1 REST API.
"""

import json
import os
import urllib.request
import urllib.parse
import threading

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'plugin.video.cosmos'
ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/')
_ADDON = None
_AUTO_LOAD_LOCK = threading.Lock()
_AUTO_LOAD_ACTIVE = set()
_LAST_PLAYBACK_META = {}


def _addon():
    global _ADDON
    if _ADDON is None:
        _ADDON = xbmcaddon.Addon(ADDON_ID)
    return _ADDON


BASE_URL = 'https://api.opensubtitles.com/api/v1'
APP_USER_AGENT = 'CosmosKodi v4.0.0'
DEFAULT_API_KEY = 'rZDSY7fV5JDbFBPHpgRywpybhIqi7s6c'


# ── Helpers ──────────────────────────────────────────────────────────────────


def _api_key():
    return (_addon().getSetting('opensubtitles_api_key') or DEFAULT_API_KEY).strip()


def _token():
    return _addon().getSetting('opensubtitles_token') or ''


def _language():
    return _addon().getSetting('opensubtitles_language') or 'en'


def _language_sequence():
    """Return the primary language followed by unique fallback languages."""
    primary = (_language() or 'en').strip().lower()
    fallback_value = _addon().getSetting('opensubtitles_fallback_languages') or 'en'
    languages = [primary] if primary else ['en']
    for value in fallback_value.split(','):
        language = value.strip().lower()
        if language and language not in languages:
            languages.append(language)
    return languages


def _setting_enabled(setting_id, default=False):
    value = (_addon().getSetting(setting_id) or '').strip().lower()
    return default if not value else value == 'true'


def _subtitle_flag(value):
    return value is True or str(value or '').strip().lower() in ('1', 'true', 'yes', 'only')


def _rank_results(results):
    """Rank results according to the user's forced and SDH preferences."""
    prefer_forced = _setting_enabled('opensubtitles_prefer_forced')
    prefer_hi = _setting_enabled('opensubtitles_prefer_hearing_impaired')

    def sort_key(item):
        attrs = item.get('attributes') or {}
        forced = _subtitle_flag(attrs.get('foreign_parts_only'))
        hearing_impaired = _subtitle_flag(attrs.get('hearing_impaired'))
        try:
            download_count = float(attrs.get('download_count') or 0)
        except (TypeError, ValueError):
            download_count = 0
        try:
            rating = float(attrs.get('ratings') or 0)
        except (TypeError, ValueError):
            rating = 0
        return (
            0 if prefer_forced and forced else 1,
            0 if prefer_hi and hearing_impaired else 1,
            -download_count,
            -rating,
        )

    return sorted(results or [], key=sort_key)


def _headers(with_auth=True):
    h = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Api-Key': _api_key(),
        'User-Agent': APP_USER_AGENT,
    }
    if with_auth:
        tok = _token()
        if tok:
            h['Authorization'] = f'Bearer {tok}'
    return h


def _http_get(path, params=None):
    url = f'{BASE_URL}{path}'
    if params:
        url = f'{url}?{urllib.parse.urlencode(params)}'
    req = urllib.request.Request(url, headers=_headers())
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except Exception as exc:
        xbmc.log(f'COSMOS [OpenSubtitles] GET {path} failed: {exc}', xbmc.LOGERROR)
        return None


def _http_post(path, body, with_auth=True):
    data = json.dumps(body).encode('utf-8')
    req = urllib.request.Request(
        f'{BASE_URL}{path}', data=data, headers=_headers(with_auth=with_auth), method='POST'
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except Exception as exc:
        xbmc.log(f'COSMOS [OpenSubtitles] POST {path} failed: {exc}', xbmc.LOGERROR)
        return None


def _http_delete(path):
    req = urllib.request.Request(
        f'{BASE_URL}{path}', headers=_headers(), method='DELETE'
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status
    except Exception as exc:
        xbmc.log(f'COSMOS [OpenSubtitles] DELETE {path} failed: {exc}', xbmc.LOGWARNING)
        return None


# ── Authentication ────────────────────────────────────────────────────────────


def _do_login(username, password):
    """Internal: attempt login with the given credentials and show result toast.

    Saves credentials and token on success.  Returns True on success.
    """
    username = username.strip()
    password = password.strip()

    if not username or not password:
        xbmcgui.Dialog().notification(
            'OpenSubtitles', 'Enter both username and password.',
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        return False

    # Persist credentials so they survive token expiry
    try:
        _addon().setSetting('opensubtitles_username', username)
        _addon().setSetting('opensubtitles_password', password)
    except Exception as e:
        xbmc.log(f'COSMOS [OpenSubtitles] failed to save credentials: {e}', xbmc.LOGWARNING)

    prog = xbmcgui.DialogProgressBG()
    prog.create('C.O.S.M.O.S', 'OpenSubtitles — logging in...')
    result = _http_post('/login', {'username': username, 'password': password}, with_auth=False)
    prog.close()

    if result and result.get('token'):
        _addon().setSetting('opensubtitles_token', result['token'])
        xbmc.log('COSMOS [OpenSubtitles] login OK', xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            'OpenSubtitles', f'✓ Logged in as {username}',
            xbmcgui.NOTIFICATION_INFO, 4000,
        )
        return True

    error_message = 'Login failed — check username / password'
    if result and isinstance(result, dict) and 'message' in result:
        error_message = f"Login failed: {result['message']}"

    xbmc.log('COSMOS [OpenSubtitles] login failed', xbmc.LOGERROR)
    xbmcgui.Dialog().notification(
        'OpenSubtitles', error_message, xbmcgui.NOTIFICATION_ERROR, 5000,
    )
    return False


def login():
    """Authenticate with OpenSubtitles via a credentials dialog.

    Opens a username / password dialog, then calls _do_login().
    Returns True on success.
    """
    from . import auth_dialog as _auth
    dlg = _auth.CredentialsDialog(
        'AuthDialogCredentials.xml', ADDON_PATH, 'Default', '720p',
        service_name='OpenSubtitles',
        icon_path=f'{ADDON_PATH}resources/media/icon_opensubtitles.png',
    )
    dlg.doModal()
    if not dlg.confirmed:
        return False
    username = dlg.username.strip()
    password = dlg.password.strip()
    del dlg
    return _do_login(username, password)


def login_from_settings():
    """Authenticate using credentials already saved in addon settings.

    Called automatically via onchange when the user fills in the
    password field in Settings → Subtitles.  No dialog is shown.
    Returns True on success.
    """
    username = _addon().getSetting('opensubtitles_username')
    password = _addon().getSetting('opensubtitles_password')
    return _do_login(username, password)



def logout():
    """Delete the stored JWT and log out from OpenSubtitles."""
    try:
        _http_delete('/logout')
    except Exception:
        pass
    _addon().setSetting('opensubtitles_token', '')
    xbmc.log('COSMOS [OpenSubtitles] logged out', xbmc.LOGINFO)


# ── Search ────────────────────────────────────────────────────────────────────


def _search_once(imdb_id=None, tmdb_id=None, title=None, content='movie',
                 season=None, episode=None, language=None):
    """Search OpenSubtitles for matching subtitles.

    Returns a list of subtitle data dicts (the 'data' array from the API),
    or [] if nothing found / request failed.
    """
    lang = language or _language()
    params = {'languages': lang}

    if content == 'movie':
        params['type'] = 'movie'
    elif content == 'episode':
        params['type'] = 'episode'
        if season is not None:
            params['season_number'] = str(season)
        if episode is not None:
            params['episode_number'] = str(episode)
    elif content == 'tvshow':
        params['type'] = 'series'
        if season is not None:
            params['season_number'] = str(season)
    else: # Default to movie if content is unknown or not explicitly handled
        params['type'] = 'movie'
    # Prefer IMDB id > TMDB id > title query
    if imdb_id:
        # Strip 'tt' prefix and leading zeros — API expects numeric IMDB id
        clean = str(imdb_id).lstrip('t').lstrip('0') or str(imdb_id)
        params['imdb_id'] = clean
    elif tmdb_id:
        params['tmdb_id'] = str(tmdb_id)
    elif title:
        params['query'] = title

    xbmc.log(
        f'COSMOS [OpenSubtitles] search params={params}', xbmc.LOGDEBUG
    )
    result = _http_get('/subtitles', params)
    if not result:
        return []
    return result.get('data') or []


def search(imdb_id=None, tmdb_id=None, title=None, content='movie',
           season=None, episode=None):
    """Search primary language first, then configured fallback languages."""
    for language in _language_sequence():
        results = _search_once(
            imdb_id=imdb_id,
            tmdb_id=tmdb_id,
            title=title,
            content=content,
            season=season,
            episode=episode,
            language=language,
        )
        if results:
            return _rank_results(results)
    return []


# ── Download ──────────────────────────────────────────────────────────────────


def _get_download_link(file_id):
    """Obtain a timed download URL for *file_id* via POST /download."""
    result = _http_post('/download', {'file_id': int(file_id)})
    if not result:
        return None
    link = result.get('link')
    if not link:
        xbmc.log(
            'COSMOS [OpenSubtitles] /download returned no link', xbmc.LOGERROR
        )
    return link


def _download_subtitle(link, filename='subtitle.srt'):
    """Fetch *link* and save it to the user-defined path or temp folder."""
    custom_path = _addon().getSetting('opensubtitles_download_path')

    if custom_path and xbmcvfs.exists(custom_path):
        dest_dir = custom_path
    else:
        dest_dir = xbmcvfs.translatePath('special://temp/cosmos_subtitles/')

    if not xbmcvfs.exists(dest_dir):
        xbmcvfs.mkdirs(dest_dir)

    safe = ''.join(c if (c.isalnum() or c in '._- ()[]') else '_' for c in filename)
    if not safe.endswith('.srt'):
        safe = safe + '.srt'
    dest = os.path.join(dest_dir, safe)

    try:
        req = urllib.request.Request(link, headers={'User-Agent': APP_USER_AGENT})
        with urllib.request.urlopen(req, timeout=20) as resp:
            content = resp.read()
            f = xbmcvfs.File(dest, 'w')
            f.write(content)
            f.close()
        xbmc.log(f'COSMOS [OpenSubtitles] subtitle saved to {dest}', xbmc.LOGINFO)
        return dest
    except Exception as exc:
        xbmc.log(f'COSMOS [OpenSubtitles] download to temp failed: {exc}', xbmc.LOGERROR)
        return None


# ── Main entry point ──────────────────────────────────────────────────────────


def download_and_apply(file_id, filename='subtitle.srt', notify=True):
    """Download a subtitle by file_id and apply it if playing.

    ``notify=False`` is used by the automatic playback path so subtitle
    loading does not interrupt playback with a modal dialog or toast.
    """
    if not file_id:
        return None

    link = _get_download_link(file_id)
    if not link:
        xbmc.log('COSMOS [OpenSubtitles] Could not get download link.', xbmc.LOGERROR)
        return None

    local_path = _download_subtitle(link, filename)
    if not local_path:
        xbmc.log('COSMOS [OpenSubtitles] Download failed.', xbmc.LOGERROR)
        return None

    player = xbmc.Player()
    if player.isPlaying():
        try:
            player.setSubtitles(local_path)
            player.showSubtitles(True)
            if notify:
                xbmcgui.Dialog().notification(
                    'Subtitles', 'Subtitle loaded!', xbmcgui.NOTIFICATION_INFO, 3000
                )
        except Exception as exc:
            xbmc.log(
                f'COSMOS [OpenSubtitles] setSubtitles failed: {exc}', xbmc.LOGERROR
            )
            if notify:
                xbmcgui.Dialog().notification(
                    'Subtitle Downloaded',
                    'Auto-load failed. Subtitle saved.',
                    xbmcgui.NOTIFICATION_WARNING, 4000
                )
    elif notify:
        xbmcgui.Dialog().ok(
            'Subtitle Saved', f'Subtitle saved to:\n\n{local_path}'
        )

    return local_path


def auto_apply_for_playback(meta, player=None):
    """Apply the automatic subtitle preference for a newly started item.

    This is intentionally best-effort and runs the network search/download in
    a daemon thread.  Kodi's player callback can fire just before the media is
    ready, so the worker waits briefly for an active player before searching.
    When the preference is off, hide any subtitle Kodi may have carried over
    from a previous item.
    """
    global _LAST_PLAYBACK_META
    data = meta or {}
    if data:
        _LAST_PLAYBACK_META = dict(data)

    addon = _addon()
    enabled = (addon.getSetting('subtitle_autoload_enabled') or '').strip().lower() == 'true'
    opensubtitles_enabled = (addon.getSetting('opensubtitles_enabled') or 'true').strip().lower() == 'true'
    active_player = player or xbmc.Player()

    if not enabled or not opensubtitles_enabled:
        try:
            active_player.showSubtitles(False)
        except Exception as exc:
            xbmc.log(f'COSMOS [OpenSubtitles] could not disable subtitles: {exc}', xbmc.LOGDEBUG)
        return

    content = str(data.get('content') or 'movie').strip().lower()
    if content not in ('movie', 'episode'):
        return

    title = str(data.get('title') or '').strip()
    imdb_id = str(data.get('imdb') or '').strip()
    tmdb_id = str(data.get('tmdb') or '').strip()
    if not title and not imdb_id and not tmdb_id:
        return

    # A direct/non-debrid link can use a different Kodi playback route from
    # debrid playback.  Both that route and the resume tracker may report the
    # same playback start, so only allow one automatic search for this item at
    # a time.  The key is released when the worker finishes, allowing a later
    # replay of the same title to search again.
    auto_key = '|'.join((
        content, tmdb_id, imdb_id,
        str(data.get('season') or ''), str(data.get('episode') or ''),
    ))
    with _AUTO_LOAD_LOCK:
        if auto_key in _AUTO_LOAD_ACTIVE:
            return
        _AUTO_LOAD_ACTIVE.add(auto_key)

    def _worker():
        try:
            for _ in range(30):
                if active_player.isPlaying():
                    break
                xbmc.sleep(500)
            if not active_player.isPlaying():
                return

            results = search(
                # Cosmos carries the series IMDb id on episode rows. Prefer
                # the TMDB id for episode searches so OpenSubtitles receives
                # the show identity together with season/episode numbers.
                imdb_id=(imdb_id or None) if content != 'episode' else None,
                tmdb_id=tmdb_id or None,
                title=title or None,
                content=content,
                season=data.get('season'),
                episode=data.get('episode'),
            )
            xbmc.log(
                f'COSMOS [OpenSubtitles] automatic search returned {len(results)} '
                f'results for {title!r} S{data.get("season", "")}E{data.get("episode", "")}',
                xbmc.LOGDEBUG,
            )
            selected_id = None
            selected_name = 'subtitle.srt'
            for item in results[:50]:
                attrs = item.get('attributes') or {}
                files = attrs.get('files') or []
                if not files:
                    continue
                selected_id = files[0].get('file_id')
                selected_name = files[0].get('file_name') or selected_name
                if selected_id:
                    break
            if not selected_id or not active_player.isPlaying():
                xbmc.log(
                    f'COSMOS [OpenSubtitles] no downloadable automatic subtitle '
                    f'found for {title!r}',
                    xbmc.LOGDEBUG,
                )
                return

            path = download_and_apply(selected_id, selected_name, notify=False)
            if path:
                xbmc.log(
                    f'COSMOS [OpenSubtitles] automatically applied subtitle for {title!r}',
                    xbmc.LOGINFO,
                )
        except Exception as exc:
            xbmc.log(f'COSMOS [OpenSubtitles] automatic subtitle load failed: {exc}', xbmc.LOGWARNING)
        finally:
            with _AUTO_LOAD_LOCK:
                _AUTO_LOAD_ACTIVE.discard(auto_key)

    xbmc.log(
        f'COSMOS [OpenSubtitles] queued automatic subtitle lookup for {title!r} '
        f'content={content} tmdb={tmdb_id!r} imdb={imdb_id!r}',
        xbmc.LOGDEBUG,
    )
    threading.Thread(target=_worker, name='cosmos-auto-subtitle', daemon=True).start()


def get_last_playback_meta():
    """Return metadata for the most recently started Cosmos playback item."""
    return dict(_LAST_PLAYBACK_META)


def apply_to_current_playback():
    """Apply the current subtitle preference without waiting for a new item."""
    player = xbmc.Player()
    try:
        if not player.isPlaying():
            return False
    except Exception:
        return False

    meta = get_last_playback_meta()
    if meta:
        auto_apply_for_playback(meta, player=player)
    else:
        enabled = (_addon().getSetting('subtitle_autoload_enabled') or '').strip().lower() == 'true'
        try:
            player.showSubtitles(enabled)
        except Exception as exc:
            xbmc.log(f'COSMOS [OpenSubtitles] current subtitle toggle failed: {exc}', xbmc.LOGDEBUG)
    return True


def pick_and_download(title, imdb_id=None, tmdb_id=None, content='movie',
                      season=None, episode=None):
    """Show subtitle picker dialog, download the chosen subtitle.

    If Kodi is currently playing a video the subtitle is applied immediately.
    Returns the local file path on success, or None.
    """
    if _addon().getSetting('opensubtitles_enabled') != 'true':
        xbmcgui.Dialog().notification(
            'Subtitles', 'OpenSubtitles is disabled in settings.',
            xbmcgui.NOTIFICATION_WARNING, 3000
        )
        return None

    # ── Search ────────────────────────────────────────────────────────────
    prog = xbmcgui.DialogProgress()
    prog.create('C.O.S.M.O.S', 'Searching subtitles...')
    try:
        results = search(
            imdb_id=imdb_id, tmdb_id=tmdb_id, title=title,
            content=content, season=season, episode=episode
        )
    finally:
        prog.close()

    if not results:
        xbmcgui.Dialog().notification(
            'Subtitles', 'No subtitles found.', xbmcgui.NOTIFICATION_INFO, 3000
        )
        return None

    # ── Build selection list ──────────────────────────────────────────────
    choices = []
    file_ids = []
    filenames = []

    for item in results[:50]:
        attrs = item.get('attributes') or {}
        files = attrs.get('files') or []
        if not files:
            continue
        file_id = files[0].get('file_id')
        if not file_id:
            continue
        fname = files[0].get('file_name') or 'subtitle.srt'
        lang = (attrs.get('language') or '').upper()
        release = (attrs.get('release') or fname)[:70]
        dl_count = attrs.get('download_count') or 0
        rating = attrs.get('ratings') or 0.0
        fps = attrs.get('fps') or ''
        fps_str = f'  {fps}fps' if fps else ''
        hearing = '  [HI]' if _subtitle_flag(attrs.get('hearing_impaired')) else ''
        forced = '  [Forced]' if _subtitle_flag(attrs.get('foreign_parts_only')) else ''

        label = f'[{lang}] {release}  ↓{dl_count}{fps_str}{forced}{hearing}'
        choices.append(label)
        file_ids.append(file_id)
        filenames.append(fname)

    if not choices:
        xbmcgui.Dialog().notification(
            'Subtitles', 'No subtitle files available.',
            xbmcgui.NOTIFICATION_INFO, 3000
        )
        return None

    idx = xbmcgui.Dialog().select('Download Subtitle', choices)
    if idx < 0:
        return None

    # ── Download ──────────────────────────────────────────────────────────
    prog2 = xbmcgui.DialogProgress()
    prog2.create('C.O.S.M.O.S', 'Downloading subtitle...')
    try:
        local_path = download_and_apply(file_ids[idx], filenames[idx])
    finally:
        prog2.close()

    if not local_path:
        xbmcgui.Dialog().notification(
            'Subtitles', 'Download failed.',
            xbmcgui.NOTIFICATION_ERROR, 4000
        )

    return local_path
