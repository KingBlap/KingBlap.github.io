# -*- coding: utf-8 -*-
"""
Playlist parser for C.O.S.M.O.S.

This addon and code was created by Zeus768 for Cosmos.
Author: Zeus768

The playlist feed is a pastebin-style pseudo-XML where every entry is
terminated with ``</item>`` and optionally opened with ``<item>``.

Both the main menu and the content listings share the exact same item
structure; the only difference is the ``<content>`` value:
    * ``directory`` -> entry is a sub-menu URL
    * ``movie``/``tvshow``/``episode`` -> entry is a playable item

Example menu entry::

    <item>
      <name>[B]Movies[/B]</name>
      <link>https://pastebin.com/D9MnxHMV</link>
      <thumbnail>https://i.imgur.com/MYX7kMn.png</thumbnail>
      <content>directory</content>
    </item>

Example content entry::

    <name>Mamma Mia! Here We Go Again (2018)</name>
    <linkname>Link 1 Non Debrid</linkname><link>https://1fichier.com/?...</link>
    <linkname>Link 2 4k Debrid</linkname><link>Search4k</link>
    <tmdb>458423</tmdb>
    <content>movie</content>
    </item>
"""
import re
import json
import os
import time
import xbmc
import xbmcaddon
import xbmcvfs
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from urllib.parse import urlsplit, urljoin

USER_AGENT = 'COSMOS/4.0.0 Kodi Addon'
MAX_BODY_BYTES = 8 * 1024 * 1024
_PARSED_CACHE = {}


def _feed_cache_path(url):
    root = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/feed_cache')
    safe = __import__('hashlib').sha256(url.encode('utf-8')).hexdigest()
    return os.path.join(root, safe + '.json')


def clear_cached_feeds():
    """Clear saved menu XML and parsed pages without changing schedules."""
    root = os.path.dirname(_feed_cache_path(''))
    removed = 0
    errors = []
    _PARSED_CACHE.clear()
    try:
        if os.path.isdir(root):
            for name in os.listdir(root):
                if not re.fullmatch(r'[a-f0-9]{64}\.json', name):
                    continue
                try:
                    os.remove(os.path.join(root, name))
                    removed += 1
                except OSError as exc:
                    errors.append(str(exc))
    except OSError as exc:
        errors.append(str(exc))
    return removed, errors


def refresh_cached_feed(url):
    """Refresh a menu and its linked XML submenus without touching Kodi UI."""
    monitor = xbmc.Monitor()
    queue = [(_normalize_url(url), 0)]
    visited = set()
    while queue and len(visited) < 200 and not monitor.abortRequested():
        current, depth = queue.pop(0)
        if current in visited or not _cacheable_feed(current):
            continue
        visited.add(current)
        body = fetch_url(current, timeout=10, allow_cache=False)
        if not body:
            continue
        kind, items = parse_page(body)
        if kind == 'directory' and depth < 6:
            for item in items:
                child = _normalize_url(urljoin(current, str(item.get('url') or '')))
                if _cacheable_feed(child):
                    queue.append((child, depth + 1))


def _cacheable_feed(url):
    """Cache Enigma XML, including a user-configured menu host."""
    try:
        parts = urlsplit(url)
        addon = xbmcaddon.Addon()
        if addon.getSetting('background_feed_refresh') == 'false':
            return False
        custom = _normalize_url(addon.getSetting('base_url') or '')
        host = (parts.hostname or '').lower()
        allowed = {'team-enigma.xyz', 'www.team-enigma.xyz'}
        if custom:
            allowed.add((urlsplit(custom).hostname or '').lower())
        return (parts.scheme in ('http', 'https') and host in allowed
                and (parts.path.lower().endswith(('.xml', '.xmll')) or url == custom))
    except (ValueError, TypeError):
        return False


def _read_feed_cache(url):
    try:
        with open(_feed_cache_path(url), 'r', encoding='utf-8') as handle:
            value = json.load(handle)
        body = value.get('body') if isinstance(value, dict) else None
        if isinstance(body, str) and body and len(body.encode('utf-8')) <= MAX_BODY_BYTES:
            return body
    except (OSError, ValueError, TypeError):
        pass
    return ''


def _save_feed_cache(url, body):
    import uuid
    path = _feed_cache_path(url)
    staging = path + '.' + uuid.uuid4().hex + '.tmp'
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(staging, 'w', encoding='utf-8') as handle:
            json.dump({'body': body, 'fetched_at': time.time()}, handle)
        os.replace(staging, path)
    except OSError as exc:
        xbmc.log(f'COSMOS: menu cache write failed: {exc}', xbmc.LOGWARNING)
    finally:
        try:
            if os.path.exists(staging):
                os.remove(staging)
        except OSError:
            pass


def _normalize_url(url):
    """Rewrite common paste-host URLs to their raw/plain-text variant so the
    parser always receives XML, not a wrapping HTML page.
    """
    if not url:
        return url
    u = url.strip()
    # pastebin.com/XXXX  ->  pastebin.com/raw/XXXX
    m = re.match(r'^(https?://)(?:www\.)?pastebin\.com/(?!raw/)([A-Za-z0-9]+)/?$', u)
    if m:
        return f'{m.group(1)}pastebin.com/raw/{m.group(2)}'
    # hastebin.com/XXXX  ->  hastebin.com/raw/XXXX
    m = re.match(r'^(https?://)(?:www\.)?hastebin\.com/(?!raw/)([A-Za-z0-9]+)/?$', u)
    if m:
        return f'{m.group(1)}hastebin.com/raw/{m.group(2)}'
    # gist.github.com/<user>/<id>  ->  gist.githubusercontent.com/<user>/<id>/raw
    m = re.match(r'^(https?://)gist\.github\.com/([^/]+)/([A-Za-z0-9]+)/?$', u)
    if m:
        return f'{m.group(1)}gist.githubusercontent.com/{m.group(2)}/{m.group(3)}/raw'
    return u


def _safe_log_url(url):
    """Redact common query-string credentials before logging a URL."""
    return re.sub(
        r'(?i)([?&](?:api_key|apikey|token)=)[^&#\s]+',
        r'\1[REDACTED]',
        str(url or ''),
    )


def fetch_url(url, timeout=20, allow_cache=True):
    """Fetch raw text body for a URL. Returns empty string on error."""
    url = _normalize_url(url)
    cacheable = _cacheable_feed(url)
    if allow_cache and cacheable:
        cached = _read_feed_cache(url)
        if cached:
            return cached
    try:
        req = Request(url, headers={'User-Agent': USER_AGENT})
        with urlopen(req, timeout=timeout) as resp:
            # Playlist feeds are small. Cap the read so a bad/misconfigured
            # endpoint cannot consume Kodi's memory while being parsed.
            body = resp.read(MAX_BODY_BYTES + 1)
        if len(body) > MAX_BODY_BYTES:
            xbmc.log(
                f'COSMOS: feed rejected because it exceeds {MAX_BODY_BYTES} bytes: '
                f'{_safe_log_url(url)}',
                xbmc.LOGWARNING,
            )
            return ''
        body = body.decode('utf-8', errors='replace')
        # If the response is clearly HTML (paste-host preview page), try to
        # extract the <pre> body which usually holds the raw text.
        if body.lstrip().lower().startswith('<!doctype') or '<html' in body.lower()[:400]:
            pre = re.search(r'<textarea[^>]*>(.*?)</textarea>', body, re.DOTALL | re.IGNORECASE)
            if pre:
                import html as _html
                body = _html.unescape(pre.group(1))
        if cacheable and body.strip():
            kind, items = parse_page(body)
            # Keep the last good page when a host returns HTML or an error page.
            if kind in ('directory', 'content', 'movie', 'tvshow') and items:
                _save_feed_cache(url, body)
        return body
    except (HTTPError, URLError) as e:
        xbmc.log(f'COSMOS: fetch failed for {_safe_log_url(url)}: {e}', xbmc.LOGERROR)
        return ''
    except Exception as e:
        xbmc.log(f'COSMOS: fetch error for {_safe_log_url(url)}: {e}', xbmc.LOGERROR)
        return ''


_LINKNAME_LINK_RE = re.compile(
    r'<linkname>(?P<lname>.*?)</linkname>\s*<link>(?P<lurl>.*?)</link>',
    re.DOTALL | re.IGNORECASE,
)
_NAME_RE = re.compile(r'<name>(.*?)</name>', re.DOTALL | re.IGNORECASE)
_TMDB_RE = re.compile(r'<tmdb>(.*?)</tmdb>', re.DOTALL | re.IGNORECASE)
_CONTENT_RE = re.compile(r'<content>(.*?)</content>', re.DOTALL | re.IGNORECASE)
_SEASON_RE = re.compile(r'<season>(.*?)</season>', re.DOTALL | re.IGNORECASE)
_EPISODE_RE = re.compile(r'<episode>(.*?)</episode>', re.DOTALL | re.IGNORECASE)
_THUMB_RE = re.compile(r'<(?:image|thumb|poster|thumbnail|fanart)>(.*?)</(?:image|thumb|poster|thumbnail|fanart)>',
                       re.DOTALL | re.IGNORECASE)
# A directory entry uses <link>URL</link> (no linkname prefix) as its child feed URL
_PLAIN_LINK_RE = re.compile(r'(?<!name>)<link>(.*?)</link>', re.DOTALL | re.IGNORECASE)
# Strip BBCode like [B]...[/B], [COLOR ...]...[/COLOR]
_BBCODE_RE = re.compile(r'\[/?[A-Za-z]+(?:=[^\]]+)?\]')


def strip_bbcode(text):
    return _BBCODE_RE.sub('', text or '').strip()


def _split_items(body):
    """Split body into per-item text blocks using </item> as separator."""
    # Normalize line endings
    body = re.sub(r'\r\n?', '\n', body or '')
    # Split on the closing item tag. Anything left at the end (no trailing
    # </item>) is still considered a final item.
    raw_parts = re.split(r'</item\s*>', body, flags=re.IGNORECASE)
    items = []
    for part in raw_parts:
        # Strip a leading <item ...> tag if present
        part = re.sub(r'^.*?<item[^>]*>', '', part, count=1, flags=re.DOTALL | re.IGNORECASE)
        # An item block must contain a <name> to be useful
        if '<name>' in part.lower():
            items.append(part)
    return items


def _split_episode_items(body):
    """Split body into per-episode blocks (episode items carry <episode> but
    not <name>, which is why they can't reuse _split_items)."""
    body = re.sub(r'\r\n?', '\n', body or '')
    raw_parts = re.split(r'</item\s*>', body, flags=re.IGNORECASE)
    items = []
    for part in raw_parts:
        part = re.sub(r'^.*?<item[^>]*>', '', part, count=1,
                      flags=re.DOTALL | re.IGNORECASE)
        if '<episode>' in part.lower():
            items.append(part)
    return items


def _parse_item_block(block):
    """Parse a single item text block into a dict."""
    name_m = _NAME_RE.search(block)
    if not name_m:
        return None
    raw_name = name_m.group(1).strip()

    tmdb_m = _TMDB_RE.search(block)
    cont_m = _CONTENT_RE.search(block)
    season_m = _SEASON_RE.search(block)
    episode_m = _EPISODE_RE.search(block)
    thumb_m = _THUMB_RE.search(block)

    # Link list (labeled links for content items)
    links = []
    # Blank out the name block first so its inner <link> is not mistaken for a link
    working = _NAME_RE.sub('', block, count=1)
    for lm in _LINKNAME_LINK_RE.finditer(working):
        links.append({
            'label': strip_bbcode(lm.group('lname')),
            'url': lm.group('lurl').strip(),
        })

    # For directory items (no <linkname>), the feed URL is in a plain <link>
    plain_url = ''
    if not links:
        # Remove the already-consumed labelled pairs before searching for plain <link>
        stripped = _LINKNAME_LINK_RE.sub('', working)
        plain_m = re.search(r'<link>(.*?)</link>', stripped, re.DOTALL | re.IGNORECASE)
        if plain_m:
            plain_url = plain_m.group(1).strip()

    content = (cont_m.group(1).strip().lower() if cont_m else '')

    return {
        'name': strip_bbcode(raw_name),
        'raw_name': raw_name.strip(),
        'tmdb': (tmdb_m.group(1).strip() if tmdb_m else ''),
        'content': content or ('directory' if plain_url and not links else 'movie'),
        'season': (season_m.group(1).strip() if season_m else ''),
        'episode': (episode_m.group(1).strip() if episode_m else ''),
        'thumb': (thumb_m.group(1).strip() if thumb_m else ''),
        'url': plain_url,      # used for directory entries
        'links': links,        # used for content entries
    }


def parse_page(body):
    """Parse a feed body, returning (kind, items).

    - ``kind`` is ``directory`` if every parsed entry is a directory,
      ``tvshow`` if the feed declares ``<viewtype>tvshow</viewtype>`` or
      contains a ``<seasons>`` wrapper, otherwise ``content``.
    - Directory items expose ``name``, ``url``, ``thumb``.
    - Content items expose ``name``, ``tmdb``, ``content``, ``links`` etc.
    - TV-show items expose ``name``, ``tmdb``, ``thumb`` and ``seasons`` where
      each season has ``seasonNo`` and ``episodes`` (each with ``episode``
      number and ``links``).
    """
    body = body or ''
    cache_key = hash(body)
    cached = _PARSED_CACHE.get(cache_key)
    if cached is not None:
        return cached[0], [dict(item) for item in cached[1]]
    low = body.lower()
    is_tvshow_feed = ('<viewtype>tvshow</viewtype>' in low.replace(' ', '')
                      or '<seasons>' in low)
    if is_tvshow_feed:
        shows = _parse_tvshow_feed(body)
        if shows:
            result = ('tvshow', shows)
            _PARSED_CACHE[cache_key] = result
            return result
        # Some TV category menus declare tvshow viewtype but contain normal
        # directory items linking to the actual show XML. Keep those links.

    items = []
    for block in _split_items(body):
        parsed = _parse_item_block(block)
        if parsed:
            items.append(parsed)

    if not items:
        result = ('directory', [])
        _PARSED_CACHE[cache_key] = result
        return result

    is_directory = all(i.get('content') == 'directory' for i in items)
    result = ('directory' if is_directory else 'content'), items
    _PARSED_CACHE[cache_key] = result
    if len(_PARSED_CACHE) > 32:
        _PARSED_CACHE.pop(next(iter(_PARSED_CACHE)))
    return result


_SHOW_SPLIT_RE = re.compile(r'</items\s*>', re.IGNORECASE)
_SEASON_SPLIT_RE = re.compile(r'</season\s*>', re.IGNORECASE)
_SEASONNO_RE = re.compile(r'<seasonNo>(.*?)</seasonNo>', re.DOTALL | re.IGNORECASE)


def _parse_tvshow_feed(body):
    """Parse a TV-shows feed into a list of show dicts.

    Feed shape::

        <viewtype>tvshow</viewtype>
        <items>
          <tmdb>1399</tmdb>
          <name>Game of Thrones</name>
          <seasons>
            <season>
              <seasonNo>1</seasonNo>
              <item>
                <episode>1</episode>
                <linkname>...</linkname><link>...</link>
                ...
              </item>
              ...
            </season>
            ...
        </items>
    """
    shows = []
    # Split feed into <items>...</items> blocks (one per show)
    parts = _SHOW_SPLIT_RE.split(body or '')
    for part in parts:
        # Keep only text starting from the last <items> in this chunk
        m = re.search(r'<items[^>]*>', part, re.IGNORECASE)
        if not m:
            continue
        chunk = part[m.end():]

        name_m = _NAME_RE.search(chunk)
        tmdb_m = _TMDB_RE.search(chunk)
        thumb_m = _THUMB_RE.search(chunk)
        if not name_m:
            continue

        # Extract the seasons wrapper, fall back to whole chunk if missing
        seasons_m = re.search(r'<seasons>(.*?)</seasons>', chunk,
                              re.DOTALL | re.IGNORECASE)
        seasons_body = seasons_m.group(1) if seasons_m else chunk

        seasons = []
        for sblock in _SEASON_SPLIT_RE.split(seasons_body):
            s_open = re.search(r'<season[^>]*>', sblock, re.IGNORECASE)
            if not s_open:
                continue
            sblock = sblock[s_open.end():]

            sno_m = _SEASONNO_RE.search(sblock)
            season_no = (sno_m.group(1).strip() if sno_m else '')

            episodes = []
            for ep_block in _split_episode_items(sblock):
                ep_m = _EPISODE_RE.search(ep_block)
                if not ep_m:
                    continue
                ep_links = []
                for lm in _LINKNAME_LINK_RE.finditer(ep_block):
                    ep_links.append({
                        'label': strip_bbcode(lm.group('lname')),
                        'url': lm.group('lurl').strip(),
                    })
                episodes.append({
                    'episode': ep_m.group(1).strip(),
                    'links': ep_links,
                })
            if episodes or season_no:
                seasons.append({'seasonNo': season_no, 'episodes': episodes})

        shows.append({
            'name': strip_bbcode(name_m.group(1)),
            'tmdb': (tmdb_m.group(1).strip() if tmdb_m else ''),
            'thumb': (thumb_m.group(1).strip() if thumb_m else ''),
            'seasons': seasons,
            'content': 'tvshow',
        })
    return shows


def extract_year(name):
    """Extract a 4-digit year from a title like 'Mamma Mia! (2018)'."""
    m = re.search(r'\((\d{4})\)', name or '')
    if m:
        try:
            return int(m.group(1))
        except ValueError:
            return 0
    return 0
