"""Pluto's regional public catalogue and ad-supported HLS playback."""
import json
import os
import re
import sys
import unicodedata
import uuid
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit, urljoin, parse_qsl
from urllib.request import Request, urlopen

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    from . import tmdb as tmdb_mod
except ImportError:
    # The bundled unit tests load this module directly, outside Kodi's
    # package importer.  TMDB remains optional in that environment.
    tmdb_mod = None

BOOT_URL = 'https://boot.pluto.tv/v4/start'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Referer': 'https://pluto.tv/'}
CACHE_DIR = xbmcvfs.translatePath(
    'special://profile/addon_data/plugin.video.cosmos/pluto_cache/')
PAGE_SIZE = 40
API_PAGE_SIZE = 100


def _https(url):
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or not parsed.hostname:
        raise ValueError('Pluto returned an invalid service URL.')
    return url


def _json(url, token=None):
    headers = dict(HEADERS)
    if token:
        headers['Authorization'] = 'Bearer ' + token
    with urlopen(Request(_https(url), headers=headers), timeout=25) as response:
        return json.load(response)


class Client:
    def __init__(self):
        # Keep tokens and signed playback URLs in memory only. Each invocation
        # gets current regional availability and a fresh anonymous session.
        self.boot = _json(BOOT_URL + '?' + urlencode({
            'appName': 'web', 'appVersion': '9.0.0', 'deviceVersion': '1',
            'deviceModel': 'web', 'deviceMake': 'Chrome', 'deviceType': 'web',
            'clientID': str(uuid.uuid4()), 'clientModelNumber': '1',
            'serverSideAds': 'true',
        }))
        self.token = self.boot['sessionToken']
        self.region = self.boot.get('session', {}).get('activeRegion') or 'unknown'

    def get(self, service, path):
        """Fetch current Pluto data on every request without a local cache."""
        url = self.boot['servers'][service].rstrip('/') + path
        return _json(url, self.token)

    def channels(self, refresh=False):
        data = self.get('channels', '/v2/guide/channels')
        channels = data['data']
        if len(channels) < int(data.get('meta', {}).get('totalCount', len(channels))):
            raise ValueError('Pluto returned an incomplete channel guide. Please try again.')
        return [c for c in channels if c.get('stitched', {}).get('path')
                and not c.get('plutoOfficeOnly')]

    def live_guide(self, refresh=False):
        channels = self.channels(refresh=refresh)
        start = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
        programmes = {}
        try:
            # Keep URL sizes bounded and merge only by exact channel ID.
            for offset in range(0, len(channels), 100):
                ids = [c.get('_id') or c.get('id') for c in channels[offset:offset + 100]]
                path = '/v2/guide/timelines?' + urlencode({
                    'start': start.strftime('%Y-%m-%dT%H:%M:%S.000Z'),
                    'duration': 240, 'channelIds': ','.join(ids)})
                data = self.get('channels', path)
                for row in data.get('data', []):
                    programmes[row['channelId']] = row.get('timelines') or []
        except (HTTPError, URLError, OSError, ValueError, KeyError, TypeError) as exc:
            xbmc.log('COSMOS: Pluto EPG unavailable: %s' % type(exc).__name__, xbmc.LOGWARNING)
        return [dict(c, timelines=programmes.get(c.get('_id') or c.get('id'), []))
                for c in channels]

    def categories(self):
        categories = []
        page = 1
        while True:
            # The folder menu only needs category metadata. Asking Pluto to
            # include every item makes this response several megabytes larger
            # per page and blocks Kodi while the menu is being built. Items
            # are fetched only after the user opens a category.
            data = self.get('vod', '/v4/vod/categories?includeItems=false&offset=100&page=%d' % page)
            categories.extend(c for c in data['categories'] if not c.get('plutoOfficeOnly'))
            if page >= int(data.get('totalPages', 1)):
                return categories
            page += 1

    def search(self, query):
        """Search Pluto's regional catalogue for on-demand titles."""
        query = str(query or '').strip()
        if not query:
            return []
        data = self.get(
            'search',
            '/v1/search?' + urlencode({'q': query, 'limit': 100}),
        )
        if not isinstance(data, dict) or not isinstance(data.get('data'), list):
            raise ValueError('Pluto returned an unexpected search response.')
        # The search service also returns live-channel and EPG matches. Keep
        # this menu focused on playable on-demand movies and series; Live TV
        # remains discoverable through the dedicated channel guide.
        return _unique(item for item in data['data']
                       if item.get('type') in ('movie', 'series'))

    def category(self, content_id):
        items = []
        page = 1
        while True:
            data = self.get('vod', '/v4/vod/categories/%s/items?offset=%d&page=%d' %
                            (_id(content_id), API_PAGE_SIZE, page))
            batch = data['items']
            items.extend(batch)
            if len(items) >= int(data.get('totalItemsCount', len(items))):
                return _unique(items)
            if not batch:
                raise ValueError('Pluto returned an incomplete category. Please refresh the catalogue.')
            page += 1

    def series(self, content_id):
        result = None
        page = 1
        while True:
            data = self.get('vod', '/v4/vod/series/%s/seasons?offset=%d&page=%d' %
                            (_id(content_id), API_PAGE_SIZE, page))
            if result is None:
                result = dict(data, seasons=[])
            seasons = data.get('seasons', [])
            result['seasons'].extend(seasons)
            if len(seasons) < API_PAGE_SIZE:
                return result
            page += 1

    def stream(self, content_id, kind, playback_path=''):
        if kind not in ('channel', 'episode'):
            raise ValueError('Invalid Pluto playback type.')
        base = self.boot['servers']['stitcher'].rstrip('/')
        params = self.boot['stitcherParams']
        if not isinstance(params, str) or not params:
            raise ValueError('Pluto did not provide a playback session.')
        # The VOD catalogue supplies the playback path for each item.  Use it
        # when available instead of reconstructing a path from the catalogue
        # item's _id.  Pluto has returned records where the display metadata
        # ID and the stitched playback asset do not point at the same clip;
        # rebuilding the URL in that case makes episode 1 play episode 2.
        # The path is relative and deliberately restricted to Pluto's known
        # stitch format so catalogue data cannot turn into an arbitrary URL.
        if playback_path:
            match = re.fullmatch(
                r'/stitch/hls/(channel|episode)/([a-fA-F0-9]{24})/master\.m3u8',
                str(playback_path).strip(),
            )
            if not match or match.group(1) != kind:
                raise ValueError('Pluto returned an invalid playback path.')
            path = '/v2' + str(playback_path).strip()
            query = dict(parse_qsl(params.lstrip('?&'), keep_blank_values=True))
            query.update(jwt=self.token, masterJWTPassthrough='true')
            return _https('%s%s?%s' % (base, path, urlencode(query)))
        # Legacy /stitch URLs can return a valid HLS takedown slate instead
        # of programme content. The v2 endpoint needs the bootstrap JWT.
        query = dict(parse_qsl(params.lstrip('?&'), keep_blank_values=True))
        query.update(jwt=self.token, masterJWTPassthrough='true')
        return _https('%s/v2/stitch/hls/%s/%s/master.m3u8?%s' %
                      (base, kind, _id(content_id), urlencode(query)))


def _id(value):
    if not re.fullmatch(r'[a-fA-F0-9]{24}', str(value)):
        raise ValueError('Invalid Pluto content ID. Reopen the Pluto TV menu.')
    return str(value)


def _unique(items):
    return list({str(i.get('_id') or i.get('id')): i for i in items
                 if i.get('_id') or i.get('id')}.values())


def _number(item, *keys):
    """Return a stable integer number from a Pluto catalogue object."""
    for key in keys:
        value = item.get(key) if isinstance(item, dict) else None
        if value is None or value == '':
            continue
        try:
            return int(value)
        except (TypeError, ValueError):
            continue
    return None


def _season_number(season):
    return _number(season, 'number', 'season', 'seasonNumber')


def _episode_number(episode):
    return _number(episode, 'number', 'episode', 'episodeNumber')


def _title_key(value):
    """Normalize episode titles for provider/TMDB matching."""
    text = unicodedata.normalize('NFKD', str(value or ''))
    text = ''.join(char for char in text if not unicodedata.combining(char))
    return re.sub(r'[^a-z0-9]+', '', text.casefold())


def _season_episodes(season):
    """Get and order the episodes belonging to one season."""
    episodes = season.get('episodes') or season.get('items') or []
    if not isinstance(episodes, list):
        return []
    return sorted(
        episodes,
        key=lambda episode: (
            _episode_number(episode) is None,
            _episode_number(episode) if _episode_number(episode) is not None else 0,
            str(episode.get('_id') or episode.get('id') or ''),
        ),
    )


def _match_episode_rows(items, metadata):
    """Order Pluto assets by canonical metadata without losing their IDs.

    Some regional Pluto catalogues expose a production/import order in the
    episode number field.  For Deadly Disasters (GB), Pluto labels the asset
    titled Tsunamis as episode 4 even though it is the canonical episode 1.
    Matching by title lets TMDB provide the canonical order while the actual
    Pluto item, including its stitched playback path, remains attached.
    """
    remaining = list(items or [])
    rows = []
    metadata = sorted(
        metadata or [],
        key=lambda episode: (
            _episode_number(episode) is None,
            _episode_number(episode) if _episode_number(episode) is not None else 0,
        ),
    )
    for episode_meta in metadata:
        wanted = _title_key(episode_meta.get('name') or episode_meta.get('title'))
        if not wanted:
            continue
        match_index = next(
            (index for index, item in enumerate(remaining)
             if _title_key(item.get('name') or item.get('title')) == wanted),
            None,
        )
        if match_index is None:
            continue
        rows.append((remaining.pop(match_index), episode_meta))
    # Keep any catalogue-only episodes playable rather than dropping them if
    # TMDB is incomplete or temporarily unavailable.
    rows.extend((item, {}) for item in remaining)
    return rows


def _year_from_date(value):
    """Return a real year, ignoring Pluto's unknown-date epoch placeholder."""
    text = str(value or '').strip()
    if not text or text in ('0', '0.0'):
        return ''
    if re.match(r'^1970-01-01(?:$|T| )', text):
        return ''
    match = re.match(r'^(\d{4})', text)
    return match.group(1) if match else ''


def _tmdb_show(item):
    """Best-effort current TMDB metadata for a Pluto series."""
    if tmdb_mod is None:
        return {}
    title = (item.get('name') if isinstance(item, dict) else item) or ''
    title = str(title).strip()
    if not title:
        return {}
    year = ''
    if isinstance(item, dict):
        released = (item.get('clip') or {}).get('originalReleaseDate', '')
        year = _year_from_date(released)

    def fetch():
        artwork = tmdb_mod.search_art_by_title(title, 'tv', year=year) or {}
        tmdb_id = artwork.get('tmdb_id')
        if not tmdb_id:
            return artwork
        metadata = tmdb_mod.get_metadata(str(tmdb_id), 'tv') or {}
        # Keep lightweight search artwork if the detailed response is
        # unavailable or lacks one of the image paths.
        for field, value in artwork.items():
            if not metadata.get(field):
                metadata[field] = value
        return metadata

    try:
        return fetch() or {}
    except Exception as exc:
        xbmc.log('[Cosmos Pluto] TMDB show lookup failed: %s' % exc, xbmc.LOGDEBUG)
        return {}


def _tmdb_seasons(tmdb_id):
    if tmdb_mod is None or not tmdb_id:
        return []
    try:
        return tmdb_mod.get_tv_seasons(str(tmdb_id)) or []
    except Exception as exc:
        xbmc.log('[Cosmos Pluto] TMDB season lookup failed: %s' % exc, xbmc.LOGDEBUG)
        return []


def _tmdb_episodes(tmdb_id, season_number):
    if tmdb_mod is None or not tmdb_id or season_number is None:
        return []
    try:
        return tmdb_mod.get_tv_episodes(str(tmdb_id), int(season_number)) or []
    except Exception as exc:
        xbmc.log('[Cosmos Pluto] TMDB episode lookup failed: %s' % exc, xbmc.LOGDEBUG)
        return []


def _apply_meta(info, metadata):
    """Overlay non-empty TMDB values without removing Pluto fallbacks."""
    if not metadata:
        return
    for key in ('title', 'plot', 'genre', 'mpaa', 'year', 'rating', 'duration'):
        value = metadata.get(key)
        if value not in (None, '', 0):
            info[key] = value


def _category_matches_mode(name, mode):
    """Keep mixed/ambiguous folders out of the dedicated type menus."""
    if not mode:
        return True
    name = str(name or '').casefold()
    movie_match = re.search(r'\bmovies?\b|\bfilms?\b|\bcinema\b', name)
    series_match = re.search(
        r'\btv\b|\btelevision\b|\bseries?\b|\bshows?\b|\bepisodes?\b|'
        r'\bseasons?\b|\bsoaps?\b|\banime\b|\bcartoons?\b',
        name,
    )
    if mode == 'movie':
        return bool(movie_match) and not bool(series_match and not movie_match)
    if mode == 'series':
        return bool(series_match) and not bool(movie_match)
    return False


def _image(item, fallback, wide=False):
    if wide:
        url = (item.get('featuredImage') or {}).get('path')
        if url:
            return url
    for image in item.get('images', []):
        if image.get('type') == ('featuredImage' if wide else 'colorLogoPNG'):
            return image['url']
    covers = item.get('covers') or []
    for cover in covers:
        if cover.get('aspectRatio') == ('16:9' if wide else '347:500'):
            return cover['url']
    return covers[0]['url'] if covers else fallback


def _info(item):
    kind = item.get('type', '')
    info = {'title': item.get('name') or 'Pluto TV',
            'plot': item.get('description') or item.get('summary') or '',
            'genre': item.get('genre') or '', 'mpaa': item.get('rating') or '',
            'mediatype': {'series': 'tvshow', 'movie': 'movie', 'episode': 'episode'}.get(kind, 'video')}
    duration = item.get('originalContentDuration') or item.get('duration')
    if duration:
        info['duration'] = int(duration) // 1000
    if kind == 'episode':
        info.update(
            season=_season_number(item) or 0,
            episode=_episode_number(item) or 0,
        )
    released = (item.get('clip') or {}).get('originalReleaseDate', '')
    year = _year_from_date(released)
    if year:
        info['year'] = int(year)
    return info


def _offset(params):
    try:
        return max(0, int(params.get('offset', 0)))
    except (TypeError, ValueError):
        return 0


def _pages(items, params, add, url, icon, fanart, render):
    offset = _offset(params)
    for item in items[offset:offset + PAGE_SIZE]:
        render(item)
    if offset:
        add('Previous Page', url(**dict(params, offset=max(0, offset - PAGE_SIZE))),
            thumb=icon, fanart=fanart)
    if offset + PAGE_SIZE < len(items):
        add('Next Page', url(**dict(params, offset=offset + PAGE_SIZE)), thumb=icon, fanart=fanart)
    if not items:
        xbmcgui.Dialog().notification('Pluto TV', 'No content available in this category in your region.')


def _add_title(item, add, url, icon, fanart, live=False, series_title='',
               tmdb=None, episode_meta=None):
    series = item.get('type') == 'series'
    content_id = item.get('_id') or item.get('id')
    title = item.get('name') or 'Untitled'
    if live and item.get('number') is not None:
        title = '%s  |  %s' % (item['number'], title)
    if item.get('type') == 'episode':
        number = _episode_number(item)
    tmdb = tmdb or {}
    episode_meta = episode_meta or {}
    if item.get('type') == 'episode':
        title = episode_meta.get('name') or title
        number = _episode_number(episode_meta)
        if number is None:
            number = _episode_number(item)
        title = '%s. %s' % (number if number is not None else '', title)
    extra = {} if series else {
        'kind': 'channel' if live else 'episode',
        'title': item.get('name', ''),
        'thumb': episode_meta.get('still') or
        tmdb.get('poster') or _image(item, icon),
        # Keep Pluto's item-to-asset mapping attached to the playable URL.
        # This is more reliable than deriving the stitch asset from _id for
        # older/regional catalogues.
        'playback_path': (item.get('stitched') or {}).get('path', ''),
    }
    info = _info(item)
    if item.get('type') == 'episode':
        canonical_number = _episode_number(episode_meta)
        if canonical_number is not None:
            info['episode'] = canonical_number
    _apply_meta(info, tmdb)
    if episode_meta:
        _apply_meta(info, {
            'title': episode_meta.get('name'),
            'plot': episode_meta.get('overview'),
            'year': _year_from_date(episode_meta.get('air_date', '')),
            'rating': episode_meta.get('rating'),
            'duration': episode_meta.get('runtime'),
        })
    if series_title and item.get('type') == 'episode':
        info['tvshowtitle'] = series_title
    if item.get('type') == 'episode':
        info['mediatype'] = 'episode'
    poster = (episode_meta.get('still') if episode_meta else None) or \
             tmdb.get('poster') or _image(item, icon)
    background = tmdb.get('fanart') or _image(item, fanart, True)
    add(title, url(action='pluto_series' if series else 'pluto_play',
                   content_id=content_id, **extra),
        thumb=poster, fanart=background,
        info=info, is_folder=series, is_playable=not series)


def _play(client, params, handle):
    stream = client.stream(
        params.get('content_id', ''),
        params.get('kind', ''),
        params.get('playback_path', ''),
    )
    kind = params.get('kind', '')
    # Check the response before resolving so a regional or service error does
    # not get handed to Kodi as if it were a playable video.
    with urlopen(Request(stream, headers=HEADERS), timeout=25) as response:
        master = response.read().decode('utf-8-sig')
        if not master.lstrip().startswith('#EXTM3U'):
            raise ValueError('Pluto did not return a playable stream in your region.')
    if '#EXT-X-STREAM-INF:' in master:
        variant = next((line.strip() for line in master.splitlines()
                        if line.strip() and not line.startswith('#')), None)
        if not variant:
            raise ValueError('Pluto did not provide a playable video playlist.')
        with urlopen(Request(_https(urljoin(stream, variant)), headers=HEADERS), timeout=25) as response:
            media = response.read().decode('utf-8-sig')
        if not media.lstrip().startswith('#EXTM3U'):
            raise ValueError('Pluto did not return a playable video playlist.')
        media_lines = [line.strip() for line in media.splitlines()]
        if not any(line and not line.startswith('#') for line in media_lines):
            raise ValueError('Pluto returned an empty video playlist.')
        if kind == 'episode' and '#EXT-X-ENDLIST' not in media:
            raise ValueError('Pluto returned an incomplete episode playlist. Please try again.')
        if '#EXTINF:' not in media:
            raise ValueError('Pluto did not return any playable video segments.')
        if 'takedownslate' in media.lower():
            raise ValueError('Pluto returned a service notice instead of this programme. Please try again later.')
    live = kind == 'channel'
    headers = urlencode(HEADERS)
    # Kodi's native HLS player reads request headers from URL options.
    item = xbmcgui.ListItem(path=stream + '|' + headers if live else stream)
    info = {'title': params.get('title') or 'Pluto TV', 'mediatype': 'video'}
    info.update(params.get('live_info') or {})
    if live:
        info.update(playcount=0, overlay=0, duration=0)
        item.setProperty('ResumeTime', '0')
        item.setProperty('TotalTime', '0')
    item.setInfo('video', info)
    item.setArt({'thumb': params.get('thumb', ''), 'fanart': params.get('fanart', '')})
    item.setMimeType('application/vnd.apple.mpegurl')
    item.setContentLookup(False)
    if live:
        item.setProperty('inputstream', 'inputstream.ffmpeg')
        item.setProperty('IsPlayable', 'true')
    else:
        if not xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
            raise ValueError('Pluto TV playback requires Kodi InputStream Adaptive. Please install or enable it.')
        item.setProperty('inputstream', 'inputstream.adaptive')
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        item.setProperty('inputstream.adaptive.manifest_headers', headers)
        item.setProperty('inputstream.adaptive.stream_headers', headers)
    xbmcplugin.setResolvedUrl(handle, True, item)


def _refresh():
    # Retain old saved routes; browsing always fetches current data.
    clear_cache()
    xbmc.executebuiltin('Container.Refresh')


def clear_cache():
    """Remove files left by older versions of the provider cache."""
    try:
        if os.path.isdir(CACHE_DIR):
            for name in os.listdir(CACHE_DIR):
                if name.endswith(('.json', '.tmp')):
                    try:
                        os.remove(os.path.join(CACHE_DIR, name))
                    except OSError:
                        pass
    except OSError:
        pass


def run(action, params, add_directory, build_url, icon, fanart):
    clear_cache()
    handle = int(sys.argv[1])
    playing = action in ('pluto_play', 'pluto_live')
    succeeded = False
    params = dict(params, action=action)
    add, url = add_directory, build_url
    try:
        if action == 'pluto_root':
            xbmcplugin.setPluginCategory(handle, 'Pluto TV')
            xbmcplugin.setContent(handle, 'files')
            for label, target, extra in (
                    ('Live TV', 'pluto_live', {}),
                    ('Movies', 'pluto_categories', {'mode': 'movie'}),
                    ('TV Shows', 'pluto_categories', {'mode': 'series'}),
                    ('All On-Demand Categories', 'pluto_categories', {})):
                add('[B]%s[/B]' % label, url(action=target, **extra),
                    thumb=icon, fanart=fanart,
                    is_folder=target not in ('pluto_refresh', 'pluto_live'),
                    is_playable=target == 'pluto_live', live=target == 'pluto_live')
            notice = 'Content could be Geo Locked and require a VPN to access!'
            add('[COLOR gold]%s[/COLOR]' % notice, '', thumb=icon, fanart=fanart,
                info={'title': notice}, is_folder=False)
        elif action == 'pluto_refresh':
            _refresh()
        else:
            if action == 'pluto_search_prompt':
                query = str(xbmcgui.Dialog().input('Search Pluto TV') or '').strip()
                if query:
                    # Replace the prompt container with a query-bearing
                    # results URL. Kodi can otherwise revisit the original
                    # empty-query URL when the user navigates back.
                    target = url(action='pluto_search_results', query=query)
                    xbmc.executebuiltin('Container.Update(%s,true)' % target)
                    # Complete the prompt successfully after scheduling the
                    # replacement; ending it as failed leaves Kodi on an
                    # inert search entry on some builds.
                    succeeded = True
                return
            client = Client()
            if action == 'pluto_live':
                from . import pluto_picker
                selected = pluto_picker.show(client.live_guide(), client.region, icon,
                                             lambda: client.live_guide(refresh=True))
                if selected is None:
                    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                    return
                channel = selected['source']
                info = pluto_picker.channel_link(selected, icon)['info']
                _play(client, {'content_id': selected['id'], 'kind': 'channel',
                               'playback_path': channel['stitched']['path'],
                               'title': info['title'], 'live_info': info,
                               'thumb': _image(channel, icon),
                               'fanart': _image(channel, fanart, True)}, handle)
                return
            if playing:
                _play(client, params, handle)
                return
            xbmcplugin.setPluginCategory(handle, 'Pluto TV (%s)' % client.region)
            xbmcplugin.setContent(handle, 'videos')
            render = lambda item: _add_title(item, add, url, icon, fanart)
            mode = params.get('mode', '')
            if mode not in ('', 'movie', 'series'):
                raise ValueError('Invalid Pluto catalogue type.')
            if action == 'pluto_categories':
                items = [c for c in client.categories()
                         if _category_matches_mode(c.get('name'), mode)]
                def render(item):
                    add(item.get('name') or 'Category',
                        url(action='pluto_category', content_id=item['_id'], mode=mode),
                        thumb=icon, fanart=fanart)
            elif action == 'pluto_search_results':
                query = params.get('query')
                query = str(query or '').strip()
                items = client.search(query) if query else []
                params = dict(params, query=query)
            elif action == 'pluto_category':
                items = [i for i in client.category(params.get('content_id', ''))
                         if not mode or i.get('type') == mode]
                if mode:
                    xbmcplugin.setContent(handle, 'movies' if mode == 'movie' else 'tvshows')
            elif action == 'pluto_series':
                data = client.series(params.get('content_id', ''))
                selected = params.get('season')
                if selected in (None, ''):
                    xbmcplugin.setContent(handle, 'seasons')
                    tmdb = _tmdb_show(data)
                    tmdb_seasons = {
                        _number(item, 'number'): item
                        for item in _tmdb_seasons(tmdb.get('tmdb_id'))
                        if _number(item, 'number') is not None
                    }
                    show_thumb = tmdb.get('poster') or _image(data, icon)
                    show_fanart = tmdb.get('fanart') or _image(data, fanart, True)
                    items = sorted(
                        (season for season in (data.get('seasons') or [])
                         if _season_number(season) is not None),
                        key=lambda season: _season_number(season),
                    )
                    def render(item):
                        season_number = _season_number(item)
                        season_meta = tmdb_seasons.get(season_number) or {}
                        title = 'Season %s' % season_number
                        add(title, url(action='pluto_series', content_id=data['_id'],
                                       season=season_number),
                            thumb=season_meta.get('poster') or show_thumb,
                            fanart=show_fanart,
                            info={
                                'title': season_meta.get('name') or title,
                                'plot': season_meta.get('overview') or '',
                                'tvshowtitle': tmdb.get('title') or data.get('name', ''),
                                'season': season_number,
                                'episodecount': season_meta.get('episode_count') or
                                len(_season_episodes(item)),
                                'mediatype': 'season',
                                'premiered': season_meta.get('air_date') or '',
                            })
                else:
                    xbmcplugin.setContent(handle, 'episodes')
                    try:
                        selected_number = int(selected)
                    except (TypeError, ValueError):
                        selected_number = None
                    season = next(
                        (s for s in (data.get('seasons') or [])
                         if _season_number(s) == selected_number),
                        None,
                    )
                    if season is None:
                        raise ValueError('This Pluto season is no longer available.')
                    items = _season_episodes(season)
                    tmdb = _tmdb_show(data)
                    tmdb_episodes = _tmdb_episodes(
                        tmdb.get('tmdb_id'), selected_number
                    )
                    episode_rows = _match_episode_rows(items, tmdb_episodes)
                    items = [item for item, _ in episode_rows]
                    episode_meta_by_id = {
                        id(item): metadata for item, metadata in episode_rows
                    }
                    render = lambda item: _add_title(
                        item, add, url, icon, fanart,
                        series_title=data.get('name', ''),
                        tmdb=tmdb,
                        episode_meta=episode_meta_by_id.get(id(item), {}),
                    )
            else:
                raise ValueError('Unknown Pluto TV action.')
            _pages(items, params, add, url, icon, fanart, render)
        succeeded = True
    except (HTTPError, URLError, OSError, ValueError, KeyError, TypeError) as exc:
        if isinstance(exc, HTTPError):
            message = ('This content is not available in your region or its availability has changed.'
                       if exc.code in (403, 404, 451) else 'Pluto request failed (HTTP %s).' % exc.code)
        elif isinstance(exc, (URLError, OSError)):
            message = 'Could not connect to Pluto TV. Please try again.'
        elif isinstance(exc, ValueError) and not isinstance(exc, json.JSONDecodeError):
            message = str(exc)
        else:
            message = 'Pluto returned an unexpected response. Please refresh the catalogue.'
        xbmc.log('[Cosmos Pluto] ' + message, xbmc.LOGWARNING)
        xbmcgui.Dialog().ok('Pluto TV', message)
        if playing:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
    finally:
        if not playing:
            xbmcplugin.endOfDirectory(handle, succeeded=succeeded, cacheToDisc=False)
