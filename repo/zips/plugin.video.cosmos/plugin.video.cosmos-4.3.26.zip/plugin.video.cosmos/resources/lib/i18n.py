# -*- coding: utf-8 -*-
"""Small, fallback-safe Kodi localization helper for C.O.S.M.O.S."""

import xbmcaddon


ADDON_ID = 'plugin.video.cosmos'
_ADDON = None


def _addon():
    global _ADDON
    if _ADDON is None:
        _ADDON = xbmcaddon.Addon(ADDON_ID)
    return _ADDON


def enabled():
    """Return whether localized UI labels are enabled by the user."""
    try:
        return (_addon().getSetting('use_localized_ui') or 'true').lower() == 'true'
    except Exception:
        return True


def L(string_id, fallback, *args):
    """Get a Kodi translation, falling back safely to English text.

    ``fallback`` keeps older installations and incomplete translation packs
    usable. Optional ``args`` are applied with ``str.format`` after lookup.
    """
    text = fallback
    if enabled():
        try:
            translated = _addon().getLocalizedString(int(string_id))
            if translated and translated != str(string_id):
                text = translated
        except Exception:
            pass
    if args:
        try:
            text = text.format(*args)
        except Exception:
            pass
    return text
