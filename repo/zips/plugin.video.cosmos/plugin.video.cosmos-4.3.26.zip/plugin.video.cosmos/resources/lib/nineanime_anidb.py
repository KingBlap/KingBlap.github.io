# -*- coding: utf-8 -*-
"""AniDB native-stream bridge used only by the embedded 9Anime section."""

from __future__ import absolute_import, division, print_function, unicode_literals

import html
import json
import re
from http.cookiejar import CookieJar
from html.parser import HTMLParser
from urllib.parse import quote_plus, urljoin, urlparse
from urllib.request import HTTPCookieProcessor, Request, build_opener


ANIDB_BASE = "https://anidb.app"
ANIDB_UA = "Kodi 9anime AniDB bridge/1.0"


class AniDBError(Exception):
    """Raised when AniDB cannot provide a native episode stream."""


class _SuggestionParser(HTMLParser):
    """Read AniDB's small HTML search-suggestion fragment."""

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.items = []
        self._item = None
        self._depth = 0

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "a" and attrs.get("href", "").find("/anime/") >= 0:
            self._item = {"href": html.unescape(attrs["href"]), "text": []}
            self._depth = 1
        elif self._item:
            self._depth += 1

    def handle_endtag(self, tag):
        if not self._item:
            return
        if tag == "a":
            self._item["text"] = " ".join(" ".join(self._item["text"]).split())
            self.items.append(self._item)
            self._item = None
            self._depth = 0
        else:
            self._depth = max(1, self._depth - 1)

    def handle_data(self, data):
        if self._item and data.strip():
            self._item["text"].append(data.strip())


class AniDBResolver:
    def __init__(self, timeout=20):
        self.timeout = timeout
        self.opener = build_opener(HTTPCookieProcessor(CookieJar()))

    def _request(self, url, accept):
        request = Request(url, headers={
            "User-Agent": ANIDB_UA,
            "Accept": accept,
            "Referer": ANIDB_BASE + "/",
        })
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                return response.read().decode("utf-8", "replace")
        except Exception as exc:
            raise AniDBError("AniDB request failed: {0}".format(exc))

    def _json(self, path):
        payload = self._request(
            urljoin(ANIDB_BASE + "/", path.lstrip("/")),
            "application/json,text/plain,*/*",
        )
        try:
            return json.loads(payload)
        except ValueError as exc:
            raise AniDBError("AniDB returned invalid JSON: {0}".format(exc))

    @staticmethod
    def _title_key(value):
        value = re.sub(r"[^a-z0-9]+", " ", (value or "").lower())
        return " ".join(value.split())

    @staticmethod
    def _anime_id(url):
        match = re.search(r"-(\d+)(?:/)?$", urlparse(url).path)
        return int(match.group(1)) if match else None

    def _search(self, title):
        fragment = self._request(
            ANIDB_BASE + "/search/suggestions?q=" + quote_plus(title),
            "text/html,*/*",
        )
        parser = _SuggestionParser()
        parser.feed(fragment)
        wanted = self._title_key(title)
        candidates = []
        for item in parser.items:
            anime_id = self._anime_id(item["href"])
            if not anime_id:
                continue
            key = self._title_key(item["text"])
            display_key = re.sub(r"\s+(?:tv|movie|special|ova|ona)(?:\s+\d{4})?$", "", key)
            display_key = re.sub(r"\s+\d{4}$", "", display_key)
            score = 100 if display_key == wanted else 0
            if not score and (key.startswith(wanted + " ") or wanted.startswith(key + " ")):
                score = 80
            if not score and wanted and all(token in key.split() for token in wanted.split()):
                score = 60
            candidates.append((score, anime_id, item["href"]))
        candidates.sort(reverse=True)
        if not candidates or candidates[0][0] < 60:
            raise AniDBError("AniDB title was not matched safely")
        return candidates[0][1]

    def _episode_id(self, anime_id, number):
        data = self._json("/api/frontend/anime/{0}/episodes".format(anime_id))
        episodes = data.get("episodes", []) if isinstance(data, dict) else []
        number = int(number)
        for episode in episodes:
            try:
                if int(episode.get("number")) == number:
                    return episode.get("id")
            except (TypeError, ValueError):
                continue
        # Some specials are displayed by 9Anime as Episode 1 while AniDB
        # retains the parent-series absolute number (for example 171).
        # Only apply this mapping when AniDB has exactly one episode, so a
        # normal multi-episode series can never select the wrong stream.
        if number == 1 and len(episodes) == 1:
            return episodes[0].get("id")
        raise AniDBError("AniDB episode {0} was not found".format(number))

    @staticmethod
    def _language_entry(languages, language):
        language = (language or "sub").lower()
        wanted = ("dub", "en", "eng", "english") if language == "dub" else ("sub", "jp", "ja", "jpn", "japanese")
        for entry in languages:
            code = str(entry.get("code", "")).lower()
            name = str(entry.get("name", "")).lower()
            if code in wanted or name in wanted:
                return entry
        return None

    def find_embed(self, title, number, language):
        anime_id = self._search(title)
        episode_id = self._episode_id(anime_id, number)
        data = self._json("/api/frontend/episode/{0}/languages".format(episode_id))
        languages = data.get("languages", []) if isinstance(data, dict) else []
        entry = self._language_entry(languages, language)
        if not entry or not entry.get("embed_url"):
            raise AniDBError("AniDB has no {0} stream for this episode".format(language.upper()))
        return urljoin(ANIDB_BASE + "/", entry["embed_url"])

    def resolve_embed(self, embed_url):
        page = self._request(embed_url, "text/html,application/xhtml+xml,*/*")
        patterns = (
            r"(?:file|src)\s*:\s*['\"]([^'\"]+\.(?:m3u8|mp4)(?:\?[^'\"]*)?)['\"]",
            r"['\"](?:file|src)['\"]\s*:\s*['\"]([^'\"]+\.(?:m3u8|mp4)(?:\?[^'\"]*)?)['\"]",
        )
        stream = None
        for pattern in patterns:
            match = re.search(pattern, page, re.I)
            if match:
                stream = html.unescape(match.group(1))
                break
        if not stream:
            raise AniDBError("AniDB embed did not expose a native HLS/MP4 stream")
        stream = urljoin(embed_url, stream)
        media_type = "hls" if ".m3u8" in stream.lower() else "mp4"
        headers = "User-Agent={0}&Referer={1}&Origin={2}".format(ANIDB_UA, embed_url, ANIDB_BASE)
        return {"direct": True, "url": stream + "|" + headers, "media_type": media_type}


def find_source(title, number, language):
    """Return an AniDB source candidate for the 9Anime source picker."""
    embed_url = AniDBResolver().find_embed(title, number, language)
    return {"name": "AniDB", "type": language, "url": embed_url, "source_kind": "ANIDB"}


def resolve(embed_url):
    return AniDBResolver().resolve_embed(embed_url)
