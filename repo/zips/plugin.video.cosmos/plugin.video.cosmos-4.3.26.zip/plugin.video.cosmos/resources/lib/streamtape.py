"""Resolve Streamtape episode embeds discovered from SRStop."""
from . import cosmos_resolvers, srstop, tmdb
from urllib.parse import parse_qsl, urlsplit


def resolve(tmdb_id, season, episode):
    try:
        links = srstop.discover_streamtape(
            tmdb.get_metadata(tmdb_id, 'tv'), season, episode)
        removed = 0
        for link in links:
            cosmos_resolvers._last_resolver_error = ''
            try:
                url = cosmos_resolvers.resolve_streamtape(link['url'])
            except Exception:
                url = None
            if not url and cosmos_resolvers._last_resolver_error == 'removed':
                removed += 1
            if url:
                # Streamtape's resolver provides the media URL with the host
                # referer and user agent Kodi needs to request it.
                resolved, _, header_string = url.partition('|')
                headers = dict(parse_qsl(header_string))
                path = urlsplit(resolved).path.lower()
                kind = 'hls' if '.m3u8' in path else 'mp4'
                stream = {'url': resolved, 'type': kind, 'headers': headers}
                if srstop.probe_stream(stream):
                    return stream
        if removed == len(links):
            return {'error': 'All %d Streamtape files listed for this episode have been removed or are unavailable on Streamtape. Choose another host.' % len(links)}
        return {'error': 'None of the %d Streamtape links passed the playback check. Choose another host or try again later.' % len(links)}
    except srstop.SourceError as exc:
        return {'error': str(exc)}
    except Exception as exc:
        try:
            import xbmc
            xbmc.log('COSMOS Streamtape: resolution failed (%s)' % type(exc).__name__,
                     xbmc.LOGWARNING)
        except Exception:
            pass
        return {'error': 'SRStop / Streamtape could not resolve this episode. Please try again.'}
