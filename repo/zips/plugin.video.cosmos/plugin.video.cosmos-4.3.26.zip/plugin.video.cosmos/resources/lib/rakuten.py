"""Rakuten TV live channels; no on-demand catalogue."""
import json
import uuid
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.request import build_opener, HTTPCookieProcessor
from http.cookiejar import CookieJar

import xbmc
import xbmcgui
import xbmcplugin

API = 'https://gizmo.rakuten.tv/v3'
HEADERS = {'User-Agent': 'Mozilla/5.0', 'Origin': 'https://rakuten.tv',
           'Referer': 'https://rakuten.tv/'}
CLASSIFICATIONS = {'uk': 18, 'ie': 41, 'fr': 23, 'de': 307, 'es': 5,
                   'it': 36, 'at': 300, 'ch': 319, 'be': 308, 'nl': 69,
                   'pt': 64, 'pl': 277, 'se': 282, 'no': 286, 'dk': 283,
                   'fi': 284}


def _market():
    try:
        language = xbmc.getLanguage(xbmc.ISO_639_1, True) or ''
        country = language.rsplit('-', 1)[-1].lower() if '-' in language else 'uk'
    except Exception:
        country = 'uk'
    country = 'uk' if country == 'gb' else country
    return country if country in CLASSIFICATIONS else 'uk'


def _request(path, market, extra=None, body=None, opener=None):
    query = {'classification_id': CLASSIFICATIONS[market],
             'device_identifier': 'web', 'locale': market, 'market_code': market}
    query.update(extra or {})
    headers = dict(HEADERS)
    payload = None
    if body is not None:
        headers['Content-Type'] = 'application/json'
        payload = json.dumps(body).encode('utf-8')
    request = Request(API + path + '?' + urlencode(query), data=payload, headers=headers)
    with (opener.open if opener else urlopen)(request, timeout=25) as response:
        result = json.load(response)
    if result.get('errors'):
        raise ValueError(result['errors'][0].get('message', 'Rakuten request failed'))
    return result


def _channels(market):
    channels = []
    page = 1
    start = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
    end = start + timedelta(hours=4)
    epg = {'epg_duration_minutes': 240,
           'epg_starts_at': start.strftime('%Y-%m-%dT%H:%M:%S.000Z'),
           'epg_ends_at': end.strftime('%Y-%m-%dT%H:%M:%S.000Z'),
           'epg_starts_at_timestamp': int(start.timestamp()),
           'epg_ends_at_timestamp': int(end.timestamp()),
           'device_stream_audio_quality': '2.0',
           'device_stream_hdr_type': 'NONE', 'device_stream_video_quality': 'FHD'}
    while True:
        query = dict(epg, page=page, per_page=40)
        try:
            result = _request('/live_channels', market, query)
        except Exception as exc:
            if not epg:
                raise
            xbmc.log('COSMOS: Rakuten EPG unavailable: %s' % exc, xbmc.LOGWARNING)
            epg = {}
            result = _request('/live_channels', market, {'page': page, 'per_page': 40})
        batch = result.get('data', [])
        channels.extend(batch)
        pages = result.get('meta', {}).get('pagination', {}).get('total_pages', page)
        if not batch or page >= int(pages):
            break
        page += 1
    if not channels:
        raise ValueError('No live channels returned')
    return channels


def _programme_info(channel, now=None):
    now = now or datetime.now(timezone.utc)
    events = []
    for programme in channel.get('live_programs') or []:
        try:
            start = datetime.fromisoformat(programme['starts_at'].replace('Z', '+00:00'))
            end = datetime.fromisoformat(programme['ends_at'].replace('Z', '+00:00'))
            if start.tzinfo is None or end.tzinfo is None or end <= start:
                continue
            events.append((start, end, programme))
        except (KeyError, ValueError, TypeError, AttributeError):
            continue
    events.sort(key=lambda event: event[0])
    current = next((event for event in events if event[0] <= now < event[1]), None)
    upcoming = next((event for event in events if event[0] > now), None)
    name = channel.get('title') or channel.get('id', 'Rakuten TV')
    lines = [name]
    for label, event in (('Now', current), ('Next', upcoming)):
        if event:
            start, end, programme = event
            times = '%s - %s' % (start.astimezone().strftime('%H:%M'),
                                end.astimezone().strftime('%H:%M'))
            lines.append('%s: %s (%s)' % (label, programme.get('title') or name, times))
            for field in ('subtitle', 'description'):
                if programme.get(field):
                    lines.append(programme[field])
    if not current:
        lines.append('Current programme information is unavailable.')
    info = {'title': name, 'plot': '\n\n'.join(lines), 'mediatype': 'video',
            'genre': [tag['name'] for tag in channel.get('labels', {}).get('tags', [])
                      if tag.get('name')]}
    if current:
        info['duration'] = int((current[1] - current[0]).total_seconds())
        info['mpaa'] = (current[2].get('classification') or {}).get('name', '')
    return info


def _stream(params, opener):
    market = params.get('market', _market())
    if market not in CLASSIFICATIONS:
        market = _market()
    body = {'content_id': params['id'], 'content_type': 'live_channels',
            'audio_language': params.get('language', 'ENG'), 'audio_quality': '2.0',
            'classification_id': CLASSIFICATIONS[market],
            'device_serial': str(uuid.uuid4()), 'player': 'web:HLS-NONE:NONE',
            'strict_video_quality': False, 'subtitle_language': 'MIS',
            'video_type': 'stream'}
    result = _request('/avod/streamings', market, {
        'device_stream_audio_quality': '2.0', 'device_stream_hdr_type': 'NONE',
        'device_stream_video_quality': 'FHD'}, body, opener=opener)
    streams = result.get('data', {}).get('stream_infos', [])
    stream = next((s['url'] for s in streams if s.get('url')), None)
    if not stream or not stream.startswith('https://'):
        raise ValueError('No playable live stream returned')
    return stream


def _play(params, handle):
    from .rakuten_proxy import Relay
    opener = build_opener(HTTPCookieProcessor(CookieJar()))
    relay = Relay(lambda: _stream(params, opener), HEADERS, opener)
    item = xbmcgui.ListItem(path=relay.url)
    item.setInfo('video', {'title': params.get('title') or 'Rakuten TV',
                           'plot': params.get('plot') or 'Rakuten TV live channel.',
                           'mediatype': 'video', 'playcount': 0,
                           'overlay': 0, 'duration': 0})
    item.setProperty('ResumeTime', '0')
    item.setProperty('TotalTime', '0')
    item.setArt({'thumb': params.get('thumb', '')})
    item.setMimeType('application/vnd.apple.mpegurl')
    item.setContentLookup(False)
    # Rakuten's stitched adverts change HLS discontinuity periods. ISA can
    # lose the current period after a session refresh and stall indefinitely.
    # Kodi's FFmpeg HLS demuxer handles these clear/AES-128 streams directly;
    # the relay supplies upstream headers, cookies, keys and session recovery.
    item.setProperty('inputstream', 'inputstream.ffmpeg')
    item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle, True, item)
    relay.keep_alive()


def run(action, params, handle, build_url, icon=''):
    try:
        if action == 'rakuten_play':
            _play(params, handle)
            return
        market = _market()
        channels = _channels(market)
        from . import rakuten_picker
        channel = rakuten_picker.show(channels, market, icon, lambda: _channels(market))
        if channel is None:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            return
        languages = channel.get('labels', {}).get('languages', [])
        language = languages[0].get('id', 'ENG') if languages else 'ENG'
        info = _programme_info(channel)
        _play({'id': channel['id'], 'market': market, 'language': language,
               'title': info['title'], 'plot': info['plot'],
               'thumb': channel.get('images', {}).get('artwork') or icon}, handle)
    except Exception as exc:
        xbmc.log('COSMOS: Rakuten TV failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Rakuten TV', 'Unable to load live TV.',
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
        if action in ('rakuten_play', 'rakuten_root'):
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        else:
            xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
