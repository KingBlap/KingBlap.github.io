# -*- coding: utf-8 -*-
"""Small, dependency-free client for the public 9anime.tech HTML pages."""

from __future__ import absolute_import, division, print_function, unicode_literals

import html
import base64
import hmac
import json
import re
import threading
import time
from http.cookiejar import CookieJar
from html.parser import HTMLParser
from urllib.parse import parse_qs, urlencode, unquote, urljoin, urlparse
from urllib.request import HTTPCookieProcessor, Request, build_opener, urlopen

from .nineanime_resolvers import resolve as resolve_9anime_provider, resolver_name
from .nineanime_anidb import resolve as resolve_anidb_embed


_PAGE_CACHE = {}
_PAGE_CACHE_LOCK = threading.Lock()
_PAGE_CACHE_MAX_ENTRIES = 128
_CATALOG_CACHE_TTL = 5 * 60
_TITLE_CACHE_TTL = 10 * 60
_EPISODE_CACHE_TTL = 60


class NineAnimeError(Exception):
    """A user-facing site or parsing error."""


def _title_from_slug(slug):
    """Turn a 9Anime URL slug into a readable fallback display title."""
    value = html.unescape(unquote(slug or "")).strip().strip("/")
    value = re.sub(r"-\d+$", "", value)
    words = [word for word in re.split(r"[-_\s]+", value) if word]
    return " ".join(word[:1].upper() + word[1:] for word in words)


def _catalog_title(title, slug):
    """Keep real site titles, but clean up card text that is just a slug."""
    value = html.unescape(title or "").strip()
    normalized_value = re.sub(r"[-_\s]+", "-", value).strip("-").lower()
    normalized_slug = (slug or "").strip().strip("/").lower()
    if not value or normalized_value == normalized_slug:
        return _title_from_slug(slug) or value
    return value


class _CatalogParser(HTMLParser):
    _void_tags = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.depth = 0
        self.card_depth = None
        self.card = None
        self.cards = []
        self.context = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = set((attrs.get("class") or "").split())
        if tag not in self._void_tags:
            self.depth += 1
        if tag == "div" and "item" in classes and self.card is None:
            self.card_depth = self.depth
            self.card = {"slug": "", "title": "", "poster": "", "type": "", "sub": "", "dub": ""}
        if self.card is None:
            return
        href = attrs.get("href", "")
        if href.startswith(("http://", "https://")):
            href = urlparse(href).path
        if tag == "a" and "/watch/" in href:
            self.card["slug"] = href.split("/watch/", 1)[1].split("/", 1)[0]
            self.context.append((tag, classes, attrs))
        elif tag == "img" and not self.card["poster"]:
            self.card["poster"] = attrs.get("src", "")
        elif tag in ("a", "span", "div"):
            self.context.append((tag, classes, attrs))

    def handle_endtag(self, tag):
        if tag in self._void_tags:
            return
        if self.card is not None and self.depth == self.card_depth:
            if self.card.get("slug") and self.card.get("title"):
                self.cards.append(dict(self.card))
            self.card = None
            self.card_depth = None
            self.context = []
        elif self.context:
            for index in range(len(self.context) - 1, -1, -1):
                if self.context[index][0] == tag:
                    del self.context[index:]
                    break
        self.depth -= 1

    def handle_data(self, data):
        if self.card is None:
            return
        value = " ".join(data.split())
        if not value:
            return
        classes = set()
        for _, current_classes, _ in self.context:
            classes.update(current_classes)
        if "name" in classes and not self.card["title"]:
            self.card["title"] = value
        elif "right" in classes and not self.card["type"]:
            self.card["type"] = value
        elif "ep-status" in classes:
            if "sub" in classes:
                self.card["sub"] += value
            if "dub" in classes:
                self.card["dub"] += value


class NineAnimeClient:
    genres = (
        ("action", "Action"), ("adventure", "Adventure"), ("avant-garde", "Avant Garde"),
        ("boys-love", "Boys Love"), ("comedy", "Comedy"), ("demons", "Demons"),
        ("drama", "Drama"), ("ecchi", "Ecchi"), ("fantasy", "Fantasy"),
        ("girls-love", "Girls Love"), ("gourmet", "Gourmet"), ("harem", "Harem"),
        ("horror", "Horror"), ("isekai", "Isekai"), ("iyashikei", "Iyashikei"),
        ("josei", "Josei"), ("kids", "Kids"), ("magic", "Magic"),
        ("mahou-shoujo", "Mahou Shoujo"), ("martial-arts", "Martial Arts"),
        ("mecha", "Mecha"), ("military", "Military"), ("music", "Music"),
        ("mystery", "Mystery"), ("parody", "Parody"), ("psychological", "Psychological"),
        ("reverse-harem", "Reverse Harem"), ("romance", "Romance"), ("school", "School"),
        ("sci-fi", "Sci-Fi"), ("seinen", "Seinen"), ("shoujo", "Shoujo"),
        ("shounen", "Shounen"), ("slice-of-life", "Slice of Life"), ("space", "Space"),
        ("sports", "Sports"), ("super-power", "Super Power"), ("supernatural", "Supernatural"),
        ("suspense", "Suspense"), ("thriller", "Thriller"), ("vampire", "Vampire"),
    )

    def __init__(self, base_url="https://9anime.tech", timeout=20):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._provider_opener = build_opener(HTTPCookieProcessor(CookieJar()))

    def absolute(self, path):
        return urljoin(self.base_url + "/", path or "/")

    def _get(self, path, cache_ttl=0):
        target = self.absolute(path)
        if cache_ttl > 0:
            now = time.time()
            with _PAGE_CACHE_LOCK:
                cached = _PAGE_CACHE.get(target)
                if cached and cached["expires"] > now:
                    return cached["body"]
                if cached:
                    _PAGE_CACHE.pop(target, None)

        request = Request(target, headers={
            "User-Agent": "Kodi 9anime plugin/1.0",
            "Accept": "text/html,application/xhtml+xml",
            "Referer": self.base_url + "/",
        })
        try:
            with urlopen(request, timeout=self.timeout) as response:
                body = response.read().decode("utf-8", "replace")
        except Exception as exc:
            raise NineAnimeError("Could not load 9anime.tech: {0}".format(exc))
        if cache_ttl > 0:
            with _PAGE_CACHE_LOCK:
                if len(_PAGE_CACHE) >= _PAGE_CACHE_MAX_ENTRIES:
                    oldest = min(_PAGE_CACHE, key=lambda key: _PAGE_CACHE[key]["expires"])
                    _PAGE_CACHE.pop(oldest, None)
                _PAGE_CACHE[target] = {
                    "body": body,
                    "expires": time.time() + cache_ttl,
                }
        return body

    @staticmethod
    def title_for_path(path):
        names = {
            "/home": "Home", "/browse/popular": "Popular", "/browse/new": "Newest",
            "/browse/ongoing": "Ongoing", "/browse/tv": "TV Series", "/browse/movies": "Movies",
            "/browse/ovas": "OVAs", "/browse/onas": "ONAs", "/browse/specials": "Specials",
        }
        return names.get(path, "Browse")

    def catalog(self, path, page=1):
        path = path or "/home"
        parsed = urlparse(path)
        params = parse_qs(parsed.query)
        if page > 1:
            params["page"] = [str(page)]
        query = urlencode([(key, value) for key, values in params.items() for value in values])
        target = parsed.path + (("?" + query) if query else "")
        parser = _CatalogParser()
        parser.feed(self._get(target, cache_ttl=_CATALOG_CACHE_TTL))
        for card in parser.cards:
            card["title"] = _catalog_title(card["title"], card["slug"])
            card["poster"] = urljoin(self.base_url + "/", card["poster"])
        return parser.cards

    def search(self, keyword, page=1):
        query = urlencode({"keyword": keyword, "page": page})
        return self.catalog("/search?" + query, 1)

    def anime(self, slug):
        if not slug:
            raise NineAnimeError("Missing anime slug.")
        source = self._get("/watch/" + slug, cache_ttl=_TITLE_CACHE_TTL)
        details = {"title": _title_from_slug(slug) or slug, "slug": slug, "plot": "", "poster": "", "genres": [], "episodes": []}
        for block in re.findall(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', source, re.I | re.S):
            try:
                data = json.loads(html.unescape(block.strip()))
            except (TypeError, ValueError):
                continue
            if isinstance(data, dict) and data.get("@type") in ("TVSeries", "Movie"):
                details["title"] = data.get("name") or details["title"]
                details["plot"] = data.get("description") or ""
                details["poster"] = data.get("image") or ""
                details["genres"] = data.get("genre") if isinstance(data.get("genre"), list) else []
                details["kind"] = data.get("@type")
                match = re.search(r"(\d{4})", data.get("datePublished", ""))
                details["year"] = int(match.group(1)) if match else 0
        player = re.search(r'<div[^>]+id=["\']player["\'][^>]+style=["\'][^"\']*url\([\'\"]?([^\'\")]+)', source, re.I)
        if player and not details["poster"]:
            details["poster"] = player.group(1)
        seen = set()
        # Do not limit this list to the first two episodes. Use finditer so
        # every episode link is retained, including absolute links returned
        # by some 9anime page variants.
        episode_pattern = re.compile(
            r'<a\b(?P<attrs>[^>]*?\bhref=["\']'
            r'(?P<href>[^"\']*?/watch/[^"\']+/ep-(?P<number>\d+))'
            r'["\'][^>]*)>(?P<body>.*?)</a>',
            re.I | re.S,
        )
        for match in episode_pattern.finditer(source):
            href = match.group("href")
            number = int(match.group("number"))
            attrs = match.group("attrs")
            if number in seen:
                continue
            seen.add(number)
            title_match = re.search(r'\btitle=["\']([^"\']+)', attrs, re.I)
            episode_title = html.unescape(title_match.group(1)).strip() if title_match else ""
            episode_title = re.sub(r"^Episode\s+{0}\s*[-:|]\s*".format(number), "", episode_title, flags=re.I)
            details["episodes"].append({
                "number": number,
                "url": self.absolute(href),
                "title": episode_title,
                "servers": [],
            })
        details["episodes"].sort(key=lambda ep: ep["number"])
        if not details["episodes"]:
            raise NineAnimeError("No episodes were found for this title.")
        try:
            current = self._get(
                "/watch/{0}/ep-{1}".format(slug, details["episodes"][0]["number"]),
                cache_ttl=_EPISODE_CACHE_TTL,
            )
        except NineAnimeError:
            # Optional provider discovery must still run if this episode page
            # is unavailable; the title and episode list are already loaded.
            current = ""
        servers = self._servers(current)
        details["episodes"][0]["servers"] = [
            dict(server, url=urljoin(self.base_url + "/", server["url"])) for server in servers]
        return details

    @staticmethod
    def _servers(source):
        servers = []
        for tag in re.findall(r"<li\b[^>]*>", source or "", re.I):
            attrs = dict(re.findall(r"([:\w-]+)\s*=\s*[\"']([^\"']*)[\"']", tag))
            url = unquote(html.unescape(attrs.get("data-url", ""))).strip()
            if not url:
                continue
            servers.append({
                "url": url,
                "name": html.unescape(attrs.get("data-server", "")),
                "type": normalize_language(attrs.get("data-type", "")),
            })
        return servers

    def episode_servers(self, slug, number):
        """Get the provider choices for one exact episode."""
        servers = self._servers(self._get(
            "/watch/{0}/ep-{1}".format(slug, int(number)),
            cache_ttl=_EPISODE_CACHE_TTL,
        ))
        for server in servers:
            server["url"] = urljoin(self.base_url + "/", server["url"])
        return servers

    def resolve_stream(self, provider_url):
        """Resolve a provider embed into a native media URL when possible."""
        stream_type = media_type(provider_url)
        if stream_type:
            origin = _url_origin(provider_url)
            source = self._playlist_mp4_source(provider_url, origin) if _looks_like_playlist(provider_url) else None
            if source:
                source = _stream_with_headers(source, origin)
                return {"direct": True, "url": source, "media_type": "mp4"}
            return {"direct": True, "url": provider_url, "media_type": stream_type}
        provider = _provider_parts(provider_url)
        if provider:
            try:
                sources = resolve_9anime_provider(self, provider_url, provider[0], provider[1])
                if sources is None:
                    sources = self._provider_sources(provider[0], provider[1])
                if sources:
                    source = self._best_source(sources)
                    if source:
                        playlist_mp4 = self._playlist_mp4_source(source, provider[0]) if _looks_like_playlist(source) else None
                        if playlist_mp4:
                            source = playlist_mp4
                        source = _stream_with_headers(source, provider[0])
                        return {
                            "direct": True,
                            "url": source,
                            "media_type": media_type(source) or (
                                "mp4" if resolver_name(provider_url) == "DGHG" else ""
                            ),
                        }
                return {"direct": False, "url": provider_url, "error": "Provider returned no playable stream"}
            except Exception as exc:
                # Provider changes, interactive CAPTCHA, or encrypted payloads
                # should leave the external-player fallback available.
                return {"direct": False, "url": provider_url, "error": _short_error(exc)}
        return {"direct": False, "url": provider_url, "error": "Unsupported provider embed"}

    @staticmethod
    def resolve_anidb(provider_url):
        """Resolve an AniDB embed selected from the 9Anime source picker."""
        try:
            return resolve_anidb_embed(provider_url)
        except Exception as exc:
            return {"direct": False, "url": provider_url, "error": _short_error(exc)}

    def _playlist_mp4_source(self, playlist_url, provider_origin):
        """Return a direct MP4 entry from a simple M3U playlist, if present.

        Real HLS playlists contain EXT-X tags and must remain HLS so Kodi's
        adaptive inputstream can handle the segment sequence. Some providers
        instead return a plain M3U list whose entries are complete MP4 files;
        those entries can be handed directly to Kodi's native player.
        """
        clean_url = (playlist_url or "").split("|", 1)[0]
        request = Request(clean_url, headers={
            "User-Agent": "Kodi 9anime plugin/1.0",
            "Accept": "application/vnd.apple.mpegurl, application/x-mpegURL, video/mp4, */*",
            "Origin": provider_origin.rstrip("/"),
            "Referer": provider_origin.rstrip("/") + "/",
        })
        try:
            with self._provider_opener.open(request, timeout=self.timeout) as response:
                playlist = response.read(524288).decode("utf-8", "replace")
        except Exception:
            return None
        entries = _extract_playlist_mp4_urls(playlist, clean_url)
        return entries[0] if entries else None

    def _provider_json(self, url, method="GET", payload=None, headers=None):
        request_headers = {
            "User-Agent": "Kodi 9anime plugin/1.0",
            "Accept": "application/json",
            "Origin": self.base_url,
            "Referer": self.base_url + "/",
        }
        request_headers.update(headers or {})
        body = None
        if payload is not None:
            request_headers["Content-Type"] = "application/json"
            body = json.dumps(payload).encode("utf-8")
        request = Request(url, data=body, headers=request_headers, method=method)
        with self._provider_opener.open(request, timeout=self.timeout) as response:
            return json.loads(response.read().decode("utf-8", "replace"))

    def _provider_sources(self, provider_origin, code, endpoint_variants=None,
                          resolver_name="generic", pow_timeout=30.0):
        endpoint_variants = endpoint_variants or ["/api/videos/{0}/embed/".format(code)]
        headers = {
            "X-Embed-Origin": self.base_url,
            "X-Embed-Referer": self.base_url + "/",
            "X-Embed-Parent": self.base_url,
        }
        last_error = None
        for endpoint in endpoint_variants:
            prefix = provider_origin.rstrip("/") + endpoint
            try:
                challenge = self._provider_json(prefix + "captcha", method="POST", payload={}, headers=headers)
                nonce = challenge.get("pow_nonce")
                difficulty = int(challenge.get("pow_difficulty", 0) or 0)
                token = challenge.get("pow_token")
                if not nonce or not token or difficulty <= 0:
                    sources = _extract_provider_sources(challenge)
                    if sources:
                        return sources
                    continue
                solution = _solve_provider_pow(str(nonce), difficulty, pow_timeout)
                if solution is None:
                    raise RuntimeError("{0} proof-of-work timed out after {1:.0f}s".format(
                        resolver_name, pow_timeout
                    ))
                verified = self._provider_json(
                    prefix + "captcha/verify",
                    method="POST",
                    payload={"pow_token": token, "solution": solution},
                    headers=headers,
                )
                captcha_token = verified.get("token")
                if verified.get("status") != "ok" or not captcha_token:
                    continue
                playback = self._provider_json(
                    prefix + "playback",
                    method="POST",
                    payload={"fingerprint": {}},
                    headers=dict(headers, **{"X-Captcha-Token": captcha_token}),
                )
                if isinstance(playback.get("playback"), dict):
                    decoded = _decrypt_provider_payload(playback["playback"])
                    sources = _extract_provider_sources(decoded)
                else:
                    sources = _extract_provider_sources(playback)
                if sources:
                    return sources
            except RuntimeError:
                raise
            except Exception as exc:
                last_error = exc
        if last_error:
            raise RuntimeError("{0} resolver failed: {1}".format(resolver_name, last_error))
        return []

    @staticmethod
    def _best_source(sources):
        candidates = [source for source in sources if source]
        candidates.sort(key=lambda source: _source_quality(source), reverse=True)
        return candidates[0] if candidates else None

    def random_slug(self):
        source = self._get("/random")
        match = re.search(r'<meta[^>]+http-equiv=["\']refresh["\'][^>]+content=["\'][^;]+;\s*url=([^"\']+)', source, re.I)
        if match:
            return urlparse(match.group(1)).path.split("/watch/", 1)[-1]
        match = re.search(r'href=["\'](/watch/([^"\']+))["\']', source, re.I)
        if match:
            return match.group(2).split("/", 1)[0]
        raise NineAnimeError("The site did not return a random title.")


_POW_MASK = 0xFFFFFFFF


def _rotl(value, shift):
    value &= _POW_MASK
    return ((value << shift) | (value >> (32 - shift))) & _POW_MASK


def _imul(left, right):
    return (left * right) & _POW_MASK


def _pow_mix(state):
    state[0] = (state[0] + state[1]) & _POW_MASK
    state[3] = _rotl(state[3] ^ state[0], 16)
    state[2] = (state[2] + state[3]) & _POW_MASK
    state[1] = _rotl(state[1] ^ state[2], 12)
    state[0] = (state[0] + state[1]) & _POW_MASK
    state[3] = _rotl(state[3] ^ state[0], 8)
    state[2] = (state[2] + state[3]) & _POW_MASK
    state[1] = _rotl(state[1] ^ state[2], 7)


def _provider_hash(data):
    # Keep the provider's hash identical, but inline its hot arithmetic path.
    # The old list/function-heavy port was needlessly slow in Kodi's Python
    # runtime and made a normal difficulty-16 challenge take 2-3 minutes.
    state0, state1, state2, state3 = 1779033703, 3144134277, 1013904242, 2773480762
    for value in data:
        state0 = (state0 + value) & _POW_MASK
        state0 = ((state0 << 7) | (state0 >> 25)) & _POW_MASK
        state0 = (state0 + state1) & _POW_MASK
        mixed = state3 ^ state0
        state3 = ((mixed << 16) | (mixed >> 16)) & _POW_MASK
        state2 = (state2 + state3) & _POW_MASK
        mixed = state1 ^ state2
        state1 = ((mixed << 12) | (mixed >> 20)) & _POW_MASK
        state0 = (state0 + state1) & _POW_MASK
        mixed = state3 ^ state0
        state3 = ((mixed << 8) | (mixed >> 24)) & _POW_MASK
        state2 = (state2 + state3) & _POW_MASK
        mixed = state1 ^ state2
        state1 = ((mixed << 7) | (mixed >> 25)) & _POW_MASK
    for _ in range(8):
        state0 = (state0 + state1) & _POW_MASK
        mixed = state3 ^ state0
        state3 = ((mixed << 16) | (mixed >> 16)) & _POW_MASK
        state2 = (state2 + state3) & _POW_MASK
        mixed = state1 ^ state2
        state1 = ((mixed << 12) | (mixed >> 20)) & _POW_MASK
        state0 = (state0 + state1) & _POW_MASK
        mixed = state3 ^ state0
        state3 = ((mixed << 8) | (mixed >> 24)) & _POW_MASK
        state2 = (state2 + state3) & _POW_MASK
        mixed = state1 ^ state2
        state1 = ((mixed << 7) | (mixed >> 25)) & _POW_MASK
    table = [0] * 512
    for index in range(512):
        state0 = (state0 + state1) & _POW_MASK
        mixed = state3 ^ state0
        state3 = ((mixed << 16) | (mixed >> 16)) & _POW_MASK
        state2 = (state2 + state3) & _POW_MASK
        mixed = state1 ^ state2
        state1 = ((mixed << 12) | (mixed >> 20)) & _POW_MASK
        state0 = (state0 + state1) & _POW_MASK
        mixed = state3 ^ state0
        state3 = ((mixed << 8) | (mixed >> 24)) & _POW_MASK
        state2 = (state2 + state3) & _POW_MASK
        mixed = state1 ^ state2
        state1 = ((mixed << 7) | (mixed >> 25)) & _POW_MASK
        table[index] = (state0 ^ state2) & _POW_MASK
    for _ in range(2):
        for index in range(512):
            target = table[index] & 511
            value = (table[index] + table[target]) & _POW_MASK
            value = ((value << 13) | (value >> 19)) & _POW_MASK
            value ^= (table[index + 1 if index + 1 < 512 else 0] * 2654435761) & _POW_MASK
            table[index] = value & _POW_MASK
            state0 = (state0 ^ table[index]) & _POW_MASK
            state0 = (state0 + state1) & _POW_MASK
            mixed = state3 ^ state0
            state3 = ((mixed << 16) | (mixed >> 16)) & _POW_MASK
            state2 = (state2 + state3) & _POW_MASK
            mixed = state1 ^ state2
            state1 = ((mixed << 12) | (mixed >> 20)) & _POW_MASK
            state0 = (state0 + state1) & _POW_MASK
            mixed = state3 ^ state0
            state3 = ((mixed << 8) | (mixed >> 24)) & _POW_MASK
            state2 = (state2 + state3) & _POW_MASK
            mixed = state1 ^ state2
            state1 = ((mixed << 7) | (mixed >> 25)) & _POW_MASK
    digest = []
    for index in range(8):
        state0 = (state0 + state1) & _POW_MASK
        mixed = state3 ^ state0
        state3 = ((mixed << 16) | (mixed >> 16)) & _POW_MASK
        state2 = (state2 + state3) & _POW_MASK
        mixed = state1 ^ state2
        state1 = ((mixed << 12) | (mixed >> 20)) & _POW_MASK
        state0 = (state0 + state1) & _POW_MASK
        mixed = state3 ^ state0
        state3 = ((mixed << 8) | (mixed >> 24)) & _POW_MASK
        state2 = (state2 + state3) & _POW_MASK
        mixed = state1 ^ state2
        state1 = ((mixed << 7) | (mixed >> 25)) & _POW_MASK
        value = state0
        start = index * 64
        for entry in table[start:start + 64]:
            value = (value + entry) & _POW_MASK
            value = ((value << 5) | (value >> 27)) & _POW_MASK
            value ^= (entry * 2246822519) & _POW_MASK
            value &= _POW_MASK
        digest.append((value ^ state2) & _POW_MASK)
    return digest


def _leading_zero_bits(words):
    count = 0
    for word in words:
        if word == 0:
            count += 32
        else:
            count += 32 - word.bit_length()
            break
    return count


def _solve_provider_pow(nonce, difficulty, timeout):
    if difficulty <= 0:
        return "0"
    prefix = nonce + ":"
    deadline = time.time() + timeout
    solution = 0
    while time.time() < deadline:
        for _ in range(256):
            candidate = prefix + str(solution)
            digest = _provider_hash(candidate.encode("latin-1", "replace"))
            if _leading_zero_bits(digest) >= difficulty:
                return str(solution)
            solution += 1
            if time.time() >= deadline:
                return None
    return None


def _extract_provider_sources(payload):
    urls = []
    seen = set()

    def visit(value, depth=0):
        if depth > 6:
            return
        if isinstance(value, str):
            candidate = unquote(value.strip())
            if candidate.startswith(("http://", "https://")) and candidate not in seen:
                seen.add(candidate)
                urls.append(candidate)
            return
        if isinstance(value, list):
            for entry in value:
                visit(entry, depth + 1)
            return
        if not isinstance(value, dict):
            return
        for key in ("url", "file", "src", "stream", "hls", "m3u8", "mp4"):
            if key in value:
                visit(value[key], depth + 1)
        for key, entry in value.items():
            if key not in ("url", "file", "src", "stream", "hls", "m3u8", "mp4"):
                visit(entry, depth + 1)

    visit(payload)
    return urls


def _provider_parts(provider_url):
    """Return (origin, video id) for the provider embed URL variants."""
    clean = unquote((provider_url or "").split("|", 1)[0].strip())
    parsed = urlparse(clean)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        return None
    path = parsed.path.rstrip("/")
    match = re.search(r"/(?:e|embed|v|video|watch)/([A-Za-z0-9_-]+)$", path, re.I)
    if not match:
        query = parse_qs(parsed.query)
        for key in ("id", "vid", "video", "code", "token"):
            value = query.get(key, [""])[0]
            if re.match(r"^[A-Za-z0-9_-]+$", value):
                return parsed.scheme + "://" + parsed.netloc, value
        return None
    return parsed.scheme + "://" + parsed.netloc, match.group(1)


def normalize_language(value):
    """Normalize site/provider language tags to the addon's SUB/DUB labels."""
    value = (value or "").strip().lower()
    if "dub" in value:
        return "dub"
    if "sub" in value:
        return "sub"
    return value


def _source_quality(url):
    stream_type = media_type(url)
    if stream_type == "hls":
        return 3
    if stream_type == "mpd":
        return 2
    if stream_type in ("mp4", "webm", "mkv"):
        return 1
    return 0


def media_type(url):
    """Return Kodi's media type for a direct stream URL, if identifiable."""
    parsed = urlparse((url or "").split("|", 1)[0])
    path = parsed.path.lower()
    query = parsed.query.lower()
    if (path.endswith((".m3u8", ".m3u")) or "m3u8" in query or "m3u" in query or "mpegurl" in query or
            "application/vnd.apple.mpegurl" in query or "application/x-mpegurl" in query or
            "format=hls" in query or "type=hls" in query or "hls" in query or
            "/manifest" in path or "/playlist" in path):
        return "hls"
    if path.endswith(".mpd") or "mpd" in query or "dash" in query or "application/dash+xml" in query:
        return "mpd"
    if path.endswith(".mp4") or "mp4" in query:
        return "mp4"
    if path.endswith(".webm") or "webm" in query:
        return "webm"
    if path.endswith(".mkv") or "mkv" in query:
        return "mkv"
    return ""


def _looks_like_playlist(url):
    parsed = urlparse((url or "").split("|", 1)[0])
    path = parsed.path.lower()
    query = parsed.query.lower()
    return (path.endswith((".m3u8", ".m3u")) or "m3u8" in query or "m3u" in query or
            "/playlist" in path or "/manifest" in path)


def _url_origin(url):
    parsed = urlparse((url or "").split("|", 1)[0])
    return "{0}://{1}".format(parsed.scheme, parsed.netloc) if parsed.scheme and parsed.netloc else ""


def _extract_playlist_mp4_urls(playlist, playlist_url):
    """Extract complete direct-video entries without mistaking HLS segments for MP4 files."""
    if "#EXT-X-" in (playlist or "").upper():
        return []
    entries = []
    for line in (playlist or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        candidate = urljoin(playlist_url, line)
        if media_type(candidate) in ("mp4", "webm", "mkv"):
            entries.append(candidate)
    return entries

def _short_error(error):
    """Return a safe, compact resolver error for Kodi's dialog."""
    message = str(error).replace("\r", " ").replace("\n", " ").strip()
    return message[:180] or error.__class__.__name__


def _stream_with_headers(url, provider_origin):
    """Attach the provider referrer needed by many protected HLS playlists."""
    if "|" in url:
        return url
    headers = "User-Agent=Kodi 9anime plugin/1.0&Referer={0}/&Origin={0}".format(provider_origin.rstrip("/"))
    return url + "|" + headers


def _b64url_decode(value):
    value = value.encode("ascii") if isinstance(value, str) else value
    return base64.urlsafe_b64decode(value + b"=" * ((4 - len(value) % 4) % 4))


def _aes_sbox():
    def multiply(left, right):
        result = 0
        for _ in range(8):
            if right & 1:
                result ^= left
            left = ((left << 1) ^ (0x11B if left & 0x80 else 0)) & 0xFF
            right >>= 1
        return result

    def power(value, exponent):
        result = 1
        while exponent:
            if exponent & 1:
                result = multiply(result, value)
            value = multiply(value, value)
            exponent >>= 1
        return result

    def rotate(value, count):
        return ((value << count) | (value >> (8 - count))) & 0xFF

    values = []
    for value in range(256):
        inverse = 0 if value == 0 else power(value, 254)
        values.append(inverse ^ rotate(inverse, 1) ^ rotate(inverse, 2) ^ rotate(inverse, 3) ^ rotate(inverse, 4) ^ 0x63)
    return values


_AES_SBOX = _aes_sbox()


def _aes_expand_key(key):
    nk = len(key) // 4
    nr = nk + 6
    words = [list(key[index:index + 4]) for index in range(0, len(key), 4)]
    rcon = 1
    for index in range(nk, 4 * (nr + 1)):
        word = list(words[index - 1])
        if index % nk == 0:
            word = [_AES_SBOX[value] for value in word[1:] + word[:1]]
            word[0] ^= rcon
            rcon = ((rcon << 1) ^ (0x11B if rcon & 0x80 else 0)) & 0xFF
        elif nk > 6 and index % nk == 4:
            word = [_AES_SBOX[value] for value in word]
        words.append([left ^ right for left, right in zip(words[index - nk], word)])
    return [sum(words[index:index + 4], []) for index in range(0, len(words), 4)]


def _aes_encrypt_block(key, block):
    def add_round_key(state, round_key):
        return [left ^ right for left, right in zip(state, round_key)]

    def mix_columns(state):
        output = list(state)
        for column in range(4):
            offset = column * 4
            a0, a1, a2, a3 = state[offset:offset + 4]
            output[offset] = _gf8_mul(a0, 2) ^ _gf8_mul(a1, 3) ^ a2 ^ a3
            output[offset + 1] = a0 ^ _gf8_mul(a1, 2) ^ _gf8_mul(a2, 3) ^ a3
            output[offset + 2] = a0 ^ a1 ^ _gf8_mul(a2, 2) ^ _gf8_mul(a3, 3)
            output[offset + 3] = _gf8_mul(a0, 3) ^ a1 ^ a2 ^ _gf8_mul(a3, 2)
        return output

    round_keys = _aes_expand_key(key)
    state = add_round_key(list(block), round_keys[0])
    rounds = len(round_keys) - 1
    for round_index in range(1, rounds):
        state = [_AES_SBOX[value] for value in state]
        state = [state[4 * ((column + row) % 4) + row] for column in range(4) for row in range(4)]
        state = mix_columns(state)
        state = add_round_key(state, round_keys[round_index])
    state = [_AES_SBOX[value] for value in state]
    state = [state[4 * ((column + row) % 4) + row] for column in range(4) for row in range(4)]
    return bytes(add_round_key(state, round_keys[-1]))


def _gf8_mul(left, right):
    result = 0
    for _ in range(8):
        if right & 1:
            result ^= left
        left = ((left << 1) ^ (0x11B if left & 0x80 else 0)) & 0xFF
        right >>= 1
    return result


def _gf128_mul(left, right):
    result = 0
    reduction = 0xE1000000000000000000000000000000
    for _ in range(128):
        if left & (1 << 127):
            result ^= right
        left = (left << 1) & ((1 << 128) - 1)
        right = (right >> 1) ^ (reduction if right & 1 else 0)
    return result


def _ghash(key_hash, data):
    value = 0
    for offset in range(0, len(data), 16):
        block = data[offset:offset + 16].ljust(16, b"\0")
        value = _gf128_mul(value ^ int.from_bytes(block, "big"), key_hash)
    return value.to_bytes(16, "big")


def _aes_gcm_decrypt(key, iv, payload):
    if len(key) not in (16, 24, 32) or len(iv) == 0 or len(payload) < 16:
        raise ValueError("Invalid AES-GCM payload")
    ciphertext, tag = payload[:-16], payload[-16:]
    hash_key = int.from_bytes(_aes_encrypt_block(key, b"\0" * 16), "big")
    counter = bytearray(iv + b"\0\0\0\1") if len(iv) == 12 else bytearray(_ghash(hash_key, iv + b"\0" * ((16 - len(iv) % 16) % 16) + (0).to_bytes(8, "big") + (len(iv) * 8).to_bytes(8, "big")))
    j0 = bytes(counter)
    auth_data = ciphertext + b"\0" * ((16 - len(ciphertext) % 16) % 16) + (0).to_bytes(8, "big") + (len(ciphertext) * 8).to_bytes(8, "big")
    expected_tag = bytes(left ^ right for left, right in zip(_aes_encrypt_block(key, j0), _ghash(hash_key, auth_data)))
    if not hmac.compare_digest(expected_tag, tag):
        raise ValueError("Provider playback authentication failed")
    output = bytearray()
    for offset in range(0, len(ciphertext), 16):
        block_counter = bytearray(j0)
        value = (int.from_bytes(block_counter[-4:], "big") + (offset // 16) + 1) & 0xFFFFFFFF
        block_counter[-4:] = value.to_bytes(4, "big")
        keystream = _aes_encrypt_block(key, bytes(block_counter))
        output.extend(left ^ right for left, right in zip(ciphertext[offset:offset + 16], keystream))
    return bytes(output)


def _decrypt_provider_payload(payload):
    parts = payload.get("key_parts") or []
    version = str(payload.get("version") or "")
    try:
        version_number = int(version)
    except ValueError:
        version_number = 0
    indexes = [version_number, 31 - version_number]
    if not (1 <= version_number <= 20 and all(1 <= index <= len(parts) for index in indexes)):
        selected = parts
    else:
        selected = [parts[index - 1] for index in indexes]
    key = b"".join(_b64url_decode(part) for part in selected)
    plaintext = _aes_gcm_decrypt(key, _b64url_decode(payload["iv"]), _b64url_decode(payload["payload"]))
    return json.loads(plaintext.decode("utf-8"))
