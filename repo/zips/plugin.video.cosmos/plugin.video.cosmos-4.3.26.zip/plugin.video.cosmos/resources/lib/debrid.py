"""
Debrid Service Integration Module

This addon and code was created by Zeus768 for Cosmos.
Author: Zeus768

Supports Real-Debrid, Premiumize, AllDebrid, Torbox, LinkSnappy, Offcloud
Uses native urllib (no external requests module)
FIXED: Offcloud GitHub API specification compliance (URL field extraction, POST cloud status, explore endpoint)
"""
import json
import time
import os
import re
import threading
import tempfile
import concurrent.futures
import xbmcgui
import xbmcaddon
import xbmc
import xbmcvfs

from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from urllib.parse import parse_qs, unquote_plus, urlencode, urlparse

# Get fresh addon instance each time for settings
def get_addon():
    return xbmcaddon.Addon()

ADDON_ID = 'plugin.video.cosmos'
ADDON_DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/')

# Quality priorities (highest to lowest)
QUALITY_ORDER = ['2160p', '1080p', '720p', '480p', '360p']
USER_AGENT = 'COSMOS Kodi Addon'

_VIDEO_EXTENSIONS = ('.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm', '.ts', '.m2ts')


def _torrent_file_name(item):
    if not isinstance(item, dict):
        return ''
    return str(item.get('path') or item.get('name') or item.get('filename') or '').replace('\\', '/')


def _requested_torrent_file_index(magnet):
    """Return the Stremio `so` file index embedded in a magnet, if present."""
    try:
        values = parse_qs(urlparse(str(magnet or '')).query).get('so') or []
        if values:
            return int(str(values[0]).split(',', 1)[0])
    except (TypeError, ValueError):
        pass
    return None


def _requested_episode(magnet):
    """Extract S/E numbers from the magnet display name as a pack fallback."""
    try:
        display_name = unquote_plus((parse_qs(urlparse(str(magnet or '')).query).get('dn') or [''])[0])
    except (TypeError, ValueError):
        display_name = ''
    patterns = (
        r'(?i)\bs0*(\d{1,2})[ ._-]*e0*(\d{1,3})\b',
        r'(?i)\b(\d{1,2})x0*(\d{1,3})\b',
    )
    for pattern in patterns:
        match = re.search(pattern, display_name)
        if match:
            return int(match.group(1)), int(match.group(2))
    return None


def _select_torrent_file(files, magnet):
    """Choose the provider file requested by a scraper or episode filename."""
    candidates = list(files or [])
    if not candidates:
        return None

    requested_index = _requested_torrent_file_index(magnet)
    if requested_index is not None and 0 <= requested_index < len(candidates):
        indexed = candidates[requested_index]
        if _torrent_file_name(indexed).lower().endswith(_VIDEO_EXTENSIONS):
            return indexed

    requested_episode = _requested_episode(magnet)
    if requested_episode:
        season, episode = requested_episode
        episode_patterns = (
            rf'(?i)\bs0*{season}[ ._-]*e0*{episode}\b',
            rf'(?i)\b{season}x0*{episode}\b',
        )
        for item in candidates:
            filename = _torrent_file_name(item)
            if filename.lower().endswith(_VIDEO_EXTENSIONS) and any(
                    re.search(pattern, filename) for pattern in episode_patterns):
                return item

    videos = [item for item in candidates if _torrent_file_name(item).lower().endswith(_VIDEO_EXTENSIONS)]
    return max(
        videos or candidates,
        key=lambda item: int(item.get('bytes') or item.get('size') or item.get('filesize') or 0),
        default=None,
    )

# Token files
RD_TOKEN_FILE = os.path.join(ADDON_DATA_PATH, 'rd_token.json')
AD_TOKEN_FILE = os.path.join(ADDON_DATA_PATH, 'ad_token.json')
PM_TOKEN_FILE = os.path.join(ADDON_DATA_PATH, 'pm_token.json')
TB_TOKEN_FILE = os.path.join(ADDON_DATA_PATH, 'tb_token.json')
LS_TOKEN_FILE = os.path.join(ADDON_DATA_PATH, 'ls_token.json')
OC_TOKEN_FILE = os.path.join(ADDON_DATA_PATH, 'oc_token.json')


def _chmod_private(path):
    """Best-effort restriction for locally persisted credentials."""
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
OC_CLOUD_INDEX_FILE = os.path.join(ADDON_DATA_PATH, 'oc_cloud_items.json')


def _ensure_data_path():
    """Ensure addon data directory exists"""
    if not xbmcvfs.exists(ADDON_DATA_PATH):
        xbmcvfs.mkdirs(ADDON_DATA_PATH)
    if not os.path.exists(ADDON_DATA_PATH):
        os.makedirs(ADDON_DATA_PATH, exist_ok=True)


def _http(url, method='GET', data=None, headers=None, timeout=30):
    """HTTP helper - returns (status_code, parsed_json_or_text)"""
    hdrs = {'User-Agent': USER_AGENT}
    if headers:
        hdrs.update(headers)
    
    post_data = None
    if data is not None:
        if isinstance(data, dict):
            post_data = urlencode(data).encode('utf-8')
            hdrs.setdefault('Content-Type', 'application/x-www-form-urlencoded')
        elif isinstance(data, str):
            post_data = data.encode('utf-8')
        elif isinstance(data, bytes):
            post_data = data
    
    try:
        req = Request(url, data=post_data, headers=hdrs, method=method)
        resp = urlopen(req, timeout=timeout)
        body = resp.read().decode('utf-8', errors='replace')
        try:
            return resp.getcode(), json.loads(body)
        except json.JSONDecodeError:
            return resp.getcode(), body
    except HTTPError as e:
        body = ''
        try:
            body = e.read().decode('utf-8')
        except Exception:
            pass
        try:
            return e.code, json.loads(body)
        except Exception:
            return e.code, body
    except URLError as e:
        xbmc.log(f'Debrid URL Error: {e.reason}', xbmc.LOGERROR)
        return 0, None
    except Exception as e:
        xbmc.log(f'Debrid HTTP error: {e}', xbmc.LOGERROR)
        return 0, None


def _get(url, params=None, headers=None, timeout=30):
    """HTTP GET helper"""
    if params:
        query = urlencode(params)
        sep = '&' if '?' in url else '?'
        url = f'{url}{sep}{query}'
    return _http(url, method='GET', headers=headers, timeout=timeout)


def _post(url, data=None, params=None, headers=None, timeout=30):
    """HTTP POST helper"""
    if params:
        query = urlencode(params)
        sep = '&' if '?' in url else '?'
        url = f'{url}{sep}{query}'
    return _http(url, method='POST', data=data, headers=headers, timeout=timeout)


def _post_json(url, data=None, params=None, headers=None, timeout=30):
    """HTTP POST helper that sends body as application/json"""
    if params:
        query = urlencode(params)
        sep = '&' if '?' in url else '?'
        url = f'{url}{sep}{query}'
    hdrs = {'Content-Type': 'application/json'}
    if headers:
        hdrs.update(headers)
    body = json.dumps(data) if data is not None else None
    return _http(url, method='POST', data=body, headers=hdrs, timeout=timeout)


# ── Auth-window helpers ─────────────────────────────────────────────────────

def _download_qr_code(url):
    """Download a QR-code PNG via the free qrserver.com API; return temp-file path."""
    try:
        from urllib.parse import quote as _q
        # Preserve the complete authorization URI for QR-based sign-in.
        qr_target = url or ''
        qr_api = (
            'https://api.qrserver.com/v1/create-qr-code/'
            f'?size=300x300&data={_q(qr_target, safe="")}'
        )
        req = Request(qr_api, headers={'User-Agent': USER_AGENT})
        with urlopen(req, timeout=8) as resp:
            img_bytes = resp.read()
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.png')
        tmp.write(img_bytes)
        tmp.close()
        xbmc.log(f'COSMOS: QR code saved to {tmp.name}', xbmc.LOGDEBUG)
        return tmp.name
    except Exception as e:
        xbmc.log(f'COSMOS: QR download error: {e}', xbmc.LOGWARNING)
        return ''


def _service_icon_path(service_key):
    """Return absolute path to the service icon, or '' if unavailable."""
    _icons = {
        'rd': os.path.join(ADDON_PATH, 'resources', 'media', 'icon_rd.jpg'),
        'ad': os.path.join(ADDON_PATH, 'resources', 'media', 'icon_ad.jpg'),
        'tb': os.path.join(ADDON_PATH, 'resources', 'media', 'icon_tb.jpg'),
        'ls': os.path.join(ADDON_PATH, 'resources', 'media', 'icon_ls.jpg'),
        'pm': os.path.join(ADDON_PATH, 'resources', 'media', 'icon_pm.jpg'),
        'oc': os.path.join(ADDON_PATH, 'resources', 'media', 'icon_oc.png'),
    }
    p = _icons.get(service_key, '')
    return p if p and os.path.exists(p) else ''


def _run_device_auth_window(service_name, service_key, user_code, verification_url,
                             expires_in, interval, poll_fn):
    """Show the full-screen AuthDialog and run poll_fn in a background thread."""
    qr_path   = _download_qr_code(verification_url)
    icon_path = _service_icon_path(service_key)

    try:
        try:
            from resources.lib.auth_dialog import AuthDialog
        except ImportError:
            from auth_dialog import AuthDialog

        dialog = AuthDialog(
            'AuthDialog.xml', ADDON_PATH, 'Default', '720p',
            service_name=service_name,
            user_code=user_code,
            verification_url=verification_url,
            expires_in=expires_in,
            icon_path=icon_path,
            qr_path=qr_path,
        )
    except Exception as e:
        xbmc.log(f'COSMOS: AuthDialog load error (falling back): {e}', xbmc.LOGWARNING)
        return _run_plain_auth_dialog(service_name, user_code, verification_url,
                                      expires_in, interval, poll_fn)

    result = [False]

    def _poll():
        start = time.time()
        while not dialog.canceled:
            time.sleep(interval)
            elapsed  = time.time() - start
            remaining = max(0, expires_in - elapsed)
            if remaining <= 0:
                dialog.close()
                return
            dialog.update_remaining(remaining)
            try:
                outcome = poll_fn()
            except Exception as exc:
                xbmc.log(f'COSMOS: auth poll error: {exc}', xbmc.LOGWARNING)
                continue
            if outcome == 'success':
                result[0] = True
                dialog.mark_authorized()
                return
            if outcome == 'denied':
                dialog.mark_denied()
                return

    t = threading.Thread(target=_poll, daemon=True)
    t.start()
    dialog.doModal()
    t.join(timeout=10)

    try:
        if qr_path and os.path.exists(qr_path):
            os.remove(qr_path)
    except Exception:
        pass

    return result[0]


def _run_plain_auth_dialog(service_name, user_code, verification_url,
                            expires_in, interval, poll_fn):
    """Fallback DialogProgress if the custom window fails to load."""
    dialog = xbmcgui.DialogProgress()
    dialog.create(f'{service_name} Authorization', '')
    start = time.time()
    while True:
        elapsed   = time.time() - start
        remaining = expires_in - elapsed
        if remaining <= 0 or dialog.iscanceled():
            dialog.close()
            return False
        dialog.update(
            max(0, int(100 - (elapsed / expires_in) * 100)),
            f'Go to: [COLOR skyblue]{verification_url}[/COLOR]\n\n'
            f'Enter Code: [COLOR yellow]{user_code}[/COLOR]\n\n'
            f'Time remaining: {int(remaining)}s',
        )
        time.sleep(interval)
        try:
            outcome = poll_fn()
        except Exception:
            continue
        if outcome == 'success':
            dialog.close()
            return True
        if outcome == 'denied':
            dialog.close()
            return False


class RealDebrid:
    """Real-Debrid API integration using device auth with file-based token storage"""
    
    BASE_URL = "https://api.real-debrid.com/rest/1.0"
    OAUTH_URL = "https://api.real-debrid.com/oauth/v2"
    DEVICE_URL = "https://real-debrid.com/device"
    CLIENT_ID = "X245A4XAIBGVM"
    
    def __init__(self):
        self._load_from_file()
    
    def _load_from_file(self):
        _ensure_data_path()
        self.token = ''
        self.refresh_token = ''
        self.client_id = self.CLIENT_ID
        self.client_secret = ''
        self.expires = 0
        
        addon = get_addon()
        self.token = addon.getSetting('rd_access_token')
        self.refresh_token = addon.getSetting('rd_refresh_token')
        self.client_id = addon.getSetting('rd_client_id') or self.CLIENT_ID
        self.client_secret = addon.getSetting('rd_client_secret') or ''
        try:
            self.expires = float(addon.getSetting('rd_expires') or 0)
        except Exception:
            self.expires = 0

        if not self.token and os.path.exists(RD_TOKEN_FILE):
            try:
                with open(RD_TOKEN_FILE, 'r') as f:
                    data = json.load(f)
                    self.token = data.get('access_token', '')
                    self.refresh_token = data.get('refresh_token', '')
                    self.client_id = data.get('client_id', self.CLIENT_ID)
                    self.client_secret = data.get('client_secret', '')
                    self.expires = float(data.get('expires', 0))
            except Exception:
                pass
    
    def _save_to_file(self):
        _ensure_data_path()
        data = {
            'access_token': self.token,
            'refresh_token': self.refresh_token,
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'expires': self.expires,
            'created_at': time.time()
        }
        try:
            with open(RD_TOKEN_FILE, 'w') as f:
                json.dump(data, f, indent=2)
            _chmod_private(RD_TOKEN_FILE)
        except Exception:
            pass
        
        try:
            addon = get_addon()
            addon.setSetting('rd_access_token', self.token)
            addon.setSetting('rd_refresh_token', self.refresh_token)
            addon.setSetting('rd_client_id', self.client_id)
            addon.setSetting('rd_client_secret', self.client_secret)
            addon.setSetting('rd_expires', str(self.expires))
            addon.setSetting('rd_auth_done', 'true')
        except Exception:
            pass
    
    def _auth_headers(self):
        return {'Authorization': f'Bearer {self.token}'}
    
    def is_authorized(self):
        if not self.token:
            return False
        
        if self.expires and time.time() > self.expires - 600:
            refreshed = self._refresh_token()
            if not refreshed:
                try:
                    status, result = _get(
                        f"{self.BASE_URL}/user",
                        headers=self._auth_headers()
                    )
                    if status == 200:
                        return True
                except Exception:
                    pass
                return False
            return True
        return True
    
    def _refresh_token(self):
        if not self.refresh_token or not self.client_secret:
            return False
        
        try:
            data = {
                'client_id': self.client_id,
                'client_secret': self.client_secret,
                'code': self.refresh_token,
                'grant_type': 'http://oauth.net/grant_type/device/1.0'
            }
            status, result = _post(f'{self.OAUTH_URL}/token', data=data)
            if status == 200 and isinstance(result, dict) and 'access_token' in result:
                self.token = result['access_token']
                self.refresh_token = result.get('refresh_token', self.refresh_token)
                self.expires = time.time() + result.get('expires_in', 86400)
                self._save_to_file()
                return True
        except Exception:
            pass
        return False
    
    def authorize(self):
        try:
            status, result = _get(
                f"{self.OAUTH_URL}/device/code",
                params={"client_id": self.CLIENT_ID, "new_credentials": "yes"}
            )
            if status != 200 or not isinstance(result, dict):
                xbmcgui.Dialog().notification('Error', 'Failed to get device code', xbmcgui.NOTIFICATION_ERROR)
                return False

            device_code = result.get('device_code')
            user_code = result.get('user_code')
            verification_url = result.get('verification_url', self.DEVICE_URL)
            expires_in = result.get('expires_in', 600)
            interval = result.get('interval', 5)

            if not device_code or not user_code:
                xbmcgui.Dialog().notification('Error', 'Invalid response from Real-Debrid', xbmcgui.NOTIFICATION_ERROR)
                return False

            def _poll():
                check_status, check_result = _get(
                    f"{self.OAUTH_URL}/device/credentials",
                    params={"client_id": self.CLIENT_ID, "code": device_code}
                )
                if check_status == 200 and isinstance(check_result, dict) and 'client_id' in check_result:
                    client_id     = check_result.get('client_id')
                    client_secret = check_result.get('client_secret')
                    tok_status, tok_result = _post(
                        f"{self.OAUTH_URL}/token",
                        data={
                            "client_id":     client_id,
                            "client_secret": client_secret,
                            "code":          device_code,
                            "grant_type":    "http://oauth.net/grant_type/device/1.0",
                        }
                    )
                    if tok_status == 200 and isinstance(tok_result, dict) and 'access_token' in tok_result:
                        self.token         = tok_result.get('access_token', '')
                        self.refresh_token = tok_result.get('refresh_token', '')
                        self.client_id     = client_id
                        self.client_secret = client_secret
                        self.expires       = time.time() + tok_result.get('expires_in', 86400)
                        self._save_to_file()
                        return 'success'
                return None

            ok = _run_device_auth_window(
                service_name='Real-Debrid', service_key='rd',
                user_code=user_code, verification_url=verification_url,
                expires_in=int(expires_in), interval=int(interval),
                poll_fn=_poll,
            )
            if ok:
                xbmcgui.Dialog().notification('Success!', 'Real-Debrid linked!', xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification('Cancelled', 'Authorization cancelled', xbmcgui.NOTIFICATION_WARNING)
            return ok
        except Exception as e:
            xbmcgui.Dialog().notification('Error', f'Auth failed: {str(e)}', xbmcgui.NOTIFICATION_ERROR)
            return False
    
    def check_cache(self, hashes):
        # Cache availability is unknown until a submitted torrent is ready.
        return {}

    def probe_cache_realtime(self, magnet, cleanup=True):
        if not self.is_authorized() or not magnet:
            return False, None
        try:
            status, result = _post(
                f"{self.BASE_URL}/torrents/addMagnet",
                data={"magnet": magnet},
                headers=self._auth_headers()
            )
            if not isinstance(result, dict) or 'id' not in result:
                return False, None
            torrent_id = result['id']

            _, info = _get(
                f"{self.BASE_URL}/torrents/info/{torrent_id}",
                headers=self._auth_headers()
            )
            is_cached = isinstance(info, dict) and info.get('status') == 'downloaded'

            if not is_cached and cleanup:
                try:
                    _http(
                        f"{self.BASE_URL}/torrents/delete/{torrent_id}",
                        method='DELETE',
                        headers=self._auth_headers()
                    )
                except Exception:
                    pass
                return False, None

            return is_cached, torrent_id
        except Exception:
            return False, None
    
    def unrestrict_link(self, link):
        if not self.is_authorized():
            return None
        try:
            status, result = _post(
                f"{self.BASE_URL}/unrestrict/link",
                data={"link": link},
                headers=self._auth_headers()
            )
            if isinstance(result, dict):
                return result.get('download')
        except Exception:
            pass
        return None
    
    def add_magnet(self, magnet, check_cache_first=True, allow_cloud=False):
        if not self.is_authorized():
            return None
        try:
            status, result = _post(
                f"{self.BASE_URL}/torrents/addMagnet",
                data={"magnet": magnet},
                headers=self._auth_headers()
            )
            if not isinstance(result, dict) or 'id' not in result:
                return None
            
            torrent_id = result.get('id')
            _, initial_info = _get(
                f"{self.BASE_URL}/torrents/info/{torrent_id}",
                headers=self._auth_headers()
            )
            torrent_files = initial_info.get('files', []) if isinstance(initial_info, dict) else []
            target_file = _select_torrent_file(torrent_files, magnet)
            selected_files = str(target_file.get('id')) if not allow_cloud and target_file and target_file.get('id') is not None else 'all'
            selection_status, _ = _post(
                f"{self.BASE_URL}/torrents/selectFiles/{torrent_id}",
                data={"files": selected_files},
                headers=self._auth_headers()
            )
            
            if allow_cloud and selection_status in (202, 204):
                return {'id': torrent_id}

            for _ in range(30):
                _, info = _get(
                    f"{self.BASE_URL}/torrents/info/{torrent_id}",
                    headers=self._auth_headers()
                )
                if isinstance(info, dict):
                    status = info.get('status', '')
                    if allow_cloud and status in ('queued', 'downloading', 'downloaded', 'uploading'):
                        return {'id': torrent_id}
                    if status == 'downloaded':
                        links = info.get('links', [])
                        if links:
                            selected = [f for f in info.get('files', []) if f.get('selected')]
                            target = _select_torrent_file(selected, magnet)
                            if target and len(selected) == len(links):
                                return self.unrestrict_link(links[selected.index(target)])
                            return self.unrestrict_link(links[0])
                    elif status in ['error', 'dead', 'virus', 'magnet_error']:
                        return None
                    elif status == 'waiting_files_selection':
                        torrent_files = info.get('files', [])
                        target_file = _select_torrent_file(torrent_files, magnet)
                        selected_files = str(target_file.get('id')) if not allow_cloud and target_file and target_file.get('id') is not None else 'all'
                        _post(
                            f"{self.BASE_URL}/torrents/selectFiles/{torrent_id}",
                            data={"files": selected_files},
                            headers=self._auth_headers()
                        )
                time.sleep(2)
            return None
        except Exception:
            return None
    
    def revoke(self):
        if os.path.exists(RD_TOKEN_FILE):
            try:
                os.remove(RD_TOKEN_FILE)
            except Exception:
                pass
        try:
            addon = get_addon()
            addon.setSetting('rd_access_token', '')
            addon.setSetting('rd_refresh_token', '')
            addon.setSetting('rd_client_id', '')
            addon.setSetting('rd_client_secret', '')
            addon.setSetting('rd_expires', '0')
            addon.setSetting('rd_auth_done', 'false')
        except Exception:
            pass
        self.token = ''
        self.refresh_token = ''
        xbmcgui.Dialog().notification("Real-Debrid", "Account unlinked", xbmcgui.NOTIFICATION_INFO)

    def account_info(self):
        if not self.token:
            return {}
        try:
            status, result = _get(
                f"{self.BASE_URL}/user",
                headers=self._auth_headers()
            )
            if status == 200 and isinstance(result, dict):
                expiration = result.get('expiration', '')
                days_left = 0
                if expiration:
                    try:
                        from datetime import datetime, timezone
                        # Make timezone-aware to correctly calculate days_left
                        if expiration.endswith('Z'):
                            expiration = expiration.replace('Z', '+00:00')
                        exp_date = datetime.fromisoformat(expiration)
                        delta = exp_date - datetime.now(timezone.utc)
                        days_left = max(0, delta.days)
                    except Exception:
                        pass
                return {
                    'username': result.get('username', ''),
                    'email': result.get('email', ''),
                    'type': result.get('type', 'free'),
                    'premium': result.get('type', '') == 'premium',
                    'expiration': expiration,
                    'days_left': days_left,
                    'points': result.get('points', 0),
                }
            elif status == 401:
                if self._refresh_token():
                    return self.account_info()
                return {'type': 'expired', 'premium': False, 'days_left': 0, 'expiration': 'Token expired - re-authorize'}
        except Exception:
            pass
        return {}


class AllDebrid:
    """AllDebrid API integration with file-based token storage"""
    
    BASE_URL = "https://api.alldebrid.com/v4"
    STATUS_URL = "https://api.alldebrid.com/v4.1"
    DEVICE_URL = "https://alldebrid.com/pin/"
    AGENT = "TraktPlayer"
    
    def __init__(self):
        self._load_from_file()
    
    def _load_from_file(self):
        _ensure_data_path()
        self.token = ''
        self.token = get_addon().getSetting('ad_api_key')
        if not self.token:
            if os.path.exists(AD_TOKEN_FILE):
                try:
                    with open(AD_TOKEN_FILE, 'r') as f:
                        data = json.load(f)
                        self.token = data.get('api_key', '')
                except Exception:
                    pass
    
    def _save_to_file(self):
        _ensure_data_path()
        try:
            with open(AD_TOKEN_FILE, 'w') as f:
                json.dump({'api_key': self.token, 'created_at': time.time()}, f)
            _chmod_private(AD_TOKEN_FILE)
            addon = get_addon()
            addon.setSetting('ad_api_key', self.token)
            addon.setSetting('ad_auth_done', 'true')
        except Exception:
            pass
    
    def is_authorized(self):
        return bool(self.token)
    
    def authorize(self):
        try:
            status, result = _get(f"{self.STATUS_URL}/pin/get", params={"agent": self.AGENT})
            if not isinstance(result, dict) or result.get('status') != 'success':
                xbmcgui.Dialog().notification('Error', 'Failed to get PIN', xbmcgui.NOTIFICATION_ERROR)
                return False

            data      = result.get('data', {})
            pin       = data.get('pin')
            check_token = data.get('check')
            user_url  = data.get('user_url', self.DEVICE_URL)
            expires_in = data.get('expires_in', 600)

            if not pin or not check_token:
                xbmcgui.Dialog().notification('Error', 'Invalid PIN response', xbmcgui.NOTIFICATION_ERROR)
                return False

            def _poll():
                check_status, check_result = _post(f"{self.BASE_URL}/pin/check", data={"pin": pin, "check": check_token})
                if isinstance(check_result, dict) and check_result.get('status') == 'success':
                    api_key = check_result.get('data', {}).get('apikey')
                    if api_key:
                        self.token = api_key
                        self._save_to_file()
                        return 'success'
                if isinstance(check_result, dict) and (check_result.get('error') or {}).get('code') in ('PIN_EXPIRED', 'PIN_INVALID'):
                    return 'denied'
                return None

            ok = _run_device_auth_window(
                service_name='AllDebrid', service_key='ad',
                user_code=pin, verification_url=user_url,
                expires_in=int(expires_in), interval=5,
                poll_fn=_poll,
            )
            if ok:
                xbmcgui.Dialog().notification('Success!', 'AllDebrid linked!', xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification('Cancelled', 'Authorization cancelled', xbmcgui.NOTIFICATION_WARNING)
            return ok
        except Exception as e:
            xbmcgui.Dialog().notification('Error', f'Auth failed: {str(e)}', xbmcgui.NOTIFICATION_ERROR)
            return False
    
    def check_cache(self, magnets):
        # No instant-cache lookup is exposed by the current documented API.
        # An empty result is unknown availability, not a playback rejection.
        return {}

    def _auth_headers(self):
        return {'Authorization': 'Bearer ' + self.token}

    def magnet_status(self, magnet_id=None):
        status, result = _post(self.STATUS_URL + '/magnet/status',
                               data={'id': magnet_id} if magnet_id is not None else {},
                               headers=self._auth_headers())
        if status != 200 or not isinstance(result, dict) or result.get('status') != 'success':
            return []
        magnets = result.get('data', {}).get('magnets') or []
        return [magnets] if isinstance(magnets, dict) else magnets

    def magnet_files(self, magnet_id):
        status, result = _post(self.BASE_URL + '/magnet/files',
                               data={'id[]': magnet_id}, headers=self._auth_headers())
        if status != 200 or not isinstance(result, dict) or result.get('status') != 'success':
            return []
        files = []
        def walk(nodes, parent=''):
            for node in nodes:
                if not isinstance(node, dict):
                    continue
                path = (parent + '/' if parent else '') + str(node.get('n') or '')
                if node.get('l'):
                    files.append({'path': path, 'filename': node.get('n') or path,
                                  'size': node.get('s') or 0, 'link': node['l']})
                if isinstance(node.get('e'), list):
                    walk(node['e'], path)
        for magnet in result.get('data', {}).get('magnets') or []:
            if str(magnet.get('id')) == str(magnet_id) and not magnet.get('error'):
                walk(magnet.get('files') or [])
        return files

    def unrestrict_link(self, link):
        if not self.is_authorized():
            return None
        try:
            status, result = _post(
                f"{self.BASE_URL}/link/unlock",
                data={"link": link}, headers=self._auth_headers()
            )
            if status == 200 and isinstance(result, dict) and result.get('status') == 'success':
                data = result.get('data', {})
                if data.get('link'):
                    return data['link']
                delayed_id = data.get('delayed')
                if delayed_id:
                    for _ in range(12):
                        time.sleep(5)
                        status, result = _post(self.BASE_URL + '/link/delayed',
                                               data={'id': delayed_id}, headers=self._auth_headers())
                        if status != 200 or not isinstance(result, dict) or result.get('status') != 'success':
                            return None
                        data = result.get('data', {})
                        if data.get('status') == 2:
                            return data.get('link')
                        if data.get('status') != 1:
                            return None
        except Exception:
            pass
        return None
    
    def add_magnet(self, magnet, check_cache_first=True, allow_cloud=False):
        if not self.is_authorized():
            return None
        try:
            status, result = _post(self.BASE_URL + '/magnet/upload',
                                   data={'magnets[]': magnet}, headers=self._auth_headers())
            if status != 200 or not isinstance(result, dict) or result.get('status') != 'success':
                return None
            uploads = result.get('data', {}).get('magnets') or []
            uploaded = uploads[0] if uploads else {}
            magnet_id = uploaded.get('id')
            if not magnet_id or uploaded.get('error'):
                return None
            if allow_cloud:
                return {'id': magnet_id}
            for _ in range(30):
                rows = self.magnet_status(magnet_id)
                row = next((r for r in rows if str(r.get('id')) == str(magnet_id)), None)
                if not row:
                    return None
                if row.get('statusCode') == 4 or row.get('status') == 'Ready':
                    target = _select_torrent_file(self.magnet_files(magnet_id), magnet)
                    return self.unrestrict_link(target['link']) if target else None
                if int(row.get('statusCode') or 0) >= 5:
                    return None
                time.sleep(2)
        except Exception:
            pass
        return None

    def revoke(self):
        if os.path.exists(AD_TOKEN_FILE):
            try:
                os.remove(AD_TOKEN_FILE)
            except Exception:
                pass
        addon = get_addon()
        addon.setSetting('ad_api_key', '')
        addon.setSetting('ad_auth_done', 'false')
        self.token = ''
        xbmcgui.Dialog().notification("AllDebrid", "Account unlinked", xbmcgui.NOTIFICATION_INFO)

    def account_info(self):
        if not self.token:
            return {}
        try:
            status, result = _get(
                f"{self.BASE_URL}/user",
                headers=self._auth_headers()
            )
            if isinstance(result, dict) and result.get('status') == 'success':
                data = result.get('data', {}).get('user', {})
                premium_until = data.get('premiumUntil', 0)
                days_left = 0
                exp_str = 'Unknown'
                if premium_until:
                    try:
                        from datetime import datetime
                        exp_date = datetime.utcfromtimestamp(float(premium_until))
                        delta = exp_date - datetime.utcnow()
                        days_left = max(0, delta.days)
                        exp_str = exp_date.strftime('%Y-%m-%d')
                    except Exception:
                        pass
                return {
                    'username': data.get('username', ''),
                    'email': data.get('email', ''),
                    'type': 'premium' if data.get('isPremium') else 'free',
                    'premium': bool(data.get('isPremium')),
                    'expiration': exp_str,
                    'days_left': days_left,
                }
        except Exception:
            pass
        return {}


class Premiumize:
    """Premiumize API integration with file-based token storage"""
    
    BASE_URL = "https://www.premiumize.me/api"
    TOKEN_URL = "https://www.premiumize.me/token"
    DEVICE_URL = "https://www.premiumize.me/device"
    CLIENT_ID = "662875953"
    CLIENT_SECRET = "xmg33m74n6t6x8phun"
    
    def __init__(self):
        self._load_from_file()
    
    def _load_from_file(self):
        _ensure_data_path()
        self.token = ''
        self.token = get_addon().getSetting('pm_access_token')
        if not self.token:
            if os.path.exists(PM_TOKEN_FILE):
                try:
                    with open(PM_TOKEN_FILE, 'r') as f:
                        data = json.load(f)
                        self.token = data.get('access_token', '')
                except Exception:
                    pass
    
    def _save_to_file(self):
        _ensure_data_path()
        try:
            with open(PM_TOKEN_FILE, 'w') as f:
                json.dump({'access_token': self.token, 'created_at': time.time()}, f)
            _chmod_private(PM_TOKEN_FILE)
            addon = get_addon()
            addon.setSetting('pm_access_token', self.token)
            addon.setSetting('pm_auth_done', 'true')
        except Exception:
            pass
    
    def is_authorized(self):
        return bool(self.token)
    
    def authorize(self):
        try:
            status, result = _post(
                self.TOKEN_URL,
                data={"client_id": self.CLIENT_ID, "response_type": "device_code"}
            )
            if not isinstance(result, dict) or not result.get('device_code'):
                xbmcgui.Dialog().notification('Error', 'Failed to get device code', xbmcgui.NOTIFICATION_ERROR)
                return False

            device_code      = result.get('device_code')
            user_code        = result.get('user_code')
            verification_url = result.get('verification_uri', self.DEVICE_URL)
            expires_in       = int(result.get('expires_in', 600))
            interval         = int(result.get('interval', 5))

            next_poll = [0.0]
            poll_interval = [max(1, interval)]

            def _poll():
                if time.monotonic() < next_poll[0]:
                    return None
                check_status, check_result = _post(
                    self.TOKEN_URL,
                    data={
                        "client_id":  self.CLIENT_ID,
                        "code":       device_code,
                        "grant_type": "device_code",
                    }
                )
                if isinstance(check_result, dict):
                    if check_result.get('access_token'):
                        self.token = check_result.get('access_token')
                        self._save_to_file()
                        return 'success'
                    error = check_result.get('error')
                    if error in ('access_denied', 'invalid_grant'):
                        return 'denied'
                    if error == 'slow_down':
                        poll_interval[0] += 5
                next_poll[0] = time.monotonic() + poll_interval[0]
                return None

            ok = _run_device_auth_window(
                service_name='Premiumize', service_key='pm',
                user_code=user_code, verification_url=verification_url,
                expires_in=expires_in, interval=interval,
                poll_fn=_poll,
            )
            if ok:
                xbmcgui.Dialog().notification('Success!', 'Premiumize linked!', xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification('Cancelled', 'Authorization cancelled', xbmcgui.NOTIFICATION_WARNING)
            return ok
        except Exception as e:
            xbmcgui.Dialog().notification('Error', f'Auth failed: {str(e)}', xbmcgui.NOTIFICATION_ERROR)
            return False
    
    def check_cache(self, hashes):
        if not self.is_authorized() or not hashes:
            return {}
        try:
            params = urlencode({'items[]': hashes[:100]}, doseq=True)
            status, result = _post(
                f"{self.BASE_URL}/cache/check",
                headers={"Authorization": f"Bearer {self.token}",
                         "Content-Type": "application/x-www-form-urlencoded"},
                data=params
            )
            if isinstance(result, dict) and result.get('status') == 'success':
                response = result.get('response', [])
                cached = {}
                for i, is_cached in enumerate(response):
                    if is_cached and i < len(hashes):
                        cached[hashes[i].lower()] = True
                return cached
        except Exception:
            pass
        return {}
    
    def unrestrict_link(self, link):
        if not self.is_authorized():
            return None
        try:
            status, result = _post(
                f"{self.BASE_URL}/transfer/directdl",
                headers={"Authorization": f"Bearer {self.token}"},
                data={"src": link}
            )
            if isinstance(result, dict) and result.get('status') == 'success':
                content = result.get('content', [])
                if content:
                    target = _select_torrent_file(content, link)
                    return target.get('link') if target else None
        except Exception:
            pass
        return None
    
    def add_magnet(self, magnet, check_cache_first=True):
        return self.unrestrict_link(magnet)

    def create_transfer(self, source):
        """Explicit Cloud-menu transfers must be stored, not just resolved."""
        if not self.is_authorized():
            return None
        status, result = _post(
            f'{self.BASE_URL}/transfer/create', data={'src': source},
            headers={'Authorization': f'Bearer {self.token}'},
        )
        if status == 200 and isinstance(result, dict) and result.get('status') == 'success' and result.get('id'):
            return result
        return None
    
    def revoke(self):
        if os.path.exists(PM_TOKEN_FILE):
            try:
                os.remove(PM_TOKEN_FILE)
            except Exception:
                pass
        addon = get_addon()
        addon.setSetting('pm_access_token', '')
        addon.setSetting('pm_auth_done', 'false')
        self.token = ''
        xbmcgui.Dialog().notification("Premiumize", "Account unlinked", xbmcgui.NOTIFICATION_INFO)

    def account_info(self):
        if not self.token:
            return {}
        try:
            status, result = _get(
                f"{self.BASE_URL}/account/info",
                headers={"Authorization": f"Bearer {self.token}"}
            )
            if status == 200 and isinstance(result, dict) and result.get('status') == 'success':
                premium_until = result.get('premium_until', 0)
                days_left = 0
                exp_str = 'Unknown'
                if premium_until:
                    try:
                        from datetime import datetime
                        exp_date = datetime.utcfromtimestamp(float(premium_until))
                        delta = exp_date - datetime.utcnow()
                        days_left = max(0, int((delta.total_seconds() + 86399) // 86400))
                        exp_str = exp_date.strftime('%Y-%m-%d')
                    except Exception:
                        pass
                return {
                    'username': str(result.get('customer_id', '')),
                    'type': 'premium' if premium_until else 'free',
                    'premium': bool(premium_until and days_left > 0),
                    'expiration': exp_str,
                    'days_left': days_left,
                    'space_used': result.get('space_used', 0),
                    'limit_used': result.get('limit_used', 0),
                }
            elif status == 401:
                return {'type': 'expired', 'premium': False, 'days_left': 0, 'expiration': 'Token expired - re-authorize'}
        except Exception:
            pass
        return {}


class Torbox:
    """Torbox API integration."""

    BASE_URL = "https://api.torbox.app/v1/api"
    DEVICE_URL = "https://torbox.app/oauth/device"

    def __init__(self):
        self._load_from_file()

    def _load_from_file(self):
        _ensure_data_path()
        self.token = ''
        self.token = (get_addon().getSetting('tb_api_key') or '').strip()
        if not self.token:
            if os.path.exists(TB_TOKEN_FILE):
                try:
                    with open(TB_TOKEN_FILE, 'r') as f:
                        data = json.load(f)
                        self.token = data.get('access_token', '')
                except Exception:
                    pass

    def _save_to_file(self):
        _ensure_data_path()
        try:
            with open(TB_TOKEN_FILE, 'w') as f:
                json.dump({'access_token': self.token, 'created_at': time.time()}, f)
            _chmod_private(TB_TOKEN_FILE)
            addon = get_addon()
            addon.setSetting('tb_api_key', self.token)
            addon.setSetting('tb_auth_done', 'true')
        except Exception:
            pass

    def _auth_headers(self):
        return {'Authorization': f'Bearer {self.token}'}

    def is_authorized(self):
        return bool(self.token)

    def authorize(self):
        try:
            dlg = xbmcgui.Dialog()
            choice = dlg.select(
                'Torbox Authorization',
                ['Enter API Key (recommended)', 'Device Code (browser link)']
            )
            if choice < 0:
                return False
            if choice == 0:
                return self._authorize_apikey()
            return self._authorize_device()
        except Exception as e:
            xbmcgui.Dialog().notification('Error', f'Auth failed: {str(e)}', xbmcgui.NOTIFICATION_ERROR)
            return False

    def _authorize_apikey(self):
        key = xbmcgui.Dialog().input(
            'Paste Torbox API Key (Settings > API on torbox.app)',
            type=xbmcgui.INPUT_ALPHANUM
        )
        if not key:
            return False
        key = key.strip()
        status, result = _get(
            f'{self.BASE_URL}/user/me',
            headers={'Authorization': f'Bearer {key}'}
        )
        if status == 200 and isinstance(result, dict) and result.get('success'):
            self.token = key
            self._save_to_file()
            email = (result.get('data') or {}).get('email', 'unknown')
            xbmcgui.Dialog().notification('Torbox', f'Linked: {email}', xbmcgui.NOTIFICATION_INFO)
            return True
        xbmcgui.Dialog().notification('Torbox', 'Invalid API key', xbmcgui.NOTIFICATION_ERROR)
        return False

    def _authorize_device(self):
        status, result = _get(f"{self.BASE_URL}/user/auth/device/start")
        if not isinstance(result, dict) or not result.get('success'):
            xbmcgui.Dialog().notification('Error', 'Failed to start device auth', xbmcgui.NOTIFICATION_ERROR)
            return False

        data = result.get('data', {}) or {}
        device_code = data.get('device_code')
        user_code   = data.get('code') or data.get('user_code')
        # Keep the browser instruction stable even when the API returns the
        # legacy tor.box/link shortcut in friendly_verification_url.
        verification_url = self.DEVICE_URL
        interval = int(data.get('interval', 5) or 5)

        expires_in = data.get('expires_in')
        if not expires_in and data.get('expires_at'):
            try:
                from datetime import datetime, timezone
                exp = datetime.strptime(data['expires_at'][:19], '%Y-%m-%dT%H:%M:%S').replace(tzinfo=timezone.utc)
                expires_in = max(60, int((exp - datetime.now(timezone.utc)).total_seconds()))
            except Exception:
                expires_in = 600
        expires_in = int(expires_in or 600)

        if not device_code or not user_code:
            xbmcgui.Dialog().notification('Error', 'Invalid device code response', xbmcgui.NOTIFICATION_ERROR)
            return False

        def _poll():
            check_status, check_result = _post_json(
                f"{self.BASE_URL}/user/auth/device/token",
                data={"device_code": device_code}
            )
            if isinstance(check_result, dict) and check_result.get('success'):
                token_data   = check_result.get('data') or {}
                access_token = token_data.get('access_token') or token_data.get('token')
                if access_token:
                    self.token = access_token
                    self._save_to_file()
                    return 'success'
            if isinstance(check_result, dict):
                err = (check_result.get('error') or '').upper()
                if err and 'PENDING' not in err and 'NOT_USED' not in err and 'SLOW_DOWN' not in err:
                    return 'denied'
            return None

        ok = _run_device_auth_window(
            service_name='Torbox', service_key='tb',
            user_code=user_code, verification_url=verification_url,
            expires_in=expires_in, interval=interval,
            poll_fn=_poll,
        )
        if ok:
            xbmcgui.Dialog().notification('Success!', 'Torbox linked!', xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification('Cancelled', 'Authorization cancelled', xbmcgui.NOTIFICATION_WARNING)
        return ok

    def check_cache(self, hashes):
        if not self.is_authorized() or not hashes:
            return {}

        cached = {}
        try:
            for i in range(0, len(hashes), 100):
                chunk = hashes[i:i + 100]
                hash_str = ','.join(chunk)
                status, result = _get(
                    f"{self.BASE_URL}/torrents/checkcached",
                    params={
                        "hash": hash_str,
                        "format": "object",
                        "list_files": "false",
                    },
                    headers=self._auth_headers()
                )
                if not (isinstance(result, dict) and result.get('success')):
                    continue
                data = result.get('data') or {}
                if isinstance(data, list):
                    for item in data:
                        h = (item.get('hash') or '').lower()
                        if h:
                            cached[h] = True
                elif isinstance(data, dict):
                    for h_key, val in data.items():
                        if val:
                            cached[h_key.lower()] = True
        except Exception:
            pass
        return cached

    def unrestrict_link(self, link):
        if not self.is_authorized():
            return None
        try:
            status, result = _post(
                f"{self.BASE_URL}/webdl/createwebdownload",
                headers=self._auth_headers(),
                data={"link": link}
            )
            if not (isinstance(result, dict) and result.get('success')):
                return None

            data = result.get('data') or {}
            download_id = data.get('webdownload_id') or data.get('id')
            if not download_id:
                return None

            dl_status, dl_result = _get(
                f"{self.BASE_URL}/webdl/requestdl",
                params={"token": self.token, "web_id": download_id, "file_id": 0}
            )
            if isinstance(dl_result, dict) and dl_result.get('success'):
                return dl_result.get('data')
        except Exception:
            pass
        return None

    def add_magnet(self, magnet, check_cache_first=True):
        if not self.is_authorized():
            return None

        try:
            status, result = _post(
                f"{self.BASE_URL}/torrents/createtorrent",
                headers=self._auth_headers(),
                data={"magnet": magnet}
            )
            if not isinstance(result, dict) or not result.get('success'):
                return None

            data = result.get('data') or {}
            torrent_id = data.get('torrent_id') or data.get('id')
            if not torrent_id:
                return None

            for _ in range(30):
                _ls, list_result = _get(
                    f"{self.BASE_URL}/torrents/mylist",
                    params={"id": torrent_id, "bypass_cache": "true"},
                    headers=self._auth_headers()
                )
                if isinstance(list_result, dict) and list_result.get('success'):
                    td = list_result.get('data') or {}
                    if isinstance(td, list) and td:
                        td = td[0]

                    state = (td.get('download_state') or '').lower()
                    ready_states = ('completed', 'cached', 'uploading', 'seeding')
                    if td.get('download_present') or state in ready_states:
                        files = td.get('files') or []
                        target = _select_torrent_file(files, magnet)
                        file_id = target.get('id', 0) if target else 0

                        _ds, dl_result = _get(
                            f"{self.BASE_URL}/torrents/requestdl",
                            params={"token": self.token, "torrent_id": torrent_id, "file_id": file_id}
                        )
                        if isinstance(dl_result, dict) and dl_result.get('success'):
                            return dl_result.get('data')
                        return None

                    if state in ('error', 'failed', 'missing_files'):
                        return None
                time.sleep(2)
            return None
        except Exception:
            return None
    
    def revoke(self):
        if os.path.exists(TB_TOKEN_FILE):
            try:
                os.remove(TB_TOKEN_FILE)
            except Exception:
                pass
        addon = get_addon()
        addon.setSetting('tb_api_key', '')
        addon.setSetting('tb_auth_done', 'false')
        self.token = ''
        xbmcgui.Dialog().notification("Torbox", "Account unlinked", xbmcgui.NOTIFICATION_INFO)

    def account_info(self):
        if not self.token:
            return {}
        try:
            # The current TorBox API exposes account identity and subscription
            # data through separate documented endpoints.  /user/account was
            # used by an older integration but is not in the current Swagger.
            status, result = _get(f'{self.BASE_URL}/user/me', headers=self._auth_headers())
            if status in (401, 403):
                return {'type': 'expired', 'premium': False, 'days_left': 0, 'expiration': 'API key invalid - re-authorize'}
            if status != 200 or not isinstance(result, dict) or not result.get('success'):
                return {}

            user_data = result.get('data') or {}
            sub_status, sub_result = _get(
                f'{self.BASE_URL}/user/subscriptions',
                headers=self._auth_headers()
            )
            subscription_data = {}
            if sub_status == 200 and isinstance(sub_result, dict) and sub_result.get('success'):
                subscription_data = sub_result.get('data') or {}

            def _find_value(value, keys):
                if isinstance(value, dict):
                    for key in keys:
                        if value.get(key) not in (None, ''):
                            return value.get(key)
                    for child in value.values():
                        found = _find_value(child, keys)
                        if found not in (None, ''):
                            return found
                elif isinstance(value, list):
                    for child in value:
                        found = _find_value(child, keys)
                        if found not in (None, ''):
                            return found
                return None

            combined = {'user': user_data, 'subscriptions': subscription_data}
            premium_until = _find_value(combined, (
                'premium_expires_at', 'plan_active_until', 'premium_until',
                'expires_at', 'expiration', 'expires', 'end_date', 'endDate'
            ))
            plan = _find_value(combined, ('plan', 'plan_name', 'planName', 'subscription'))
            premium_flag = _find_value(combined, ('is_premium', 'isPremium', 'premium', 'active'))

            days_left = 0
            exp_str = 'Unknown'
            if premium_until:
                try:
                    from datetime import datetime, timezone
                    exp_date = None
                    value = str(premium_until).strip()
                    if value.replace('.', '', 1).isdigit():
                        exp_date = datetime.fromtimestamp(float(value), tz=timezone.utc)
                    else:
                        if value.endswith('Z'):
                            value = value[:-1] + '+00:00'
                        exp_date = datetime.fromisoformat(value)
                        if exp_date.tzinfo is None:
                            exp_date = exp_date.replace(tzinfo=timezone.utc)

                    if exp_date:
                        delta = exp_date - datetime.now(timezone.utc)
                        days_left = max(0, delta.days)
                        exp_str = exp_date.strftime('%Y-%m-%d')
                except Exception as e:
                    xbmc.log(f'COSMOS: Torbox date parsing failed: {e}', xbmc.LOGWARNING)
                    exp_str = str(premium_until)[:10]

            premium = bool(days_left > 0)
            if isinstance(premium_flag, bool):
                premium = premium or premium_flag
            if isinstance(plan, (int, float)):
                premium = premium or plan > 0
            elif isinstance(plan, str):
                premium = premium or plan.strip().lower() not in ('', 'free', 'none', '0', 'false')

            email = _find_value(user_data, ('email', 'username')) or ''
            return {
                'username': email,
                'email': email,
                'type': 'premium' if premium else 'free',
                'premium': premium,
                'expiration': exp_str,
                'days_left': days_left,
            }
        except Exception:
            pass
        return {}


class LinkSnappy:
    """LinkSnappy debrid service with username/password and session-cookie auth"""
    BASE_URL = 'https://linksnappy.com/api'

    def __init__(self):
        self.username = ''
        self.password = ''
        self.cookie = ''
        self._load_credentials()

    def _load_credentials(self):
        addon = get_addon()
        self.username = addon.getSetting('ls_username') or ''
        self.password = addon.getSetting('ls_password') or ''
        self.cookie = addon.getSetting('ls_cookie') or ''
        if not self.cookie and os.path.exists(LS_TOKEN_FILE):
            try:
                with open(LS_TOKEN_FILE, 'r') as f:
                    data = json.load(f)
                    self.cookie = data.get('cookie', '')
                    self.username = data.get('username', self.username)
            except Exception:
                pass

    def _save_credentials(self, cookie):
        self.cookie = cookie
        addon = get_addon()
        addon.setSetting('ls_cookie', cookie)
        addon.setSetting('ls_auth_done', 'true')
        try:
            os.makedirs(os.path.dirname(LS_TOKEN_FILE), exist_ok=True)
            with open(LS_TOKEN_FILE, 'w') as f:
                json.dump({'cookie': cookie, 'username': self.username}, f)
            _chmod_private(LS_TOKEN_FILE)
        except Exception:
            pass

    def authorize(self):
        try:
            icon_path = _service_icon_path('ls')
            username  = ''
            password  = ''

            try:
                try:
                    from resources.lib.auth_dialog import CredentialsDialog
                except ImportError:
                    from auth_dialog import CredentialsDialog

                dlg = CredentialsDialog(
                    'AuthDialogCredentials.xml', ADDON_PATH, 'Default', '720p',
                    service_name='LinkSnappy',
                    icon_path=icon_path,
                )
                dlg.doModal()
                if not dlg.confirmed:
                    return False
                username = dlg.username.strip()
                password = dlg.password
            except Exception:
                d = xbmcgui.Dialog()
                username = d.input('LinkSnappy Username').strip()
                if not username:
                    return False
                password = d.input('LinkSnappy Password', option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if not password:
                    return False

            if not username or not password:
                return False

            import urllib.request
            import urllib.parse
            import http.cookiejar

            cj     = http.cookiejar.CookieJar()
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
            data   = urllib.parse.urlencode({'username': username, 'password': password}).encode()
            req    = urllib.request.Request(
                f'{self.BASE_URL}/AUTHENTICATE', data=data,
                headers={'User-Agent': USER_AGENT}
            )
            resp   = opener.open(req, timeout=15)
            result = json.loads(resp.read().decode())

            if result.get('status') == 'OK':
                cookies       = '; '.join([f'{c.name}={c.value}' for c in cj])
                self.username = username
                self.password = password
                addon = get_addon()
                addon.setSetting('ls_username', username)
                addon.setSetting('ls_password', password)
                self._save_credentials(cookies)
                xbmcgui.Dialog().notification('LinkSnappy', f'Logged in as {username}', xbmcgui.NOTIFICATION_INFO)
                return True
            else:
                error_msg = result.get('error', 'Login failed')
                xbmcgui.Dialog().notification('LinkSnappy', error_msg, xbmcgui.NOTIFICATION_ERROR)
                return False
        except Exception as e:
            xbmcgui.Dialog().notification('LinkSnappy', f'Auth error: {e}', xbmcgui.NOTIFICATION_ERROR)
            return False

    def is_authorized(self):
        return bool((self.username and self.password) or self.cookie)

    def _login_headers(self):
        headers = {'User-Agent': USER_AGENT}
        if self.cookie:
            headers['Cookie'] = self.cookie
        return headers

    def unrestrict_link(self, link):
        if not self.is_authorized():
            return None
        try:
            import urllib.request
            import urllib.parse

            if not self.cookie and self.username and self.password:
                self._re_login()

            data = urllib.parse.urlencode({
                'genLinks': json.dumps([{'link': link}]),
                'username': self.username,
                'password': self.password,
            }).encode()

            req = urllib.request.Request(f'{self.BASE_URL}/linkgen', data=data, headers=self._login_headers())
            resp = urllib.request.urlopen(req, timeout=30)
            result = json.loads(resp.read().decode())

            if result.get('status') == 'OK':
                links = result.get('links', [])
                if links:
                    item = links[0]
                    if not isinstance(item, dict) or item.get('error') or item.get('status', 'OK') != 'OK':
                        return None
                    gen = item.get('generated', '')
                    if isinstance(gen, str) and gen.startswith(('https://', 'http://')):
                        return gen
        except Exception:
            pass
        return None

    def _re_login(self):
        try:
            import urllib.request
            import urllib.parse
            import http.cookiejar

            cj = http.cookiejar.CookieJar()
            opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
            data = urllib.parse.urlencode({
                'username': self.username,
                'password': self.password
            }).encode()
            req = urllib.request.Request(f'{self.BASE_URL}/AUTHENTICATE', data=data, headers={'User-Agent': USER_AGENT})
            resp = opener.open(req, timeout=15)
            result = json.loads(resp.read().decode())
            if result.get('status') == 'OK':
                cookies = '; '.join([f'{c.name}={c.value}' for c in cj])
                self._save_credentials(cookies)
        except Exception:
            pass

    def add_magnet(self, magnet, check_cache_first=True):
        return self.unrestrict_link(magnet)

    def check_cache(self, hashes):
        return {}

    def revoke(self):
        if os.path.exists(LS_TOKEN_FILE):
            try:
                os.remove(LS_TOKEN_FILE)
            except Exception:
                pass
        addon = get_addon()
        addon.setSetting('ls_username', '')
        addon.setSetting('ls_password', '')
        addon.setSetting('ls_cookie', '')
        addon.setSetting('ls_auth_done', 'false')
        self.username = ''
        self.password = ''
        self.cookie = ''
        xbmcgui.Dialog().notification('LinkSnappy', 'Account unlinked', xbmcgui.NOTIFICATION_INFO)

    def account_info(self):
        if not self.is_authorized():
            return {}
        try:
            import urllib.request
            import urllib.parse

            if not self.cookie and self.username and self.password:
                self._re_login()

            data = urllib.parse.urlencode({
                'username': self.username,
                'password': self.password,
            }).encode()
            req = urllib.request.Request(f'{self.BASE_URL}/USERDETAILS', data=data, headers=self._login_headers())
            resp = urllib.request.urlopen(req, timeout=15)
            result = json.loads(resp.read().decode())

            if result.get('status') == 'OK':
                user_data = result.get('return', {})
                expire = user_data.get('expire', '')
                days_left = 0
                exp_str = 'Unknown'
                if expire:
                    try:
                        from datetime import datetime, timezone
                        if str(expire).isdigit():
                            exp_date = datetime.fromtimestamp(int(expire), tz=timezone.utc)
                        else:
                            expire_str = str(expire)
                            if expire_str.endswith('Z'):
                                expire_str = expire_str.replace('Z', '+00:00')
                            exp_date = datetime.fromisoformat(expire_str)
                            if exp_date.tzinfo is None:
                                exp_date = exp_date.replace(tzinfo=timezone.utc)
                        delta = exp_date - datetime.now(timezone.utc)
                        import math
                        days_left = max(0, math.ceil(delta.total_seconds() / 86400))
                        exp_str = exp_date.strftime('%Y-%m-%d')
                    except Exception:
                        exp_str = str(expire)
                return {
                    'username': self.username,
                    'type': user_data.get('package', 'unknown'),
                    'premium': bool(days_left > 0),
                    'expiration': exp_str,
                    'days_left': days_left,
                }
        except Exception:
            pass
        return {}


class Offcloud:
    """Offcloud debrid integration — https://offcloud.com/"""

    BASE_URL = 'https://offcloud.com/api'

    def __init__(self):
        self._load_from_file()

    def _load_from_file(self):
        _ensure_data_path()
        self.api_key = ''
        self.api_key = (get_addon().getSetting('oc_api_key') or '').strip()
        if not self.api_key:
            if os.path.exists(OC_TOKEN_FILE):
                try:
                    with open(OC_TOKEN_FILE, 'r') as f:
                        data = json.load(f)
                        self.api_key = data.get('api_key', '')
                except Exception:
                    pass

    def _save_to_file(self):
        _ensure_data_path()
        try:
            with open(OC_TOKEN_FILE, 'w') as f:
                json.dump({'api_key': self.api_key, 'created_at': time.time()}, f)
            _chmod_private(OC_TOKEN_FILE)
            addon = get_addon()
            addon.setSetting('oc_api_key', self.api_key)
            addon.setSetting('oc_auth_done', 'true')
        except Exception as e:
            xbmc.log(f'Offcloud: save to file failed: {e}', xbmc.LOGERROR)

    def is_authorized(self):
        return bool(self.api_key)

    def authorize(self):
        try:
            dlg = xbmcgui.Dialog()
            key = dlg.input(
                'Offcloud API Key  (offcloud.com/settings → Account → API key)',
                type=xbmcgui.INPUT_ALPHANUM,
            )
            if not key:
                return False
            key = key.strip()

            status, result = _get(f'{self.BASE_URL}/account/info', params={'key': key})

            if status == 200 and isinstance(result, dict) and not result.get('error'):
                self.api_key = key
                self._save_to_file()
                email = result.get('email') or result.get('user', {}).get('email', 'unknown')
                xbmcgui.Dialog().notification('Offcloud', f'Linked: {email}', xbmcgui.NOTIFICATION_INFO, 3000)
                return True

            if status == 200:
                self.api_key = key
                self._save_to_file()
                xbmcgui.Dialog().notification('Offcloud', 'API key saved', xbmcgui.NOTIFICATION_INFO)
                return True

            err = result.get('error') or result.get('message') or '' if isinstance(result, dict) else ''
            xbmcgui.Dialog().notification('Offcloud', f'Invalid API key ({err or status})', xbmcgui.NOTIFICATION_ERROR, 4000)
        except Exception as e:
            xbmcgui.Dialog().notification('Offcloud', f'Auth error: {e}', xbmcgui.NOTIFICATION_ERROR)
        return False

    def revoke(self):
        if os.path.exists(OC_TOKEN_FILE):
            try:
                os.remove(OC_TOKEN_FILE)
            except Exception:
                pass
        addon = get_addon()
        addon.setSetting('oc_api_key', '')
        addon.setSetting('oc_auth_done', 'false')
        self.api_key = ''
        xbmcgui.Dialog().notification('Offcloud', 'Account unlinked', xbmcgui.NOTIFICATION_INFO)

    def _normalize_hash(self, hash_or_magnet):
        if not hash_or_magnet:
            return ''
        h_str = str(hash_or_magnet).strip().lower()
        if h_str.startswith('magnet:'):
            m = re.search(r'btih:([a-fA-F0-9]{40})', h_str)
            if not m:
                m = re.search(r'btih:([a-fA-F0-9]{32})', h_str)
            if m:
                return m.group(1).lower()
        elif re.match(r'^[a-f0-9]{40}$', h_str) or re.match(r'^[a-f0-9]{32}$', h_str):
            return h_str
        return ''

    def check_cache(self, hashes):
        """Check which hashes are instantly available on Offcloud according to official API spec."""
        if not self.is_authorized() or not hashes:
            return {}

        cached = {}
        clean_hashes = [self._normalize_hash(h) for h in hashes if self._normalize_hash(h)]
        if not clean_hashes:
            return {}

        try:
            chunk = clean_hashes[:100]
            status, result = _post_json(
                f'{self.BASE_URL}/cache',
                params={'key': self.api_key},
                data={'hashes': chunk},
                timeout=5
            )
            if status == 200 and isinstance(result, dict):
                items = result.get('cachedItems') or []
                if isinstance(items, dict):
                    for h, is_cached in items.items():
                        if is_cached:
                            cached[str(h).lower()] = True
                elif isinstance(items, list):
                    for h in items:
                        cached[str(h).lower()] = True
        except Exception as e:
            xbmc.log(f'Offcloud cache check error: {e}', xbmc.LOGERROR)

        return cached

    def add_magnet(self, magnet, check_cache_first=True, allow_cloud=False):
        """Resolve magnet or URL according to Offcloud API specification."""
        if not self.is_authorized():
            return None

        # Try instant download URL generation first
        url = self._instant(magnet)
        if url:
            return url

        # Fast Cloud Fallback (2 quick polls / 4 seconds threshold)
        return self._fast_cloud_check(magnet)

    def _extract_url_from_response(self, response_dict, magnet=''):
        """Extract stream URL from Offcloud API answer structure (URL string or links list)."""
        if not isinstance(response_dict, dict):
            return None

        # Check standard Offcloud 'url' parameter from API docs
        direct_url = response_dict.get('url')
        if direct_url and isinstance(direct_url, str) and direct_url.startswith('http'):
            return direct_url

        # Check multi-file 'links' array parameter
        links = response_dict.get('links') or []
        if isinstance(links, list) and links:
            files = [{'path': unquote_plus(urlparse(link).path), 'link': link}
                     for link in links if isinstance(link, str) and link.startswith(('http://', 'https://'))]
            target = _select_torrent_file(files, magnet)
            return target.get('link') if target else None

        return None

    def _instant(self, url):
        """POST /instant — Submits URL/Magnet to Offcloud Instant endpoint."""
        try:
            status, result = _post(
                f'{self.BASE_URL}/instant',
                params={'key': self.api_key},
                data={'url': url},
                timeout=5
            )
            if status == 200 and isinstance(result, dict):
                if result.get('not_available') or result.get('error'):
                    return None

                extracted = self._extract_url_from_response(result, url)
                if extracted:
                    return extracted
        except Exception as e:
            xbmc.log(f'Offcloud /instant error: {e}', xbmc.LOGERROR)
        return None

    def _fast_cloud_check(self, url):
        """Submits to /cloud and polls POST /cloud/status per official API spec."""
        try:
            status, result = _post(
                f'{self.BASE_URL}/cloud',
                params={'key': self.api_key},
                data={'url': url},
                timeout=5
            )
            if not isinstance(result, dict):
                return None

            request_id = result.get('requestId')
            if not request_id:
                return None

            # Immediate ready check
            if result.get('status') == 'downloaded':
                extracted = self._extract_url_from_response(result, url)
                if extracted:
                    return extracted
                return self._explore_or_status(request_id, url)

            # Poll twice with 2-second interval (4 seconds threshold)
            for _ in range(2):
                xbmc.sleep(2000)
                status_result = self._cloud_status(request_id, url)
                if status_result:
                    return status_result

        except Exception as e:
            xbmc.log(f'Offcloud fast_cloud_check error: {e}', xbmc.LOGERROR)
        return None

    def _cloud_status(self, request_id, magnet=''):
        """POST /cloud/status with requestId per official Offcloud GitHub spec."""
        result = self.cloud_status_info(request_id)
        if isinstance(result, dict):
            status_str = result.get('status') or result.get('downloadStatus')
            if status_str == 'downloaded' or result.get('isCompleted'):
                extracted = self._extract_url_from_response(result, magnet)
                if extracted:
                    return extracted
                return self._explore_or_status(request_id, magnet)
        return None

    def cloud_status_info(self, request_id):
        """Return the raw status response for a queued cloud request."""
        try:
            status, result = _post(
                f'{self.BASE_URL}/cloud/status',
                params={'key': self.api_key},
                data={'requestId': request_id},
                timeout=4
            )
            if status == 200 and isinstance(result, dict):
                return result
        except Exception as e:
            xbmc.log(f'Offcloud cloud status error: {e}', xbmc.LOGERROR)
        return None

    def _explore_or_status(self, request_id, magnet=''):
        """GET /cloud/explore/[requestId] — Retrieves archive file list per official API spec."""
        links = self.cloud_explore(request_id)
        if links:
            return self._extract_url_from_response({'links': links}, magnet)
        return None

    def cloud_explore(self, request_id):
        """Return the raw file/link list for a completed cloud request."""
        try:
            status, result = _get(
                f'{self.BASE_URL}/cloud/explore/{request_id}',
                params={'key': self.api_key},
                timeout=4
            )
            if status == 200 and isinstance(result, list):
                return result
        except Exception as e:
            xbmc.log(f'Offcloud explore error: {e}', xbmc.LOGERROR)
        return None

    def unrestrict_link(self, link):
        if not self.is_authorized():
            return None
        return self._instant(link)

    def account_info(self):
        if not self.is_authorized():
            return {}
        try:
            status, result = _get(f'{self.BASE_URL}/account/info', params={'key': self.api_key}, timeout=5)
            if status == 200 and isinstance(result, dict):
                plan = result.get('plan') or result.get('planName') or ''
                email = result.get('email', '') or result.get('user', {}).get('email', 'unknown')
                is_premium = bool(result.get('is_premium') or result.get('isPremium') or result.get('isPremiumAccount'))
                premium_until = result.get('expiration_date') or result.get('planExpiryDate') or result.get('expiresOn') or ''
                days_left = 0
                if premium_until:
                    try:
                        from datetime import datetime, timezone
                        exp_date = None
                        if isinstance(premium_until, (int, float)) and premium_until > 0:
                            exp_date = datetime.fromtimestamp(premium_until, tz=timezone.utc)
                        elif isinstance(premium_until, str) and premium_until:
                            if ' ' in premium_until: # Handles 'YYYY-MM-DD HH:MM:SS'
                                premium_until = premium_until.replace(' ', 'T')
                            if premium_until.endswith('Z'):
                                premium_until = premium_until.replace('Z', '+00:00')
                            exp_date = datetime.fromisoformat(premium_until)

                        if exp_date:
                            delta = exp_date - datetime.now(timezone.utc)
                            days_left = max(0, delta.days)
                            exp_str = exp_date.strftime('%Y-%m-%d')
                    except Exception as e:
                        xbmc.log(f'COSMOS: Offcloud date parsing failed: {e}', xbmc.LOGWARNING)
                        exp_str = str(premium_until)[:10]
                return {
                    'username': email,
                    'email': email,
                    'type': plan or ('premium' if is_premium else 'free'),
                    'premium': is_premium,
                    'expiration': exp_str,
                    'days_left': days_left,
                }
        except Exception as e:
            xbmc.log(f'Offcloud account_info error: {e}', xbmc.LOGERROR)
        return {}


def get_debrid_services():
    """Get list of authorized and enabled debrid services in priority order"""
    addon = get_addon()
    services = []

    # Optional providers must be isolated. A malformed token, expired
    # credential, or temporary API failure in one service must not prevent a
    # different authorized service from being used.
    providers = (
        ('Real-Debrid', 'rd_enabled', RealDebrid),
        ('AllDebrid', 'ad_enabled', AllDebrid),
        ('Premiumize', 'pm_enabled', Premiumize),
        ('Torbox', 'tb_enabled', Torbox),
        ('LinkSnappy', 'ls_enabled', LinkSnappy),
        ('Offcloud', 'oc_enabled', Offcloud),
    )
    for name, setting_id, service_type in providers:
        try:
            service = service_type()
            if addon.getSetting(setting_id) == 'false':
                continue
            if service.is_authorized():
                services.append((name, service))
        except Exception as exc:
            xbmc.log(
                f'COSMOS [DEBRID] {name} authorization check failed: {exc}',
                xbmc.LOGWARNING,
            )

    return services


def resolve_with_debrid(link_or_magnet, is_magnet=False):
    """Try to resolve link through available debrid services"""
    try:
        easynews_host = (urlparse(link_or_magnet or '').hostname or '').lower().rstrip('.')
    except ValueError:
        easynews_host = ''
    if easynews_host == 'easynews.com' or easynews_host.endswith('.easynews.com'):
        return link_or_magnet, 'Easynews'
    services = get_debrid_services()

    for name, service in services:
        try:
            if is_magnet:
                result = service.add_magnet(link_or_magnet, check_cache_first=True)
            else:
                result = service.unrestrict_link(link_or_magnet)
            
            if result:
                return result, name
        except Exception as e:
            xbmc.log(f'COSMOS [DEBRID] {name!r} EXCEPTION: {e}', xbmc.LOGERROR)
            continue

    return None, None


# ── Compatibility aliases ──────────────────────────────────────────────────

def get_active_services():
    return get_debrid_services()


def check_cache_all(hashes):
    """Check all hashes against all authorized debrid services concurrently using ThreadPoolExecutor."""
    cached = set()
    services = get_debrid_services()

    if not hashes or not services:
        return cached

    def _check_service(service_tuple):
        name, service = service_tuple
        svc_cached = set()
        try:
            if hasattr(service, 'check_cache'):
                res = service.check_cache(hashes)
                if isinstance(res, (set, list)):
                    svc_cached.update(
                        str(h).strip().lower() for h in res if h
                    )
                elif isinstance(res, dict):
                    for h, is_cached in res.items():
                        if is_cached:
                            svc_cached.add(str(h).strip().lower())
        except Exception as e:
            xbmc.log(f'COSMOS [DEBRID] check_cache_all concurrently {name} FAILED: {e}', xbmc.LOGWARNING)
        return svc_cached

    with concurrent.futures.ThreadPoolExecutor(
            max_workers=max(1, min(len(services), 8))) as executor:
        results = executor.map(_check_service, services)
        for res in results:
            cached.update(res)

    return cached


def probe_realtime_cache(results, limit=15):
    try:
        rd = RealDebrid()
    except Exception:
        return results
    if not rd.is_authorized():
        return results

    probed = 0
    for r in results:
        if probed >= limit:
            break
        if r.get('cached') or not r.get('magnet'):
            continue
        is_cached, torrent_id = rd.probe_cache_realtime(r['magnet'])
        probed += 1
        if is_cached:
            r['cached'] = True
            r['rd_torrent_id'] = torrent_id

    return results


def resolve_magnet(magnet):
    return resolve_with_debrid(magnet, is_magnet=True)


def get_debrid_account_info():
    """Return isolated status and expiry information for each provider."""
    addon = get_addon()
    providers = (
        ('Real-Debrid', 'rd_enabled', RealDebrid),
        ('AllDebrid', 'ad_enabled', AllDebrid),
        ('Premiumize', 'pm_enabled', Premiumize),
        ('Torbox', 'tb_enabled', Torbox),
        ('LinkSnappy', 'ls_enabled', LinkSnappy),
        ('Offcloud', 'oc_enabled', Offcloud),
    )
    accounts = []
    for name, setting_id, service_type in providers:
        record = {
            'name': name, 'enabled': True, 'configured': False,
            'authorized': False, 'status': 'Not linked',
            'days_left': None, 'expiration': '',
        }
        try:
            if (addon.getSetting(setting_id) or 'true').strip().lower() == 'false':
                record['enabled'] = False
                record['status'] = 'Disabled'
                accounts.append(record)
                continue
            service = service_type()
            authorized = bool(service.is_authorized())
            record['authorized'] = authorized
            record['configured'] = authorized
            if not authorized:
                accounts.append(record)
                continue
            info = service.account_info() or {}
            if not isinstance(info, dict) or not info:
                record['status'] = 'Check failed'
                record['error'] = 'Account endpoint returned no usable data'
                accounts.append(record)
                continue
            if isinstance(info, dict):
                for key in ('username', 'email', 'type', 'premium', 'expiration', 'days_left'):
                    if key in info:
                        record[key] = info.get(key)
            try:
                record['days_left'] = int(record['days_left']) if record['days_left'] is not None else None
            except (TypeError, ValueError, OverflowError):
                record['days_left'] = None
            if isinstance(info, dict) and info.get('error'):
                record['status'] = 'Check failed'
                record['error'] = str(info.get('error'))
            elif record['days_left'] is not None and record['days_left'] <= 0:
                record['status'] = 'Expired'
            else:
                record['status'] = 'Active'
        except Exception as exc:
            record['status'] = 'Check failed'
            record['error'] = str(exc)
            xbmc.log(f'COSMOS debrid account status failed for {name}: {exc}', xbmc.LOGWARNING)
        accounts.append(record)
    return accounts


def get_all_account_info():
    accounts = []

    # Easynews Account Info
    try:
        addon = get_addon()
        easynews_user = addon.getSetting('easynews_username')
        easynews_enabled = addon.getSetting('easynews_enabled') != 'false'
        
        if easynews_user:
            from resources.lib import easynews # Import here to avoid circular dependency if easynews imports debrid
            is_active = easynews.test_login() # Perform an actual login test
            
            if is_active:
                accounts.append({
                    'name': 'Easynews',
                    'configured': True,
                    'username': easynews_user,
                    'type': 'Usenet',
                    'premium': True,
                    'expires': 'Active', # This could be more dynamic if EasyNews API provided it
                    'days_left': 30, # This could be more dynamic if EasyNews API provided it
                })
            else:
                accounts.append({
                    'name': 'Easynews',
                    'configured': True,
                    'username': easynews_user,
                    'type': 'Usenet',
                    'premium': False,
                    'expires': 'Login Failed',
                    'days_left': 0,
                    'error': 'Login failed - check credentials',
                })
        else:
            accounts.append({'name': 'Easynews', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'Easynews', 'configured': True, 'error': str(e)})

    # Real-Debrid
    try:
        rd = RealDebrid()
        if rd.token:
            info = rd.account_info()
            if info:
                accounts.append({
                    'name': 'Real-Debrid',
                    'configured': True,
                    'username': info.get('username', ''),
                    'email': info.get('email', ''),
                    'type': info.get('type', 'unknown'),
                    'premium': info.get('premium', False),
                    'expires': info.get('expiration', 'Unknown'),
                    'days_left': info.get('days_left', 0),
                    'points': info.get('points', 0),
                })
            else:
                accounts.append({'name': 'Real-Debrid', 'configured': True, 'error': 'Could not fetch account info - try re-authorizing'})
        else:
            accounts.append({'name': 'Real-Debrid', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'Real-Debrid', 'configured': True, 'error': str(e)})
    
    # AllDebrid
    try:
        ad = AllDebrid()
        if ad.token:
            info = ad.account_info()
            if info:
                accounts.append({
                    'name': 'AllDebrid',
                    'configured': True,
                    'username': info.get('username', ''),
                    'email': info.get('email', ''),
                    'type': info.get('type', 'unknown'),
                    'premium': info.get('premium', False),
                    'expires': info.get('expiration', 'Unknown'),
                    'days_left': info.get('days_left', 0),
                })
            else:
                accounts.append({'name': 'AllDebrid', 'configured': True, 'error': 'Could not fetch account info - try re-authorizing'})
        else:
            accounts.append({'name': 'AllDebrid', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'AllDebrid', 'configured': True, 'error': str(e)})
    
    # Premiumize
    try:
        pm = Premiumize()
        if pm.token:
            info = pm.account_info()
            if info:
                accounts.append({
                    'name': 'Premiumize',
                    'configured': True,
                    'username': info.get('username', ''),
                    'type': info.get('type', 'unknown'),
                    'premium': info.get('premium', False),
                    'expires': info.get('expiration', 'Unknown'),
                    'days_left': info.get('days_left', 0),
                })
            else:
                accounts.append({'name': 'Premiumize', 'configured': True, 'error': 'Could not fetch account info - try re-authorizing'})
        else:
            accounts.append({'name': 'Premiumize', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'Premiumize', 'configured': True, 'error': str(e)})
    
    # Torbox
    try:
        tb = Torbox()
        if tb.token:
            info = tb.account_info()
            if info:
                accounts.append({
                    'name': 'Torbox',
                    'configured': True,
                    'username': info.get('username', ''),
                    'email': info.get('email', ''),
                    'type': info.get('type', 'unknown'),
                    'premium': info.get('premium', False),
                    'expires': info.get('expiration', 'Unknown'),
                    'days_left': info.get('days_left', 0),
                })
            else:
                accounts.append({'name': 'Torbox', 'configured': True, 'error': 'Could not fetch account info - try re-authorizing'})
        else:
            accounts.append({'name': 'Torbox', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'Torbox', 'configured': True, 'error': str(e)})
    
    # LinkSnappy
    try:
        ls = LinkSnappy()
        if ls.is_authorized():
            info = ls.account_info()
            if info:
                accounts.append({
                    'name': 'LinkSnappy',
                    'configured': True,
                    'username': info.get('username', ''),
                    'type': info.get('type', 'unknown'),
                    'premium': info.get('premium', False),
                    'expires': info.get('expiration', 'Unknown'),
                    'days_left': info.get('days_left', 0),
                })
            else:
                accounts.append({'name': 'LinkSnappy', 'configured': True, 'error': 'Could not fetch account info - try re-logging in'})
        else:
            accounts.append({'name': 'LinkSnappy', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'LinkSnappy', 'configured': True, 'error': str(e)})

    # Offcloud
    try:
        oc = Offcloud()
        if oc.is_authorized():
            info = oc.account_info()
            if info:
                accounts.append({
                    'name': 'Offcloud',
                    'configured': True,
                    'username': info.get('username', ''),
                    'email': info.get('email', ''),
                    'type': info.get('type', 'unknown'),
                    'premium': info.get('premium', False),
                    'expires': info.get('expiration', 'Unknown'),
                    'days_left': info.get('days_left', 0),
                })
            else:
                accounts.append({'name': 'Offcloud', 'configured': True, 'error': 'Could not fetch account info - try re-authorizing'})
        else:
            accounts.append({'name': 'Offcloud', 'configured': False})
    except Exception as e:
        accounts.append({'name': 'Offcloud', 'configured': True, 'error': str(e)})

    return accounts


# ══════════════════════════════════════════════════════════════════════════════
# ██████  DEBRID CLOUD BROWSER  ████████████████████████████████████████████████
# ══════════════════════════════════════════════════════════════════════════════

def get_cloud_services():
    """Return authorized cloud-capable services in stable priority order.

    Authorization can involve token refreshes and provider API calls. Keep
    each provider independent so one malformed/expired credential or transient
    outage cannot hide every other cloud service from the menu.
    """
    addon = get_addon()
    services = []
    providers = (
        ('Real-Debrid', 'rd_enabled', 'rd', RealDebrid),
        ('Premiumize', 'pm_enabled', 'pm', Premiumize),
        ('Torbox', 'tb_enabled', 'tb', Torbox),
        ('AllDebrid', 'ad_enabled', 'ad', AllDebrid),
        # LinkSnappy is resolver-only: it has no official cloud
        # library/torrent listing endpoint, but remains available for
        # immediate link resolution from the Cloud menu.
        ('LinkSnappy', 'ls_enabled', 'ls', LinkSnappy),
        ('Offcloud', 'oc_enabled', 'oc', Offcloud),
    )

    for name, setting_id, code, service_type in providers:
        try:
            if addon.getSetting(setting_id) == 'false':
                continue
            service = service_type()
            if service.is_authorized():
                services.append((name, service, code))
        except Exception as exc:
            xbmc.log(
                f'COSMOS [DEBRID] {name} cloud authorization check failed: {exc}',
                xbmc.LOGWARNING,
            )

    return services


def rd_get_torrents():
    rd = RealDebrid()
    if not rd.is_authorized():
        return []
    try:
        status, result = _get(f"{rd.BASE_URL}/torrents", headers=rd._auth_headers())
        if status == 200 and isinstance(result, list):
            items = []
            for item in result:
                bytes_size = item.get('bytes', 0)
                if bytes_size > 1073741824:
                    size_str = f"{bytes_size / 1073741824:.2f} GB"
                elif bytes_size > 1048576:
                    size_str = f"{bytes_size / 1048576:.1f} MB"
                else:
                    size_str = f"{bytes_size / 1024:.0f} KB"
                items.append({
                    'id': item.get('id', ''),
                    'name': item.get('filename', 'Unknown'),
                    'status': item.get('status', ''),
                    'progress': item.get('progress', 0),
                    'size': size_str,
                    'bytes': bytes_size,
                    'service': 'rd'
                })
            return items
    except Exception:
        pass
    return []


def rd_get_torrent_files(torrent_id):
    rd = RealDebrid()
    if not rd.is_authorized():
        return []
    try:
        status, result = _get(f"{rd.BASE_URL}/torrents/info/{torrent_id}", headers=rd._auth_headers())
        if status == 200 and isinstance(result, dict):
            files = []
            links = result.get('links', [])
            file_list = [f for f in result.get('files', []) if f.get('selected') == 1]
            for i, link in enumerate(links):
                filename = f"File {i+1}"
                filesize = 0
                if i < len(file_list):
                    filename = file_list[i].get('path', '').split('/')[-1] or filename
                    filesize = file_list[i].get('bytes', 0)
                if filesize > 1073741824:
                    size_str = f"{filesize / 1073741824:.2f} GB"
                elif filesize > 1048576:
                    size_str = f"{filesize / 1048576:.1f} MB"
                else:
                    size_str = f"{filesize / 1024:.0f} KB" if filesize > 0 else ""
                files.append({
                    'name': filename,
                    'link': link,
                    'size': size_str,
                    'bytes': filesize,
                    'service': 'rd'
                })
            return files
    except Exception:
        pass
    return []


def rd_get_downloads():
    rd = RealDebrid()
    if not rd.is_authorized():
        return []
    try:
        status, result = _get(f"{rd.BASE_URL}/downloads", params={"limit": 50}, headers=rd._auth_headers())
        if status == 200 and isinstance(result, list):
            items = []
            for item in result:
                filename = item.get('filename', 'Unknown')
                filesize = item.get('filesize', 0)
                if filesize > 1073741824:
                    size_str = f"{filesize / 1073741824:.2f} GB"
                elif filesize > 1048576:
                    size_str = f"{filesize / 1048576:.1f} MB"
                else:
                    size_str = f"{filesize / 1024:.0f} KB"
                video_exts = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm']
                is_video = any(filename.lower().endswith(ext) for ext in video_exts)
                items.append({
                    'name': filename,
                    'link': item.get('download', ''),
                    'size': size_str,
                    'bytes': filesize,
                    'date': item.get('generated', '')[:10],
                    'is_video': is_video,
                    'service': 'rd'
                })
            return items
    except Exception:
        pass
    return []


def pm_get_cloud_files(folder_id=None):
    pm = Premiumize()
    if not pm.is_authorized():
        return []
    try:
        params = {'id': folder_id} if folder_id else {}
        status, result = _get(f"{pm.BASE_URL}/folder/list", params=params, headers={"Authorization": f"Bearer {pm.token}"})
        if status == 200 and isinstance(result, dict) and result.get('status') == 'success':
            items = []
            for item in result.get('content', []):
                name = item.get('name', 'Unknown')
                size = item.get('size', 0)
                if size > 1073741824:
                    size_str = f"{size / 1073741824:.2f} GB"
                elif size > 1048576:
                    size_str = f"{size / 1048576:.1f} MB"
                else:
                    size_str = f"{size / 1024:.0f} KB" if size > 0 else ""
                video_exts = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm']
                is_video = any(name.lower().endswith(ext) for ext in video_exts)
                items.append({
                    'id': item.get('id', ''),
                    'name': name,
                    'type': item.get('type', ''),
                    'link': item.get('link', ''),
                    'size': size_str,
                    'bytes': size,
                    'is_video': is_video,
                    'service': 'pm'
                })
            return items
    except Exception:
        pass
    return []


def pm_get_transfers():
    pm = Premiumize()
    if not pm.is_authorized():
        return []
    try:
        status, result = _get(f"{pm.BASE_URL}/transfer/list", headers={"Authorization": f"Bearer {pm.token}"})
        if status == 200 and isinstance(result, dict) and result.get('status') == 'success':
            items = []
            for item in result.get('transfers', []):
                progress = item.get('progress', 0)
                items.append({
                    'id': item.get('folder_id', '') or item.get('file_id', ''),
                    'name': item.get('name', 'Unknown'),
                    'status': item.get('status', ''),
                    'progress': max(0, min(100, int(float(progress or 0) * 100))),
                    'service': 'pm'
                })
            return items
    except Exception:
        pass
    return []


def tb_get_torrents():
    tb = Torbox()
    if not tb.is_authorized():
        return []
    try:
        status, result = _get(f"{tb.BASE_URL}/torrents/mylist", headers=tb._auth_headers())
        if status == 200 and isinstance(result, dict) and result.get('success'):
            items = []
            data = result.get('data', [])
            if isinstance(data, dict):
                data = [data]
            for item in data:
                size = item.get('size', 0)
                if size > 1073741824:
                    size_str = f"{size / 1073741824:.2f} GB"
                elif size > 1048576:
                    size_str = f"{size / 1048576:.1f} MB"
                else:
                    size_str = f"{size / 1024:.0f} KB"
                progress = item.get('progress', 0)
                items.append({
                    'id': item.get('id', ''),
                    'name': item.get('name', 'Unknown'),
                    'status': item.get('download_state', ''),
                    'progress': int(progress * 100) if progress <= 1 else int(progress),
                    'size': size_str,
                    'bytes': size,
                    'service': 'tb'
                })
            return items
    except Exception:
        pass
    return []


def tb_get_torrent_files(torrent_id):
    tb = Torbox()
    if not tb.is_authorized():
        return []
    try:
        status, result = _get(f"{tb.BASE_URL}/torrents/mylist", params={"id": torrent_id}, headers=tb._auth_headers())
        if status == 200 and isinstance(result, dict) and result.get('success'):
            files = []
            data = result.get('data', {})
            if isinstance(data, list) and data:
                data = data[0]
            for f in data.get('files', []):
                file_id = f.get('id', 0)
                name = f.get('name', '').split('/')[-1] or f"File {file_id}"
                size = f.get('size', 0)
                if size > 1073741824:
                    size_str = f"{size / 1073741824:.2f} GB"
                elif size > 1048576:
                    size_str = f"{size / 1048576:.1f} MB"
                else:
                    size_str = f"{size / 1024:.0f} KB"
                video_exts = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm']
                is_video = any(name.lower().endswith(ext) for ext in video_exts)
                files.append({
                    'id': file_id,
                    'torrent_id': torrent_id,
                    'name': name,
                    'size': size_str,
                    'bytes': size,
                    'is_video': is_video,
                    'service': 'tb'
                })
            return files
    except Exception:
        pass
    return []


def tb_get_download_link(torrent_id, file_id):
    tb = Torbox()
    if not tb.is_authorized():
        return None
    try:
        status, result = _get(f"{tb.BASE_URL}/torrents/requestdl", params={"token": tb.token, "torrent_id": torrent_id, "file_id": file_id})
        if status == 200 and isinstance(result, dict) and result.get('success'):
            return result.get('data')
    except Exception:
        pass
    return None


def ad_get_magnets():
    ad = AllDebrid()
    if not ad.is_authorized():
        return []
    try:
        items = []
        for item in ad.magnet_status():
            size = item.get('size', 0)
            if size > 1073741824:
                size_str = f"{size / 1073741824:.2f} GB"
            elif size > 1048576:
                size_str = f"{size / 1048576:.1f} MB"
            else:
                size_str = f"{size / 1024:.0f} KB"
            items.append({
                'id': item.get('id', ''),
                'name': item.get('filename', 'Unknown'),
                'status': item.get('status', ''),
                'size': size_str,
                'bytes': size,
                'service': 'ad'
            })
        return items
    except Exception:
        pass
    return []


def ad_get_magnet_files(magnet_id):
    ad = AllDebrid()
    if not ad.is_authorized():
        return []
    try:
        files = []
        links = ad.magnet_files(magnet_id)
        for link_info in links:
            filename = link_info.get('filename', 'Unknown')
            size = link_info.get('size', 0)
            if size > 1073741824:
                size_str = f"{size / 1073741824:.2f} GB"
            elif size > 1048576:
                size_str = f"{size / 1048576:.1f} MB"
            else:
                size_str = f"{size / 1024:.0f} KB"
            video_exts = ['.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm']
            is_video = any(filename.lower().endswith(ext) for ext in video_exts)
            files.append({
                'name': filename,
                'link': link_info.get('link', ''),
                'size': size_str,
                'bytes': size,
                'is_video': is_video,
                'service': 'ad'
            })
        return files
    except Exception:
        pass
    return []


def _load_oc_cloud_items():
    _ensure_data_path()
    if not os.path.exists(OC_CLOUD_INDEX_FILE):
        return []
    try:
        with open(OC_CLOUD_INDEX_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save_oc_cloud_items(items):
    _ensure_data_path()
    try:
        with open(OC_CLOUD_INDEX_FILE, 'w', encoding='utf-8') as f:
            json.dump(items[-100:], f)
    except OSError as e:
        xbmc.log(f'Offcloud cloud index save failed: {e}', xbmc.LOGWARNING)


def oc_add_cloud_item(url):
    """Queue a URL or magnet in Offcloud and remember its request locally.

    Offcloud exposes request status and file exploration by request ID, but it
    does not provide a general cloud-list endpoint. The local index preserves
    requests made through this add-on so they remain browsable.
    """
    oc = Offcloud()
    if not oc.is_authorized() or not url:
        return None
    try:
        status, result = _post(
            f'{oc.BASE_URL}/cloud',
            params={'key': oc.api_key},
            data={'url': url},
            timeout=10,
        )
        if status != 200 or not isinstance(result, dict):
            return None

        request_id = str(result.get('requestId') or result.get('request_id') or '')
        direct = oc._extract_url_from_response(result)
        if not request_id and not direct:
            return None

        item_id = request_id or f'instant-{int(time.time() * 1000)}'
        item = {
            'id': item_id,
            'name': result.get('name') or url.rsplit('/', 1)[-1] or 'Offcloud item',
            'source': url,
            'status': result.get('status') or ('downloaded' if direct else 'queued'),
            'link': direct or '',
            'created_at': int(time.time()),
            'service': 'oc',
        }
        items = [it for it in _load_oc_cloud_items() if str(it.get('id')) != item_id]
        items.append(item)
        _save_oc_cloud_items(items)
        return item
    except Exception as e:
        xbmc.log(f'Offcloud cloud add error: {e}', xbmc.LOGERROR)
        return None


def oc_get_cloud_items():
    """Return locally indexed Offcloud requests with refreshed statuses."""
    oc = Offcloud()
    if not oc.is_authorized():
        return []

    items = _load_oc_cloud_items()
    changed = False
    for item in items:
        item_id = str(item.get('id') or '')
        if not item_id or item_id.startswith('instant-') or item.get('link'):
            continue
        try:
            info = oc.cloud_status_info(item_id)
            if not isinstance(info, dict):
                continue
            new_status = info.get('status') or info.get('downloadStatus')
            if new_status and new_status != item.get('status'):
                item['status'] = new_status
                changed = True
            direct = oc._extract_url_from_response(info)
            if direct and direct != item.get('link'):
                item['link'] = direct
                changed = True
        except Exception as e:
            xbmc.log(f'Offcloud cloud status refresh failed: {e}', xbmc.LOGDEBUG)
    if changed:
        _save_oc_cloud_items(items)
    return items


def oc_get_cloud_files(request_id):
    """Explore an indexed Offcloud request and return playable file rows."""
    request_id = str(request_id or '')
    items = _load_oc_cloud_items()
    item = next((it for it in items if str(it.get('id')) == request_id), None)
    if not item:
        return []

    direct = item.get('link') or ''
    if direct:
        return [{
            'name': item.get('name') or 'Offcloud file',
            'link': direct,
            'size': '',
            'is_video': True,
            'service': 'oc',
        }]

    oc = Offcloud()
    if not oc.is_authorized():
        return []
    info = oc.cloud_status_info(request_id)
    if not isinstance(info, dict):
        return []
    status = info.get('status') or info.get('downloadStatus') or ''
    if status:
        item['status'] = status
    if status != 'downloaded' and not info.get('isCompleted'):
        _save_oc_cloud_items(items)
        return []

    links = oc.cloud_explore(request_id) or []
    files = []
    for entry in links:
        if isinstance(entry, dict):
            link = entry.get('url') or entry.get('link') or ''
            name = entry.get('name') or link.rsplit('/', 1)[-1] or 'Offcloud file'
        else:
            link = str(entry or '')
            name = link.rsplit('/', 1)[-1] or 'Offcloud file'
        if link.startswith('http'):
            files.append({
                'name': name,
                'link': link,
                'size': '',
                'is_video': name.lower().endswith(
                    ('.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm', '.ts')
                ),
                'service': 'oc',
            })
    if files:
        item['link'] = files[0]['link']
    _save_oc_cloud_items(items)
    return files


def oc_forget_cloud_item(item_id):
    """Remove a locally indexed Offcloud request from this add-on."""
    item_id = str(item_id or '')
    items = _load_oc_cloud_items()
    remaining = [it for it in items if str(it.get('id')) != item_id]
    if len(remaining) == len(items):
        return False
    _save_oc_cloud_items(remaining)
    return True


def delete_cloud_item(service, item_id, item_type='file'):
    try:
        if service == 'rd':
            rd = RealDebrid()
            if rd.is_authorized():
                status, _ = _http(f"{rd.BASE_URL}/torrents/delete/{item_id}", method='DELETE', headers=rd._auth_headers())
                return status in (200, 204)
        
        elif service == 'pm':
            pm = Premiumize()
            if pm.is_authorized():
                endpoint = 'folder/delete' if item_type == 'folder' else 'item/delete'
                status, result = _post(f"{pm.BASE_URL}/{endpoint}", data={"id": item_id}, headers={"Authorization": f"Bearer {pm.token}"})
                return status == 200 and isinstance(result, dict) and result.get('status') == 'success'
        
        elif service == 'tb':
            tb = Torbox()
            if tb.is_authorized():
                status, result = _post_json(f"{tb.BASE_URL}/torrents/controltorrent", data={"torrent_id": item_id, "operation": "delete"}, headers=tb._auth_headers())
                return isinstance(result, dict) and result.get('success')
        
        elif service == 'ad':
            ad = AllDebrid()
            if ad.is_authorized():
                status, result = _post(f"{ad.BASE_URL}/magnet/delete", data={"id": item_id}, headers=ad._auth_headers())
                return isinstance(result, dict) and result.get('status') == 'success'

        elif service == 'oc':
            # Offcloud request IDs can be explored but are not exposed through
            # a documented delete endpoint. Remove the local browser entry.
            return oc_forget_cloud_item(item_id)
    except Exception:
        pass
    return False
