# -*- coding: utf-8 -*-
"""
Resume-point tracker for C.O.S.M.O.S playback.

This addon and code was created by Zeus768 for Cosmos.
Author: Zeus768

Whenever a link is played the plugin process spawns a ``_Tracker`` thread
that subclasses ``xbmc.Player``. It samples the current playback time
every few seconds and persists it — keyed by a stable logical id built
from (tmdb, content, season, episode) — to ``resume.json``.

Resumption is then offered as a per-link context-menu entry that re-plays
the same payload with ``resume=1``; the tracker seeks to the stored
offset once playback starts.
"""
import hashlib
import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcvfs

from . import trakt as _trakt
from . import simkl as _simkl
from . import punchplay as _punchplay
from . import watched as _watched
from . import opensubtitles as _opensubtitles

ADDON_ID = 'plugin.video.cosmos'


PROFILE_DIR = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/')
RESUME_FILE = os.path.join(PROFILE_DIR, 'resume.json')
SAMPLE_INTERVAL = 5
MIN_SAVE_SECONDS = 60            # ignore anything shorter than this
FINISHED_RATIO = 0.85            # legacy default; use get_finished_ratio() below
NINEANIME_SOURCE = '9anime'


def _selected_setting_value(setting_id, values, default_index=0):
    """Return a value from a legacy Kodi ``select`` setting.

    Kodi stores the selected option as its zero-based index.  A few older
    profiles can retain the literal value instead, so accept either form.
    """
    try:
        raw = xbmcaddon.Addon(ADDON_ID).getSetting(setting_id)
    except Exception:
        raw = ''
    raw = str(raw or '').strip()
    try:
        index = int(raw)
        if 0 <= index < len(values):
            return values[index]
    except (TypeError, ValueError):
        pass
    for value in values:
        if raw.lower() == str(value).lower():
            return value
    return values[default_index]


def get_finished_ratio():
    """Return the configured watched-completion threshold as a ratio."""
    value = _selected_setting_value(
        'watched_completion_percentage',
        (50, 60, 70, 80, 85, 90, 95, 100),
        default_index=4,
    )
    try:
        return max(0.01, min(1.0, float(value) / 100.0))
    except (TypeError, ValueError):
        return FINISHED_RATIO


def _refresh_container():
    """Refresh the active Kodi container after watched state changes."""
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception as e:
        xbmc.log(f'COSMOS resume: container refresh failed: {e}', xbmc.LOGDEBUG)


def get_scrobble_minimum_seconds():
    """Return the minimum playback position required for scrobbling."""
    value = _selected_setting_value(
        'scrobble_minimum_playback_time',
        (0, 30, 60, 120, 300, 600),
        default_index=0,
    )
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


def get_resume_prompt_timeout_seconds():
    """Return resume prompt timeout; -1 means the prompt is disabled."""
    value = _selected_setting_value(
        'resume_prompt_timeout',
        (-1, 5, 10, 15, 30, 0),
        default_index=0,
    )
    try:
        return int(value)
    except (TypeError, ValueError):
        return -1


def _tracking_content(meta):
    """Return the playable media type used by resume and watched tracking.

    Older menu/download payloads identify a TV episode as ``tvshow`` while
    carrying season and episode numbers. Treat those rows as episodes so the
    completion threshold writes the episode watched marker and uses the
    episode duration fallback.
    """
    meta = meta or {}
    content = str(meta.get('content') or '').strip().lower()
    season = str(meta.get('season') or '').strip()
    episode = str(meta.get('episode') or '').strip()
    if content in ('tv', 'tvshow', 'series', 'episode'):
        if content == 'episode' or (season and episode):
            return 'episode'
    return content or 'movie'


def _is_direct_link_meta(meta):
    """Return whether playback metadata represents a direct/non-debrid link."""
    label = str((meta or {}).get('label') or '').strip().lower()
    return (
        'non debrid' in label
        or 'non-debrid' in label
        or '[direct]' in label
        or 'debrid' not in label
    )


def autoplay_next_episode_enabled():
    try:
        value = xbmcaddon.Addon(ADDON_ID).getSetting('autoplay_next_episode')
        return str(value or '').strip().lower() in ('true', '1', 'yes')
    except Exception:
        return False


def _safe_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError, OverflowError):
        return default


def _ensure():
    if not os.path.isdir(PROFILE_DIR):
        try:
            os.makedirs(PROFILE_DIR)
        except OSError:
            pass


def key_for(tmdb='', content='movie', season='', episode='', label='', url=''):
    """Stable logical key independent of resolved stream URL and source label."""
    raw = '|'.join(str(x or '') for x in (tmdb, content, season, episode))
    return hashlib.md5(raw.encode('utf-8', errors='ignore')).hexdigest()


def key_for_local(path):
    """Stable resume key for locally downloaded files — based on basename
    so the same file can be recognised even if moved between folders."""
    import os as _os
    base = _os.path.basename(path or '')
    raw = f'local|{base}'
    return hashlib.md5(raw.encode('utf-8', errors='ignore')).hexdigest()


def is_nineanime(meta):
    """Return whether metadata belongs to an actual 9Anime playback.

    9Anime uses a synthetic ``tmdb`` value because its catalog is separate
    from TMDB.  Keep that legacy shape recognised while preferring the
    explicit provider marker added to new resume rows.
    """
    if not isinstance(meta, dict):
        return False
    source = str(meta.get('source') or meta.get('provider') or '').strip().lower()
    if source in (NINEANIME_SOURCE, '9anime.tech'):
        return True
    return str(meta.get('tmdb') or '').strip().lower().startswith('9anime:')


def _load():
    _ensure()
    if not os.path.isfile(RESUME_FILE):
        return {}
    try:
        with open(RESUME_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp)
            if not isinstance(data, dict):
                return {}
            return {
                key: value for key, value in data.items()
                if isinstance(value, dict) and not is_nineanime(value)
            }
    except (ValueError, OSError):
        return {}


def _save(data):
    _ensure()
    data = {
        key: value for key, value in (data or {}).items()
        if isinstance(value, dict) and not is_nineanime(value)
    }
    try:
        with open(RESUME_FILE, 'w', encoding='utf-8') as fp:
            json.dump(data, fp)
    except OSError as e:
        xbmc.log(f'COSMOS resume: save failed: {e}', xbmc.LOGWARNING)
    try:
        from . import sync as _sync
        _sync.maybe_autosync()
    except Exception:
        pass


def get(key):
    """Return (position, duration) or None."""
    d = _load().get(key)
    if not d:
        return None
    pos = _safe_float(d.get('pos', 0))
    dur = _safe_float(d.get('dur', 0))
    if pos < MIN_SAVE_SECONDS:
        return None
    return pos, dur


def put(key, pos, dur, meta=None):
    data = _load()
    pos = _safe_float(pos)
    if pos is None or pos < MIN_SAVE_SECONDS:
        return
    
    meta = meta or {}
    tracking_content = _tracking_content(meta)

    # 9Anime is deliberately excluded from Continue Watching.  Remove any
    # legacy row as soon as its old tracker writes again, and reject all new
    # 9Anime metadata regardless of whether it came from a menu or playback.
    if is_nineanime(meta):
        if data.pop(key, None) is not None:
            _save(data)
        return
    
    # Sanitize bloated pack durations (e.g. > 5 hours) or missing durations before saving
    dur = _safe_float(dur)
    if dur <= 0 or dur > 18000:
        tmdb_id = meta.get('tmdb')
        content = tracking_content
        season = meta.get('season')
        episode = meta.get('episode')
        runtime_mins = 0
        try:
            from . import tmdb as tmdb_mod
            if tmdb_id:
                if content == 'movie':
                    m_meta = tmdb_mod.get_metadata(tmdb_id, 'movie')
                    runtime_mins = m_meta.get('runtime', 0) or 0
                elif content in ('episode', 'tvshow') and season and episode:
                    try:
                        ep_meta = tmdb_mod.get_episode_meta(tmdb_id, int(season), int(episode))
                        runtime_mins = ep_meta.get('runtime', 0) or 0
                    except Exception:
                        eps = tmdb_mod.get_tv_episodes(tmdb_id, int(season))
                        for e in (eps or []):
                            if str(e.get('number')) == str(episode):
                                runtime_mins = e.get('runtime', 0) or 0
                                break
        except Exception:
            pass

        if runtime_mins > 0:
            dur = float(runtime_mins * 60)
        else:
            dur = 1440.0 if content == 'episode' else 7200.0

    threshold_reached = False
    if dur and pos / max(dur, 1) >= get_finished_ratio():
        data.pop(key, None)
        if meta:
            try:
                from . import watched as _watched
                if tracking_content == 'episode':
                    _watched.mark_watched(
                        meta.get('tmdb'), meta.get('season'), meta.get('episode'))
                elif tracking_content == 'movie':
                    _watched.mark_movie_watched(meta.get('tmdb'))
                threshold_reached = tracking_content in ('episode', 'movie') and bool(meta.get('tmdb'))
                xbmc.log(
                    f'COSMOS resume: local watched threshold reached '
                    f'content={tracking_content} tmdb={meta.get("tmdb")!r} '
                    f'season={meta.get("season")!r} episode={meta.get("episode")!r}',
                    xbmc.LOGINFO,
                )
            except Exception:
                pass
    else:
        # Explicit mapping ensures url and required metadata fields are never stripped out
        entry = {
            'pos': float(pos),
            'dur': float(dur),
            'ts': int(time.time()),
            'url': meta.get('url', ''),
            'title': meta.get('title', ''),
            'tmdb': meta.get('tmdb', ''),
            'content': tracking_content,
            'season': meta.get('season', ''),
            'episode': meta.get('episode', ''),
            'label': meta.get('label', ''),
            'poster': meta.get('poster', ''),
            'fanart': meta.get('fanart', ''),
            'year': meta.get('year', ''),
            'imdb': meta.get('imdb', ''),
            'source': meta.get('source', ''),
            'provider': meta.get('provider', ''),
            'slug': meta.get('slug', ''),
        }
        data[key] = entry
    _save(data)
    if threshold_reached:
        _refresh_container()


def clear(key):
    data = _load()
    if data.pop(key, None) is not None:
        _save(data)
        return True
    return False


def list_recent(limit=30, min_ratio=0.02):
    """Return resume entries ordered by most-recently-sampled, newest first.

    Each returned dict carries the stored meta (title, tmdb, content,
    season, episode, label, url, poster, fanart, year, imdb) plus
    ``key``, ``pos``, ``dur``, ``ts`` and ``progress`` (0..1).
    """
    data = _load()
    rows = []
    for key, v in data.items():
        if not isinstance(v, dict):
            continue
        if is_nineanime(v):
            continue
        pos = _safe_float(v.get('pos', 0))
        dur = _safe_float(v.get('dur', 0))
        if pos < MIN_SAVE_SECONDS:
            continue
            
        # Fast non-blocking sanitization: avoid slow inline network calls that freeze Kodi's UI
        if dur <= 0 or dur > 18000:
            content = _tracking_content(v)
            dur = 1440.0 if content == 'episode' else 7200.0  # Instant fallback (24m / 2h)

        progress = (pos / dur) if dur > 0 else 0
        if dur > 0 and progress >= get_finished_ratio():
            continue
        if dur > 0 and progress < min_ratio:
            # brushed the timeline very briefly — skip
            pass
        rows.append({
            'key': key,
            'pos': pos,
            'dur': dur,
            'progress': progress,
            'ts': int(v.get('ts', 0) or 0),
            'title': v.get('title', ''),
            'tmdb': v.get('tmdb', ''),
            'content': v.get('content', 'movie'),
            'season': v.get('season', ''),
            'episode': v.get('episode', ''),
            'label': v.get('label', ''),
            'url': v.get('url', ''),
            'poster': v.get('poster', ''),
            'fanart': v.get('fanart', ''),
            'year': v.get('year', ''),
            'imdb': v.get('imdb', ''),
            'source': v.get('source', ''),
            'provider': v.get('provider', ''),
            'slug': v.get('slug', ''),
        })
    rows.sort(key=lambda r: r.get('ts', 0), reverse=True)
    return rows[:limit]


def format_offset(seconds):
    s = int(seconds or 0)
    m, s = divmod(s, 60)
    h, m = divmod(m, 60)
    if h:
        return f'{h:d}h {m:02d}m'
    return f'{m:d}m {s:02d}s'


def _future_air_date(value):
    """Return whether an episode air date is later than today."""
    value = str(value or '').strip()
    if not value:
        return False
    try:
        return value[:10] > time.strftime('%Y-%m-%d')
    except Exception:
        return False


def _next_episode_numbers(meta):
    """Find the next released TMDB episode after the current one."""
    try:
        tmdb_id = str(meta.get('tmdb') or '').strip()
        season = int(meta.get('season'))
        episode = int(meta.get('episode'))
    except (AttributeError, TypeError, ValueError):
        return None
    if not tmdb_id:
        return None

    try:
        from . import tmdb as tmdb_mod

        candidate = tmdb_mod.get_episode_meta(tmdb_id, season, episode + 1)
        if candidate and not _future_air_date(candidate.get('air_date')):
            return season, episode + 1

        # The current season may have ended. Find the first released episode
        # in the next numbered season, skipping specials (season 0).
        seasons = tmdb_mod.get_tv_seasons(tmdb_id)
        for season_row in sorted(seasons or [], key=lambda row: int(row.get('number', 0) or 0)):
            try:
                next_season = int(season_row.get('number'))
            except (TypeError, ValueError):
                continue
            if next_season <= season or next_season == 0:
                continue
            episodes = tmdb_mod.get_tv_episodes(tmdb_id, next_season)
            for episode_row in episodes or []:
                try:
                    next_episode = int(episode_row.get('number'))
                except (TypeError, ValueError):
                    continue
                if next_episode > 0 and not _future_air_date(episode_row.get('air_date')):
                    return next_season, next_episode
    except Exception as exc:
        xbmc.log(f'COSMOS resume: next episode lookup failed: {exc}', xbmc.LOGDEBUG)
    return None


def _autoplay_next_episode(meta):
    """Queue the next released episode through the normal Link Zero route."""
    if not autoplay_next_episode_enabled():
        return
    if str(meta.get('content') or '').lower() != 'episode':
        return

    # Cosmos Shows episodes carry their source-feed identity. Hand those
    # episodes back to the Shows-menu route so its playlist order and native
    # links are used instead of guessing the next item from TMDB alone.
    if meta.get('feed'):
        from urllib.parse import urlencode
        url = 'plugin://plugin.video.cosmos/?' + urlencode({
            'action': 'autoplay_next_episode',
            'feed': meta.get('feed', ''),
            'tmdb': meta.get('tmdb', ''),
            'title': meta.get('title', ''),
            'year': meta.get('year', ''),
            'imdb': meta.get('imdb', ''),
            'season': meta.get('season', ''),
            'episode': meta.get('episode', ''),
            'poster': meta.get('poster', ''),
            'fanart': meta.get('fanart', ''),
        })
        xbmc.log('COSMOS resume: handing next episode to the Shows menu route', xbmc.LOGINFO)
        xbmc.executebuiltin(f'RunPlugin({url})')
        return

    numbers = _next_episode_numbers(meta)
    if not numbers:
        xbmc.log('COSMOS resume: no released next episode found', xbmc.LOGDEBUG)
        return

    import json as _json
    from urllib.parse import urlencode

    next_season, next_episode = numbers
    # Carry show identities and the service return route into the new tracker.
    # Playback-specific fields belong to the completed episode, so discard them.
    next_meta = dict(meta)
    for key in ('url', 'label', 'resume_key', 'episode_title'):
        next_meta.pop(key, None)
    next_meta.update({
        'content': 'episode',
        'season': next_season,
        'episode': next_episode,
    })
    payload = _json.dumps(next_meta)
    url = 'plugin://plugin.video.cosmos/?' + urlencode({
        'action': 'link_zero',
        'auto_next': '1',
        'payload': payload,
    })
    xbmc.log(
        f'COSMOS resume: auto-playing next episode S{next_season}E{next_episode}',
        xbmc.LOGINFO,
    )
    xbmc.executebuiltin(f'RunPlugin({url})')


# ── Background Player subclass ───────────────────────────────────────────

class _Tracker(xbmc.Player):
    def __init__(self, key, seek_to=0.0, meta=None):
        super().__init__()
        self._key = key
        self._seek_to = float(seek_to or 0)
        self._meta = meta or {}
        self._stop = threading.Event()
        self._playing = False
        self._last_saved = 0
        self._scrobbled_start = False
        self._scrobbled_stop = False
        self._finished = False
        self._duration = 0.0
        self._trakt_event_lock = threading.Lock()
        self._trakt_event_thread = None
        self._simkl_event_lock = threading.Lock()
        self._simkl_event_thread = None
        self._punchplay_event_lock = threading.Lock()
        self._punchplay_event_thread = None
        self._playback_session_id = f'cosmos-kodi-{time.time_ns()}'

    def _playback_position(self):
        try:
            position = float(self.getTime() or 0)
        except Exception:
            position = 0.0
        if position <= 0:
            position = float(self._last_saved or 0)
        return max(0.0, position)

    def _scrobble_minimum_met(self, position=None):
        minimum = get_scrobble_minimum_seconds()
        if minimum <= 0:
            return True
        if position is None:
            position = self._playback_position()
        return position >= minimum

    def _maybe_scrobble_start(self, progress=None, position=None):
        """Send the start event once the configured minimum is reached."""
        if self._scrobbled_start or not self._scrobble_minimum_met(position):
            return False
        self._scrobbled_start = True
        if progress is None:
            progress = self._current_progress()
        self._do_scrobble('start', progress=progress)
        return True

    # ── Scrobble helpers (best-effort, non-blocking) ───────────────────
    def _watch_tracking_service(self):
        """Return the selected playback tracking destination."""
        return _watched.get_tracking_service()

    def _service_selected(self, service):
        selected = self._watch_tracking_service()
        return selected == 'all' or selected == service

    def _trakt_scrobble_enabled(self):
        if not self._service_selected('trakt'):
            return False
        media, _ = _trakt._build_media(self._meta)
        return bool(media)

    def _simkl_scrobble_enabled(self):
        if not self._service_selected('simkl'):
            return False
        ids = self._meta.get('ids') if isinstance(self._meta.get('ids'), dict) else {}
        known_id_keys = (
            'simkl', 'imdb', 'tmdb', 'tvdb', 'mal', 'anidb', 'anilist', 'kitsu',
        )
        has_id = any(
            self._meta.get(key) or self._meta.get(f'{key}_id') or ids.get(key)
            for key in known_id_keys
        )
        # SIMKL also supports title/year resolution when no external ID is
        # available, so do not disable scrobbling for those valid payloads.
        return bool(self._meta.get('title') and (
            has_id or self._meta.get('year')))

    def _punchplay_scrobble_enabled(self):
        if not self._service_selected('punchplay'):
            return False
        content = str(self._meta.get('content') or 'movie').lower()
        is_episode = content in ('episode', 'tv', 'tvshow', 'show', 'anime', 'anime_episode')
        if is_episode and (self._meta.get('season') in (None, '') or
                           self._meta.get('episode') in (None, '')):
            return False
        ids = self._meta.get('ids') if isinstance(self._meta.get('ids'), dict) else {}
        has_identity = any(
            self._meta.get(key) or self._meta.get(f'{key}_id') or ids.get(key)
            for key in ('punchplay', 'tmdb', 'imdb', 'tvdb')
        )
        return bool(self._meta.get('title') and (has_identity or self._meta.get('year')))

    def _position_and_duration(self):
        position = self._playback_position()
        duration = float(self._duration or 0)
        if self.isPlayingVideo():
            try:
                duration = max(duration, float(self.getTotalTime() or 0))
            except Exception:
                pass
        return position, duration

    def _current_progress(self):
        try:
            pos = float(self.getTime() or 0)
            dur = float(self.getTotalTime() or 0)
        except Exception:
            pos, dur = 0.0, 0.0
        if dur <= 0:
            # Player has already stopped — fall back to last known position/duration
            pos = self._last_saved
            dur = self._duration
        if dur <= 0:
            return 0.0
        return max(0.0, min(100.0, (pos / dur) * 100.0))

    def _do_scrobble(self, verb, progress=None, punchplay_verb=None):
        if progress is None:
            progress = self._current_progress()

        # 9Anime playback is local to Cosmos.  Do not turn its synthetic
        # catalog ids into Trakt/Simkl rows that can be
        # fetched back into Continue Watching as unrelated service entries.
        if is_nineanime(self._meta):
            xbmc.log('COSMOS resume: skipping remote scrobble for 9Anime playback', xbmc.LOGDEBUG)
            return

        xbmc.log(
            f'COSMOS resume: playback tracking service={self._watch_tracking_service()}',
            xbmc.LOGDEBUG,
        )

        if self._trakt_scrobble_enabled():
            try:
                def _send_trakt_event(previous):
                    if previous is not None:
                        previous.join()
                    try:
                        ok = _trakt._scrobble(
                            verb, self._meta, progress, require_watched=(verb == 'stop'))
                        if ok and verb == 'stop':
                            _watched.cache_selected_watched(self._meta, service='trakt')
                    except Exception as exc:
                        xbmc.log(f'COSMOS Trakt scrobble failed: {exc}', xbmc.LOGWARNING)

                # Preserve playback event order and let the final stop finish
                # before the plugin's Python interpreter shuts down.
                with self._trakt_event_lock:
                    previous = self._trakt_event_thread
                    t = threading.Thread(
                        target=_send_trakt_event,
                        args=(previous,),
                        name='cosmos-trakt-event',
                        daemon=False,
                    )
                    self._trakt_event_thread = t
                    t.start()
            except Exception as e:
                xbmc.log(f'COSMOS Trakt scrobble dispatch failed: {e}', xbmc.LOGWARNING)
        xbmc.log(f'COSMOS Simkl scrobble enabled: {self._simkl_scrobble_enabled()}', xbmc.LOGDEBUG)
        if self._simkl_scrobble_enabled() and not is_nineanime(self._meta):
            try:
                def _send_simkl_event(previous):
                    if previous is not None:
                        previous.join()
                    try:
                        ok = _simkl.scrobble(
                            verb, self._meta, progress, require_watched=(verb == 'stop'))
                    except Exception as exc:
                        xbmc.log(f'COSMOS Simkl scrobble failed: {exc}', xbmc.LOGWARNING)
                        return
                    if ok and verb == 'stop':
                        # Fetch the updated next-to-watch entry before the
                        # watched-cache write refreshes the visible container.
                        # Also invalidate on an accepted already-watched (409)
                        # response, which bypasses HTTP success invalidation.
                        try:
                            _simkl._invalidate_ratings_cache()
                            _simkl.get_next_episode_items(refresh=True)
                        except Exception as exc:
                            xbmc.log(
                                f'COSMOS Simkl post-playback sync failed: {exc}',
                                xbmc.LOGWARNING,
                            )
                        _watched.cache_selected_watched(self._meta, service='simkl')
                        return_url = str(self._meta.get('return_url') or '')
                        if 'action=simkl_next_episodes' in return_url:
                            # Rebuild the list after completion is accepted
                            # and the next-episode snapshot has been fetched.
                            xbmc.executebuiltin(f'Container.Update({return_url},replace)')


                # A lock inside the HTTP call does not guarantee event order.
                # Chain workers so a delayed start cannot overwrite the stop,
                # and keep the final write alive during plugin shutdown.
                with self._simkl_event_lock:
                    worker = threading.Thread(
                        target=_send_simkl_event,
                        args=(self._simkl_event_thread,),
                        name='cosmos-simkl-event',
                        daemon=False,
                    )
                    worker.start()
                    self._simkl_event_thread = worker
            except Exception as e:
                xbmc.log(f'COSMOS Simkl scrobble dispatch failed: {e}', xbmc.LOGWARNING)

        if self._punchplay_scrobble_enabled() and not is_nineanime(self._meta):
            try:
                position, duration = self._position_and_duration()
                punchplay_action = punchplay_verb or verb

                def _send_punchplay_event(previous):
                    if previous is not None:
                        previous.join()
                    try:
                        ok = _punchplay.scrobble(
                            punchplay_action, self._meta, progress=progress,
                            position_seconds=position,
                            duration_seconds=duration,
                            playback_session_id=self._playback_session_id,
                            watched_threshold=get_finished_ratio(),
                        )
                    except Exception as exc:
                        xbmc.log(
                            f'COSMOS PunchPlay scrobble failed: {exc}',
                            xbmc.LOGWARNING,
                        )
                        return
                    if (ok and punchplay_action == 'stop' and
                            progress >= get_finished_ratio() * 100):
                        # Keep the PunchPlay watched indicator current
                        # immediately. Partner Sync later reconciles this
                        # optimistic cache entry with authoritative history.
                        _watched.cache_selected_watched(
                            self._meta, service='punchplay')
                        return_url = str(self._meta.get('return_url') or '')
                        if ('action=punchplay_continue_watching' in return_url or
                                'action%3Dpunchplay_continue_watching' in return_url):
                            # The stop has now been accepted and PunchPlay has
                            # advanced its show-level next-episode pointer.
                            # Re-fetch the official Continue Watching endpoint
                            # only now, avoiding an early redraw of the episode
                            # that just completed.
                            xbmc.executebuiltin(f'Container.Update({return_url})')

                # Preserve PunchPlay's required per-session event ordering.
                with self._punchplay_event_lock:
                    worker = threading.Thread(
                        target=_send_punchplay_event,
                        args=(self._punchplay_event_thread,),
                        name='cosmos-punchplay-event',
                        daemon=False,
                    )
                    worker.start()
                    self._punchplay_event_thread = worker
            except Exception as e:
                xbmc.log(
                    f'COSMOS PunchPlay scrobble dispatch failed: {e}',
                    xbmc.LOGWARNING,
                )
    def onAVStarted(self):  # noqa: N802
        self._playing = True
        if not is_nineanime(self._meta):
            try:
                _opensubtitles.auto_apply_for_playback(self._meta, player=self)
            except Exception as e:
                xbmc.log(f'COSMOS automatic subtitle preference failed: {e}', xbmc.LOGWARNING)
        if self._seek_to and self._seek_to > 0:
            xbmc.sleep(500)
            try:
                self.seekTime(self._seek_to)
            except Exception as e:
                xbmc.log(f'COSMOS resume: seek failed: {e}', xbmc.LOGWARNING)
        try:
            dur = float(self.getTotalTime() or 0)
            self._duration = dur
        except Exception:
            dur = 0.0
            self._duration = 0.0
        p = 0.0
        if self._seek_to and dur > 0:
            p = max(0.0, min(100.0, (self._seek_to / dur) * 100.0))
        self._maybe_scrobble_start(progress=p, position=self._seek_to)

    def onPlayBackStopped(self):  # noqa: N802
        """Called when user manually stops playback."""
        if self._finished and self._meta.get('return_url'):
            self._stop.set()
            return
        if not self._scrobbled_stop:
            self._scrobbled_stop = True
            current_position = self._playback_position()
            if self._scrobble_minimum_met(current_position):
                self._maybe_scrobble_start(position=current_position)
                if self._scrobbled_start:
                    current_progress = self._current_progress()
                    self._do_scrobble('stop', progress=current_progress)

        # Save final resume point
        try:
            pos = self.getTime() if self.isPlayingVideo() else self._last_saved
            dur = self.getTotalTime() if self.isPlayingVideo() else 0
            if pos:
                put(self._key, pos, dur, meta=self._meta)
        except Exception:
            pass
        self._stop.set()

    def onPlayBackPaused(self):  # noqa: N802
        if self._maybe_scrobble_start() and self._scrobbled_start:
            return
        if self._scrobbled_start:
            self._do_scrobble('pause')

    def onPlayBackResumed(self):  # noqa: N802
        # Trakt and Simkl continue to use start for resume. PunchPlay has a
        # dedicated resume action, supplied without altering either path.
        if self._maybe_scrobble_start() and self._scrobbled_start:
            return
        if self._scrobbled_start:
            self._do_scrobble('start', punchplay_verb='resume')

    def onPlayBackSeek(self, time_ms, seek_offset):  # noqa: N802
        try:
            dur = float(self.getTotalTime() or 0)
            pos = float(time_ms) / 1000.0
            p = (pos / dur) * 100.0 if dur > 0 else 0.0
        except Exception:
            p = 0.0
        if self._simkl_scrobble_enabled():
            try:
                # Simkl docs: "Do not poll /scrobble/* every few seconds or minutes."
                # A seek event is not a user play/pause/stop action. The new progress
                # will be sent with the next onPlayBackResumed or onPlayBackPaused event.
                pass
            except Exception as e:
                xbmc.log(f'COSMOS Simkl seek scrobble dispatch failed: {e}', xbmc.LOGWARNING)

    def onPlayBackEnded(self):  # noqa: N802
        if self._finished:
            return
        self._finished = True
        clear(self._key)
        try:
            tracking_content = _tracking_content(self._meta)
            if tracking_content == 'episode':
                _watched.mark_watched(
                    self._meta.get('tmdb'), self._meta.get('season'), self._meta.get('episode'))
            elif tracking_content == 'movie':
                _watched.mark_movie_watched(self._meta.get('tmdb'))
        except Exception:
            pass
                
        final_position = max(self._duration, self._last_saved, self._seek_to)
        scrobble_allowed = self._scrobble_minimum_met(final_position)
        if scrobble_allowed:
            self._maybe_scrobble_start(progress=0.0, position=final_position)
        if not self._scrobbled_stop and scrobble_allowed and self._scrobbled_start:
            self._scrobbled_stop = True
            self._do_scrobble('stop', progress=100.0)

        try:
            return_url = self._meta.get('return_url')
            if return_url:
                # Some plugin play routes are also the active container URL.
                # Refreshing those routes re-enters their picker. A targeted
                # update returns 9Anime to its episode list instead.
                xbmc.executebuiltin('PlayerControl(Stop)')
                punchplay_continue = (
                    self._watch_tracking_service() == 'punchplay' and
                    ('action=punchplay_continue_watching' in return_url or
                     'action%3Dpunchplay_continue_watching' in return_url)
                )
                simkl_next_pending = (
                    'action=simkl_next_episodes' in return_url and
                    self._simkl_scrobble_enabled() and self._scrobbled_stop
                )
                if not punchplay_continue and not simkl_next_pending:
                    xbmc.sleep(500)
                    xbmc.executebuiltin(f'Container.Update({return_url})')
                if (_is_direct_link_meta(self._meta) and
                        not punchplay_continue and not simkl_next_pending):
                    # Direct links return to the source container through the
                    # targeted update above; refresh it as well so watched
                    # badges and completion indicators are rebuilt.
                    xbmc.sleep(250)
                    _refresh_container()
            else:
                # Refresh the container to show the updated history
                _refresh_container()
        except Exception:
            pass

        if autoplay_next_episode_enabled():
            threading.Thread(
                target=_autoplay_next_episode,
                args=(dict(self._meta),),
                name='cosmos-autoplay-next-episode',
                daemon=True,
            ).start()
             
        self._stop.set()

    def onPlayBackError(self):  # noqa: N802
        self._stop.set()

    def run(self, max_runtime=6 * 3600):
        start = time.time()
        deadline = start + 45
        while not self._stop.is_set() and not self.isPlayingVideo():
            if time.time() > deadline:
                return
            xbmc.sleep(500)
        self._playing = self.isPlayingVideo()
        while not self._stop.is_set() and self.isPlayingVideo():
            try:
                pos = self.getTime()
                dur = self.getTotalTime()
            except Exception:
                pos, dur = 0, 0
            if pos and dur > 0:
                # Duration can be unavailable in onAVStarted, especially for
                # adaptive streams. Retain it before Kodi tears down playback.
                self._duration = dur
                progress = max(0.0, min(100.0, (pos / dur) * 100.0))
                self._maybe_scrobble_start(progress=progress, position=pos)
            if pos and pos >= MIN_SAVE_SECONDS:
                if abs(pos - self._last_saved) >= SAMPLE_INTERVAL:
                    put(self._key, pos, dur, meta=self._meta)
                    self._last_saved = pos
                    
            if time.time() - start > max_runtime:
                break
            xbmc.sleep(SAMPLE_INTERVAL * 1000)

        # Some Kodi/player combinations stop reporting video before delivering
        # onPlayBackEnded. Recover a natural end from the last sampled
        # position, while leaving explicit stop/error callbacks untouched.
        if not self._finished and not self._stop.is_set():
            # Playback has stopped, so querying Kodi here races player
            # teardown. Use the final successfully sampled values instead.
            position = float(self._last_saved or 0)
            duration = float(self._duration or 0)
            if duration > 0 and position / duration >= 0.985:
                xbmc.log('COSMOS resume: recovered missed playback-ended callback', xbmc.LOGINFO)
                self.onPlayBackEnded()
                return
            if not self.isPlayingVideo():
                # Even without an ended/stopped callback, finalize the real
                # last position so Simkl can mark >=80% playback watched.
                self.onPlayBackStopped()

        if not self._finished:
            try:
                pos = self.getTime() if self.isPlayingVideo() else self._last_saved
                dur = self.getTotalTime() if self.isPlayingVideo() else 0
                if pos:
                    put(self._key, pos, dur, meta=self._meta)
            except Exception:
                pass


def start_tracker(key, seek_to=0.0, meta=None):
    tracker = _Tracker(key, seek_to=seek_to, meta=meta)
    t = threading.Thread(target=tracker.run, name='cosmos-resume-tracker', daemon=True)
    t.start()
    return tracker
