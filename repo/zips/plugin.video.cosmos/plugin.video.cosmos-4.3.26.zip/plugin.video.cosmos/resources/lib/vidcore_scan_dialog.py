"""Cosmos progress screen for Vidcore source checks."""
import threading
import time
import xbmc
import xbmcgui
from .source_finder_dialog import ADDON_PATH


class SourceScanDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.cancelled = threading.Event()
        self.ready = threading.Event()

    def onInit(self):
        self.setProperty('scan_status', 'Searching playback providers...')
        self.setProperty('scan_checked', '0')
        self.setProperty('scan_available', '0')
        self.setProperty('scan_remaining', '...')
        self.update(0, 'Searching playback providers...')
        self.setFocusId(900)
        self.ready.set()

    def create(self, *args):
        self.show()
        # Kodi queues onInit for this Python invoker. A threading.Event wait
        # prevents that callback from running; xbmc.sleep services callbacks.
        deadline = time.monotonic() + 5
        monitor = xbmc.Monitor()
        while not self.ready.is_set() and time.monotonic() < deadline:
            if monitor.abortRequested():
                self.cancelled.set()
                return
            xbmc.sleep(25)
        if not self.ready.is_set():
            self.close()
            raise RuntimeError('Source scan dialog did not open')

    def update(self, percent, message):
        # Size a plain image within the fixed track. Kodi's progress end-cap
        # textures can exceed the track when using our full-width artwork.
        percent = max(0.0, min(100.0, float(percent)))
        fill = self.getControl(100)
        fill.setWidth(max(1, int(820 * percent / 100)))
        fill.setVisible(percent > 0)
        self.setProperty('scan_status', message)

    def update_sources(self, checked, total, available):
        self.setProperty('scan_checked', str(checked))
        self.setProperty('scan_available', str(available))
        self.setProperty('scan_remaining', str(total - checked))
        self.update(100 * checked / max(1, total),
                    'Checking streams... %d of %d complete' % (checked, total))

    def iscanceled(self):
        return self.cancelled.is_set()

    def onClick(self, control_id):
        if control_id == 900:
            self.cancelled.set()

    def onAction(self, action):
        if action.getId() in (9, 10, 92, 216):
            self.cancelled.set()


def create_progress():
    dialog = SourceScanDialog('VidCoreScan.xml', ADDON_PATH, 'Default', '720p')
    try:
        dialog.create()
        return dialog
    except Exception as exc:
        xbmc.log('COSMOS Vidcore custom scan screen failed: %s' %
                 type(exc).__name__, xbmc.LOGWARNING)
        dialog.close()
        fallback = xbmcgui.DialogProgress()
        fallback.create('Vidcore', 'Checking playback sources...')
        return fallback
