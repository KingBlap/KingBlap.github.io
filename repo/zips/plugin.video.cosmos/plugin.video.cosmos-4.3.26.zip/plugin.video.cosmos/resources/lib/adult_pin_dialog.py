import xbmcgui


class AdultPinDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.value = ''

    def onInit(self):
        self.getControl(9000).setText('')
        self.setFocusId(9000)

    def onClick(self, control_id):
        if control_id == 9001:
            self.value = (self.getControl(9000).getText() or '').strip()
            self.close()

    def onAction(self, action):
        action_id = action.getId()
        # Back/Escape/Stop close the dialog without submitting the PIN.
        if action_id in (9, 10, 92):
            self.value = ''
            self.close()
        # Select/OK on a remote submits when the unlock button has focus.
        elif action_id in (7, 100) and self.getFocusId() == 9001:
            self.onClick(9001)
        # Make the vertical focus path reliable on remotes and gamepads.
        elif action_id == 1 and self.getFocusId() == 9001:  # up
            self.setFocusId(9000)
        elif action_id == 2 and self.getFocusId() == 9000:  # down
            self.setFocusId(9001)
        else:
            super().onAction(action)
