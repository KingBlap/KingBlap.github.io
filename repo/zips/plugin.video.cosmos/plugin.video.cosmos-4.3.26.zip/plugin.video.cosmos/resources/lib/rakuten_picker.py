"""Rakuten live channel picker using the Cosmos source picker controls."""
import xbmcgui

from .source_finder_dialog import LinkPickerDialog, ADDON_PATH
from .rakuten import _programme_info


def channel_link(channel, icon):
    info = _programme_info(channel)
    lines = info['plot'].split('\n\n')
    now = next((line for line in lines if line.startswith('Now:')), 'Now: Programme unavailable')
    return {'label': channel.get('title') or channel['id'],
            'meta': now, 'preview_meta': '\n\n'.join(lines[1:]),
            'icon': channel.get('images', {}).get('artwork') or icon,
            'format_label': 'LIVE', 'channel': channel, 'info': info}


class RakutenLivePickerDialog(LinkPickerDialog):
    provider_title = 'Rakuten TV'

    def make_link(self, channel):
        return channel_link(channel, self.channel_icon)

    def __init__(self, *args, **kwargs):
        self.channels = kwargs.pop('channels')
        self.refresh_channels = kwargs.pop('refresh_channels')
        self.market = kwargs.pop('market')
        self.channel_icon = kwargs.get('icon_path', '')
        kwargs['links'] = [self.make_link(c) for c in self.channels]
        kwargs['quality_label'] = self.provider_title
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('rt_market', 'UK' if self.market == 'uk' else self.market.upper())
        super().onInit()

    def _refresh_selection_banner(self):
        if not self.links:
            return
        # Recalculate Now/Next on navigation, including programme boundaries.
        link = self.make_link(self.links[self.current_index]['channel'])
        self.links[self.current_index] = link
        super()._refresh_selection_banner()
        self.setProperty('rt_channel_logo', link['icon'])
        self.setProperty('rt_epg', link['preview_meta'])
        self.getControl(4001).getListItem(self.current_index).setProperty('meta', link['meta'])

    def onClick(self, controlId):
        if controlId != 4004:
            super().onClick(controlId)
            return
        selected_id = self.links[self.current_index]['channel']['id']
        progress = xbmcgui.DialogProgress()
        progress.create(self.provider_title, 'Refreshing live programme guide...')
        try:
            channels = self.refresh_channels()
            self.channels = sorted(channels, key=lambda c: int(c.get('channel_number') or 99999))
            self.links = [self.make_link(c) for c in self.channels]
            self.current_index = next((i for i, c in enumerate(self.channels)
                                       if c['id'] == selected_id), 0)
            self.onInit()
        except Exception:
            xbmcgui.Dialog().notification(self.provider_title, 'Unable to refresh the programme guide.')
        finally:
            progress.close()


def show(channels, market, icon, refresh_channels):
    if not channels:
        return None
    channels = sorted(channels, key=lambda c: int(c.get('channel_number') or 99999))
    dialog = RakutenLivePickerDialog(
        'RakutenLivePicker.xml', ADDON_PATH, 'Default', '720p',
        channels=channels, market=market, icon_path=icon,
        refresh_channels=refresh_channels)
    try:
        dialog.doModal()
        index = dialog.selected_index
        if index is not None and 0 <= index < len(dialog.links):
            return dialog.links[index]['channel']
        return None
    finally:
        del dialog
