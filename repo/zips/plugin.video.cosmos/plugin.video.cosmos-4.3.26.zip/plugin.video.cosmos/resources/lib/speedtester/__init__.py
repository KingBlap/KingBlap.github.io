"""Self-contained speed-test dialog ported from Enigma Wizard."""
