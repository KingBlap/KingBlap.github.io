# -*- coding: utf-8 -*-
"""
Trakt.tv integration for C.O.S.M.O.S.

This addon and code was created by Zeus768 for Cosmos.
Author: Zeus768

Implements OAuth device-code flow (stdlib only) and wrappers for listing
the authenticated user's personal lists (watchlist / collection / history
/ custom lists), the users they follow, those users' public lists, and
liking (following) any of those lists in bulk — the "follow all lists"
feature.

Token storage: special://profile/addon_data/plugin.video.cosmos/trakt_token.json
"""
import json
import math
import os
import time
import threading
import tempfile
import hashlib
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from .auth_dialog import AuthDialog


ADDON_ID = 'plugin.video.cosmos'
ADDON = xbmcaddon.Addon()
DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
TOKEN_FILE = os.path.join(DATA_PATH, 'trakt_token.json')

# Credentials provided by the user (embedded app credentials).
# Can be overridden in settings.xml (trakt_client_id / trakt_client_secret).
DEFAULT_CLIENT_ID = 'cd6019e01042e2c52ff983503fb38fbf0e71a667bd6c0e7dc19f1be06312fa35'
DEFAULT_CLIENT_SECRET = 'c80d41f0eda4491eeadc235959be9056a3aef60103941b992747e58fd5907245'

API_BASE = 'https://api.trakt.tv'
OAUTH_BASE = 'https://auth.trakt.tv'
API_VERSION = '2'
APP_VERSION = ADDON.getAddonInfo('version')
UA = f'COSMOS-Kodi/{APP_VERSION} (plugin.video.cosmos)'
_TOKEN_REFRESH_LOCK = threading.Lock()
_LAST_API_ERROR = ''
_VIP_NOTICE = threading.local()


def take_vip_notice():
    """Consume a VIP response on this thread; background calls never prompt."""
    notice = getattr(_VIP_NOTICE, 'value', None)
    _VIP_NOTICE.value = None
    return notice


def _vip_response(status, headers):
    from urllib.parse import urlsplit
    if status not in (420, 426):
        return
    headers = {str(k).lower(): str(v) for k, v in (headers or {}).items()}
    vip = headers.get('x-vip-user', '').lower() == 'true'
    limit = headers.get('x-account-limit', '')
    upgrade = headers.get('x-upgrade-url', 'https://trakt.tv/vip')
    parsed = urlsplit(upgrade)
    # Only hand official HTTPS Trakt URLs to the OS browser.
    if (parsed.scheme != 'https' or parsed.hostname not in ('trakt.tv', 'app.trakt.tv')
            or parsed.username or parsed.password or parsed.netloc not in ('trakt.tv', 'app.trakt.tv')):
        upgrade = 'https://trakt.tv/vip'
    _VIP_NOTICE.value = {
        'status': status, 'vip': vip,
        'limit': limit if limit.isdigit() else '',
        'upgrade_url': '' if status == 420 and vip else upgrade,
    }
_STATUS_ERRORS = {
    0: 'Network failure: check connection, DNS and TLS',
    400: 'Bad request: request could not be parsed',
    401: 'Unauthorized: authorization is missing or expired; reconnect if refresh fails',
    403: 'Forbidden: invalid API key or unapproved application',
    404: 'Not found: requested record does not exist',
    405: 'Method not found: check the endpoint and HTTP method',
    409: 'Conflict: resource already exists or operation conflicts with current state',
    412: 'Precondition failed: application/json content type is required',
    420: 'Account limit exceeded: check list or item limits',
    422: 'Validation failed: check the submitted IDs and fields',
    423: 'Account locked: contact Trakt support',
    426: 'VIP required: this operation requires Trakt VIP',
    429: 'Rate limit exceeded: wait before retrying',
    500: 'Trakt server error: contact Trakt support if it persists',
    502: 'Trakt overloaded: try again in 30 seconds',
    503: 'Trakt overloaded: try again in 30 seconds',
    504: 'Trakt unavailable: try again in 30 seconds',
    520: 'Cloudflare error: try again later',
    521: 'Cloudflare error: try again later',
    522: 'Cloudflare timeout: try again later',
}


def get_last_error():
    """Diagnostic for the latest failed API request; no credentials/body."""
    return _LAST_API_ERROR


def _debug_bundle_event(tag, detail):
    """Send safe Trakt diagnostics to Cosmos' optional general debug bundle."""
    try:
        from . import debug_bundle
        if debug_bundle.is_enabled():
            debug_bundle.log('Trakt ' + str(tag), detail)
    except Exception:
        pass


def _record_status(status, method, url, headers=None, data=None):
    global _LAST_API_ERROR
    from urllib.parse import urlsplit
    path = urlsplit(url).path
    method = str(method or 'GET').upper()
    api_error = ''
    if isinstance(data, dict):
        api_error = data.get('error') or data.get('error_description') or ''
        if isinstance(api_error, (dict, list)):
            api_error = ''
        api_error = ' '.join(str(api_error).replace('\r', ' ').replace('\n', ' ').split())[:200]
    if 200 <= status < 300:
        _LAST_API_ERROR = ''
        _debug_bundle_event('HTTP', f'{method} {path} -> {status}')
        return
    _vip_response(status, headers)
    reason = _STATUS_ERRORS.get(status, 'Unexpected HTTP response')
    # Device authentication assigns special meanings to these HTTP codes.
    if path.endswith('/oauth/device/token'):
        reason = {400: 'Authorization pending', 404: 'Invalid device code',
                  409: 'Device code already used', 410: 'Device code expired',
                  418: 'Authorization denied', 429: 'Device polling too fast'}.get(status, reason)
        if status == 400:
            _LAST_API_ERROR = ''
            _debug_bundle_event(
                'AUTH', f'{method} {path} -> HTTP {status}: {reason}'
            )
            return
    retry = next((str(v) for k, v in (headers or {}).items()
                  if k.lower() == 'retry-after'), '')
    suffix = ('; Retry-After: %s seconds' % retry) if retry.isdigit() else ''
    _LAST_API_ERROR = '%s %s — HTTP %s: %s%s' % (method, path, status, reason, suffix)
    xbmc.log('Trakt: ' + _LAST_API_ERROR, xbmc.LOGWARNING)
    detail = f'{method} {path} -> HTTP {status}: {reason}{suffix}'
    if api_error:
        detail += f'; api_error={api_error}'
    _debug_bundle_event('HTTP ERROR', detail)


# ── helpers ──────────────────────────────────────────────────────────────

def _ensure_dir():
    if not xbmcvfs.exists(DATA_PATH):
        xbmcvfs.mkdirs(DATA_PATH)
    if not os.path.isdir(DATA_PATH):
        os.makedirs(DATA_PATH, exist_ok=True)


def _credentials():
    cid = (ADDON.getSetting('trakt_client_id') or '').strip() or DEFAULT_CLIENT_ID
    csec = (ADDON.getSetting('trakt_client_secret') or '').strip() or DEFAULT_CLIENT_SECRET
    return cid, csec


def _http_json(url, method='GET', payload=None, headers=None, timeout=20):
    """Return (status_code, parsed_json_or_text, response_headers)."""
    cid, _ = _credentials()
    hdr = {
        'Content-Type': 'application/json',
        'trakt-api-version': API_VERSION,
        'trakt-api-key': cid,
        'User-Agent': UA,
    }
    if headers:
        hdr.update(headers)
    body = json.dumps(payload).encode('utf-8') if payload is not None else None
    try:
        # Honour Trakt rate-limit responses once so bursty list loads recover.
        for attempt in range(2):
            req = Request(url, data=body, headers=hdr, method=method)
            try:
                with urlopen(req, timeout=timeout) as r:
                    raw = r.read().decode('utf-8', errors='replace')
                    try:
                        data = json.loads(raw) if raw else {}
                    except ValueError:
                        data = {'_raw': raw}
                    _record_status(r.getcode(), method, url, data=data)
                    return r.getcode(), data, dict(r.headers.items())
            except HTTPError as e:
                if e.code != 429 or attempt:
                    raise
                try:
                    wait_for = max(1, int(e.headers.get('Retry-After', '1')))
                except (TypeError, ValueError):
                    # An unrecognised delay must not cause an early retry.
                    raise e
                if wait_for > 10:
                    # Return the rate-limit response promptly instead of
                    # shortening Trakt's requested delay or blocking Kodi.
                    raise
                xbmc.log(f'Trakt: rate limited, retrying in {wait_for}s', xbmc.LOGWARNING)
                _debug_bundle_event(
                    'RETRY', f'{method} {urlsplit(url).path} -> HTTP 429; '
                    f'retrying after {wait_for}s',
                )
                time.sleep(wait_for)
    except HTTPError as e:
        raw = ''
        try:
            raw = e.read().decode('utf-8', errors='replace')
        except Exception:
            pass
        try:
            data = json.loads(raw) if raw else {}
        except ValueError:
            data = {'_raw': raw}
        response_headers = dict(e.headers.items() if e.headers else [])
        _record_status(e.code, method, url, response_headers, data=data)
        return e.code, data, response_headers
    except URLError as e:
        _record_status(0, method, url)
        return 0, None, {}
    except Exception as e:
        _record_status(0, method, url)
        return 0, None, {}


# ── token storage ────────────────────────────────────────────────────────

def _save_token(data):
    _ensure_dir()
    data = dict(data or {})
    data['stored_at'] = int(time.time())
    try:
        with open(TOKEN_FILE, 'w', encoding='utf-8') as fp:
            json.dump(data, fp)
        try:
            os.chmod(TOKEN_FILE, 0o600)
        except OSError:
            pass
    except OSError as e:
        xbmc.log(f'Trakt save token failed: {e}', xbmc.LOGERROR)
    # Also save to settings for ReAuth compatibility
    try:
        ADDON.setSetting('trakt_access_token', data.get('access_token', ''))
        ADDON.setSetting('trakt_refresh_token', data.get('refresh_token', ''))
        ADDON.setSetting('trakt_expires_in', str(data.get('expires_in', '')))
        ADDON.setSetting('trakt_created_at', str(data.get('created_at', '')))
    except Exception as e:
        xbmc.log(f'Trakt save token to settings failed: {e}', xbmc.LOGWARNING)


def _load_token():
    # Try settings first for ReAuth compatibility
    access_token = ADDON.getSetting('trakt_access_token')
    if access_token:
        try:
            created_at = int(ADDON.getSetting('trakt_created_at'))
        except (ValueError, TypeError):
            created_at = 0
        try:
            expires_in = int(ADDON.getSetting('trakt_expires_in'))
        except (ValueError, TypeError):
            expires_in = 0
        
        token_data = {
            'access_token': access_token,
            'refresh_token': ADDON.getSetting('trakt_refresh_token'),
            'created_at': created_at,
            'expires_in': expires_in,
            'token_type': 'bearer',
            'scope': 'public',
            'stored_at': created_at, # Use created_at as a proxy for stored_at
        }
        return token_data

    # Fallback to file
    if os.path.isfile(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, 'r', encoding='utf-8') as fp:
                return json.load(fp)
        except (OSError, ValueError):
            pass
    return None

def _delete_token():
    try:
        if os.path.isfile(TOKEN_FILE):
            os.remove(TOKEN_FILE)
    except OSError:
        pass
    try:
        ADDON.setSetting('trakt_access_token', '')
        ADDON.setSetting('trakt_refresh_token', '')
        ADDON.setSetting('trakt_expires_in', '')
        ADDON.setSetting('trakt_created_at', '')
        ADDON.setSetting('trakt_auth_done', 'false')
        ADDON.setSetting('trakt_username', '')
    except Exception:
        pass


def is_authorized():
    return bool((_load_token() or {}).get('access_token'))


def _token_needs_refresh(tok):
    if not tok:
        return True
    try:
        stored_at = int(tok.get('stored_at') or 0)
        expires_in = int(tok.get('expires_in') or 0)
    except (TypeError, ValueError, OverflowError):
        return True
    if not stored_at or not expires_in:
        return False
    return (time.time() - stored_at) > (expires_in * 0.8)


def _refresh_token(expected_refresh_token=None, force=False):
    """Refresh once at a time because Trakt refresh tokens are single-use."""
    with _TOKEN_REFRESH_LOCK:
        tok = _load_token()
        if not tok or not tok.get('refresh_token'):
            return False

        # Another caller may have refreshed while this caller was waiting for
        # the lock. Reuse that result instead of consuming the new token too.
        if expected_refresh_token and tok.get('refresh_token') != expected_refresh_token:
            return bool(tok.get('access_token'))
        if not force and not _token_needs_refresh(tok):
            return bool(tok.get('access_token'))

        cid, csec = _credentials()
        status, data, _ = _http_json(
            f'{OAUTH_BASE}/oauth/token',
            method='POST',
            payload={
                'client_id': cid,
                'client_secret': csec,
                'refresh_token': tok['refresh_token'],
                'grant_type': 'refresh_token',
            },
        )
        if status == 200 and isinstance(data, dict) and data.get('access_token'):
            _save_token(data)
            xbmc.log('Trakt: token refreshed', xbmc.LOGINFO)
            return True
        # Trakt invalidates legacy refresh tokens after its auth migration and
        # refresh tokens are single-use. Do not keep retrying a dead token.
        if status == 400 and isinstance(data, dict) and data.get('error') == 'invalid_grant':
            xbmc.log('Trakt: refresh token rejected; user must authorize again', xbmc.LOGWARNING)
            _delete_token()
            return False
        xbmc.log(f'Trakt: refresh failed (status: {status}) - not deleting token to preserve ReAuth compatibility', xbmc.LOGWARNING)
        # Do not delete the token on refresh failure. This allows ReAuth to manage
        # the token independently. If the token is truly invalid, the next API
        # call will fail, but we avoid a race condition where we delete a token
        # that ReAuth has just refreshed.
        return False


def _get_access_token():
    tok = _load_token()
    if not tok:
        return None
    if _token_needs_refresh(tok):
        if not _refresh_token():
            # Do not continue sending an expired/rejected credential after a
            # failed refresh. The caller can re-authorize cleanly.
            return None
        tok = _load_token()
    return (tok or {}).get('access_token')


def _auth_headers():
    cid, _ = _credentials()
    tok = _get_access_token()
    if not tok:
        return None
    return {
        'Authorization': f'Bearer {tok}',
        'trakt-api-key': cid,
    }

# ── Auth Dialog Helpers ───────────────────────────────────────────────────

def _download_qr_code(url):
    """Download a QR-code PNG via the free qrserver.com API; return temp-file path."""
    try:
        from urllib.parse import quote as _q
        # Preserve the complete authorization URI for QR-based sign-in.
        qr_target = url or ''
        qr_api = (
            'https://api.qrserver.com/v1/create-qr-code/'
            f'?size=300x300&data={_q(qr_target, safe="")}'
        )
        req = Request(qr_api, headers={'User-Agent': UA})
        with urlopen(req, timeout=8) as resp:
            img_bytes = resp.read()
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.png')
        tmp.write(img_bytes)
        tmp.close()
        xbmc.log(f'Trakt: QR code saved to {tmp.name}', xbmc.LOGDEBUG)
        return tmp.name
    except Exception as e:
        xbmc.log(f'Trakt: QR download error: {e}', xbmc.LOGWARNING)
        return ''

def _service_icon_path():
    """Return absolute path to the Trakt icon."""
    path = os.path.join(xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/'), 'resources', 'media', 'icon_trakt.png')
    return path if xbmcvfs.exists(path) else ''

def _run_device_auth_window(service_name, user_code, verification_url,
                             expires_in, interval, poll_fn):
    """Show the full-screen AuthDialog and run poll_fn in a background thread."""
    qr_path   = _download_qr_code(verification_url)
    icon_path = _service_icon_path()

    try:
        dialog = AuthDialog(
            'AuthDialog.xml', xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/'), 'Default', '720p',
            service_name=service_name,
            user_code=user_code,
            verification_url=verification_url,
            expires_in=expires_in,
            icon_path=icon_path,
            qr_path=qr_path,
        )
    except Exception as e:
        xbmc.log(f'Trakt: AuthDialog load error (falling back): {e}', xbmc.LOGWARNING)
        prog = xbmcgui.DialogProgress()
        prog.create(f'{service_name} Authorization', f'Go to: [B]{verification_url}[/B]\nEnter code: [B]{user_code}[/B]')
        start_time = time.time()
        while time.time() - start_time < expires_in:
            if prog.iscanceled():
                prog.close()
                return False
            elapsed = time.time() - start_time
            pct = min(99, int((elapsed / expires_in) * 100))
            prog.update(
                pct,
                f'Go to: [B][COLOR skyblue]{verification_url}[/COLOR][/B]\n\n'
                f'Enter code: [B][COLOR yellow]{user_code}[/COLOR][/B]\n\n'
                f'Time left: {int(expires_in - elapsed)}s'
            )
            time.sleep(interval)
            outcome = poll_fn()
            if outcome == 'success':
                prog.close()
                return True
            elif outcome == 'denied':
                prog.close()
                return False
        prog.close()
        return False

    result = [False]

    def _poll():
        start = time.time()
        while not dialog.canceled:
            time.sleep(interval)
            elapsed  = time.time() - start
            remaining = max(0, expires_in - elapsed)
            if remaining <= 0:
                dialog.close()
                return
            dialog.update_remaining(remaining)
            try:
                outcome = poll_fn()
            except Exception as exc:
                xbmc.log(f'Trakt: auth poll error: {exc}', xbmc.LOGWARNING)
                continue
            if outcome == 'success':
                result[0] = True
                dialog.mark_authorized()
                return
            if outcome == 'denied':
                dialog.mark_denied()
                return

    t = threading.Thread(target=_poll, daemon=True)
    t.start()
    dialog.doModal()
    t.join(timeout=10)

    try:
        if qr_path and os.path.exists(qr_path):
            os.remove(qr_path)
    except Exception:
        pass

    return result[0]

# ── device-code OAuth flow ───────────────────────────────────────────────

def authorize():
    """Run device-code auth, show dialog with user_code, poll for token."""
    cid, csec = _credentials()
    status, data, _ = _http_json(f'{API_BASE}/oauth/device/code', method='POST', payload={'client_id': cid})
    if status != 200 or not isinstance(data, dict) or not data.get('device_code'):
        xbmcgui.Dialog().ok('Trakt', f'Failed to get device code\nStatus: {status}')
        return False

    device_code = data['device_code']
    user_code = data.get('user_code', '')
    verification_url = data.get('verification_url') or 'https://trakt.tv/activate'
    expires_in = int(data.get('expires_in') or 600)
    interval = max(2, int(data.get('interval') or 5))

    token_url = f'{API_BASE}/oauth/device/token'
    payload = {'code': device_code, 'client_id': cid, 'client_secret': csec}

    def _poll():
        status, data, _ = _http_json(token_url, method='POST', payload=payload)
        if status == 200 and isinstance(data, dict) and data.get('access_token'):
            _save_token(data)
            try:
                ADDON.setSetting('trakt_auth_done', 'true')
            except Exception:
                pass
            me = get_me()
            if me and me.get('user'):
                uname = me['user'].get('username', '')
                try:
                    ADDON.setSetting('trakt_username', uname)
                except Exception:
                    pass
            return 'success'
        
        if status in (404, 409, 410, 418):
            xbmc.log(f'Trakt auth poll failed with terminal error: {status}', xbmc.LOGWARNING)
            return 'denied'

        return None

    ok = _run_device_auth_window(
        service_name='Trakt',
        user_code=user_code,
        verification_url=verification_url,
        expires_in=expires_in,
        interval=interval,
        poll_fn=_poll
    )

    if ok:
        xbmcgui.Dialog().notification('Trakt', 'Authorization successful', xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().notification('Trakt', 'Authorization timed out or was cancelled.', xbmcgui.NOTIFICATION_WARNING, 3500)
    return ok


def revoke():
    tok = _load_token()
    if tok and tok.get('access_token'):
        cid, csec = _credentials()
        _http_json(
            f'{OAUTH_BASE}/oauth/revoke',
            method='POST',
            payload={
                'token': tok['access_token'],
                'client_id': cid,
                'client_secret': csec,
            },
        )
    _delete_token()
    xbmcgui.Dialog().notification('Trakt', 'Unlinked',
                                  xbmcgui.NOTIFICATION_INFO, 2500)


# ── API wrappers ─────────────────────────────────────────────────────────

def get_summary(kind, media_id, season=None, episode=None):
    """Hydrate snapshot metadata from canonical summaries (15-minute cache).

    Activity, watch state and list membership must still come from their
    original endpoints; this cache contains only public media metadata.
    """
    from urllib.parse import quote
    if not media_id or kind not in ('movie', 'show', 'episode'):
        return {}
    ident = quote(str(media_id), safe='')
    if kind == 'episode':
        try:
            path = '/shows/%s/seasons/%d/episodes/%d' % (
                ident, int(season), int(episode))
        except (TypeError, ValueError):
            return {}
    else:
        path = '/%ss/%s' % (kind, ident)
    cache_dir = os.path.join(DATA_PATH, 'trakt_summaries')
    cache_file = os.path.join(cache_dir, hashlib.sha256(path.encode('utf-8')).hexdigest() + '.json')
    try:
        with open(cache_file, encoding='utf-8') as stream:
            cached = json.load(stream)
        age = time.time() - float(cached['saved_at'])
        if 0 <= age < 900 and isinstance(cached.get('data'), dict):
            return cached['data']
    except (OSError, ValueError, TypeError, KeyError):
        pass
    data = _get(path, params={'extended': 'full'})
    if not isinstance(data, dict) or not data.get('ids'):
        return {}
    temp_path = None
    try:
        os.makedirs(cache_dir, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                                         dir=cache_dir, delete=False) as stream:
            temp_path = stream.name
            json.dump({'saved_at': time.time(), 'data': data}, stream)
        os.replace(temp_path, cache_file)
    except OSError:
        pass
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)
    return data

def _get(path, params=None, paginated=False, limit=100, max_pages=50, timeout=20):
    """GET helper. If paginated, follow X-Pagination-Page-Count until done."""
    hdr = _auth_headers()
    if not hdr:
        xbmc.log('Trakt GET: No auth headers available - user may not be authorized', xbmc.LOGWARNING)
        return None
    url = f'{API_BASE}{path}'
    if params:
        from urllib.parse import urlencode
        url = f'{url}?{urlencode(params)}'

    if not paginated:
        status, data, _ = _http_json(url, headers=hdr, timeout=timeout)
        if status == 401:
            xbmc.log('Trakt GET: 401 Unauthorized - attempting token refresh', xbmc.LOGWARNING)
            failed_token = (_load_token() or {}).get('refresh_token')
            if _refresh_token(expected_refresh_token=failed_token, force=True):
                hdr = _auth_headers()
                status, data, _ = _http_json(url, headers=hdr, timeout=timeout)
        if 200 <= status < 300:
            xbmc.log(f'Trakt GET {path} -> {status} SUCCESS', xbmc.LOGINFO)
            return data
        xbmc.log(f'Trakt GET {path} -> {status} FAILED', xbmc.LOGWARNING)
        return None

    # Paginated
    from urllib.parse import urlencode
    results = []
    page = 1
    while page <= max_pages:
        p = dict(params or {})
        p['page'] = page
        p['limit'] = limit
        u = f'{API_BASE}{path}?{urlencode(p)}'
        status, data, headers = _http_json(u, headers=hdr, timeout=timeout)
        if status == 401:
            failed_token = (_load_token() or {}).get('refresh_token')
        else:
            failed_token = None
        if status == 401 and _refresh_token(expected_refresh_token=failed_token, force=True):
            hdr = _auth_headers()
            status, data, headers = _http_json(u, headers=hdr, timeout=timeout)
        if not (200 <= status < 300) or not isinstance(data, list):
            xbmc.log(f'Trakt GET paginated {path} page {page} -> {status} FAILED', xbmc.LOGWARNING)
            break
        results.extend(data)
        page_count = next(
            (value for key, value in headers.items()
             if str(key).lower() == 'x-pagination-page-count'),
            None,
        )
        try:
            total_pages = int(page_count or 1)
        except (TypeError, ValueError):
            total_pages = 1
        xbmc.log(f'Trakt GET paginated {path} page {page}/{total_pages} -> {len(data)} items', xbmc.LOGINFO)
        if page >= total_pages or not data or (page_count is None and len(data) < limit):
            break
        page += 1
    xbmc.log(f'Trakt GET paginated {path} -> TOTAL {len(results)} items', xbmc.LOGINFO)
    return results


def _post(path, payload=None):
    hdr = _auth_headers()
    if not hdr:
        return None, None
    status, data, _ = _http_json(
        f'{API_BASE}{path}', method='POST', payload=payload or {}, headers=hdr,
    )
    if status == 401:
        failed_token = (_load_token() or {}).get('refresh_token')
    else:
        failed_token = None
    if status == 401 and _refresh_token(expected_refresh_token=failed_token, force=True):
        hdr = _auth_headers()
        status, data, _ = _http_json(
            f'{API_BASE}{path}', method='POST', payload=payload or {}, headers=hdr,
        )
    return status, data


def _delete(path):
    hdr = _auth_headers()
    if not hdr:
        return None
    status, _data, _ = _http_json(f'{API_BASE}{path}', method='DELETE', headers=hdr)
    if status == 401:
        failed_token = (_load_token() or {}).get('refresh_token')
    else:
        failed_token = None
    if status == 401 and _refresh_token(expected_refresh_token=failed_token, force=True):
        hdr = _auth_headers()
        status, _data, _ = _http_json(f'{API_BASE}{path}', method='DELETE', headers=hdr)
    return status


def get_me():
    """GET /users/settings — current user info."""
    return _get('/users/settings')


def get_my_lists(page=1, limit=20):
    """GET /users/me/lists — custom personal lists."""
    return get_user_lists('me', page=page, limit=limit)


def get_watchlist(media='movies', sort='added', page=1, limit=20):
    """GET /users/me/watchlist/{movies|shows}/{sort}."""
    return _get(f'/users/me/watchlist/{media}/{sort}',
                params={'page': page, 'limit': limit}) or []


def get_history(media='movies', page=1, limit=20):
    """GET /users/{username}/history/{movies|shows} (paginated)."""
    from urllib.parse import quote
    username = (ADDON.getSetting('trakt_username') or '').strip()
    if not username:
        me = get_me()
        username = ((me or {}).get('user') or {}).get('username', '').strip()
        if username:
            try:
                ADDON.setSetting('trakt_username', username)
            except Exception:
                pass
    if not username:
        xbmc.log('Trakt history: username is unavailable', xbmc.LOGWARNING)
        return []
    username = quote(username, safe='')
    return _get(f'/users/{username}/history/{media}',
                params={'page': page, 'limit': limit}) or []


def get_watched(media='movies'):
    """GET Trakt's current watched library for movies or shows.

    Trakt's history endpoint contains play events, while the website's
    watched checkmark is represented by this endpoint.  Keeping this
    separate lets the UI use the correct official source when an item has a
    watched state but no recent history event.
    """
    from urllib.parse import quote
    username = (ADDON.getSetting('trakt_username') or '').strip()
    if not username:
        me = get_me()
        username = ((me or {}).get('user') or {}).get('username', '').strip()
        if username:
            try:
                ADDON.setSetting('trakt_username', username)
            except Exception:
                pass
    if not username:
        xbmc.log('Trakt watched: username is unavailable', xbmc.LOGWARNING)
        return []
    username = quote(username, safe='')
    return _get(f'/users/{username}/watched/{media}', paginated=True, limit=250) or []


def _playback_cache_file():
    # Scope private progress to the current authorization; never share accounts.
    token = (_load_token() or {}).get('access_token') or ''
    scope = hashlib.sha256(str(token).encode('utf-8')).hexdigest()
    return os.path.join(DATA_PATH, 'trakt_playback_' + scope + '.json')


def _invalidate_playback_cache():
    for path in (_playback_cache_file(), _playback_cache_file() + '.next'):
        try:
            os.remove(path)
        except OSError:
            pass


def get_playback_items():
    """GET /sync/playback, cached for two minutes across Kodi invocations.

    Optional pagination is omitted to get the complete list in one request.
    Failed reads are briefly cached too, preventing repeated menu retries.
    """
    if not is_authorized():
        return []
    cache_file = _playback_cache_file()
    try:
        with open(cache_file, encoding='utf-8') as stream:
            cached = json.load(stream)
        if 0 <= time.time() - float(cached['saved_at']) < 120:
            if isinstance(cached.get('items'), list):
                return cached['items']
    except (OSError, ValueError, TypeError, KeyError):
        pass
    data = _get('/sync/playback', timeout=8)
    items = data if isinstance(data, list) else []
    temp_path = None
    try:
        os.makedirs(DATA_PATH, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                                         dir=DATA_PATH, delete=False) as stream:
            temp_path = stream.name
            json.dump({'saved_at': time.time(), 'items': items}, stream)
        os.replace(temp_path, _playback_cache_file())
    except OSError:
        pass
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)
    return items



def get_continue_watching_items():
    """Combine paused playback with Trakt's own next_episode suggestions.

    Only inspect the 15 most recently watched shows. Per-show progress is
    cached for 15 minutes, avoiding a library-wide request on each visit.
    """
    if not is_authorized():
        return []
    playback = get_playback_items()
    paused_shows = {
        str((item.get('show') or {}).get('ids', {}).get('trakt'))
        for item in playback if isinstance(item, dict) and item.get('show')
    }
    cache_file = _playback_cache_file() + '.next'
    try:
        with open(cache_file, encoding='utf-8') as stream:
            cached = json.load(stream)
        if 0 <= time.time() - float(cached['saved_at']) < 900:
            suggestions = cached['items']
            if isinstance(suggestions, list):
                return playback + [item for item in suggestions
                    if str(item['show']['ids'].get('trakt')) not in paused_shows]
    except (OSError, ValueError, TypeError, KeyError):
        pass
    watched = _get('/sync/watched/shows', timeout=8)
    if not isinstance(watched, list):
        watched = []
    watched = sorted((item for item in watched if isinstance(item, dict)),
                     key=lambda item: item.get('last_watched_at') or '', reverse=True)
    suggestions = []
    for item in watched[:15]:
        show = item.get('show') or {}
        ident = (show.get('ids') or {}).get('trakt')
        if not ident:
            continue
        data = _get('/shows/%s/progress/watched' % int(ident),
                    params={'last_activity': 'watched'}, timeout=8)
        # Fail promptly on API errors instead of continuing a request burst.
        if data is None:
            break
        episode = data.get('next_episode') if isinstance(data, dict) else None
        if not isinstance(episode, dict):
            continue
        suggestions.append({'show': show, 'episode': episode,
                            'is_next_episode': True, 'progress': 0,
                            'last_watched_at': item.get('last_watched_at')})
    temp_path = None
    try:
        os.makedirs(DATA_PATH, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                                         dir=DATA_PATH, delete=False) as stream:
            temp_path = stream.name
            json.dump({'saved_at': time.time(), 'items': suggestions}, stream)
        os.replace(temp_path, _playback_cache_file() + '.next')
    except OSError:
        pass
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)
    return playback + [item for item in suggestions
                       if str(item['show']['ids'].get('trakt')) not in paused_shows]


def get_discover_items(kind='movies', category='trending', page=1):
    """Fetch one discovery page; reuse results for 15 minutes.

    Public catalogs still require authorization in the Cosmos menu. Request
    full metadata once per page instead of fetching a summary for each row.
    """
    if not is_authorized():
        return []
    if kind not in ('movies', 'shows') or category not in (
            'trending', 'popular', 'anticipated', 'watched'):
        return []
    try:
        page = max(1, int(page))
    except (TypeError, ValueError):
        page = 1
    path = '/%s/%s' % (kind, category)
    if category == 'watched':
        path += '/weekly'
    cache_file = _playback_cache_file() + '.discover-%s-%s-%d' % (kind, category, page)
    try:
        with open(cache_file, encoding='utf-8') as stream:
            cached = json.load(stream)
        if 0 <= time.time() - float(cached['saved_at']) < float(cached['ttl']):
            if isinstance(cached.get('items'), list):
                return cached['items']
    except (OSError, ValueError, TypeError, KeyError):
        pass
    data = _get(path, params={'page': page, 'limit': 20, 'extended': 'full'}, timeout=8)
    node_key = 'movie' if kind == 'movies' else 'show'
    items = []
    if isinstance(data, list):
        for item in data:
            if not isinstance(item, dict):
                continue
            # Popular returns bare media objects; other catalogs wrap them.
            node = item.get(node_key) if node_key in item else item
            if isinstance(node, dict) and node.get('ids'):
                items.append({node_key: node})
    temp_path = None
    try:
        os.makedirs(DATA_PATH, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                                         dir=DATA_PATH, delete=False) as stream:
            temp_path = stream.name
            json.dump({'saved_at': time.time(), 'ttl': 900 if isinstance(data, list) else 120,
                       'items': items}, stream)
        os.replace(temp_path, cache_file)
    except OSError:
        pass
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)
    return items


def search_items(query, kind='movie,show', page=1):
    """GET /search/{type}, one submitted query/page, cached 15 minutes."""
    query = ' '.join(str(query or '').split())
    if not is_authorized() or not query or kind not in ('movie', 'show', 'movie,show'):
        return []
    try:
        page = max(1, int(page))
    except (TypeError, ValueError):
        page = 1
    key = hashlib.sha256(json.dumps([kind, query, page]).encode('utf-8')).hexdigest()
    cache_file = _playback_cache_file() + '.search-' + key
    try:
        with open(cache_file, encoding='utf-8') as stream:
            cached = json.load(stream)
        if 0 <= time.time() - float(cached['saved_at']) < float(cached['ttl']):
            if isinstance(cached.get('items'), list):
                return cached['items']
    except (OSError, ValueError, TypeError, KeyError):
        pass
    # Treat punctuation as literal title text, not search-engine operators.
    literal_query = ''.join(('\\' + char) if char in
                           '+-&|!(){}[]^"~*?:/\\' else char for char in query)
    data = _get('/search/' + kind,
                params={'query': literal_query, 'page': page, 'limit': 20,
                        'extended': 'full'}, timeout=8)
    items = [item for item in data if isinstance(item, dict) and
             (isinstance(item.get('movie'), dict) or isinstance(item.get('show'), dict))
             ] if isinstance(data, list) else []
    temp_path = None
    try:
        os.makedirs(DATA_PATH, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                                         dir=DATA_PATH, delete=False) as stream:
            temp_path = stream.name
            json.dump({'saved_at': time.time(), 'ttl': 900 if isinstance(data, list) else 120,
                       'items': items}, stream)
        os.replace(temp_path, cache_file)
    except OSError:
        pass
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)
    return items


def get_following(page=1, limit=20, all_pages=False):
    """GET /users/me/following — users I follow."""
    rows = _get('/users/me/following') or []
    if all_pages:
        return rows
    start = (max(1, int(page)) - 1) * limit
    return rows[start:start + limit]


def get_liked_lists(page=1, limit=20):
    """GET /users/likes/lists — lists I've liked (followed)."""
    return _get('/users/likes/lists', params={'page': page, 'limit': limit}) or []


def get_user_lists(user_id, page=1, limit=20, all_pages=False):
    """GET /users/{id}/lists — public custom lists of another user."""
    # This endpoint returns all lists; page/limit are not API parameters.
    rows = _get(f'/users/{user_id}/lists') or []
    if all_pages:
        return rows
    start = (max(1, int(page)) - 1) * limit
    return rows[start:start + limit]


def get_list_items(user_id, list_id, page=1, limit=20, all_pages=False):
    """GET /users/{id}/lists/{list_id}/items"""
    if all_pages:
        return _get(f'/users/{user_id}/lists/{list_id}/items',
                    paginated=True, limit=limit) or []
    return _get(f'/users/{user_id}/lists/{list_id}/items',
                params={'page': page, 'limit': limit}) or []


def like_list(user_id, list_id):
    """POST /users/{id}/lists/{list_id}/like"""
    status, _ = _post(f'/users/{user_id}/lists/{list_id}/like')
    return status in (200, 201, 204)


# ── Scrobble / Watchlist (P2) ────────────────────────────────────────────

def _build_media(meta):
    """Return ({'movie'|'show'+'episode': {...}}, is_episode) from a meta
    dict containing content, tmdb, imdb, season, episode.

    Returns (None, False) if the meta is insufficient for scrobbling
    (e.g. a show with no season/episode).
    """
    if not meta:
        return None, False
    content = (str(meta.get('content') or 'movie')).lower()
    season = meta.get('season')
    episode = meta.get('episode')

    ids = {}
    supplied_ids = meta.get('ids') if isinstance(meta.get('ids'), dict) else {}
    for key in ('tmdb', 'trakt', 'tvdb'):
        value = meta.get(key) or meta.get(key + '_id') or supplied_ids.get(key)
        try:
            number = int(str(value))
            if number > 0:
                ids[key] = number
        except (TypeError, ValueError):
            pass
    imdb = str(meta.get('imdb') or supplied_ids.get('imdb') or '').strip()
    if imdb and imdb.startswith('tt'):
        ids['imdb'] = imdb
    if not ids:
        return None, False

    is_tv = content not in ('movie', '')
    if not is_tv:
        return {'movie': {'ids': ids}}, False

    try:
        s_no = int(str(season)) if season not in (None, '') else None
        e_no = int(str(episode)) if str(episode or '').strip() != '' else None
    except (TypeError, ValueError):
        s_no = e_no = None
    if s_no is None or e_no is None or s_no < 0 or e_no < 1:
        return None, False
    # For shows use tmdb at the SHOW level (ids are the show's tmdb id)
    return (
        {'show': {'ids': ids},
         'episode': {'season': s_no, 'number': e_no}},
        True,
    )


def _scrobble(verb, meta, progress, require_watched=False):
    """POST /scrobble/{start|pause|stop}. Returns True on success.

    With require_watched, only a server-confirmed scrobble counts as watched.

    Silently no-ops if Trakt is not authorised or the meta dict is not
    scrobble-able. Uses a short HTTP timeout so it never blocks playback.
    """
    if verb not in ('start', 'pause', 'stop'):
        return False
    if not is_authorized():
        xbmc.log(f'Trakt scrobble {verb}: Not authorized - skipping', xbmc.LOGINFO)
        return False
    media, _ = _build_media(meta)
    if not media:
        xbmc.log(f'Trakt scrobble {verb}: Invalid media meta (missing tmdb/imdb or episode info) - skipping', xbmc.LOGWARNING)
        xbmc.log('Trakt scrobble: building payload', xbmc.LOGDEBUG)
        return False
    hdr = _auth_headers()
    if not hdr:
        xbmc.log(f'Trakt scrobble {verb}: No auth headers', xbmc.LOGWARNING)
        return False
    try:
        p = float(progress or 0)
        if not math.isfinite(p):
            raise ValueError
    except (TypeError, ValueError, OverflowError):
        p = 0.0
    p = max(0.0, min(100.0, p))
    payload = dict(media)
    payload['progress'] = p
    payload['app_version'] = APP_VERSION
    
    xbmc.log(f'Trakt scrobble {verb}: progress={p:.1f}%, media={media}', xbmc.LOGINFO)
    
    status, _data, _ = _http_json(
        f'{API_BASE}/scrobble/{verb}',
        method='POST', payload=payload, headers=hdr, timeout=8,
    )
    if status == 401:
        failed_token = (_load_token() or {}).get('refresh_token')
    else:
        failed_token = None
    if status == 401 and _refresh_token(expected_refresh_token=failed_token, force=True):
        hdr = _auth_headers()
        status, _data, _ = _http_json(
            f'{API_BASE}/scrobble/{verb}',
            method='POST', payload=payload, headers=hdr, timeout=8,
        )
    ok = 200 <= (status or 0) < 300
    if ok:
        xbmc.log(f'Trakt scrobble {verb} -> {status} SUCCESS', xbmc.LOGINFO)
    else:
        xbmc.log(f'Trakt scrobble {verb} -> {status} FAILED', xbmc.LOGWARNING)
    if ok:
        _invalidate_playback_cache()
    if require_watched:
        return bool(ok and verb == 'stop' and isinstance(_data, dict)
                    and _data.get('action') == 'scrobble')
    return ok


def scrobble_start(meta, progress=0.0):
    return _scrobble('start', meta, progress)


def scrobble_pause(meta, progress=0.0):
    return _scrobble('pause', meta, progress)


def scrobble_stop(meta, progress=0.0):
    return _scrobble('stop', meta, progress)


def _watchlist_payload(content, tmdb='', imdb='', trakt_id='',
                       season=None, episode=None):
    """Build a /sync/watchlist payload for a movie, show or episode."""
    ids = {}
    if tmdb:
        try:
            ids['tmdb'] = int(str(tmdb))
        except (TypeError, ValueError):
            pass
    if imdb and str(imdb).startswith('tt'):
        ids['imdb'] = imdb
    if trakt_id:
        try:
            ids['trakt'] = int(str(trakt_id))
        except (TypeError, ValueError):
            pass
    if not ids:
        return None

    kind = (content or 'movie').lower()
    if kind == 'movie':
        return {'movies': [{'ids': ids}]}

    # Shows / episodes
    try:
        s_no = int(str(season)) if season not in (None, '') else None
        e_no = int(str(episode)) if str(episode or '').strip() != '' else None
    except (TypeError, ValueError):
        s_no = e_no = None
    if s_no is not None and e_no is not None:
        # Nested episode under show (tmdb/imdb here are the SHOW's ids).
        return {'shows': [{
            'ids': ids,
            'seasons': [{
                'number': s_no,
                'episodes': [{'number': e_no}],
            }],
        }]}
    return {'shows': [{'ids': ids}]}


def _sync_write_succeeded(status, data):
    """A successful HTTP status can still contain an unmatched item."""
    if not 200 <= (status or 0) < 300 or not isinstance(data, dict):
        return False
    not_found = data.get('not_found') or {}
    return isinstance(not_found, dict) and not any(not_found.values())


def add_to_watchlist(content, tmdb='', imdb='', trakt_id='',
                     season=None, episode=None):
    """POST /sync/watchlist. Returns True on success."""
    payload = _watchlist_payload(content, tmdb, imdb, trakt_id, season, episode)
    if not payload:
        return False
    status, data = _post('/sync/watchlist', payload=payload)
    if not status or not (200 <= status < 300):
        xbmc.log(f'Trakt add_to_watchlist -> {status}', xbmc.LOGWARNING)
        return False
    # Trakt returns {"added": {...}, "not_found": {...}, ...}; treat any
    # added>0 as success, but also accept an empty-added response when the
    # item is already on the watchlist (Trakt silently dedupes).
    ok = _sync_write_succeeded(status, data)
    return ok


def remove_from_watchlist(content, tmdb='', imdb='', trakt_id='',
                          season=None, episode=None):
    """POST /sync/watchlist/remove. Returns True on success."""
    payload = _watchlist_payload(content, tmdb, imdb, trakt_id, season, episode)
    if not payload:
        return False
    status, data = _post('/sync/watchlist/remove', payload=payload)
    if not status or not (200 <= status < 300):
        xbmc.log(f'Trakt remove_from_watchlist -> {status}', xbmc.LOGWARNING)
        return False
    ok = _sync_write_succeeded(status, data)
    return ok

def add_to_history(content, tmdb='', imdb='', trakt_id='',
                     season=None, episode=None):
    """POST /sync/history. Returns True on success."""
    payload = _watchlist_payload(content, tmdb, imdb, trakt_id, season, episode)
    if not payload:
        return False
    
    import time
    watched_at = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

    if 'movies' in payload:
        for movie in payload['movies']:
            movie['watched_at'] = watched_at
    if 'shows' in payload:
        for show in payload['shows']:
            if 'seasons' in show:
                for s in show['seasons']:
                    if 'episodes' in s:
                        for ep in s['episodes']:
                            ep['watched_at'] = watched_at
            else: # whole show
                show['watched_at'] = watched_at
    
    status, data = _post('/sync/history', payload=payload)
    if not status or not (200 <= status < 300):
        xbmc.log(f'Trakt add_to_history -> {status}', xbmc.LOGWARNING)
        return False
    ok = _sync_write_succeeded(status, data)
    if ok:
        _invalidate_playback_cache()
    return ok

def unlike_list(user_id, list_id):
    """DELETE /users/{id}/lists/{list_id}/like"""
    return _delete(f'/users/{user_id}/lists/{list_id}/like') in (200, 204)


def _history_payload(content, tmdb='', imdb='', trakt_id='',
                       season=None, episode=None):
    """Build a /sync/history/remove payload for a movie, show or episode."""
    ids = {}
    if tmdb:
        try:
            ids['tmdb'] = int(str(tmdb))
        except (TypeError, ValueError):
            pass
    if imdb and str(imdb).startswith('tt'):
        ids['imdb'] = imdb
    if trakt_id:
        try:
            ids['trakt'] = int(str(trakt_id))
        except (TypeError, ValueError):
            pass
    if not ids:
        return None

    kind = (content or 'movie').lower()
    if kind == 'movie':
        return {'movies': [{'ids': ids}]}

    # Shows / episodes
    try:
        s_no = int(str(season)) if season not in (None, '') else None
        e_no = int(str(episode)) if str(episode or '').strip() != '' else None
    except (TypeError, ValueError):
        s_no = e_no = None
    if s_no is not None and e_no is not None:
        return {'shows': [{'ids': ids, 'seasons': [{'number': s_no, 'episodes': [{'number': e_no}]}]}]}
    return {'shows': [{'ids': ids}]}


def remove_from_history(content, tmdb='', imdb='', trakt_id='',
                        season=None, episode=None):
    """POST /sync/history/remove. Returns True on success."""
    payload = _history_payload(content, tmdb, imdb, trakt_id, season, episode)
    if not payload:
        return False
    status, data = _post('/sync/history/remove', payload=payload)
    ok = _sync_write_succeeded(status, data)
    if ok:
        _invalidate_playback_cache()
    return ok


def clear_history():
    """POST /sync/history/remove with empty payload to clear all history. Returns True on success."""
    # Trakt API documentation states that an empty payload to /sync/history/remove
    # will remove all history.
    status, data = _post('/sync/history/remove', payload={})
    return 200 <= (status or 0) < 300

# ── "Follow all lists" bulk action ───────────────────────────────────────

def follow_all_lists_from_following():
    """Iterate every user I follow and `like` (follow) each of their
    public custom lists that I don't already like. Returns (liked, skipped,
    failed) counts. Respects Trakt's 1-req/sec rate limit."""
    if not is_authorized():
        return 0, 0, 0

    following = get_following(all_pages=True) or []
    already = get_liked_lists() or []
    already_keys = set()
    for row in already:
        lst = row.get('list') or {}
        owner = ((lst.get('user') or {}).get('ids') or {}).get('slug', '')
        lid = (lst.get('ids') or {}).get('trakt', '')
        if owner and lid:
            already_keys.add(f'{owner}:{lid}')

    prog = xbmcgui.DialogProgressBG()
    prog.create('Trakt', f'Scanning {len(following)} followed users...')
    liked = skipped = failed = 0
    try:
        for i, f in enumerate(following):
            user = f.get('user') or {}
            slug = (user.get('ids') or {}).get('slug') or user.get('username', '')
            if not slug:
                continue
            prog.update(int((i / max(1, len(following))) * 100),
                        'Trakt', f'@{slug} — fetching lists')
            lists = get_user_lists(slug, all_pages=True) or []
            for lst in lists:
                lid = (lst.get('ids') or {}).get('trakt', '')
                if not lid:
                    continue
                if f'{slug}:{lid}' in already_keys:
                    skipped += 1
                    continue
                if like_list(slug, lid):
                    liked += 1
                else:
                    failed += 1
                time.sleep(1.1)  # Trakt rate limit ~1 POST/sec
    finally:
        try:
            prog.close()
        except Exception:
            pass
    return liked, skipped, failed
