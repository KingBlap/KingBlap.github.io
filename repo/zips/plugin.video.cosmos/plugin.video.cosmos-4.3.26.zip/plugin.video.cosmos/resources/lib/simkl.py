# -*- coding: utf-8 -*-
"""
Simkl integration for C.O.S.M.O.S.

Minimal tracker support for auth, watchlist syncing, and history marking.
"""
import json
import math
import os
import hashlib
import base64
import secrets
import sys
import time
import threading
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import urlencode, urlparse, urlsplit, parse_qs, quote_plus
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from . import tmdb as tmdb_mod
from .auth_dialog import AuthDialog


ADDON_ID = 'plugin.video.cosmos'
ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/')
ICON_SIMKL = os.path.join(ADDON_PATH, 'resources', 'media', 'icon_simkl.png')
DATA_PATH = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
TOKEN_FILE = os.path.join(DATA_PATH, 'simkl_token.json')
TRAKT_IMPORT_FILE = os.path.join(DATA_PATH, 'trakt_simkl_imports.json')
NEXT_EPISODES_CACHE_FILE = os.path.join(DATA_PATH, 'simkl_next_episodes.json')
LIST_CACHE_FILE = os.path.join(DATA_PATH, 'simkl_lists_cache.json')
SIMKL_MENU_CACHE_TTL = 15 * 60
# .org hosts documentation; authenticated API traffic belongs on .com.
API_BASE = 'https://api.simkl.com'
APP_NAME = 'cosmos-kodi'
APP_VERSION = ADDON.getAddonInfo('version')
UA = f'{APP_NAME}/{APP_VERSION}'
DEFAULT_CLIENT_ID = '4e7b8df6be59ea7f70f3b056fb28d50c14b0e148dfd4cfe02ac8b8a37abcaddc'
LEGACY_CLIENT_ID = 'ad8431d5f7dca2827ca626a6922ba0a8cfa090963f79422114dfb358c26ee527'
DEFAULT_CLIENT_SECRET = ''
SIMKL_SCOPE = 'media:read media:write'


def _log(message, level=xbmc.LOGINFO):
    """Write Simkl diagnostics with a searchable Kodi-log prefix."""
    xbmc.log(f'[COSMOS Simkl] {message}', level)


def _debug_bundle_event(tag, detail):
    """Write safe Simkl request diagnostics to the optional Cosmos bundle."""
    try:
        from . import debug_bundle
        if debug_bundle.is_enabled():
            debug_bundle.log('Simkl ' + str(tag), detail)
    except Exception:
        pass


def _debug_http_result(method, url, status, data=None):
    """Record an HTTP outcome without exporting query strings or request data."""
    path = urlsplit(url).path
    summary = f'{str(method or "GET").upper()} {path} -> HTTP {status}'
    if status in (400, 401) and isinstance(data, dict):
        error = data.get('error') or data.get('code') or ''
        description = (data.get('error_description') or data.get('message')
                       or data.get('detail') or '')

        def clean(value, limit):
            return ' '.join(str(value).replace('\r', ' ').replace('\n', ' ').split())[:limit]

        error = clean(error, 100)
        description = clean(description, 240)
        if error:
            summary += f'; error={error}'
        if description:
            summary += f'; description={description}'
    _debug_bundle_event('HTTP', summary)


def _pkce_pair():
    verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(verifier.encode('ascii')).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b'=').decode('ascii')
    return verifier, challenge

TRAKT_IMPORT_DESTINATIONS = (
    ('Plan to Watch', 'plantowatch'),
    ('Watching', 'watching'),
    ('Completed', 'completed'),
    ('On Hold', 'hold'),
    ('Dropped', 'dropped'),
)

_request_lock = threading.Lock()
_scrobble_lock = threading.Lock()
_token_refresh_lock = threading.Lock()
_last_request_time = 0.0
_CUSTOM_LIST_CACHE = {}

_SYNC_WRITE_PATHS = frozenset((
    '/sync/history',
    '/sync/history/remove',
    '/sync/add-to-list',
    '/sync/ratings',
    '/sync/ratings/remove',
    '/sync/watched',
))
_TRANSIENT_STATUSES = frozenset((429, 500, 502, 503))
_MAX_TRANSIENT_ATTEMPTS = 5
_MAX_RETRY_DELAY = 60

def _throttle():
    from . import simkl_store
    simkl_store.throttle(DATA_PATH)


def _ensure_dir():
    if not xbmcvfs.exists(DATA_PATH):
        xbmcvfs.mkdirs(DATA_PATH)
    if not os.path.isdir(DATA_PATH):
        os.makedirs(DATA_PATH, exist_ok=True)


def _simkl_icon():
    """Return the path to the Simkl icon, falling back to the default addon icon."""
    return ICON_SIMKL if xbmcvfs.exists(ICON_SIMKL) else f'{ADDON_PATH}icon.png'


def _save_token(data, refreshing=False):
    _ensure_dir()
    if not refreshing:
        ADDON.setSetting('simkl_cache_identity', secrets.token_hex(16))
        ADDON.setSetting('simkl_user_id', '')
        ADDON.setSetting('simkl_username', '')
    data = dict(data or {})
    data['stored_at'] = int(time.time())
    try:
        with open(TOKEN_FILE, 'w', encoding='utf-8') as fp:
            json.dump(data, fp)
        try:
            os.chmod(TOKEN_FILE, 0o600)
        except OSError:
            pass
    except OSError as e:
        xbmc.log(f'Simkl save token failed: {e}', xbmc.LOGERROR)
    # Also save to settings for ReAuth compatibility
    try:
        ADDON.setSetting('simkl_access_token', data.get('access_token', ''))
        ADDON.setSetting('simkl_refresh_token', data.get('refresh_token', ''))
        ADDON.setSetting('simkl_expires_in', str(data.get('expires_in', '')))
        ADDON.setSetting('simkl_stored_at', str(data.get('stored_at', '')))
    except Exception as e:
        xbmc.log(f'Simkl save token to settings failed: {e}', xbmc.LOGWARNING)


def _load_token():
    # Try settings first for ReAuth compatibility
    access_token = ADDON.getSetting('simkl_access_token')
    if access_token:
        try:
            expires_in = int(ADDON.getSetting('simkl_expires_in'))
        except (ValueError, TypeError):
            expires_in = 0
        try:
            stored_at = int(ADDON.getSetting('simkl_stored_at'))
        except (ValueError, TypeError):
            stored_at = 0
        
        token_data = {
            'access_token': access_token,
            'refresh_token': ADDON.getSetting('simkl_refresh_token'),
            'expires_in': expires_in,
            # Older installs did not persist the token timestamp. Treat those
            # tokens as long-lived until Simkl rejects them instead of forcing
            # a refresh on every API operation.
            'stored_at': stored_at,
        }
        return token_data

    # Fallback to file
    if os.path.isfile(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, 'r', encoding='utf-8') as fp:
                return json.load(fp)
        except (OSError, ValueError):
            pass
    return None

def _delete_token():
    try:
        if os.path.isfile(TOKEN_FILE):
            os.remove(TOKEN_FILE)
    except OSError:
        pass
    try:
        ADDON.setSetting('simkl_access_token', '')
        ADDON.setSetting('simkl_refresh_token', '')
        ADDON.setSetting('simkl_expires_in', '')
        ADDON.setSetting('simkl_auth_done', 'false')
        ADDON.setSetting('simkl_username', '')
        ADDON.setSetting('simkl_user_id', '')
    except Exception:
        pass


def _load_trakt_imports():
    """Load the local record of Trakt-list imports made by this add-on."""
    if not os.path.isfile(TRAKT_IMPORT_FILE):
        return []
    try:
        with open(TRAKT_IMPORT_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save_trakt_import(record):
    """Keep the source list name and last import result in Kodi profile data."""
    _ensure_dir()
    key = (
        str(record.get('source_user') or '').lower(),
        str(record.get('list_id') or ''),
    )
    records = [
        item for item in _load_trakt_imports()
        if (
            str(item.get('source_user') or '').lower(),
            str(item.get('list_id') or ''),
        ) != key
    ]
    records.append(dict(record))
    try:
        with open(TRAKT_IMPORT_FILE, 'w', encoding='utf-8') as fp:
            json.dump(records[-100:], fp, ensure_ascii=False, indent=2)
        try:
            os.chmod(TRAKT_IMPORT_FILE, 0o600)
        except OSError:
            pass
    except OSError as e:
        xbmc.log(f'Simkl: save Trakt import record failed: {e}', xbmc.LOGWARNING)


def get_trakt_import_record(source_user, list_id):
    """Return the last local import record for a Trakt list, if any."""
    source_user = str(source_user or '').lower()
    list_id = str(list_id or '')
    for record in reversed(_load_trakt_imports()):
        if (str(record.get('source_user') or '').lower(),
                str(record.get('list_id') or '')) == (source_user, list_id):
            return record
    return None


def _credentials():
    cid = (ADDON.getSetting('simkl_client_id') or '').strip() or DEFAULT_CLIENT_ID
    if cid == LEGACY_CLIENT_ID:
        cid = DEFAULT_CLIENT_ID
    # The registered Simkl app is a public device client.  Ignore any legacy
    # secret left in Kodi settings and never send a client_secret to AUTH V2.
    csec = ''
    return cid, csec


def _build_api_url(path, params=None):
    cid, _ = _credentials()
    query = {'client_id': cid, 'app-name': APP_NAME, 'app-version': APP_VERSION}
    if params:
        query.update(params)
    return f'{API_BASE}{path}?{urlencode(query)}'


_LAST_API_ERROR = ''


def _account_cache_key():
    identity = ADDON.getSetting('simkl_cache_identity')
    if identity:
        return identity
    token = (_load_token() or {}).get('access_token') or ''
    identity = hashlib.sha256(token.encode('utf-8')).hexdigest()
    ADDON.setSetting('simkl_cache_identity', identity)
    return identity


def _sync_snapshot(force=False, resource=None):
    from . import simkl_store
    if not is_authorized():
        return None, False
    try:
        result, ok = simkl_store.sync(DATA_PATH, _account_cache_key(),
            lambda path, **kwargs: _http_json(path, method='POST' if path == '/users/settings' else 'GET',
                                             headers=_auth_headers(), **kwargs),
            force=force, resource=resource)
        if not ok:
            _log('Sync incomplete; retaining previous snapshot and cursor', xbmc.LOGWARNING)
        return result, ok
    except (OSError, simkl_store.sqlite3.Error) as exc:
        _log(f'Sync cache unavailable: {exc}', xbmc.LOGWARNING)
        return None, False


def _http_json(path, method='GET', payload=None, headers=None, timeout=20, params=None,
               _retry_rate_limit=True, _retry_auth=True):
    global _LAST_API_ERROR
    method = str(method or 'GET').upper()
    key = 'cooldown:' + _account_cache_key()
    cache = _load_list_cache()
    client_cooldown = cache.get('cooldown:client') or {}
    account_cooldown = cache.get(key) or {}
    cooldowns = [client_cooldown]
    if headers and headers.get('Authorization'):
        cooldowns.append(account_cooldown)
    cooldown = max(cooldowns, key=lambda item: float(item.get('until') or 0))
    if cooldown.get('until', 0) > time.time():
        status = int(cooldown.get('status') or 429)
        _LAST_API_ERROR = cooldown.get('message') or 'Simkl API limit reached; try later'
        _debug_bundle_event('COOLDOWN', f'{method} {path} -> HTTP {status}; request skipped')
        return status, {'error': cooldown.get('error') or 'rate_limit',
                        'message': _LAST_API_ERROR}, {}

    # Kodi directory requests must return control promptly.  The sync/cache
    # layer defers failed GETs and serves the last good snapshot, while
    # user-initiated writes use the documented exponential retry policy.
    attempts = (
        _MAX_TRANSIENT_ATTEMPTS
        if _retry_rate_limit and method != 'GET'
        else 1
    )
    delay = 1
    result = (0, None, {})
    for attempt in range(attempts):
        with _request_lock:
            result = _http_json_request(path, method, payload, headers, timeout, params)
        status, data, response_headers = result
        if status == 429 and isinstance(data, dict) and data.get('error') in (
                'user_limit_exceeded', 'app_limit_exceeded'):
            # Daily allowances cannot recover during a short retry loop.
            break
        if status not in _TRANSIENT_STATUSES or attempt >= attempts - 1:
            break

        if status == 429:
            # Daily errors already stop above. Burst errors clear in a second;
            # Retry-After on these can carry the unrelated daily reset.
            wait = 1
        else:
            wait = min(delay, _MAX_RETRY_DELAY)
        _log(
            f'{method} {path} transient HTTP {status}; '
            f'retry {attempt + 2}/{attempts} in {wait}s',
            xbmc.LOGWARNING,
        )
        _debug_bundle_event(
            'RETRY', f'{method} {urlsplit(_build_api_url(path, params=params)).path} '
            f'-> HTTP {status}; retry '
            f'{attempt + 2}/{attempts} after {wait}s',
        )
        time.sleep(wait)
        delay = min(delay * 2, _MAX_RETRY_DELAY)

    if _retry_rate_limit and _is_sync_write_rate_limit(path, method, result):
        _log(f'Simkl: sync write returned a rate-limit response; retrying once: {path}',
             xbmc.LOGWARNING)
        _debug_bundle_event(
            'RETRY', f'{method} {urlsplit(_build_api_url(path, params=params)).path} '
            '-> HTTP 400 rate_limit; retrying after 3s',
        )
        time.sleep(3)
        with _request_lock:
            result = _http_json_request(path, method, payload, headers, timeout, params)

    status, data, response_headers = result
    # Access tokens can be revoked or rotated between the proactive refresh
    # check and the actual request.  Red Light handles this by reloading the
    # settings database, refreshing once, and replaying the original request.
    # Do the same here, but never recurse more than once.
    if status == 401 and _retry_auth and headers and headers.get('Authorization'):
        failed_token = headers['Authorization'].removeprefix('Bearer ').strip()
        refreshed = _refresh_token(force=True, expected_access_token=failed_token)
        if refreshed:
            fresh_headers = _auth_headers()
            if fresh_headers:
                return _http_json(path, method=method, payload=payload,
                                  headers=fresh_headers, timeout=timeout,
                                  params=params, _retry_rate_limit=_retry_rate_limit,
                                  _retry_auth=False)
    if status in (200, 201, 204) and ((method == 'POST' and (path in _SYNC_WRITE_PATHS or path.startswith('/scrobble/'))) or
                                      (method == 'DELETE' and path.startswith('/sync/playback/'))):
        try:
            _invalidate_ratings_cache()
        except Exception as exc:
            _log(f'Cache invalidation failed: {exc}', xbmc.LOGWARNING)
    _LAST_API_ERROR = ''
    if status not in (200, 201, 204):
        if status == 429:
            retry = next((v for k, v in response_headers.items() if k.lower() == 'retry-after'), 60)
            quota_error = data.get('error') if isinstance(data, dict) else ''
            delay = (_retry_after_seconds({'Retry-After': retry}, ceiling=None)
                     if quota_error in ('user_limit_exceeded', 'app_limit_exceeded') else 1)
            daily = isinstance(data, dict) and data.get('error') == 'user_limit_exceeded'
            _LAST_API_ERROR = ('Simkl daily account API limit reached' if daily else 'Simkl API rate limit reached')
            _LAST_API_ERROR += ' — retry after ' + datetime.fromtimestamp(time.time() + delay).strftime('%H:%M')
            cooldown_key = (key if headers and headers.get('Authorization') and
                            quota_error != 'app_limit_exceeded' else 'cooldown:client')
            cache[cooldown_key] = {
                'until': time.time() + delay,
                'status': 429,
                'error': 'rate_limit',
                'message': _LAST_API_ERROR,
            }
            _ensure_dir()
            try:
                with open(LIST_CACHE_FILE, 'w', encoding='utf-8') as fp:
                    json.dump(cache, fp)
            except OSError:
                pass
        elif status == 412:
            _LAST_API_ERROR = (
                'Simkl client temporarily blocked (HTTP 412 client_id_failed); '
                'fresh requests are paused'
            )
            cache['cooldown:client'] = {
                'until': time.time() + 15 * 60,
                'status': 412,
                'error': 'client_id_failed',
                'message': _LAST_API_ERROR,
            }
            _ensure_dir()
            try:
                with open(LIST_CACHE_FILE, 'w', encoding='utf-8') as fp:
                    json.dump(cache, fp)
            except OSError:
                pass
        elif status == 401 and isinstance(data, dict) and data.get('error') == 'user_token_required':
            _LAST_API_ERROR = 'Simkl request requires an access token; this is a request authentication error'
        elif status in (401, 403):
            _LAST_API_ERROR = 'Simkl authorization/access denied — reconnect or check account access'
        elif status == 0:
            _LAST_API_ERROR = 'Cannot connect to Simkl'
        else:
            _LAST_API_ERROR = 'Simkl request failed (HTTP %s)' % status
    return result


def _http_json_request(path, method='GET', payload=None, headers=None, timeout=20, params=None):
    _throttle()
    url = _build_api_url(path, params=params)
    hdr = {'Content-Type': 'application/json', 'User-Agent': UA}
    if headers:
        hdr.update(headers)
    body = json.dumps(payload).encode('utf-8') if payload is not None else None
    try:
        req = Request(url, data=body, headers=hdr, method=method)
        with urlopen(req, timeout=timeout) as r:
            raw = r.read().decode('utf-8', errors='replace')
            try:
                data = json.loads(raw) if raw else {}
            except ValueError:
                data = {'_raw': raw}
            result = (r.getcode(), data, dict(r.headers.items()))
            _debug_http_result(method, url, r.getcode(), data)
            _log(f'{method} {path} -> {r.getcode()}', xbmc.LOGINFO)
            return result
    except HTTPError as e:
        raw = ''
        try:
            raw = e.read().decode('utf-8', errors='replace')
        except Exception:
            pass
        try:
            data = json.loads(raw) if raw else {}
        except ValueError:
            data = {'_raw': raw}
        result = (e.code, data, dict(e.headers.items() if e.headers else []))
        _debug_http_result(method, url, e.code, data)
        _log(f'{method} {path} -> {e.code}', xbmc.LOGWARNING)
        _log_api_error_detail(method, path, e.code, data)
        return result
    except URLError as e:
        _debug_bundle_event('HTTP ERROR', f'{method} {urlsplit(url).path} -> network error (URLError)')
        _log(f'{method} {path} URL error: {e.reason}', xbmc.LOGERROR)
        return 0, None, {}
    except Exception as e:
        _debug_bundle_event('HTTP ERROR', f'{method} {urlsplit(url).path} -> request error ({type(e).__name__})')
        _log(f'{method} {path} HTTP error: {e}', xbmc.LOGERROR)
        return 0, None, {}


def _log_api_error_detail(method, path, status, data):
    """Log safe Simkl error fields for client/request errors, never payloads."""
    if status not in (400, 401):
        return
    if isinstance(data, dict):
        error = data.get('error') or data.get('code') or ''
        detail = (data.get('error_description') or data.get('message')
                  or data.get('detail') or '')
    else:
        error = detail = ''

    def clean(value, limit):
        return ' '.join(str(value).replace('\r', ' ').replace('\n', ' ').split())[:limit]

    error = clean(error, 100) or 'unavailable'
    detail = clean(detail, 240) or 'no API error description returned'
    level = xbmc.LOGINFO if error.lower() in (
        'authorization_pending', 'slow_down'
    ) else xbmc.LOGWARNING
    _log(
        f'HTTP {status} details for {str(method).upper()} {path}: '
        f'error={error}; description={detail}',
        level,
    )


def _retry_after_seconds(headers, ceiling=_MAX_RETRY_DELAY):
    """Parse Retry-After; persistent daily cooldowns must not be capped."""
    raw = next(
        (value for key, value in (headers or {}).items()
         if str(key).lower() == 'retry-after'),
        86400 if ceiling is None else 5,
    )
    try:
        value = int(float(raw))
    except (TypeError, ValueError, OverflowError):
        try:
            retry_at = parsedate_to_datetime(str(raw))
            if retry_at.tzinfo is None:
                retry_at = retry_at.replace(tzinfo=timezone.utc)
            value = int((retry_at - datetime.now(timezone.utc)).total_seconds())
        except (TypeError, ValueError, OverflowError):
            value = 86400 if ceiling is None else 5
    return max(2, min(value, ceiling)) if ceiling is not None else max(2, value)


def _is_sync_write_rate_limit(path, method, result):
    """Keep compatibility with Simkl's legacy 400 sync-write response."""
    status, data, _headers = result
    if str(method or 'GET').upper() != 'POST' or path not in _SYNC_WRITE_PATHS or status != 400:
        return False
    return isinstance(data, dict) and str(data.get('error') or '').lower() == 'rate_limit'


def _http_form(path, method='POST', payload=None, headers=None, timeout=20, params=None):
    method = str(method or 'POST').upper()
    url = _build_api_url(path, params=params)
    hdr = {'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': UA}
    if headers:
        hdr.update(headers)
    body = urlencode(payload).encode('utf-8') if payload is not None else None
    delay = 1
    for attempt in range(_MAX_TRANSIENT_ATTEMPTS):
        _throttle()
        with _request_lock:
            try:
                req = Request(url, data=body, headers=hdr, method=method)
                with urlopen(req, timeout=timeout) as r:
                    raw = r.read().decode('utf-8', errors='replace')
                    try:
                        data = json.loads(raw) if raw else {}
                    except ValueError:
                        data = {'_raw': raw}
                    status = r.getcode()
                    response_headers = dict(r.headers.items())
                    _debug_http_result(method, url, status, data)
                    _log(f'{method} {path} -> {status}', xbmc.LOGINFO)
            except HTTPError as e:
                raw = ''
                try:
                    raw = e.read().decode('utf-8', errors='replace')
                except Exception:
                    pass
                try:
                    data = json.loads(raw) if raw else {}
                except ValueError:
                    data = {'_raw': raw}
                status = e.code
                response_headers = dict(e.headers.items() if e.headers else [])
                _debug_http_result(method, url, status, data)
                _log(f'{method} {path} -> {status}', xbmc.LOGWARNING)
                _log_api_error_detail(method, path, status, data)
            except URLError as e:
                _debug_bundle_event('HTTP ERROR', f'{method} {urlsplit(url).path} -> network error (URLError)')
                _log(f'{method} {path} URL error: {e.reason}', xbmc.LOGERROR)
                return 0, None, {}
            except Exception as e:
                _debug_bundle_event('HTTP ERROR', f'{method} {urlsplit(url).path} -> request error ({type(e).__name__})')
                _log(f'{method} {path} HTTP error: {e}', xbmc.LOGERROR)
                return 0, None, {}

        if status not in _TRANSIENT_STATUSES or attempt >= _MAX_TRANSIENT_ATTEMPTS - 1:
            return status, data, response_headers
        wait = _retry_after_seconds(response_headers) if status == 429 else min(delay, _MAX_RETRY_DELAY)
        _log(
            f'{method} {path} transient HTTP {status}; '
            f'retry {attempt + 2}/{_MAX_TRANSIENT_ATTEMPTS} in {wait}s',
            xbmc.LOGWARNING,
        )
        _debug_bundle_event(
            'RETRY', f'{method} {urlsplit(url).path} -> HTTP {status}; retry '
            f'{attempt + 2}/{_MAX_TRANSIENT_ATTEMPTS} after {wait}s',
        )
        time.sleep(wait)
        delay = min(delay * 2, _MAX_RETRY_DELAY)

    return status, data, response_headers


def _token_needs_refresh(tok):
    if not tok:
        return True
    try:
        stored_at = int(tok.get('stored_at', 0))
        expires_in = int(tok.get('expires_in', 30 * 86400))  # Default 30 days
    except (TypeError, ValueError, OverflowError):
        return True
    if not stored_at:
        return False
    return (time.time() - stored_at) > (expires_in * 0.8)


def _refresh_token(force=False, expected_access_token=None):
    # Simkl refresh tokens are single-use. Re-check the token while holding a
    # process-wide lock so simultaneous Kodi requests cannot consume the same
    # refresh token twice.
    with _token_refresh_lock:
        tok = _load_token()
        if not tok or not tok.get('refresh_token'):
            return False
        if expected_access_token and tok.get('access_token') != expected_access_token:
            return bool(tok.get('access_token'))
        if not force and not _token_needs_refresh(tok):
            return True

        cid, csec = _credentials()
        refresh_payload = {
            'client_id': cid,
            'refresh_token': tok['refresh_token'],
            'grant_type': 'refresh_token',
            'scope': SIMKL_SCOPE,
        }
        status, data, _ = _http_form(
            '/oauth2/token',
            method='POST',
            payload=refresh_payload,
        )
        if status == 200 and isinstance(data, dict) and data.get('access_token'):
            _account_cache_key()
            _save_token(data, refreshing=True)
            xbmc.log('Simkl: token refreshed', xbmc.LOGINFO)
            return True

        xbmc.log(f'Simkl refresh failed: {status}', xbmc.LOGWARNING)
        # Do not delete the token on refresh failure. This allows ReAuth to manage
        # the token independently and avoids a race condition where we delete a
        # token that ReAuth has just refreshed.
        return False


def _get_access_token():
    tok = _load_token()
    if not tok:
        _log('access token lookup: no saved token found', xbmc.LOGWARNING)
        return None
    if _token_needs_refresh(tok) and tok.get('refresh_token'):
        _log('access token lookup: token requires refresh', xbmc.LOGDEBUG)
        if not _refresh_token():
            # Never keep using an expired credential after refresh failure.
            _log('access token lookup: refresh failed', xbmc.LOGWARNING)
            return None
        tok = _load_token()
    access_token = (tok or {}).get('access_token')
    _log(f'access token lookup: {"available" if access_token else "missing"}',
         xbmc.LOGDEBUG if access_token else xbmc.LOGWARNING)
    return access_token


def is_authorized():
    authorized = bool(_get_access_token())
    _log(f'authorization check: {"authorized" if authorized else "not authorized"}',
         xbmc.LOGDEBUG if authorized else xbmc.LOGWARNING)
    return authorized


def has_token():
    """Cheap local check for menu construction; network refresh is deferred."""
    token = _load_token()
    return bool(isinstance(token, dict) and token.get('access_token'))


def _auth_headers():
    access_token = _get_access_token()
    if not access_token:
        return None
    cid, _ = _credentials()
    return {'Authorization': f'Bearer {access_token}', 'simkl-api-key': cid}


def _scrobble_payload(meta):
    """Build a robust singular item payload required by /scrobble/*.

    Simkl expects movies as {"movie": {...}} and TV/anime episodes as
    {"show": {...}, "episode": {...}} or {"anime": {...}, "episode": {...}}.
    This function ensures all required fields are present for reliable scrobbling.
    """
    xbmc.log('Simkl: building scrobble payload', xbmc.LOGDEBUG)
    if not meta:
        return None

    title = str(meta.get('title') or '').strip()
    content_type_from_meta = str(meta.get('content') or 'movie').lower()
    year = str(meta.get('year') or '').strip()
    season = meta.get('season')
    episode = meta.get('episode')
    
    if not title:
        xbmc.log("Simkl: _scrobble_payload missing title.", xbmc.LOGWARNING)
        return None

    # The guide accepts every known external ID and falls back to title/year.
    # Preserve IDs already nested under ``ids`` as well as the flat metadata
    # fields used by Cosmos playback routes.
    supplied_ids = meta.get('ids') if isinstance(meta.get('ids'), dict) else {}
    ids = {}
    for key in ('simkl', 'imdb', 'tmdb', 'tvdb', 'mal', 'anidb', 'anilist', 'kitsu'):
        value = supplied_ids.get(key)
        if value in (None, ''):
            value = meta.get(key)
        if value in (None, ''):
            value = meta.get(f'{key}_id')
        if value in (None, ''):
            continue
        value = str(value).strip()
        if not value:
            continue
        if key == 'tmdb' and value.isdigit():
            value = int(value)
        ids[key] = value

    if not ids and not year:
        xbmc.log(
            'Simkl: scrobble payload needs an ID or a title/year fallback',
            xbmc.LOGWARNING,
        )
        return None

    # Base object for a movie or a show.
    media_object = {'title': title, 'ids': ids}
    if year:
        try: media_object['year'] = int(year)
        except (ValueError, TypeError): pass

    # Handle movies
    if 'movie' in content_type_from_meta:
        return {'movie': media_object}

    # Simkl-native anime uses an absolute episode number without a season.
    # TMDB/TVDB-primary anime uses the ordinary show/season coordinates; a
    # TMDB ID may identify several separate Simkl anime titles.
    if 'anime' in content_type_from_meta:
        try:
            episode_no = int(episode)
        except (TypeError, ValueError):
            return None
        if episode_no < 1:
            return None
        native_ids = any(key in ids for key in ('simkl', 'mal', 'anilist', 'anidb', 'kitsu'))
        if native_ids and (meta.get('anime_numbering') == 'absolute' or season in (None, '')):
            return {'anime': media_object, 'episode': {'number': episode_no}}
        try:
            season_no = int(season)
        except (TypeError, ValueError):
            return None
        if season_no < 0 or not any(key in ids for key in ('tmdb', 'tvdb')):
            return None
        show_object = dict(media_object, ids={key: value for key, value in ids.items()
                                              if key in ('tmdb', 'tvdb', 'imdb')})
        return {'show': show_object, 'episode': {'season': season_no,
                                                 'number': episode_no}}

    # Handle ordinary TV episodes.
    if any(x in content_type_from_meta for x in ('tv', 'show', 'episode', 'anime')):
        try:
            season_no = int(season)
            episode_no = int(episode)
        except (TypeError, ValueError):
            xbmc.log("Simkl: scrobble payload missing valid season/episode", xbmc.LOGWARNING)
            return None
        
        episode_object = {'season': season_no, 'number': episode_no}
        
        return {'show': media_object, 'episode': episode_object}

    xbmc.log(f"Simkl: _scrobble_payload unknown content type: {content_type_from_meta}", xbmc.LOGWARNING)
    return None

def scrobble(verb, meta, progress=0.0, require_watched=False):
    """Report a real playback event to Simkl using their dedicated scrobble endpoints."""
    if verb not in ('start', 'pause', 'stop'):
        return False

    if not is_authorized():
        xbmc.log(f'Simkl scrobble {verb}: Not authorized - skipping', xbmc.LOGINFO)
        return False

    payload = _scrobble_payload(meta)
    if payload is None:
        xbmc.log(f'Simkl scrobble {verb}: Failed to build valid payload', xbmc.LOGWARNING)
        return False

    headers = _auth_headers()

    try:
        p = float(progress or 0)
        if not math.isfinite(p):
            raise ValueError
    except (TypeError, ValueError, OverflowError):
        p = 0.0

    payload['progress'] = round(max(0.0, min(100.0, p)), 2)

    # SIMKL permits only one scrobble operation per user at a time. Keep
    # playback events ordered even though resume.py dispatches them in daemon
    # threads, and do not retry a 429 here: the next real player event is the
    # documented retry point and avoids duplicate scrobbles.
    with _scrobble_lock:
        status, data, _ = _http_json(
            f'/scrobble/{verb}',
            method='POST',
            payload=payload,
            headers=headers,
            timeout=8,
            _retry_rate_limit=False,
        )

    already_watched = (
        status == 409
        and isinstance(data, dict)
        and bool(data.get('watched_at'))
    )
    ok = (200 <= (status or 0) < 300) or already_watched
    action = data.get('action') if isinstance(data, dict) else None
    watched = already_watched or (ok and action == 'scrobble')
    if ok:
        xbmc.log(
            f'Simkl scrobble {verb} -> {status} '
            f'{"ALREADY WATCHED" if already_watched else "SUCCESS"} '
            f'progress={payload["progress"]:.2f} action={action} watched={watched}',
            xbmc.LOGINFO,
        )
    else:
        xbmc.log(
            f'Simkl scrobble {verb} -> {status} FAILED',
            xbmc.LOGWARNING,
        )
    # A successful stop below 80% is only a saved pause point. Never let
    # callers mistake HTTP success for confirmed remote watch history.
    return bool(watched) if require_watched else ok


def scrobble_start(meta, progress=0.0):
    return scrobble('start', meta, progress)


def scrobble_pause(meta, progress=0.0):
    return scrobble('pause', meta, progress)


def scrobble_stop(meta, progress=0.0):
    return scrobble('stop', meta, progress)


def add_to_history(meta):
    """Add an item to Simkl watch history. Does not show notifications."""
    if not is_authorized():
        return False

    content = (meta.get('content') or 'movie').lower()

    title = meta.get('title')
    year = meta.get('year')
    tmdb = meta.get('tmdb')
    imdb = meta.get('imdb')
    season = meta.get('season')
    episode = meta.get('episode')

    payload = {'movies': [], 'shows': [], 'anime': []}
    watched_at = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

    is_show = content in ('tv', 'tvshow', 'episode', 'show')
    is_anime = content in ('anime', 'anime_episode')

    if content == 'movie':
        movie = _build_item_payload(
            title, year=year, tmdb=tmdb, imdb=imdb, content='movie',
        )
        if movie:
            movie['watched_at'] = watched_at
            payload['movies'].append(movie)
    elif is_show:
        if season and episode:
            item = _build_show_episode_payload(
                title, year=year, tmdb=tmdb, imdb=imdb,
                season=season, episode=episode, watched_at=watched_at,
            )
            if item:
                payload['shows'].append(item)
            else:
                xbmc.log(f'Simkl: Failed to build episode payload for history. {title} S{season}E{episode}', xbmc.LOGWARNING)
                return False
        else:
            xbmc.log(f'Simkl: Cannot add show to history without episode details: {title}', xbmc.LOGWARNING)
            return False
    elif is_anime:
        if season and episode:
            item = _build_show_episode_payload(
                title, year=year, tmdb=tmdb, imdb=imdb, content='anime',
                season=season, episode=episode, watched_at=watched_at,
            )
            if item:
                payload['anime'].append(item)
            else:
                xbmc.log(f'Simkl: Failed to build anime episode payload for history. {title} S{season}E{episode}', xbmc.LOGWARNING)
                return False
        else:
            xbmc.log(f'Simkl: Cannot add anime to history without episode details: {title}', xbmc.LOGWARNING)
            return False


    status, data, _ = _http_json(
        '/sync/history',
        method='POST',
        payload=payload,
        headers=_auth_headers(),
    )
    added = data.get('added') if isinstance(data, dict) else None
    if status in (200, 201) and (not isinstance(added, dict) or any((added.get(key) or 0) for key in ('movies', 'shows', 'episodes'))):
        xbmc.log(f'Simkl: Added to history: {title}', xbmc.LOGINFO)
        return True
    xbmc.log(f'Simkl: Failed to add to history. Status: {status}', xbmc.LOGWARNING)
    return False

def remove_from_history(meta):
    """Remove an item from Simkl watch history."""
    if not is_authorized():
        return False

    content = (meta.get('content') or 'movie').lower()
    title = meta.get('title')
    year = meta.get('year')
    tmdb = meta.get('tmdb')
    imdb = meta.get('imdb')
    season = meta.get('season')
    episode = meta.get('episode')

    payload = {'movies': [], 'shows': [], 'anime': []}

    is_show = content in ('tv', 'tvshow', 'episode', 'show')
    is_anime = content in ('anime', 'anime_episode')

    item = None
    if content == 'movie':
        item = _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='movie')
        if item:
            payload['movies'].append(item)
    elif is_show:
        if season and episode:
            item = _build_show_episode_payload(
                title, year=year, tmdb=tmdb, imdb=imdb,
                content='show', season=season, episode=episode,
            )
        else:
            item = _build_item_payload(
                title, year=year, tmdb=tmdb, imdb=imdb, content='show',
            )
            # A parent-show history action should unmark its watched seasons
            # while keeping the show in the user's library. An item with no
            # seasons would remove the library entry entirely.
            seasons = []
            for season_item in (meta.get('seasons') or []):
                try:
                    seasons.append({'number': int(season_item.get('number'))})
                except (AttributeError, TypeError, ValueError):
                    continue
            if item and seasons:
                item['seasons'] = seasons
        if item:
            payload['shows'].append(item)
    elif is_anime:
        item = _build_show_episode_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='anime', season=season, episode=episode) if season and episode else _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='anime')
        if item:
            # The current remove-history contract accepts anime under shows[].
            payload['shows'].append(item)
    
    if not any(payload.values()):
        xbmc.log('Simkl: Failed to build remove from history payload.', xbmc.LOGWARNING)
        return False

    status, data, _ = _http_json('/sync/history/remove', method='POST', payload=payload, headers=_auth_headers())

    if status in (200, 201):
        return True

    xbmc.log(f'Simkl: Failed to remove from history. Status: {status}', xbmc.LOGWARNING)
    return False

def clear_history():
    """Clear all items from Simkl watch history."""
    if not is_authorized():
        return False

    # Fetch all history
    movies = _get_history('movies') or []
    shows = _get_history('shows') or []
    anime = _get_history('anime') or []

    if not movies and not shows and not anime:
        xbmc.log('Simkl: No history found to clear.', xbmc.LOGINFO)
        return True # Nothing to do

    payload = {'movies': [], 'shows': [], 'anime': []}

    # Prepare movies payload
    for movie_item in movies:
        if movie_item.get('movie') and movie_item['movie'].get('ids'):
            payload['movies'].append({'ids': movie_item['movie']['ids']})

    # Prepare shows and anime payload
    for item_type, item_list in [('show', shows), ('anime', anime)]:
        for item in item_list:
            # To clear all history for a show/anime, we just need its ID.
            # The API will remove all watched history for that item.
            if item.get(item_type) and item[item_type].get('ids'):
                if item_type == 'show':
                    payload['shows'].append({'ids': item[item_type]['ids']})
                elif item_type == 'anime':
                    # Anime removals use the shows[] bucket on this endpoint.
                    payload['shows'].append({'ids': item[item_type]['ids']})

    if not any(payload.values()):
        xbmc.log('Simkl: History fetched, but failed to build remove payload.', xbmc.LOGWARNING)
        return False

    # Make the API call
    status, data, _ = _http_json('/sync/history/remove', method='POST', payload=payload, headers=_auth_headers())

    if status in (200, 201):
        xbmc.log('Simkl: History cleared successfully.', xbmc.LOGINFO)
        return True
    
    xbmc.log(f'Simkl: Failed to clear history. Status: {status}', xbmc.LOGWARNING)
    return False

def remove_from_watchlist(meta):
    """Remove an item from Simkl watchlist (Plan to Watch)."""
    if not is_authorized():
        return False

    content = (meta.get('content') or 'movie').lower()
    title = meta.get('title')
    year = meta.get('year')
    tmdb = meta.get('tmdb')
    imdb = meta.get('imdb')
    season = meta.get('season')
    episode = meta.get('episode')

    payload = {'movies': [], 'shows': [], 'anime': []}
    
    is_show = content in ('tv', 'tvshow', 'episode', 'show')
    is_anime = content in ('anime', 'anime_episode')

    item_payload = None
    if content == 'movie':
        item_payload = _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='movie')
        if item_payload:
            payload['movies'].append(item_payload)
    elif is_show:
        item_payload = _build_show_episode_payload(title, year=year, tmdb=tmdb, imdb=imdb, season=season, episode=episode) if season and episode else _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='show')
        if item_payload:
            payload['shows'].append(item_payload)
    elif is_anime:
        item_payload = _build_show_episode_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='anime', season=season, episode=episode) if season and episode else _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='anime')
        if item_payload:
            payload['shows'].append(item_payload)

    if not any(p for p in payload.values()):
        xbmc.log('Simkl: Failed to build remove from watchlist payload.', xbmc.LOGWARNING)
        return False

    status, data, _ = _http_json('/sync/history/remove', method='POST', payload=payload, headers=_auth_headers())
    
    deleted = data.get('deleted') if isinstance(data, dict) else None
    if status in (200, 201) and (not isinstance(deleted, dict) or any(deleted.get(key, 0) for key in ('movies', 'shows', 'episodes'))):
        xbmc.log(f'Simkl: Removed from watchlist: {title}', xbmc.LOGINFO)
        return True
    
    xbmc.log(f'Simkl: Failed to remove from watchlist. Status: {status}', xbmc.LOGWARNING)
    return False

def add_to_collection(meta):
    """Add an item to Simkl 'completed' list."""
    if not is_authorized():
        return False

    content = (meta.get('content') or 'movie').lower()
    title = meta.get('title')
    year = meta.get('year')
    tmdb = meta.get('tmdb')
    imdb = meta.get('imdb')

    payload = {'movies': [], 'shows': [], 'anime': []}

    is_show = content in ('tv', 'tvshow', 'episode', 'show')
    is_anime = content in ('anime', 'anime_episode')

    item_payload = None
    if content == 'movie':
        item_payload = _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='movie')
        if item_payload:
            item_payload['to'] = 'completed'
            payload['movies'].append(item_payload)
    elif is_show:
        item_payload = _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='show')
        if item_payload:
            item_payload['to'] = 'completed'
            payload['shows'].append(item_payload)
    elif is_anime:
        item_payload = _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='anime')
        if item_payload:
            item_payload['to'] = 'completed'
            payload['anime'].append(item_payload)

    if not any(p for p in payload.values()):
        xbmc.log('Simkl: Failed to build add to collection payload.', xbmc.LOGWARNING)
        return False

    status, data, _ = _http_json('/sync/add-to-list', method='POST', payload=payload, headers=_auth_headers())
    
    added = data.get('added') if isinstance(data, dict) else None
    if status in (200, 201) and (not isinstance(added, dict) or any(added.get(key, 0) for key in ('movies', 'shows', 'anime', 'episodes'))):
        return True
    
    xbmc.log(f'Simkl: Failed to add to collection. Status: {status}', xbmc.LOGWARNING)
    return False

def remove_from_collection(meta):
    """Remove an item from Simkl 'completed' list."""
    if not is_authorized():
        return False

    content = (meta.get('content') or 'movie').lower()
    title = meta.get('title')
    year = meta.get('year')
    tmdb = meta.get('tmdb')
    imdb = meta.get('imdb')

    payload = {'movies': [], 'shows': [], 'anime': []}

    is_show = content in ('tv', 'tvshow', 'episode', 'show')
    is_anime = content in ('anime', 'anime_episode')

    item_payload = None
    if content == 'movie':
        item_payload = _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='movie')
        if item_payload:
            payload['movies'].append(item_payload)
    elif is_show:
        item_payload = _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='show')
        if item_payload:
            payload['shows'].append(item_payload)
    elif is_anime:
        item_payload = _build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='anime')
        if item_payload:
            payload['shows'].append(item_payload)

    if not any(p for p in payload.values()):
        xbmc.log('Simkl: Failed to build remove from collection payload.', xbmc.LOGWARNING)
        return False

    status, data, _ = _http_json('/sync/history/remove', method='POST', payload=payload, headers=_auth_headers())
    
    deleted = data.get('deleted') if isinstance(data, dict) else None
    if status in (200, 201) and (not isinstance(deleted, dict) or any(deleted.get(key, 0) for key in ('movies', 'shows', 'episodes'))):
        return True
    
    xbmc.log(f'Simkl: Failed to remove from collection. Status: {status}', xbmc.LOGWARNING)
    return False

def clear_collection():
    """Clear all items from Simkl 'completed' list."""
    if not is_authorized():
        return False

    # Fetch all items from the 'completed' list
    # _get_list returns a list of (section, item_data) tuples
    completed_items = _get_list('completed')
    if not completed_items:
        xbmc.log('Simkl: No collection items found to clear.', xbmc.LOGINFO)
        return True

    payload = {'movies': [], 'shows': [], 'anime': []}

    for section, item_data in completed_items:
        item_meta = _get_item_meta(item_data)
        ids = item_meta.get('ids')
        if not ids:
            continue

        # For shows and anime, we need to remove the entire show, not just episodes.
        # The remove-from-list endpoint for a show does not require season/episode details.
        item_payload = {'ids': ids}

        if section == 'movies':
            payload['movies'].append(item_payload)
        elif section == 'shows':
            payload['shows'].append(item_payload)
        elif section == 'anime':
            payload['shows'].append(item_payload)

    if not any(payload.values()):
        xbmc.log('Simkl: Collection fetched, but failed to build remove payload.', xbmc.LOGWARNING)
        return False

    status, data, _ = _http_json('/sync/history/remove', method='POST', payload=payload, headers=_auth_headers())

    deleted = data.get('deleted') if isinstance(data, dict) else None
    if status in (200, 201) and (not isinstance(deleted, dict) or any(deleted.get(key, 0) for key in ('movies', 'shows', 'episodes'))):
        xbmc.log('Simkl: Collection cleared successfully.', xbmc.LOGINFO)
        return True

    xbmc.log(f'Simkl: Failed to clear collection. Status: {status}', xbmc.LOGWARNING)
    return False

def _download_qr_code(data):
    tmp = None
    try:
        import tempfile
        # Preserve the complete authorization URI for QR-based sign-in.
        qr_target = data or ''
        qr_api = (
            'https://api.qrserver.com/v1/create-qr-code/'
            '?size=450x450&margin=0&format=png&data=' + quote_plus(qr_target)
        )
        req = Request(qr_api, headers={'User-Agent': UA})
        with urlopen(req, timeout=20) as r:
            img_bytes = r.read()
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix='.png')
        tmp.write(img_bytes)
        tmp.close()
        return tmp.name
    except Exception as e:
        if tmp:
            try:
                tmp.close()
                os.remove(tmp.name)
            except Exception:
                pass
        raise


def _run_plain_auth_dialog(service_name, user_code, verification_url,
                            expires_in, interval, poll_fn):
    dialog = xbmcgui.DialogProgress()
    dialog.create(f'{service_name} Authorization', '')
    start = time.time()
    while True:
        elapsed = time.time() - start
        remaining = expires_in - elapsed
        if remaining <= 0 or dialog.iscanceled():
            dialog.close()
            return False
        dialog.update(
            max(0, int(100 - (elapsed / expires_in) * 100)),
            f'Go to: [COLOR skyblue]{verification_url}[/COLOR]\n\n'
            f'Enter Code: [COLOR yellow]{user_code}[/COLOR]\n\n'
            f'Time remaining: {int(remaining)}s',
        )
        time.sleep(interval)
        if dialog.iscanceled() or time.time() - start >= expires_in:
            dialog.close()
            return False
        try:
            outcome = poll_fn()
        except Exception:
            continue
        if outcome == 'success':
            dialog.close()
            return True
        if outcome == 'denied':
            dialog.close()
            return False
        if outcome == 'slow_down':
            interval += 5


def _run_device_auth_window(service_name, user_code, verification_url,
                             verification_label, expires_in, interval, poll_fn):
    qr_path = ''
    try:
        qr_path = _download_qr_code(verification_url)
    except Exception as exc:
        xbmc.log(f'Simkl QR generation failed: {exc}', xbmc.LOGERROR)

    try:
        dialog = AuthDialog(
            'AuthDialog.xml', ADDON_PATH, 'Default', '720p',
            service_name=service_name,
            user_code=user_code,
            verification_url=verification_url,
            verification_label=verification_label,
            expires_in=expires_in,
            qr_path=qr_path,
            icon_path=_simkl_icon(),
        )
    except Exception as e:
        xbmc.log(f'Simkl AuthDialog load error (fallback): {e}', xbmc.LOGWARNING)
        if qr_path and os.path.exists(qr_path):
            try:
                os.remove(qr_path)
            except Exception:
                pass
        return _run_plain_auth_dialog(service_name, user_code, verification_url,
                                      expires_in, interval, poll_fn)

    result = [False]

    def _poll():
        start = time.time()
        poll_interval = interval
        while not dialog.canceled:
            time.sleep(poll_interval)
            if dialog.canceled:
                return
            elapsed = time.time() - start
            remaining = max(0, expires_in - elapsed)
            if remaining <= 0:
                dialog.close()
                return
            dialog.update_remaining(remaining)
            try:
                outcome = poll_fn()
            except Exception as exc:
                xbmc.log(f'Simkl auth poll error: {exc}', xbmc.LOGWARNING)
                continue
            if outcome == 'success':
                result[0] = True
                dialog.mark_authorized()
                return
            if outcome == 'denied':
                dialog.mark_denied()
                return
            if outcome == 'slow_down':
                poll_interval += 5

    thread = threading.Thread(target=_poll, daemon=True)
    thread.start()
    dialog.doModal()
    thread.join(timeout=10)

    try:
        if qr_path and os.path.exists(qr_path):
            os.remove(qr_path)
    except Exception:
        pass

    return result[0]


def authorize():
    cid, _ = _credentials()
    if not cid:
        xbmcgui.Dialog().notification(
            'Simkl', 'Please enter a Simkl client ID in Settings first',
            xbmcgui.NOTIFICATION_WARNING, 4000,
        )
        return False

    # The bundled COSMOS client is registered as an OAuth 2.0 app.  SIMKL
    # therefore requires its device endpoint rather than /oauth/pin (which
    # returns unauthorized_client for this client type).
    try:
        verifier, challenge = _pkce_pair()
        status, data, _ = _http_form(
            '/oauth2/device',
            method='POST',
            payload={
                'client_id': cid,
                'scope': SIMKL_SCOPE,
                'code_challenge': challenge,
                'code_challenge_method': 'S256',
            },
        )
    except Exception as exc:
        xbmc.log(f'Simkl device authorization request failed: {exc}', xbmc.LOGWARNING)
        status, data = 0, None

    if status == 200 and isinstance(data, dict) and data.get('user_code') and data.get('device_code'):
        user_code = data.get('user_code')
        device_code = data.get('device_code')
        verification_url = (
            data.get('verification_uri')
            or data.get('verification_url')
            or 'https://simkl.com/pin'
        )
        verification_uri_complete = data.get('verification_uri_complete') or verification_url
        expires_in = int(data.get('expires_in') or 900)
        interval = max(2, int(data.get('interval') or 5))

        def _poll_device_code():
            status, tokdata, _ = _http_form(
                '/oauth2/token',
                method='POST',
                payload={
                    'client_id': cid,
                    'device_code': device_code,
                    'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
                    'code_verifier': verifier,
                },
            )
            if isinstance(tokdata, dict):
                error = str(tokdata.get('error') or '').strip().lower()
                description = str(
                    tokdata.get('error_description') or tokdata.get('message') or ''
                ).replace('\r', ' ').replace('\n', ' ').strip()[:240]
                if status != 200 or error:
                    expected = error in ('authorization_pending', 'slow_down')
                    log_level = xbmc.LOGINFO if expected else xbmc.LOGWARNING
                    xbmc.log(
                        f'Simkl device token response: HTTP {status}; '
                        f'error={error or "none"}'
                        + (f'; description={description}' if description else ''),
                        log_level,
                    )
                if status == 200 and tokdata.get('access_token'):
                    _save_token(tokdata)
                    try:
                        ADDON.setSetting('simkl_auth_done', 'true')

                        _refresh_profile()
                    except Exception:
                        pass
                    return 'success'
                if error == 'authorization_pending':
                    return None
                if error == 'slow_down':
                    return 'slow_down'
                if error:
                    return 'denied'

            # A malformed/expired device request must not be treated as a
            # pending authorization.  Otherwise the dialog keeps sending
            # /oauth2/token and produces a repeated 400 loop.
            if status >= 400:
                xbmc.log(
                    f'Simkl device token response: HTTP {status}; '
                    'no JSON error details returned',
                    xbmc.LOGWARNING,
                )
                return 'denied'

            return None

        ok = _run_device_auth_window(
            service_name='Simkl',
            user_code=user_code,
            verification_url=verification_uri_complete,
            verification_label='Open https://simkl.com/pin and enter the code shown below.',
            expires_in=expires_in,
            interval=interval,
            poll_fn=_poll_device_code,
        )
        if ok:
            xbmcgui.Dialog().notification('Simkl', 'Authorization successful', xbmcgui.NOTIFICATION_INFO, 3000)
            return True

        xbmcgui.Dialog().notification('Simkl', 'Device authorization timed out or failed', xbmcgui.NOTIFICATION_ERROR, 3500)
        return False

    detail = ''
    if isinstance(data, dict):
        detail = data.get('error_description') or data.get('message') or data.get('error') or ''
    xbmcgui.Dialog().notification(
        'Simkl',
        f'Device authorization failed ({status})' + (f': {detail}' if detail else ''),
        xbmcgui.NOTIFICATION_ERROR, 4000,
    )
    return False


def revoke():
    # SIMKL's current PIN tokens are long-lived and are revoked from the
    # account's Connected Apps page, not through an /oauth2/revoke endpoint.
    # Disconnect locally so this addon stops sending the token immediately.
    _delete_token()
    xbmcgui.Dialog().notification('Simkl', 'Simkl account disconnected', xbmcgui.NOTIFICATION_INFO, 3000)


def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def _build_url(**kwargs):
    return f'{sys.argv[0]}?{urlencode(kwargs)}'


def _row(label, url, is_folder=False, thumb=''):
    li = xbmcgui.ListItem(label=label)
    t = thumb or _simkl_icon()
    li.setArt({'icon': t, 'thumb': t, 'poster': t})
    xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=is_folder)


def menu_root():
    # Keep root-menu rendering local; refresh an expired token only when the
    # user starts an API-backed operation.
    if not has_token():
        _row('[COLOR yellow][B]Authorize Simkl[/B][/COLOR]', _build_url(action='simkl_auth'), is_folder=False)
        _row('[COLOR grey]Sign in to sync your watchlist with Simkl[/COLOR]', _build_url(action='simkl_root'), is_folder=False)
    else:
        uname = (ADDON.getSetting('simkl_username') or '').strip() or 'Simkl'
        _row(f'[COLOR springgreen][B]Signed in as {uname}[/B][/COLOR]', _build_url(action='simkl_root'), is_folder=True)
        _row('[COLOR white]My Lists[/COLOR]', _build_url(action='simkl_watchlist'), is_folder=True)
        _row('Search Simkl', _build_url(action='simkl_search'), is_folder=True)
        _row('Discover on Simkl', _build_url(action='simkl_discover'), is_folder=True)
        _row('Calendar', _build_url(action='simkl_calendar'), is_folder=True)
        _row('[COLOR white]Next Episodes[/COLOR]', _build_url(action='simkl_next_episodes'), is_folder=True)
        _row('[COLOR white]History[/COLOR]', _build_url(action='simkl_history'), is_folder=True)
        _row('[COLOR white]Playback Progress[/COLOR]', _build_url(action='simkl_playback'), is_folder=True)
        _row('My Ratings', _build_url(action='simkl_ratings'), is_folder=True)
        _row('Refresh Account / Sync', _build_url(action='simkl_sync'), is_folder=False)
        _row('[COLOR red]Disconnect Simkl[/COLOR]', _build_url(action='simkl_revoke'), is_folder=False)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _build_item_payload(title, year='', tmdb='', imdb='', content='movie', season='', episode=''):
    payload = {'title': title or 'Untitled'}
    if year:
        try:
            payload['year'] = int(year)
        except ValueError:
            pass
    ids = {}
    if tmdb:
        try:
            ids['tmdb'] = int(tmdb)
        except ValueError:
            pass
    if imdb:
        ids['imdb'] = imdb
    if ids:
        payload['ids'] = ids
    if content == 'movie':
        return payload
    if content == 'show' or not season:
        return payload
    payload['season'] = int(season)
    payload['episode'] = int(episode)
    return payload


def _build_show_episode_payload(title, year='', tmdb='', imdb='', content='show',
                                 season='', episode='', watched_at=None):
    """Build the nested show payload used by Simkl list/history endpoints."""
    show = _build_item_payload(
        title=title,
        year=year,
        tmdb=tmdb,
        imdb=imdb,
        content=content,
    )
    try:
        season_no = int(season)
        episode_no = int(episode)
    except (TypeError, ValueError):
        return None

    episode_item = {'number': episode_no}
    if watched_at:
        episode_item['watched_at'] = watched_at
    show['seasons'] = [{
        'number': season_no,
        'episodes': [episode_item],
    }]
    return show


def _build_rating_payload(meta, rating=None, for_remove=False):
    """Build the documented /sync/ratings item shape."""
    if not isinstance(meta, dict):
        return None

    content = str(meta.get('content') or 'movie').lower()
    is_movie = content == 'movie'
    is_anime = content in ('anime', 'anime_episode')
    # Simkl accepts anime[] when adding a rating, but the remove-ratings
    # contract folds anime into shows[].
    section = 'movies' if is_movie else (
        'shows' if (is_anime and for_remove) else ('anime' if is_anime else 'shows')
    )
    item = _build_item_payload(
        meta.get('title') or meta.get('name') or '',
        year=meta.get('year', ''),
        tmdb=meta.get('tmdb') or meta.get('tmdb_id') or '',
        imdb=meta.get('imdb') or meta.get('imdb_id') or '',
        content='movie' if is_movie else 'show',
    )
    if not item:
        return None

    ids = item.setdefault('ids', {})
    for key in ('simkl', 'tvdb', 'mal', 'anidb', 'anilist', 'kitsu'):
        value = meta.get(key) or meta.get(f'{key}_id')
        if value not in (None, ''):
            ids[key] = str(value)
    if not ids:
        return None
    if rating is not None:
        try:
            rating = int(rating)
        except (TypeError, ValueError):
            return None
        if not 1 <= rating <= 10:
            return None
        item['rating'] = rating
    return {section: [item]}


def add_rating(meta, rating):
    """Add or replace a Simkl user rating (1-10)."""
    if not is_authorized():
        return False
    payload = _build_rating_payload(meta, rating=rating)
    if not payload:
        return False
    status, data, _ = _http_json(
        '/sync/ratings', method='POST', payload=payload,
        headers=_auth_headers(),
    )
    added = data.get('added') if isinstance(data, dict) else None
    success = status in (200, 201) and isinstance(added, dict) and (
        bool(added.get('statuses'))
        or any((added.get(key) or 0) for key in ('movies', 'shows', 'anime'))
    )
    return success


def remove_rating(meta):
    """Remove only the Simkl rating, preserving the watchlist item."""
    if not is_authorized():
        return False
    payload = _build_rating_payload(meta, for_remove=True)
    if not payload:
        return False
    status, data, _ = _http_json(
        '/sync/ratings/remove', method='POST', payload=payload,
        headers=_auth_headers(),
    )
    deleted = data.get('deleted') if isinstance(data, dict) else None
    not_found = data.get('not_found') if isinstance(data, dict) else None
    xbmc.log(
        f'Simkl: rating removal status={status} payload_types={list(payload)} '
        f'deleted={deleted} not_found={not_found}', xbmc.LOGINFO,
    )
    return status in (200, 201)


def _add_to_watchlist_impl(title, year='', tmdb='', imdb='', content='movie', season='', episode=''):
    cid, _ = _credentials()
    if not is_authorized() or not cid:
        xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000)
        return False

    content = str(content or 'movie').lower()
    payload = {'movies': [], 'shows': [], 'anime': []}
    if content == 'movie':
        movie = _build_item_payload(
            title, year=year, tmdb=tmdb, imdb=imdb, content='movie',
        )
        movie['to'] = 'plantowatch'
        payload['movies'].append(movie)
    else:
        is_anime = content in ('anime', 'anime_episode')
        section = 'anime' if is_anime else 'shows'
        if season and episode:
            item = _build_show_episode_payload(
                title, year=year, tmdb=tmdb, imdb=imdb,
                content='anime' if is_anime else 'show',
                season=season, episode=episode,
            )
            if item and item.get('seasons') and item['seasons'][0].get('episodes'):
                item['to'] = 'plantowatch'
        else:
            item = _build_item_payload(
                title, year=year, tmdb=tmdb, imdb=imdb,
                content='anime' if is_anime else 'show',
            )
            item['to'] = 'plantowatch'
        if not item:
            xbmcgui.Dialog().notification(
                'Simkl', 'A valid season and episode are required',
                xbmcgui.NOTIFICATION_WARNING, 3000,
                )
            return False
        payload[section].append(item)

    status, data, _ = _http_json(
        '/sync/add-to-list',
        method='POST',
        payload=payload,
        headers=_auth_headers(),
    )
    added = data.get('added') if isinstance(data, dict) else None
    if status in (200, 201) and (
        not isinstance(added, dict)
        or any((added.get(key) or 0) for key in ('movies', 'shows', 'anime', 'episodes'))
    ):
        xbmcgui.Dialog().notification('Simkl', 'Added to Simkl watchlist', xbmcgui.NOTIFICATION_INFO, 2500)
        return True
    xbmc.log(f'Simkl add to watchlist failed. Status: {status}', xbmc.LOGWARNING)
    xbmcgui.Dialog().notification('Simkl', f'Failed to update watchlist (status {status})', xbmcgui.NOTIFICATION_ERROR, 3500)
    return False


def _mark_watched_impl(title, year='', tmdb='', imdb='', content='movie', season='', episode=''):
    if not is_authorized():
        xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000)
        return False

    content = str(content or 'movie').lower()
    
    # Normalize content type for TV episodes
    if content in ('tv', 'tvshow', 'episode'):
        content = 'show'
    is_anime = content in ('anime', 'anime_episode')
    
    # Fallback to ListItem labels/properties if parameters are missing from context call
    if not title:
        title = xbmc.getInfoLabel('ListItem.Title') or ''
    if not season:
        season = xbmc.getInfoLabel('ListItem.Season') or ''
    if not episode:
        episode = xbmc.getInfoLabel('ListItem.Episode') or ''

    # Logic for movies and episodes (history)
    if content == 'movie':
        payload = {'movies': [_build_item_payload(title, year=year, tmdb=tmdb, imdb=imdb, content='movie')]}
        payload['movies'][0]['watched_at'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        endpoint = '/sync/history'
        success_msg = 'Marked as watched on Simkl'
        fail_msg = 'Failed to mark movie as watched'
    elif str(season).isdigit() and str(episode).isdigit():  # Episode
        item = _build_show_episode_payload(
            title, year=year, tmdb=tmdb, imdb=imdb,
            content='anime' if is_anime else 'show',
            season=season, episode=episode, watched_at=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        )
        if not item: 
            xbmc.log(f'Simkl: Failed to build show episode payload for {title} S{season}E{episode}', xbmc.LOGWARNING)
            xbmcgui.Dialog().notification('Simkl', 'Could not build episode data', xbmcgui.NOTIFICATION_ERROR, 3500)
            return False
        payload = {'anime' if is_anime else 'shows': [item]}
        endpoint = '/sync/history'
        success_msg = 'Marked as watched on Simkl'
        fail_msg = 'Failed to mark episode as watched'
    else:  # Show
        item = _build_item_payload(
            title, year=year, tmdb=tmdb, imdb=imdb,
            content='anime' if is_anime else 'show',
        )
        item['to'] = 'completed'
        payload = {'anime' if is_anime else 'shows': [item]}
        endpoint = '/sync/add-to-list'
        success_msg = 'Marked show as completed on Simkl'
        fail_msg = 'Failed to mark show as completed'

    if not any(payload.values()):
        xbmc.log(f'Simkl: Mark watched failed, empty payload for {title}', xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Simkl', 'Could not build item data', xbmcgui.NOTIFICATION_ERROR, 3500)
        return False

    status, data, _ = _http_json(
        endpoint,
        method='POST',
        payload=payload,
        headers=_auth_headers(),
    )
    added = data.get('added') if isinstance(data, dict) else None
    if status in (200, 201) and (
        not isinstance(added, dict)
        or any((added.get(key) or 0) for key in ('movies', 'shows', 'anime', 'episodes'))
    ):
        xbmcgui.Dialog().notification('Simkl', success_msg, xbmcgui.NOTIFICATION_INFO, 2500)
        return True
    xbmc.log(f'Simkl {fail_msg}. Status: {status}', xbmc.LOGWARNING)
    xbmcgui.Dialog().notification('Simkl', f'{fail_msg} (status {status})', xbmcgui.NOTIFICATION_ERROR, 3500)
    return False


def _get_last_activity_timestamp():
    if not is_authorized():
        return None
    # Simkl exposes activities as a read-only GET endpoint.  Keeping this as
    # GET is important because POST can be rejected by the API and prevents
    # the addon from detecting changes made on the Simkl site.
    status, data, _ = _http_json('/sync/activities', method='GET', headers=_auth_headers())
    if status != 200 or not isinstance(data, dict):
        return None
    return data.get('all') or None


def sync_watchlist(force=False):
    _data, ok = _sync_snapshot(force=force)
    return ok


def _get_history(media_type):
    library, ok = _sync_snapshot()
    if library is None:
        raise RuntimeError('Simkl history unavailable')
    return [row for row in library.get(media_type, {}).values()
            if row.get('status') == 'completed' or
            (media_type != 'movies' and (row.get('watched_episodes_count') or row.get('seasons')))]

def _load_list_cache():
    if not os.path.isfile(LIST_CACHE_FILE):
        return {}
    try:
        with open(LIST_CACHE_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _get_cached_list(list_name, allow_stale=False):
    # List data belongs to the authorized Simkl account.  A shared cache made
    # an account switch look like an empty/broken menu (or showed another
    # user's list) until the cache expired.
    account_key = _account_cache_key()
    record = _load_list_cache().get(f'{account_key}:{str(list_name)}')
    if not isinstance(record, dict) or not isinstance(record.get('items'), list):
        return None
    age = time.time() - float(record.get('stored_at') or 0)
    if not allow_stale and age > SIMKL_MENU_CACHE_TTL:
        return None
    return [(row[0], row[1]) for row in record['items']
            if isinstance(row, list) and len(row) == 2 and isinstance(row[1], dict)]


def _save_cached_list(list_name, items):
    _ensure_dir()
    cache = _load_list_cache()
    account_key = _account_cache_key()
    cache[f'{account_key}:{str(list_name)}'] = {
        'stored_at': int(time.time()), 'items': items,
    }
    try:
        with open(LIST_CACHE_FILE, 'w', encoding='utf-8') as fp:
            json.dump(cache, fp, ensure_ascii=False)
    except (OSError, TypeError) as exc:
        _log(f'list cache write failed: {exc}', xbmc.LOGWARNING)


def _get_list(list_name):
    if str(list_name).startswith('custom:'):
        return _CUSTOM_LIST_CACHE.get(str(list_name), [])
    media = None
    if ':' in str(list_name):
        media, list_name = list_name.split(':', 1)
    library, _ok = _sync_snapshot()
    if library is None:
        return None
    return [(kind, item) for kind, rows in library.items() for item in rows.values()
            if (not media or kind == media) and item.get('status') == list_name]


def _trakt_list_item_payload(item, destination):
    """Translate one Trakt list item into Simkl's bulk list-write shape."""
    if not isinstance(item, dict):
        return None, None

    # Trakt list entries can be movies, shows, or episodes. Simkl's built-in
    # watchlist statuses are title-level, so an episode entry is represented
    # by its parent show when importing a custom Trakt list.
    if isinstance(item.get('movie'), dict):
        media = item['movie']
        section = 'movies'
    elif isinstance(item.get('episode'), dict) and isinstance(item.get('show'), dict):
        media = item['show']
        section = 'shows'
    elif isinstance(item.get('show'), dict):
        media = item['show']
        section = 'shows'
    else:
        media = item
        section = 'movies' if str(item.get('type') or '').lower() == 'movie' else 'shows'

    title = str(media.get('title') or '').strip()
    if not title:
        return None, None

    raw_ids = media.get('ids') or {}
    ids = {}
    # These are the cross-catalog identifiers accepted by Simkl. The Trakt
    # slug is also supported by the migration endpoint as `traktslug`.
    for source_key, simkl_key in (
        ('imdb', 'imdb'),
        ('tmdb', 'tmdb'),
        ('tvdb', 'tvdb'),
        ('slug', 'traktslug'),
    ):
        value = raw_ids.get(source_key)
        if value not in (None, ''):
            ids[simkl_key] = str(value)

    payload = {'title': title, 'to': destination}
    year = media.get('year')
    try:
        if year:
            payload['year'] = int(year)
    except (TypeError, ValueError):
        pass
    if ids:
        payload['ids'] = ids

    # Use the strongest available identifier to deduplicate shows that appear
    # multiple times in a Trakt list as separate episode entries.
    # Keep this compatible with Kodi releases that embed Python 3.7;
    # assignment expressions were only added in Python 3.8.
    dedupe_key = f'title:{title.casefold()}:{payload.get("year", "")}'
    for key in ('tmdb', 'imdb', 'tvdb', 'traktslug'):
        value = ids.get(key)
        if value:
            dedupe_key = f'{key}:{value}'
            break
    return section, (dedupe_key, payload)


def import_trakt_list(items, destination, source_user='', list_id='', list_name='',
                      progress_callback=None):
    """Import Trakt list items into one Simkl built-in status bucket.

    Simkl accepts bulk arrays but does not currently expose custom-list write
    endpoints. This intentionally stores the source list name locally while
    writing each title to the selected built-in Simkl status.
    """
    valid_destinations = {value for _label, value in TRAKT_IMPORT_DESTINATIONS}
    if destination not in valid_destinations:
        return {'ok': False, 'error': 'invalid_destination'}
    if not is_authorized():
        return {'ok': False, 'error': 'not_authorized'}

    buckets = {'movies': {}, 'shows': {}}
    skipped = 0
    for item in items or []:
        section, translated = _trakt_list_item_payload(item, destination)
        if not section or not translated:
            skipped += 1
            continue
        dedupe_key, payload = translated
        buckets[section][dedupe_key] = payload

    total = sum(len(bucket) for bucket in buckets.values())
    added = 0
    not_found = []
    failed = 0
    batch_size = 50
    completed = 0

    for section in ('movies', 'shows'):
        values = list(buckets[section].values())
        for offset in range(0, len(values), batch_size):
            batch = values[offset:offset + batch_size]
            payload = {section: batch}
            status, data, _ = _http_json(
                '/sync/add-to-list', method='POST', payload=payload,
                headers=_auth_headers(),
            )
            if status in (200, 201) and isinstance(data, dict):
                response_added = data.get('added') or {}
                response_not_found = data.get('not_found') or {}
                if not isinstance(response_added, dict):
                    response_added = {}
                if not isinstance(response_not_found, dict):
                    response_not_found = {}
                added += sum(
                    len(value) if isinstance(value, list) else 0
                    for value in response_added.values()
                )
                for value in response_not_found.values():
                    if isinstance(value, list):
                        not_found.extend(value)
            else:
                failed += len(batch)
                xbmc.log(
                    f'Simkl: Trakt list import batch failed ({section}) status={status}',
                    xbmc.LOGWARNING,
                )
            completed += len(batch)
            if progress_callback:
                progress_callback(
                    int((completed / max(1, total)) * 100),
                    f'Imported {completed} of {total} items',
                )

    record = {
        'source': 'trakt',
        'source_user': str(source_user or ''),
        'list_id': str(list_id or ''),
        'list_name': str(list_name or 'Untitled'),
        'destination': destination,
        'imported_at': int(time.time()),
        'source_items': len(items or []),
        'unique_items': total,
        'added': added,
        'not_found': len(not_found),
        'skipped': skipped,
        'failed': failed,
    }
    _save_trakt_import(record)
    return {
        'ok': failed == 0,
        'record': record,
        'not_found': not_found,
    }


def _get_sync_items():
    library, _ok = _sync_snapshot()
    return [(kind, item) for kind, rows in (library or {}).items() for item in rows.values()]


def get_playback_items():
    data, _ok = _sync_snapshot(resource=lambda a: (
        '/sync/playback', {'extended': 'full'},
        [(a.get(b) or {}).get('playback') for b in ('movies', 'tv_shows', 'anime')]))
    if isinstance(data, dict):
        data = [row for key in ('movies', 'episodes', 'shows', 'anime') for row in data.get(key, [])]
    return sorted(data or [], key=lambda row: row.get('last_watched_at') or '', reverse=True)


def _load_next_episode_cache():
    """Load the last successful Next Episodes response from Kodi profile data."""
    if not os.path.isfile(NEXT_EPISODES_CACHE_FILE):
        return []
    try:
        with open(NEXT_EPISODES_CACHE_FILE, 'r', encoding='utf-8') as fp:
            data = json.load(fp)
    except (OSError, ValueError):
        return []

    rows = data.get('items') if isinstance(data, dict) else data
    if not isinstance(rows, list):
        return []
    return [
        (row.get('section'), row.get('item'))
        for row in rows
        if isinstance(row, dict)
        and row.get('section') in ('shows', 'anime')
        and isinstance(row.get('item'), dict)
    ]


def _save_next_episode_cache(items):
    """Save a successful Next Episodes response without storing credentials."""
    _ensure_dir()
    payload = {
        'cached_at': int(time.time()),
        'items': [
            {'section': section, 'item': item}
            for section, item in items
            if section in ('shows', 'anime') and isinstance(item, dict)
        ],
    }
    try:
        with open(NEXT_EPISODES_CACHE_FILE, 'w', encoding='utf-8') as fp:
            json.dump(payload, fp, ensure_ascii=False)
    except OSError as e:
        xbmc.log(f'Simkl: Failed to cache next episodes: {e}', xbmc.LOGWARNING)


def _next_episode_date(item):
    """Return the official next-episode date as an aware datetime, if valid."""
    raw_date = str((item.get('next_to_watch_info') or {}).get('date') or '').strip()
    if not raw_date:
        return None
    try:
        parsed = datetime.fromisoformat(raw_date.replace('Z', '+00:00'))
    except ValueError:
        return None
    return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed


def _prepare_next_episode_items(items):
    """Apply the user's anime, future-episode, and sort preferences."""
    include_anime = (ADDON.getSetting('simkl_next_episodes_include_anime') or 'true').lower() == 'true'
    hide_future = (ADDON.getSetting('simkl_next_episodes_hide_future') or 'true').lower() == 'true'
    sort_by_title = (ADDON.getSetting('simkl_next_episodes_sort') or '0') == '1'
    now = datetime.now(timezone.utc)

    prepared = []
    for section, item in items:
        if section == 'anime' and not include_anime:
            continue
        if hide_future:
            next_date = _next_episode_date(item)
            if next_date and next_date > now:
                continue
        prepared.append((section, item))

    if sort_by_title:
        prepared.sort(key=lambda pair: (
            _item_title(pair[1]).lower(),
            str((pair[1].get('next_to_watch_info') or {}).get('date') or '9999'),
        ))
    else:
        prepared.sort(key=lambda pair: (
            str((pair[1].get('next_to_watch_info') or {}).get('date') or '9999'),
            _item_title(pair[1]).lower(),
        ))
    return prepared


def get_next_episode_items(refresh=None):
    library, _ok = _sync_snapshot(force=refresh is True)
    include_anime = (ADDON.getSetting('simkl_next_episodes_include_anime') or 'true').lower() == 'true'
    rows = [(kind, item) for kind, entries in (library or {}).items()
            if kind == 'shows' or (kind == 'anime' and include_anime)
            for item in entries.values() if item.get('status') == 'watching'
            and isinstance(item.get('next_to_watch_info'), dict)]
    return _prepare_next_episode_items(rows)


def delete_playback(playback_id):
    """Delete one paused playback session using the official endpoint."""
    if not is_authorized() or playback_id in (None, ''):
        return False
    try:
        playback_id = int(playback_id)
    except (TypeError, ValueError):
        return False
    status, _data, _ = _http_json(
        f'/sync/playback/{playback_id}',
        method='DELETE',
        headers=_auth_headers(),
    )
    return 200 <= (status or 0) < 300


def menu_playback(page='1'):
    from . import cosmos as cosmos_mod
    items = get_playback_items()
    
    if not items:
        _add_simkl_item('[COLOR grey]No in-progress items found on Simkl[/COLOR]', _build_url(action='simkl_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return

    try:
        page = int(page)
    except (ValueError, TypeError):
        page = 1
    page_size = 20
    start_index = (page - 1) * page_size
    end_index = start_index + page_size
    items_to_render = items[start_index:end_index]
    has_next = end_index < len(items)

    for item in items_to_render:
        media_item = item.get('movie') or item.get('show') or item.get('anime')
        if not media_item:
            continue

        is_movie = 'movie' in item
        title = media_item.get('title', 'Untitled')
        year = media_item.get('year', '')
        ids = media_item.get('ids', {})
        tmdb_id = str(ids.get('tmdb', ''))
        imdb_id = str(ids.get('imdb', ''))
        progress = item.get('progress', 0)
        
        label = f'{title} ({year})' if year else title
        
        if not is_movie and item.get('episode'):
            ep_info = item.get('episode')
            s_num = ep_info.get('season')
            e_num = ep_info.get('number')
            if s_num is not None and e_num is not None:
                label += f' - S{s_num:02d}E{e_num:02d}'

        if progress:
            label += f'  [COLOR gold]{progress}%[/COLOR]'

        content_type = 'movie' if is_movie else ('anime' if 'anime' in item else 'tvshow')
        poster, fanart = _item_art(item, content=content_type)

        li = xbmcgui.ListItem(label=label)
        li.setArt({'poster': poster, 'thumb': poster, 'icon': poster or _simkl_icon(), 'fanart': fanart})
        li.setProperty('IsPlayable', 'true')

        payload_dict = {
            'title': title, 'year': year, 'tmdb': tmdb_id, 'imdb': imdb_id,
            'ids': dict(ids),
            'simkl': ids.get('simkl') or ids.get('simkl_id') or '',
            'content': ('movie' if is_movie else ('anime_episode' if content_type == 'anime' else 'episode')),
            'poster': poster, 'fanart': fanart,
        }
        if not is_movie and item.get('episode'):
            ep_info = item.get('episode')
            payload_dict['season'] = ep_info.get('season')
            payload_dict['episode'] = ep_info.get('number')

        payload = json.dumps(payload_dict)
        url = _build_url(action='link_zero', payload=payload)

        playback_context = []
        if item.get('id') not in (None, ''):
            playback_context.append((
                '[COLOR red]Remove Playback Progress[/COLOR]',
                f'RunPlugin({_build_url(action="simkl_delete_playback", playback_id=item.get("id"))})',
            ))
        
        cosmos_mod._set_ctx(li,
            cosmos_mod._fav_ctx_items(payload, tmdb_id, content_type, title),
            cosmos_mod._info_ctx_items(title, tmdb_id, content_type, poster, fanart),
            cosmos_mod._scrobbler_ctx_items(payload, tmdb_id, content_type, title, season=payload_dict.get('season'), episode=payload_dict.get('episode')),
            cosmos_mod._extras_ctx_items(title, tmdb_id, content_type, poster, fanart),
            cosmos_mod._trailer_ctx_items(tmdb_id, content_type),
            cosmos_mod._opensubtitles_ctx_items(payload, tmdb_id, content_type, title, season=payload_dict.get('season'), episode=payload_dict.get('episode')),
            playback_context,
        )
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=False)

    if has_next:
        next_page_params = {'action': 'simkl_playback', 'page': str(page + 1)}
        li = xbmcgui.ListItem(f'[B]Next Page ({page + 1}) »[/B]')
        xbmcplugin.addDirectoryItem(_handle(), _build_url(**next_page_params), li, isFolder=True)

    xbmcplugin.setContent(_handle(), 'videos')
    # Ratings are user-mutated data; never let Kodi reuse an older directory
    # listing after a rating is removed or changed.
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _next_episode_numbers(item, info, section):
    """Return season/episode numbers, including Simkl's anime fallback."""
    season = info.get('season')
    episode = info.get('episode')

    # The official response omits ``season`` for anime.  The compact
    # next_to_watch marker still commonly contains SxxExx; use it when it is
    # available and retain season 1 as the conventional fallback for anime
    # entries that only return E##.
    marker = str(item.get('next_to_watch') or '')
    if season in (None, '') and marker:
        import re
        match = re.search(r'[sS](\d+)[eE](\d+)', marker)
        if match:
            season = match.group(1)
            if episode in (None, ''):
                episode = match.group(2)

    try:
        episode = int(episode)
    except (TypeError, ValueError):
        episode = None
    try:
        season = int(season)
    except (TypeError, ValueError):
        season = 1 if section == 'anime' else None
    return season, episode


def menu_next_episodes():
    """Show the next unwatched episode for each Simkl watching show."""
    if not is_authorized():
        _add_simkl_item(
            '[COLOR yellow]Authorize Simkl to view Next Episodes[/COLOR]',
            _build_url(action='simkl_auth'),
            is_folder=False,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return

    from . import cosmos as cosmos_mod

    items = get_next_episode_items()
    if not items:
        _add_simkl_item(
            '[COLOR grey]No next episodes found on Simkl[/COLOR]',
            _build_url(action='simkl_root'),
            is_folder=False,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return

    rendered = 0
    for section, item in items:
        media_item = item.get('show') or item.get('anime') or {}
        info = item.get('next_to_watch_info') or {}
        title = media_item.get('title') or 'Untitled'
        year = media_item.get('year') or ''
        ids = media_item.get('ids') or {}
        tmdb_id = str(ids.get('tmdb') or '')
        imdb_id = str(ids.get('imdb') or '')
        season, episode = _next_episode_numbers(item, info, section)
        if episode is None:
            xbmc.log(
                f'Simkl: Skipping next episode without an episode number for {title!r}',
                xbmc.LOGWARNING,
            )
            continue

        content_type = 'anime' if section == 'anime' else 'tvshow'
        poster, fanart = _item_art(item, content='tv')
        episode_title = str(info.get('title') or '').strip()
        label = f'{title} ({year})' if year else title
        if season is not None:
            label += f' - S{season:02d}E{episode:02d}'
        else:
            label += f' - E{episode:02d}'
        if episode_title:
            label += f' - {episode_title}'
        show_air_date = (ADDON.getSetting('simkl_next_episodes_show_air_date') or 'true').lower() == 'true'
        air_date = str(info.get('date') or '')[:10]
        if show_air_date and air_date:
            label += f'  [COLOR grey]{air_date}[/COLOR]'

        payload = json.dumps({
            'title': title,
            'year': year,
            'tmdb': tmdb_id,
            'imdb': imdb_id,
            'content': content_type,
            'return_url': _build_url(action='simkl_next_episodes'),
            'ids': dict(ids),
            'simkl': ids.get('simkl') or ids.get('simkl_id') or '',
            'season': season,
            'episode': episode,
            'poster': poster,
            'fanart': fanart,
        })
        context_items = cosmos_mod._scrobbler_ctx_items(
            payload, tmdb_id, content_type, title,
            season=season, episode=episode,
        ) + cosmos_mod._extras_ctx_items(
            title, tmdb_id, content_type, poster, fanart,
        ) + cosmos_mod._trailer_ctx_items(tmdb_id, content_type) + cosmos_mod._opensubtitles_ctx_items(
            payload, tmdb_id, content_type, title,
            season=season, episode=episode,
        )
        # Keep this explicit in the Simkl Next Episodes menu. The shared
        # scrobbler picker can omit service actions depending on its context,
        # but this menu always has the exact season/episode payload needed by
        # Simkl's history endpoint.
        if is_authorized():
            simkl_watch_url = _build_url(
                action='simkl_mark_watched', payload=payload,
            )
            context_items.insert(
                0,
                ('[COLOR orange]Mark as Watched on Simkl[/COLOR]',
                 f'RunPlugin({simkl_watch_url})'),
            )
        _add_simkl_item(
            label,
            _build_url(action='link_zero', payload=payload),
            is_folder=False,
            title=title,
            year=year,
            plot=episode_title,
            content=content_type,
            poster=poster,
            fanart=fanart,
            is_playable=True,
            context_items=context_items,
        )
        rendered += 1

    if not rendered:
        _add_simkl_item(
            '[COLOR grey]No playable next episodes found on Simkl[/COLOR]',
            _build_url(action='simkl_root'),
            is_folder=False,
        )
    xbmcplugin.setContent(_handle(), 'episodes')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _invalidate_ratings_cache():
    from . import simkl_store
    simkl_store.invalidate(DATA_PATH, _account_cache_key())


def _get_ratings_data():
    # Ratings are included in the shared /sync/all-items snapshot.  Do not
    # make a separate /sync/ratings request just to render this menu.
    library, _ok = _sync_snapshot()
    if not isinstance(library, dict):
        return library

    result = {'movies': [], 'shows': [], 'anime': []}
    for source, target in (('movies', 'movies'), ('shows', 'shows'), ('anime', 'anime')):
        for item in (library.get(source) or {}).values():
            if not isinstance(item, dict):
                continue
            media = item.get('movie') or item.get('show') or item.get('anime') or item
            if not isinstance(media, dict):
                continue
            rating = item.get('user_rating') or item.get('rating') or media.get('user_rating') or media.get('rating')
            if rating not in (None, '', 0, '0'):
                result[target].append(item)
    return result


def menu_ratings():
    """Show the user's rated movies, shows, and anime."""
    if not is_authorized():
        _add_simkl_item(
            '[COLOR yellow]Authorize Simkl to view ratings[/COLOR]',
            _build_url(action='simkl_auth'),
            is_folder=False,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    from . import cosmos as cosmos_mod
    data = _get_ratings_data()
    if not isinstance(data, dict):
        _add_simkl_item(
            '[COLOR grey]Unable to load Simkl ratings[/COLOR]',
            _build_url(action='simkl_root'), is_folder=False,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    rendered = 0
    for section in ('movies', 'shows', 'anime'):
        for item in data.get(section) or []:
            media_item = item.get('movie') or item.get('show') or item.get('anime') or item
            if not isinstance(media_item, dict):
                continue
            title = media_item.get('title') or media_item.get('name') or 'Untitled'
            year = media_item.get('year') or ''
            ids = media_item.get('ids') or item.get('ids') or {}
            tmdb_id = str(ids.get('tmdb') or '')
            imdb_id = str(ids.get('imdb') or '')
            rating = item.get('user_rating') or item.get('rating') or ''
            content_type = 'movie' if section == 'movies' else ('anime' if section == 'anime' else 'tvshow')
            poster, fanart = _item_art(item, content=content_type)
            label = f'{title} ({year})' if year else str(title)
            if rating:
                label += f'  [COLOR gold]{rating}/10[/COLOR]'

            li = xbmcgui.ListItem(label=label)
            li.setArt({
                'poster': poster, 'thumb': poster,
                'icon': poster or _simkl_icon(), 'fanart': fanart,
            })
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(str(title))
                if year:
                    tag.setYear(int(year))
                tag.setMediaType('movie' if content_type == 'movie' else 'tvshow')
            except Exception:
                pass

            payload = json.dumps({
                'title': title, 'year': year, 'tmdb': tmdb_id,
                'imdb': imdb_id, 'content': content_type,
                'poster': poster, 'fanart': fanart,
                'simkl': ids.get('simkl') or '',
                'tvdb': ids.get('tvdb') or '',
            })
            if content_type in ('tvshow', 'anime'):
                url = _build_url(action='simkl_show_seasons', payload=json.dumps(item))
                is_folder = True
            else:
                url = _build_url(action='link_zero', payload=payload)
                is_folder = False
                li.setProperty('IsPlayable', 'true')

            cosmos_mod._set_ctx(
                li,
                cosmos_mod._fav_ctx_items(payload, tmdb_id, content_type, title),
                cosmos_mod._info_ctx_items(title, tmdb_id, content_type, poster, fanart),
                cosmos_mod._scrobbler_ctx_items(payload, tmdb_id, content_type, title),
                cosmos_mod._extras_ctx_items(title, tmdb_id, content_type, poster, fanart),
                cosmos_mod._trailer_ctx_items(tmdb_id, content_type),
                cosmos_mod._opensubtitles_ctx_items(payload, tmdb_id, content_type, title),
                [(
                    '[COLOR red]Remove Simkl Rating[/COLOR]',
                    f'RunPlugin({_build_url(action="simkl_remove_rating", payload=payload)})',
                )],
            )
            xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=is_folder)
            rendered += 1

    if not rendered:
        _add_simkl_item(
            '[COLOR grey]No Simkl ratings found[/COLOR]',
            _build_url(action='simkl_root'), is_folder=False,
        )
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _add_simkl_item(label, url, is_folder=True, title='', year='', plot='', content='video', poster='', fanart='', is_playable=False, context_items=None, season=None, episode=None, episode_title=''):
    li = xbmcgui.ListItem(label=label)
    if is_playable:
        li.setProperty('IsPlayable', 'true')
    if title:
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            if year:
                try:
                    tag.setYear(int(year))
                except ValueError:
                    pass
            if plot:
                tag.setPlot(plot)
            if content == 'episode':
                tag.setMediaType('episode')
                tag.setTvShowTitle(title)
                tag.setTitle(episode_title or title)
                if isinstance(season, int):
                    tag.setSeason(season)
                if isinstance(episode, int):
                    tag.setEpisode(episode)
            elif content == 'movie':
                tag.setMediaType('movie')
            elif content in ('tv', 'tvshow'):
                tag.setMediaType('tvshow')
            else:
                tag.setMediaType('video')
        except Exception:
            pass
    art = {}
    art['icon'] = poster or _simkl_icon()
    art['thumb'] = poster or _simkl_icon()
    if poster:
        art['poster'] = poster
    if fanart:
        art['fanart'] = fanart
    li.setArt(art)
    if context_items:
        li.addContextMenuItems(context_items)
    xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=is_folder)


def _get_item_meta(item):
    if not isinstance(item, dict):
        return {}
    for key in ('movie', 'show', 'anime'):
        meta = item.get(key)
        if isinstance(meta, dict):
            return meta
    return item


def _item_title(item):
    meta = _get_item_meta(item)
    title = (meta.get('title') or meta.get('name') or '').strip()
    if title:
        return title
    return 'Untitled'


def _item_year(item):
    meta = _get_item_meta(item)
    year = meta.get('year')
    if year:
        return str(year)
    return ''


def _item_plot(item):
    meta = _get_item_meta(item)
    return (meta.get('overview') or '').strip()


def _item_ids(item):
    meta = _get_item_meta(item)
    return meta.get('ids') or {}


def _item_art(item, content='movie'):
    meta = _get_item_meta(item)
    poster = ''
    fanart = ''
    ids = meta.get('ids') or {}
    tmdb_id = str(ids.get('tmdb') or '')
    if tmdb_id:
        try:
            tmdb_meta = tmdb_mod.get_metadata(tmdb_id, 'movie' if content == 'movie' else 'tvshow')
            poster = tmdb_meta.get('poster') or ''
            fanart = tmdb_meta.get('fanart') or ''
        except Exception:
            pass

    simkl_poster = meta.get('poster')
    if not poster and isinstance(simkl_poster, str):
        if simkl_poster.startswith('http'):
            poster = simkl_poster
        elif simkl_poster:
            poster = f'https://simkl.in/posters/{simkl_poster}_m.jpg'

    simkl_fanart = meta.get('fanart')
    if not fanart and isinstance(simkl_fanart, str):
        if simkl_fanart.startswith('http'):
            fanart = simkl_fanart
        elif simkl_fanart:
            fanart = f'https://simkl.in/fanart/{simkl_fanart}_medium.jpg'

    return poster, fanart


def _simkl_seasons(item):
    """Return the seasons available for a SIMKL show entry."""
    seasons = item.get('seasons') or []
    by_number = {}
    for season in seasons:
        try:
            number = int(
                season.get('number')
                if season.get('number') is not None else 0
            )
        except (TypeError, ValueError):
            continue
        by_number[number] = dict(season)

    tmdb_id = str(_item_ids(item).get('tmdb') or '')
    if tmdb_id:
        try:
            tmdb_seasons = tmdb_mod.get_tv_seasons(tmdb_id) or []
        except Exception as e:
            xbmc.log(f'Simkl TMDB season fallback failed: {e}', xbmc.LOGWARNING)
            tmdb_seasons = []

        for season in tmdb_seasons:
            try:
                number = int(
                    season.get('number')
                    if season.get('number') is not None else 0
                )
            except (TypeError, ValueError):
                continue
            merged = dict(season)
            merged.update(by_number.get(number) or {})
            merged['number'] = number
            by_number[number] = merged

    return [
        by_number[number]
        for number in sorted(by_number)
        if by_number[number].get('episode_count', 0)
        or by_number[number].get('episodes')
        or number == 0
    ]


def _simkl_episode_rows(item, season_num):
    """Merge SIMKL watched rows with the complete TMDB episode catalog."""
    simkl_rows = []
    for season_item in item.get('seasons') or []:
        try:
            number = int(
                season_item.get('number')
                if season_item.get('number') is not None else -1
            )
        except (TypeError, ValueError):
            continue
        if number == season_num:
            simkl_rows = season_item.get('episodes') or []
            break

    by_number = {}
    for row in simkl_rows:
        try:
            number = int(row.get('number'))
        except (TypeError, ValueError):
            continue
        by_number[number] = dict(row)

    tmdb_id = str(_item_ids(item).get('tmdb') or '')
    if tmdb_id:
        try:
            catalog_rows = tmdb_mod.get_tv_episodes(tmdb_id, season_num) or []
        except Exception as e:
            xbmc.log(f'Simkl TMDB episode fallback failed: {e}', xbmc.LOGWARNING)
            catalog_rows = []
        for catalog_row in catalog_rows:
            try:
                number = int(catalog_row.get('number'))
            except (TypeError, ValueError):
                continue
            merged = dict(catalog_row)
            merged.update(by_number.get(number) or {})
            if not merged.get('title'):
                merged['title'] = catalog_row.get('name') or ''
            if not merged.get('overview'):
                merged['overview'] = catalog_row.get('overview') or ''
            by_number[number] = merged

    return [by_number[number] for number in sorted(by_number)]


def menu_my_lists():
    """Show categories for different Simkl lists."""
    categories = (('movies', 'My Movies'), ('shows', 'My TV Shows'), ('anime', 'My Anime'))
    for media, label in sorted(categories, key=lambda pair: pair[1].casefold()):
        _add_simkl_item(label, _build_url(action='simkl_list_items', list_name='media:' + media))
    _add_simkl_item('Custom Lists (Beta, PRO/VIP)', _build_url(action='simkl_custom_lists'))
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _refresh_profile():
    """Recover profile identity for existing authorizations as well as new ones."""
    headers = _auth_headers()
    if not headers:
        return False
    data, _ok = _sync_snapshot(resource=lambda a: (
        '/users/settings', {}, (a.get('settings') or {}).get('all')))
    if not isinstance(data, dict):
        return False
    user = data.get('user') or {}
    name = user.get('name') or user.get('username') or ''
    user_id = (data.get('account') or {}).get('id') or user.get('id') or user.get('user_id')
    ADDON.setSetting('simkl_username', str(name))
    ADDON.setSetting('simkl_user_id', str(user_id or ''))
    return bool(user_id)


def _get_custom_lists():
    """Return the signed-in user's Simkl custom lists (AUTH V2, PRO/VIP)."""
    user_id = (ADDON.getSetting('simkl_user_id') or '').strip()
    if not user_id:
        if not _refresh_profile():
            return None
        user_id = (ADDON.getSetting('simkl_user_id') or '').strip()
    data, _ok = _sync_snapshot(resource=lambda a: (
        f'/lists/user/{quote_plus(user_id)}', {'limit': 50, 'page': 1},
        (a.get('custom_lists') or {}).get('lists') or {}))
    if not isinstance(data, dict):
        _log('Custom list discovery unavailable', xbmc.LOGWARNING)
        return None
    if data.get('error'):
        _log(f'custom list discovery returned {data.get("error")}', xbmc.LOGWARNING)
        return None
    lists = data.get('lists') or []
    _log(f'custom list discovery returned {len(lists)} lists', xbmc.LOGINFO)
    return [item for item in lists if isinstance(item, dict) and item.get('id')]


def menu_custom_lists():
    """Render the authorized user's custom Simkl lists."""
    lists = _get_custom_lists()
    if lists is None:
        _add_simkl_item(_LAST_API_ERROR or 'Custom lists unavailable; check account access', _build_url(action='simkl_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return
    if not lists:
        _add_simkl_item('[COLOR grey]No custom lists available (PRO/VIP required)[/COLOR]', _build_url(action='simkl_root'), is_folder=False)
    # Keep the account's list content predictable in Kodi regardless of the
    # order returned by Simkl.
    lists = sorted(lists, key=lambda item: str(item.get('name') or f'List {item.get("id")}').casefold())
    for item in lists:
        name = str(item.get('name') or f'List {item.get("id")}')
        count = (item.get('counts') or {}).get('items')
        label = f'{name} ({count})' if count is not None else name
        _add_simkl_item(label, _build_url(action='simkl_custom_list_items', list_id=str(item['id'])))
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def menu_custom_list_items(list_id, page='1'):
    """Render items from one authorized Simkl custom list."""
    data, _ok = _sync_snapshot(resource=lambda a: (
        f'/lists/{quote_plus(str(list_id or ""))}',
        {'limit': 500, 'page': 1, 'extended': 'full'},
        [(a.get('custom_lists') or {}).get('lists') or {}, int(time.time() // 86400)]))
    if not isinstance(data, dict) or data.get('error'):
        reason = (data or {}).get('error') if isinstance(data, dict) else None
        _log(f'custom list {list_id} fetch failed: error={reason or "none"}', xbmc.LOGWARNING)
        _add_simkl_item('[COLOR grey]Custom list unavailable (PRO/VIP access may be required)[/COLOR]', _build_url(action='simkl_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    media_type = str(data.get('media_type') or 'movies').lower()
    section = 'anime' if media_type == 'anime' else ('shows' if media_type in ('shows', 'tv') else 'movies')
    items = [(section, item) for item in (data.get('items') or []) if isinstance(item, dict)]
    _log(f'custom list {list_id} returned {len(items)} items', xbmc.LOGINFO)
    # Use the existing renderer by temporarily preserving the list shape in a
    # small local path; custom items already match the normal Simkl item fields.
    if not items:
        _add_simkl_item('[COLOR grey]No items found in this custom list[/COLOR]', _build_url(action='simkl_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    cache_key = f'custom:{list_id}'
    _CUSTOM_LIST_CACHE[cache_key] = items
    menu_list_items(cache_key, page=page)


def menu_list_items(list_name, page='1'):
    if str(list_name).startswith('media:'):
        media = list_name.split(':', 1)[1]
        if media in ('movies', 'shows', 'anime'):
            statuses = sorted(TRAKT_IMPORT_DESTINATIONS, key=lambda pair: pair[0].casefold())
            xbmcplugin.addSortMethod(_handle(), xbmcplugin.SORT_METHOD_LABEL)
            for label, status in statuses:
                if media == 'movies' and status in ('watching', 'hold'):
                    continue
                _add_simkl_item(label, _build_url(action='simkl_list_items', list_name=media + ':' + status))
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return
    from . import cosmos as cosmos_mod
    items = _get_list(list_name)
    if items is None:
        label = '[COLOR red]%s[/COLOR]' % (_LAST_API_ERROR or 'Simkl list unavailable; please reconnect your account')
        _add_simkl_item(label, _build_url(action='simkl_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return
    if not items:
        _add_simkl_item(f'[COLOR grey]No items found in "{list_name}" list[/COLOR]', _build_url(action='simkl_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    # Simkl's API/cache order is not guaranteed to be alphabetical. Sort the
    # full list before paging so entries stay A-Z across every page.
    items = sorted(items, key=lambda pair: _item_title(pair[1]).casefold())

    try:
        page = int(page)
    except (ValueError, TypeError):
        page = 1

    page_size = 20
    start_index = (page - 1) * page_size
    end_index = start_index + page_size

    items_to_render = items[start_index:end_index]
    has_next = end_index < len(items)

    xbmcplugin.addSortMethod(_handle(), xbmcplugin.SORT_METHOD_LABEL)

    has_movies = False
    has_tv = False
    for section, item in items_to_render:
        title = _item_title(item)
        year = _item_year(item)
        plot = _item_plot(item)
        ids = _item_ids(item)
        tmdb_id = str(ids.get('tmdb') or '')
        imdb_id = str(ids.get('imdb') or '')
        content_type = 'anime' if section == 'anime' else ('tvshow' if section == 'shows' else 'movie')
        poster, fanart = _item_art(item, content=content_type)

        li = xbmcgui.ListItem(label=f'{title} ({year})' if year else title)
        li.setArt({'poster': poster, 'thumb': poster, 'icon': poster or _simkl_icon(), 'fanart': fanart})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            if year: tag.setYear(int(year))
            if plot: tag.setPlot(plot)
            tag.setMediaType(content_type)
        except Exception: pass

        if section in ('shows', 'anime'):
            has_tv = True
            payload = json.dumps(item)
            url = _build_url(action='simkl_show_seasons', payload=payload)
            is_folder = True
            li.setProperty('IsPlayable', 'false')

            ctx_payload = json.dumps({
                'title': title, 'year': year, 'tmdb': tmdb_id, 'imdb': imdb_id,
                'content': content_type, 'poster': poster, 'fanart': fanart,
            })
            cosmos_mod._set_ctx(li,
                cosmos_mod._fav_ctx_items(ctx_payload, tmdb_id, content_type, title),
                cosmos_mod._info_ctx_items(title, tmdb_id, content_type, poster, fanart),
                cosmos_mod._scrobbler_ctx_items(ctx_payload, tmdb_id, content_type, title),
                cosmos_mod._extras_ctx_items(title, tmdb_id, content_type, poster, fanart),
                cosmos_mod._trailer_ctx_items(tmdb_id, content_type),
                cosmos_mod._opensubtitles_ctx_items(ctx_payload, tmdb_id, content_type, title)
            )
        else:
            has_movies = True
            payload = json.dumps({
                'title': title, 'year': year, 'tmdb': tmdb_id, 'imdb': imdb_id,
                'content': 'movie', 'poster': poster, 'fanart': fanart
            })
            url = _build_url(action='link_zero', payload=payload)
            is_folder = False
            li.setProperty('IsPlayable', 'true')

            cosmos_mod._set_ctx(li,
                cosmos_mod._fav_ctx_items(payload, tmdb_id, 'movie', title),
                cosmos_mod._info_ctx_items(title, tmdb_id, 'movie', poster, fanart),
                cosmos_mod._scrobbler_ctx_items(payload, tmdb_id, 'movie', title),
                cosmos_mod._extras_ctx_items(title, tmdb_id, 'movie', poster, fanart),
                cosmos_mod._trailer_ctx_items(tmdb_id, 'movie'),
                cosmos_mod._opensubtitles_ctx_items(payload, tmdb_id, 'movie', title)
            )
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=is_folder)

    if has_next:
        next_page_params = {'action': 'simkl_list_items', 'list_name': list_name, 'page': str(page + 1)}
        if str(list_name).startswith('custom:'):
            next_page_params = {'action': 'simkl_custom_list_items', 'list_id': list_name.split(':', 1)[1], 'page': str(page + 1)}
        li = xbmcgui.ListItem(f'[B]Next Page ({page + 1}) »[/B]')
        xbmcplugin.addDirectoryItem(_handle(), _build_url(**next_page_params), li, isFolder=True)

    if has_tv and has_movies:
        xbmcplugin.setContent(_handle(), 'videos')
    elif has_tv:
        xbmcplugin.setContent(_handle(), 'tvshows')
    else:
        xbmcplugin.setContent(_handle(), 'movies')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def menu_history(page='1'):
    from . import cosmos as cosmos_mod
    try:
        movies = _get_history('movies') or []
        shows = _get_history('shows') or []
        anime = _get_history('anime') or []
    except RuntimeError:
        _add_simkl_item('Simkl history unavailable; try again later', _build_url(action='simkl_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    all_history = movies + shows + anime
    all_history.sort(key=lambda x: x.get('last_watched_at', '0'), reverse=True)

    if not all_history:
        _add_simkl_item('[COLOR grey]No history items found[/COLOR]', _build_url(action='simkl_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    try:
        page = int(page)
    except (ValueError, TypeError):
        page = 1

    page_size = 20
    start_index = (page - 1) * page_size
    end_index = start_index + page_size

    items_to_render = all_history[start_index:end_index]
    has_next = end_index < len(all_history)

    has_movies = False
    has_tv = False
    for item in items_to_render:
        media_item = item.get('movie') or item.get('show') or item.get('anime')
        if not media_item:
            continue

        is_movie = 'movie' in item
        title = media_item.get('title', 'Untitled')
        year = media_item.get('year', '')
        plot = media_item.get('overview', '') or ''
        ids = media_item.get('ids', {})
        tmdb_id = str(ids.get('tmdb', ''))
        imdb_id = str(ids.get('imdb', ''))

        is_show = 'show' in item
        is_anime = 'anime' in item
        if is_movie:
            content_type = 'movie'
        elif is_anime:
            content_type = 'anime'
        else:
            content_type = 'tvshow'

        poster, fanart = _item_art(item, content=content_type)

        li = xbmcgui.ListItem(label=f'{title} ({year})' if year else title)
        li.setArt({'poster': poster, 'thumb': poster, 'icon': poster or _simkl_icon(), 'fanart': fanart})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            if year:
                try:
                    tag.setYear(int(year))
                except (ValueError, TypeError):
                    pass
            if plot: tag.setPlot(plot)
            tag.setMediaType(content_type)
        except Exception: pass

        if not is_movie:  # show or anime
            has_tv = True
            payload = json.dumps(item)
            url = _build_url(action='simkl_show_seasons', payload=payload)
            is_folder = True
            li.setProperty('IsPlayable', 'false')

            item_content_type = 'anime' if is_anime else 'tvshow'
            ctx_payload = json.dumps({
                'title': title, 'year': year, 'tmdb': tmdb_id, 'imdb': imdb_id,
                'content': item_content_type, 'poster': poster, 'fanart': fanart,
                'seasons': (media_item.get('seasons') or []),
            })
            remove_ctx = [
                ('[COLOR red]Remove from History[/COLOR]',
                 f'RunPlugin({_build_url(action="simkl_remove_from_history", payload=ctx_payload)})')
            ]
            cosmos_mod._set_ctx(li,
                cosmos_mod._fav_ctx_items(ctx_payload, tmdb_id, item_content_type, title),
                cosmos_mod._info_ctx_items(title, tmdb_id, item_content_type, poster, fanart),
                cosmos_mod._scrobbler_ctx_items(ctx_payload, tmdb_id, item_content_type, title),
                cosmos_mod._extras_ctx_items(title, tmdb_id, item_content_type, poster, fanart),
                cosmos_mod._trailer_ctx_items(tmdb_id, item_content_type),
                cosmos_mod._opensubtitles_ctx_items(ctx_payload, tmdb_id, item_content_type, title),
                remove_ctx
            )
        else:
            has_movies = True
            payload = json.dumps({
                'title': title, 'year': year, 'tmdb': tmdb_id, 'imdb': imdb_id,
                'content': 'movie', 'poster': poster, 'fanart': fanart,
            })
            url = _build_url(action='link_zero', payload=payload)
            is_folder = False
            li.setProperty('IsPlayable', 'true')

            remove_ctx = [
                ('[COLOR red]Remove from History[/COLOR]',
                 f'RunPlugin({_build_url(action="simkl_remove_from_history", payload=payload)})')
            ]
            cosmos_mod._set_ctx(li,
                cosmos_mod._fav_ctx_items(payload, tmdb_id, 'movie', title),
                cosmos_mod._info_ctx_items(title, tmdb_id, 'movie', poster, fanart),
                cosmos_mod._scrobbler_ctx_items(payload, tmdb_id, 'movie', title),
                cosmos_mod._extras_ctx_items(title, tmdb_id, 'movie', poster, fanart),
                cosmos_mod._trailer_ctx_items(tmdb_id, 'movie'),
                cosmos_mod._opensubtitles_ctx_items(payload, tmdb_id, 'movie', title),
                remove_ctx
            )
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=is_folder)

    if has_next:
        next_page_params = {'action': 'simkl_history', 'page': str(page + 1)}
        li = xbmcgui.ListItem(f'[B]Next Page ({page + 1}) »[/B]')
        xbmcplugin.addDirectoryItem(_handle(), _build_url(**next_page_params), li, isFolder=True)

    if has_tv and has_movies:
        xbmcplugin.setContent(_handle(), 'videos')
    elif has_tv:
        xbmcplugin.setContent(_handle(), 'tvshows')
    else:
        xbmcplugin.setContent(_handle(), 'movies')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def simkl_sync_activities(show_notification=False):
    _data, ok = _sync_snapshot()
    return ok


def menu_show_seasons(payload):
    try:
        item = json.loads(payload or '{}')
    except (ValueError, TypeError):
        item = {}
    seasons = _simkl_seasons(item)
    if not seasons:
        _add_simkl_item('[COLOR grey]No season data available[/COLOR]', _build_url(action='simkl_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    poster, fanart = _item_art(item, content='tv')
    title = _item_title(item)
    year = _item_year(item)
    plot = _item_plot(item)

    for season in seasons:
        number = season.get('number') if season.get('number') is not None else 0
        label = f'Season {number}' if number else 'Season 0'
        payload_text = json.dumps(item)
        _add_simkl_item(
            label, 
            _build_url(action='simkl_show_episodes', payload=payload_text, season=str(number)), 
            is_folder=True,
            title=title,
            year=year,
            plot=plot,
            content='tvshow',
            poster=poster,
            fanart=fanart
        )

    xbmcplugin.setContent(_handle(), 'seasons')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def menu_show_episodes(payload, season=''):
    from . import cosmos as cosmos_mod
    try:
        item = json.loads(payload or '{}')
    except (ValueError, TypeError):
        item = {}
    try:
        season_num = int(season or 0)
    except (ValueError, TypeError):
        season_num = 0

    episodes = _simkl_episode_rows(item, season_num)

    if not episodes:
        _add_simkl_item('[COLOR grey]No episode data available[/COLOR]', _build_url(action='simkl_root'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    base_title = _item_title(item)
    year = _item_year(item)
    ids = _item_ids(item)
    poster, fanart = _item_art(item, content='tv')
    episode_content = 'anime' if 'anime' in item else 'tv'

    for ep in episodes:
        ep_number = int(ep.get('number') or 0)
        ep_title = ep.get('title') or f'Episode {ep_number}'
        label = f'S{season_num:02d}E{ep_number:02d} {ep_title}' if season_num else f'Episode {ep_number}'
        payload_text = json.dumps({
            'title': base_title,
            'year': year,
            'tmdb': str(ids.get('tmdb') or ''),
            'imdb': str(ids.get('imdb') or ''),
            'content': episode_content,
            'season': season_num,
            'episode': ep_number,
            'poster': poster,
            'fanart': fanart
        })
        remove_ctx = [
            ('[COLOR red]Remove from History[/COLOR]',
             f'RunPlugin({_build_url(action="simkl_remove_from_history", payload=payload_text)})')
        ]
        context_items = cosmos_mod._scrobbler_ctx_items(
            payload_text, str(ids.get('tmdb') or ''), episode_content, base_title,
            season=season_num, episode=ep_number,
        ) + remove_ctx
        _add_simkl_item(
            label,
            _build_url(action='link_zero', payload=payload_text),
            is_folder=False,
            title=base_title,
            year=year,
            plot=ep_title,
            content=episode_content,
            poster=poster,
            fanart=fanart,
            is_playable=True,
            context_items=context_items
        )

    xbmcplugin.setContent(_handle(), 'episodes')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def action_auth():
    if authorize():
        xbmc.executebuiltin('Container.Refresh')


def action_revoke():
    revoke()
    xbmc.executebuiltin('Container.Refresh')


def action_sync():
    if sync_all():
        xbmc.executebuiltin('Container.Refresh')


def sync_all():
    _data, ok = _sync_snapshot(force=True)
    if ok:
        from . import watched
        watched.sync_remote_now('simkl')
    xbmcgui.Dialog().notification('Simkl',
        'Library synced; other sections refresh when opened' if ok else 'Sync unavailable; cached data retained',
        xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_WARNING, 3500)
    return ok


def action_delete_playback(playback_id):
    """Remove a paused playback session from Simkl."""
    if not is_authorized():
        xbmcgui.Dialog().notification(
            'Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        return
    if delete_playback(playback_id):
        xbmcgui.Dialog().notification(
            'Simkl', 'Playback progress removed', xbmcgui.NOTIFICATION_INFO, 2500,
        )
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcgui.Dialog().notification(
            'Simkl', 'Failed to remove playback progress',
            xbmcgui.NOTIFICATION_ERROR, 3500,
        )

def action_clear_collection():
    """Handle the 'Clear Collection' menu action."""
    if not is_authorized():
        xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    if xbmcgui.Dialog().yesno('Simkl', 'Are you sure you want to clear your entire Simkl collection (Completed list)? This cannot be undone.'):
        prog = xbmcgui.DialogProgress()
        prog.create('Simkl', 'Clearing collection...')
        try:
            prog.update(50, 'Fetching and removing items...')
            if clear_collection():
                xbmcgui.Dialog().notification('Simkl', 'Collection Cleared', xbmcgui.NOTIFICATION_INFO, 3000)
                xbmc.executebuiltin('Container.Refresh')
            else:
                xbmcgui.Dialog().notification('Simkl', 'Failed to clear collection', xbmcgui.NOTIFICATION_ERROR, 4000)
        finally:
            prog.close()

def action_add_to_collection(payload_str):
    """Handle the 'Add to Collection' context menu action."""
    if not is_authorized():
        xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification('Simkl', 'Invalid item data for collection', xbmcgui.NOTIFICATION_ERROR)
        return
    
    if add_to_collection(meta):
        xbmcgui.Dialog().notification('Simkl', 'Added to Collection', xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcgui.Dialog().notification('Simkl', 'Failed to add to collection', xbmcgui.NOTIFICATION_ERROR, 4000)

def action_remove_from_collection(payload_str):
    """Handle the 'Remove from Collection' context menu action."""
    if not is_authorized():
        xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification('Simkl', 'Invalid item data for removal', xbmcgui.NOTIFICATION_ERROR)
        return
    
    if remove_from_collection(meta):
        xbmcgui.Dialog().notification('Simkl', 'Removed from Collection', xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcgui.Dialog().notification('Simkl', 'Failed to remove from collection', xbmcgui.NOTIFICATION_ERROR, 4000)

def action_remove_from_watchlist(payload_str):
    """Handle the 'Remove from Watchlist' context menu action."""
    if not is_authorized():
        xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification('Simkl', 'Invalid item data for removal', xbmcgui.NOTIFICATION_ERROR)
        return
    
    if remove_from_watchlist(meta):
        xbmcgui.Dialog().notification('Simkl', 'Removed from Watchlist', xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcgui.Dialog().notification('Simkl', 'Failed to remove from watchlist', xbmcgui.NOTIFICATION_ERROR, 4000)

def action_remove_from_history(payload_str):
    """Handle the 'Remove from History' context menu action."""
    if not is_authorized():
        xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification('Simkl', 'Invalid item data for removal', xbmcgui.NOTIFICATION_ERROR)
        return
    
    if remove_from_history(meta):
        xbmcgui.Dialog().notification('Simkl', 'Removed from History', xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcgui.Dialog().notification('Simkl', 'Failed to remove from history', xbmcgui.NOTIFICATION_ERROR, 4000)

def action_clear_history():
    """Handle the 'Clear History' menu action."""
    if not is_authorized():
        xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    if xbmcgui.Dialog().yesno('Simkl', 'Are you sure you want to clear your entire Simkl watch history? This cannot be undone.'):
        prog = xbmcgui.DialogProgress()
        prog.create('Simkl', 'Clearing history...')
        try:
            prog.update(50, 'Fetching and removing items...')
            if clear_history():
                xbmcgui.Dialog().notification('Simkl', 'History Cleared', xbmcgui.NOTIFICATION_INFO, 3000)
                xbmc.executebuiltin('Container.Refresh')
            else:
                xbmcgui.Dialog().notification('Simkl', 'Failed to clear history', xbmcgui.NOTIFICATION_ERROR, 4000)
        finally:
            prog.close()

def action_watchlist():
    if not is_authorized():
        xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000)
        menu_root()
        return
    menu_my_lists()


def action_history(page='1'):
    if not is_authorized():
        xbmcgui.Dialog().notification('Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000)
        menu_root()
        return
    menu_history(page=page)


def action_add_watchlist(payload_str):
    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification('Simkl', 'Invalid item data', xbmcgui.NOTIFICATION_ERROR)
        return

    if _add_to_watchlist_impl(
        title=meta.get('title', ''),
        year=meta.get('year', ''),
        tmdb=meta.get('tmdb', ''),
        imdb=meta.get('imdb', ''),
        content=meta.get('content', 'movie'),
        season=meta.get('season', ''),
        episode=meta.get('episode', ''),
    ):
        xbmc.executebuiltin('Container.Refresh')


def action_rate(payload_str):
    """Prompt for and save a Simkl rating from a context menu."""
    if not is_authorized():
        xbmcgui.Dialog().notification(
            'Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        return
    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification(
            'Simkl', 'Invalid item data', xbmcgui.NOTIFICATION_ERROR, 3000,
        )
        return

    title = meta.get('title') or meta.get('name') or 'Item'
    rating_text = xbmcgui.Dialog().numeric(0, f'{title} — Simkl rating (1-10)')
    if not rating_text:
        return
    try:
        rating = int(rating_text)
    except (TypeError, ValueError):
        rating = 0
    if not 1 <= rating <= 10:
        xbmcgui.Dialog().notification(
            'Simkl', 'Rating must be a number from 1 to 10',
            xbmcgui.NOTIFICATION_ERROR, 3000,
        )
        return

    if add_rating(meta, rating):
        xbmcgui.Dialog().notification(
            'Simkl', f'Rated {title} {rating}/10',
            xbmcgui.NOTIFICATION_INFO, 2500,
        )
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcgui.Dialog().notification(
            'Simkl', 'Failed to save Simkl rating',
            xbmcgui.NOTIFICATION_ERROR, 3500,
        )


def action_remove_rating(payload_str):
    """Remove only the selected Simkl rating."""
    if not is_authorized():
        xbmcgui.Dialog().notification(
            'Simkl', 'Authorize Simkl first', xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        return
    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification(
            'Simkl', 'Invalid item data', xbmcgui.NOTIFICATION_ERROR, 3000,
        )
        return

    if remove_rating(meta):
        xbmcgui.Dialog().notification(
            'Simkl', 'Rating removed', xbmcgui.NOTIFICATION_INFO, 2500,
        )
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.cosmos/?action=simkl_ratings,replace)')
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmcgui.Dialog().notification(
            'Simkl', 'Failed to remove Simkl rating',
            xbmcgui.NOTIFICATION_ERROR, 3500,
        )


def action_mark_watched(payload_str):
    try:
        meta = json.loads(payload_str)
    except (json.JSONDecodeError, TypeError):
        xbmcgui.Dialog().notification('Simkl', 'Invalid item data', xbmcgui.NOTIFICATION_ERROR)
        return

    content = meta.get('content', 'movie')
    season = meta.get('season')
    episode = meta.get('episode')

    if content in ('show', 'tvshow') and not (season and episode):
        dlg = xbmcgui.Dialog()
        choice = dlg.select('Mark as Watched on Simkl', ['Mark entire show as watched', 'Mark a specific episode'])
        
        if choice == 0: # Mark entire show
             # The existing logic in _mark_watched_impl handles this when season/episode are None
            season, episode = None, None
        elif choice == 1: # Mark specific episode
            title = meta.get('title') or 'TV Show'
            season_str = dlg.numeric(0, f'{title} \u2014 Season number')
            if not season_str: return
            try:
                season = int(season_str)
            except ValueError:
                xbmcgui.Dialog().notification('Simkl', 'Invalid season number', xbmcgui.NOTIFICATION_ERROR)
                return

            episode_str = dlg.numeric(0, f'{title} S{season:02d} \u2014 Episode number')
            if not episode_str: return
            try:
                episode = int(episode_str)
            except ValueError:
                xbmcgui.Dialog().notification('Simkl', 'Invalid episode number', xbmcgui.NOTIFICATION_ERROR)
                return
        else: # Cancelled
            return

    if _mark_watched_impl(
        title=meta.get('title', ''),
        year=meta.get('year', ''),
        tmdb=meta.get('tmdb', ''),
        imdb=meta.get('imdb', ''),
        content=content,
        season=season,
        episode=episode,
    ):
        xbmc.executebuiltin('Container.Refresh')
