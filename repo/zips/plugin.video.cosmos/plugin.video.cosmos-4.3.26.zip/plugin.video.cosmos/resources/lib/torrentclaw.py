# -*- coding: utf-8 -*-
"""TorrentClaw's public JSON API and Release Hub browser."""
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit, parse_qsl
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

DEFAULT_URL = 'https://torrentclaw.to'
PAGE_SIZE = 24
MAX_BYTES = 8 * 1024 * 1024
_META_CACHE = {}


def tmdb_client():
    from . import tmdb
    return tmdb


def show_source_picker(links, title, icon):
    from . import torrentclaw_source_picker
    return torrentclaw_source_picker.show(links, title=title, section_icon=icon)


def metadata(item, season=None, episode=None):
    """Enrich safely: explicit IDs first, then exact title/year matches only."""
    content = 'tvshow' if item.get('contentType') == 'show' else 'movie'
    key = (content, str(item.get('tmdbId') or ''), item.get('imdbId'),
           item.get('title'), item.get('year'), season, episode)
    cached = _META_CACHE.get(key)
    if cached and time.monotonic() - cached[0] < 900:
        return dict(cached[1])
    meta = {'title': item.get('title') or '', 'plot': item.get('overview') or '',
            'year': number(item.get('year')), 'poster': item.get('posterUrl') or '',
            'fanart': item.get('backdropUrl') or '', 'imdb_id': item.get('imdbId') or '',
            'tmdb_id': str(item.get('tmdbId') or ''), 'content': content,
            'genre': ', '.join(item.get('genres') or [])}
    try:
        meta['rating'] = float(item.get('ratingTmdb') or item.get('ratingImdb') or 0)
    except (ValueError, TypeError):
        meta['rating'] = 0.0
    try:
        client = tmdb_client()
        tmdb_id = meta['tmdb_id']
        if not tmdb_id and meta['imdb_id']:
            tmdb_id = client.find_by_imdb_id(meta['imdb_id'], content)
        if not tmdb_id and meta['title']:
            kind = 'tv' if content == 'tvshow' else 'movie'
            query = {'api_key': client._api_key(), 'query': meta['title'], 'page': 1}
            if meta['year']:
                query['first_air_date_year' if kind == 'tv' else 'year'] = meta['year']
            results = (client._fetch('https://api.themoviedb.org/3/search/' + kind + '?' + urlencode(query)) or {}).get('results') or []
            normalize = lambda title: re.sub(r'[^\w]+', '', str(title).casefold())
            candidates = [r for r in results if
                          normalize(meta['title']) in {normalize(r.get(k) or '') for k in ('title', 'name', 'original_title', 'original_name')}
                          and (not meta['year'] or number((r.get('release_date') or r.get('first_air_date') or '')[:4]) == meta['year'])]
            if len(candidates) == 1:
                tmdb_id = str(candidates[0]['id'])
        if tmdb_id:
            meta['tmdb_id'] = str(tmdb_id)
            details = client.get_metadata(tmdb_id, content) or {}
            meta.update({k: v for k, v in details.items() if v not in (None, '', [], 0)})
            if content == 'tvshow' and season is not None and episode is not None:
                detail = client.get_episode_meta(tmdb_id, season, episode) or {}
                meta['tvshowtitle'] = meta['title']
                for source, target in (('name', 'title'), ('overview', 'plot'), ('still', 'thumb'),
                                       ('air_date', 'premiered'), ('runtime', 'runtime'), ('rating', 'rating')):
                    if detail.get(source):
                        meta[target] = detail[source]
    except Exception:
        # Metadata outages must never prevent browsing or source selection.
        xbmc.log('COSMOS TorrentClaw: TMDB unavailable; using provider metadata.', xbmc.LOGWARNING)
    if season is not None and episode is not None:
        meta.update(content='episode', season=season, episode=episode,
                    tvshowtitle=meta.get('tvshowtitle') or item.get('title') or '')
    if len(_META_CACHE) >= 256:
        _META_CACHE.clear()
    _META_CACHE[key] = (time.monotonic(), dict(meta))
    return meta


def apply_metadata(li, meta):
    tmdb_client().apply_to_listitem(li, meta, meta['content'])
    tag = li.getVideoInfoTag()
    ids = {name: str(meta[field]) for name, field in (('tmdb', 'tmdb_id'), ('imdb', 'imdb_id')) if meta.get(field)}
    if ids:
        tag.setUniqueIDs(ids, 'tmdb' if 'tmdb' in ids else 'imdb')
    if meta['content'] == 'episode':
        tag.setMediaType('episode')
        tag.setTvShowTitle(meta.get('tvshowtitle', ''))
        tag.setSeason(meta['season'])
        tag.setEpisode(meta['episode'])
    if meta.get('thumb'):
        li.setArt({'thumb': meta['thumb']})


class ApiError(Exception):
    pass


def connect():
    """Guide the user through saving an existing API key."""
    dialog = xbmcgui.Dialog()
    if xbmcaddon.Addon().getSetting('torrentclaw_api_key').strip():
        dialog.ok('TorrentClaw',
                  'An API key is already saved. Select Disconnect TorrentClaw '
                  'to clear it before connecting with another key.')
        return False
    dialog.ok('Connect TorrentClaw',
              'Sign in at https://torrentclaw.to and open your profile API Keys tab. '
              'Copy your API key, then enter it on the next screen. '
              'Playback also requires a configured Debrid account.')
    key = dialog.input('TorrentClaw API key', type=xbmcgui.INPUT_ALPHANUM,
                       option=xbmcgui.ALPHANUM_HIDE_INPUT).strip()
    if not key:
        return False
    if any(ord(char) < 33 or ord(char) > 126 for char in key):
        dialog.ok('TorrentClaw', 'Enter the API key only, without spaces or line breaks.')
        return False
    addon = xbmcaddon.Addon()
    addon.setSetting('torrentclaw_api_key', key)
    # Confirm Kodi persisted the credential before reporting a successful login.
    if addon.getSetting('torrentclaw_api_key').strip() != key:
        dialog.ok('TorrentClaw',
                  'The API key could not be saved in Cosmos settings. '
                  'Please try again or enter it under Settings > TorrentClaw.')
        return False
    dialog.ok('TorrentClaw', 'API key saved successfully. Cosmos will use it for '
              'TorrentClaw requests and playback.')
    return True


def disconnect():
    """Remove the locally saved key without revoking it on the website."""
    xbmcaddon.Addon().setSetting('torrentclaw_api_key', '')
    xbmcgui.Dialog().ok('TorrentClaw',
                        'TorrentClaw API key removed from Cosmos. You can connect again '
                        'with a different API key when needed.')
    return True


def request(endpoint, **params):
    addon = xbmcaddon.Addon()
    base = DEFAULT_URL
    parsed = urlsplit(base)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ApiError('Set a valid HTTPS base URL in TorrentClaw settings.')
    headers = {'Accept': 'application/json', 'User-Agent': 'COSMOS TorrentClaw/1.0'}
    key = addon.getSetting('torrentclaw_api_key').strip()
    if key:
        headers['Authorization'] = 'Bearer ' + key
    url = base + '/api/v1/' + endpoint + '?' + urlencode({
        k: v for k, v in params.items() if v is not None and v != ''
    })
    try:
        with urlopen(Request(url, headers=headers), timeout=20) as response:
            raw = response.read(MAX_BYTES + 1)
        if len(raw) > MAX_BYTES:
            raise ApiError('TorrentClaw response was too large. Narrow your search.')
        data = json.loads(raw.decode('utf-8'))
        if not isinstance(data, dict):
            raise ValueError('Expected an object')
        return data
    except HTTPError as exc:
        if exc.code in (401, 403):
            raise ApiError('Check your TorrentClaw API key in addon settings.') from exc
        if exc.code == 429:
            raise ApiError('TorrentClaw rate limit reached. Please try again later.') from exc
        raise ApiError('TorrentClaw returned HTTP %s.' % exc.code) from exc
    except (URLError, OSError) as exc:
        raise ApiError('Cannot reach TorrentClaw. Please try again later.') from exc
    except (ValueError, UnicodeError) as exc:
        raise ApiError('TorrentClaw returned an invalid API response.') from exc


def number(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def page_items(data, endpoint):
    items = data.get('results' if endpoint == 'search' else 'items')
    if not isinstance(items, list):
        raise ApiError('TorrentClaw returned an unexpected list format.')
    return [item for item in items if isinstance(item, dict)]


def has_next(data, page):
    return page * max(1, number(data.get('pageSize'), PAGE_SIZE)) < number(data.get('total'))


def magnet_for(torrent, title, season=None, episode=None):
    magnet = str(torrent.get('magnetUrl') or '')
    if not magnet.lower().startswith('magnet:?'):
        info_hash = str(torrent.get('infoHash') or '')
        if not re.fullmatch(r'(?:[a-fA-F0-9]{40}|[A-Z2-7a-z]{32})', info_hash):
            return ''
        magnet = 'magnet:?' + urlencode({'xt': 'urn:btih:' + info_hash})
    # The shared Debrid resolver uses dn to select an episode inside a pack.
    display = torrent.get('rawTitle') or title
    if season is not None and episode is not None:
        display = '%s S%02dE%02d' % (title, season, episode)
    values = [(k, v) for k, v in parse_qsl(urlsplit(magnet).query) if k != 'dn']
    values.append(('dn', display))
    return 'magnet:?' + urlencode(values)


def playback_payload(item, torrent, season=None, episode=None, meta=None):
    meta = meta or {}
    return {
        'url': magnet_for(torrent, item.get('title', ''), season, episode),
        'title': item.get('title', ''), 'label': torrent.get('rawTitle') or item.get('title', ''),
        'content': 'episode' if item.get('contentType') == 'show' else 'movie',
        'tmdb': str(meta.get('tmdb_id') or item.get('tmdbId') or ''), 'imdb': meta.get('imdb_id') or item.get('imdbId') or '',
        'year': str(meta.get('year') or item.get('year') or ''), 'poster': meta.get('poster') or item.get('posterUrl') or '',
        'fanart': meta.get('fanart') or item.get('backdropUrl') or '', 'source': 'TorrentClaw',
        'metadata': meta,
        'season': '' if season is None else str(season),
        'episode': '' if episode is None else str(episode),
    }


def source_label(torrent):
    size = number(torrent.get('sizeBytes')) / (1024 ** 3)
    parts = [torrent.get('quality') or 'Unknown quality']
    if size:
        parts.append('%.2f GB' % size)
    parts.append('%s seeds' % number(torrent.get('seeders')))
    parts.extend(str(torrent[k]) for k in ('codec', 'audioCodec', 'hdrType', 'source') if torrent.get(k))
    return ' | '.join(parts) + ' - ' + str(torrent.get('rawTitle') or 'Torrent')


def run(action, params, handle, build_url, play_link, icon, fanart):
    if action in ('torrentclaw_connect', 'torrentclaw_disconnect'):
        changed = connect() if action == 'torrentclaw_connect' else disconnect()
        if changed:
            xbmc.executebuiltin('Container.Refresh')
        return

    def folder(label, target, **kwargs):
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
        xbmcplugin.addDirectoryItem(handle, build_url(action=target, **kwargs), li, True)

    def finish(success=True):
        xbmcplugin.endOfDirectory(handle, succeeded=success)

    try:
        if action == 'torrentclaw_play':
            # Keep the chosen torrent; do not invoke the generic source search.
            play_link(params.get('payload', '{}'), bypass_source=True)
            return
        if action == 'torrentclaw_settings':
            xbmcaddon.Addon().openSettings()
            finish(False)
            return
        if action == 'torrentclaw_root':
            folder('Recently Added', 'torrentclaw_list', endpoint='recent')
            folder('Popular Movies & TV Shows', 'torrentclaw_list', endpoint='popular')
            folder('Search Movies', 'torrentclaw_search', kind='movie')
            folder('Search TV Shows', 'torrentclaw_search', kind='show')
            xbmcplugin.setContent(handle, 'files')
            finish()
            return
        if action in ('torrentclaw_search', 'torrentclaw_list'):
            endpoint = params.get('endpoint', 'search')
            if endpoint not in ('recent', 'popular', 'search'):
                raise ApiError('Unknown TorrentClaw list.')
            query = params.get('query', '')
            kind = params.get('kind', '')
            page = max(1, number(params.get('page'), 1))
            if action == 'torrentclaw_search':
                query = xbmcgui.Dialog().input('Search TorrentClaw').strip()
                if not query:
                    finish(False)
                    return
            options = {'page': page, 'limit': PAGE_SIZE}
            if endpoint == 'search':
                options.update(q=query, type=kind)
            data = request(endpoint, **options)
            items = page_items(data, endpoint)
            # Fetch concurrently, but create Kodi UI items on the main thread.
            with ThreadPoolExecutor(max_workers=4) as pool:
                enriched = list(pool.map(metadata, items))
            for item, meta in zip(items, enriched):
                if not item.get('id') or not item.get('title'):
                    continue
                summary = {k: v for k, v in item.items() if k not in ('torrents', 'streaming')}
                summary['tmdbId'] = meta.get('tmdb_id') or item.get('tmdbId')
                summary['imdbId'] = meta.get('imdb_id') or item.get('imdbId')
                label = '%s (%s) [%s]' % (meta['title'], meta.get('year') or '?',
                                         'TV' if item.get('contentType') == 'show' else 'Movie')
                li = xbmcgui.ListItem(label=label)
                li.setArt({'thumb': item.get('posterUrl') or icon,
                           'poster': item.get('posterUrl') or icon, 'fanart': item.get('backdropUrl') or fanart})
                apply_metadata(li, meta)
                xbmcplugin.addDirectoryItem(handle, build_url(
                    action='torrentclaw_seasons' if item.get('contentType') == 'show' else 'torrentclaw_sources',
                    item=json.dumps(summary)), li, True)
            if has_next(data, page):
                folder('Next Page', 'torrentclaw_list', endpoint=endpoint, query=query, kind=kind, page=page + 1)
            if not items:
                xbmcgui.Dialog().notification('TorrentClaw', 'No titles found.', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setContent(handle, 'movies' if kind == 'movie' else 'tvshows' if kind == 'show' else 'videos')
            finish()
            return
        if action in ('torrentclaw_seasons', 'torrentclaw_episodes', 'torrentclaw_sources'):
            item = json.loads(params.get('item', '{}'))
            # Old saved show links also open the season browser.
            if action == 'torrentclaw_sources' and item.get('contentType') == 'show' and 'season' not in params:
                action = 'torrentclaw_seasons'
        if action in ('torrentclaw_seasons', 'torrentclaw_episodes'):
            meta = metadata(item)
            tmdb_id = meta.get('tmdb_id')
            if not tmdb_id:
                raise ApiError('No TMDB match found for this show. Seasons are unavailable.')
            item['tmdbId'] = tmdb_id
            item['imdbId'] = meta.get('imdb_id') or item.get('imdbId')
            try:
                if action == 'torrentclaw_seasons':
                    entries = tmdb_client().get_tv_seasons(tmdb_id) or []
                else:
                    season = number(params.get('season'), -1)
                    if season < 0:
                        raise ApiError('Invalid season selection.')
                    entries = tmdb_client().get_tv_episodes(tmdb_id, season) or []
            except ApiError:
                raise
            except Exception as exc:
                raise ApiError('Unable to load TMDB seasons or episodes. Please try again.') from exc
            for entry in entries:
                index = number(entry.get('number'), -1)
                if index < 0:
                    continue
                season_view = action == 'torrentclaw_seasons'
                label = (entry.get('name') or ('Specials' if index == 0 else 'Season %d' % index)) if season_view else (
                    'S%02dE%02d  %s' % (season, index, entry.get('name') or 'Episode %d' % index))
                li = xbmcgui.ListItem(label=label)
                poster = (entry.get('poster') if season_view else params.get('poster')) or meta.get('poster') or icon
                li.setArt({'icon': icon, 'thumb': entry.get('still') or poster,
                           'poster': poster, 'fanart': meta.get('fanart') or fanart})
                entry_meta = dict(meta, title=entry.get('name') or label,
                                  plot=entry.get('overview') or meta.get('plot') or '',
                                  premiered=entry.get('air_date') or '',
                                  poster=poster)
                if not season_view:
                    entry_meta.update(content='episode', season=season, episode=index,
                                      tvshowtitle=meta['title'], thumb=entry.get('still') or poster,
                                      rating=entry.get('rating') or 0.0, runtime=entry.get('runtime') or 0)
                apply_metadata(li, entry_meta)
                if season_view:
                    tag = li.getVideoInfoTag()
                    tag.setMediaType('season')
                    tag.setSeason(index)
                    tag.setTvShowTitle(meta['title'])
                    li.setProperty('TotalEpisodes', str(entry.get('episode_count') or 0))
                    target = build_url(action='torrentclaw_episodes', item=json.dumps(item), season=index, poster=poster)
                else:
                    target = build_url(action='torrentclaw_sources', item=json.dumps(item), season=season, episode=index)
                xbmcplugin.addDirectoryItem(handle, target, li, True)
            if not entries:
                xbmcgui.Dialog().notification('TorrentClaw', 'No seasons or episodes available from TMDB.', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setContent(handle, 'seasons' if action == 'torrentclaw_seasons' else 'episodes')
            finish()
            return
        if action != 'torrentclaw_sources':
            raise ApiError('Unknown TorrentClaw action.')
        if not xbmcaddon.Addon().getSetting('torrentclaw_api_key').strip():
            if not connect():
                finish(False)
                return
        item = json.loads(params.get('item', '{}'))
        options = {'q': item['title'], 'type': item.get('contentType'), 'limit': 50}
        if item.get('year'):
            options.update(year_min=item['year'], year_max=item['year'])
        season = episode = None
        if item.get('contentType') == 'show':
            for name in ('season', 'episode'):
                value = number(params.get(name), -1)
                if value < 0:
                    raise ApiError('Choose an episode from the season menu.')
                options[name] = value
            season, episode = options['season'], options['episode']
        # Recent/popular return metadata only. Search by title and year, then
        # enforce the content ID so similarly named releases never get mixed.
        match = None
        for page in range(1, 6):
            data = request('search', page=page, **options)
            match = next((r for r in page_items(data, 'search') if str(r.get('id')) == str(item['id'])), None)
            if match or not has_next(data, page):
                break
        if not match:
            raise ApiError('No matching torrents found for this title or episode.')
        torrents = match.get('torrents') or []
        for field in ('tmdbId', 'imdbId'):
            if not match.get(field) and item.get(field):
                match[field] = item[field]
        meta = metadata(match, season, episode)
        picker_links = []
        seen = set()
        for torrent in sorted((t for t in torrents if isinstance(t, dict)),
                              key=lambda t: number(t.get('seeders')), reverse=True):
            # Permit season packs (episode=null), but reject a different episode.
            if season is not None:
                if torrent.get('season') is not None and number(torrent['season'], -1) != season:
                    continue
                if torrent.get('episode') is not None and number(torrent['episode'], -1) != episode:
                    continue
            payload = playback_payload(match, torrent, season, episode, meta)
            if not payload['url'] or payload['url'] in seen:
                continue
            seen.add(payload['url'])
            picker_links.append({
                'label': torrent.get('rawTitle') or match.get('title') or 'Torrent',
                'meta': source_label(torrent).split(' - ', 1)[0],
                'icon': meta.get('poster') or icon,
                'payload': payload,
            })
        if not picker_links:
            raise ApiError('No playable magnets returned. Check your API key or try another episode.')
        if not debrid.get_debrid_services():
            raise ApiError('Configure a Debrid service in Cosmos before playing TorrentClaw sources.')
        title = meta.get('tvshowtitle') or meta.get('title') or match.get('title', '')
        if season is not None:
            title += ' S%02dE%02d' % (season, episode)
        chosen = show_source_picker(picker_links, title, icon)
        # This action was opened as a folder. Keep the title list behind the
        # modal and use Player.play for its selected torrent.
        finish(False)
        if chosen:
            play_link(json.dumps(chosen['payload']), bypass_source=True, use_player=True)
    except (ApiError, ValueError, KeyError, TypeError) as exc:
        message = str(exc) if isinstance(exc, ApiError) else 'Could not read this TorrentClaw result.'
        xbmc.log('COSMOS TorrentClaw: ' + message, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('TorrentClaw', message, xbmcgui.NOTIFICATION_WARNING, 5000)
        if action == 'torrentclaw_play':
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        else:
            finish(False)
