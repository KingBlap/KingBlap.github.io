# -*- coding: utf-8 -*-
"""
TMDB metadata client for C.O.S.M.O.S.

This addon and code was created by Zeus768 for Cosmos.
Author: Zeus768

Uses TMDB v3 API to fetch movie and TV metadata (poster, fanart, plot,
rating, runtime, cast etc.) from a tmdb id supplied in the playlist XML.
"""
import json
import re
import time
import os
import xbmc
import xbmcaddon
import xbmcvfs
from . import fanarttv
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

IMG_BASE = 'https://image.tmdb.org/t/p/'
POSTER_SIZE = 'w500'
FANART_SIZE = 'original'
DEFAULT_API_KEY = 'ce92f63cbc22f39ce4ffad5779dfddc2'
DEFAULT_FANARTTV_API_KEY = '973f01d9fb20a2da1de673ba0db90cdd'
_TMDB_ART_HEALTH = {'checked': 0.0, 'ok': True}
_TVDB_ID_CACHE = {}
_SESSION_META_CACHE = {}


def _cache_paths():
    root = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.cosmos/metadata_cache')
    return root, os.path.join(root, 'metadata.json'), os.path.join(root, 'art')


def _cache_enabled():
    # Offline metadata/artwork caching is intentionally disabled.  Artwork is
    # returned from the remote service directly and is never written to the
    # add-on profile.
    return False


def _read_cache():
    if not _cache_enabled():
        return {}
    _, path, _ = _cache_paths()
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            value = json.load(handle)
            return value if isinstance(value, dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _write_cache(cache):
    try:
        root, path, _ = _cache_paths()
        os.makedirs(root, exist_ok=True)
        temp = path + '.tmp'
        with open(temp, 'w', encoding='utf-8') as handle:
            json.dump(cache, handle, ensure_ascii=False)
        os.replace(temp, path)
    except OSError as exc:
        xbmc.log('COSMOS metadata cache write failed: %s' % exc, xbmc.LOGWARNING)


def _cached_meta(tmdb_id, content):
    row = _read_cache().get('%s:%s' % (content, tmdb_id))
    if not isinstance(row, dict):
        return {}
    age = time.time() - float(row.get('_cached_at') or 0)
    days = int(xbmcaddon.Addon().getSetting('offline_metadata_cache_days') or 30)
    if age > days * 86400:
        return {}
    meta = row.get('meta')
    return meta if isinstance(meta, dict) else {}


def _store_meta(meta):
    if not _cache_enabled() or not meta.get('tmdb_id'):
        return
    cache = _read_cache()
    root, _, art_root = _cache_paths()
    os.makedirs(art_root, exist_ok=True)
    # Keep local copies of artwork; Kodi can render these while the CDN is offline.
    for field in ('poster', 'fanart'):
        url = meta.get(field, '')
        if not str(url).startswith(('http://', 'https://')):
            continue
        filename = '%s_%s.jpg' % (meta['tmdb_id'], field)
        local = os.path.join(art_root, filename)
        try:
            if not os.path.exists(local):
                req = Request(url, headers={'User-Agent': 'COSMOS/4.0.0'})
                with urlopen(req, timeout=10) as response:
                    with open(local, 'wb') as handle:
                        handle.write(response.read())
            if os.path.exists(local) and os.path.getsize(local):
                meta[field] = local
        except (HTTPError, URLError, OSError, ValueError):
            pass
    key = '%s:%s' % (meta.get('content', 'movie'), meta['tmdb_id'])
    cache[key] = {'_cached_at': time.time(), 'meta': meta}
    # Prune expired entries and keep the JSON cache within the configured limit.
    retention = int(xbmcaddon.Addon().getSetting('offline_metadata_cache_days') or 30) * 86400
    now = time.time()
    cache = {k: v for k, v in cache.items()
             if isinstance(v, dict) and now - float(v.get('_cached_at') or 0) <= retention}
    limit = int(xbmcaddon.Addon().getSetting('offline_metadata_cache_limit') or 100) * 1024 * 1024
    while len(cache) > 1 and len(json.dumps(cache, ensure_ascii=False).encode('utf-8')) > limit:
        oldest = min(cache, key=lambda k: float(cache[k].get('_cached_at') or 0))
        del cache[oldest]
    _write_cache(cache)


def _safe_log_url(url):
    """Redact API credentials before a URL is written to Kodi's log."""
    return re.sub(
        r'(?i)([?&](?:api_key|apikey|token)=)[^&\s]+',
        r'\1[REDACTED]',
        str(url or ''),
    )


def _api_key():
    addon = xbmcaddon.Addon()
    return (addon.getSetting('tmdb_api_key') or DEFAULT_API_KEY).strip()


def _fanart_key():
    return (xbmcaddon.Addon().getSetting('fanarttv_api_key') or
            DEFAULT_FANARTTV_API_KEY).strip()


def _fanart_fallback(tmdb_id, content, tvdb_id=''):
    key = _fanart_key()
    if not key:
        return {}
    # Fanart.tv identifies movies by TMDB ID, but TV shows by TheTVDB ID.
    media_id = tmdb_id if content == 'movie' else tvdb_id
    if not media_id:
        return {}
    return fanarttv.artwork(media_id, content, key)


def _tmdb_art_service_ok(sample_url):
    """Probe TMDB's image CDN at most once every five minutes."""
    if not sample_url or not _fanart_key():
        return bool(sample_url)
    now = time.time()
    if now - _TMDB_ART_HEALTH['checked'] < 300:
        return _TMDB_ART_HEALTH['ok']
    ok = False
    try:
        request = Request(sample_url, headers={'User-Agent': 'COSMOS/4.1.88'}, method='HEAD')
        with urlopen(request, timeout=5) as response:
            ok = 200 <= int(response.status) < 400
    except (HTTPError, URLError, OSError, ValueError):
        ok = False
    _TMDB_ART_HEALTH.update({'checked': now, 'ok': ok})
    return ok


def _fetch(url, timeout=15):
    try:
        req = Request(url, headers={'User-Agent': 'COSMOS/4.0.0'})
        resp = urlopen(req, timeout=timeout)
        body = resp.read().decode('utf-8', errors='replace')
        return json.loads(body)
    except (HTTPError, URLError, ValueError) as e:
        xbmc.log(f'TMDB fetch error for {_safe_log_url(url)}: {e}', xbmc.LOGWARNING)
        return None


def _img(path, size=POSTER_SIZE):
    if not path:
        return ''
    return f'{IMG_BASE}{size}{path}'


def get_metadata(tmdb_id, content='movie'):
    """Fetch a condensed metadata dict for a given tmdb id.

    Returns a dict with keys: title, plot, year, rating, votes, runtime,
    genre, mpaa, poster, fanart, imdb_id, tagline, premiered.
    """
    key = _api_key()
    if not key or not tmdb_id:
        return {}
    session_key = '%s:%s' % (content, tmdb_id)
    if session_key in _SESSION_META_CACHE:
        return dict(_SESSION_META_CACHE[session_key])

    kind = 'movie' if content == 'movie' else 'tv'
    url = (
        f'https://api.themoviedb.org/3/{kind}/{tmdb_id}'
        f'?api_key={key}&append_to_response=external_ids,credits'
    )
    data = _fetch(url)
    if not data:
        cached = _cached_meta(tmdb_id, content)
        if cached:
            xbmc.log('COSMOS TMDB: using offline metadata cache for %s/%s' % (content, tmdb_id), xbmc.LOGINFO)
            _SESSION_META_CACHE[session_key] = cached
            return cached
        cached_tvdb = _TVDB_ID_CACHE.get(str(tmdb_id), '')
        art = _fanart_fallback(tmdb_id, content, cached_tvdb)
        if art:
            art.update({'tmdb_id': str(tmdb_id), 'content': content})
        return art

    title = data.get('title') or data.get('name') or ''
    release = data.get('release_date') or data.get('first_air_date') or ''
    year = release[:4] if release else ''
    runtime = data.get('runtime') or 0
    if not runtime and data.get('episode_run_time'):
        runtime = data['episode_run_time'][0]

    genres = ', '.join(g.get('name', '') for g in (data.get('genres') or []))
    ext = data.get('external_ids') or {}
    credits = data.get('credits') or {}
    cast = (credits.get('cast') or [])[:20]  # Keep full cast objects
    directors = [c.get('name') for c in (credits.get('crew') or [])
                 if c.get('job') == 'Director']

    meta = {
        'title': title,
        'originaltitle': data.get('original_title') or data.get('original_name') or title,
        'plot': data.get('overview') or '',
        'tagline': data.get('tagline') or '',
        'year': int(year) if year.isdigit() else 0,
        'premiered': release,
        'rating': float(data.get('vote_average') or 0),
        'votes': int(data.get('vote_count') or 0),
        'runtime': int(runtime or 0) * 60,
        'genre': genres,
        'mpaa': '',
        'poster': _img(data.get('poster_path'), POSTER_SIZE),
        'fanart': _img(data.get('backdrop_path'), FANART_SIZE),
        'imdb_id': ext.get('imdb_id') or '',
        'tvdb_id': str(ext.get('tvdb_id') or ''),
        'cast': cast,
        'director': ', '.join(directors),
        'tmdb_id': str(tmdb_id),
        'content': content,
    }
    if meta.get('tvdb_id'):
        _TVDB_ID_CACHE[str(tmdb_id)] = meta['tvdb_id']
    art_sample = meta.get('poster') or meta.get('fanart')
    art_ok = _tmdb_art_service_ok(art_sample)
    fallback = {}
    if not meta.get('poster') or not meta.get('fanart') or not art_ok:
        fallback = _fanart_fallback(tmdb_id, content, meta.get('tvdb_id'))
    if not meta.get('poster') or not art_ok:
        meta['poster'] = fallback.get('poster', '')
    if not meta.get('fanart') or not art_ok:
        meta['fanart'] = fallback.get('fanart', '')
    _store_meta(meta)
    _SESSION_META_CACHE[session_key] = dict(meta)
    return meta


def find_by_imdb_id(imdb_id, content='movie'):
    """Find a TMDB ID from an IMDB ID."""
    key = _api_key()
    if not key or not imdb_id:
        return None

    # Map content type to TMDB's result key
    kind_map = {'movie': 'movie_results', 'show': 'tv_results', 'tvshow': 'tv_results'}
    result_key = kind_map.get(content, 'movie_results')

    url = (
        f'https://api.themoviedb.org/3/find/{imdb_id}'
        f'?api_key={key}&external_source=imdb_id'
    )
    data = _fetch(url)
    if data and data.get(result_key):
        results = data[result_key]
        if results:
            return str(results[0].get('id', ''))
    return None


def get_tv_seasons(tmdb_id):
    """Return a list of season dicts (number, name, episode_count, overview,
    poster, air_date) for a TV show tmdb_id. Season 0 (specials) is kept.
    """
    key = _api_key()
    if not key or not tmdb_id:
        return []
    url = f'https://api.themoviedb.org/3/tv/{tmdb_id}?api_key={key}'
    data = _fetch(url) or {}
    out = []
    for s in data.get('seasons') or []:
        out.append({
            'number': s.get('season_number', 0),
            'name': s.get('name') or f"Season {s.get('season_number', 0)}",
            'episode_count': s.get('episode_count', 0),
            'overview': s.get('overview') or '',
            'poster': _img(s.get('poster_path'), POSTER_SIZE),
            'air_date': s.get('air_date') or '',
        })
    return out


def get_tv_episodes(tmdb_id, season_number):
    """Return episode dicts (number, name, overview, still, air_date,
    runtime, rating) for a given (tmdb_id, season_number)."""
    key = _api_key()
    if not key or not tmdb_id:
        return []
    url = (f'https://api.themoviedb.org/3/tv/{tmdb_id}/season/'
           f'{int(season_number)}?api_key={key}')
    data = _fetch(url) or {}
    out = []
    season_poster = _img(data.get('poster_path'), POSTER_SIZE)
    for e in data.get('episodes') or []:
        out.append({
            'poster': season_poster,
            'number': e.get('episode_number', 0),
            'name': e.get('name') or f"Episode {e.get('episode_number', 0)}",
            'overview': e.get('overview') or '',
            'still': _img(e.get('still_path'), FANART_SIZE),
            'air_date': e.get('air_date') or '',
            'runtime': int(e.get('runtime') or 0) * 60,
            'rating': float(e.get('vote_average') or 0),
        })
    return out

def get_episode_meta(tmdb_id, season_number, episode_number):
    """Fetch metadata for a single TV episode."""
    key = _api_key()
    if not key or not tmdb_id:
        return None
    try:
        s_num = int(season_number)
        e_num = int(episode_number)
    except (ValueError, TypeError):
        xbmc.log(f'COSMOS TMDB: get_episode_meta invalid season/episode numbers: {season_number}, {episode_number}', xbmc.LOGWARNING)
        return None

    url = (
        f'https://api.themoviedb.org/3/tv/{tmdb_id}/season/{s_num}/episode/{e_num}'
        f'?api_key={key}&language=en-US'
    )
    data = _fetch(url)
    if not data:
        xbmc.log(f'COSMOS TMDB: get_episode_meta failed to fetch data for {_safe_log_url(url)}', xbmc.LOGWARNING)
        return None
    elif data.get('success') is False:
        xbmc.log(f'COSMOS TMDB: get_episode_meta API returned success=False for {_safe_log_url(url)}: {data.get("status_message")}', xbmc.LOGWARNING)
        return None

    return {
        'number': data.get('episode_number', 0),
        'name': data.get('name') or f"Episode {data.get('episode_number', 0)}",
        'overview': data.get('overview') or '',
        'still': _img(data.get('still_path'), FANART_SIZE),
        'air_date': data.get('air_date') or '',
        'runtime': int(data.get('runtime') or 0) * 60,
        'rating': float(data.get('vote_average') or 0),
    }


def search_by_title(title, content='movie'):
    """Search TMDB by title and return the first matching tmdb_id string.

    Used for DDLValley items that have no embedded tmdb_id.
    Quality/release-format tags are stripped before searching.
    """
    import re
    from urllib.parse import quote_plus

    key = _api_key()
    if not key or not title:
        return ''

    kind = 'movie' if content == 'movie' else 'tv'

    # Strip trailing quality/format noise so the search hits
    clean = re.sub(
        r'\b(?:2160p|4k|uhd|1080p|720p|480p|blu[- ]?ray|bdrip|brrip|'
        r'web[-.]?dl|webrip|hdtv|hdcam|dvdrip|dvdscr|dvdr|ts|cam|tc|'
        r'complete)\b.*$',
        '', title, flags=re.I,
    ).strip(' .-')

    url = (
        f'https://api.themoviedb.org/3/search/{kind}'
        f'?api_key={key}&query={quote_plus(clean)}&page=1'
    )
    data = _fetch(url)
    if not data:
        return ''
    results = data.get('results') or []
    if results:
        return str(results[0].get('id') or '')
    return ''


def search_art_by_title(title, content='movie', year=None):
    """Find lightweight TMDB artwork and ID for a title in one request.

    Used by scraper listings that need posters/fanart for many items.  Full
    metadata is fetched later by the Info/Extras flows when it is needed.
    """
    from urllib.parse import quote_plus

    key = _api_key()
    if not key or not title:
        return {}

    kind = 'movie' if content == 'movie' else 'tv'
    clean = re.sub(
        r'\b(?:2160p|4k|uhd|1080p|720p|480p|blu[- ]?ray|bdrip|brrip|'
        r'web[-.]?dl|webrip|hdtv|hdcam|dvdrip|dvdscr|dvdr|ts|cam|tc|'
        r'complete)\b.*$',
        '', title, flags=re.I,
    ).strip(' .-')
    url = (
        f'https://api.themoviedb.org/3/search/{kind}'
        f'?api_key={key}&query={quote_plus(clean)}&page=1'
    )
    if year:
        try:
            year_value = int(year)
            url += (
                f'&{"primary_release_year" if kind == "movie" else "first_air_date_year"}'
                f'={year_value}'
            )
        except (TypeError, ValueError):
            pass
    data = _fetch(url) or {}
    result = (data.get('results') or [None])[0]
    if not result or not result.get('id'):
        return {}

    release = result.get('release_date') or result.get('first_air_date') or ''
    return {
        'tmdb_id': str(result['id']),
        'title': result.get('title') or result.get('name') or title,
        'originaltitle': result.get('original_title') or result.get('original_name') or '',
        'year': int(release[:4]) if release[:4].isdigit() else 0,
        'poster': _img(result.get('poster_path'), POSTER_SIZE),
        'fanart': _img(result.get('backdrop_path'), FANART_SIZE),
        'content': content,
    }


def get_popular_people(page=1):
    """Fetch popular people from TMDB.

    Returns a list of person dicts with keys: id, name, known_for, profile_path.
    """
    key = _api_key()
    if not key:
        return []

    url = f'https://api.themoviedb.org/3/person/popular?api_key={key}&page={page}'
    data = _fetch(url)
    if not data:
        return []

    people = []
    for person in data.get('results') or []:
        if not person.get('id'):
            continue
        people.append({
            'id': str(person['id']),
            'name': person.get('name') or 'Unknown',
            'known_for': person.get('known_for') or [],
            'profile_path': person.get('profile_path'),
        })
    return people


def get_person_credits(person_id):
    """Fetch combined movie and TV credits for a person.

    Returns a dict with 'cast' and 'crew' lists containing both movies and TV shows.
    """
    key = _api_key()
    if not key or not person_id:
        return {'cast': [], 'crew': []}

    url = f'https://api.themoviedb.org/3/person/{person_id}/combined_credits?api_key={key}'
    data = _fetch(url)
    if not data:
        return {'cast': [], 'crew': []}

    return {
        'cast': data.get('cast') or [],
        'crew': data.get('crew') or [],
    }


def apply_to_listitem(li, meta, content='movie'):
    """Apply metadata dict produced by get_metadata() to an xbmcgui.ListItem.

    Uses InfoTagVideo (Matrix+) so it works on Kodi 19/20/21.
    """
    if not meta:
        return
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(meta.get('title', ''))
        tag.setOriginalTitle(meta.get('originaltitle', '') or meta.get('title', ''))
        tag.setPlot(meta.get('plot', ''))
        tag.setTagLine(meta.get('tagline', ''))
        if meta.get('year'):
            tag.setYear(meta['year'])
        tag.setRating(meta.get('rating', 0.0))
        tag.setVotes(meta.get('votes', 0))
        if meta.get('premiered'):
            tag.setPremiered(meta['premiered'])
        if meta.get('runtime'):
            tag.setDuration(meta['runtime'])
        tag.setGenres([g.strip() for g in (meta.get('genre') or '').split(',') if g.strip()])
        tag.setMediaType('movie' if content == 'movie' else 'tvshow')
        if meta.get('imdb_id'):
            tag.setIMDBNumber(meta['imdb_id'])
        if meta.get('director'):
            tag.setDirectors([d.strip() for d in meta['director'].split(',') if d.strip()])
        if meta.get('cast') and hasattr(xbmc, 'Actor'):
            actors = []
            for person in meta['cast']:
                if isinstance(person, dict):
                    actors.append(xbmc.Actor(
                        name=person.get('name', ''),
                        role=person.get('character', ''),
                        thumbnail=_img(person.get('profile_path'), 'w185')
                    ))
                elif isinstance(person, str):
                    actors.append(xbmc.Actor(name=person))
            tag.setCast(actors)
    except Exception:
        # Fallback to legacy setInfo for older Kodi
        info = {
            'title': meta.get('title', ''),
            'plot': meta.get('plot', ''),
            'year': meta.get('year', 0),
            'rating': meta.get('rating', 0.0),
            'votes': str(meta.get('votes', 0)),
            'genre': meta.get('genre', ''),
            'duration': meta.get('runtime', 0),
            'mediatype': 'movie' if content == 'movie' else 'tvshow',
            'imdbnumber': meta.get('imdb_id', ''),
            'premiered': meta.get('premiered', ''),
        }
        li.setInfo('video', info)

    art = {}
    if meta.get('poster'):
        art['poster'] = meta['poster']
        art['thumb'] = meta['poster']
    if meta.get('fanart'):
        art['fanart'] = meta['fanart']
    if art:
        li.setArt(art)
