# -*- coding: utf-8 -*-
"""
C.O.S.M.O.S - Cinema On-demand Streaming Multimedia Operating System

This addon and code was created by Zeus768 & Enigma for Cosmos.
Author: Zeus768 & Enigma

Main plugin router.

Handles menu navigation driven by a remote playlist feed, item playback
with TMDB metadata, and forwards Debrid auth actions to the shared
``debrid`` module (compatible with zeus768 Trakt Player flow).
"""
import sys
import re
import time
from builtins import ValueError, TypeError, OverflowError
from urllib.parse import urlencode, parse_qsl, unquote, urlsplit

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from . import parser
from . import tmdb as tmdb_mod
from . import openai_search as openai_search_mod
from . import filehost
from . import debrid
from . import search as search_mod
from . import downloader
from . import favourites as fav_mod
from . import resume as resume_mod
from . import search_history as sh_mod
from . import newly_added as na_mod
from . import sync as sync_mod
from . import tools as tools_mod
from . import trakt_ui as trakt_ui_mod
from . import trakt as trakt_mod
from . import simkl as simkl_mod
from . import punchplay as punchplay_mod
from . import cloud_ui as cloud_mod
from . import watched as watched_mod
from . import refooty as refooty_mod
from . import wwe_archive as wwe_archive_mod
from . import watchwrestling as watchwrestling_mod
from . import source_finder_dialog as sf_mod
from . import ddlvalley as ddlv_mod
from . import rlsbb as rlsbb_mod
from . import nineanime_section as nineanime_mod
from . import info_dialog as info_mod
from . import extras_dialog as extras_mod
from . import debug_bundle as debug_bundle_mod
from . import opensubtitles as opensubtitles_mod
from . import debrid_status_ui as debrid_status_ui_mod
from . import ookla_speedtest as ookla_speedtest_mod
from . import manyxxx as manyxxx_mod
from . import hqpornxxx as hqpornxxx_mod
from . import eporner as eporner_mod
from .i18n import L as _L


ADDON = xbmcaddon.Addon()
ADDON_ID = 'plugin.video.cosmos'
CARTOONIO_ID = 'plugin.video.cartoonio'
CARTOONIO_REPO_ID = 'repository.enigmawiz'
RADIOUK_ID = 'plugin.audio.radiouk'
RADIOUK_REPO_ID = 'repository.enigmawiz'
WIKI_TRAILERS_ID = 'plugin.video.wikitrailer'
WIKI_TRAILERS_REPO_ID = 'repository.enigmawiz'
WIKI_TRAILERS_ICON = 'https://team-enigma.xyz/repo/zips/plugin.video.wikitrailer/icon.png'
EFFEDUPMOVIES_ID = 'plugin.video.effedupmovies'
EFFEDUPMOVIES_ICON = 'https://team-enigma.xyz/repo/zips/plugin.video.effedupmovies/icon.png'
INPUTSTREAM_ADAPTIVE_ID = 'inputstream.adaptive'
# Kodi may retain a blank value saved by an older installation even after the
# settings.xml default changes.  Keep TMDB-backed browser paths working in
# that case by using the same built-in default as the metadata client.
if not (ADDON.getSetting('tmdb_api_key') or '').strip():
    ADDON.setSetting('tmdb_api_key', tmdb_mod.DEFAULT_API_KEY)
if not (ADDON.getSetting('fanarttv_api_key') or '').strip():
    ADDON.setSetting('fanarttv_api_key', tmdb_mod.DEFAULT_FANARTTV_API_KEY)
if not (ADDON.getSetting('opensubtitles_api_key') or '').strip():
    ADDON.setSetting('opensubtitles_api_key', opensubtitles_mod.DEFAULT_API_KEY)
ADDON_PATH = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/')
ICON = f'{ADDON_PATH}icon.png'
FANART = f'{ADDON_PATH}fanart.jpg'
RUGBY_FANART  = f'{ADDON_PATH}resources/media/fanart_rugby.jpg'
RACING_FANART    = f'{ADDON_PATH}resources/media/fanart_racing.png'
WRESTLING_FANART = f'{ADDON_PATH}resources/media/fanart_wrestling.jpg'
TUBI_ICON = f'{ADDON_PATH}resources/media/icon_tubi.png'
TUBI_FANART = f'{ADDON_PATH}resources/media/fanart_tubi.jpg'
PLUTO_ICON = f'{ADDON_PATH}resources/media/icon_pluto_black.png'
FREEBIE_TV_ICON = f'{ADDON_PATH}resources/media/icon_freebie_tv.png'
VIDCORE_ICON = f'{ADDON_PATH}resources/media/icon_vidcore.png'
PLEX_ICON = f'{ADDON_PATH}resources/media/icon_plex_tv.png'
SAMSUNG_TVPLUS_ICON = f'{ADDON_PATH}resources/media/icon_samsung_tvplus.png'
BBC_ICON = FREEBIE_TV_ICON
RAKUTEN_ICON = f'{ADDON_PATH}resources/media/icon_rakuten_tv.png'
MANYXXX_ICON = 'https://many.xxx/img/favicon/apple-touch-icon.png'
HQPORNXXX_ICON = 'https://hqporn.xxx/static/images/favicon/android-icon-192x192-c92674301e.png'
EPORNER_ICON = eporner_mod.ICON
DDLVALLEY_ICON  = f'{ADDON_PATH}resources/media/icon_ddlvalley.png'
RLSBB_ICON      = f'{ADDON_PATH}resources/media/icon_rlsbb.png'
DDLV_ICON = DDLVALLEY_ICON
RLSBB_FANART = f'{ADDON_PATH}resources/media/fanart_rlsbb.png'
NINEANIME_ICON = f'{ADDON_PATH}resources/media/icon_9anime.png'
NINEANIME_FANART = f'{ADDON_PATH}resources/media/fanart_9anime.png'
RAPIDGATOR_ICON = f'{ADDON_PATH}resources/media/icon_rapidgator.png'
NITROFLARE_ICON = f'{ADDON_PATH}resources/media/icon_nitroflare.png'
MULTIUP_ICON    = f'{ADDON_PATH}resources/media/icon_multiup.png'
UPLOADGIG_ICON  = f'{ADDON_PATH}resources/media/icon_uploadgig.png'
UPLOADY_ICON    = f'{ADDON_PATH}resources/media/icon_uploady.png'



def _menu_icon(name):
    """Return the icon path for a named main-menu slot.

    To use your own icon, drop a PNG named  icon_<name>.png  into the
    addon's  resources/media/  folder.  The bundled placeholder is kept
    as the default fallback.

    Slot names and their default filenames
    ──────────────────────────────────────
      icon_newly_added.png   – Newly Added
      icon_ddlvalley.png     – DDLValley
      icon_trakt.png         – Trakt
      icon_trending.png      – Trending This Week
      icon_trailers.png      – Trailers
      icon_search.png        – Universal Search
      icon_continue.png      – Continue Watching
      icon_favourites.png    – Favourites
      icon_boxing.png        – Boxing Replays
      icon_combat.png        – Combat Replays
      icon_football.png      – Football Replays
      icon_downloads.png     – Downloads
      icon_cloud.png         – Cloud
      icon_tools.png         – Tools
      icon_anime.png          – Anime
      icon_release_hub.png   – Release Hub
      icon_my_tracking.png   – My Tracking
      icon_settings.png      – Settings / Debrid
      icon_clearcache.png    – Clear Cache
      icon_movies.png        – Movies (TMDB browser)
      icon_tvshows.png       – TV Shows (TMDB browser)
      icon_simkl.png         – Simkl
    """
    path = f'{ADDON_PATH}resources/media/icon_{name}.png'
    if xbmcvfs.exists(path):
        xbmc.log(f'COSMOS: Using custom menu icon for "{name}": {path}', xbmc.LOGINFO)
        return path
    else:
        xbmc.log(f'COSMOS: Custom menu icon not found for "{name}", using default. Path checked: {path}', xbmc.LOGWARNING)
        return ICON


def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def _base_url_cli():
    """sys.argv[0] is the plugin:// base url used for child URL building."""
    return sys.argv[0]


def build_url(**kwargs):
    return f'{_base_url_cli()}?{urlencode(kwargs)}'


def _effective_base_url(default_url):
    """Return user-configured base url if set, otherwise default_url."""
    cfg = (ADDON.getSetting('base_url') or '').strip()
    return cfg or default_url


def _menu_name_key(value):
    """Normalize a menu label for tolerant root-feed matching."""
    cleaned = parser.strip_bbcode(str(value or '')).casefold()
    return re.sub(r'[^a-z0-9]+', '', cleaned)


def _root_feed_item(items, *names):
    """Find a named Enigma root feed entry using tolerant label matching."""
    wanted = {_menu_name_key(name) for name in names}
    for item in items or []:
        if _menu_name_key(item.get('name')) in wanted:
            return item
    return None


def _root_feed_url(item):
    """Build the normal Cosmos menu URL for a remote root feed item."""
    child_feed = (item or {}).get('url', '').strip()
    if not child_feed:
        return ''
    return build_url(action='menu', feed=child_feed.replace('.xml', '.xmll'))


_XXX_PIN = '6969'
_ADULT_UNLOCK_PROPERTY = 'plugin.video.cosmos.adult.unlocked'
_ADULT_UNLOCKED_AT_PROPERTY = 'plugin.video.cosmos.adult.unlocked_at'
_ADULT_UNLOCKED = False


def _adult_access(prompt=True, force=False):
    """Authorize adult routes; direct child URLs cannot bypass the PIN."""
    global _ADULT_UNLOCKED
    window = xbmcgui.Window(10000)
    # Returning from an Adult Lounge child menu should reuse the active
    # session; ``force`` is only meant to defeat the normal fast path when
    # entering from the main Cosmos root after the lock was cleared.
    if force and window.getProperty(_ADULT_UNLOCK_PROPERTY) == 'true':
        _ADULT_UNLOCKED = True
        return True
    if not force and (_ADULT_UNLOCKED or window.getProperty(_ADULT_UNLOCK_PROPERTY) == 'true'):
        _ADULT_UNLOCKED = True
        return True
    entered = ''
    try:
        from .adult_pin_dialog import AdultPinDialog
        dialog = AdultPinDialog('AdultPinDialog.xml', ADDON_PATH, 'Default', '720p')
        dialog.doModal()
        entered = dialog.value
        del dialog
    except Exception as exc:
        xbmc.log('COSMOS: styled PIN dialog unavailable: %s' % exc, xbmc.LOGDEBUG)
        entered = str(xbmcgui.Dialog().input(
            'Enter Adult Lounge PIN', type=xbmcgui.INPUT_ALPHANUM,
        ) or '').strip()
    if entered == _XXX_PIN:
        _ADULT_UNLOCKED = True
        window.setProperty(_ADULT_UNLOCK_PROPERTY, 'true')
        window.setProperty(_ADULT_UNLOCKED_AT_PROPERTY, str(time.time()))
        return True
    if entered:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Incorrect Adult Lounge PIN',
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
    return False


def _lock_adult_lounge():
    """Clear the session unlock when returning to the main Cosmos root."""
    global _ADULT_UNLOCKED
    _ADULT_UNLOCKED = False
    window = xbmcgui.Window(10000)
    window.clearProperty(_ADULT_UNLOCK_PROPERTY)
    window.clearProperty(_ADULT_UNLOCKED_AT_PROPERTY)


def _xxx_root(from_main_root=False):
    """Open the protected Adult Lounge directory after PIN validation."""
    if from_main_root and not _adult_access(prompt=True, force=True):
        xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)
        return
    if not from_main_root and not _adult_route_authorized():
        return
    _add_directory(
        '[COLOR gold]Notice: Some content may require a VPN to access[/COLOR]',
        '', is_folder=False, is_playable=False,
    )
    _add_directory(
        '[B]many.xxx[/B]', build_url(action='manyxxx_root'), thumb=MANYXXX_ICON,
    )
    _add_directory(
        '[B]hqporn.xxx[/B]', build_url(action='hqpornxxx_root'), thumb=HQPORNXXX_ICON,
    )
    _add_directory(
        '[B]Eporner[/B]', build_url(action='eporner_root'), thumb=EPORNER_ICON,
    )
    _add_directory(
        '[B]Effed Up Movies[/B]', build_url(action='effedupmovies_install'),
        thumb=EFFEDUPMOVIES_ICON, is_folder=False,
    )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _adult_route_authorized():
    # Child routes inherit the unlock from the Adult Lounge root.  Never open
    # another PIN dialog while navigating back through a provider submenu.
    global _ADULT_UNLOCKED
    window = xbmcgui.Window(10000)
    if _ADULT_UNLOCKED or window.getProperty(_ADULT_UNLOCK_PROPERTY) == 'true':
        return True
    xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)
    return False


def _manyxxx_root():
    if not _adult_route_authorized():
        return
    for label, url in (
            ('Latest Updates', 'https://many.xxx/latest-updates/'),
            ('Most Popular', 'https://many.xxx/most-popular/'),
            ('Top Rated', 'https://many.xxx/top-rated/')):
        _add_directory('[B]%s[/B]' % label,
                       build_url(action='manyxxx_list', url=url), thumb=MANYXXX_ICON)
    _add_directory('[B]Categories[/B]',
                   build_url(action='manyxxx_categories'), thumb=MANYXXX_ICON)
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), cacheToDisc=False)


def _manyxxx_categories():
    if not _adult_route_authorized():
        return
    try:
        index = 'https://many.xxx/categories/'
        categories = manyxxx_mod.parse_categories(manyxxx_mod.fetch(index), index)
        for category in categories:
            _add_directory('[B]%s[/B]' % category['title'],
                           build_url(action='manyxxx_list', url=category['url']),
                           thumb=MANYXXX_ICON,
                           info={'title': category['title'],
                                 'plot': 'Browse %s videos from many.xxx.' % category['title']})
        xbmcplugin.setContent(_handle(), 'files')
        xbmcplugin.endOfDirectory(_handle(), succeeded=bool(categories), cacheToDisc=False)
    except Exception as exc:
        xbmc.log('COSMOS: many.xxx categories failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('many.xxx', 'Unable to load categories.', xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)


def _manyxxx_list(page_url):
    if not _adult_route_authorized():
        return
    try:
        items, next_url = manyxxx_mod.parse_listing(manyxxx_mod.fetch(page_url), page_url)
    except Exception as exc:
        xbmc.log('COSMOS: many.xxx listing failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('many.xxx', 'Unable to load this page.',
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)
        return
    for item in items:
        label = item['title']
        if item.get('duration'):
            label += '  [COLOR grey](%s)[/COLOR]' % item['duration']
        _add_directory(label,
            build_url(action='manyxxx_play', url=item['url'], title=item['title']),
            thumb=item.get('thumb', ''), is_folder=False, is_playable=True,
            info={'title': item['title']}, live=True)
    if next_url:
        _add_directory('[B]Next Page »[/B]',
                       build_url(action='manyxxx_list', url=next_url), thumb=MANYXXX_ICON)
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), cacheToDisc=False)


def _manyxxx_play(page_url, title=''):
    if not _adult_route_authorized():
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return
    try:
        sources = manyxxx_mod.parse_sources(manyxxx_mod.fetch(page_url), page_url)
        if not sources:
            raise ValueError('No playable MP4 source was found')
        choice = 0
        if len(sources) > 1:
            choice = xbmcgui.Dialog().select('many.xxx - Choose Quality',
                                              [source['label'] for source in sources])
            if choice < 0:
                xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
                return
        stream = manyxxx_mod.kodi_stream_url(sources[choice]['url'], page_url)
        item = xbmcgui.ListItem(label=title or 'many.xxx', path=stream)
        item.setInfo('video', {'title': title or 'many.xxx', 'mediatype': 'video', 'playcount': 0})
        item.setProperty('ResumeTime', '0')
        item.setProperty('TotalTime', '0')
        item.setProperty('IsPlayable', 'true')
        item.setMimeType('video/mp4')
        xbmcplugin.setResolvedUrl(_handle(), True, item)
    except Exception as exc:
        xbmc.log('COSMOS: many.xxx resolve failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('many.xxx', 'Unable to resolve this video.',
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())


def _hqpornxxx_root():
    if not _adult_route_authorized():
        return
    for label, url in (
            ('New Videos', 'https://hqporn.xxx/fresh/'),
            ('Best Videos', 'https://hqporn.xxx/best/'),
            ):
        _add_directory('[B]%s[/B]' % label,
                       build_url(action='hqpornxxx_list', url=url), thumb=HQPORNXXX_ICON)
    _add_directory('[B]Categories[/B]',
                   build_url(action='hqpornxxx_categories'), thumb=HQPORNXXX_ICON)
    _add_directory('[B]Channels[/B]',
                   build_url(action='hqpornxxx_channels'), thumb=HQPORNXXX_ICON)
    _add_directory('[B]Pornstars[/B]',
                   build_url(action='hqpornxxx_pornstars'), thumb=HQPORNXXX_ICON)
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), cacheToDisc=False)


def _hqpornxxx_list(page_url):
    if not _adult_route_authorized():
        return
    try:
        items, next_url = hqpornxxx_mod.parse_listing(hqpornxxx_mod.fetch(page_url), page_url)
    except Exception as exc:
        xbmc.log('COSMOS: hqporn.xxx listing failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('hqporn.xxx', 'Unable to load this page.',
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)
        return
    for item in items:
        label = item['title']
        if item.get('duration'):
            label += '  [COLOR grey](%s)[/COLOR]' % item['duration']
        _add_directory(label,
            build_url(action='hqpornxxx_play', url=item['url'], title=item['title']),
            thumb=item.get('thumb', ''), is_folder=False, is_playable=True,
            info={'title': item['title']}, live=True)
    if next_url:
        _add_directory('[B]Next Page »[/B]',
                       build_url(action='hqpornxxx_list', url=next_url), thumb=HQPORNXXX_ICON)
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), cacheToDisc=False)


def _hqpornxxx_categories():
    if not _adult_route_authorized():
        return
    _add_directory('[B]HD MILF[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/milf/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD MILF', 'plot': 'Browse HD MILF videos from hqporn.xxx.'})
    _add_directory('[B]HD Public[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/public/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD Public', 'plot': 'Browse HD Public videos from hqporn.xxx.'})
    _add_directory('[B]HD Car[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/car/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD Car', 'plot': 'Browse HD Car videos from hqporn.xxx.'})
    _add_directory('[B]HD Wife[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/wife/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD Wife', 'plot': 'Browse HD Wife videos from hqporn.xxx.'})
    _add_directory('[B]HD Granny[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/granny/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD Granny', 'plot': 'Browse HD Granny videos from hqporn.xxx.'})
    _add_directory('[B]HD Maid[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/maid/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD Maid', 'plot': 'Browse HD Maid videos from hqporn.xxx.'})
    _add_directory('[B]HD Cheating[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/cheating/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD Cheating', 'plot': 'Browse HD Cheating videos from hqporn.xxx.'})
    _add_directory('[B]HD FMM Threesome[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/fmm-threesome/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD FMM Threesome', 'plot': 'Browse HD FMM Threesome videos from hqporn.xxx.'})
    _add_directory('[B]HD Mature Amateur[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/mature-amateur/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD Mature Amateur', 'plot': 'Browse HD Mature Amateur videos from hqporn.xxx.'})
    _add_directory('[B]HD POV Blowjob[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/pov-blowjob/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD POV Blowjob', 'plot': 'Browse HD POV Blowjob videos from hqporn.xxx.'})
    _add_directory('[B]HD Compilation[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/compilation/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD Compilation', 'plot': 'Browse HD Compilation videos from hqporn.xxx.'})
    _add_directory('[B]HD Cash[/B]',
                   build_url(action='hqpornxxx_list', url='https://hqporn.xxx/hd/cash/'),
                   thumb=HQPORNXXX_ICON,
                   info={'title': 'HD Cash', 'plot': 'Browse HD Cash videos from hqporn.xxx.'})
    for slug, title in (
            ('amateur-sex', 'HD Amateur'), ('mature', 'HD Mature'),
            ('mature-mom', 'HD Mature Mom'), ('housewife', 'HD Housewife'),
            ('cougar', 'HD Cougar'), ('cosplay', 'HD Cosplay'),
            ('office-sex', 'HD Office'), ('nurse', 'HD Nurse'),
            ('massage', 'HD Massage'), ('lesbi', 'HD Lesbian'),
            ('3some', 'HD Threesome'), ('hardcore', 'HD Hardcore'),
            ('anal-sex', 'HD Anal'), ('webcam', 'HD Webcam')):
        _add_directory('[B]%s[/B]' % title,
                       build_url(action='hqpornxxx_list',
                                 url='https://hqporn.xxx/hd/%s/' % slug),
                       thumb=HQPORNXXX_ICON,
                       info={'title': title,
                             'plot': 'Browse %s videos from hqporn.xxx.' % title})
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _eporner_root():
    if not _adult_route_authorized():
        return
    _add_directory('[B]Categories[/B]', build_url(action='eporner_categories'),
                   thumb=EPORNER_ICON,
                   info={'title': 'Categories', 'plot': 'Browse Eporner categories.'})
    _add_directory('[B]Pornstars[/B]', build_url(action='eporner_pornstars'),
                   thumb=EPORNER_ICON,
                   info={'title': 'Pornstars', 'plot': 'Browse Eporner pornstar video catalogues.'})
    _add_directory('[B]Channels[/B]', build_url(action='eporner_channels'),
                   thumb=EPORNER_ICON,
                   info={'title': 'Channels', 'plot': 'Browse Eporner channel video catalogues.'})
    _add_directory('[B]Best Videos[/B]',
                   build_url(action='eporner_web_list',
                             url='https://www.eporner.com/best-videos/'),
                   thumb=EPORNER_ICON,
                   info={'title': 'Best Videos',
                         'plot': 'Browse the best videos on Eporner.'})
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), cacheToDisc=False)


def _eporner_categories():
    if not _adult_route_authorized():
        return
    _add_directory(
        '[B]Japanese[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/japanese/'),
        thumb=EPORNER_ICON,
        info={'title': 'Japanese',
              'plot': 'Browse Japanese videos on Eporner.'},
    )
    _add_directory(
        '[B]POV Porn[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/pov-porn/'),
        thumb=EPORNER_ICON,
        info={'title': 'POV Porn',
              'plot': 'Browse POV Porn videos on Eporner.'},
    )
    _add_directory(
        '[B]Lesbians[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/lesbians/'),
        thumb=EPORNER_ICON,
        info={'title': 'Lesbians',
              'plot': 'Browse Lesbians videos on Eporner.'},
    )
    _add_directory(
        '[B]Ebony[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/ebony/'),
        thumb=EPORNER_ICON,
        info={'title': 'Ebony',
              'plot': 'Browse Ebony videos on Eporner.'},
    )
    _add_directory(
        '[B]Office[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/office/'),
        thumb=EPORNER_ICON,
        info={'title': 'Office',
              'plot': 'Browse Office videos on Eporner.'},
    )
    _add_directory(
        '[B]Homemade[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/homemade/'),
        thumb=EPORNER_ICON,
        info={'title': 'Homemade',
              'plot': 'Browse Homemade videos on Eporner.'},
    )
    _add_directory(
        '[B]Big Tits[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/big-tits/'),
        thumb=EPORNER_ICON,
        info={'title': 'Big Tits',
              'plot': 'Browse Big Tits videos on Eporner.'},
    )
    _add_directory(
        '[B]Webcam[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/webcam/'),
        thumb=EPORNER_ICON,
        info={'title': 'Webcam',
              'plot': 'Browse Webcam videos on Eporner.'},
    )
    _add_directory(
        '[B]Casting[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/casting/'),
        thumb=EPORNER_ICON,
        info={'title': 'Casting',
              'plot': 'Browse Casting videos on Eporner.'},
    )
    _add_directory(
        '[B]Nurse[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/nurse/'),
        thumb=EPORNER_ICON,
        info={'title': 'Nurse',
              'plot': 'Browse Nurse videos on Eporner.'},
    )
    _add_directory(
        '[B]HD Sex[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/hd-sex/'),
        thumb=EPORNER_ICON,
        info={'title': 'HD Sex',
              'plot': 'Browse HD Sex videos on Eporner.'},
    )
    _add_directory(
        '[B]Fetish[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/fetish/'),
        thumb=EPORNER_ICON,
        info={'title': 'Fetish',
              'plot': 'Browse Fetish videos on Eporner.'},
    )
    _add_directory(
        '[B]Group Sex[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/group-sex/'),
        thumb=EPORNER_ICON,
        info={'title': 'Group Sex',
              'plot': 'Browse Group Sex videos on Eporner.'},
    )
    _add_directory(
        '[B]Indian[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/indian/'),
        thumb=EPORNER_ICON,
        info={'title': 'Indian',
              'plot': 'Browse Indian videos on Eporner.'},
    )
    _add_directory(
        '[B]Threesome[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/threesome/'),
        thumb=EPORNER_ICON,
        info={'title': 'Threesome',
              'plot': 'Browse Threesome videos on Eporner.'},
    )
    _add_directory(
        '[B]Latina[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/latina/'),
        thumb=EPORNER_ICON,
        info={'title': 'Latina',
              'plot': 'Browse Latina videos on Eporner.'},
    )
    _add_directory(
        '[B]Pornstar[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/pornstar/'),
        thumb=EPORNER_ICON,
        info={'title': 'Pornstar',
              'plot': 'Browse Pornstar videos on Eporner.'},
    )
    _add_directory(
        '[B]Redhead[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/redhead/'),
        thumb=EPORNER_ICON,
        info={'title': 'Redhead',
              'plot': 'Browse Redhead videos on Eporner.'},
    )
    _add_directory(
        '[B]Doctor[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/doctor/'),
        thumb=EPORNER_ICON,
        info={'title': 'Doctor',
              'plot': 'Browse Doctor videos on Eporner.'},
    )
    _add_directory(
        '[B]For Women[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/for-women/'),
        thumb=EPORNER_ICON,
        info={'title': 'For Women',
              'plot': 'Browse For Women videos on Eporner.'},
    )
    _add_directory(
        '[B]Striptease[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/striptease/'),
        thumb=EPORNER_ICON,
        info={'title': 'Striptease',
              'plot': 'Browse Striptease videos on Eporner.'},
    )
    _add_directory(
        '[B]Cosplay[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/cosplay/'),
        thumb=EPORNER_ICON,
        info={'title': 'Cosplay',
              'plot': 'Browse Cosplay videos on Eporner.'},
    )
    _add_directory(
        '[B]Compilation[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/compilation/'),
        thumb=EPORNER_ICON,
        info={'title': 'Compilation',
              'plot': 'Browse Compilation videos on Eporner.'},
    )
    _add_directory(
        '[B]Cuckold[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/cuckold/'),
        thumb=EPORNER_ICON,
        info={'title': 'Cuckold',
              'plot': 'Browse Cuckold videos on Eporner.'},
    )
    _add_directory(
        '[B]Hotwife[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/hotwife/'),
        thumb=EPORNER_ICON,
        info={'title': 'Hotwife',
              'plot': 'Browse Hotwife videos on Eporner.'},
    )
    _add_directory(
        '[B]Gloryhole[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/gloryhole/'),
        thumb=EPORNER_ICON,
        info={'title': 'Gloryhole',
              'plot': 'Browse Gloryhole videos on Eporner.'},
    )
    _add_directory(
        '[B]Hotel[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/hotel/'),
        thumb=EPORNER_ICON,
        info={'title': 'Hotel',
              'plot': 'Browse Hotel videos on Eporner.'},
    )
    _add_directory(
        '[B]Uniform[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/uniform/'),
        thumb=EPORNER_ICON,
        info={'title': 'Uniform',
              'plot': 'Browse Uniform videos on Eporner.'},
    )
    _add_directory(
        '[B]Outdoor[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/outdoor/'),
        thumb=EPORNER_ICON,
        info={'title': 'Outdoor',
              'plot': 'Browse Outdoor videos on Eporner.'},
    )
    _add_directory(
        '[B]AI[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/ai/'),
        thumb=EPORNER_ICON,
        info={'title': 'AI',
              'plot': 'Browse AI videos on Eporner.'},
    )
    _add_directory(
        '[B]Footjob[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/footjob/'),
        thumb=EPORNER_ICON,
        info={'title': 'Footjob',
              'plot': 'Browse Footjob videos on Eporner.'},
    )
    _add_directory(
        '[B]HQ Porn[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/hq-porn/'),
        thumb=EPORNER_ICON,
        info={'title': 'HQ Porn',
              'plot': 'Browse HQ Porn videos on Eporner.'},
    )
    _add_directory(
        '[B]Swingers[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/swingers/'),
        thumb=EPORNER_ICON,
        info={'title': 'Swingers',
              'plot': 'Browse Swingers videos on Eporner.'},
    )
    _add_directory(
        '[B]Bukkake[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/bukkake/'),
        thumb=EPORNER_ICON,
        info={'title': 'Bukkake',
              'plot': 'Browse Bukkake videos on Eporner.'},
    )
    _add_directory(
        '[B]BDSM[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/bdsm/'),
        thumb=EPORNER_ICON,
        info={'title': 'BDSM',
              'plot': 'Browse BDSM videos on Eporner.'},
    )
    _add_directory(
        '[B]Small Tits[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/small-tits/'),
        thumb=EPORNER_ICON,
        info={'title': 'Small Tits',
              'plot': 'Browse Small Tits videos on Eporner.'},
    )
    _add_directory(
        '[B]4K Porn[/B]',
        build_url(action='eporner_web_list',
                  url='https://www.eporner.com/cat/4k-porn/'),
        thumb=EPORNER_ICON,
        info={'title': '4K Porn',
              'plot': 'Browse 4K Porn videos on Eporner.'},
    )
    xbmcplugin.addSortMethod(_handle(), xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _eporner_pornstars(page=1):
    if not _adult_route_authorized():
        return
    index = 'https://www.eporner.com/pornstar-list/'
    try:
        page = max(int(page or 1), 1)
        page_url = index if page == 1 else index.rstrip('/') + '/%d/' % page
        performers = eporner_mod.parse_pornstars(eporner_mod.fetch(page_url), page_url)
        performers.sort(key=lambda performer: performer.get('title', '').casefold())
        for performer in performers:
            _add_directory('[B]%s[/B]' % performer['title'],
                           build_url(action='eporner_web_list', url=performer['url']),
                           thumb=performer.get('thumb') or EPORNER_ICON,
                           info={'title': performer['title'],
                                 'artist': performer['title'],
                                 'genre': 'Adult', 'studio': 'Eporner',
                                 'mediatype': 'video',
                                 'plot': 'Browse videos featuring %s on Eporner.' % performer['title']})
        if performers:
            _add_directory('[B]Next Page »[/B]',
                           build_url(action='eporner_pornstars', page=str(page + 1)),
                           thumb=EPORNER_ICON,
                           info={'title': 'Next Page'})
        xbmcplugin.setContent(_handle(), 'files')
        xbmcplugin.endOfDirectory(_handle(), succeeded=bool(performers), cacheToDisc=False)
    except Exception as exc:
        xbmc.log('COSMOS: Eporner pornstar list failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Eporner', 'Unable to load Pornstars.',
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)


def _eporner_channels(page=1):
    if not _adult_route_authorized():
        return
    index = 'https://www.eporner.com/channels/'
    try:
        page = max(int(page or 1), 1)
        # Eporner serves the same channel index for these page URLs, so fetch
        # the complete index once and paginate the parsed results locally.
        channels = eporner_mod.parse_channels(eporner_mod.fetch(index), index)
        channels.sort(key=lambda channel: channel.get('title', '').casefold())
        page_size = 20
        start = (page - 1) * page_size
        visible_channels = channels[start:start + page_size]
        for channel in visible_channels:
            _add_directory('[B]%s[/B]' % channel['title'],
                           build_url(action='eporner_web_list', url=channel['url']),
                           thumb=channel.get('thumb') or EPORNER_ICON,
                           info={'title': channel['title'], 'artist': channel['title'],
                                 'genre': 'Adult', 'studio': 'Eporner',
                                 'plot': 'Browse videos from %s on Eporner.' % channel['title']})
        if start + page_size < len(channels):
            _add_directory('[B]Next Page »[/B]',
                           build_url(action='eporner_channels', page=str(page + 1)),
                           thumb=EPORNER_ICON,
                           info={'title': 'Next Page'})
        xbmcplugin.setContent(_handle(), 'files')
        xbmcplugin.endOfDirectory(_handle(), succeeded=bool(channels), cacheToDisc=False)
    except Exception as exc:
        xbmc.log('COSMOS: Eporner channels failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Eporner', 'Unable to load Channels.',
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)


def _eporner_list(page=1, order='latest'):
    if not _adult_route_authorized():
        return
    try:
        page = max(int(page or 1), 1)
        items, has_next = eporner_mod.listing(page, order)
    except Exception as exc:
        xbmc.log('COSMOS: Eporner listing failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Eporner', 'Unable to load this page.', xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)
        return
    for item in items:
        # Catalogue responses already contain the fields needed to render the
        # row. Avoid fetching every video page just to populate a listing.
        info = {'title': item['title'], 'genre': 'Adult', 'studio': 'Eporner',
                'mediatype': 'video', 'playcount': 0,
                'duration': item.get('duration') or 0}
        poster = item.get('thumb') or EPORNER_ICON
        if not isinstance(poster, str):
            poster = EPORNER_ICON
        _add_directory(item['title'],
                       build_url(action='eporner_play', url=item['url'], title=item['title']),
                       thumb=poster, fanart=FANART,
                       is_folder=False, is_playable=True, info=info)
    if has_next and items:
        _add_directory('[B]Next Page »[/B]',
                       build_url(action='eporner_list', page=str(page + 1), order=order),
                       thumb=EPORNER_ICON)
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), cacheToDisc=False)


def _eporner_web_list(page_url, page=1):
    if not _adult_route_authorized():
        return
    try:
        page = max(int(page or 1), 1)
        url = page_url if page == 1 else page_url.rstrip('/') + '/%d/' % page
        items, has_items = eporner_mod.parse_listing(eporner_mod.fetch(url), url)
    except Exception as exc:
        xbmc.log('COSMOS: Eporner web listing failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Eporner', 'Unable to load Best Videos.', xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)
        return
    for item in items:
        info = {'title': item['title'], 'genre': 'Adult', 'studio': 'Eporner',
                'mediatype': 'video', 'playcount': 0,
                'duration': item.get('duration') or 0}
        poster = item.get('thumb') or EPORNER_ICON
        if not isinstance(poster, str):
            poster = EPORNER_ICON
        _add_directory(item['title'],
                       build_url(action='eporner_play', url=item['url'], title=item['title']),
                       thumb=poster, fanart=FANART,
                       is_folder=False, is_playable=True, info=info)
    if has_items and items:
        _add_directory('[B]Next Page »[/B]',
                       build_url(action='eporner_web_list', url=page_url,
                                 page=str(page + 1)), thumb=EPORNER_ICON)
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), cacheToDisc=False)


def _eporner_play(page_url, title=''):
    if not _adult_route_authorized():
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return
    try:
        if not title:
            title = (eporner_mod.metadata(page_url).get('title') or
                     page_url.rstrip('/').rsplit('/', 1)[-1].replace('-', ' ').title())
        entries = eporner_mod.sources(page_url)
        if not entries:
            raise ValueError('No playable MP4 or HLS source was found')
        stream = eporner_mod.kodi_stream_url(entries[0], page_url)
        item = xbmcgui.ListItem(label=title or 'Eporner', path=stream)
        item.setInfo('video', {'title': title or 'Eporner', 'genre': 'Adult',
                               'studio': 'Eporner', 'mediatype': 'video', 'playcount': 0})
        item.setProperty('ResumeTime', '0')
        item.setProperty('TotalTime', '0')
        item.setProperty('IsPlayable', 'true')
        item.setMimeType('application/vnd.apple.mpegurl' if '.m3u8' in stream else 'video/mp4')
        xbmcplugin.setResolvedUrl(_handle(), True, item)
    except Exception as exc:
        xbmc.log('COSMOS: Eporner resolve failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Eporner', 'Unable to resolve this video.', xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())


def _hqpornxxx_channels():
    if not _adult_route_authorized():
        return
    try:
        index = 'https://hqporn.xxx/channels/'
        channels = hqpornxxx_mod.parse_channels(hqpornxxx_mod.fetch(index), index)
        for channel in channels:
            _add_directory('[B]%s[/B]' % channel['title'],
                           build_url(action='hqpornxxx_list', url=channel['url']),
                           thumb=HQPORNXXX_ICON,
                           info={'title': channel['title'],
                                 'plot': 'Browse videos from the %s channel.' % channel['title']})
        xbmcplugin.setContent(_handle(), 'files')
        xbmcplugin.endOfDirectory(_handle(), succeeded=bool(channels), cacheToDisc=False)
    except Exception as exc:
        xbmc.log('COSMOS: hqporn.xxx channels failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('hqporn.xxx', 'Unable to load channels.',
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)


def _hqpornxxx_pornstars(page=1):
    if not _adult_route_authorized():
        return
    try:
        page = max(int(page or 1), 1)
        index = 'https://hqporn.xxx/pornstars/'
        people = hqpornxxx_mod.parse_pornstars(hqpornxxx_mod.fetch(index), index)
        people.sort(key=lambda person: person.get('title', '').casefold())
        page_size = 20
        start = (page - 1) * page_size
        visible_people = people[start:start + page_size]
        for person in visible_people:
            _add_directory('[B]%s[/B]' % person['title'],
                           build_url(action='hqpornxxx_list', url=person['url']),
                           thumb=person.get('thumb') or HQPORNXXX_ICON,
                           info={'title': person['title'],
                                 'plot': 'Browse videos featuring %s.' % person['title']})
        if start + page_size < len(people):
            _add_directory('[B]Next Page »[/B]',
                           build_url(action='hqpornxxx_pornstars', page=str(page + 1)),
                           thumb=HQPORNXXX_ICON,
                           info={'title': 'Next Page'})
        xbmcplugin.setContent(_handle(), 'files')
        xbmcplugin.endOfDirectory(_handle(), succeeded=bool(people), cacheToDisc=False)
    except Exception as exc:
        xbmc.log('COSMOS: hqporn.xxx pornstars failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('hqporn.xxx', 'Unable to load pornstars.',
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False, cacheToDisc=False)


def _hqpornxxx_play(page_url, title=''):
    if not _adult_route_authorized():
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return
    try:
        sources = hqpornxxx_mod.parse_sources(hqpornxxx_mod.fetch(page_url), page_url)
        if not sources:
            raise ValueError('No playable MP4 source was found')
        choice = 0
        if len(sources) > 1:
            choice = xbmcgui.Dialog().select('hqporn.xxx - Choose Quality',
                                              [source['label'] for source in sources])
            if choice < 0:
                xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
                return
        stream = hqpornxxx_mod.kodi_stream_url(sources[choice]['url'], page_url)
        item = xbmcgui.ListItem(label=title or 'hqporn.xxx', path=stream)
        item.setInfo('video', {'title': title or 'hqporn.xxx', 'mediatype': 'video', 'playcount': 0})
        item.setProperty('ResumeTime', '0')
        item.setProperty('TotalTime', '0')
        item.setProperty('IsPlayable', 'true')
        item.setMimeType('video/mp4')
        xbmcplugin.setResolvedUrl(_handle(), True, item)
    except Exception as exc:
        xbmc.log('COSMOS: hqporn.xxx resolve failed: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('hqporn.xxx', 'Unable to resolve this video.',
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())


# ── Menu / directory navigation ──────────────────────────────────────────

def _add_directory(label, url, thumb='', is_folder=True, info=None, is_playable=False,
                   fanart=None, context_items=None, live=False):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': thumb or ICON, 'thumb': thumb or ICON,
               'poster': thumb or ICON, 'fanart': fanart or FANART})
    if info:
        tag = None
        try:
            tag = li.getVideoInfoTag()
        except Exception:
            tag = None
        if tag is None:
            li.setInfo('video', info)
        else:
            # Kodi's modern VideoInfoTag API is not perfectly uniform across
            # versions. Apply each field independently so an older skin/API
            # cannot suppress the remaining metadata or the watched badge.
            tag_fields = (
                ('plot', 'setPlot', lambda value: value),
                ('title', 'setTitle', lambda value: value),
                ('tvshowtitle', 'setTvShowTitle', lambda value: value),
                ('mediatype', 'setMediaType', lambda value: value),
                ('year', 'setYear', int),
                ('genre', 'setGenres', lambda value: [
                    part.strip() for part in str(value).split(',') if part.strip()
                ]),
                ('rating', 'setRating', float),
                ('duration', 'setDuration', int),
                ('mpaa', 'setMpaa', str),
                ('season', 'setSeason', int),
                ('episode', 'setEpisode', int),
                ('playcount', 'setPlaycount', int),
            )
            for key, setter_name, convert in tag_fields:
                if key not in info or info[key] is None:
                    continue
                try:
                    getattr(tag, setter_name)(convert(info[key]))
                except Exception:
                    pass
    if is_playable:
        li.setProperty('IsPlayable', 'true')
    if live:
        # Live channels must never acquire Kodi watched/resume state.
        li.setInfo('video', dict(info or {}, mediatype='video', playcount=0,
                                 overlay=0, duration=0))
        li.setProperty('ResumeTime', '0')
        li.setProperty('TotalTime', '0')
    if context_items:
        li.addContextMenuItems(list(context_items) + _subtitle_toggle_ctx_items())
    # A completely empty URL with is_folder=False is the most reliable way
    # to create a non-clickable label across different Kodi skins.
    if not url and not is_folder:
        url = build_url(action='noop')
        li.setProperty('IsPlayable', 'false') # Explicitly mark as not playable
    xbmcplugin.addDirectoryItem(handle=_handle(), url=url or '', listitem=li, isFolder=is_folder)



_PAGE_SIZE = 20


def list_menu(feed_url, is_root=False, page=1, fallback_url=''):
    """Fetch and render a directory or content page."""
    requested_url = feed_url
    body = parser.fetch_url(feed_url)
    if not body and fallback_url and fallback_url != feed_url:
        xbmc.log(
            f'COSMOS: configured menu feed failed; retrying default feed '
            f'{fallback_url}',
            xbmc.LOGWARNING,
        )
        feed_url = fallback_url
        body = parser.fetch_url(feed_url)
    if not body:
        if is_root:
            xbmc.log(
                f'COSMOS: root feed unavailable; showing local menu fallback: '
                f'{requested_url}', xbmc.LOGWARNING,
            )
            _add_directory(f'[B]{_L(30003, "Newly Added")}[/B]',
                           build_url(action='newly_added', feed=feed_url),
                           thumb=_menu_icon('newly_added'), is_folder=True)
            _add_directory(f'[B]{_L(30001, "Movies")}[/B]',
                           build_url(action='movies_root'),
                           thumb=_menu_icon('movies'), is_folder=True)
            _add_directory(f'[B]{_L(30002, "TV Shows")}[/B]',
                           build_url(action='tvshows_root'),
                           thumb=_menu_icon('tvshows'), is_folder=True)
            _add_directory(f'[B]{_L(30005, "Continue Watching")}[/B]',
                           build_url(action='continue_watching'),
                           thumb=_menu_icon('continue'), is_folder=True)
            _add_directory(f'[B]{_L(30004, "Universal Search")}[/B]',
                           build_url(action='search', feed=feed_url),
                           thumb=_menu_icon('search'), fanart=FANART,
                           is_folder=True)
            _add_directory(f'[B]{_L(30006, "Favourites")}[/B]',
                           build_url(action='favourites_list'),
                           thumb=_menu_icon('favourites'), is_folder=True)
            _add_directory('[B]My Tracking[/B]', build_url(action='tracking_root'),
                           thumb=_menu_icon('my_tracking'), fanart=FANART,
                           is_folder=True)
            _add_directory(f'[B]{_L(30007, "Downloads")}[/B]',
                           build_url(action='downloads_list'),
                           thumb=_menu_icon('downloads'), is_folder=True)
            _add_directory('[B]Release Hub[/B]',
                           build_url(action='release_hub_root'),
                           thumb=_menu_icon('release_hub'), fanart=FANART,
                           is_folder=True)
            _add_directory('[B]Cartoons & Anime[/B]', build_url(action='anime_root'),
                           thumb=_menu_icon('cartoons_anime'), fanart=FANART,
                           info={'title': 'Cartoons & Anime'}, is_folder=True)
            _add_directory('[B]Freebie TV[/B]', build_url(action='freebie_tv_root'),
                           thumb=FREEBIE_TV_ICON, fanart=FANART,
                           info={'title': 'Freebie TV'}, is_folder=True)
            _add_directory('[B]Sports Hub[/B]', build_url(action='sports_hub'),
                           thumb=_menu_icon('sports'), fanart=FANART,
                           is_folder=True)
            _add_directory('[B]Music[/B]', build_url(action='music_root'),
                           thumb=f'{ADDON_PATH}resources/media/icon_music_root.png',
                           fanart=FANART, info={'title': 'Music'}, is_folder=True)
            _add_directory('[B]Adult Lounge[/B]', build_url(action='xxx_root'),
                           thumb=_menu_icon('xxx'), fanart=FANART,
                           is_folder=True)
            _add_directory(f'[B]{_L(30009, "Tools")}[/B]',
                           build_url(action='tools'),
                           thumb=_menu_icon('tools'), is_folder=True)
            _add_directory('[B]Wiki Trailers[/B]',
                           build_url(action='install_wiki_trailers'),
                           thumb=WIKI_TRAILERS_ICON, fanart=FANART,
                           info={'title': 'Wiki Trailers', 'plot':
                                 'Select to install Wiki Trailers from the Enigma Repository.'},
                           is_folder=False)
            _add_directory('[B]Changelog[/B]', build_url(action='view_changelog'),
                           is_folder=False, thumb=_menu_icon('changelog'))
            _add_directory('[B]Settings[/B]', build_url(action='open_settings'),
                           is_folder=False, thumb=_menu_icon('settings'))
            _add_directory('[COLOR lime]Any requests? Please message @enigmawiz in the Telegram group with the TMDB ID.[/COLOR]',
                           '', thumb=_menu_icon('requests'), is_folder=False,
                           is_playable=False)
            _add_directory('[COLOR gold]Telegram: Scan QR code or manually enter https://t.me/Cosmos23456/1[/COLOR]',
                           build_url(action='telegram_qr'),
                           thumb=_menu_icon('telegram'), is_folder=False)
            _add_directory('[COLOR cyan]Support C.O.S.M.O.S: https://buymeacoffee.com/cosmoskodi[/COLOR]',
                           '', thumb=ICON, is_folder=False, is_playable=False)
            xbmcplugin.endOfDirectory(_handle(), succeeded=True,
                                      cacheToDisc=False)
            return
        xbmc.log(
            f'COSMOS: unable to load menu feed: {requested_url}',
            xbmc.LOGERROR,
        )
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'Failed to load menu feed',
            xbmcgui.NOTIFICATION_ERROR, 4000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    kind, items = parser.parse_page(body)

    if kind == 'directory':
        # ── C.O.S.M.O.S root order ──────────────────────────────────────────
        if is_root:
            _add_directory(
                f'[B]{_L(30003, "Newly Added")}[/B]',
                build_url(action='newly_added', feed=feed_url),
                thumb=_menu_icon('newly_added'), is_folder=True,
            )
            _add_directory(
                f'[B]{_L(30001, "Movies")}[/B]',
                build_url(action='movies_root'),
                thumb=_menu_icon('movies'), is_folder=True,
            )
            _add_directory(
                f'[B]{_L(30002, "TV Shows")}[/B]',
                build_url(action='tvshows_root'),
                thumb=_menu_icon('tvshows'), is_folder=True,
            )
        # ── Items coming from the home feed (Movies, TV Shows, ...)
        # The root layout is curated locally. Keep the parsed feed available
        # for the two Enigma destinations, but do not render arbitrary feed
        # rows ahead of the requested Cosmos sections.
        feed_items = items
        if is_root:
            feed_items = []

        for it in feed_items:
            child_feed = (it.get('url') or '').strip()
            if not child_feed:
                xbmc.log(
                    f'COSMOS: skipping root feed item without URL: {it.get("name", "")!r}',
                    xbmc.LOGWARNING,
                )
                continue
            url = build_url(action='menu', feed=child_feed.replace('.xml', '.xmll'))
            _add_directory(f'[B]{it["name"]}[/B]', url, thumb=it.get('thumb'))
        if is_root:
            enigma_movies = _root_feed_item(
                items, 'Enigma Movies', 'Enigma Movie', 'Movies', 'Movie',
            )
            enigma_tv = _root_feed_item(
                items, 'Enigma TV Shows', 'Enigma TV Show', 'TV Shows',
                'TV Show', 'Enigma Shows', 'Enigma TV', 'Shows',
            )
            if enigma_movies and _root_feed_url(enigma_movies):
                _add_directory(
                    '[B]Enigma Movies[/B]', _root_feed_url(enigma_movies),
                    thumb=enigma_movies.get('thumb') or _menu_icon('movies'),
                    is_folder=True,
                )
            if enigma_tv and _root_feed_url(enigma_tv):
                _add_directory(
                    '[B]Enigma TV Shows[/B]', _root_feed_url(enigma_tv),
                    thumb=enigma_tv.get('thumb') or _menu_icon('tvshows'),
                    is_folder=True,
                )
            _add_directory(
                f'[B]{_L(30005, "Continue Watching")}[/B]',
                build_url(action='continue_watching'),
                thumb=_menu_icon('continue'), is_folder=True,
            )
            _add_directory(
                f'[B]{_L(30004, "Universal Search")}[/B]',
                build_url(action='search', feed=feed_url),
                thumb=_menu_icon('search'), is_folder=True,
            )
            _add_directory(
                f'[B]{_L(30006, "Favourites")}[/B]',
                build_url(action='favourites_list'),
                thumb=_menu_icon('favourites'), is_folder=True,
            )
            _add_directory(
                '[B]My Tracking[/B]', build_url(action='tracking_root'),
                thumb=_menu_icon('my_tracking'), fanart=FANART, is_folder=True,
            )
            _add_directory(
                f'[B]{_L(30007, "Downloads")}[/B]',
                build_url(action='downloads_list'),
                thumb=_menu_icon('downloads'), is_folder=True,
            )
            _add_directory(
                '[B]Release Hub[/B]', build_url(action='release_hub_root'),
                thumb=_menu_icon('release_hub'), fanart=FANART, is_folder=True,
            )
            _add_directory(
                '[B]Cartoons & Anime[/B]', build_url(action='anime_root'),
                thumb=_menu_icon('cartoons_anime'), fanart=FANART,
                info={'title': 'Cartoons & Anime'},
                is_folder=True,
            )
            _add_directory(
                '[B]Freebie TV[/B]', build_url(action='freebie_tv_root'),
                thumb=FREEBIE_TV_ICON, fanart=FANART,
                info={'title': 'Freebie TV'},
                is_folder=True,
            )
            _add_directory(
                '[B]Sports Hub[/B]', build_url(action='sports_hub'),
                thumb=_menu_icon('sports'), fanart=FANART, is_folder=True,
            )
            _add_directory(
                '[B]Music[/B]', build_url(action='music_root'),
                thumb=f'{ADDON_PATH}resources/media/icon_music_root.png', fanart=FANART,
                info={'title': 'Music'},
                is_folder=True,
            )
            _add_directory(
                '[B]Adult Lounge[/B]', build_url(action='xxx_root', adult_entry='1'),
                thumb=_menu_icon('xxx'), fanart=FANART, is_folder=True,
            )
            _add_directory(
                f'[B]{_L(30009, "Tools")}[/B]',
                build_url(action='tools'),
                thumb=_menu_icon('tools'), is_folder=True,
            )
        if is_root:
            wiki_trailers_installed = bool(
                xbmc.getCondVisibility(f'System.HasAddon({WIKI_TRAILERS_ID})'))
            wiki_trailers_icon = WIKI_TRAILERS_ICON
            if wiki_trailers_installed:
                try:
                    wiki_trailers_icon = (
                        xbmcaddon.Addon(WIKI_TRAILERS_ID).getAddonInfo('icon')
                        or WIKI_TRAILERS_ICON)
                except Exception:
                    pass
            _add_directory(
                '[B]Wiki Trailers[/B]',
                f'plugin://{WIKI_TRAILERS_ID}/' if wiki_trailers_installed
                else build_url(action='install_wiki_trailers'),
                thumb=wiki_trailers_icon, fanart=FANART,
                info={'title': 'Wiki Trailers', 'plot': (
                    'Browse Wiki Trailers.' if wiki_trailers_installed else
                    'Select to install Wiki Trailers from the Enigma Repository.')},
                is_folder=wiki_trailers_installed,
            )
            _add_directory('[B]Settings[/B]', build_url(action='open_settings'),
                           is_folder=False, thumb=_menu_icon('settings'))
            _add_directory(
                '[B]Changelog[/B]', build_url(action='view_changelog'),
                is_folder=False, thumb=_menu_icon('changelog'),
            )
            _add_directory(
                '[COLOR lime]Any requests? Please message @enigmawiz in the Telegram group with the TMDB ID.[/COLOR]',
                '', thumb=_menu_icon('requests'), is_folder=False, is_playable=False,
            )
            # Add non-clickable Telegram link
            _add_directory('[COLOR gold]Telegram: Scan QR code or manually enter https://t.me/Cosmos23456/1[/COLOR]',
                           build_url(action='telegram_qr'),
                           thumb=_menu_icon('telegram'), is_folder=False)
            _add_directory('[COLOR cyan]Support C.O.S.M.O.S: https://buymeacoffee.com/cosmoskodi[/COLOR]',
                           '', thumb=ICON, is_folder=False, is_playable=False)
        xbmcplugin.setContent(_handle(), 'files')
    elif kind == 'tvshow':
        total = len(items)
        start = (page - 1) * _PAGE_SIZE
        end = start + _PAGE_SIZE
        _render_tvshows(items[start:end], feed_url)
        if end < total:
            next_li = xbmcgui.ListItem(
                label=f'[B]Next page ({page + 1}) »[/B]  {end}/{total} shown')
            next_li.setArt({'icon': ICON, 'thumb': ICON, 'fanart': FANART})
            xbmcplugin.addDirectoryItem(
                _handle(),
                build_url(action='menu', feed=feed_url, page=str(page + 1)),
                next_li, isFolder=True,
            )
    else:
        total = len(items)
        start = (page - 1) * _PAGE_SIZE
        end = start + _PAGE_SIZE
        _render_content(items[start:end], feed_url=feed_url)
        if end < total:
            next_li = xbmcgui.ListItem(
                label=f'[B]Next page ({page + 1}) »[/B]  {end}/{total} shown')
            next_li.setArt({'icon': ICON, 'thumb': ICON, 'fanart': FANART})
            xbmcplugin.addDirectoryItem(
                _handle(),
                build_url(action='menu', feed=feed_url, page=str(page + 1)),
                next_li, isFolder=True,
            )

    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=True)


def _render_content(items, feed_url=''):
    """Render a list of movies / tv shows with TMDB metadata.

    Each content item is rendered as a *folder*; opening it lists the
    labelled source links (Link 1 Non Debrid, Link 2 4k Debrid, ...) which
    are the actual playable items.
    """
    import json as _json
    # Match the Enigma-show flow: take one watched snapshot for the complete
    # listing, then use that same state for labels and Kodi playcounts.
    watched_movies = watched_mod.get_local_watched_movies()
    for it in items:
        tmdb_id = str(it.get('tmdb') or '').strip()
        content = str(it.get('content') or 'movie').strip().lower()
        meta = tmdb_mod.get_metadata(tmdb_id, content) if tmdb_id else {}

        clean_title = meta.get('title') or it.get('name') or 'Untitled'
        label = clean_title
        year = meta.get('year')
        if year:
            label = f'{label} ({year})'
        movie_watched = bool(content == 'movie' and tmdb_id in watched_movies)
        if content == 'movie' and tmdb_id:
            label = f'{_watched_indicator(movie_watched)}  {label}'

        li = xbmcgui.ListItem(label=label)
        tmdb_mod.apply_to_listitem(li, meta, content)
        if content == 'movie' and tmdb_id:
            try:
                li.getVideoInfoTag().setPlaycount(1 if movie_watched else 0)
            except Exception:
                li.setProperty('PlayCount', '1' if movie_watched else '0')
        thumb = meta.get('poster') or it.get('thumb') or ICON
        fanart = meta.get('fanart') or FANART
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})

        payload = _json.dumps({
            'title': it.get('name') or clean_title,
            'tmdb': tmdb_id,
            'content': content,
            'season': it.get('season'),
            'episode': it.get('episode'),
            'links': it.get('links') or [],
            'imdb': (meta or {}).get('imdb_id', ''),
            'year': year or parser.extract_year(it.get('name') or ''),
            'poster': thumb,
            'fanart': fanart,
            # Enigma movie entries are playable from their stored links. Keep
            # the source feed as provenance and as a useful return location.
            'feed': it.get('feed') or feed_url,
            'return_url': build_url(action='menu', feed=feed_url) if feed_url else '',
        })
        url = build_url(action='show_links', payload=payload)
        _title_str = meta.get('title') or it.get('name', '')
        _set_ctx(li,
                 _fav_ctx_items(payload, tmdb_id, content, _title_str),
                 _info_ctx_items(_title_str, tmdb_id, content, thumb, fanart),
                 _scrobbler_ctx_items(payload, tmdb_id, content, _title_str),
                 _extras_ctx_items(_title_str, tmdb_id, content, thumb, fanart),
                 _trailer_ctx_items(tmdb_id, content),
                 _local_movie_ctx_items(tmdb_id, content, _title_str),
                 _opensubtitles_ctx_items(payload, tmdb_id, content, _title_str),
                 _direct_link_download_ctx_items(payload),
                 replace_items=True,
        )
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)

    xbmcplugin.setContent(_handle(), 'movies')
    xbmcplugin.addSortMethod(_handle(), xbmcplugin.SORT_METHOD_LABEL)


def _list_links(payload_json):
    """Render the labelled links of a content item as playable sub-items."""
    import json as _json
    try:
        data = _json.loads(payload_json)
    except ValueError:
        xbmc.log('COSMOS [ERROR] _list_links: JSON decode failed', xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    links = data.get('links') or []
    xbmc.log(
        f'COSMOS [FLOW] show_links  title={data.get("title")!r}'
        f'  content={data.get("content")!r}'
        f'  tmdb={data.get("tmdb")!r}'
        f'  season={data.get("season")!r}  episode={data.get("episode")!r}'
        f'  link_count={len(links)}',
        xbmc.LOGDEBUG,
    )
    if not links:
        # No pre-built links — jump straight to the scraper pipeline when we
        # have enough metadata to search (imdb or tmdb present). This handles
        # TMDB browse items, favourites, continue-watching entries, etc. that
        # carry no native feed links but do have a TMDB/IMDB id.
        if data.get('imdb') or data.get('tmdb'):
            _link_zero(payload_json)
        else:
            xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No links available',
                                          xbmcgui.NOTIFICATION_WARNING, 3000)
            xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    thumb = data.get('poster') or ICON
    fanart = data.get('fanart') or FANART
    title = data.get('title') or 'Untitled'

    if len(links) == 1:
        _label = str(links[0].get('label', '')).lower()
        if 'non debrid' in _label or 'debrid' not in _label:
            _direct_play_payload = _json.dumps({
                'title': title,
                'tmdb': data.get('tmdb'),
                'content': data.get('content'),
                'season': data.get('season'),
                'episode': data.get('episode'),
                'imdb': data.get('imdb'),
                'year': data.get('year'),
                'url': links[0].get('url', ''),
                'label': links[0].get('label', 'Link 1'),
                'feed': data.get('feed', ''),
                'return_url': data.get('return_url', ''),
            })
            
            # Bypass the source-finder redirect while still allowing the
            # normal saved-position prompt to appear.
            _play_url = build_url(
                action='play_link', payload=_direct_play_payload,
                direct='1', use_player='1')
            xbmc.executebuiltin(f'RunPlugin({_play_url})')
            
            # Safely abort the source picker directory generation
            xbmcplugin.endOfDirectory(_handle(), succeeded=False)
            return

    # ── Link Zero ─────────────────────────────────────────────────────
    # Always prepend a "Link Zero" row that runs the torrent scrapers
    # ── Link Zero ─────────────────────────────────────────────────────
    # Always prepend a "Link Zero" row that runs the torrent scrapers
    # (debrid + cache check) above the feed's non-debrid links. Users can
    # skip it and pick a feed link below if they prefer.
    try:
        lz = xbmcgui.ListItem(label='[COLOR gold][B]Link Zero[/B][/COLOR]  [COLOR grey]Find from scrapers (debrid-cached)[/COLOR]')
        lz.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})
        try:
            tag = lz.getVideoInfoTag()
            tag.setTitle(f'{title} — Link Zero')
            tag.setMediaType('movie' if (data.get('content') or 'movie') == 'movie' else 'episode')
        except Exception:
            pass
        lz.setProperty('IsPlayable', 'true')
        lz_payload = __import__('json').dumps({
            'title': title,
            'tmdb': data.get('tmdb'),
            'content': data.get('content'),
            'season': data.get('season'),
            'episode': data.get('episode'),
            'imdb': data.get('imdb'),
            'year': data.get('year'),
            'poster': thumb,
            'fanart': fanart,
        })
        lz_url = build_url(action='link_zero', payload=lz_payload)
        xbmcplugin.addDirectoryItem(_handle(), lz_url, lz, isFolder=False)
    except Exception as _e:
        xbmc.log(f'COSMOS: Link Zero row failed: {_e}', xbmc.LOGWARNING)

    for idx, link in enumerate(links):
        label = link.get('label') or f'Link {idx + 1}'
        is_movie = str(data.get('content') or 'movie').lower() == 'movie'
        movie_watched = bool(
            is_movie and data.get('tmdb') and
            watched_mod.is_movie_watched(data.get('tmdb'))
        )
        display_label = (
            f'{_watched_indicator(movie_watched)}  {label}'
            if is_movie and data.get('tmdb') else label
        )
        li = xbmcgui.ListItem(label=display_label)
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(f'{title} — {label}')
            tag.setMediaType('movie' if (data.get('content') or 'movie') == 'movie' else 'episode')
            if is_movie and data.get('tmdb'):
                tag.setPlaycount(1 if movie_watched else 0)
        except Exception:
            pass
        li.setProperty('IsPlayable', 'true')

        link_payload_dict = {
            'title': title,
            'tmdb': data.get('tmdb'),
            'content': data.get('content'),
            'season': data.get('season'),
            'episode': data.get('episode'),
            'imdb': data.get('imdb'),
            'year': data.get('year'),
            'url': link.get('url', ''),
            'label': label,
            'feed': data.get('feed', ''),
            'return_url': data.get('return_url', ''),
        }
        link_payload = _json.dumps(link_payload_dict)
        play_url = build_url(action='play_link', payload=link_payload)
        resume_url = build_url(action='play_link', payload=link_payload, resume='1')
        start_over_url = build_url(action='play_link', payload=link_payload, prompt='0')
        dl_url = build_url(action='download_item', payload=link_payload)

        # Apply stored resume point
        rkey = resume_mod.key_for(
            tmdb=data.get('tmdb'), content=data.get('content'),
            season=data.get('season'), episode=data.get('episode'),
            label=label, url=link.get('url', ''),
        )
        resume_info = resume_mod.get(rkey)
        ctx = []
        if resume_info:
            pos, dur = resume_info
            li.setLabel(
                f'{display_label}  [COLOR gold]{resume_mod.format_offset(pos)}[/COLOR]')
            try:
                tag = li.getVideoInfoTag()
                tag.setResumePoint(float(pos), float(dur or 0))
            except Exception:
                li.setProperty('ResumeTime', str(int(pos)))
                if dur:
                    li.setProperty('TotalTime', str(int(dur)))
            ctx.append((f'[COLOR gold]Continue from {resume_mod.format_offset(pos)}[/COLOR]',
                        f'RunPlugin({resume_url})'))
            ctx.append(('Play from beginning', f'RunPlugin({start_over_url})'))
            ctx.append(('Clear resume point',
                        f'RunPlugin({build_url(action="clear_resume", key=rkey)})'))
        download_label = (
            '[COLOR cyan]Resolve & download this link[/COLOR]'
            if _is_debrid_source(link.get('url', ''), label)
            else '[COLOR cyan]Download this link[/COLOR]'
        )
        ctx.append((download_label, f'RunPlugin({dl_url})'))
        ctx.extend(_local_movie_ctx_items(
            data.get('tmdb'), data.get('content') or 'movie', title))
        _sub_lnk_pl = _json.dumps({
            'title': title,
            'tmdb': data.get('tmdb'),
            'imdb': data.get('imdb'),
            'content': data.get('content', 'movie'),
            'season': data.get('season'),
            'episode': data.get('episode'),
        })
        ctx.append(('[COLOR cyan]Download Subtitles[/COLOR]',
                    f'RunPlugin({build_url(action="opensubtitles_search", payload=_sub_lnk_pl)})'))
        li.addContextMenuItems(ctx + _subtitle_toggle_ctx_items())
        xbmcplugin.addDirectoryItem(_handle(), play_url, li, isFolder=False)

    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


# ── TV shows ─────────────────────────────────────────────────────────────

def _render_tvshows(shows, feed_url):
    """Render the top-level list of TV shows as folders."""
    _replace_builtin_context_items()
    for sh in shows:
        tmdb_id = sh.get('tmdb') or ''
        meta = tmdb_mod.get_metadata(tmdb_id, 'tvshow') if tmdb_id else {}

        label = meta.get('title') or sh.get('name') or 'Untitled'
        li = xbmcgui.ListItem(label=label)
        tmdb_mod.apply_to_listitem(li, meta, 'tvshow')
        thumb = meta.get('poster') or sh.get('thumb') or ICON
        fanart = meta.get('fanart') or FANART
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})

        url = build_url(action='tv_seasons', feed=feed_url, tmdb=tmdb_id)
        tv_payload = __import__('json').dumps({
            'feed': feed_url, 'tmdb': tmdb_id,
            'title': meta.get('title') or sh.get('name', ''),
            'content': 'tvshow',
            'year': meta.get('year', ''),
            'thumb': thumb, 'fanart': fanart,
        })
        _tv_title = meta.get('title') or sh.get('name', '')
        ctx = []
        ctx.extend(_fav_ctx_items(tv_payload, tmdb_id, 'tvshow', _tv_title))
        ctx.extend(_info_ctx_items(_tv_title, tmdb_id, 'tvshow', thumb, fanart))
        ctx.extend(_scrobbler_ctx_items(tv_payload, tmdb_id, 'tvshow', _tv_title))
        ctx.extend(_extras_ctx_items(_tv_title, tmdb_id, 'tvshow', thumb, fanart))
        ctx.extend(_trailer_ctx_items(tmdb_id, 'tvshow'))
        ctx.extend(_local_tvshow_ctx_items(tmdb_id, _tv_title))
        ctx.extend(_opensubtitles_ctx_items(tv_payload, tmdb_id, 'tvshow', _tv_title))
        if ctx:
            li.addContextMenuItems(ctx + _subtitle_toggle_ctx_items())
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)


    xbmcplugin.setContent(_handle(), 'tvshows')
    xbmcplugin.addSortMethod(_handle(), xbmcplugin.SORT_METHOD_LABEL)


def _find_show(feed_url, tmdb_id):
    """Re-fetch the TV feed and return the show dict matching tmdb_id."""
    body = parser.fetch_url(feed_url)
    if not body:
        return None, None
    kind, shows = parser.parse_page(body)
    if kind != 'tvshow':
        return None, None
    for sh in shows:
        if str(sh.get('tmdb') or '') == str(tmdb_id or ''):
            return sh, shows
    # Fallback: if only one show in the feed, use it
    if len(shows) == 1:
        return shows[0], shows
    return None, shows


def _find_next_episode(show, watched_set):
    """Return (season_no, ep_no, links) for the first unwatched episode,
    iterating seasons and episodes in playlist order.
    Returns None when every episode is marked watched."""
    for season in show.get('seasons', []):
        sno = season.get('seasonNo')
        try:
            sno_int = int(sno)
        except (TypeError, ValueError):
            continue
        for ep in season.get('episodes', []):
            ep_no = ep.get('episode')
            try:
                ep_int = int(ep_no)
            except (TypeError, ValueError):
                continue
            if (sno_int, ep_int) not in watched_set:
                return sno_int, ep_int, ep.get('links') or []
    return None


def _find_following_episode(show, season_no, episode_no):
    """Return the episode immediately after the current Cosmos feed item."""
    try:
        current = (int(season_no), int(episode_no))
    except (TypeError, ValueError):
        return None

    flattened = []
    for season in show.get('seasons', []):
        try:
            season_number = int(season.get('seasonNo'))
        except (TypeError, ValueError):
            continue
        for episode in season.get('episodes', []):
            try:
                episode_number = int(episode.get('episode'))
            except (TypeError, ValueError):
                continue
            flattened.append((season_number, episode_number, episode.get('links') or []))

    for index, item in enumerate(flattened):
        if item[:2] == current and index + 1 < len(flattened):
            return flattened[index + 1]

    # If the current item was removed from the feed, still choose the first
    # later-numbered item rather than incorrectly restarting the show.
    for item in flattened:
        if item[:2] > current:
            return item
    return None


def _autoplay_next_from_shows(params):
    """Start the next episode using the native Cosmos Shows feed sequence."""
    import json as _json

    feed_url = str(params.get('feed') or '').strip()
    tmdb_id = str(params.get('tmdb') or '').strip()
    if not feed_url:
        xbmc.log('COSMOS autoplay: Shows episode has no feed URL', xbmc.LOGWARNING)
        return

    show, _ = _find_show(feed_url, tmdb_id)
    if not show:
        xbmc.log('COSMOS autoplay: Shows feed could not be refreshed', xbmc.LOGWARNING)
        return

    following = _find_following_episode(
        show, params.get('season', ''), params.get('episode', ''),
    )
    if not following:
        xbmc.log('COSMOS autoplay: current Shows episode is the final feed item', xbmc.LOGINFO)
        return

    next_season, next_episode, next_links = following
    title = str(params.get('title') or show.get('name') or 'Untitled')
    return_url = build_url(
        action='tv_episodes', feed=feed_url, tmdb=tmdb_id,
        season=str(next_season),
    )
    payload = {
        'title': title,
        'tmdb': tmdb_id,
        'content': 'episode',
        'season': next_season,
        'episode': next_episode,
        'links': next_links or [],
        'feed': feed_url,
        'return_url': return_url,
        'imdb': params.get('imdb', ''),
        'year': params.get('year', ''),
        'poster': params.get('poster', ''),
        'fanart': params.get('fanart', ''),
    }

    # Automatic continuation always uses Link Zero. The Cosmos feed is used
    # only to identify the next episode; Link Zero remains responsible for
    # source discovery, cache checks, debrid resolution, and playback.
    play_url = build_url(
        action='link_zero', payload=_json.dumps(payload), auto_next='1',
    )

    xbmc.log(
        f'COSMOS autoplay: starting Shows episode S{next_season}E{next_episode}',
        xbmc.LOGINFO,
    )
    xbmc.executebuiltin(f'RunPlugin({play_url})')


def _season_watched_progress(watched_set, season_number,
                             episode_numbers=None, episode_count=0):
    """Return an accurate ``(watched, total)`` pair for one season.

    Direct-link feeds can contain duplicate or malformed episode rows, so use
    their unique positive episode numbers.  TMDB season lists only expose an
    episode count; in that case count watched markers within the advertised
    1..N range so stale markers cannot inflate the season progress.
    """
    try:
        season_number = int(season_number)
    except (TypeError, ValueError):
        return 0, 0

    watched_numbers = set()
    for watched_season, watched_episode in watched_set or set():
        try:
            watched_season = int(watched_season)
            watched_episode = int(watched_episode)
        except (TypeError, ValueError):
            continue
        if watched_season == season_number and watched_episode > 0:
            watched_numbers.add(watched_episode)

    if episode_numbers is not None:
        available = set()
        for episode_number in episode_numbers:
            try:
                episode_number = int(episode_number)
            except (TypeError, ValueError):
                continue
            if episode_number > 0:
                available.add(episode_number)
        return len(watched_numbers & available), len(available)

    try:
        total = max(0, int(episode_count or 0))
    except (TypeError, ValueError):
        total = 0
    done = sum(1 for episode_number in watched_numbers
               if episode_number <= total)
    return done, total


def _list_tv_seasons(feed_url, tmdb_id):
    """List seasons of a given show."""
    _replace_builtin_context_items()
    show, _ = _find_show(feed_url, tmdb_id)
    if not show:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Show not found',
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    import json as _json

    meta = tmdb_mod.get_metadata(tmdb_id, 'tvshow') if tmdb_id else {}
    fanart = meta.get('fanart') or FANART
    default_thumb = meta.get('poster') or show.get('thumb') or ICON
    show_title = meta.get('title') or show.get('name') or ''

    # ── Continue Watching — in-progress episodes for this show ───────────
    in_progress = [
        r for r in resume_mod.list_recent(limit=50)
        if str(r.get('tmdb', '')) == str(tmdb_id or '')
        and r.get('content') == 'episode'
    ]
    for r in in_progress[:3]:
        r_season = r.get('season', '')
        r_episode = r.get('episode', '')
        r_pos = r.get('pos', 0)
        r_pct = int((r.get('progress') or 0) * 100)
        r_pos_h = resume_mod.format_offset(r_pos)
        if str(r_season).isdigit() and str(r_episode).isdigit():
            r_se = f'S{int(r_season):02d}E{int(r_episode):02d}'
        else:
            r_se = f'S{r_season}E{r_episode}'
        cw_label = (f'[B][COLOR gold]▶  Continue Watching[/COLOR][/B]'
                    f'  [COLOR grey]{r_se} · {r_pos_h} ({r_pct}%)[/COLOR]')
        cw_li = xbmcgui.ListItem(label=cw_label)
        r_thumb = r.get('poster') or default_thumb
        cw_li.setArt({'icon': r_thumb, 'thumb': r_thumb,
                      'poster': default_thumb, 'fanart': fanart})
        cw_li.setProperty('IsPlayable', 'true')
        try:
            tag = cw_li.getVideoInfoTag()
            tag.setTitle(f'{show_title} — {r_se} (Resume)'.strip())
            tag.setMediaType('episode')
            tag.setResumePoint(float(r_pos), float(r.get('dur', 0) or 0))
        except Exception:
            cw_li.setProperty('ResumeTime', str(int(r_pos)))
            if r.get('dur'):
                cw_li.setProperty('TotalTime', str(int(r['dur'])))
        cw_payload = _json.dumps({
            'title': show_title,
            'tmdb': tmdb_id,
            'content': 'episode',
            'season': r_season,
            'episode': r_episode,
            'imdb': (meta or {}).get('imdb_id', ''),
            'year': meta.get('year'),
            'url': r.get('url', ''),
            'label': r.get('label', ''),
            'poster': default_thumb,
            'fanart': fanart,
        })
        play_url = build_url(action='play_link', payload=cw_payload, resume='1')
        start_url = build_url(action='play_link', payload=cw_payload, prompt='0')
        clear_url = build_url(action='clear_resume', key=r.get('key', ''))
        cw_li.addContextMenuItems([
            ('Play from beginning', f'RunPlugin({start_url})'),
            ('[COLOR red]Remove from Continue Watching[/COLOR]',
             f'RunPlugin({clear_url})'),
        ] + _direct_link_download_ctx_items(cw_payload) + _subtitle_toggle_ctx_items())
        xbmcplugin.addDirectoryItem(_handle(), play_url, cw_li, isFolder=False)

    # ── Next Episode shortcut ─────────────────────────────────────────────
    watched_set = watched_mod.get_local_watched_set(tmdb_id) if tmdb_id else set()
    next_ep = _find_next_episode(show, watched_set)
    if next_ep:
        ne_sno, ne_ep_no, ne_links = next_ep
        ne_se = f'S{ne_sno:02d}E{ne_ep_no:02d}'
        ne_label = f'[B]▶  Next Episode[/B]  [COLOR grey]{ne_se}[/COLOR]'
        ne_li = xbmcgui.ListItem(label=ne_label)
        ne_li.setArt({'icon': default_thumb, 'thumb': default_thumb,
                      'poster': default_thumb, 'fanart': fanart})
        try:
            tag = ne_li.getVideoInfoTag()
            tag.setTitle(f'{show_title} — Next Episode'.strip())
            tag.setMediaType('episode')
        except Exception:
            pass
        ne_payload = _json.dumps({
            'title': show_title,
            'tmdb': tmdb_id,
            'content': 'episode',
            'season': ne_sno,
            'episode': ne_ep_no,
            'links': ne_links,
            'feed': feed_url,
            'return_url': build_url(
                action='tv_episodes', feed=feed_url, tmdb=tmdb_id,
                season=str(ne_sno),
            ),
            'imdb': (meta or {}).get('imdb_id', ''),
            'year': meta.get('year'),
            'poster': default_thumb,
            'fanart': fanart,
        })
        ne_url = build_url(action='show_links', payload=ne_payload)
        _set_ctx(ne_li, _direct_link_download_ctx_items(ne_payload))
        xbmcplugin.addDirectoryItem(_handle(), ne_url, ne_li, isFolder=True)

    for season in show.get('seasons', []):
        sno = season.get('seasonNo')
        if sno is None or sno == '':
            sno = '?'
        # Count watched episodes to show progress in label
        ep_list = season.get('episodes') or []
        done, total = _season_watched_progress(
            watched_set, sno, (ep.get('episode') for ep in ep_list),
        )
        progress = (f'  [COLOR grey]{done}/{total} watched[/COLOR]'
                    if total else '')
        label = f'Season {sno}{progress}'
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': default_thumb, 'thumb': default_thumb,
                   'poster': default_thumb, 'fanart': fanart})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(label)
            tag.setMediaType('season')
        except Exception:
            pass

        season_value = int(sno) if str(sno).isdigit() else sno
        _season_payload_dict = {
            'title': show_title,
            'tmdb': tmdb_id,
            'content': 'tvshow',
            'season': season_value,
        }
        season_pairs = []
        for episode in ep_list:
            try:
                season_pairs.append((season_value, int(episode.get('episode'))))
            except (TypeError, ValueError, AttributeError):
                pass
        season_ctx = _local_season_ctx_items(
            tmdb_id, season_value, show_title, season_pairs)
        ctx = season_ctx + _opensubtitles_ctx_items(
            _json.dumps(_season_payload_dict), tmdb_id, 'tvshow', show_title,
            season=season_value,
        )
        if ctx:
            li.addContextMenuItems(ctx + _subtitle_toggle_ctx_items())

        url = build_url(action='tv_episodes', feed=feed_url,
                        tmdb=tmdb_id, season=str(sno))
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)

    xbmcplugin.setContent(_handle(), 'seasons')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=True)


def _list_tv_episodes(feed_url, tmdb_id, season_no):
    """List episodes of a given season — each episode is a folder showing its
    links (reusing the existing show_links handler)."""
    import json as _json

    _replace_builtin_context_items()

    show, _ = _find_show(feed_url, tmdb_id)
    if not show:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    season = None
    for s in show.get('seasons', []):
        if str(s.get('seasonNo') or '') == str(season_no):
            season = s
            break
    if season is None:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    meta = tmdb_mod.get_metadata(tmdb_id, 'tvshow') if tmdb_id else {}
    show_title = meta.get('title') or show.get('name') or ''
    fanart = meta.get('fanart') or FANART
    default_thumb = meta.get('poster') or show.get('thumb') or ICON

    # Fetch per-episode metadata from TMDB (name, air_date, plot, still, rating)
    ep_meta_list = []
    if tmdb_id and str(season_no).isdigit():
        try:
            ep_meta_list = tmdb_mod.get_tv_episodes(tmdb_id, int(season_no)) or []
        except Exception:
            ep_meta_list = []
    ep_meta_by_no = {e['number']: e for e in ep_meta_list}

    # Watched set for badge and context menu
    watched_set = watched_mod.get_local_watched_set(tmdb_id) if tmdb_id else set()
    return_url = build_url(
        action='tv_episodes', feed=feed_url, tmdb=tmdb_id,
        season=str(season_no),
    )

    for ep in season.get('episodes', []):
        ep_no = ep.get('episode') or '?'
        se_code = (f'S{int(season_no):02d}E{int(ep_no):02d}' if (
            str(season_no).isdigit() and str(ep_no).isdigit()) else f'S{season_no}E{ep_no}')

        # Per-episode metadata from TMDB
        ep_key = int(ep_no) if str(ep_no).isdigit() else ep_no
        ep_info = ep_meta_by_no.get(ep_key, {})
        ep_name = ep_info.get('name', '')
        ep_plot = ep_info.get('overview', '')
        ep_air_date = ep_info.get('air_date', '')
        ep_still = ep_info.get('still', '') or default_thumb
        ep_rating = ep_info.get('rating', 0.0)
        ep_runtime = ep_info.get('runtime', 0)

        # Watched status
        try:
            ep_watched = (int(season_no), int(ep_no)) in watched_set
        except (TypeError, ValueError):
            ep_watched = False

        base_label = f'{se_code}  {ep_name}' if ep_name else se_code
        label = f'{_watched_indicator(ep_watched)}  {base_label}'
        thumb = ep_still or default_thumb

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb,
                   'poster': default_thumb, 'fanart': fanart})
        try:
            tag = li.getVideoInfoTag()
            ep_full_title = f'{show_title} — {ep_name}' if ep_name else f'{show_title} {se_code}'
            tag.setTitle(ep_full_title.strip())
            tag.setMediaType('episode')
            if ep_plot:
                tag.setPlot(ep_plot)
            if ep_air_date:
                tag.setPremiered(ep_air_date)
                try:
                    tag.setFirstAired(ep_air_date)
                except Exception:
                    pass
            if ep_rating:
                tag.setRating(ep_rating)
            if ep_runtime:
                tag.setDuration(ep_runtime)
            if str(season_no).isdigit():
                tag.setSeason(int(season_no))
            if str(ep_no).isdigit():
                tag.setEpisode(int(ep_no))
            tag.setPlaycount(1 if ep_watched else 0)
        except Exception:
            li.setProperty('PlayCount', '1' if ep_watched else '0')

        payload = _json.dumps({
            'title': show_title or show.get('name', ''),
            'tmdb': tmdb_id,
            'content': 'episode',
            'season': int(season_no) if str(season_no).isdigit() else season_no,
            'episode': int(ep_no) if str(ep_no).isdigit() else ep_no,
            'links': ep.get('links') or [],
            'feed': feed_url,
            'return_url': return_url,
            'imdb': (meta or {}).get('imdb_id', ''),
            'year': meta.get('year'),
            'poster': default_thumb,
            'fanart': fanart,
        })
        url = build_url(action='show_links', payload=payload)

        # Context menu — toggle local watched status
        ctx = _local_episode_ctx_items(tmdb_id, season_no, ep_no, show_title)
        ctx.extend(_direct_link_download_ctx_items(payload))

        _ep_payload = {
            'title': show_title or show.get('name', ''),
            'tmdb': tmdb_id,
            'imdb': (meta or {}).get('imdb_id', ''),
            'content': 'episode',
            'season': int(season_no) if str(season_no).isdigit() else season_no,
            'episode': int(ep_no) if str(ep_no).isdigit() else ep_no,
        }
        ctx.extend(_opensubtitles_ctx_items(
            _json.dumps(_ep_payload), tmdb_id, 'episode', show_title,
            season=_ep_payload['season'], episode=_ep_payload['episode']
        ))
        li.addContextMenuItems(ctx + _subtitle_toggle_ctx_items())

        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)

    xbmcplugin.setContent(_handle(), 'episodes')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=True)



# ── Playback ─────────────────────────────────────────────────────────────

def _resume_prompt_choice(title, position):
    """Return True to resume, False to start over, or None when disabled."""
    timeout_seconds = resume_mod.get_resume_prompt_timeout_seconds()
    if timeout_seconds < 0:
        return None
    message = (
        f'Resume {title or "this item"} from '
        f'{resume_mod.format_offset(position)}?'
    )
    try:
        kwargs = {
            'nolabel': 'Start from beginning',
            'yeslabel': 'Continue',
            'defaultt': True,
        }
        if timeout_seconds > 0:
            kwargs['autoclose'] = int(timeout_seconds * 1000)
        return bool(xbmcgui.Dialog().yesno('C.O.S.M.O.S', message, **kwargs))
    except TypeError:
        # Older Kodi builds may not accept the optional keyword arguments.
        return bool(xbmcgui.Dialog().yesno('C.O.S.M.O.S', message))


def _resume_row_for_payload(data):
    """Find a local resume row matching the logical media identity."""
    for row in resume_mod.list_recent(limit=50):
        if (
            str(row.get('tmdb') or '') == str(data.get('tmdb') or '') and
            str(row.get('content') or 'movie') == str(data.get('content') or 'movie') and
            str(row.get('season') or '') == str(data.get('season') or '') and
            str(row.get('episode') or '') == str(data.get('episode') or '')
        ):
            return row
    return None


def _normalise_playback_content(data):
    """Treat season/episode TV payloads as episodes for tracking/autoplay."""
    content = str(data.get('content') or '').strip().lower()
    season = str(data.get('season') or '').strip()
    episode = str(data.get('episode') or '').strip()
    if content in ('tv', 'tvshow', 'series') and season and episode:
        return 'episode'
    return content or 'movie'


def _play_link(payload_json, resume=False, bypass_source=False, prompt=True,
               use_player=False):
    """Play a single link chosen from the movie's link list."""
    import json as _json
    try:
        data = _json.loads(payload_json)
    except ValueError:
        xbmc.log('COSMOS: play_link payload JSON decode failed', xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return

    xbmc.log(
        f'COSMOS [FLOW] play_link  title={data.get("title")!r}'
        f'  content={data.get("content")!r}'
        f'  tmdb={data.get("tmdb")!r}'
        f'  season={data.get("season")!r}  episode={data.get("episode")!r}'
        f'  resume={resume}'
        f'  url={str(data.get("url",""))[:120]!r}',
        xbmc.LOGDEBUG,
    )

    url = (data.get('url') or '').strip()
    if not url:
        _link_zero(payload_json)
        return

    rkey = resume_mod.key_for(
        tmdb=data.get('tmdb'), content=data.get('content'),
        season=data.get('season'), episode=data.get('episode'),
        label=data.get('label', ''), url=url,
    )

    # A normal click can offer the saved position; explicit resume and
    # "start from beginning" context actions bypass this prompt.
    if not resume and prompt:
        info = resume_mod.get(rkey)
        if info:
            choice = _resume_prompt_choice(data.get('title'), info[0])
            if choice is not None:
                resume = choice

 # If "Play from beginning" is chosen, re-run the scraper flow to get a
    # fresh link, instead of re-using a potentially expired direct/debrid URL.
    # This covers magnet links and direct media URLs. Filehoster links will
    # fall through and be re-resolved by filehost.play_direct_link.
    if not resume and not bypass_source:
        _label_lower = data.get('label', '').lower()
        if 'non debrid' not in _label_lower:
            is_direct = filehost._is_direct_media_url(url)
            is_magnet = url.lower().startswith('magnet:')
            if is_direct or is_magnet:
                _link_zero(payload_json)
                return

    seek_to = 0
    if resume:
        info = resume_mod.get(rkey)
        if info:
            seek_to = info[0]
    meta = {
        'title': data.get('title', ''),
        'content': _normalise_playback_content(data),
        'tmdb': str(data.get('tmdb') or ''),
        'season': str(data.get('season') or ''),
        'episode': str(data.get('episode') or ''),
        'label': data.get('label', ''),
        'url': url,
        'poster': data.get('poster', ''),
        'fanart': data.get('fanart', ''),
        'year': str(data.get('year') or ''),
        'imdb': str(data.get('imdb') or ''),
        'source': data.get('source', ''),
        'provider': data.get('provider', ''),
        'slug': data.get('slug', ''),
        'feed': data.get('feed', ''),
        'return_url': data.get('return_url', ''),
        'is_playback': bool(resume_mod.is_nineanime(data)),
    }
    meta['ids'] = dict(data.get('ids')) if isinstance(data.get('ids'), dict) else {}
    for id_key in ('simkl', 'tvdb', 'mal', 'anidb', 'anilist', 'kitsu'):
        meta[id_key] = data.get(id_key) or data.get(id_key + '_id') or ''
    meta['anime_numbering'] = data.get('anime_numbering', '')
    resume_mod.start_tracker(rkey, seek_to=seek_to, meta=meta)

    token = url.lower()
    if token in filehost.SEARCH_TOKENS:
        filehost.play_search_token(
            token,
            title=data.get('title') or '',
            year=str(data.get('year') or ''),
            tmdb_id=str(data.get('tmdb') or ''),
            imdb_id=str(data.get('imdb') or ''),
            content=data.get('content') or 'movie',
            season=data.get('season') or None,
            episode=data.get('episode') or None,
        )
        opensubtitles_mod.auto_apply_for_playback(meta)
        return

    # Handle magnet links from "Continue Watching"
    if url.lower().startswith('magnet:'):
        stream_url, name = debrid.resolve_magnet(url)
        if not stream_url:
            xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Failed to resolve magnet link',
                                          xbmcgui.NOTIFICATION_ERROR, 4000)
            xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
            return
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S',
            f'Playing via {name}',
            xbmcgui.NOTIFICATION_INFO, 2500,
        )
        # Re-use the logic from filehost._play_stream
        if '|' in stream_url:
            url_part, header_part = stream_url.split('|', 1)
            is_hls = '.m3u8' in url_part.lower()
            if is_hls:
                li = xbmcgui.ListItem(path=url_part)
                li.setMimeType('application/vnd.apple.mpegurl')
                li.setContentLookup(False)
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                li.setProperty('inputstream.adaptive.manifest_headers', header_part)
                li.setProperty('inputstream.adaptive.stream_headers', header_part)
            else:
                # For non-HLS, Kodi's player wants the headers in the path
                li = xbmcgui.ListItem(path=stream_url)
                li.setMimeType('video/mp4')
                li.setContentLookup(False)
        else:
            li = xbmcgui.ListItem(path=stream_url)
        if data.get('source') == 'TorrentClaw' and data.get('metadata'):
            from . import torrentclaw
            torrentclaw.apply_metadata(li, data['metadata'])
        li.setProperty('IsPlayable', 'true')
        if use_player:
            xbmc.Player().play(li.getPath(), li)
        else:
            xbmcplugin.setResolvedUrl(_handle(), True, li)
        opensubtitles_mod.auto_apply_for_playback(meta)
        return

    # Direct filehost / http(s) URL. Some non-debrid hosts start playback via
    # xbmc.Player().play(), which may not deliver the resume tracker's
    # onAVStarted callback. Keep the subtitle preference reliable by also
    # starting the guarded automatic subtitle fallback here.
    played = filehost.play_direct_link(
        url, title=data.get('title') or '', use_player=use_player)
    if played:
        opensubtitles_mod.auto_apply_for_playback(meta)

# ── Settings / Debrid auth actions ───────────────────────────────────────

def _open_settings():
    ADDON.openSettings()

def toggle_language_invoker():
    """Read the setting and update reuselanguageinvoker in addon.xml."""
    import xbmcvfs
    import xml.etree.ElementTree as ET
    
    enabled = (ADDON.getSetting('reuse_language_invoker') or 'true').lower() == 'true'
    addon_xml_path = xbmcvfs.translatePath(f'special://home/addons/{ADDON_ID}/addon.xml')
    
    try:
        tree = ET.parse(addon_xml_path)
        root = tree.getroot()
        for ext in root.findall('extension'):
            if ext.get('point') == 'xbmc.python.pluginsource':
                ext.set('reuselanguageinvoker', 'true' if enabled else 'false')
                tree.write(addon_xml_path, encoding='utf-8', xml_declaration=True)
                
                if xbmcgui.Dialog().yesno(
                    'C.O.S.M.O.S',
                    'Language invoker setting updated.\nReload profile now to apply changes?'
                ):
                    xbmc.executebuiltin('ReloadSkin()')
                return
    except Exception as e:
        xbmc.log(f'COSMOS: Failed to update language invoker in addon.xml: {e}', xbmc.LOGERROR)

def _sync_credentials_to_resolveurl():
    """Push credentials using ResolveURL's current host setting IDs."""
    _sync_filehost_logins()

def _auth_aio():
    """Validate AIO Streams login before persisting credentials."""
    from . import auth_dialog as _auth_dialog
    from .scrapers import AIOStreamsScraper
    import os as _os
    icon = _os.path.join(ADDON_PATH, 'resources', 'media', 'icon_aio_streams.png')
    dlg = _auth_dialog.AIOStreamsDialog(
        'AIOStreams.xml',
        ADDON_PATH,
        service_name='AIO Streams',
        icon_path=icon,
        initial_url=(ADDON.getSetting('aio_url') or 'https://aiostreams.fortheweak.cloud'),
    )
    dlg.doModal()
    if dlg.confirmed:
        dlg.username = (dlg.username or '').strip()
        if not dlg.url or not dlg.username or not dlg.password:
            xbmcgui.Dialog().notification(
                'C.O.S.M.O.S', 'AIO Streams requires server URL, UUID/alias and password',
                xbmcgui.NOTIFICATION_WARNING, 4000)
            del dlg
            return
        progress = xbmcgui.DialogProgressBG()
        progress.create('C.O.S.M.O.S', 'Checking AIO Streams login...')
        try:
            valid, message = AIOStreamsScraper.validate_credentials(
                dlg.url, dlg.username, dlg.password)
        except Exception:
            valid, message = False, 'Unable to verify AIO Streams login; try again'
        finally:
            progress.close()
        if not valid:
            xbmcgui.Dialog().notification(
                'C.O.S.M.O.S', message, xbmcgui.NOTIFICATION_WARNING, 6000)
            del dlg
            return
        ADDON.setSetting('aio_url',       AIOStreamsScraper._normalise_url(dlg.url))
        ADDON.setSetting('aio_username',  dlg.username)
        ADDON.setSetting('aio_password',  dlg.password)
        ADDON.setSetting('aio_auth_done', 'true')
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'AIO Streams configured successfully',
            xbmcgui.NOTIFICATION_INFO, 3000)
    del dlg


def _revoke_aio():
    """Clear all stored AIO Streams credentials."""
    ADDON.setSetting('aio_url',       '')
    ADDON.setSetting('aio_username',  '')
    ADDON.setSetting('aio_password',  '')
    ADDON.setSetting('aio_auth_done', 'false')
    xbmcgui.Dialog().notification(
        'C.O.S.M.O.S', 'AIO Streams credentials cleared',
        xbmcgui.NOTIFICATION_INFO, 3000)


def _run_action(action):
    """Map Debrid action queries to the appropriate class method call."""
    # Map action -> (ClassName, method_name)
    mapping = {
        'auth_rd': ('RealDebrid', 'authorize'),
        'revoke_rd': ('RealDebrid', 'revoke'),
        'auth_ad': ('AllDebrid', 'authorize'),
        'revoke_ad': ('AllDebrid', 'revoke'),
        'auth_pm': ('Premiumize', 'authorize'),
        'revoke_pm': ('Premiumize', 'revoke'),
        'auth_tb': ('Torbox', 'authorize'),
        'revoke_tb': ('Torbox', 'revoke'),
        'auth_ls': ('LinkSnappy', 'authorize'),
        'revoke_ls': ('LinkSnappy', 'revoke'),
        'auth_oc': ('Offcloud', 'authorize'),
        'revoke_oc': ('Offcloud', 'revoke'),
    }
    target = mapping.get(action)
    if not target:
        return False
    cls_name, method = target
    cls = getattr(debrid, cls_name, None)
    if not cls:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', f'{cls_name} not supported',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    try:
        instance = cls()
        getattr(instance, method)()
    except Exception as e:
        xbmc.log(f'COSMOS: action {action} failed: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('C.O.S.M.O.S', f'{action} failed',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return False
        
    # Refresh the container instantly after any Debrid auth/revoke action
    xbmc.executebuiltin('Container.Refresh')
    return True


# ── Favourites ───────────────────────────────────────────────────────────

# ── Context-menu helpers ─────────────────────────────────────────────────
# Each helper returns a list of (label, action) tuples.
# _set_ctx() merges them all and calls addContextMenuItems exactly ONCE —
# Kodi replaces custom items on every addContextMenuItems call, so calling
# it multiple times means only the last call's items appear.

def _replace_builtin_context_items():
    """Use only Cosmos context actions for the current plugin directory."""
    try:
        xbmcplugin.setProperty(
            _handle(), 'pluginreplacecontextitems', 'true')
    except Exception as exc:
        xbmc.log(
            f'COSMOS: could not replace built-in context items: {exc}',
            xbmc.LOGWARNING,
        )


def _set_ctx(li, *item_lists, replace_items=False):
    """Flatten *item_lists and apply as a single addContextMenuItems call."""
    if not replace_items:
        try:
            raw_query = sys.argv[2] if len(sys.argv) >= 3 else ''
            query = raw_query[1:] if raw_query.startswith('?') else raw_query
            current_action = dict(
                parse_qsl(query, keep_blank_values=True)).get('action', '')
            replace_items = current_action.startswith('tmdb_')
        except Exception:
            pass
    if replace_items:
        _replace_builtin_context_items()

    ctx = []
    for items in item_lists:
        ctx.extend(items)
    ctx.extend(_subtitle_toggle_ctx_items())
    if ctx:
        li.addContextMenuItems(ctx)


def _is_debrid_source(url, label=''):
    """Return whether a playlist source needs scraper/debrid resolution."""
    source = str(url or '').strip().lower()
    name = str(label or '').strip().lower()
    return (
        'debrid' in name
        or source.startswith('magnet:')
        or source in filehost.SEARCH_TOKENS
    )


def _direct_link_download_ctx_items(payload_json):
    """Return a context action for direct links carried by Enigma items.

    Enigma movie and episode cards keep their native links in the card
    payload, so the card itself has no download URL yet.  A single link can
    be sent straight to the downloader; multiple links open the normal link
    picker, whose individual rows already expose ``Download this link``.
    """
    import json as _json

    try:
        data = _json.loads(payload_json) if isinstance(payload_json, str) else (payload_json or {})
    except Exception:
        return []
    if not isinstance(data, dict):
        return []

    links = data.get('links') or []
    direct_links = []
    for link in links:
        if isinstance(link, dict):
            url = str(link.get('url') or '').strip()
            label = link.get('label') or 'Direct link'
        else:
            url = str(link or '').strip()
            label = 'Direct link'
        if url and not _is_debrid_source(url, label):
            direct_links.append((url, str(label)))

    # Continue Watching entries already contain their resolved direct URL.
    if not direct_links and str(data.get('url') or '').strip():
        current_url = str(data['url']).strip()
        current_label = str(data.get('label') or 'Direct link')
        if not _is_debrid_source(current_url, current_label):
            direct_links.append((current_url, current_label))

    if not direct_links:
        return []

    if len(direct_links) == 1:
        url, label = direct_links[0]
        download_payload = dict(data)
        download_payload['url'] = url
        download_payload['label'] = label
        download_url = build_url(
            action='download_item',
            payload=_json.dumps(download_payload),
        )
        return [('[COLOR cyan]Download direct link[/COLOR]',
                 f'RunPlugin({download_url})')]

    picker_url = build_url(action='show_links', payload=payload_json)
    return [('[COLOR cyan]Choose direct link to download[/COLOR]',
             f'Container.Update({picker_url})')]


def _local_movie_ctx_items(tmdb_id, content, title=''):
    """Return the local watched toggle for TMDB movies."""
    if (content or '').lower() != 'movie' or not tmdb_id:
        return []
    if watched_mod.is_local_movie_watched(tmdb_id):
        url = build_url(action='mark_movie_unwatched', tmdb=str(tmdb_id), name=title)
        text = _L(30018, 'Mark as Unwatched Locally')
        label = f'[COLOR green]{text}[/COLOR]'
    else:
        url = build_url(action='mark_movie_watched', tmdb=str(tmdb_id), name=title)
        text = _L(30017, 'Mark as Watched Locally')
        label = f'[COLOR yellow]{text}[/COLOR]'
    return [(label, f'RunPlugin({url})')]


def _local_tvshow_ctx_items(tmdb_id, title=''):
    """Return reversible bulk watched actions for a TV show card."""
    if not tmdb_id:
        return []
    mark_url = build_url(action='mark_show_watched', tmdb=str(tmdb_id), name=title)
    clear_url = build_url(action='mark_show_unwatched', tmdb=str(tmdb_id), name=title)
    mark_text = _L(30035, 'Mark All Episodes Watched Locally')
    items = [(
        f'[COLOR yellow]{mark_text}[/COLOR]',
        f'RunPlugin({mark_url})',
    )]
    if watched_mod.get_local_watched_set(tmdb_id):
        clear_text = _L(30036, 'Clear Local Watched Episodes')
        items.append((
            f'[COLOR green]{clear_text}[/COLOR]',
            f'RunPlugin({clear_url})',
        ))
    return items


def _local_season_ctx_items(tmdb_id, season, title='', episodes=None):
    """Return reversible watched actions for one season's known episodes."""
    if not tmdb_id or season is None:
        return []
    pairs = list(episodes or [])
    if not pairs:
        return []
    watched = watched_mod.get_local_watched_set(tmdb_id)
    season_pairs = {(int(s), int(e)) for s, e in pairs
                    if str(s).lstrip('-').isdigit() and str(e).isdigit()}
    done = bool(season_pairs) and season_pairs.issubset(watched)
    if done:
        action = 'mark_season_unwatched'
        text = _L(30036, 'Clear Season Watched Status')
        color = 'green'
    else:
        action = 'mark_season_watched'
        text = _L(30035, 'Mark Season Watched Locally')
        color = 'yellow'
    url = build_url(action=action, tmdb=str(tmdb_id), season=str(season),
                    name=title)
    return [(f'[COLOR {color}]{text}[/COLOR]', f'RunPlugin({url})')]


def _local_episode_ctx_items(tmdb_id, season, episode, title=''):
    """Return the local watched toggle for one TV episode."""
    if not tmdb_id or season is None or episode is None:
        return []
    try:
        episode_watched = (int(season), int(episode)) in watched_mod.get_local_watched_set(tmdb_id)
    except (TypeError, ValueError):
        episode_watched = False
    if episode_watched:
        url = build_url(action='mark_unwatched', tmdb=str(tmdb_id),
                        season=str(season), episode=str(episode), name=title)
        text = _L(30018, 'Mark as Unwatched Locally')
        label = f'[COLOR green]{text}[/COLOR]'
    else:
        url = build_url(action='mark_watched', tmdb=str(tmdb_id),
                        season=str(season), episode=str(episode), name=title)
        text = _L(30017, 'Mark as Watched Locally')
        label = f'[COLOR yellow]{text}[/COLOR]'
    return [(label, f'RunPlugin({url})')]


def _local_movie_label(title, tmdb_id, content):
    """Add an empty/checked watched indicator to movie labels."""
    if (content or '').lower() == 'movie' and tmdb_id:
        return f'{_watched_indicator(watched_mod.is_local_movie_watched(tmdb_id))}  {title}'
    return title


def _watched_indicator(watched):
    """Return a font-safe watched box and mark for Kodi skins.

    Some Kodi skins do not contain Unicode ballot-box/checkmark glyphs and
    render each missing glyph as a rectangle. ASCII brackets plus a ``v``
    mark are supported by every Kodi font and keep the mark inside the box.
    """
    if watched:
        return '[COLOR green][v][/COLOR]'
    return '[COLOR grey][ ][/COLOR]'


def _notify_watched_action(operation, ok=True):
    """Show the result of a local watched-status mutation."""
    verb = 'Watched' if operation == 'watched' else 'Unwatched'
    message = f'{verb} locally' if ok else f'{verb} failed'
    icon = xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR
    xbmcgui.Dialog().notification('C.O.S.M.O.S', message, icon, 2500)


def _fav_ctx_items(payload_json, tmdb_id, content, name):
    """Return Favourite context items."""
    safe_name = name or ''
    items = []
    if fav_mod.is_favourite(tmdb_id, content, safe_name):
        rm_url = build_url(action='remove_favourite', tmdb=str(tmdb_id or ''),
                           content=content, name=safe_name)
        items.append((f'[COLOR pink][B]{_L(30013, "Remove from COSMOS Favourites")}[/B][/COLOR]',
                      f'RunPlugin({rm_url})'))
    else:
        add_url = build_url(action='add_favourite', tmdb=str(tmdb_id or ''),
                            content=content, name=safe_name, payload=payload_json)
        items.append((f'[COLOR pink][B]{_L(30012, "Add to COSMOS Favourites")}[/B][/COLOR]',
                      f'RunPlugin({add_url})'))
    return items


def _scrobbler_ctx_items(payload_json, tmdb_id, content, name, season='', episode=''):
    """Return the low-cost Simkl rating action for an item.

    Rating is an explicit user action and does not fetch anything just to
    render the context menu.  Other online-service actions remain disabled
    here because playback tracking is configured as local-only.
    """
    try:
        from . import simkl as _simkl
    except Exception:
        return []
    if not getattr(_simkl, 'has_token', _simkl.is_authorized)():
        return []
    url = build_url(action='simkl_rate', payload=payload_json)
    return [('[COLOR gold]Rate on Simkl[/COLOR]', f'RunPlugin({url})')]


def _info_ctx_items(title, tmdb_id, content, poster, fanart):
    """Return View Info context item."""
    info_url = build_url(
        action='show_info',
        title=(title or '')[:200],
        tmdb=str(tmdb_id or ''),
        content=content or 'movie',
        poster=poster or '',
        fanart=fanart or '',
    )
    return [(f'[COLOR cyan]{_L(30014, "View Info")}[/COLOR]', f'RunPlugin({info_url})')]


def _extras_ctx_items(title, tmdb_id, content, poster, fanart):
    """Return Extras context item (Cast, Recommended, Similar, Reviews,
    Trivia, Blunders, Parental Guide)."""
    extras_url = build_url(
        action='show_extras',
        title=(title or '')[:200],
        tmdb=str(tmdb_id or ''),
        content=content or 'movie',
        poster=poster or '',
        fanart=fanart or '',
    )
    return [(f'[COLOR FF66AAFF]{_L(30015, "Extras")}[/COLOR]', f'RunPlugin({extras_url})')]


def _trailer_ctx_items(tmdb_id, content):
    """Return the shared Wiki Trailers context action."""
    if not tmdb_id:
        return []
    if xbmc.getCondVisibility('System.HasAddon(plugin.video.wikitrailer)'):
        media_type = 'tv' if str(content or '').lower() in ('tv', 'tvshow', 'series', 'show', 'episode') else 'movie'
        trailer_url = (
            'plugin://plugin.video.wikitrailer/?' +
            urlencode({'action': 'play', 'tmdb_id': str(tmdb_id), 'media_type': media_type})
        )
        command = f'PlayMedia({trailer_url})'
    else:
        command = build_url(action='install_wiki_trailers')
        command = f'RunPlugin({command})'
    return [('[B]Watch Trailer[/B]', command)]


def _opensubtitles_ctx_items(payload_json, tmdb_id, content, title,
                              season=None, episode=None, imdb=None):
    """Return 'Download Subtitles' context item for OpenSubtitles."""
    import json as _json
    try:
        data = _json.loads(payload_json) if isinstance(payload_json, str) else (payload_json or {})
    except Exception:
        data = {}
    sub_payload = _json.dumps({
        'title': title or data.get('title', ''),
        'tmdb': tmdb_id or data.get('tmdb', ''),
        'imdb': imdb or data.get('imdb', ''),
        'content': content or data.get('content', 'movie'),
        'season': season if season is not None else data.get('season'),
        'episode': episode if episode is not None else data.get('episode'),
    })
    url = build_url(action='opensubtitles_search', payload=sub_payload)
    return [(f'[COLOR cyan]{_L(30016, "Download Subtitles")}[/COLOR]', f'RunPlugin({url})')]


def _subtitle_toggle_ctx_items():
    """Return the universal context action for automatic subtitles."""
    enabled = (ADDON.getSetting('subtitle_autoload_enabled') or '').strip().lower() == 'true'
    label = ('[COLOR green]Auto Subtitles: ON[/COLOR]'
             if enabled else '[COLOR red]Auto Subtitles: OFF[/COLOR]')
    url = build_url(action='toggle_auto_subtitles')
    return [(label, f'RunPlugin({url})')]


# Legacy shim names kept so any external code that calls the old _attach_*
# functions still works — they now just delegate to _set_ctx + the new helpers.
def _attach_fav_context(li, payload_json, tmdb_id, content, name):
    _set_ctx(li, _fav_ctx_items(payload_json, tmdb_id, content, name))

def _attach_trakt_watchlist_context(li, payload_json, tmdb_id, content, name, season='', episode=''):
    _set_ctx(li, _scrobbler_ctx_items(payload_json, tmdb_id, content, name, season, episode))

def _attach_info_context(li, title, tmdb_id, content, poster, fanart):
    _set_ctx(li, _info_ctx_items(title, tmdb_id, content, poster, fanart))

def _attach_extras_context(li, title, tmdb_id, content, poster, fanart):
    _set_ctx(li, _extras_ctx_items(title, tmdb_id, content, poster, fanart))

def _attach_trailer_context(li, tmdb_id, content):
    _set_ctx(li, _trailer_ctx_items(tmdb_id, content))


def _show_info(title, tmdb_id, content, poster, fanart):
    """Fetch metadata and open the full-screen CosmosInfo dialog."""
    meta = {}
    if tmdb_id:
        meta = tmdb_mod.get_metadata(tmdb_id, content) or {}
    if not meta and title:
        found_id = tmdb_mod.search_by_title(title, content)
        if found_id:
            meta = tmdb_mod.get_metadata(found_id, content) or {}
    if not meta:
        meta = {'title': title, 'poster': poster, 'fanart': fanart}
    info_mod.open_info_dialog(
        meta,
        poster=poster or meta.get('poster', ''),
        fanart=fanart or meta.get('fanart', ''),
    )


def _show_extras(title, tmdb_id, content, poster, fanart):
    """Fetch metadata and open the full-screen CosmosExtras dialog."""
    meta = {}
    effective_tmdb_id = tmdb_id
    if tmdb_id:
        meta = tmdb_mod.get_metadata(tmdb_id, content) or {}
    
    if not meta and title:
        found_id = tmdb_mod.search_by_title(title, content)
        if found_id:
            effective_tmdb_id = found_id
            meta = tmdb_mod.get_metadata(found_id, content) or {}

    if not meta:
        if not effective_tmdb_id:
             xbmcgui.Dialog().notification('C.O.S.M.O.S Extras', 'No TMDB ID available to fetch full metadata.', xbmcgui.NOTIFICATION_WARNING, 2000)
        meta = {'title': title, 'poster': poster, 'fanart': fanart}
    extras_mod.open_extras_dialog(
        meta,
        tmdb_id=effective_tmdb_id or meta.get('tmdb_id', ''),
        content=content,
        poster=poster or meta.get('poster', ''),
        fanart=fanart or meta.get('fanart', ''),
    )


def _add_favourite(payload_json, tmdb_id, content, name):
    import json as _json
    try:
        payload = _json.loads(payload_json) if payload_json else {}
    except ValueError:
        payload = {}
    # Preserve the route used by the original item. TMDB TV favourites do
    # not have a feed URL, so they must return through the TMDB seasons view.
    route = payload.get('favourite_route') or {}
    if not route:
        normalized_content = str(content or payload.get('content') or 'movie').lower()
        if payload.get('feed'):
            # Enigma items belong to a parent menu. Reopen that exact menu so
            # the item appears in its original Cosmos context, with its
            # neighbouring entries and normal navigation intact.
            route = {'action': 'menu', 'feed': payload.get('feed')}
        elif normalized_content in ('tvshow', 'tv', 'series', 'show'):
            if payload.get('feed'):
                route = {'action': 'tv_seasons', 'feed': payload.get('feed')}
            else:
                route = {
                    'action': 'tmdb_tv_seasons',
                    'name': payload.get('title') or name or '',
                    'year': str(payload.get('year') or ''),
                    'imdb': payload.get('imdb') or '',
                    'poster': payload.get('poster') or '',
                    'fanart': payload.get('fanart') or '',
                }
        else:
            # Enigma movies retain their direct links in the payload. Open
            # that link list again, with Link Zero available as fallback.
            route = {'action': 'show_links'}
    # Store TMDB browse arguments in the payload too, which lets old clients
    # and the normal show_links fallback reopen the item with full metadata.
    if route.get('action') == 'tmdb_tv_seasons':
        payload['tmdb'] = str(tmdb_id or payload.get('tmdb') or '')
        for field in ('name', 'year', 'imdb', 'poster', 'fanart'):
            if route.get(field) and not payload.get(field):
                payload[field if field != 'name' else 'title'] = route[field]
    entry = {
        'tmdb': str(tmdb_id or ''),
        'content': content or 'movie',
        'name': name or payload.get('title') or payload.get('name') or 'Untitled',
        'thumb': payload.get('poster') or payload.get('thumb') or '',
        'fanart': payload.get('fanart') or '',
        'payload': payload,   # raw payload dict for reopening
        'route': route,
    }
    fav_mod.add(entry)
    xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Added to Favourites',
                                  xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _remove_favourite(tmdb_id, content, name):
    if fav_mod.remove(tmdb_id, content, name):
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Removed from Favourites',
                                      xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _list_favourites():
    items = fav_mod.load()
    if not items:
        _add_directory('[COLOR grey]No favourites yet. Add some from any item[/COLOR]',
                       build_url(action='favourites_list'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    import json as _json
    for it in items:
        name = it.get('name') or 'Untitled'
        content = it.get('content') or 'movie'
        tmdb_id = it.get('tmdb') or ''
        meta = tmdb_mod.get_metadata(tmdb_id, content) if tmdb_id else {}
        label = meta.get('title') or name
        year = meta.get('year')
        if year:
            label = f'{label} ({year})'
        li = xbmcgui.ListItem(label=label)
        tmdb_mod.apply_to_listitem(li, meta, content)
        thumb = meta.get('poster') or it.get('thumb') or ICON
        fanart = meta.get('fanart') or it.get('fanart') or FANART
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})

        open_url = build_url(action='open_favourite', key=it.get('key', ''))
        rm_url = build_url(action='remove_favourite', tmdb=tmdb_id,
                           content=content, name=name)
        li.addContextMenuItems([
            ('[COLOR pink][B]Remove from COSMOS Favourites[/B][/COLOR]', f'RunPlugin({rm_url})'),
        ] + _local_movie_ctx_items(tmdb_id, content, name) + _subtitle_toggle_ctx_items())
        xbmcplugin.addDirectoryItem(_handle(), open_url, li, isFolder=True)

    xbmcplugin.setContent(_handle(), 'movies')
    xbmcplugin.addSortMethod(_handle(), xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _open_favourite(key, root_feed=''):
    """Render the destination within this directory request.

    Container.Update races with Kodi loading this folder and gets rejected
    as an update already in progress. Each destination owns endOfDirectory.
    """
    import json as _json
    target = next((item for item in fav_mod.load() if item.get('key') == key), None)
    if not target:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Favourite not found',
                                      xbmcgui.NOTIFICATION_WARNING, 2500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    payload = target.get('payload') or {}
    if isinstance(payload, str):
        try:
            payload = _json.loads(payload)
        except ValueError:
            payload = {}
    payload = dict(payload) if isinstance(payload, dict) else {}
    for field, value in (
            ('tmdb', target.get('tmdb')),
            ('title', target.get('name')),
            ('content', target.get('content'))):
        if not payload.get(field) and value:
            payload[field] = value
    route = target.get('route') or {}
    feed = route.get('feed') or payload.get('feed')
    content = str(target.get('content') or payload.get('content') or 'movie').lower()
    if feed:
        payload['feed'] = str(feed).replace('.xmll', '.xml')
        # Open the saved item inline, including records whose old route
        # points at the containing menu. Never redirect a loading folder.
        if content in ('tvshow', 'tv', 'series', 'show'):
            _list_tv_seasons(payload['feed'], payload.get('tmdb') or '')
        else:
            _list_links(_json.dumps(payload))
        return

    if content in ('tvshow', 'tv', 'series', 'show'):
        _tmdb_tv_seasons(
            payload.get('tmdb') or '',
            name=route.get('name') or payload.get('title') or '',
            year=route.get('year') or payload.get('year') or '',
            imdb=route.get('imdb') or payload.get('imdb') or '',
            poster=route.get('poster') or payload.get('poster') or target.get('thumb', ''),
            fanart=route.get('fanart') or payload.get('fanart') or target.get('fanart', ''),
        )
        return

    # Saved movie/episode links and TMDB source searches use their normal
    # handlers directly, without starting a competing directory update.
    if route.get('action') == 'link_zero':
        _link_zero(_json.dumps(payload))
    else:
        _list_links(_json.dumps(payload))

# ── Resume control ───────────────────────────────────────────────────────

def _clear_resume(key):
    if resume_mod.clear(key):
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Resume point cleared',
                                      xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


# ── Universal Search ─────────────────────────────────────────────────────

def _do_search(feed_url):
    """Choose a search source, then present history and search actions.

    We render the results INLINE inside this same plugin invocation (instead
    of trying to redirect via Container.Update, which on some Kodi builds
    races with endOfDirectory(succeeded=False) and appears as a no-op). This
    is the single most reliable pattern for plugin-driven search flows.
    """
    source_options = [
        '[COLOR orange]Search Enigma menus[/COLOR]',
        '[COLOR deepskyblue]Search TMDB[/COLOR]',
        '[COLOR violet]Search both[/COLOR]',
    ]
    source_idx = xbmcgui.Dialog().select(
        'C.O.S.M.O.S - Search Source', source_options,
    )
    if source_idx < 0:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    search_source = ('enigma', 'tmdb', 'both')[source_idx]
    allow_actor_search = search_source in ('tmdb', 'both')

    history = sh_mod.load()
    options = ['[COLOR cyan]Enter a new search...[/COLOR]']
    if allow_actor_search:
        options.append('[COLOR magenta]Search by actor / person (TMDB)...[/COLOR]')
    if history:
        options.append('[COLOR grey]— Recent searches —[/COLOR]')
        options.extend([h.get('q', '') for h in history])
        options.append('[COLOR red]Clear search history[/COLOR]')

    dlg = xbmcgui.Dialog()
    idx = dlg.select('C.O.S.M.O.S - Search', options)
    if idx < 0:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    # "Enter a new search" → keyword search
    if idx == 0:
        kb = xbmc.Keyboard('', 'C.O.S.M.O.S - Search Movies & TV Shows')
        kb.doModal()
        if not kb.isConfirmed():
            xbmcplugin.endOfDirectory(_handle(), succeeded=False)
            return
        query = (kb.getText() or '').strip()
        if not query:
            xbmcplugin.endOfDirectory(_handle(), succeeded=False)
            return
        sh_mod.add(query)
        # Render results inline — no Container.Update redirect.
        _list_search_results(feed_url, query, search_source=search_source)
        return

    # "Search by actor / person"
    actor_index = 1 if allow_actor_search else -1
    if idx == actor_index:
        kb = xbmc.Keyboard('', 'C.O.S.M.O.S - Search Actor / Director (TMDB)')
        kb.doModal()
        if not kb.isConfirmed():
            xbmcplugin.endOfDirectory(_handle(), succeeded=False)
            return
        person_q = (kb.getText() or '').strip()
        if not person_q:
            xbmcplugin.endOfDirectory(_handle(), succeeded=False)
            return
        _actor_search(feed_url, person_q)
        return

    # History header separator row
    hist_offset = 1 + (1 if allow_actor_search else 0)
    if history and idx == hist_offset:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    # Last row = Clear search history
    if history and idx == len(options) - 1:
        if dlg.yesno('C.O.S.M.O.S', 'Clear all saved search history?'):
            sh_mod.clear()
            xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Search history cleared',
                                          xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    # Picked a recent query
    picked_index = idx - (hist_offset + 1)  # skip static rows + header
    if 0 <= picked_index < len(history):
        query = history[picked_index].get('q', '').strip()
        if not query:
            xbmcplugin.endOfDirectory(_handle(), succeeded=False)
            return
        sh_mod.add(query)  # bump to top
        _list_search_results(feed_url, query, search_source=search_source)
        return
    xbmcplugin.endOfDirectory(_handle(), succeeded=False)


def _list_search_results(feed_url, query, page=1, search_source='both'):
    import json as _json

    PAGE_SIZE = 20
    search_source = str(search_source or 'both').lower()
    if search_source not in ('enigma', 'tmdb', 'both'):
        search_source = 'both'
    search_source_label = {
        'enigma': 'Enigma menus',
        'tmdb': 'TMDB',
        'both': 'Enigma menus + TMDB',
    }[search_source]
    use_local = search_source in ('enigma', 'both')
    use_tmdb = search_source in ('tmdb', 'both')
    query_variants = [query]
    try:
        page = max(1, int(page or '1'))
    except (ValueError, TypeError):
        page = 1

    try:
        depth = int(ADDON.getSetting('search_crawl_depth') or '3')
    except ValueError:
        depth = 3
    depth = max(1, min(depth, search_mod.MAX_DEPTH))
    force = (ADDON.getSetting('search_refresh_on_open') or 'false').lower() == 'true'

    dlg = xbmcgui.DialogProgress()
    dlg.create(
        'C.O.S.M.O.S',
        f'Searching {search_source_label} for "{query}"...',
    )
    local_results = []
    tmdb_results = []
    tmdb_total_pages = 0
    tmdb_pages_fetched = 0
    tmdb_has_more = False

    try:
        # Expand natural-language searches once through anonymous AI Horde,
        # then use its title suggestions for every enabled source. The user's
        # original phrase remains included in the search variants.
        if use_local or use_tmdb:
            dlg.update(5, 'Understanding natural-language search...')
            query_variants.extend(openai_search_mod.expand_query(query))
            query_variants = list(dict.fromkeys(
                q.strip() for q in query_variants if q.strip()
            ))

        # --- Step 1: Enigma menu search ---
        if use_local:
            dlg.update(10, 'Preparing Enigma menu index...')
            cached = search_mod._load_cache()
            need_crawl = force or not cached or cached.get('base') != feed_url

            if need_crawl:
                dlg.update(20, 'Indexing Enigma playlists for search...')
                def _cb(count, label):
                    if dlg.iscanceled():
                        raise Exception("Search cancelled")
                    pct = 20 + min(40, int(count * 1.5))
                    dlg.update(pct, f'Indexing playlists... #{count}: {label[:60]}')
                try:
                    index = search_mod.get_index(
                        feed_url, force_refresh=True, progress_cb=_cb,
                        max_depth=depth,
                    )
                except Exception as e:
                    if "Search cancelled" in str(e):
                        dlg.close()
                        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
                        return
                    raise
            else:
                index = cached

            if dlg.iscanceled():
                return
            dlg.update(65, 'Searching Enigma menu items...')
            seen_local = set()
            for variant in query_variants:
                for result in search_mod.search(index, variant):
                    result_key = (
                        result.get('feed', ''),
                        result.get('name', ''),
                        result.get('season', ''),
                        result.get('episode', ''),
                    )
                    if result_key not in seen_local:
                        seen_local.add(result_key)
                        local_results.append(result)

        # --- Step 2: TMDB Search ---
        # Pass query as plain text — _tmdb_fetch runs urlencode() internally,
        # so wrapping with quote_plus() here would double-encode the string.
        if dlg.iscanceled():
            return
        if use_tmdb:
            dlg.update(75, 'Searching TMDB...')
        if use_tmdb and _tmdb_key():
            # Local results use the user's literal phrase. TMDB also gets
            # optional semantic title/theme variants from the AI expander.
            needed_tmdb_items = max(0, page * PAGE_SIZE - len(local_results))
            tmdb_pages_needed = max(
                1,
                (needed_tmdb_items + PAGE_SIZE - 1) // PAGE_SIZE,
            )
            seen_tmdb = set()
            for variant in query_variants:
                for tmdb_page in range(1, min(20, tmdb_pages_needed) + 1):
                    if dlg.iscanceled():
                        return
                    tmdb_data = _tmdb_fetch(
                        'search/multi',
                        {'query': variant, 'page': str(tmdb_page)},
                    )
                    if not tmdb_data:
                        break
                    variant_total_pages = min(
                        20, int(tmdb_data.get('total_pages') or 1),
                    )
                    tmdb_total_pages = max(tmdb_total_pages, variant_total_pages)
                    tmdb_pages_fetched = max(tmdb_pages_fetched, tmdb_page)
                    tmdb_has_more = tmdb_has_more or tmdb_page < variant_total_pages
                    # Do not require poster_path: valid TMDB matches can use
                    # the fallback icon/art path during rendering.
                    for result in tmdb_data.get('results') or []:
                        if result.get('media_type') not in ('movie', 'tv'):
                            continue
                        result_key = (result.get('media_type'), result.get('id'))
                        if result.get('id') and result_key not in seen_tmdb:
                            seen_tmdb.add(result_key)
                            tmdb_results.append(result)

        if dlg.iscanceled():
            return
        dlg.update(90, 'Compiling results...')

    except Exception as e:
        xbmc.log(f'COSMOS: search error: {e}', xbmc.LOGERROR)
        dlg.close()
        xbmcgui.Dialog().notification('C.O.S.M.O.S', f'Search failed: {e}',
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    finally:
        dlg.close()

    # --- Step 3: Combine and Paginate ---
    if not local_results and not tmdb_results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S',
                                      f'No results for "{query}"',
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    
    rendered_tmdb_keys = set()
    all_items = []

    for it in local_results:
        tmdb_id = it.get('tmdb', '')
        if not tmdb_id and use_tmdb:
            # In a combined search, resolve missing IDs so local items can
            # be de-duplicated against the TMDB search results.
            title = parser.strip_bbcode(it.get('name', ''))
            content = it.get('content', 'movie')
            found_id = tmdb_mod.search_by_title(title, content)
            if found_id:
                it['tmdb'] = found_id  # Update item in-place for later use
                tmdb_id = found_id
        if tmdb_id:
            media_key = 'tv' if it.get('content') in ('tvshow', 'tv', 'episode') else 'movie'
            rendered_tmdb_keys.add((media_key, str(tmdb_id)))
        all_items.append({'type': 'local', 'data': it})

    for r in tmdb_results:
        tmdb_id = str(r.get('id') or '')
        media_key = str(r.get('media_type') or '')
        key = (media_key, tmdb_id)
        if tmdb_id and key not in rendered_tmdb_keys:
            rendered_tmdb_keys.add(key)
            all_items.append({'type': 'tmdb', 'data': r})

    start_index = (page - 1) * PAGE_SIZE
    end_index = start_index + PAGE_SIZE
    items_to_render = all_items[start_index:end_index]
    has_next = (
        end_index < len(all_items)
        or tmdb_has_more
    )

    # --- Step 4: Render page ---
    for item in items_to_render:
        if item['type'] == 'local':
            it = item['data']

            tmdb_id = it.get('tmdb', '')
            content = it.get('content', 'movie')
            meta = tmdb_mod.get_metadata(tmdb_id, content) if tmdb_id else {}

            name = parser.strip_bbcode(it.get('name', '')) or 'Untitled'
            year = (meta.get('year') or parser.extract_year(it.get('name', '')))
            title = meta.get('title') or name
            label = f'{title} ({year})' if year else title
            label = _local_movie_label(label, tmdb_id, content)
            # Append origin path (from feed hierarchy) as hint
            if it.get('path'):
                label = f'{label}  [COLOR grey]· {it["path"][:40]}[/COLOR]'

            if content == 'tvshow':
                li = xbmcgui.ListItem(label=label)
                tmdb_mod.apply_to_listitem(li, meta, 'tvshow')
                thumb = meta.get('poster') or it.get('thumb') or ICON
                fanart = meta.get('fanart') or FANART
                li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})
                
                # Keep Enigma results on the original feed so the native
                # season/episode menus and every direct/non-debrid link are
                # preserved. TMDB results use the TMDB browser below.
                imdb_id = (meta or {}).get('imdb_id', '')
                url = build_url(
                    action='tv_seasons',
                    feed=it.get('feed') or feed_url,
                    tmdb=tmdb_id,
                )
                
                tv_payload = _json.dumps({
                    'title': title, 'tmdb': tmdb_id, 'content': 'tvshow',
                    'imdb': imdb_id, 'year': str(year or ''),
                    'poster': thumb, 'fanart': fanart,
                })
                _set_ctx(li,
                         _fav_ctx_items(tv_payload, tmdb_id, 'tvshow', title),
                         _scrobbler_ctx_items(tv_payload, tmdb_id, 'tvshow', title),
                         _extras_ctx_items(title, tmdb_id, 'tvshow', thumb, fanart),
                         _trailer_ctx_items(tmdb_id, 'tvshow'),
                         _local_tvshow_ctx_items(tmdb_id, title),
                         _opensubtitles_ctx_items(tv_payload, tmdb_id, 'tvshow', title))
                xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)
            else:
                li = xbmcgui.ListItem(label=label)
                tmdb_mod.apply_to_listitem(li, meta, content)
                thumb = meta.get('poster') or it.get('thumb') or ICON
                fanart = meta.get('fanart') or FANART
                li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})

                # Relabel links with [Direct]/[Debrid] tag
                tagged_links = [
                    {'label': search_mod._label_for_link(lk.get('label'), lk.get('url')),
                     'url': lk.get('url', '')}
                    for lk in (it.get('links') or [])
                ]

                payload = _json.dumps({
                    'title': title,
                    'tmdb': tmdb_id,
                    'content': content,
                    'season': it.get('season'),
                    'episode': it.get('episode'),
                    'links': tagged_links,
                    'imdb': (meta or {}).get('imdb_id', ''),
                    'year': year or 0,
                    'poster': thumb,
                    'fanart': fanart,
                })
                url = build_url(action='show_links', payload=payload)
                _set_ctx(li,
                         _fav_ctx_items(payload, tmdb_id, content, title),
                         _scrobbler_ctx_items(payload, tmdb_id, content, title),
                         _extras_ctx_items(title, tmdb_id, content, thumb, fanart),
                         _trailer_ctx_items(tmdb_id, content),
                         _local_movie_ctx_items(tmdb_id, content, title),
                         _opensubtitles_ctx_items(payload, tmdb_id, content, title))
                xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)

        elif item['type'] == 'tmdb':
            r = item['data']
            tmdb_id = str(r.get('id') or '')

            is_tv = r.get('media_type') == 'tv'
            norm_content = 'tvshow' if is_tv else 'movie'

            meta = tmdb_mod.get_metadata(tmdb_id, norm_content) if tmdb_id else {}

            name = (meta.get('title') or r.get('title') or r.get('name') or 'Untitled')
            year = (meta.get('year')
                        or (r.get('release_date') or r.get('first_air_date') or '')[:4]
                        or '')
            label = f'{name} ({year})' if year else name
            label = f'{label}  [COLOR deepskyblue][TMDB][/COLOR]'

            poster_path = r.get('poster_path') or ''
            backdrop_path = r.get('backdrop_path') or ''
            raw_thumb = f'https://image.tmdb.org/t/p/w500{poster_path}' if poster_path else ICON
            raw_fan   = f'https://image.tmdb.org/t/p/original{backdrop_path}' if backdrop_path else FANART
            thumb = meta.get('poster') or raw_thumb
            fan   = meta.get('fanart') or raw_fan

            li = xbmcgui.ListItem(label=label)
            tmdb_mod.apply_to_listitem(li, meta, norm_content)
            li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fan})

            imdb_id = (meta or {}).get('imdb_id', '')

            if is_tv:
                url = build_url(
                    action='tmdb_tv_seasons',
                    tmdb=tmdb_id, name=name, year=str(year or ''),
                    imdb=imdb_id, poster=thumb, fanart=fan,
                )
                is_folder = True
                li.setProperty('IsPlayable', 'false')
                fav_payload = _json.dumps({
                    'title': name, 'tmdb': tmdb_id, 'content': norm_content,
                    'imdb': imdb_id, 'year': year or '',
                    'poster': thumb, 'fanart': fan,
                })
                _set_ctx(li,
                         _fav_ctx_items(fav_payload, tmdb_id, norm_content, name),
                         _info_ctx_items(name, tmdb_id, norm_content, thumb, fan),
                         _scrobbler_ctx_items(fav_payload, tmdb_id, norm_content, name),
                         _extras_ctx_items(name, tmdb_id, norm_content, thumb, fan),
                         _trailer_ctx_items(tmdb_id, norm_content),
                         _local_tvshow_ctx_items(tmdb_id, name),
                         _opensubtitles_ctx_items(fav_payload, tmdb_id, norm_content, name))
            else: # Movie
                lz_payload = _json.dumps({
                    'title': name, 'tmdb': tmdb_id, 'content': 'movie',
                    'season': None, 'episode': None, 'imdb': imdb_id,
                    'year': year or '', 'poster': thumb, 'fanart': fan,
                })
                url = build_url(action='link_zero', payload=lz_payload)
                is_folder = False
                li.setProperty('IsPlayable', 'true')
                _set_ctx(li,
                         _fav_ctx_items(lz_payload, tmdb_id, norm_content, name),
                         _info_ctx_items(name, tmdb_id, norm_content, thumb, fan),
                         _scrobbler_ctx_items(lz_payload, tmdb_id, norm_content, name),
                         _extras_ctx_items(name, tmdb_id, norm_content, thumb, fan),
                         _trailer_ctx_items(tmdb_id, norm_content),
                         _local_movie_ctx_items(tmdb_id, norm_content, name),
                         _opensubtitles_ctx_items(lz_payload, tmdb_id, norm_content, name))

            xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=is_folder)

    # --- Step 5: Add Next Page item ---
    if has_next:
        next_page_params = {
            'action': 'search_results',
            'feed': feed_url,
            'query': query,
            'search_source': search_source,
            'page': str(page + 1)
        }
        li = xbmcgui.ListItem(f'[B]Next Page ({page + 1}) »[/B]')
        xbmcplugin.addDirectoryItem(_handle(), build_url(**next_page_params), li, isFolder=True)

    xbmcplugin.setContent(_handle(), 'movies')
    xbmcplugin.addSortMethod(_handle(), xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)

# ── Downloads ────────────────────────────────────────────────────────────

def _download_item(payload_json):
    import json as _json
    try:
        data = _json.loads(payload_json)
    except (TypeError, ValueError):
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Invalid download payload',
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    url = data.get('url') if isinstance(data, dict) else None
    if not isinstance(data, dict) or not isinstance(url, str) or not url.strip():
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Invalid download payload',
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    title = parser.strip_bbcode(str(data.get('title') or 'download'))
    content = str(data.get('content') or 'movie').strip().lower()
    if content not in ('movie', 'episode', 'tvshow'):
        content = 'movie'
    label = parser.strip_bbcode(str(data.get('label') or ''))
    downloader.download(
        url=url.strip(),
        title=title,
        content=content,
        season=data.get('season'),
        episode=data.get('episode'),
        imdb_id=str(data.get('imdb') or ''),
        tmdb_id=str(data.get('tmdb') or ''),
        year=str(data.get('year') or ''),
        label=label,
    )


def _list_downloads():
    active = downloader.list_active()
    items = downloader.list_downloads()
    interrupted = downloader.list_interrupted()
    if not active and not items and not interrupted:
        _add_directory('[COLOR grey]No downloads yet[/COLOR]',
                       build_url(action='downloads_list'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    # In-progress jobs header + rows
    for aj in active:
        pct = aj.get('pct', 0) or 0
        title = aj.get('title') or 'Downloading'
        lbl = aj.get('label') or ''
        line = f'[COLOR yellow][In Progress {pct}%][/COLOR] {title}'
        if lbl:
            line = f'{line} — {lbl}'
        li = xbmcgui.ListItem(label=line)
        li.setArt({'icon': ICON, 'thumb': ICON, 'fanart': FANART})
        _add_directory(line, build_url(action='downloads_list'), is_folder=False)

    # Interrupted (.part) rows
    def _fmt_size(n):
        if not n:
            return '0 B'
        step = 1024.0
        for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
            if n < step:
                return f'{n:.1f} {unit}'
            n /= step
        return f'{n:.1f} PB'

    for itp in interrupted:
        line = (f'[COLOR orange][Paused][/COLOR] {itp.get("title", "download")}'
                f'  · {_fmt_size(itp.get("bytes", 0))} on disk')
        li = xbmcgui.ListItem(label=line)
        li.setArt({'icon': ICON, 'thumb': ICON, 'fanart': FANART})
        resume_url = build_url(action='resume_interrupted',
                               part_path=itp.get('part_path', ''))
        delete_url = build_url(action='delete_interrupted',
                               part_path=itp.get('part_path', ''))
        li.addContextMenuItems([
            ('[COLOR red]Delete partial file[/COLOR]', f'RunPlugin({delete_url})'),
        ] + _subtitle_toggle_ctx_items())
        xbmcplugin.addDirectoryItem(_handle(), resume_url, li, isFolder=False)

    import os as _os
    for it in items:
        path = it.get('path') or ''
        if not path:
            continue
        label = it.get('title') or _os.path.basename(path)
        if it.get('label'):
            label = f'{label} - {parser.strip_bbcode(it["label"])}'
        if it.get('content') in ('episode', 'tvshow') and it.get('season') and it.get('episode'):
            try:
                label = f'{label} S{int(it["season"]):02d}E{int(it["episode"]):02d}'
            except (TypeError, ValueError):
                pass

        # Local resume decoration — show offset badge when applicable
        rkey = resume_mod.key_for_local(path)
        rinfo = resume_mod.get(rkey)
        if rinfo:
            label = f'{label}  [COLOR gold]{resume_mod.format_offset(rinfo[0])}[/COLOR]'

        li = xbmcgui.ListItem(label=label)
        thumb = ICON
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': FANART})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(label)
            tag.setMediaType('movie' if it.get('content') == 'movie' else 'episode')
            if rinfo:
                tag.setResumePoint(float(rinfo[0]), float(rinfo[1] or 0))
        except Exception:
            if rinfo:
                li.setProperty('ResumeTime', str(int(rinfo[0])))
                if rinfo[1]:
                    li.setProperty('TotalTime', str(int(rinfo[1])))
        li.setProperty('IsPlayable', 'true')

        # Route playback through our plugin so local files also get
        # resume-tracking + Continue Watching integration.
        play_url = build_url(action='play_local', path=path)
        resume_url = build_url(action='play_local', path=path, resume='1')
        delete_url = build_url(action='delete_local', path=path)
        clear_url = build_url(action='clear_local_resume', path=path)

        ctx = []
        if rinfo:
            ctx.append((f'[COLOR gold]Continue from {resume_mod.format_offset(rinfo[0])}[/COLOR]',
                        f'RunPlugin({resume_url})'))
            ctx.append(('Play from beginning', f'RunPlugin({play_url})'))
            ctx.append(('Clear resume point', f'RunPlugin({clear_url})'))
        ctx.append(('[COLOR red]Delete file[/COLOR]', f'RunPlugin({delete_url})'))
        li.addContextMenuItems(ctx + _subtitle_toggle_ctx_items())

        # Default click uses resume when present, else plays from start
        default_url = resume_url if rinfo else play_url
        xbmcplugin.addDirectoryItem(_handle(), default_url, li, isFolder=False)

    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _resume_interrupted_download(part_path):
    """Resume a paused .part file by re-running the downloader with the
    original source URL / metadata saved in the companion sidecar JSON.
    Because the downloader's ``_Download._open_connection`` detects an
    existing ``.part`` file and issues a ``Range: bytes=N-`` request, the
    already-on-disk bytes are reused transparently."""
    import os as _os
    if not part_path or not part_path.endswith('.part') or not _os.path.isfile(part_path):
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Partial file not found',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        return

    sidecar = downloader._read_sidecar(part_path)
    source_url = sidecar.get('url') if sidecar else None
    if not isinstance(source_url, str) or not source_url.strip():
        # Older .part file from before sidecars existed — fall back to the
        # legacy instruction message so the user can re-trigger manually.
        xbmcgui.Dialog().ok(
            'C.O.S.M.O.S',
            'No resume metadata was stored for this paused download '
            '(created before v2.0.3).\n\nOpen the original item and pick the '
            'same source again — bytes already on disk will be reused via '
            'HTTP Range.\n\nPartial file kept at:\n' + part_path,
        )
        return

    title = sidecar.get('title')
    if not isinstance(title, str) or not title.strip():
        title = 'download'
    content = sidecar.get('content')
    if content not in ('movie', 'episode', 'tvshow'):
        content = 'movie'
    label = sidecar.get('label')
    if not isinstance(label, str):
        label = str(label or '')
    xbmcgui.Dialog().notification(
        'C.O.S.M.O.S',
        f'Resuming: {title}',
        xbmcgui.NOTIFICATION_INFO, 2500,
    )
    downloader.download(
        url=source_url.strip(),
        title=title,
        content=content,
        season=sidecar.get('season'),
        episode=sidecar.get('episode'),
        imdb_id=sidecar.get('imdb_id', ''),
        tmdb_id=sidecar.get('tmdb_id', ''),
        year=sidecar.get('year', ''),
        label=label,
    )
    xbmc.executebuiltin('Container.Refresh')


def _delete_interrupted_part(part_path):
    confirm = xbmcgui.Dialog().yesno(
        'C.O.S.M.O.S', 'Delete this paused .part file?\n' + (part_path or ''),
    )
    if not confirm:
        return
    if downloader.delete_interrupted(part_path):
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Partial file deleted',
                                      xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')


def _play_local(path, resume=False):
    """Play a locally downloaded file with resume-tracking.

    Maintains a per-file resume key so the same local file can be
    picked up where it was last stopped from the Continue Watching row
    or the Downloads menu.
    """
    path = str(path or '').strip()
    if not path:
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return

    import os as _os
    # Resolve display meta from the downloads index
    meta_row = next((it for it in downloader.list_downloads()
                     if it.get('path') == path), {}) or {}
    if not meta_row or not xbmcvfs.exists(path):
        resume_mod.clear(resume_mod.key_for_local(path))
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'Downloaded file is no longer available',
            xbmcgui.NOTIFICATION_WARNING, 2500
        )
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return
    title = meta_row.get('title') or _os.path.splitext(_os.path.basename(path))[0]
    content = meta_row.get('content') or 'movie'
    # Downloads created by older menu payloads can label an episode as
    # ``tvshow``. Normalize it before starting the tracker so local resume,
    # completion thresholds, and watched indicators all use episode keys.
    content = _normalise_playback_content({
        'content': content,
        'season': meta_row.get('season'),
        'episode': meta_row.get('episode'),
    })

    rkey = resume_mod.key_for_local(path)
    seek_to = 0
    if resume:
        info = resume_mod.get(rkey)
        if info:
            seek_to = info[0]

    meta = {
        'title': title,
        'content': content,
        'tmdb': str(meta_row.get('tmdb') or ''),
        'season': str(meta_row.get('season') or ''),
        'episode': str(meta_row.get('episode') or ''),
        'label': meta_row.get('label') or '',
        'url': path,
        'poster': meta_row.get('poster') or '',
        'fanart': meta_row.get('fanart') or '',
        'year': str(meta_row.get('year') or ''),
        'imdb': str(meta_row.get('imdb') or ''),
    }
    resume_mod.start_tracker(rkey, seek_to=seek_to, meta=meta)

    li = xbmcgui.ListItem(path=path)
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        tag.setMediaType('episode' if content == 'episode' else 'movie')
        if seek_to > 0:
            tag.setResumePoint(float(seek_to), 0.0)
    except Exception:
        if seek_to > 0:
            li.setProperty('ResumeTime', str(int(seek_to)))
    xbmcplugin.setResolvedUrl(_handle(), True, li)


def _clear_local_resume(path):
    if not path:
        return
    rkey = resume_mod.key_for_local(path)
    if resume_mod.clear(rkey):
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Resume point cleared',
                                      xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _delete_local(path):
    path = str(path or '').strip()
    if not path:
        return
    import os as _os
    confirm = xbmcgui.Dialog().yesno(
        'C.O.S.M.O.S', f'Delete this downloaded file?\n{_os.path.basename(path)}'
    )
    if not confirm:
        return
    removed = downloader.remove_download(path, delete_file=True)
    if removed and not xbmcvfs.exists(path):
        resume_mod.clear(resume_mod.key_for_local(path))
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'File deleted',
                                      xbmcgui.NOTIFICATION_INFO, 2500)
    else:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Could not delete file',
                                      xbmcgui.NOTIFICATION_ERROR, 2500)
    xbmc.executebuiltin('Container.Refresh')


# ── Clear Cache ──────────────────────────────────────────────────────────

def _do_clear_cache(is_auto=False):
    """Clear the addon's own caches and Kodi texture / thumbnail cache.

    is_auto: if True, runs silently without user confirmation or notifications on failure.
    """
    if not is_auto:
        confirm = xbmcgui.Dialog().yesno(
            'C.O.S.M.O.S',
            'Clear Enigma menu, addon and Kodi thumbnail caches?\n'
            'This will not delete your downloaded files.'
        )
        if not confirm:
            return

    addon_removed = 0
    tex_removed = 0
    errors = []

    # 1) Addon search / parser cache files in profile dir
    import os as _os
    profile_dir = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
    _keep = {
        # Core user data
        'downloads.json', 'favourites.json', 'resume.json', 'watched.json',
        'search_history.json', 'active_downloads.json',
        # Debrid & service tokens
        'rd_token.json', 'ad_token.json', 'pm_token.json', 'tb_token.json',
        'ls_token.json', 'oc_token.json', 'oc_cloud_items.json',
        'simkl_token.json', 'trakt_token.json',
        # State files
        'seen_items.json', 'na_state.json',
        # Reports
        'deadlink_report.txt', 'deadlink_report.json',
    }
    try:
        if _os.path.isdir(profile_dir):
            for fname in _os.listdir(profile_dir):
                # Preserve known credentials and any future credential-like
                # file even if a new service is added without updating this
                # cache routine first.
                if (fname in _keep or re.search(
                        r'(token|auth|credential|secret|password|apikey|api[_-]?key)',
                        fname, re.IGNORECASE)):
                    continue
                fp = _os.path.join(profile_dir, fname)
                if _os.path.isfile(fp) and (fname.endswith('.json') or fname.endswith('.cache')) and not fname.endswith('.part.json'):
                    try:
                        _os.remove(fp)
                        addon_removed += 1
                    except OSError as _e:
                        errors.append(f'{fname}: {_e}')
    except OSError as _e:
        errors.append(f'profile dir: {_e}')

    # Clear only disposable menu-feed copies, preserving user profile data.
    try:
        menu_removed, menu_errors = parser.clear_cached_feeds()
        addon_removed += menu_removed
        errors.extend(f'menu cache: {error}' for error in menu_errors)
    except OSError as _e:
        errors.append(f'menu cache: {_e}')

    # 2) Kodi Textures13.db + Thumbnails folder (via JSON-RPC + VFS)
    if not is_auto or (ADDON.getSetting('auto_clear_texture_cache') or 'true').lower() == 'true':
        try:
            import json as _json
            rpc = {
                'jsonrpc': '2.0',
                'method': 'Textures.GetTextures',
                'params': {'properties': ['url']},
                'id': 1,
            }
            resp = xbmc.executeJSONRPC(_json.dumps(rpc))
            data = _json.loads(resp)
            textures = (data.get('result') or {}).get('textures') or []
            for t in textures:
                tid = t.get('textureid')
                if tid is None:
                    continue
                rm = {
                    'jsonrpc': '2.0', 'method': 'Textures.RemoveTexture',
                    'params': {'textureid': tid}, 'id': 2,
                }
                xbmc.executeJSONRPC(_json.dumps(rm))
                tex_removed += 1
        except Exception as e:
            errors.append(f'thumbnails: {e}')
            xbmc.log(f'COSMOS: texture clear failed: {e}', xbmc.LOGWARNING)

    # 3) Kodi packages / temp
    try:
        xbmcvfs.rmdir('special://temp/archive_cache/', force=True)
    except Exception as e:
        errors.append(f'temp: {e}')

    # 4) Clear the short-lived provider page caches.
    try:
        manyxxx_mod.clear_cache()
        hqpornxxx_mod.clear_cache()
        from . import tubi as _tubi_cache, pluto as _pluto_cache, plex as _plex_cache
        _tubi_cache.clear_cache()
        _pluto_cache.clear_cache()
        _plex_cache.clear_cache()
    except Exception as e:
        errors.append(f'provider caches: {e}')

    # Final, explicit notification
    if not is_auto:
        if errors and not addon_removed and not tex_removed:
            xbmcgui.Dialog().notification(
                'C.O.S.M.O.S',
                f'Clear cache failed: {errors[0]}',
                xbmcgui.NOTIFICATION_ERROR, 5000,
            )
        elif errors:
            xbmcgui.Dialog().notification(
                'C.O.S.M.O.S',
                f'Cleared {addon_removed} files + {tex_removed} thumbs '
                f'({len(errors)} warnings)',
                xbmcgui.NOTIFICATION_WARNING, 4500,
            )
        else:
            xbmcgui.Dialog().notification(
                'C.O.S.M.O.S',
                f'Cache cleared • {addon_removed} files + {tex_removed} thumbs',
                xbmcgui.NOTIFICATION_INFO, 3500,
            )
    elif not errors and (addon_removed > 0 or tex_removed > 0):
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S',
            f'Auto-cleared cache: {addon_removed} files + {tex_removed} thumbs',
            xbmcgui.NOTIFICATION_INFO, 3500,
        )

    xbmc.log(
        f'COSMOS: cache cleared (auto={is_auto}) addon={addon_removed} tex={tex_removed} '
        f'errors={errors}', xbmc.LOGINFO,
    )

def _clear_cache():
    """Clear the addon's own caches and Kodi texture / thumbnail cache."""
    _do_clear_cache(is_auto=False)


def _show_detected_regions():
    from . import plex as _plex
    from . import tubi as _tubi
    try:
        language = xbmc.getLanguage(xbmc.ISO_639_1, True) or ''
        country = language.rsplit('-', 1)[-1].upper() if '-' in language else 'UNKNOWN'
    except Exception:
        country = 'unknown'
    xbmcgui.Dialog().ok('Detected Provider Regions',
                        'Kodi country: %s\n\nTubi: %s\nPlex: %s' %
                        (country, _tubi._region(), _plex._locale()))


def _test_inputstream():
    installed = xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')
    xbmcgui.Dialog().ok('InputStream Adaptive',
                        'InputStream Adaptive is enabled.' if installed else
                        'InputStream Adaptive is not enabled.')


def _clear_provider_caches():
    _do_clear_cache(is_auto=False)


def _clear_downloads_index():
    confirm = xbmcgui.Dialog().yesno(
        'C.O.S.M.O.S',
        'Clear downloads index?\nThis removes entries from the Downloads menu '
        'but does NOT delete the actual files on disk.'
    )
    if not confirm:
        return
    downloader._save_index([])
    xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Downloads index cleared',
                                  xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')


def _sync_filehost_logins():
    """Manually retry the same credential sync used by settings and playback."""
    from .filehost_credentials import sync_credentials
    updated, failed = sync_credentials()
    if (ADDON.getSetting('uploady_api_key') or '').strip():
        updated.append('Uploady')
    if updated:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', f'Synced: {", ".join(updated)}',
            xbmcgui.NOTIFICATION_INFO, 3000)
    if failed:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', f'Failed to sync: {", ".join(failed)}. Check ResolveURL is installed and enabled.',
            xbmcgui.NOTIFICATION_ERROR, 5000)

# ── Continue Watching ────────────────────────────────────────────────────

def _cw_number(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError, OverflowError):
        return default


def _cw_timestamp(value, fallback=0):
    """Convert common service timestamps to a sortable Unix timestamp."""
    if isinstance(value, (int, float)):
        return int(value)
    value = str(value or '').strip()
    if not value:
        return int(fallback or 0)
    try:
        return int(float(value))
    except (TypeError, ValueError):
        pass
    try:
        from datetime import datetime
        return int(datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp())
    except (TypeError, ValueError, OverflowError):
        return int(fallback or 0)


def _cw_progress(value):
    """Normalize service progress to the 0..1 range used by Cosmos."""
    progress = _cw_number(value)
    if progress > 1:
        progress /= 100.0
    return max(0.0, min(1.0, progress))


def _cw_episode_value(value, *keys):
    if isinstance(value, dict):
        for key in keys:
            candidate = value.get(key)
            if candidate is not None and str(candidate).strip() != '':
                return candidate
    return None


def _cw_remote_row(service, item):
    """Map a Trakt/Simkl item to the Cosmos CW row shape."""
    if not isinstance(item, dict):
        return None

    source = service.lower()
    data = item
    if source == 'simkl':
        media = item.get('movie') or item.get('show') or item.get('anime') or {}
        episode = item.get('episode') or {}
        is_movie = bool(item.get('movie'))
        content = 'movie' if is_movie else ('episode' if episode else 'tvshow')
        ids = media.get('ids') or {}
        title = media.get('title') or media.get('name') or 'Untitled'
        year = media.get('year') or ''
        poster = media.get('poster') or media.get('poster_url') or ''
        fanart = media.get('fanart') or media.get('fanart_url') or ''
    elif source == 'trakt':
        media = item.get('movie') or item.get('show') or {}
        episode = item.get('episode') or {}
        is_movie = bool(item.get('movie'))
        content = 'movie' if is_movie else ('episode' if episode else 'tvshow')
        ids = media.get('ids') or {}
        title = media.get('title') or media.get('name') or 'Untitled'
        year = media.get('year') or ''
        poster = media.get('images', {}).get('poster', [])[0] if isinstance(media.get('images'), dict) and media.get('images', {}).get('poster') else ''
        fanart = media.get('images', {}).get('fanart', [])[0] if isinstance(media.get('images'), dict) and media.get('images', {}).get('fanart') else ''
    else:
        return None

    tmdb = (
        ids.get('tmdb') or ids.get('tmdb_id') or ids.get('tmdbId') or
        item.get('tmdb_id') or item.get('tmdbId') or item.get('tmdb') or
        data.get('tmdb_id') or data.get('tmdbId') or data.get('tmdb')
    )
    imdb = (
        ids.get('imdb') or ids.get('imdb_id') or ids.get('imdbId') or
        item.get('imdb_id') or item.get('imdbId') or item.get('imdb') or
        data.get('imdb_id') or data.get('imdbId') or data.get('imdb')
    )
    season = _cw_episode_value(episode, 'season', 'season_number', 'seasonNumber')
    episode_no = _cw_episode_value(
        episode, 'number', 'episode', 'episode_number', 'episodeNumber')
    if season is None:
        season = _cw_episode_value(data, 'season', 'season_number', 'seasonNumber')
    if episode_no is None:
        episode_no = _cw_episode_value(
            data, 'episode', 'episode_number', 'episodeNumber')

    if not tmdb and not imdb:
        return None
    if content == 'tvshow' and season is not None and episode_no is not None:
        content = 'episode'

    duration = _cw_number(
        item.get('duration_seconds') or item.get('duration') or
        item.get('durationSeconds') or data.get('duration_seconds') or
        data.get('durationSeconds') or data.get('duration')
    )
    progress = _cw_progress(
        item.get('progress') if item.get('progress') is not None else
        item.get('progressPercent') if item.get('progressPercent') is not None else
        data.get('progress') if data.get('progress') is not None else
        data.get('progressPercent')
    )
    position = _cw_number(
        item.get('position_seconds') or item.get('position') or
        item.get('progress_seconds') or item.get('progressSeconds') or
        data.get('position_seconds') or data.get('position') or
        data.get('progress_seconds') or data.get('progressSeconds')
    )
    if position <= 0 and duration > 0 and progress > 0:
        position = duration * progress

    timestamp = _cw_timestamp(
        item.get('last_watched_at') or item.get('watchedAt') or
        item.get('updated_at') or item.get('paused_at') or
        data.get('last_watched_at') or data.get('updated_at'),
        fallback=0,
    )
    source_label = {
        'trakt': 'Trakt',
        'simkl': 'Simkl',
    }.get(source, service)
    return {
        'source': source_label,
        'sources': [source_label],
        'is_next_episode': bool(item.get('is_next_episode')),
        'ts': timestamp,
        'title': title,
        'tmdb': str(tmdb or ''),
        'imdb': str(imdb or ''),
        'content': content,
        'season': season if season is not None else '',
        'episode': episode_no if episode_no is not None else '',
        'poster': poster,
        'fanart': fanart,
        'year': year,
        'progress': progress,
        'pos': position,
        'dur': duration,
        'url': '',
        'label': '',
    }


def _cw_fetch_remote(services=('Trakt', 'Simkl')):
    """Fetch all optional service sources without making the menu fragile."""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    def _one(service):
        if service == 'Trakt':
            if services == ('Trakt',):
                return trakt_mod.get_continue_watching_items()
            return trakt_mod.get_playback_items()
        if service == 'Simkl':
            return simkl_mod.get_playback_items()
        return []

    rows = []
    with ThreadPoolExecutor(max_workers=len(services)) as pool:
        futures = {pool.submit(_one, service): service for service in services}
        for future in as_completed(futures):
            service = futures[future]
            try:
                result = future.result() or []
                for item in result:
                    row = _cw_remote_row(service, item)
                    if row:
                        rows.append(row)
            except Exception as exc:
                xbmc.log(f'COSMOS CW: {service} fetch failed: {exc}', xbmc.LOGWARNING)
    return rows


def _cw_identity(row):
    tmdb = str(row.get('tmdb') or '').strip()
    content = row.get('content') or 'movie'
    season = str(row.get('season') or '').strip()
    episode = str(row.get('episode') or '').strip()
    if tmdb:
        if season and episode:
            return ('tmdb-episode', tmdb, season, episode)
        return ('tmdb', tmdb, 'movie' if content == 'movie' else 'show')
    return ('title', str(row.get('title') or '').strip().lower(), season, episode)


def _cw_dismissed_path():
    profile_dir = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}/')
    if not xbmcvfs.exists(profile_dir):
        xbmcvfs.mkdirs(profile_dir)
    return f'{profile_dir}continue_watching_dismissed.json'


def _cw_identity_token(row):
    """Return a stable JSON token used to hide one Continue Watching row."""
    import json as _json
    return _json.dumps(_cw_identity(row), separators=(',', ':'))


def _cw_load_dismissed():
    import json as _json
    path = _cw_dismissed_path()
    if not xbmcvfs.exists(path):
        return set()
    try:
        handle = xbmcvfs.File(path)
        data = _json.loads(handle.read() or '[]')
        handle.close()
        return {str(value) for value in data}
    except Exception:
        return set()


def _remove_from_continue_watching(params):
    """Clear local progress and persistently hide the selected CW row."""
    import json as _json
    row = {
        'tmdb': params.get('tmdb', ''),
        'content': params.get('content', 'movie'),
        'season': params.get('season', ''),
        'episode': params.get('episode', ''),
        'title': params.get('title', ''),
    }
    dismissed = _cw_load_dismissed()
    dismissed.add(_cw_identity_token(row))
    path = _cw_dismissed_path()
    try:
        handle = xbmcvfs.File(path, 'w')
        handle.write(_json.dumps(sorted(dismissed)))
        handle.close()
    except Exception as exc:
        xbmc.log(f'COSMOS CW: Failed to save dismissed item: {exc}', xbmc.LOGWARNING)

    key = params.get('key', '')
    local_path = params.get('path', '')
    if key:
        resume_mod.clear(key)
    elif local_path:
        resume_mod.clear(resume_mod.key_for_local(local_path))
    xbmcgui.Dialog().notification(
        'C.O.S.M.O.S', 'Removed from Continue Watching',
        xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')


def _cw_is_local_file(row):
    path = str(row.get('url') or '')
    if not path or path.lower().startswith(('http://', 'https://', 'magnet:')):
        return False
    try:
        return bool(xbmcvfs.exists(path))
    except Exception:
        return False


def _list_continue_watching(service=None):
    import json as _json

    # --- 1. Get In-Progress Items (filtered to drop already-watched episodes) ---
    raw_resume_items = [] if service else resume_mod.list_recent(limit=50)
    # 9Anime has its own catalog/watch markers and is not supported by the
    # Cosmos Continue Watching feature.  Filter current and legacy rows
    # before any merge, rendering, or remote-service comparison.
    resume_items = []
    for r in raw_resume_items:
        if resume_mod.is_nineanime(r):
            continue
        if r.get('content') == 'episode':
            r_tmdb = str(r.get('tmdb', ''))
            r_s = str(r.get('season', ''))
            r_e = str(r.get('episode', ''))
            if r_tmdb and r_s and r_e:
                try:
                    if watched_mod.is_watched(r_tmdb, int(r_s), int(r_e)):
                        continue  # Drop finished episodes so they disappear from Continue Watching
                except Exception:
                    pass
        resume_items.append(r)

    for r in resume_items:
        r.setdefault('source', 'Local')
        r.setdefault('sources', ['Local'])

    # --- 2. Get Next Episode Items ---
    next_episode_items = []
    watched_shows = {} if service else watched_mod.get_all_watched_shows()
    sorted_shows = sorted(watched_shows.items(), key=lambda item: item[1]['ts'], reverse=True)

    for tmdb_id, last_watched in sorted_shows[:15]:
        try:
            s_no = int(last_watched.get('last_watched_s', 0))
            e_no = int(last_watched.get('last_watched_e', 0))
        except (ValueError, TypeError):
            s_no, e_no = 0, 0

        # Fallback: if pointers are missing, extract from watched set directly
        if not s_no or not e_no:
            try:
                watched_eps = watched_mod.get_watched_set(tmdb_id)
                if watched_eps:
                    s_no, e_no = max(watched_eps, key=lambda x: (x[0], x[1]))
            except Exception:
                continue

        if not s_no or not e_no:
            continue

        show_meta = tmdb_mod.get_metadata(tmdb_id, 'tvshow')
        if not show_meta:
            continue

        xbmc.log(f"COSMOS CW: Checking next episode for TMDB {tmdb_id}, last watched S{s_no}E{e_no}", xbmc.LOGDEBUG)
        next_ep_meta = tmdb_mod.get_episode_meta(tmdb_id, s_no, e_no + 1)
        if not next_ep_meta:
            xbmc.log(f"COSMOS CW: No next episode found for S{s_no}E{e_no+1}. Trying S{s_no+1}E1.", xbmc.LOGDEBUG)
            next_ep_meta = tmdb_mod.get_episode_meta(tmdb_id, s_no + 1, 1)
            if next_ep_meta:
                next_s, next_e = s_no + 1, 1
                xbmc.log(f"COSMOS CW: Found next episode S{next_s}E{next_e}.", xbmc.LOGDEBUG)
            else:
                xbmc.log(f"COSMOS CW: No next episode found for S{s_no+1}E1. Skipping show {tmdb_id}.", xbmc.LOGDEBUG)
                continue
        else:
            next_s, next_e = s_no, e_no + 1
            xbmc.log(f"COSMOS CW: Found next episode S{next_s}E{next_e}.", xbmc.LOGDEBUG)

        next_episode_item = {
            'is_next_episode': True,
            'ts': last_watched['ts'],
            'title': show_meta.get('title', 'Unknown Show'),
            'tmdb': tmdb_id,
            'content': 'episode',
            'season': next_s,
            'episode': next_e,
            'poster': show_meta.get('poster') or next_ep_meta.get('still'),
            'fanart': show_meta.get('fanart'),
            'imdb': show_meta.get('imdb_id'),
            'year': show_meta.get('year'),
            'url': '',
            'label': '',
            'progress': 0,
        }
        xbmc.log(f"COSMOS CW: Adding next episode item: {next_episode_item['title']} S{next_episode_item['season']}E{next_episode_item['episode']}", xbmc.LOGDEBUG)
        next_episode_item['source'] = 'Local'
        next_episode_item['sources'] = ['Local']
        next_episode_items.append(next_episode_item)

    # --- 3. Fetch optional remote progress and combine sources ---
    # Every service is optional. A timeout, expired token, or malformed
    # response must never prevent local Continue Watching from opening.
    remote_items = _cw_fetch_remote((service,)) if service else _cw_fetch_remote()

    # Create a set of (tmdb_id, season, episode) for all currently in-progress episodes,
    # but skip any episode that is already marked as watched locally.
    in_progress_episodes_keys = set()
    for r in resume_items:
        if r.get('content') == 'episode':
            r_tmdb = str(r.get('tmdb', ''))
            r_s = str(r.get('season', ''))
            r_e = str(r.get('episode', ''))
            if r_tmdb and r_s and r_e:
                try:
                    if watched_mod.is_watched(r_tmdb, int(r_s), int(r_e)):
                        continue # Skip watched items so they don't block next episode
                except Exception:
                    pass
                in_progress_episodes_keys.add((r_tmdb, r_s, r_e))
    xbmc.log(f"COSMOS CW: In-progress episode keys: {in_progress_episodes_keys}", xbmc.LOGDEBUG)

    # Filter out 'Next Episode' items if that specific episode is already in progress.
    filtered_next_episodes = [
        item for item in next_episode_items
        if (str(item.get('tmdb')), str(item.get('season')), str(item.get('episode')))
        not in in_progress_episodes_keys
    ]
    xbmc.log(
        f"COSMOS CW: Filtered local next episodes: {len(filtered_next_episodes)}; "
        f"remote rows: {len(remote_items)}",
        xbmc.LOGDEBUG,
    )

    # Merge the same title/episode reported by multiple services. Local
    # resume data wins because it has an exact Kodi position and can resume
    # the local file or source; remote service names are retained for clarity.
    merged = {}
    for row in resume_items + filtered_next_episodes + remote_items:
        key = _cw_identity(row)
        existing = merged.get(key)
        row_sources = list(row.get('sources') or ([row.get('source')] if row.get('source') else []))
        if not existing:
            row['sources'] = row_sources
            merged[key] = row
            continue

        existing_sources = existing.setdefault('sources', [])
        for source in row_sources:
            if source and source not in existing_sources:
                existing_sources.append(source)

        existing_is_local = existing.get('source') == 'Local' and not existing.get('is_next_episode')
        row_is_local = row.get('source') == 'Local' and not row.get('is_next_episode')
        if row_is_local and not existing_is_local:
            row['sources'] = existing_sources
            merged[key] = row
        elif not existing_is_local and not row_is_local:
            # Prefer a real in-progress row over a next-episode placeholder.
            if existing.get('is_next_episode') and not row.get('is_next_episode'):
                row['sources'] = existing_sources
                merged[key] = row
            elif row.get('ts', 0) > existing.get('ts', 0):
                existing.update({k: v for k, v in row.items() if k != 'sources'})

    dismissed = _cw_load_dismissed()
    combined_items = [
        row for row in merged.values()
        if _cw_identity_token(row) not in dismissed
    ]
    combined_items.sort(key=lambda x: x.get('ts', 0), reverse=True)
    rows = combined_items[:50]

    if not rows:
        _add_directory('[COLOR grey]Nothing to continue — start watching something![/COLOR]',
                       build_url(action='continue_watching'), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    # --- 4. Render List ---
    _still_cache = {}  # (tmdb, season, episode) -> still URL
    for r in rows:
        if r.get('content') == 'episode' and r.get('tmdb') and r.get('season') and r.get('episode'):
            cache_key = (str(r['tmdb']), str(r['season']), str(r['episode']))
            if cache_key not in _still_cache:
                _still_cache[cache_key] = None  # mark as pending

    pending_seasons = {}
    for (tmdb_id_r, season_r, ep_r) in list(_still_cache):
        pending_seasons.setdefault((tmdb_id_r, season_r), []).append(ep_r)

    for (tmdb_id_r, season_r), ep_nos in pending_seasons.items():
        try:
            if str(season_r).isdigit():
                ep_list = tmdb_mod.get_tv_episodes(tmdb_id_r, int(season_r)) or []
                for e in ep_list:
                    k = (tmdb_id_r, season_r, str(e['number']))
                    if k in _still_cache:
                        _still_cache[k] = e.get('still', '') or ''
        except Exception:
            pass

    # Pre-fetch movie posters if missing from resume data
    _movie_poster_cache = {} # tmdb_id -> poster_url
    for r in rows:
        if r.get('content') == 'movie' and r.get('tmdb') and not r.get('poster'):
            tmdb_id = str(r['tmdb'])
            if tmdb_id not in _movie_poster_cache:
                _movie_poster_cache[tmdb_id] = None # Mark as pending

    for tmdb_id in list(_movie_poster_cache):
        try:
            meta = tmdb_mod.get_metadata(tmdb_id, 'movie')
            if meta and meta.get('poster'):
                _movie_poster_cache[tmdb_id] = meta['poster']
        except Exception:
            pass

    for r in rows:
        is_next_ep = r.get('is_next_episode', False)
        title = r.get('title') or 'Untitled'
        content = r.get('content') or 'movie'
        season = r.get('season') or ''
        episode = r.get('episode') or ''
        is_local_file = _cw_is_local_file(r)

        if content in ('episode', 'tvshow') and str(season).isdigit() and str(episode).isdigit():
            se = f'S{int(season):02d}E{int(episode):02d}'
            label = f'{title} — {se}'
        else:
            label = title

        if is_next_ep:
            label = f'[COLOR cyan]▶ Next: [/COLOR]{label}'
        else:
            pct = int((r.get('progress') or 0) * 100)
            pos_h = resume_mod.format_offset(r.get('pos', 0))
            progress_label = f'{pct}% ({pos_h})' if r.get('pos') else f'{pct}%'
            label = f'{label}  [COLOR gold]· {progress_label}[/COLOR]'

        source_names = [str(s) for s in (r.get('sources') or []) if s]
        if source_names:
            label += f'  [COLOR grey]· {"/".join(source_names)}[/COLOR]'

        still = _still_cache.get((str(r.get('tmdb', '')), str(season), str(episode)), '')

        movie_poster = ''
        if r.get('content') == 'movie' and r.get('tmdb'):
            movie_poster = _movie_poster_cache.get(str(r.get('tmdb')), '')

        thumb = r.get('poster') or still or movie_poster or ICON
        fanart = r.get('fanart') or FANART
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})
        
        # Extract common item details for context menu functions
        item_tmdb_id = r.get('tmdb', '')
        item_content = r.get('content', 'movie')
        item_title = r.get('title', 'Untitled')
        item_poster = thumb
        item_fanart = fanart
        item_season = r.get('season', '')
        item_episode = r.get('episode', '')

        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType('episode' if content == 'episode' else 'movie')
            if not is_next_ep and (r.get('pos') or r.get('dur')):
                tag.setResumePoint(float(r.get('pos', 0)), float(r.get('dur', 0) or 0))
        except Exception:
            if not is_next_ep and (r.get('pos') or r.get('dur')):
                li.setProperty('ResumeTime', str(int(r.get('pos', 0))))
                if r.get('dur'):
                    li.setProperty('TotalTime', str(int(r.get('dur'))))

        li.setProperty('IsPlayable', 'true')

        link_payload = {
            'title': title,
            'tmdb': r.get('tmdb', ''),
            'content': content,
            'season': season,
            'episode': episode,
            'imdb': r.get('imdb', ''),
            'year': r.get('year', ''),
            'url': r.get('url', ''),
            'label': r.get('label', ''),
            'poster': thumb,
            'fanart': fanart,
        }
        payload_s = _json.dumps(link_payload)

        # Prepare custom context menu items for Continue Watching
        remove_url = build_url(
            action='remove_from_continue_watching',
            tmdb=item_tmdb_id,
            content=item_content,
            season=item_season,
            episode=item_episode,
            title=item_title,
            key=r.get('key', ''),
            path=r.get('url', '') if is_local_file else '',
        )
        custom_ctx_items = [(
            '[COLOR red]Remove from Continue Watching[/COLOR]',
            f'RunPlugin({remove_url})',
        )]
        if is_next_ep:
            play_url = build_url(action='link_zero', payload=payload_s)
        elif is_local_file:
            play_url = build_url(action='play_local', path=r.get('url', ''), resume='1')
            start_over = build_url(action='play_local', path=r.get('url', ''))
            custom_ctx_items.append(('[COLOR cyan]Start from beginning[/COLOR]', f'RunPlugin({start_over})'))
        else:
            saved_url = str(r.get('url') or '').strip()
            if not saved_url:
                # Remote-only service rows have no saved stream URL and must
                # enter the normal Link Zero source finder.
                play_url = build_url(action='link_zero', payload=payload_s)
                start_over = play_url
            else:
                # Continue Watching must reuse the exact saved source. The
                # direct flag prevents direct/non-debrid media URLs from
                # being redirected into Link Zero when starting over.
                play_url = build_url(
                    action='play_link', payload=payload_s, resume='1', direct='1')
                start_over = build_url(
                    action='play_link', payload=payload_s, prompt='0', direct='1')
            custom_ctx_items.append(('[COLOR cyan]Start from beginning[/COLOR]', f'RunPlugin({start_over})'))

            # Add "Play next episode" for TV episodes
            if item_content == 'episode':
                try:
                    s_no = int(item_season)
                    e_no = int(item_episode)
                    next_ep_payload_dict = {
                        'title': item_title,
                        'tmdb': item_tmdb_id,
                        'content': 'episode',
                        'season': s_no,
                        'episode': e_no + 1,
                        'imdb': r.get('imdb', ''),
                        'year': r.get('year', ''),
                        'poster': item_poster,
                        'fanart': item_fanart,
                    }
                    next_ep_payload_s = _json.dumps(next_ep_payload_dict)
                    next_ep_url = build_url(action='play_link', payload=next_ep_payload_s)
                    custom_ctx_items.append(('[COLOR cyan]Play next episode[/COLOR]', f'RunPlugin({next_ep_url})'))
                except (ValueError, TypeError):
                    pass

        _set_ctx(li,
                 custom_ctx_items,
                 _extras_ctx_items(item_title, item_tmdb_id, item_content, item_poster, item_fanart),
                 _scrobbler_ctx_items(payload_s, item_tmdb_id, item_content, item_title, season=item_season, episode=item_episode),
                 _opensubtitles_ctx_items(payload_s, item_tmdb_id, item_content, item_title, season=item_season, episode=item_episode, imdb=r.get('imdb', '')),
                 _fav_ctx_items(payload_s, item_tmdb_id, item_content, item_title),
                 _trailer_ctx_items(item_tmdb_id, item_content),
                 replace_items=True)

        xbmcplugin.addDirectoryItem(_handle(), play_url, li, isFolder=False)

    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _mark_watched_locally(meta, watched=True):
    """Mutate only the addon's local watched ledger."""
    meta = dict(meta or {})
    if (meta.get('content') or 'movie').lower() == 'movie':
        if watched:
            watched_mod.mark_movie_watched(meta.get('tmdb'))
        else:
            watched_mod.mark_movie_unwatched(meta.get('tmdb'))
    elif watched:
        watched_mod.mark_watched(
            meta.get('tmdb'), meta.get('season'), meta.get('episode'))
    else:
        watched_mod.mark_unwatched(
            meta.get('tmdb'), meta.get('season'), meta.get('episode'))
    return True


def _mark_watched_from_cw(params):
    """Mark an item as fully watched and remove it from Continue Watching."""
    key = params.get('key', '')
    if key:
        resume_mod.clear(key)
    tmdb = params.get('tmdb', '')
    content = params.get('content', 'movie')
    season = params.get('season', '')
    episode = params.get('episode', '')
    meta = {
        'tmdb': tmdb,
        'title': params.get('title') or params.get('name') or '',
        'content': content,
        'season': season,
        'episode': episode,
    }
    if ((content == 'episode' and tmdb and season and episode)
            or (content == 'movie' and tmdb)):
        ok = _mark_watched_locally(meta)
        _notify_watched_action('watched', ok)
    else:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'Unable to mark this item as watched',
            xbmcgui.NOTIFICATION_ERROR, 3000)
    xbmc.executebuiltin('Container.Refresh')


def _show_episode_pairs(tmdb_id):
    """Return TMDB's known ``(season, episode)`` pairs for a show."""
    pairs = []
    for season in tmdb_mod.get_tv_seasons(tmdb_id) or []:
        season_no = season.get('number')
        try:
            season_no = int(season_no)
        except (ValueError, TypeError):
            continue
        for episode in tmdb_mod.get_tv_episodes(tmdb_id, season_no) or []:
            episode_no = episode.get('number')
            try:
                pairs.append((season_no, int(episode_no)))
            except (ValueError, TypeError):
                continue
    return pairs


def _mark_show_watched_locally(params, watched=True):
    """Bulk-toggle watched state for every TMDB episode of a show."""
    tmdb_id = str(params.get('tmdb') or '')
    title = params.get('name') or 'show'
    if not tmdb_id:
        return
    if not watched:
        count = watched_mod.mark_show_unwatched(tmdb_id, None)
        message = f'{count} watched markers cleared locally'
        xbmcgui.Dialog().notification('C.O.S.M.O.S', message,
                                      xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin('Container.Refresh')
        return
    try:
        pairs = _show_episode_pairs(tmdb_id)
    except Exception as exc:
        xbmc.log(f'COSMOS: local show watched lookup failed: {exc}', xbmc.LOGWARNING)
        pairs = []
    if not pairs:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', f'No episodes found for {title}',
            xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    count = watched_mod.mark_show_watched(tmdb_id, pairs)
    message = f'{count} episodes marked watched locally'
    xbmcgui.Dialog().notification('C.O.S.M.O.S', message,
                                  xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')


def _mark_season_watched_locally(params, watched=True):
    """Bulk-toggle watched state for the episodes in one season."""
    tmdb_id = str(params.get('tmdb') or '')
    season = params.get('season')
    title = params.get('name') or 'season'
    try:
        season = int(season)
    except (TypeError, ValueError):
        return
    if not tmdb_id:
        return
    pairs = [(season, int(ep.get('number'))) for ep in
             (tmdb_mod.get_tv_episodes(tmdb_id, season) or [])
             if str(ep.get('number', '')).isdigit()]
    if not pairs:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', f'No episodes found for {title}',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    if watched:
        count = watched_mod.mark_show_watched(tmdb_id, pairs)
        message = f'{count} season episodes marked watched'
    else:
        count = watched_mod.mark_show_unwatched(tmdb_id, pairs)
        message = f'{count} season episodes cleared'
    xbmcgui.Dialog().notification('C.O.S.M.O.S', message,
                                  xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')


# ── Scraper artwork enrichment ──────────────────────────────────────────

_SCRAPER_TMDB_CACHE = {}


def _scraper_tmdb_meta(item):
    """Resolve TMDB artwork for scraper entries that do not carry a TMDB id.

    RLSBB and DDLValley provide release titles and sometimes their own image,
    but usually do not embed a TMDB id.  Look up the title once per listing
    session so their menus can use the same poster/fanart pipeline as the
    main feed without repeatedly querying TMDB for identical entries.
    """
    title = parser.strip_bbcode(str(item.get('title') or '')).strip()
    content = item.get('content') or 'movie'
    tmdb_content = 'movie' if content == 'movie' else 'tvshow'
    cache_key = (title.casefold(), tmdb_content)
    if cache_key in _SCRAPER_TMDB_CACHE:
        return _SCRAPER_TMDB_CACHE[cache_key]

    meta = {}
    if title:
        meta = tmdb_mod.search_art_by_title(title, tmdb_content) or {}
    _SCRAPER_TMDB_CACHE[cache_key] = meta
    return meta


# ── DDLValley integration ───────────────────────────────────────────────


def _ddlvalley_root():
    """Show DDLValley top-level menu: Movies, TV Shows, Search."""
    _add_directory(
        '[COLOR yellow][B]Movies[/B][/COLOR]',
        build_url(action='ddlvalley_movies_menu'),
        thumb=DDLV_ICON, is_folder=True,
    )
    _add_directory(
        '[COLOR yellow][B]TV Shows[/B][/COLOR]',
        build_url(action='ddlvalley_tv_menu'),
        thumb=DDLV_ICON, is_folder=True,
    )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _ddlvalley_movies_menu():
    """Show DDLValley Movies sub-categories."""
    cats = [
        ('All Movies',       'movies'),
        ('3D HSBS',          'movies/3d-hsbs'),
        ('BDRip',            'movies/bdrip'),
        ('Blu-ray 1080p',    'movies/bluray-1080p'),
        ('Blu-ray 2160p',    'movies/bluray-2160p'),
        ('Blu-ray 720p',     'movies/bluray-720p'),
        ('CAM',              'movies/cam'),
        ('Complete Blu-ray', 'movies/complete-bluray'),
        ('DVDR',             'movies/dvdr'),
        ('DVDRip',           'movies/dvdrip-movies'),
        ('DVDScr',           'movies/dvdscr'),
        ('TC',               'movies/tc'),
        ('TS',               'movies/ts'),
        ('WEBRip',           'movies/webrip'),
        ('YIFY Rips',        'movies/yify-rips'),
    ]
    for label, cat in cats:
        _add_directory(label, build_url(action='ddlvalley_cat', category=cat, page='1'),
                       thumb=DDLVALLEY_ICON, is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _ddlvalley_tv_menu():
    """Show DDLValley TV Shows sub-categories."""
    cats = [
        ('All TV Shows', 'tv-shows'),
        ('HD 1080p',     'tv-shows/hd-1080'),
        ('HD 720p',      'tv-shows/hd-720'),
        ('TV Packs',     'tv-shows/tv-pack'),
        ('WebDL',        'tv-shows/web-dl'),
    ]
    for label, cat in cats:
        _add_directory(label, build_url(action='ddlvalley_cat', category=cat, page='1'),
                       thumb=DDLVALLEY_ICON, is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _ddlvalley_list(category, page=1):
    """Render a DDLValley listing page.  category is a slug like 'movies' or 'movies/bdrip'.
    Falls back to the flat slug if the nested URL returns nothing."""
    items, has_next = ddlv_mod.get_items_for_xml(category, page=page)
    if not items:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'No items found',
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    for it in items:
        title = it['title']
        content = it['content']
        meta = _scraper_tmdb_meta(it)
        tmdb_id = meta.get('tmdb_id', '')
        poster = meta.get('poster') or it['poster'] or ICON
        fanart = meta.get('fanart') or FANART
        label = title
        if it['quality']:
            label += f'  [COLOR gold]{it["quality"]}[/COLOR]'
        if content == 'episode':
            label += f'  [COLOR cyan]S{it["season"]}E{it["episode"]}[/COLOR]'

        li = xbmcgui.ListItem(label=_local_movie_label(label, tmdb_id, content))
        li.setArt({
            'icon': poster,
            'thumb': poster,
            'poster': poster,
            'fanart': fanart,
        })
        tmdb_mod.apply_to_listitem(li, meta, content)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType('movie' if content == 'movie' else 'episode')
            if it['plot']:
                tag.setPlot(it['plot'])
        except Exception:
            li.setInfo('video', {'title': title, 'plot': it.get('plot', '')})
        li.setProperty('IsPlayable', 'false')

        # Context menus: Favourites + Trakt Watchlist
        _payload = __import__('json').dumps({
            'title': title,
            'content': content,
            'tmdb': tmdb_id,
            'poster': poster,
            'fanart': fanart,
        })
        _set_ctx(li,
                 _fav_ctx_items(_payload, tmdb_id, content, title),
                 _info_ctx_items(title, tmdb_id, content, poster, fanart),
                 _extras_ctx_items(title, tmdb_id, content, poster, fanart),
                 _local_movie_ctx_items(tmdb_id, content, title),
                 _opensubtitles_ctx_items(_payload, tmdb_id, content, title, it['season'], it['episode']))

        xbmcplugin.addDirectoryItem(_handle(),
                                    build_url(action='ddlvalley_post', url=it['link']),
                                    li, isFolder=True)

    if has_next:
        next_li = xbmcgui.ListItem(label=f'[COLOR cyan][B]Next page ({page + 1}) »[/B][/COLOR]')
        next_li.setArt({'icon': ICON, 'thumb': ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(_handle(),
                                    build_url(action='ddlvalley_cat', category=category, page=str(page + 1)),
                                    next_li, isFolder=True)

    is_tv = category.startswith('tv-shows')
    xbmcplugin.setContent(_handle(), 'episodes' if is_tv else 'movies')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _ddlvalley_post(post_url):
    """Show a DDLValley detail page with download links (bento-style)."""
    try:
        return _ddlvalley_post_inner(post_url)
    except Exception as e:
        xbmc.log(f'COSMOS: _ddlvalley_post crashed: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            'DDLValley', f'Error loading post: {e}',
            xbmcgui.NOTIFICATION_ERROR, 5000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)


def _ddlvalley_post_inner(post_url):
    """Inner body of _ddlvalley_post — wrapped so any crash surfaces as a toast."""
    detail = ddlv_mod.scrape_detail(post_url)
    if not detail:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'Failed to load post details',
            xbmcgui.NOTIFICATION_ERROR, 3000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    title = detail['title']
    poster = detail['poster'] or ICON
    fanart = FANART
    plot = detail['plot'] or ''
    content = detail['content']
    season = detail['season']
    episode = detail['episode']

    links = detail.get('links') or []
    if not links:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'No links found for this post',
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    # Build picker entries with host icons
    ddlvalley_host_icons = {
        'Rapidgator': RAPIDGATOR_ICON,
        'Nitroflare': NITROFLARE_ICON,
        'Multiup':    MULTIUP_ICON,
        'Uploadgig':  UPLOADGIG_ICON,
        'Uploady':    UPLOADY_ICON,
    }
    picker_links = []
    for link in links:
        host = link['host']
        host_icon_path = ddlvalley_host_icons.get(host, DDLVALLEY_ICON)
        if not xbmcvfs.exists(host_icon_path):
            host_icon_path = DDLVALLEY_ICON
        quality = detail.get('quality', '') or ''
        label = f'[B]{host}[/B]'
        if quality:
            label += f'  {quality}'
        picker_links.append({
            'label': label,
            'url': link['url'],
            'host': host,
            'icon': host_icon_path,
        })

    chosen = sf_mod.show_ddlvalley_link_picker(
        picker_links,
        title=title,
        section_icon=DDLVALLEY_ICON,
    )
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)
    if not chosen:
        return
    filehost.play_direct_link(chosen['url'], title=title, use_player=True)


def _ddlvalley_search():
    """Prompt user for a search query and show DDLValley results."""
    kb = xbmc.Keyboard('', 'DDLValley Search')
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    query = kb.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    _ddlvalley_search_results(query, page=1)


def _ddlvalley_search_results(query, page=1):
    """Render DDLValley search results for a query."""
    items, has_next = ddlv_mod.get_items_for_search(query, page=page)
    if not items:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', f'No results for: {query}',
            xbmcgui.NOTIFICATION_INFO, 3000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    for it in items:
        title = it['title']
        content = it['content']
        meta = _scraper_tmdb_meta(it)
        tmdb_id = meta.get('tmdb_id', '')
        poster = meta.get('poster') or it['poster'] or ICON
        fanart = meta.get('fanart') or FANART
        label = title
        if it['quality']:
            label += f'  [COLOR gold]{it["quality"]}[/COLOR]'
        if content == 'episode':
            label += f'  [COLOR cyan]S{it["season"]}E{it["episode"]}[/COLOR]'

        li = xbmcgui.ListItem(label=_local_movie_label(label, tmdb_id, content))
        li.setArt({
            'icon': poster,
            'thumb': poster,
            'poster': poster,
            'fanart': fanart,
        })
        tmdb_mod.apply_to_listitem(li, meta, content)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType('movie' if content == 'movie' else 'episode')
            if it['plot']:
                tag.setPlot(it['plot'])
        except Exception:
            li.setInfo('video', {'title': title, 'plot': it.get('plot', '')})
        li.setProperty('IsPlayable', 'false')
        _sr_payload = __import__('json').dumps({
            'title': title,
            'content': content,
            'tmdb': tmdb_id,
            'poster': poster,
            'fanart': fanart,
        })
        _set_ctx(li,
                 _fav_ctx_items(_sr_payload, tmdb_id, content, title),
                 _info_ctx_items(title, tmdb_id, content, poster, fanart),
                 _extras_ctx_items(title, tmdb_id, content, poster, fanart),
                 _local_movie_ctx_items(tmdb_id, content, title),
                 _opensubtitles_ctx_items(_sr_payload, tmdb_id, content, title, it['season'], it['episode']))
        detail_url = build_url(action='ddlvalley_post', url=it['link'])
        xbmcplugin.addDirectoryItem(_handle(), detail_url, li, isFolder=True)

    if has_next:
        next_li = xbmcgui.ListItem(
            label=f'[COLOR cyan][B]Next page ({page + 1}) »[/B][/COLOR]')
        next_li.setArt({'icon': ICON, 'thumb': ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(
            _handle(),
            build_url(action='ddlvalley_search_results', query=query, page=str(page + 1)),
            next_li, isFolder=True,
        )

    xbmcplugin.setContent(_handle(), 'movies')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── RlsBB integration ───────────────────────────────────────────────────────


def _rlsbb_icon():
    """Return the best available icon for RlsBB entries."""
    return RLSBB_ICON if xbmcvfs.exists(RLSBB_ICON) else _menu_icon('search')


def _rlsbb_fanart():
    """Return the best available fanart for RlsBB entries."""
    return RLSBB_FANART if xbmcvfs.exists(RLSBB_FANART) else FANART


def _rlsbb_host_icon(host):
    """Return a per-filehost icon path, falling back to the RlsBB icon."""
    host_icons = {
        'Rapidgator': RAPIDGATOR_ICON,
        'Nitroflare': NITROFLARE_ICON,
        'Uploadgig':  UPLOADGIG_ICON,
        'Uploady':    UPLOADY_ICON,
        'Multiup':    MULTIUP_ICON,
    }
    candidate = host_icons.get(host)
    if candidate and xbmcvfs.exists(candidate):
        return candidate
    return _rlsbb_icon()


def _rlsbb_root():
    """Show RlsBB top-level menu: Movies, TV Shows, Latest, UFC, Search."""
    icon = _rlsbb_icon()
    _add_directory('[COLOR orange][B]Movies[/B][/COLOR]',
                   build_url(action='rlsbb_movies_menu'), thumb=icon, is_folder=True)
    _add_directory('[COLOR orange][B]TV Shows[/B][/COLOR]',
                   build_url(action='rlsbb_tv_menu'), thumb=icon, is_folder=True)
    _add_directory('[COLOR lime][B]Latest Releases[/B][/COLOR]',
                   build_url(action='rlsbb_latest', page='1'), thumb=icon, is_folder=True)
    _add_directory('[COLOR red][B]UFC[/B][/COLOR]',
                   build_url(action='rlsbb_ufc', page='1'), thumb=icon, is_folder=True)
    _add_directory('[COLOR cyan][B]Search[/B][/COLOR]',
                   build_url(action='rlsbb_search'), thumb=icon, is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _rlsbb_movies_menu():
    """Show RlsBB movie sub-categories."""
    icon = _rlsbb_icon()
    categories = [
        ('All Movies', 'movies'),
        ('BluRay / 1080p', 'movies/bluray-1080p'),
        ('BluRay / 720p', 'movies/bluray-720p'),
        ('4K / UHD', 'movies/4k-uhd'),
        ('BDRip', 'movies/bdrip'),
        ('DVDRip', 'movies/dvdrip'),
        ('WEBRip', 'movies/webrip'),
        ('HDTV', 'movies/hdtv'),
        ('CAM', 'movies/cam'),
        ('TeleSync', 'movies/telesync'),
        ('3D', 'movies/3d'),
        ('Top Movies', 'movies/top-movies'),
    ]
    for label, category in categories:
        _add_directory(label, build_url(action='rlsbb_cat', category=category, page='1'),
                        thumb=icon, is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _rlsbb_tv_menu():
    """Show RlsBB TV-show sub-categories."""
    icon = _rlsbb_icon()
    categories = [
        ('All TV Shows', 'tv-shows'),
        ('Top TV Shows', 'tv-shows/top'),
        ('TV Packs / Season', 'tv-shows/tv-packs'),
    ]
    for label, category in categories:
        _add_directory(label, build_url(action='rlsbb_cat', category=category, page='1'),
                        thumb=icon, is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _rlsbb_render_list(items, has_next, next_action, next_params, is_tv=False):
    """Render a paginated RlsBB listing."""
    icon = _rlsbb_icon()
    if not items:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'No items found – RlsBB',
            xbmcgui.NOTIFICATION_INFO, 2500,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    for item in items:
        title = item['title']
        content = item['content']
        meta = _scraper_tmdb_meta(item)
        tmdb_id = meta.get('tmdb_id', '')
        poster = meta.get('poster') or item['poster'] or icon
        fanart = meta.get('fanart') or _rlsbb_fanart()
        label = title
        if item['quality']:
            label += f'  [COLOR gold]{item["quality"]}[/COLOR]'
        if content == 'episode':
            label += f'  [COLOR cyan]S{item["season"]}E{item["episode"]}[/COLOR]'

        li = xbmcgui.ListItem(label=_local_movie_label(label, tmdb_id, content))
        li.setArt({
            'icon': poster,
            'thumb': poster,
            'poster': poster,
            'fanart': fanart,
        })
        tmdb_mod.apply_to_listitem(li, meta, content)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType('movie' if content == 'movie' else 'episode')
            if item['plot']:
                tag.setPlot(item['plot'])
        except Exception:
            li.setInfo('video', {'title': title, 'plot': item.get('plot', '')})
        li.setProperty('IsPlayable', 'false')

        payload = __import__('json').dumps({
            'title': title,
            'content': content,
            'tmdb': tmdb_id,
            'imdb': meta.get('imdb_id', ''),
            'season': item['season'],
            'episode': item['episode'],
            'poster': poster,
            'fanart': fanart,
        })
        _set_ctx(
            li,
            _fav_ctx_items(payload, tmdb_id, content, title),
            _info_ctx_items(title, tmdb_id, content, poster, fanart),
            _extras_ctx_items(title, tmdb_id, content, poster, fanart),
            _local_movie_ctx_items(tmdb_id, content, title),
            _opensubtitles_ctx_items(payload, tmdb_id, content, title, item['season'], item['episode'])
        )

        detail_url = build_url(action='rlsbb_post', url=item['link'])
        xbmcplugin.addDirectoryItem(_handle(), detail_url, li, isFolder=True)

    if has_next:
        next_li = xbmcgui.ListItem(
            label='[COLOR cyan][B]Next page »[/B][/COLOR]')
        next_li.setArt({'icon': ICON, 'thumb': ICON, 'fanart': _rlsbb_fanart()})
        xbmcplugin.addDirectoryItem(
            _handle(),
            build_url(action=next_action, **next_params),
            next_li,
            isFolder=True,
        )

    xbmcplugin.setContent(_handle(), 'episodes' if is_tv else 'movies')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _rlsbb_cat(category, page=1):
    """Render a RlsBB category listing."""
    items, has_next = rlsbb_mod.get_items_for_category(category, page=page)
    _rlsbb_render_list(
        items, has_next, 'rlsbb_cat',
        {'category': category, 'page': str(page + 1)},
        is_tv=category.startswith('tv-shows'),
    )


def _rlsbb_latest(page=1):
    """Render the RlsBB latest releases page."""
    items, has_next = rlsbb_mod.get_latest(page=page)
    _rlsbb_render_list(items, has_next, 'rlsbb_latest', {'page': str(page + 1)})


def _rlsbb_ufc(page=1):
    """Render RlsBB UFC results."""
    items, has_next = rlsbb_mod.get_ufc(page=page)
    _rlsbb_render_list(items, has_next, 'rlsbb_ufc', {'page': str(page + 1)})


def _rlsbb_post(post_url):
    """Show a RlsBB detail page through the existing Cosmos link picker."""
    try:
        return _rlsbb_post_inner(post_url)
    except Exception as e:
        xbmc.log(f'COSMOS: _rlsbb_post crashed: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            'RlsBB', f'Error loading post: {e}',
            xbmcgui.NOTIFICATION_ERROR, 5000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)


def _rlsbb_post_inner(post_url):
    """Inner body of _rlsbb_post — wrapped so any crash surfaces as a toast."""
    import json as _json

    if not post_url:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    detail = rlsbb_mod.scrape_detail(post_url)
    if not detail:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'Failed to load RlsBB post',
            xbmcgui.NOTIFICATION_ERROR, 3000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    title = detail['title']
    poster = detail['poster'] or _rlsbb_icon()
    fanart = _rlsbb_fanart()
    raw_links = detail.get('links') or []
    if not raw_links:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'No Rapidgator/Nitroflare links found',
            xbmcgui.NOTIFICATION_INFO, 3000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    picker_links = []
    for link in raw_links:
        host = link['host']
        quality = link.get('quality', '') or detail.get('quality', '')
        label = f'[B]{host}[/B]'
        if quality:
            label += f'  {quality}'
        picker_links.append({
            'label': label,
            'url': link['url'],
            'host': host,
            'quality': quality,
            'icon': _rlsbb_host_icon(host),
        })

    chosen = sf_mod.show_rlsbb_link_picker(
        picker_links,
        title=title,
        section_icon=_rlsbb_icon(),
    )
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)
    if not chosen:
        return
    chosen_url = chosen['url']
    # RlsBB may return protected.to for the Uploady-labeled mirror and the
    # picker metadata is not guaranteed to survive every skin path. Follow
    # all protected links before handing them to the normal resolver.
    if 'protected.to/' in chosen_url.lower():
        xbmc.log('COSMOS: Following RlsBB protected link before playback', xbmc.LOGINFO)
        chosen_url = rlsbb_mod.resolve_uploady_redirect(chosen_url)
    filehost.play_direct_link(chosen_url, title=title, use_player=True)


def _rlsbb_search():
    """Prompt for a query and show RlsBB search results."""
    kb = xbmc.Keyboard('', 'RlsBB Search')
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    query = kb.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    _rlsbb_search_results(query, page=1)


def _rlsbb_search_results(query, page=1):
    """Render RlsBB search results."""
    items, has_next = rlsbb_mod.get_search_results(query, page=page)
    _rlsbb_render_list(
        items, has_next, 'rlsbb_search_results',
        {'query': query, 'page': str(page + 1)},
    )


# ── Newly Added (last 7 days) ────────────────────────────────────────────

def _list_newly_added(feed_url, page=1):
    """Render items whose first_seen timestamp is within the last 7 days.

    We cross-reference each tracked item with the current search index so
    we can present the full playable payload (with links) when available.
    """
    import json as _json
    _replace_builtin_context_items()
    try:
        page = max(1, int(page))
    except (ValueError, TypeError):
        page = 1

    rows = na_mod.list_recent(days=7, limit=None)  # Fetch all recent items
    if not rows:
        _add_directory('[COLOR grey]No newly added items in the last 7 days[/COLOR]',
                       build_url(action='newly_added', feed=feed_url), is_folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    total = len(rows)
    start = (page - 1) * _PAGE_SIZE
    end = start + _PAGE_SIZE

    # Match the saved search catalogue by TMDB identity, using a lookup table
    # and no feed crawl or online metadata requests during menu rendering.
    page_rows = rows[start:end]
    cached = search_mod._load_cache()
    lookup = {}
    for item in (cached or {}).get('items') or []:
        if not isinstance(item, dict):
            continue
        lookup.setdefault(na_mod._key(item), item)
    prepared_metadata = na_mod.load_metadata()

    def _lookup(row):
        return lookup.get(na_mod._key(row))

    added_any = False
    for r in page_rows:
        it = _lookup(r) or {}
        tmdb_id = r.get('tmdb') or it.get('tmdb', '')
        content = na_mod._identity_content(r)
        source_feed = str(r.get('feed') or it.get('feed') or '').strip()
        raw_name = r.get('name') or it.get('name') or 'Untitled'
        name = parser.strip_bbcode(raw_name)

        prepared = prepared_metadata.get(na_mod.metadata_key(r)) or {}
        meta = prepared.get('meta') if isinstance(prepared, dict) else {}
        meta = meta if isinstance(meta, dict) else {}
        label_title = meta.get('title') or name
        year = meta.get('year') or parser.extract_year(raw_name)
        display_title = label_title
        if content == 'episode' and r.get('season') not in (None, '') and r.get('episode') not in (None, ''):
            display_title = f"{label_title} S{r['season']}E{r['episode']}" if meta.get('title') else name
        label = f'{display_title} ({year})' if year else display_title
        
        # age badge + section + added date
        import time as _time
        now_ts = int(_time.time())
        age_days = max(0, (now_ts - int(r.get('first_seen', 0))) // 86400)
        added_date = _time.strftime('%d %b', _time.localtime(int(r.get('first_seen', now_ts))))
        section = r.get('section') or na_mod._infer_section(r.get('feed', ''))
        section_tag = f'  [COLOR grey]{section}[/COLOR]' if section else ''
        label = (f'{label}  [COLOR springgreen]NEW ({age_days}d)[/COLOR]'
                 f'  [COLOR darkorange]{added_date}[/COLOR]{section_tag}')

        li = xbmcgui.ListItem(label=label)
        tmdb_mod.apply_to_listitem(li, meta, content)
        thumb = meta.get('poster') or r.get('thumb') or it.get('thumb') or ICON
        fanart = meta.get('fanart') or FANART
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})
        
        # Enrich plot with section + date so it shows in the info panel
        try:
            tag = li.getVideoInfoTag()
            existing_plot = tag.getPlot() or meta.get('plot', '')
            section_line = f'Section: {section}  |  Added: {added_date}' if section else f'Added: {added_date}'
            tag.setPlot(f'[{section_line}]\n{existing_plot}'.strip())
        except Exception:
            pass

        if content == 'tvshow':
            # Return to the native Enigma show location when its source feed
            # is known; retain TMDB as a compatibility fallback for old rows.
            imdb_id = (meta or {}).get('imdb_id', '')
            if source_feed:
                url = build_url(
                    action='tv_seasons', feed=source_feed, tmdb=tmdb_id)
            else:
                url = build_url(
                    action='tmdb_tv_seasons',
                    tmdb=tmdb_id, name=label_title, year=str(year or ''),
                    imdb=imdb_id, poster=thumb, fanart=fanart,
                )
            
            tv_payload = _json.dumps({
                'title': label_title, 'tmdb': tmdb_id, 'content': 'tvshow',
                'imdb': imdb_id, 'year': str(year or ''),
                'poster': thumb, 'fanart': fanart,
            })
            _set_ctx(li,
                     _fav_ctx_items(tv_payload, tmdb_id, 'tvshow', label_title),
                     _scrobbler_ctx_items(tv_payload, tmdb_id, 'tvshow', label_title),
                     _extras_ctx_items(label_title, tmdb_id, 'tvshow', thumb, fanart),
                     _trailer_ctx_items(tmdb_id, 'tvshow'),
                     _local_tvshow_ctx_items(tmdb_id, label_title),
                     _opensubtitles_ctx_items(tv_payload, tmdb_id, 'tvshow', label_title))
            xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)
            added_any = True
        else:
            # Newly Added is a navigation view. Episodes return to their
            # Enigma season and films open their exact stored Enigma entry,
            # rather than starting Link Zero directly.
            tagged_links = [
                {'label': search_mod._label_for_link(lk.get('label'), lk.get('url')),
                 'url': lk.get('url', '')}
                for lk in (r.get('links') or it.get('links') or [])
            ]
            payload = _json.dumps({
                'title': label_title,
                'tmdb': tmdb_id,
                'content': content,
                'season': r.get('season') if r.get('season') not in (None, '') else it.get('season'),
                'episode': r.get('episode') if r.get('episode') not in (None, '') else it.get('episode'),
                'links': tagged_links,
                'imdb': (meta or {}).get('imdb_id', ''),
                'year': year or 0,
                'poster': thumb,
                'fanart': fanart,
            })

            if content == 'episode' and source_feed:
                url = build_url(
                    action='tv_episodes', feed=source_feed, tmdb=tmdb_id,
                    season=str(r.get('season') if r.get('season') not in (None, '') else it.get('season', '')),
                )
                is_folder = True
            elif content == 'movie' and tagged_links:
                # Open this exact Enigma film entry rather than returning to
                # the full source XML listing.  show_links preserves the
                # film's native direct/debrid choices and normal playback.
                url = build_url(action='show_links', payload=payload)
                is_folder = True
            elif tagged_links:
                url = build_url(action='show_links', payload=payload)
                is_folder = True
            else:
                # Legacy rows without a recorded feed cannot be navigated.
                # Keep them visible and allow a rescan to back-fill location.
                url = build_url(action='newly_added', feed=feed_url)
                is_folder = False

            _set_ctx(li,
                     _fav_ctx_items(payload, tmdb_id, content, label_title),
                     _info_ctx_items(label_title, tmdb_id, content, thumb, fanart),
                     _scrobbler_ctx_items(payload, tmdb_id, content, label_title),
                     _extras_ctx_items(label_title, tmdb_id, content, thumb, fanart),
                     _trailer_ctx_items(tmdb_id, content),
                     _opensubtitles_ctx_items(payload, tmdb_id, content, label_title),
                     _direct_link_download_ctx_items(payload))
            xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=is_folder)
            added_any = True

    if not added_any:
        _add_directory(
            '[COLOR grey]Rebuild the search index to populate this list '
            '(open Universal Search once).[/COLOR]',
            build_url(action='newly_added', feed=feed_url), is_folder=False,
        )

    if end < total:
        next_li = xbmcgui.ListItem(
            label=f'[B]Next page ({page + 1}) »[/B]  {end}/{total} shown')
        next_li.setArt({'icon': ICON, 'thumb': ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(
            _handle(),
            build_url(action='newly_added', feed=feed_url, page=str(page + 1)),
            next_li, isFolder=True)

    xbmcplugin.setContent(_handle(), 'movies')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── Sync (export / import) ───────────────────────────────────────────────

def _sync_export():
    sync_mod.interactive_export()


def _sync_import():
    sync_mod.interactive_import()


# ── Trailers (TMDB → YouTube via plugin.video.youtube) ───────────────────

def _trending_week():
    """Render TMDB /trending/all/week — a lightweight daily-fresh row
    above the Trailers feed. Each item plays its trailer via YouTube."""
    import json as _json
    key = (ADDON.getSetting('tmdb_api_key') or tmdb_mod.DEFAULT_API_KEY).strip()
    if not key:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'TMDB API key missing (Settings → General)',
            xbmcgui.NOTIFICATION_WARNING, 5000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    body = parser.fetch_url(
        f'https://api.themoviedb.org/3/trending/all/week'
        f'?api_key={key}&language=en-US'
    )
    try:
        data = _json.loads(body or '{}')
    except ValueError:
        data = {}
    results = data.get('results') or []
    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No trending data',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    for r in results:
        mtype = (r.get('media_type') or '').lower()
        if mtype not in ('movie', 'tv'):
            continue
        is_tv = (mtype == 'tv')
        tmdb_id = str(r.get('id') or '')
        name = r.get('title') or r.get('name') or 'Untitled'
        date = r.get('release_date') or r.get('first_air_date') or ''
        year = date[:4] if date else ''
        label = f'{name} ({year})' if year else name
        # subtle rank badge based on list position
        rank = results.index(r) + 1
        if rank <= 3:
            label = f'[COLOR hotpink]#{rank}[/COLOR]  {label}'
        else:
            label = f'[COLOR grey]#{rank}[/COLOR]  {label}'

        poster = r.get('poster_path') or ''
        backdrop = r.get('backdrop_path') or ''
        thumb = f'https://image.tmdb.org/t/p/w500{poster}' if poster else ICON
        fanart = f'https://image.tmdb.org/t/p/original{backdrop}' if backdrop else FANART

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(label)
            tag.setPlot(r.get('overview') or '')
            tag.setMediaType('tvshow' if is_tv else 'movie')
            if year and year.isdigit():
                tag.setYear(int(year))
            va = r.get('vote_average')
            if va:
                try:
                    tag.setRating(float(va))
                except Exception:
                    pass
        except Exception:
            pass
        li.setProperty('IsPlayable', 'true')

        play_url = build_url(
            action='play_trailer', tmdb=tmdb_id,
            content=('tvshow' if is_tv else 'movie'),
        )
        xbmcplugin.addDirectoryItem(_handle(), play_url, li, isFolder=False)

    xbmcplugin.setContent(_handle(), 'movies')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── Root menu hubs ───────────────────────────────────────────────────────


def _freebie_tv_root():
    """Free streaming hub and Vidcore's TMDB catalogue."""
    _add_directory(
        '[B]Vidcore[/B]', build_url(action='vidcore_root'),
        thumb=VIDCORE_ICON, fanart=FANART,
        info={'title': 'Vidcore',
              'plot': 'Browse and search movies and TV shows using TMDB, then choose from available Vidcore playback sources.'},
        is_folder=True,
    )
    _add_directory(
        '[B]Tubi TV[/B]', build_url(action='tubi_root'),
        thumb=TUBI_ICON, fanart=TUBI_FANART,
        info={
            'title': 'Tubi TV',
            'plot': 'Browse free movies, TV shows, and live TV on Tubi.',
        },
        is_folder=True,
    )
    _add_directory(
        '[B]Pluto TV[/B]', build_url(action='pluto_root'),
        thumb=PLUTO_ICON, fanart=FANART,
        info={
            'title': 'Pluto TV',
            'plot': 'Watch live channels and browse free on-demand movies and TV shows on Pluto TV.',
        },
        is_folder=True,
    )
    _add_directory(
        '[B]Plex[/B]', build_url(action='plex_root'),
        thumb=PLEX_ICON, fanart=FANART,
        info={
            'title': 'Plex',
            'plot': 'Browse free ad-supported movies and TV shows on Plex.',
        },
        is_folder=True,
    )
    _add_directory(
        '[B]Samsung TV Plus[/B]', build_url(action='samsungtvplus_root'),
        thumb=SAMSUNG_TVPLUS_ICON, fanart=FANART,
        info={
            'title': 'Samsung TV Plus',
            'plot': 'Watch free regional live TV channels from Samsung TV Plus.',
        }, is_folder=False, is_playable=True,
    )
    _add_directory(
        '[B]Rakuten TV[/B]', build_url(action='rakuten_root'),
        thumb=RAKUTEN_ICON, fanart=FANART,
        info={'title': 'Rakuten TV',
              'plot': 'Watch live TV channels on Rakuten TV.'},
        is_folder=False, is_playable=True, live=True,
    )
    _add_directory(
        '[B]BBC Channels[/B]', build_url(action='bbc_root'),
        thumb=BBC_ICON, fanart=FANART,
        info={'title': 'BBC Channels',
              'plot': 'Scrape and watch BBC live television channels through BBC iPlayer.'},
        is_folder=True,
    )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _music_root():
    """Music hub with Radio UK and the official MusicMP3.ru catalogue."""
    installed = bool(xbmc.getCondVisibility(f'System.HasAddon({RADIOUK_ID})'))
    radio_icon = _menu_icon('radiouk')
    radio_fanart = f'{ADDON_PATH}resources/media/fanart_radiouk.png'
    if installed:
        try:
            radio_addon = xbmcaddon.Addon(RADIOUK_ID)
            radio_icon = radio_addon.getAddonInfo('icon') or radio_icon
            radio_fanart = radio_addon.getAddonInfo('fanart') or radio_fanart
        except Exception:
            pass
    _add_directory(
        '[B]Radio UK[/B]',
        f'plugin://{RADIOUK_ID}/' if installed else build_url(action='install_radiouk'),
        thumb=radio_icon, fanart=radio_fanart,
        info={'title': 'Radio UK', 'plot': ('Listen to live UK radio stations.' if installed else
              'Select to install Radio UK from the Enigma Repository.')},
        is_folder=installed,
    )
    _add_directory(
        '[B]MusicMP3[/B]',
        build_url(action='musicmp3_root'),
        thumb=f'{ADDON_PATH}resources/media/icon_musicmp3.png', fanart=FANART,
        info={
            'title': 'MusicMP3',
            'plot': 'Browse MusicMP3.ru inside Kodi with native search, artists, albums, and music playback.',
        },
        is_folder=True,
    )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _install_radiouk():
    """Install optional Radio UK through an existing Enigma Repository."""
    if xbmc.getCondVisibility(f'System.HasAddon({RADIOUK_ID})'):
        xbmc.executebuiltin(f'ActivateWindow(Music,plugin://{RADIOUK_ID}/,return)')
        return
    if not xbmc.getCondVisibility(f'System.HasAddon({RADIOUK_REPO_ID})'):
        xbmcgui.Dialog().ok(
            'Radio UK',
            'Radio UK requires the Enigma Repository.\n\nInstall and enable the Enigma Repo first, then try again.',
        )
        return
    xbmc.executebuiltin(f'InstallAddon({RADIOUK_ID})')
    xbmcgui.Dialog().notification(
        'Radio UK', 'Kodi installation requested from Enigma Repo',
        xbmcgui.NOTIFICATION_INFO, 5000,
    )


def _install_wiki_trailers():
    """Open or install Wiki Trailers through the Enigma Repository."""
    if xbmc.getCondVisibility(f'System.HasAddon({WIKI_TRAILERS_ID})'):
        xbmc.executebuiltin(
            f'ActivateWindow(Videos,plugin://{WIKI_TRAILERS_ID}/,return)')
        return
    if not xbmc.getCondVisibility(f'System.HasAddon({WIKI_TRAILERS_REPO_ID})'):
        xbmcgui.Dialog().ok(
            'Wiki Trailers',
            'Wiki Trailers requires the Enigma Repository.\n\n'
            'Install and enable the Enigma Repository first, then try again.',
        )
        return
    xbmc.executebuiltin(f'InstallAddon({WIKI_TRAILERS_ID})')
    xbmcgui.Dialog().notification(
        'Wiki Trailers', 'Kodi installation requested from Enigma Repo',
        xbmcgui.NOTIFICATION_INFO, 5000,
    )


def _install_effedupmovies():
    """Open or install Effed Up Movies from the Enigma Repository."""
    # This is an Adult Lounge child route. Reuse the active lounge session so
    # returning from the addon does not ask for the PIN again.
    if not _adult_route_authorized():
        return

    if xbmc.getCondVisibility('System.HasAddon(%s)' % EFFEDUPMOVIES_ID):
        xbmc.executebuiltin('ActivateWindow(Videos,plugin://%s/,return)' % EFFEDUPMOVIES_ID)
        return
    if not xbmc.getCondVisibility('System.HasAddon(%s)' % RADIOUK_REPO_ID):
        xbmcgui.Dialog().ok(
            'Effed Up Movies',
            'Effed Up Movies requires the Enigma Repository.\n\n'
            'Install and enable the Enigma Repository first, then try again.',
        )
        return
    xbmc.executebuiltin('InstallAddon(%s)' % EFFEDUPMOVIES_ID)
    xbmcgui.Dialog().notification(
        'Effed Up Movies', 'Kodi installation requested from Enigma Repo',
        xbmcgui.NOTIFICATION_INFO, 5000,
    )


def _anime_root():
    """Anime provider hub; additional anime sites can be added here later."""
    _add_directory(
        '[B]9Anime[/B]', build_url(action='nineanime_root'),
        thumb=NINEANIME_ICON, fanart=NINEANIME_FANART, is_folder=True,
        info={
            'title': '9Anime',
            'plot': 'Browse anime series and movies through 9Anime.',
        },
    )
    cartoonio_installed = bool(
        xbmc.getCondVisibility(f'System.HasAddon({CARTOONIO_ID})'))
    if cartoonio_installed:
        try:
            cartoonio_addon = xbmcaddon.Addon(CARTOONIO_ID)
            cartoonio_icon = cartoonio_addon.getAddonInfo('icon')
            cartoonio_fanart = cartoonio_addon.getAddonInfo('fanart')
        except Exception:
            cartoonio_icon = _menu_icon('cartoonio')
            cartoonio_fanart = f'{ADDON_PATH}resources/media/fanart_cartoonio.jpg'
        _add_directory(
            '[B]Cartoonio[/B]', f'plugin://{CARTOONIO_ID}/',
            thumb=cartoonio_icon or _menu_icon('cartoonio'),
            fanart=cartoonio_fanart or f'{ADDON_PATH}resources/media/fanart_cartoonio.jpg',
            info={
                'title': 'Cartoonio',
                'plot': ('Browse classic and modern cartoons through the '
                         'installed Cartoonio add-on.'),
            },
            is_folder=True,
        )
    else:
        _add_directory(
            '[B]Cartoonio[/B]',
            build_url(action='install_cartoonio'),
            thumb=_menu_icon('cartoonio'),
            fanart=f'{ADDON_PATH}resources/media/fanart_cartoonio.jpg',
            info={
                'title': 'Cartoonio',
                'plot': ('Optional cartoon provider. Select to install '
                         'Cartoonio from the Enigma Repository.'),
            },
            is_folder=False,
        )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)


def _install_cartoonio():
    """Install optional Cartoonio only through an existing Enigma Repo."""
    if xbmc.getCondVisibility(f'System.HasAddon({CARTOONIO_ID})'):
        xbmc.executebuiltin(
            f'ActivateWindow(Videos,plugin://{CARTOONIO_ID}/,return)')
        return
    if not xbmc.getCondVisibility(f'System.HasAddon({CARTOONIO_REPO_ID})'):
        xbmcgui.Dialog().ok(
            'Cartoonio',
            'Cartoonio requires the Enigma Repository.\n\n'
            'Install and enable the Enigma Repo first, then try again.',
        )
        return
    xbmc.executebuiltin(f'InstallAddon({CARTOONIO_ID})')
    xbmcgui.Dialog().notification(
        'Cartoonio', 'Kodi installation requested from Enigma Repo',
        xbmcgui.NOTIFICATION_INFO, 5000,
    )


def _release_hub_root():
    """Release-site hub for scene and direct-download release sources."""
    _add_directory(
        '[B]DDLValley[/B]', build_url(action='ddlvalley'),
        thumb=_menu_icon('ddlvalley'), is_folder=True,
    )
    _add_directory(
        '[B]RlsBB[/B]', build_url(action='rlsbb'),
        thumb=RLSBB_ICON if xbmcvfs.exists(RLSBB_ICON) else _menu_icon('rlsbb'),
        fanart=RLSBB_FANART if xbmcvfs.exists(RLSBB_FANART) else FANART,
        is_folder=True,
    )
    _add_directory(
        '[B]TorrentClaw[/B]', build_url(action='torrentclaw_root'),
        thumb=_menu_icon('torrentclaw'), is_folder=True,
    )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _tracking_root():
    """Tracking hub for the addon's supported watch-status services."""
    entries = (
        ('Trakt', 'trakt_root', 'trakt'),
        ('Simkl', 'simkl_root', 'simkl'),
        ('PunchPlay', 'punchplay_root', 'punchplay'),
    )
    for label, action, icon in entries:
        _add_directory(
            f'[B]{label}[/B]', build_url(action=action),
            thumb=_menu_icon(icon), is_folder=True,
        )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _sports_hub():
    """Top-level sports provider hub."""
    _add_directory(
        '[B]Watch Wrestling[/B]', build_url(action='watchwrestling_root'),
        thumb=_menu_icon('watchwrestling'), fanart=FANART,
        info={'title': 'Watch Wrestling', 'plot': 'Wrestling events, shows and available video servers.'},
        is_folder=True,
    )
    _add_directory(
        '[B]WWE Official Archive[/B]',
        build_url(action='wwe_archive'),
        thumb=_menu_icon('wwe_archive'), fanart=FANART,
        info={'title': 'WWE Official Archive',
              'plot': 'Free selected WWE full matches and highlights from WWE.com.'},
        is_folder=True,
    )
    _add_directory(
        '[B]ReFooty[/B]', build_url(action='refooty_root'),
        thumb=_menu_icon('refooty'), fanart=FANART,
        info={'title': 'ReFooty', 'plot': 'Football highlights and full-match replays.'},
        is_folder=True,
    )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _watchwrestling_menu(url='', sources=False, title='Watch Wrestling', offset=0):
    try:
        if not url:
            for label, page in watchwrestling_mod.sections():
                _add_directory(label, build_url(action='watchwrestling_list', page=page),
                               thumb=_menu_icon('watchwrestling'), fanart=FANART, is_folder=True)
        elif sources:
            entries = watchwrestling_mod.sources(url)
            if not entries:
                xbmcgui.Dialog().notification('Watch Wrestling', 'No video servers available',
                                              xbmcgui.NOTIFICATION_INFO, 4000)
            for label, source in entries:
                li = xbmcgui.ListItem(label=label)
                icon = _menu_icon('watchwrestling')
                li.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': FANART})
                li.setInfo('video', {'title': title + ' - ' + label, 'genre': 'Wrestling, Sports'})
                li.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(
                    _handle(), build_url(action='watchwrestling_play', source=source, title=title),
                    li, isFolder=False)
        else:
            entries, next_page = watchwrestling_mod.catalogue_page(url, offset)
            if not entries:
                xbmcgui.Dialog().notification('Watch Wrestling', 'No events found on this page',
                                              xbmcgui.NOTIFICATION_INFO, 4000)
            for entry in entries:
                _add_directory(
                    entry['title'], build_url(
                        action='watchwrestling_list' if entry['folder'] else 'watchwrestling_sources',
                        page=entry['url'], title=entry['title']),
                    thumb=entry['thumb'] or _menu_icon('watchwrestling'), fanart=FANART,
                    info={'title': entry['title'], 'genre': 'Wrestling, Sports', 'mediatype': 'video'},
                    is_folder=True)
            if next_page:
                _add_directory('[B]Next Page[/B]', build_url(action='watchwrestling_list',
                                                           page=next_page[0], offset=str(next_page[1])),
                               thumb=_menu_icon('watchwrestling'), fanart=FANART, is_folder=True)
        xbmcplugin.setContent(_handle(), 'files' if not url else 'videos')
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
    except Exception as exc:
        xbmc.log(f'COSMOS Watch Wrestling: {exc}', xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Watch Wrestling', 'Unable to load this page',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)


def _watchwrestling_play(source, title):
    try:
        source = watchwrestling_mod.unwrap(source)
    except Exception as exc:
        xbmc.log(f'COSMOS Watch Wrestling player: {exc}', xbmc.LOGWARNING)
        message = str(exc) if isinstance(exc, watchwrestling_mod.PlayerUnavailable) else 'Unable to open this video server'
        xbmcgui.Dialog().notification('Watch Wrestling', message,
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return
    if watchwrestling_mod.is_direct_stream(source):
        xbmc.log('COSMOS Watch Wrestling: direct JWPlayer media resolved', xbmc.LOGINFO)
        filehost._play_stream(source)
        return
    if 'dailymotion.com' in source or 'dai.ly/' in source:
        try:
            from . import hls_manifest_proxy
            stream, _ = filehost.resolve_filehost_link(source)
            if not stream:
                raise ValueError('Dailymotion did not provide a playable stream')
            if '.m3u8' in stream.partition('|')[0]:
                stream = hls_manifest_proxy.prepare(stream)
                xbmc.log('COSMOS Watch Wrestling: Dailymotion master playlist validated; using local manifest handoff', xbmc.LOGINFO)
            filehost._play_stream(stream)
        except Exception as exc:
            xbmc.log(f'COSMOS Watch Wrestling Dailymotion: {type(exc).__name__}', xbmc.LOGWARNING)
            xbmcgui.Dialog().notification('Watch Wrestling', 'Dailymotion source unavailable; try another server',
                                          xbmcgui.NOTIFICATION_ERROR, 4000)
            xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return
    filehost.play_direct_link(source, title=title)


def _wwe_archive(page='1'):
    try:
        entries = wwe_archive_mod.videos()
    except Exception as exc:
        xbmc.log(f'COSMOS WWE archive: {exc}', xbmc.LOGWARNING)
        entries = []
    try:
        page_number = max(1, int(page or 1))
    except (TypeError, ValueError):
        page_number = 1
    page_size = 20
    start = (page_number - 1) * page_size
    page_entries = entries[start:start + page_size]
    for title, url in page_entries:
        info = wwe_archive_mod.metadata(url, title)
        li = xbmcgui.ListItem(label=title)
        poster = info.get('thumb') or _menu_icon('wwe_archive')
        li.setArt({'icon': poster, 'thumb': poster, 'fanart': info.get('fanart') or FANART})
        li.setInfo('video', info)
        xbmcplugin.addDirectoryItem(
            _handle(), build_url(action='wwe_sources', page=url, title=title),
            li, isFolder=True,
        )
    if start + page_size < len(entries):
        _add_directory(
            '[B]Next Page[/B]',
            build_url(action='wwe_archive', page=str(page_number + 1)),
            thumb=_menu_icon('sports'), fanart=FANART,
            info={'title': f'WWE Archive - Page {page_number + 1}'},
            is_folder=True,
        )
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _wwe_sources(page_url, title):
    try:
        entries = wwe_archive_mod.sources(page_url)
    except Exception:
        entries = []
    if not entries:
        xbmcgui.Dialog().notification('WWE Official Archive',
                                      'No playable sources found',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
    for index, source in enumerate(entries, 1):
        li = xbmcgui.ListItem(label=f'[B]Source {index}[/B]')
        li.setArt({'icon': _menu_icon('wwe_archive'), 'thumb': _menu_icon('wwe_archive'), 'fanart': FANART})
        li.setInfo('video', {'title': title, 'plot': 'WWE Official Archive source',
                             'genre': 'Wrestling, Sports', 'studio': 'WWE',
                             'mediatype': 'video'})
        xbmcplugin.addDirectoryItem(
            _handle(), build_url(action='wwe_play', source=source, title=title),
            li, isFolder=False,
        )
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _refooty_root():
    section_info = {'genre': 'Football, Sports', 'studio': 'ReFooty'}
    _add_directory(
        '[B]Behind the Scenes[/B]',
        build_url(action='refooty_category',
                  url=f'{refooty_mod.BASE_URL}behind-the-scenes', page='1'),
        thumb=_menu_icon('refooty'), fanart=FANART, info=dict(section_info, title='Behind the Scenes'), is_folder=True,
    )
    _add_directory(
        '[B]European Competitions[/B]', build_url(action='refooty_european'),
        thumb=_menu_icon('refooty'), fanart=FANART, info=dict(section_info, title='European Competitions'), is_folder=True,
    )
    _add_directory(
        '[B]Countries & Leagues[/B]', build_url(action='refooty_countries'),
        thumb=_menu_icon('refooty'), fanart=FANART, info=dict(section_info, title='Countries & Leagues'), is_folder=True,
    )
    _add_directory(
        '[B]Latest Highlights[/B]', build_url(action='refooty_latest', page='1'),
        thumb=_menu_icon('refooty'), fanart=FANART, info=dict(section_info, title='Latest Highlights'), is_folder=True,
    )
    _add_directory(
        '[B]Full Matches[/B]', build_url(action='refooty_full_matches', page='1'),
        thumb=_menu_icon('refooty'), fanart=FANART, info=dict(section_info, title='Full Matches'), is_folder=True,
    )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _refooty_european():
    competitions = (
        ('Champions League', 'uefa-champions-league'),
        ('Europa League', 'uefa-europa-league'),
        ('Europa Conference League', 'uefa-europa-conference-league'),
        ('UEFA Super Cup', 'uefa-super-cup'),
    )
    for label, slug in competitions:
        _add_directory(
            f'[B]{label}[/B]',
            build_url(action='refooty_category',
                      url=f'{refooty_mod.BASE_URL}european/{slug}', page='1'),
            thumb=_menu_icon('refooty'), fanart=FANART,
            info={'title': label, 'genre': 'Football, Sports', 'studio': 'ReFooty'}, is_folder=True,
        )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _refooty_countries():
    for label, (slug, _leagues) in refooty_mod.COUNTRIES.items():
        _add_directory(
            f'[B]{label}[/B]', build_url(action='refooty_leagues', country=slug),
            thumb=_menu_icon('sports'), fanart=FANART,
            info={'title': label, 'genre': 'Football, Sports', 'studio': 'ReFooty'}, is_folder=True,
        )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _refooty_leagues(country):
    for label, (slug, leagues) in refooty_mod.COUNTRIES.items():
        if slug != country:
            continue
        for league in leagues:
            league_slug = re.sub(r'[^a-z0-9]+', '-', league.casefold()).strip('-')
            url = f'{refooty_mod.BASE_URL}{slug}/{league_slug}'
            _add_directory(
                f'[B]{league}[/B]', build_url(action='refooty_category', url=url, page='1'),
                thumb=_menu_icon('sports'), fanart=FANART,
                info={'title': league, 'genre': 'Football, Sports', 'studio': 'ReFooty'}, is_folder=True,
            )
        break
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _refooty_category(url, page=1):
    try:
        matches = refooty_mod._video_catalogue(url, page=page)
    except Exception as exc:
        xbmc.log(f'COSMOS ReFooty category: {exc}', xbmc.LOGWARNING)
        matches = []
    for title, video_url in matches[:12]:
        info = refooty_mod.metadata(video_url, title)
        li = xbmcgui.ListItem(label=title)
        poster = info.get('thumb') or _menu_icon('sports')
        li.setArt({'icon': poster, 'thumb': poster, 'fanart': info.get('fanart') or FANART})
        li.setInfo('video', info)
        xbmcplugin.addDirectoryItem(
            _handle(), build_url(action='refooty_play', page=video_url, title=title),
            li, isFolder=False,
        )
    if len(matches) >= 12:
        _add_directory('[COLOR cyan][B]Next Page »[/B][/COLOR]',
                       build_url(action='refooty_category', url=url, page=str(int(page) + 1)),
                       thumb=_menu_icon('sports'), is_folder=True)
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _refooty_full_matches(page=1):
    try:
        page = max(int(page or 1), 1)
    except (TypeError, ValueError):
        page = 1
    # ReFooty currently returns 12 cards per load-more batch.
    page_size = 12
    try:
        matches = refooty_mod.full_matches(page=page)
    except Exception as exc:
        xbmc.log(f'COSMOS ReFooty: {exc}', xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('ReFooty', 'Unable to load full matches',
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        matches = []
    visible = matches[:page_size]
    for title, url in visible:
        info = refooty_mod.metadata(url, title)
        li = xbmcgui.ListItem(label=title)
        poster = info.get('thumb') or _menu_icon('sports')
        li.setArt({'icon': poster, 'thumb': poster, 'fanart': info.get('fanart') or FANART})
        li.setInfo('video', info)
        xbmcplugin.addDirectoryItem(
            _handle(), build_url(action='refooty_play', page=url, title=title),
            li, isFolder=False,
        )
    if len(matches) >= page_size:
        _add_directory(
            '[COLOR cyan][B]Next Page »[/B][/COLOR]',
            build_url(action='refooty_full_matches', page=str(page + 1)),
            thumb=_menu_icon('sports'), fanart=FANART, is_folder=True,
        )
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _refooty_latest(page=1):
    try:
        page = max(int(page or 1), 1)
    except (TypeError, ValueError):
        page = 1
    try:
        matches = refooty_mod.latest_highlights(page=page)
    except Exception as exc:
        xbmc.log(f'COSMOS ReFooty highlights: {exc}', xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('ReFooty', 'Unable to load latest highlights',
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        matches = []
    for title, url in matches[:12]:
        info = refooty_mod.metadata(url, title)
        li = xbmcgui.ListItem(label=title)
        poster = info.get('thumb') or _menu_icon('sports')
        li.setArt({'icon': poster, 'thumb': poster, 'fanart': info.get('fanart') or FANART})
        li.setInfo('video', info)
        xbmcplugin.addDirectoryItem(
            _handle(), build_url(action='refooty_play', page=url, title=title),
            li, isFolder=False,
        )
    if len(matches) >= 12:
        _add_directory(
            '[COLOR cyan][B]Next Page »[/B][/COLOR]',
            build_url(action='refooty_latest', page=str(page + 1)),
            thumb=_menu_icon('sports'), fanart=FANART, is_folder=True,
        )
    xbmcplugin.setContent(_handle(), 'videos')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── Tools menu ───────────────────────────────────────────────────────────

def _tools_menu(feed_url):
    xbmcplugin.setContent(_handle(), 'files')
    _add_directory(
        '[COLOR springgreen][B]Scan Newly Added Now[/B][/COLOR]',
        build_url(action='newly_added_scan', feed=feed_url),
        thumb=_menu_icon('newly_added'), is_folder=False,
        info={'title': 'Scan Newly Added Now',
              'plot': 'Check Enigma feeds now for new films, shows and episodes.'},
    )
    _add_directory(
        '[COLOR deepskyblue][B]Speedtest[/B][/COLOR]  '
        '[COLOR grey]Test ping, download, and upload speed[/COLOR]',
        build_url(action='ookla_speedtest'),
        thumb=_menu_icon('tools'), is_folder=False,
    )
    _add_directory(
        '[COLOR cyan][B]Install InputStream Adaptive[/B][/COLOR]  '
        '[COLOR grey]Install the Kodi HLS playback component[/COLOR]',
        build_url(action='install_inputstream_adaptive'),
        thumb=_menu_icon('tools'), is_folder=False,
    )
    if xbmc.getCondVisibility('System.Platform.Windows'):
        _add_directory(
            '[COLOR cyan][B]InputStream Helper[/B][/COLOR]  '
            '[COLOR grey]Install or repair the Windows Widevine CDM[/COLOR]',
            build_url(action='inputstream_helper_windows'),
            thumb=_menu_icon('tools'), is_folder=False,
        )
    _add_directory(
        '[COLOR lime][B]Debrid Account Status[/B][/COLOR]  '
        '[COLOR grey]Check provider status and days remaining[/COLOR]',
        build_url(action='debrid_account_status'),
        thumb=_menu_icon('tools'), is_folder=False,
    )
    _add_directory(
        '[COLOR cyan][B]Playlist health checker[/B][/COLOR]  '
        '[COLOR grey]Find broken entries, duplicates, and expired links[/COLOR]',
        build_url(action='playlist_health_check', feed=feed_url),
        thumb=_menu_icon('tools'), is_folder=False,
    )
    _add_directory(
        '[COLOR deepskyblue]View last playlist health report[/COLOR]',
        build_url(action='playlist_health_report'),
        thumb=_menu_icon('tools'), is_folder=False,
    )
    _add_directory(
        '[COLOR orangered][B]Dead-link checker[/B][/COLOR]  '
        '[COLOR grey]Probe every non-debrid URL[/COLOR]',
        build_url(action='dead_link_check', feed=feed_url),
        thumb=_menu_icon('tools'), is_folder=False,
    )
    _add_directory(
        '[COLOR cyan]View last dead-link report[/COLOR]',
        build_url(action='dead_link_report'),
        thumb=_menu_icon('tools'), is_folder=False,
    )
    _add_directory(
        '[COLOR lime]Auto-Sync now (gofile.io)[/COLOR]',
        build_url(action='sync_auto_now'),
        thumb=_menu_icon('tools'), is_folder=False,
    )
    _add_directory(
        '[COLOR yellow][B]Clear Cache[/B][/COLOR]',
        build_url(action='clear_cache'),
        thumb=_menu_icon('clearcache'), is_folder=False,
    )
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _debrid_account_status():
    """Open the Cosmos-themed live debrid account status dialog."""
    debrid_status_ui_mod.show()


def _inputstream_helper_windows():
    """Run InputStream Helper's Windows Widevine check/repair."""
    if not xbmc.getCondVisibility('System.Platform.Windows'):
        return
    addon_id = 'script.module.inputstreamhelper'
    if not xbmc.getCondVisibility('System.HasAddon(%s)' % addon_id):
        xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
        xbmcgui.Dialog().notification(
            'InputStream Helper',
            'Installation requested. Reopen Tools when installation finishes.',
            xbmcgui.NOTIFICATION_INFO, 5000)
        return
    try:
        import inputstreamhelper
        helper = inputstreamhelper.Helper('mpd', drm='com.widevine.alpha')
        if helper.check_inputstream():
            xbmcgui.Dialog().notification(
                'InputStream Helper', 'Widevine CDM is ready for Plex playback.',
                xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception as exc:
        xbmc.log('COSMOS: InputStream Helper Widevine check failed: %s' % exc,
                 xbmc.LOGWARNING)
        xbmc.executebuiltin('Addon.OpenSettings(%s)' % addon_id)


def _trailers_root():
    """List trailer categories pulled from TMDB."""
    cats = [
        ('Popular Movies', 'movie/popular'),
        ('Upcoming Movies', 'movie/upcoming'),
        ('Now Playing Movies', 'movie/now_playing'),
        ('Top Rated Movies', 'movie/top_rated'),
        ('Popular TV Shows', 'tv/popular'),
        ('Top Rated TV Shows', 'tv/top_rated'),
    ]
    for label, endpoint in cats:
        _add_directory(
            f'[COLOR deepskyblue]{label}[/COLOR]',
            build_url(action='trailers_list', endpoint=endpoint),
            thumb=ICON, is_folder=True,
        )
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _trailers_list(endpoint):
    """List entries from a TMDB discovery endpoint — each one plays its trailer."""
    import json as _json
    key = (ADDON.getSetting('tmdb_api_key') or tmdb_mod.DEFAULT_API_KEY).strip()
    if not key:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'TMDB API key missing (Settings → General)',
            xbmcgui.NOTIFICATION_WARNING, 5000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    is_tv = endpoint.startswith('tv/')
    body = parser.fetch_url(
        f'https://api.themoviedb.org/3/{endpoint}?api_key={key}&page=1&language=en-US'
    )
    try:
        data = _json.loads(body or '{}')
    except ValueError:
        data = {}
    results = data.get('results') or []
    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No trailers found',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    for r in results:
        tmdb_id = str(r.get('id') or '')
        name = r.get('title') or r.get('name') or 'Untitled'
        date = r.get('release_date') or r.get('first_air_date') or ''
        year = date[:4] if date else ''
        label = f'{name} ({year})' if year else name
        poster = r.get('poster_path') or ''
        backdrop = r.get('backdrop_path') or ''
        thumb = f'https://image.tmdb.org/t/p/w500{poster}' if poster else ICON
        fanart = f'https://image.tmdb.org/t/p/original{backdrop}' if backdrop else FANART

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(label)
            tag.setPlot(r.get('overview') or '')
            tag.setMediaType('movie' if not is_tv else 'tvshow')
            if year and year.isdigit():
                tag.setYear(int(year))
        except Exception:
            pass
        li.setProperty('IsPlayable', 'true')

        play_url = build_url(
            action='play_trailer',
            tmdb=tmdb_id,
            content=('tvshow' if is_tv else 'movie'),
        )
        xbmcplugin.addDirectoryItem(_handle(), play_url, li, isFolder=False)

    xbmcplugin.setContent(_handle(), 'movies')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _play_trailer(tmdb_id, content):
    """Resolve a TMDB video -> YouTube key, then hand off to plugin.video.youtube.

    Called via RunPlugin so _handle() is -1 — we must NOT call setResolvedUrl.
    Instead we use xbmc.executebuiltin to launch the YouTube plugin directly.
    Compatible with both the standard and SlyGuy builds of plugin.video.youtube.
    """
    import json as _json
    key = (ADDON.getSetting('tmdb_api_key') or tmdb_mod.DEFAULT_API_KEY).strip()
    if not key or not tmdb_id:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'TMDB key / id missing',
                                      xbmcgui.NOTIFICATION_ERROR, 3500)
        return
    kind = 'tv' if content == 'tvshow' else 'movie'
    body = parser.fetch_url(
        f'https://api.themoviedb.org/3/{kind}/{tmdb_id}/videos?api_key={key}&language=en-US'
    )
    try:
        data = _json.loads(body or '{}')
    except ValueError:
        data = {}
    yt_key = ''
    for v in data.get('results') or []:
        if (v.get('site') or '').lower() == 'youtube' and (v.get('type') or '').lower() == 'trailer':
            yt_key = v.get('key') or ''
            if yt_key:
                break
    if not yt_key:
        # fall back to first YouTube result of any type
        for v in data.get('results') or []:
            if (v.get('site') or '').lower() == 'youtube' and v.get('key'):
                yt_key = v['key']
                break
    if not yt_key:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No trailer found on TMDB',
                                      xbmcgui.NOTIFICATION_INFO, 3500)
        return

    # Use PlayMedia (not RunPlugin) so Kodi triggers the full playback chain —
    # PlayMedia calls the YouTube plugin and lets it setResolvedUrl correctly.
    # Compatible with the standard and SlyGuy builds of plugin.video.youtube.
    yt_url = f'plugin://plugin.video.youtube/play/?video_id={yt_key}'
    xbmc.log(f'COSMOS: playing trailer: {yt_url}', xbmc.LOGINFO)
    xbmc.executebuiltin(f'PlayMedia({yt_url})')


# ── Actor / person search (TMDB → cross-reference the crawled index) ─────

def _actor_search(feed_url, person_query):
    """Search TMDB for a person, list their credits, keep only items whose
    tmdb id is present in the addon's crawled index so every result is
    actually playable inside COSMOS."""
    import json as _json
    key = (ADDON.getSetting('tmdb_api_key') or tmdb_mod.DEFAULT_API_KEY).strip()
    if not key:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'TMDB API key missing (Settings → General)',
            xbmcgui.NOTIFICATION_WARNING, 5000,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    # Step 1: person search
    from urllib.parse import quote_plus
    body = parser.fetch_url(
        f'https://api.themoviedb.org/3/search/person?api_key={key}'
        f'&query={quote_plus(person_query)}&page=1'
    )
    try:
        data = _json.loads(body or '{}')
    except ValueError:
        data = {}
    people = data.get('results') or []
    if not people:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', f'No person matching "{person_query}"',
            xbmcgui.NOTIFICATION_INFO, 3500,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    if len(people) == 1:
        picked = people[0]
    else:
        labels = [f'{p.get("name","?")} — {p.get("known_for_department","?")}'
                  for p in people[:15]]
        idx = xbmcgui.Dialog().select('Select person', labels)
        if idx < 0:
            xbmcplugin.endOfDirectory(_handle(), succeeded=False)
            return
        picked = people[idx]

    pid = picked.get('id')
    if not pid:
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    # Step 2: combined credits
    cbody = parser.fetch_url(
        f'https://api.themoviedb.org/3/person/{pid}/combined_credits?api_key={key}'
    )
    try:
        cdata = _json.loads(cbody or '{}')
    except ValueError:
        cdata = {}
    credits = (cdata.get('cast') or []) + (cdata.get('crew') or [])
    if not credits:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No credits on TMDB',
                                      xbmcgui.NOTIFICATION_INFO, 3500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    # Step 3: ensure we have the crawled index so we can filter by playability
    cached = search_mod._load_cache()
    need_crawl = not cached or cached.get('base') != feed_url
    if need_crawl:
        dlg = xbmcgui.DialogProgressBG()
        dlg.create('C.O.S.M.O.S', 'Indexing playlists for search...')

        def _cb(count, label):
            pct = min(95, count * 2)
            dlg.update(pct, 'C.O.S.M.O.S', f'Scanning #{count}: {label[:60]}')

        try:
            cached = search_mod.get_index(feed_url, force_refresh=True,
                                          progress_cb=_cb)
        finally:
            dlg.close()
    index_by_tmdb = {}
    for it in (cached or {}).get('items') or []:
        t = str(it.get('tmdb') or '')
        if t:
            index_by_tmdb[t] = it

    # Step 4: keep only credits present in our feed, dedupe by tmdb id
    matched = []
    seen_ids = set()
    for c in credits:
        tid = str(c.get('id') or '')
        if not tid or tid in seen_ids:
            continue
        if tid not in index_by_tmdb:
            continue
        seen_ids.add(tid)
        matched.append((c, index_by_tmdb[tid]))

    if not matched:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S',
            f'No "{picked.get("name","?")}" items in your playlists',
            xbmcgui.NOTIFICATION_INFO, 4500,
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    for c, it in matched:
        tmdb_id = str(c.get('id') or '')
        content = it.get('content') or ('tvshow' if c.get('media_type') == 'tv' else 'movie')
        meta = tmdb_mod.get_metadata(tmdb_id, content) if tmdb_id else {}
        name = parser.strip_bbcode(it.get('name', '')) or meta.get('title') or 'Untitled'
        year = meta.get('year') or parser.extract_year(it.get('name', ''))
        label_title = meta.get('title') or name
        label = f'{label_title} ({year})' if year else label_title
        li = xbmcgui.ListItem(label=label)
        tmdb_mod.apply_to_listitem(li, meta, content)
        thumb = meta.get('poster') or it.get('thumb') or ICON
        fanart = meta.get('fanart') or FANART
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fanart})

        if content == 'tvshow':
            tv_payload = _json.dumps({
                'feed': it.get('feed', ''), 'tmdb': tmdb_id,
                'title': label_title, 'name': label_title, 'content': 'tvshow',
                'imdb': (meta or {}).get('imdb_id', ''),
                'thumb': thumb, 'fanart': fanart,
            })
            _set_ctx(li,
                     _fav_ctx_items(tv_payload, tmdb_id, 'tvshow', label_title),
                     _info_ctx_items(label_title, tmdb_id, 'tvshow', thumb, fanart),
                     _scrobbler_ctx_items(tv_payload, tmdb_id, 'tvshow', label_title),
                     _extras_ctx_items(label_title, tmdb_id, 'tvshow', thumb, fanart),
                     _trailer_ctx_items(tmdb_id, 'tvshow'),
                     _local_tvshow_ctx_items(tmdb_id, label_title),
                     _opensubtitles_ctx_items(tv_payload, tmdb_id, 'tvshow', label_title))
            url = build_url(action='tv_seasons', feed=it.get('feed', ''), tmdb=tmdb_id)
            xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)
        else:
            tagged_links = [
                {'label': search_mod._label_for_link(lk.get('label'), lk.get('url')),
                 'url': lk.get('url', '')}
                for lk in (it.get('links') or [])
            ]
            payload = _json.dumps({
                'title': label_title,
                'tmdb': tmdb_id,
                'content': content,
                'season': it.get('season'),
                'episode': it.get('episode'),
                'links': tagged_links,
                'imdb': (meta or {}).get('imdb_id', ''),
                'year': year or 0,
                'poster': thumb,
                'fanart': fanart,
            })
            url = build_url(action='show_links', payload=payload)
            _set_ctx(li,
                     _fav_ctx_items(payload, tmdb_id, content, label_title),
                     _info_ctx_items(label_title, tmdb_id, content, thumb, fanart),
                     _scrobbler_ctx_items(payload, tmdb_id, content, label_title),
                     _extras_ctx_items(label_title, tmdb_id, content, thumb, fanart),
                     _trailer_ctx_items(tmdb_id, content),
                     _opensubtitles_ctx_items(payload, tmdb_id, content, label_title),
                     _direct_link_download_ctx_items(payload))
            xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)

    xbmcplugin.setContent(_handle(), 'movies')
    xbmcplugin.addSortMethod(_handle(), xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── Link Zero: scraper-based source picker ───────────────────────────────

_SIZE_RE = __import__('re').compile(
    r'\b(\d+(?:\.\d+)?)\s*(GB|GiB|MB|MiB)\b', __import__('re').IGNORECASE)


def _extract_size_label(title):
    """Best-effort file-size label pulled from a scraper result title."""
    m = _SIZE_RE.search(title or '')
    if not m:
        return ''
    unit = m.group(2).upper().replace('IB', 'B')
    return f'{m.group(1)} {unit}'


_NON_VIDEO_RESOLVED_EXTENSIONS = {
    '.txt', '.nfo', '.md', '.html', '.htm', '.xml', '.json',
    '.jpg', '.jpeg', '.png', '.gif', '.webp',
    '.srt', '.sub', '.ass', '.ssa', '.vtt',
    '.torrent', '.zip', '.rar', '.7z',
}


def _is_plausible_video_url(stream_url):
    """Reject resolved metadata/assets while allowing extensionless streams."""
    if not stream_url:
        return False
    raw_url = str(stream_url).split('|', 1)[0]
    try:
        path = unquote(urlsplit(raw_url).path).lower().rstrip('/')
    except (TypeError, ValueError):
        path = raw_url.lower().split('?', 1)[0]
    leaf = path.rsplit('/', 1)[-1]
    extension = ('.' + leaf.rsplit('.', 1)[-1]) if '.' in leaf else ''
    return extension not in _NON_VIDEO_RESOLVED_EXTENSIONS


def _link_zero_filehost_sources(title, year, content, season=None, episode=None):
    """Find optional Rapidgator/Nitroflare mirrors for Link Zero.

    DDLValley and RlsBB already provide the add-on's supported Rapidgator and
    Nitroflare discovery paths. Their links are only added when the matching
    premium credentials exist, and the actual resolution remains delegated to
    ResolveURL through ``filehost.resolve_filehost_link``. This keeps ordinary
    Link Zero searches fast for users who do not use file-host accounts.
    """
    rg_authorized = bool(
        (ADDON.getSetting('rapidgator_username') or '').strip() and
        (ADDON.getSetting('rapidgator_password') or '').strip()
    )
    nf_authorized = bool(
        (ADDON.getSetting('nitroflare_username') or '').strip() and
        (ADDON.getSetting('nitroflare_password') or '').strip()
    )
    if not rg_authorized and not nf_authorized:
        return []

    query = str(title or '').strip()
    if year:
        query += f' {year}'
    if content != 'movie' and season is not None and episode is not None:
        try:
            query += f' S{int(season):02d}E{int(episode):02d}'
        except (TypeError, ValueError):
            query += f' S{season}E{episode}'
    query = query.strip()
    if not query:
        return []

    from concurrent.futures import ThreadPoolExecutor, as_completed
    from . import scrapers as _scr

    def _listing(kind):
        if kind == 'DDLValley':
            items, _has_next = ddlv_mod.get_items_for_search(query, page=1)
        else:
            items, _has_next = rlsbb_mod.get_search_results(query, page=1)
        return items or []

    listings = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = {pool.submit(_listing, kind): kind for kind in ('DDLValley', 'RlsBB')}
        for future in as_completed(futures):
            try:
                listings.extend(future.result()[:6])
            except Exception as exc:
                xbmc.log(
                    f'COSMOS Link Zero: {futures[future]} file-host search failed: {exc}',
                    xbmc.LOGDEBUG,
                )

    # Avoid scraping the same release twice when both indexes expose it.
    seen_posts = set()
    unique_listings = []
    for item in listings:
        post_url = str(item.get('link') or '').strip()
        if not post_url or post_url in seen_posts:
            continue
        seen_posts.add(post_url)
        unique_listings.append(item)
    unique_listings = unique_listings[:8]

    def _detail(item):
        url = item.get('link') or ''
        if 'rlsbb' in url.lower():
            return rlsbb_mod.scrape_detail(url)
        return ddlv_mod.scrape_detail(url)

    direct_sources = []
    seen_links = set()

    def _same_number(left, right):
        try:
            return int(left) == int(right)
        except (TypeError, ValueError):
            return str(left or '').strip() == str(right or '').strip()

    with ThreadPoolExecutor(max_workers=min(6, max(1, len(unique_listings)))) as pool:
        futures = {pool.submit(_detail, item): item for item in unique_listings}
        for future in as_completed(futures):
            try:
                detail = future.result() or {}
            except Exception as exc:
                xbmc.log(f'COSMOS Link Zero: file-host detail failed: {exc}', xbmc.LOGDEBUG)
                continue

            detail_content = str(detail.get('content') or '').lower()
            if content == 'movie':
                if detail_content and detail_content != 'movie':
                    continue
            elif season is not None and episode is not None:
                if not _same_number(detail.get('season'), season) or not _same_number(detail.get('episode'), episode):
                    continue

            detail_title = detail.get('title') or title or 'File-host source'
            detail_quality = detail.get('quality') or ''
            for link in detail.get('links') or []:
                host = str(link.get('host') or '').strip()
                url = str(link.get('url') or '').strip()
                host_lower = host.lower()
                if not url or url in seen_links:
                    continue
                if host_lower == 'rapidgator' and not rg_authorized:
                    continue
                if host_lower == 'nitroflare' and not nf_authorized:
                    continue
                if host_lower not in ('rapidgator', 'nitroflare'):
                    continue
                seen_links.add(url)
                # SourceFinder buckets require the canonical values
                # (2160p/1080p/720p/480p/360p), not labels such as
                # "1080p BluRay" returned by the release scrapers.
                quality = _scr.detect_quality(
                    f'{detail_title} {link.get("quality") or detail_quality}'
                )
                display_title = f'{detail_title} [{host}]'
                direct_sources.append({
                    'title': display_title,
                    'display_title': display_title,
                    'display_meta': f'{host}  ·  Premium account',
                    'source': host,
                    'quality': quality,
                    'seeds': 0,
                    'cached': False,
                    'magnet': '',
                    'url': url,
                    'filehost': True,
                })
    return direct_sources


def _link_zero(payload_json, auto_next=False):
    """Find sources via torrent scrapers for the current item, then let the
    user filter by quality (Source Finder) and pick a specific link (Link
    Picker) before playing through the normal debrid pipeline. Automatic
    continuation selects a viable source when next-episode autoplay is enabled."""
    import json as _json
    from . import scrapers as _scr
    try:
        data = _json.loads(payload_json or '{}')
    except ValueError:
        data = {}

    title = data.get('title') or 'Untitled'
    year = str(data.get('year') or '')
    imdb = str(data.get('imdb') or '')
    tmdb = str(data.get('tmdb') or '')
    content = data.get('content') or 'movie'
    season = data.get('season')
    episode = data.get('episode')
    if season == '':
        season = None
    if episode == '':
        episode = None

    # Link Zero payloads may not have a resolved URL, so offer the same
    # configurable resume choice before source discovery begins.
    if not auto_next and not data.get('resume_key') and data.get('tmdb'):
        resume_row = _resume_row_for_payload(data)
        if resume_row:
            choice = _resume_prompt_choice(data.get('title'), resume_row.get('pos', 0))
            if choice is True:
                data['resume_key'] = resume_row.get('key', '')
            elif choice is False:
                # A non-empty sentinel prevents the later source-resolution
                # code from finding the same resume row again.
                data['resume_key'] = '__cosmos_skip_resume__'

    if title == 'Untitled' and not year and not imdb and not tmdb:
        xbmc.log(
            f'COSMOS [ERROR] link_zero: insufficient metadata for search. Payload: {payload_json}',
            xbmc.LOGERROR,
        )
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Not enough info to find sources',
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return

    xbmc.log(
        f'COSMOS [FLOW] link_zero  title={title!r}  year={year!r}'
        f'  imdb={imdb!r}  tmdb={tmdb!r}'
        f'  content={content!r}  season={season!r}  episode={episode!r}',
        xbmc.LOGDEBUG,
    )

    # If no IMDB id was stored in the payload (e.g. TMDB metadata fetch failed
    # at browse time), do a quick direct fetch now — all three IMDB scrapers
    # (Torrentio, Comet, MediaFusion) silently skip when imdb is empty.
    if not imdb and tmdb:
        try:
            _fallback_meta = tmdb_mod.get_metadata(tmdb, content)
            imdb = _fallback_meta.get('imdb_id') or ''
            if imdb:
                xbmc.log(f'COSMOS: Link Zero fetched IMDB id {imdb} for TMDB {tmdb}', xbmc.LOGDEBUG)
        except Exception as _fe:
            xbmc.log(f'COSMOS: Link Zero IMDB fallback failed: {_fe}', xbmc.LOGWARNING)

    dlg = xbmcgui.DialogProgressBG()
    dlg.create('C.O.S.M.O.S', f'Link Zero — searching sources for {title}')
    try:
        results = _scr.search_all(
            f'{title} {year}'.strip(),
            preferred_quality='1080p',
            imdb_id=imdb,
            content=content,
            season=season,
            episode=episode,
        )
    except Exception as e:
        xbmc.log(f'COSMOS: Link Zero scrape failed: {e}', xbmc.LOGERROR)
        results = []
    finally:
        dlg.close()

    try:
        filehost_sources = _link_zero_filehost_sources(
            title, year, content, season=season, episode=episode,
        )
        if filehost_sources:
            xbmc.log(
                f'COSMOS [FLOW] link_zero  adding {len(filehost_sources)} '
                'premium file-host sources',
                xbmc.LOGDEBUG,
            )
            results.extend(filehost_sources)
    except Exception as exc:
        xbmc.log(f'COSMOS Link Zero: premium file-host source step failed: {exc}', xbmc.LOGDEBUG)

    xbmc.log(f'COSMOS [FLOW] link_zero  scrape returned {len(results)} results', xbmc.LOGDEBUG)

    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Link Zero: no sources found',
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return

    # Debrid cache check for a nicer picker. RD's old batch instant-
    # availability endpoint is dead, so pre-sort by seeds first, then do a
    # real (add/check/cleanup) cache probe on the top candidates only -
    # that's the only way left to get an accurate cached flag from RD.
    hashes = []
    for r in results:
        h = _scr.extract_hash(r.get('magnet', ''))
        if h:
            hashes.append(h)
            r['hash'] = h
    try:
        cached_set = debrid.check_cache_all(hashes) if hashes else set()
    except Exception:
        cached_set = set()
    xbmc.log(
        f'COSMOS [FLOW] link_zero  cache check  hashes={len(hashes)}'
        f'  cached_hits={len(cached_set)}',
        xbmc.LOGDEBUG,
    )
    for r in results:
        if r.get('hash', '').lower() in cached_set:
            r['cached'] = True

    results.sort(key=lambda s: -(s.get('seeds', 0) or 0))
    results = results[:300]

    try:
        debrid.probe_realtime_cache(results, limit=15)
    except Exception as e:
        xbmc.log(f'COSMOS: Link Zero realtime cache probe failed: {e}', xbmc.LOGDEBUG)

    # Cached links first, then by seeds.
    results.sort(key=lambda s: (0 if s.get('cached') else 1, -(s.get('seeds', 0) or 0)))

    for r in results:
        cached_label = 'Cached' if r.get('cached') else 'Uncached'
        size_label = r.get('size_label') or _extract_size_label(r.get('title', ''))
        if r.get('filehost'):
            meta_bits = [r.get('source', '?'), 'Premium account']
        else:
            meta_bits = [r.get('source', '?'), f"{r.get('seeds', 0)} seeds", cached_label]
        if size_label:
            meta_bits.insert(1, size_label)
        r['display_title'] = (r.get('title') or 'Untitled').replace('|', '·')[:100]
        r['display_meta'] = '  ·  '.join(meta_bits)

    # --- APPENDED: Auto-Play Logic (Bypasses Source Finder if enabled) ---
    is_autoplay = (ADDON.getSetting('autoplay_enabled') or 'false').lower() == 'true'
    auto_next_mode = auto_next and content == 'episode'
    if auto_next_mode:
        is_autoplay = resume_mod.autoplay_next_episode_enabled()
    if is_autoplay and (content in ('movie', 'episode') or (content == 'tvshow' and data.get('season') is not None and data.get('episode') is not None)):
        xbmc.log('COSMOS: Auto-Play is ON. Bypassing Source Finder.', xbmc.LOGINFO)
        for attempt in results:
            # Automatic next-episode playback may use the first viable
            # Link Zero result when no cached result exists. This keeps the
            # handoff automatic while preserving Link Zero's normal ordering.
            if attempt.get('cached') or auto_next_mode or attempt.get('source') == 'EasyNews':
                if attempt.get('source') == 'EasyNews' and attempt.get('url'):
                    stream_url, name = filehost.resolve_filehost_link(attempt['url'])
                elif attempt.get('filehost') and attempt.get('url'):
                    stream_url, name = filehost.resolve_filehost_link(attempt.get('url', ''))
                else:
                    magnet = attempt.get('magnet', '')
                    if not magnet:
                        continue
                    stream_url, name = debrid.resolve_magnet(magnet)
                if stream_url and not _is_plausible_video_url(stream_url):
                    xbmc.log(
                        f'COSMOS [ERROR] link_zero rejected non-video URL from '
                        f'{attempt.get("source")!r}: {str(stream_url).split("?", 1)[0]}',
                        xbmc.LOGERROR,
                    )
                    stream_url = None
                if stream_url:
                    resume_label = attempt.get('display_title') or attempt.get('title') or data.get('title') or 'Unknown Source'
                    playback_url = (attempt.get('url', '') if attempt.get('filehost') or attempt.get('source') == 'EasyNews'
                                    else attempt.get('magnet', ''))
                    rkey = resume_mod.key_for(
                        tmdb=data.get('tmdb'), content=data.get('content'),
                        season=data.get('season'), episode=data.get('episode'),
                        label=resume_label, url=playback_url,
                    )
                    
                    seek_to = 0
                    resume_key_to_clear = data.get('resume_key', '')
                    if resume_key_to_clear:
                        res_info = resume_mod.get(resume_key_to_clear)
                        if res_info:
                            seek_to = res_info[0]
                    elif data.get('tmdb'):
                        for r_item in resume_mod.list_recent(limit=50):
                            if (str(r_item.get('tmdb')) == str(data.get('tmdb')) and
                                str(r_item.get('content')) == str(data.get('content', 'movie')) and
                                str(r_item.get('season', '')) == str(data.get('season', '')) and
                                str(r_item.get('episode', '')) == str(data.get('episode', ''))):
                                res_info = resume_mod.get(r_item.get('key'))
                                if res_info:
                                    seek_to = res_info[0]
                                    resume_key_to_clear = r_item.get('key')
                                break
                                
                    if resume_key_to_clear and resume_key_to_clear != rkey:
                        resume_mod.clear(resume_key_to_clear)

                    meta = {
                        'title': data.get('title', ''), 'content': _normalise_playback_content(data),
                        'tmdb': str(data.get('tmdb') or ''), 'season': str(data.get('season') if data.get('season') is not None else ''),
                        'episode': str(data.get('episode') if data.get('episode') is not None else ''), 'label': resume_label,
                        'episode_title': str(data.get('episode_title') or ''),
                        'ids': dict(data.get('ids')) if isinstance(data.get('ids'), dict) else {},
                        'url': playback_url, 'poster': data.get('poster', ''),
                        'fanart': data.get('fanart', ''), 'year': str(data.get('year') or ''),
                        'imdb': str(data.get('imdb') or ''),
                        'simkl': str(data.get('simkl') or data.get('simkl_id') or ''),
                        'tvdb': str(data.get('tvdb') or data.get('tvdb_id') or ''),
                        'mal': str(data.get('mal') or data.get('mal_id') or ''),
                        'anidb': str(data.get('anidb') or data.get('anidb_id') or ''),
                        'anilist': str(data.get('anilist') or data.get('anilist_id') or ''),
                        'kitsu': str(data.get('kitsu') or data.get('kitsu_id') or ''),
                        'feed': data.get('feed', ''),
                        'return_url': data.get('return_url', ''),
                    }
                    meta['anime_numbering'] = data.get('anime_numbering', '')
                    resume_mod.start_tracker(rkey, seek_to=seek_to, meta=meta)

                    xbmcgui.Dialog().notification('C.O.S.M.O.S', f'Playing via {name} [{attempt.get("quality","?")}]', xbmcgui.NOTIFICATION_INFO, 2500)
                    if '|' in stream_url:
                        url_part, header_part = stream_url.split('|', 1)
                        li = xbmcgui.ListItem(path=url_part)
                        li.setMimeType('video/mp4')
                        li.setContentLookup(False)
                        li.setProperty('inputstream.adaptive.stream_headers', header_part)
                    else:
                        li = xbmcgui.ListItem(path=stream_url)
                        
                    if auto_next:
                        xbmc.Player().play(stream_url, li)
                    else:
                        xbmcplugin.setResolvedUrl(_handle(), True, li)
                    opensubtitles_mod.auto_apply_for_playback(meta)
                    return
    xbmc.log(
        f'COSMOS [FLOW] link_zero  opening Source Finder  total={len(results)}'
        f'  cached={sum(1 for r in results if r.get("cached"))}',
        xbmc.LOGDEBUG,
    )
    picker_poster = data.get('show_poster') or data.get('poster') or data.get('thumb') or ''
    if not picker_poster and tmdb:
        try:
            from . import tmdb as picker_tmdb
            picker_meta = picker_tmdb.get_metadata(
                tmdb, 'movie' if content == 'movie' else 'tvshow') or {}
            picker_poster = picker_meta.get('poster') or ''
        except Exception as exc:
            xbmc.log(f'COSMOS Link Zero poster lookup failed: {exc}', xbmc.LOGDEBUG)
    pick = sf_mod.pick_link(
        title, results,
        quality_order=_scr.QUALITY_ORDER,
        bucket_of=lambda r: r.get('quality', '480p'),
        poster=picker_poster,
    )
    if not pick:
        xbmc.log('COSMOS [FLOW] link_zero  user cancelled Source Finder / Link Picker', xbmc.LOGDEBUG)
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return

    xbmc.log(
        f'COSMOS [FLOW] link_zero  user picked'
        f'  title={pick.get("title","")[:80]!r}'
        f'  quality={pick.get("quality")!r}'
        f'  source={pick.get("source")!r}'
        f'  seeds={pick.get("seeds")}  cached={pick.get("cached")}',
        xbmc.LOGDEBUG,
    )

    if pick.get('source') == 'EasyNews' and pick.get('url'):
        from . import usenet_clients
        queued, queue_message = usenet_clients.maybe_submit_result(pick, name=title)
        if queued:
            xbmcgui.Dialog().notification('C.O.S.M.O.S', queue_message,
                                          xbmcgui.NOTIFICATION_INFO, 4000)
            xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
            return
        stream_url, name = filehost.resolve_filehost_link(pick['url'])
    elif pick.get('filehost') and pick.get('url'):
        xbmc.log(
            f'COSMOS [FLOW] link_zero  resolving premium file-host source '
            f'via ResolveURL host={pick.get("source")!r}',
            xbmc.LOGDEBUG,
        )
        stream_url, name = filehost.resolve_filehost_link(pick.get('url', ''))
    else:
        stream_url, name = debrid.resolve_magnet(pick.get('magnet', ''))
    if stream_url and not _is_plausible_video_url(stream_url):
        xbmc.log(
            f'COSMOS [ERROR] link_zero rejected non-video URL from '
            f'{pick.get("source")!r}: {str(stream_url).split("?", 1)[0]}',
            xbmc.LOGERROR,
        )
        stream_url = None
    if not stream_url:
        xbmc.log(
            f'COSMOS [ERROR] link_zero  resolve_magnet failed'
            f'  quality={pick.get("quality")!r}  source={pick.get("source")!r}',
            xbmc.LOGERROR,
        )
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Link Zero: debrid resolve failed',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return

    # --- Start Resume Tracking ---
    resume_label = pick.get('display_title') or pick.get('title') or data.get('title') or 'Unknown Source'
    magnet_url = pick.get('magnet') or pick.get('url', '')

    rkey = resume_mod.key_for(
        tmdb=data.get('tmdb'), content=data.get('content'),
        season=data.get('season'), episode=data.get('episode'),
        label=resume_label, url=magnet_url,
    )
    
    # Check for existing resume position if resume_key was passed or can be found
    seek_to = 0
    resume_key_to_clear = data.get('resume_key', '')
    
    if resume_key_to_clear:
        res_info = resume_mod.get(resume_key_to_clear)
        if res_info:
            seek_to = res_info[0]
    elif data.get('tmdb'):
        for r_item in resume_mod.list_recent(limit=50):
            if (str(r_item.get('tmdb')) == str(data.get('tmdb')) and
                str(r_item.get('content')) == str(data.get('content', 'movie')) and
                str(r_item.get('season', '')) == str(data.get('season', '')) and
                str(r_item.get('episode', '')) == str(data.get('episode', ''))):
                res_info = resume_mod.get(r_item.get('key'))
                if res_info:
                    seek_to = res_info[0]
                    resume_key_to_clear = r_item.get('key')
                break

    if resume_key_to_clear and resume_key_to_clear != rkey:
        resume_mod.clear(resume_key_to_clear)

    meta = {
        'title': data.get('title', ''),
        'content': _normalise_playback_content(data),
        'tmdb': str(data.get('tmdb') or ''),
        'season': str(data.get('season') if data.get('season') is not None else ''),
        'episode': str(data.get('episode') if data.get('episode') is not None else ''),
        'episode_title': str(data.get('episode_title') or ''),
        'label': resume_label,
        'ids': dict(data.get('ids')) if isinstance(data.get('ids'), dict) else {},
        'url': magnet_url,
        'poster': data.get('poster', ''),
        'fanart': data.get('fanart', ''),
        'year': str(data.get('year') or ''),
        'imdb': str(data.get('imdb') or ''),
        'simkl': str(data.get('simkl') or data.get('simkl_id') or ''),
        'tvdb': str(data.get('tvdb') or data.get('tvdb_id') or ''),
        'mal': str(data.get('mal') or data.get('mal_id') or ''),
        'anidb': str(data.get('anidb') or data.get('anidb_id') or ''),
        'anilist': str(data.get('anilist') or data.get('anilist_id') or ''),
        'kitsu': str(data.get('kitsu') or data.get('kitsu_id') or ''),
        'feed': data.get('feed', ''),
        'return_url': data.get('return_url', ''),
    }
    meta['anime_numbering'] = data.get('anime_numbering', '')
    resume_mod.start_tracker(rkey, seek_to=seek_to, meta=meta)
    # --- End Resume Tracking ---
    xbmcgui.Dialog().notification(
        'C.O.S.M.O.S',
        f'Playing via {name} [{pick.get("quality","?")}]',
        xbmcgui.NOTIFICATION_INFO, 2500,
    )
    if '|' in stream_url:
        url_part, header_part = stream_url.split('|', 1)
        li = xbmcgui.ListItem(path=url_part)
        li.setMimeType('video/mp4')
        li.setContentLookup(False)
        li.setProperty('inputstream.adaptive.stream_headers', header_part)
    else:
        li = xbmcgui.ListItem(path=stream_url)
    if auto_next:
        xbmc.Player().play(stream_url, li)
    else:
        xbmcplugin.setResolvedUrl(_handle(), True, li)
    opensubtitles_mod.auto_apply_for_playback(meta)


def _show_changelog_if_updated(force=False):
    """Display an unmissable changelog modal when the installed version has
    changed since the last time the user saw it. The user must dismiss the
    custom release browser to continue. Runs once per version.
    """
    try:
        current = (ADDON.getAddonInfo('version') or '').strip()
    except Exception:
        current = ''
    if not current:
        return
    last_seen = (ADDON.getSetting('last_changelog_version') or '').strip()
    if last_seen == current and not force:
        return

    # Read bundled changelog.txt
    changelog_path = f'{ADDON_PATH}changelog.txt'
    body = ''
    try:
        if xbmcvfs.exists(changelog_path):
            f = xbmcvfs.File(changelog_path)
            try:
                body = f.read() or ''
            finally:
                f.close()
    except Exception as e:
        xbmc.log(f'COSMOS: changelog read failed: {e}', xbmc.LOGWARNING)

    if not body.strip():
        body = f'C.O.S.M.O.S v{current} installed. No changelog entries found.'

    footer = (
        '\n\n'
        '----------------------------------------\n'
        '-- COSMOS DEV out\n'
        '----------------------------------------\n'
    )
    text = body.rstrip() + footer

    heading = f'C.O.S.M.O.S v{current} - What\'s New'
    try:
        from .changelog_dialog import open_changelog
        open_changelog(ADDON_PATH, current, body)
    except Exception as e:
        xbmc.log(f'COSMOS: custom changelog failed, falling back: {e}', xbmc.LOGWARNING)
        try:
            xbmcgui.Dialog().textviewer(heading, text)
        except Exception:
            xbmcgui.Dialog().ok(heading, text[:4000])

    try:
        ADDON.setSetting('last_changelog_version', current)
    except Exception as e:
        xbmc.log(f'COSMOS: could not persist changelog version: {e}',
                 xbmc.LOGWARNING)


# ── Newly-Added scan + toast helpers ────────────────────────────────────

def _manual_scan_newly_added(home_url):
    """Force a fresh scan without waiting for the hourly schedule."""
    dialog = xbmcgui.DialogProgressBG()
    dialog.create('C.O.S.M.O.S', 'Scanning Newly Added — films, shows and episodes')
    try:
        result = na_mod.scan_feeds(home_url, force=True) or {}
        status = result.get('status')
        if status == 'busy':
            message = 'A Newly Added scan is already running'
        elif status == 'complete':
            message = 'Newly Added scan complete — open Newly Added to view results'
        elif status == 'partial':
            observed = result.get('observed', 0)
            message = (f'Scanned {observed} items; some feeds remain. Use Scan Now later or wait for the hourly scan'
                       if observed else 'No content scanned. Use Scan Now later or wait for the hourly scan')
        elif status == 'aborted':
            message = 'Newly Added scan stopped'
        else:
            message = 'Newly Added scan could not finish'
        icon = (xbmcgui.NOTIFICATION_INFO if status in ('busy', 'complete')
                else xbmcgui.NOTIFICATION_WARNING)
    except Exception as exc:
        xbmc.log(f'COSMOS newly_added manual scan failed: {exc}', xbmc.LOGWARNING)
        message = 'Newly Added scan failed — check the Kodi log'
        icon = xbmcgui.NOTIFICATION_ERROR
    finally:
        dialog.close()
    xbmcgui.Dialog().notification('C.O.S.M.O.S', message, icon, 5000)


def _maybe_scan_newly_added(home_url):
    """If more than an hour has passed since the last scan, spawn a background
    thread to refresh the newly-added tracker from all enigma XML feeds."""
    if not na_mod.should_scan():
        return
    import threading

    def _scan_and_notify():
        na_mod.scan_feeds(home_url)
        # Check after the background scan completes so a newly discovered
        # film or episode can be announced during this root-menu visit.
        _maybe_show_newly_added_toast()

    t = threading.Thread(target=_scan_and_notify, daemon=True)
    t.start()
    xbmc.log('COSMOS: newly_added hourly scan spawned', xbmc.LOGINFO)


def _maybe_show_newly_added_toast():
    na_mod.show_notification(ADDON)


# ── TMDB Movies & TV Shows browser ───────────────────────────────────────

def _tmdb_key():
    return (ADDON.getSetting('tmdb_api_key') or tmdb_mod.DEFAULT_API_KEY).strip()


def _tmdb_require_key():
    """Show a warning notification and return '' if no TMDB API key is set."""
    key = _tmdb_key()
    if not key:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'TMDB API key missing — add it in Settings → General',
            xbmcgui.NOTIFICATION_WARNING, 5000,
        )
    return key


def _submenu_icon(name):
    """Return icon path from resources/media/submenus/, fall back to main ICON."""
    path = f'{ADDON_PATH}resources/media/submenus/icon_{name}.png'
    return path if xbmcvfs.exists(path) else ICON


def _tmdb_fetch(endpoint, extra_params=None):
    """Fetch a TMDB v3 endpoint and return parsed JSON (or {} on error)."""
    import json as _json
    key = _tmdb_key()
    if not key:
        return {}
    sep = '&' if '?' in endpoint else '?'
    url = f'https://api.themoviedb.org/3/{endpoint}{sep}api_key={key}&language=en-US'
    if extra_params:
        from urllib.parse import urlencode as _ue
        url += '&' + _ue({k: v for k, v in extra_params.items() if v is not None})
    body = parser.fetch_url(url)
    try:
        return _json.loads(body or '{}')
    except ValueError:
        return {}


def _render_tmdb_results(results, content='movie', page=1, total_pages=1,
                          browse_action=None, browse_params=None):
    """Render a list of TMDB result dicts as Kodi directory items.

    Each item is rendered identically to _render_content(): it opens the
    standard show_links page, which presents Link Zero (all scrapers →
    SourceFinder.xml → LinkPicker.xml) at the top, exactly as every other
    section of the addon does.  No custom sub-menu is shown.
    """
    import json as _json
    is_tv = content in ('tvshow', 'tv')
    norm_content = 'tvshow' if is_tv else 'movie'

    for r in results:
        tmdb_id = str(r.get('id') or '')
        # Prefer enriched TMDB metadata (poster hi-res, imdb_id, full cast, etc.)
        # but fall back to whatever the search result already contains so the
        # list renders immediately even if the detail fetch is slow.
        meta = tmdb_mod.get_metadata(tmdb_id, norm_content) if tmdb_id else {}

        name = (meta.get('title') or r.get('title') or r.get('name') or 'Untitled')
        year = (meta.get('year')
                or (r.get('release_date') or r.get('first_air_date') or '')[:4]
                or '')
        label = f'{name} ({year})' if year else name
        label = _local_movie_label(label, tmdb_id, norm_content)

        poster_path = r.get('poster_path') or ''
        backdrop_path = r.get('backdrop_path') or ''
        raw_thumb = f'https://image.tmdb.org/t/p/w500{poster_path}' if poster_path else ICON
        raw_fan   = f'https://image.tmdb.org/t/p/original{backdrop_path}' if backdrop_path else FANART
        thumb = meta.get('poster') or raw_thumb
        fan   = meta.get('fanart') or raw_fan

        li = xbmcgui.ListItem(label=label)
        if meta:
            tmdb_mod.apply_to_listitem(li, meta, norm_content)
        else:
            # Minimal fallback art + info when metadata fetch was skipped/failed
            li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fan})
            try:
                tag = li.getVideoInfoTag()
                tag.setTitle(name)
                tag.setPlot(r.get('overview') or '')
                tag.setMediaType('tvshow' if is_tv else 'movie')
                if year and str(year).isdigit():
                    tag.setYear(int(year))
                v = r.get('vote_average')
                if v:
                    tag.setRating(float(v))
            except Exception:
                pass
        # Ensure art is always set (apply_to_listitem may not set all keys)
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fan})

        imdb_id = (meta or {}).get('imdb_id', '')

        if is_tv:
            # TV show: open seasons browser first
            url = build_url(
                action='tmdb_tv_seasons',
                tmdb=tmdb_id,
                name=name,
                year=str(year or ''),
                imdb=imdb_id,
                poster=thumb,
                fanart=fan,
            )
            fav_payload = _json.dumps({
                'title': name, 'tmdb': tmdb_id, 'content': norm_content,
                'imdb': imdb_id, 'year': year or '',
                'poster': thumb, 'fanart': fan,
            })
            _set_ctx(li,
                     _fav_ctx_items(fav_payload, tmdb_id, norm_content, name),
                     _info_ctx_items(name, tmdb_id, norm_content, thumb, fan),
                     _scrobbler_ctx_items(fav_payload, tmdb_id, norm_content, name),
                     _extras_ctx_items(name, tmdb_id, norm_content, thumb, fan),
                     _trailer_ctx_items(tmdb_id, norm_content),
                     _local_tvshow_ctx_items(tmdb_id, name),
                     _opensubtitles_ctx_items(fav_payload, tmdb_id, norm_content, name))
            xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)
        else:
            # Movie: go directly to scrapers → SourceFinder → LinkPicker
            lz_payload = _json.dumps({
                'title': name,
                'tmdb': tmdb_id,
                'content': 'movie',
                'season': None,
                'episode': None,
                'imdb': imdb_id,
                'year': year or '',
                'poster': thumb,
                'fanart': fan,
            })
            li.setProperty('IsPlayable', 'true')
            url = build_url(action='link_zero', payload=lz_payload)
            _set_ctx(li,
                     _fav_ctx_items(lz_payload, tmdb_id, norm_content, name),
                     _info_ctx_items(name, tmdb_id, norm_content, thumb, fan),
                     _scrobbler_ctx_items(lz_payload, tmdb_id, norm_content, name),
                     _extras_ctx_items(name, tmdb_id, norm_content, thumb, fan),
                     _trailer_ctx_items(tmdb_id, norm_content),
                     _local_movie_ctx_items(tmdb_id, norm_content, name),
                     _opensubtitles_ctx_items(lz_payload, tmdb_id, norm_content, name))
            xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=False)

    # Next-page button
    if page < total_pages and browse_action and browse_params is not None:
        bp = dict(browse_params)
        bp['page'] = str(page + 1)
        bp['action'] = browse_action
        next_li = xbmcgui.ListItem(
            label=f'[B]Next page ({page + 1}) »[/B]  [COLOR grey]{page}/{total_pages}[/COLOR]')
        next_li.setArt({'icon': ICON, 'thumb': ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(_handle(), build_url(**bp), next_li, isFolder=True)

    xbmcplugin.setContent(_handle(), 'tvshows' if is_tv else 'movies')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=True)


# ── TMDB TV seasons / episodes browser ──────────────────────────────────

def _tmdb_tv_seasons(tmdb_id, name='', year='', imdb='', poster='', fanart=''):
    """List seasons for a TMDB TV show. Each season opens _tmdb_tv_episodes."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    _replace_builtin_context_items()

    # Fetch full show details; append external_ids to get the IMDB id if missing.
    data = _tmdb_fetch(f'tv/{tmdb_id}', {'append_to_response': 'external_ids'})
    seasons = data.get('seasons') or []

    if not imdb:
        ext = data.get('external_ids') or {}
        imdb = ext.get('imdb_id') or ''

    if not name:
        name = data.get('name') or data.get('original_name') or 'Untitled'

    if not seasons:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No seasons found',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    watched_set = watched_mod.get_watched_set(tmdb_id) if tmdb_id else set()
    for season in seasons:
        snum = season.get('season_number')
        if snum is None:
            continue
        ep_count = season.get('episode_count', 0)
        watched_count, ep_count = _season_watched_progress(
            watched_set, snum, episode_count=ep_count,
        )
        slabel = ('Specials' if snum == 0 else f'Season {snum}')
        slabel = (f'[B]{slabel}[/B]  '
                  f'[COLOR grey]{watched_count}/{ep_count} watched[/COLOR]')

        sp = season.get('poster_path') or ''
        s_thumb = (f'https://image.tmdb.org/t/p/w500{sp}' if sp else poster or ICON)

        li = xbmcgui.ListItem(label=slabel)
        li.setArt({'icon': s_thumb, 'thumb': s_thumb,
                   'poster': s_thumb, 'fanart': fanart or FANART})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(slabel)
            tag.setMediaType('season')
            tag.setSeason(int(snum))
        except Exception:
            pass

        season_pairs = [(snum, n) for n in range(1, int(ep_count or 0) + 1)]
        season_ctx = _local_season_ctx_items(tmdb_id, snum, name, season_pairs)
        if season_ctx:
            li.addContextMenuItems(season_ctx)

        url = build_url(
            action='tmdb_tv_episodes',
            tmdb=str(tmdb_id),
            season=str(snum),
            name=name,
            year=str(year or ''),
            imdb=imdb,
            poster=poster or ICON,
            fanart=fanart or FANART,
        )
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)

    xbmcplugin.setContent(_handle(), 'seasons')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _tmdb_tv_episodes(tmdb_id, season_num, name='', year='', imdb='',
                      poster='', fanart=''):
    """List episodes for one season. Each episode fires link_zero → SourceFinder → LinkPicker."""
    import json as _json
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    try:
        snum = int(season_num)
    except (ValueError, TypeError):
        snum = 1

    data = _tmdb_fetch(f'tv/{tmdb_id}/season/{snum}')
    episodes = data.get('episodes') or []

    if not episodes:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No episodes found',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    for ep in episodes:
        ep_num = ep.get('episode_number')
        if ep_num is None:
            continue
        ep_name  = ep.get('name') or f'Episode {ep_num}'
        ep_plot  = ep.get('overview') or ''
        ep_still = ep.get('still_path') or ''
        ep_thumb = (f'https://image.tmdb.org/t/p/w500{ep_still}'
                    if ep_still else poster or ICON)
        air_date = ep.get('air_date') or ''
        rating   = ep.get('vote_average') or 0

        ep_watched = (int(snum), int(ep_num)) in watched_mod.get_local_watched_set(tmdb_id)
        base_label = f'[B]{snum}x{ep_num:02d}[/B]  {ep_name}'
        label = f'{_watched_indicator(ep_watched)}  {base_label}'

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': ep_thumb, 'thumb': ep_thumb,
                   'poster': poster or ICON, 'fanart': fanart or FANART})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(ep_name)
            tag.setPlot(ep_plot)
            tag.setMediaType('episode')
            tag.setSeason(snum)
            tag.setEpisode(int(ep_num))
            if air_date and len(air_date) >= 4:
                try:
                    tag.setYear(int(air_date[:4]))
                except Exception:
                    pass
            if rating:
                tag.setRating(float(rating))
        except Exception:
            pass

        li.setProperty('IsPlayable', 'true')

        lz_payload = _json.dumps({
            'title': name,
            'tmdb': str(tmdb_id),
            'content': 'episode',
            'season': snum,
            'episode': int(ep_num),
            'episode_title': ep_name,
            'imdb': imdb,
            'year': str(year or ''),
            'poster': poster or ICON,
            'fanart': fanart or FANART,
        })
        url = build_url(action='link_zero', payload=lz_payload)

        _set_ctx(li,
            _local_episode_ctx_items(tmdb_id, snum, ep_num, name),
            _scrobbler_ctx_items(lz_payload, tmdb_id, 'episode', name, season=str(snum), episode=str(ep_num)),
            _opensubtitles_ctx_items(lz_payload, tmdb_id, 'episode', name, season=snum, episode=int(ep_num))
        )
        xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=False)

    xbmcplugin.setContent(_handle(), 'episodes')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── Movies root submenu ──────────────────────────────────────────────────

def _movies_root():
    """Top-level Movies submenu backed by TMDB."""
    items = [
        ('Trending',              'tmdb_browse',              {'category': 'trending_week',  'content': 'movie'}, 'trending'),
        ('Trending Recent',       'tmdb_browse',              {'category': 'trending_day',   'content': 'movie'}, 'trending_recent'),
        ('Popular',               'tmdb_browse',              {'category': 'popular',        'content': 'movie'}, 'popular'),
        ('Popular Today',         'tmdb_browse',              {'category': 'now_playing',    'content': 'movie'}, 'popular_today'),
        ('Premieres',             'tmdb_browse',              {'category': 'upcoming',       'content': 'movie'}, 'premieres'),
        ('Latest Releases',       'tmdb_browse',              {'category': 'now_playing',    'content': 'movie'}, 'latest_releases'),
        ('Most Watched',          'tmdb_browse',              {'category': 'most_watched',   'content': 'movie'}, 'most_watched'),
        ('Most Favorited',        'tmdb_browse',              {'category': 'top_rated',      'content': 'movie'}, 'most_favorited'),
        ('Top 10 Box Office',     'tmdb_browse',              {'category': 'box_office',     'content': 'movie'}, 'box_office'),
        ('Blockbusters',          'tmdb_browse',              {'category': 'blockbusters',   'content': 'movie'}, 'blockbusters'),
        ('In Theaters',           'tmdb_browse',              {'category': 'now_playing',    'content': 'movie'}, 'in_theaters'),
        ('Up Coming',             'tmdb_browse',              {'category': 'upcoming',       'content': 'movie'}, 'upcoming'),
        ('Oscar Winners',         'tmdb_browse',              {'category': 'oscar_winners',  'content': 'movie'}, 'oscar_winners'),
        ('Genres',                'tmdb_genres',              {'content': 'movie'},                               'genres'),
        ('Providers',             'tmdb_providers',           {'content': 'movie'},                               'providers'),
        ('Languages',             'tmdb_languages',           {'content': 'movie'},                               'languages'),
        ('Years',                 'tmdb_years',               {'content': 'movie'},                               'years'),
        ('Decades',               'tmdb_decades',             {'content': 'movie'},                               'decades'),
        ('Certifications',        'tmdb_certs',               {'content': 'movie'},                               'certifications'),
        ('Because You Watched...','tmdb_because_you_watched', {'content': 'movie'},                               'because_you_watched'),
        ('Watched',               'tmdb_watched',             {'content': 'movie'},                               'watched'),
        ('Recently Watched',      'tmdb_recently_watched',    {'content': 'movie'},                               'recently_watched'),
        ('In Progress',           'tmdb_in_progress',         {'content': 'movie'},                               'in_progress'),
    ]
    for label, act, params, icon_name in items:
        p = dict(params)
        p['action'] = act
        _add_directory(f'[B]{label}[/B]', build_url(**p),
                       thumb=_submenu_icon(icon_name), is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── TV Shows root submenu ────────────────────────────────────────────────

def _tvshows_root():
    """Top-level TV Shows submenu backed by TMDB."""
    items = [
        ('Trending',                   'tmdb_browse',                   {'category': 'trending_week', 'content': 'tvshow'}, 'trending'),
        ('Trending Recent',            'tmdb_browse',                   {'category': 'trending_day',  'content': 'tvshow'}, 'trending_recent'),
        ('Popular',                    'tmdb_browse',                   {'category': 'popular',       'content': 'tvshow'}, 'popular'),
        ('Popular Today',              'tmdb_browse',                   {'category': 'airing_today',  'content': 'tvshow'}, 'popular_today'),
        ('Premieres',                  'tmdb_browse',                   {'category': 'on_the_air',    'content': 'tvshow'}, 'premieres'),
        ('Most Watched',               'tmdb_browse',                   {'category': 'most_watched',  'content': 'tvshow'}, 'most_watched'),
        ('Most Favorited',             'tmdb_browse',                   {'category': 'top_rated',     'content': 'tvshow'}, 'most_favorited'),
        ('Airing Today',               'tmdb_browse',                   {'category': 'airing_today',  'content': 'tvshow'}, 'airing_today'),
        ('On the Air',                 'tmdb_browse',                   {'category': 'on_the_air',    'content': 'tvshow'}, 'on_the_air'),
        ('Up Coming',                  'tmdb_browse',                   {'category': 'upcoming_tv',   'content': 'tvshow'}, 'upcoming'),
        ('Genres',                     'tmdb_genres',                   {'content': 'tvshow'},                               'genres'),
        ('Providers',                  'tmdb_providers',                {'content': 'tvshow'},                               'providers'),
        ('Networks',                   'tmdb_networks',                 {},                                                  'networks'),
        ('Languages',                  'tmdb_languages',                {'content': 'tvshow'},                               'languages'),
        ('Years',                      'tmdb_years',                    {'content': 'tvshow'},                               'years'),
        ('Decades',                    'tmdb_decades',                  {'content': 'tvshow'},                               'decades'),
        ('Certifications',             'tmdb_certs',                    {'content': 'tvshow'},                               'certifications'),
        ('Because You Watched...',     'tmdb_because_you_watched',      {'content': 'tvshow'},                               'because_you_watched'),
        ('Watched',                    'tmdb_watched',                  {'content': 'tvshow'},                               'watched'),
        ('Recently Watched',           'tmdb_recently_watched',         {'content': 'tvshow'},                               'recently_watched'),
        ('In Progress',                'tmdb_in_progress',              {'content': 'tvshow'},                               'in_progress'),
        ('Random Next Episodes',       'tmdb_random_next_episodes',     {},                                                  'random_next_episodes'), # noqa
    ]
    for label, act, params, icon_name in items:
        p = dict(params)
        p['action'] = act
        _add_directory(f'[B]{label}[/B]', build_url(**p),
                       thumb=_submenu_icon(icon_name), is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── Generic category browser ─────────────────────────────────────────────

# Maps category slug → (endpoint template, extra discover params)
def _today_str():
    import datetime
    return str(datetime.date.today())


# {kind} is replaced with 'movie' or 'tv' at call time.
_TMDB_CATEGORY_MAP = {
    'trending_week':   (lambda k: f'trending/{k}/week',    {}),
    'trending_day':    (lambda k: f'trending/{k}/day',     {}),
    'popular':         (lambda k: f'{k}/popular',          {}),
    'now_playing':     (lambda k: f'{k}/now_playing',      {}),
    'upcoming':        (lambda k: f'{k}/upcoming',         {}),
    'top_rated':       (lambda k: f'{k}/top_rated',        {}),
    'most_watched':    (lambda k: f'discover/{k}',         {'sort_by': 'popularity.desc'}),
    'box_office':      (lambda k: f'discover/{k}',         {'sort_by': 'revenue.desc'}),
    'blockbusters':    (lambda k: f'discover/{k}',         {'sort_by': 'revenue.desc', 'vote_count.gte': '500'}),
    'oscar_winners':   (lambda k: f'discover/{k}',         {'sort_by': 'vote_average.desc',
                                                             'vote_count.gte': '500',
                                                             'with_keywords': '210024'}),
    'airing_today':    (lambda k: 'tv/airing_today',       {}),
    'on_the_air':      (lambda k: 'tv/on_the_air',         {}),
    'upcoming_tv':     (lambda k: 'discover/tv',           {'sort_by': 'first_air_date.desc',
                                                             'first_air_date.gte': _today_str()}),
}


def _tmdb_browse(category, content='movie', page=1):
    """Fetch and display a TMDB browse category with pagination."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    is_tv = content in ('tvshow', 'tv')
    kind = 'tv' if is_tv else 'movie'

    cat = _TMDB_CATEGORY_MAP.get(category)
    if not cat:
        cat = _TMDB_CATEGORY_MAP['popular']

    endpoint_fn, base_extra = cat
    endpoint = endpoint_fn(kind)
    extra = dict(base_extra)
    extra['page'] = str(page)

    data = _tmdb_fetch(endpoint, extra)
    results = data.get('results') or []
    total_pages = min(int(data.get('total_pages') or 1), 20)

    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No results found',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    _render_tmdb_results(
        results, content=content, page=page, total_pages=total_pages,
        browse_action='tmdb_browse',
        browse_params={'category': category, 'content': content},
    )


# ── Genres ───────────────────────────────────────────────────────────────

def _tmdb_genres(content='movie'):
    """List TMDB genres for movies or TV shows."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    is_tv = content in ('tvshow', 'tv')
    kind = 'tv' if is_tv else 'movie'
    data = _tmdb_fetch(f'genre/{kind}/list')
    genres = data.get('genres') or []
    if not genres:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Could not load genres',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    for g in genres:
        gid = str(g.get('id') or '')
        gname = g.get('name') or ''
        _add_directory(f'[B]{gname}[/B]',
                       build_url(action='tmdb_by_genre', genre_id=gid,
                                 genre_name=gname, content=content, page='1'),
                       thumb=_submenu_icon('genres'), is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _tmdb_by_genre(genre_id, genre_name, content='movie', page=1):
    """List movies/shows in a genre."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    is_tv = content in ('tvshow', 'tv')
    kind = 'tv' if is_tv else 'movie'
    data = _tmdb_fetch(f'discover/{kind}',
                       {'with_genres': genre_id, 'sort_by': 'popularity.desc', 'page': str(page)})
    results = data.get('results') or []
    total_pages = min(int(data.get('total_pages') or 1), 20)
    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No results found',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    _render_tmdb_results(results, content=content, page=page, total_pages=total_pages,
                          browse_action='tmdb_by_genre',
                          browse_params={'genre_id': genre_id, 'genre_name': genre_name,
                                         'content': content})


# ── Years ────────────────────────────────────────────────────────────────

def _tmdb_years(content='movie'):
    """Year picker — past 50 years."""
    import datetime
    cur_year = datetime.date.today().year
    for yr in range(cur_year, cur_year - 51, -1):
        _add_directory(f'[B]{yr}[/B]',
                       build_url(action='tmdb_by_year', year=str(yr), content=content, page='1'),
                       thumb=_submenu_icon('years'), is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _tmdb_by_year(year, content='movie', page=1):
    """List movies/shows from a specific year."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    is_tv = content in ('tvshow', 'tv')
    kind = 'tv' if is_tv else 'movie'
    yr_param = 'first_air_date_year' if is_tv else 'primary_release_year'
    data = _tmdb_fetch(f'discover/{kind}',
                       {yr_param: year, 'sort_by': 'popularity.desc', 'page': str(page)})
    results = data.get('results') or []
    total_pages = min(int(data.get('total_pages') or 1), 20)
    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No results found',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    _render_tmdb_results(results, content=content, page=page, total_pages=total_pages,
                          browse_action='tmdb_by_year',
                          browse_params={'year': year, 'content': content})


# ── Decades ──────────────────────────────────────────────────────────────

def _tmdb_decades(content='movie'):
    """Decade picker."""
    import datetime
    cur_decade = (datetime.date.today().year // 10) * 10
    for decade in range(cur_decade, 1919, -10):
        _add_directory(f'[B]{decade}s[/B]',
                       build_url(action='tmdb_by_decade', decade=str(decade),
                                 content=content, page='1'),
                       thumb=_submenu_icon('decades'), is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _tmdb_by_decade(decade, content='movie', page=1):
    """List movies/shows from a decade."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    is_tv = content in ('tvshow', 'tv')
    kind = 'tv' if is_tv else 'movie'
    yr_from = int(decade)
    yr_to = yr_from + 9
    date_from = f'{yr_from}-01-01'
    date_to = f'{yr_to}-12-31'
    if is_tv:
        disc = {'first_air_date.gte': date_from, 'first_air_date.lte': date_to,
                'sort_by': 'popularity.desc', 'page': str(page)}
    else:
        disc = {'primary_release_date.gte': date_from, 'primary_release_date.lte': date_to,
                'sort_by': 'popularity.desc', 'page': str(page)}
    data = _tmdb_fetch(f'discover/{kind}', disc)
    results = data.get('results') or []
    total_pages = min(int(data.get('total_pages') or 1), 20)
    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No results found',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    _render_tmdb_results(results, content=content, page=page, total_pages=total_pages,
                          browse_action='tmdb_by_decade',
                          browse_params={'decade': str(decade), 'content': content})


# ── Certifications ───────────────────────────────────────────────────────

_MOVIE_CERTS = ['G', 'PG', 'PG-13', 'R', 'NC-17', 'NR']
_TV_CERTS    = ['TV-Y', 'TV-Y7', 'TV-G', 'TV-PG', 'TV-14', 'TV-MA', 'NR']


def _tmdb_certs(content='movie'):
    """Certification picker (US ratings)."""
    is_tv = content in ('tvshow', 'tv')
    certs = _TV_CERTS if is_tv else _MOVIE_CERTS
    for cert in certs:
        _add_directory(f'[B]{cert}[/B]',
                       build_url(action='tmdb_by_cert', cert=cert, content=content, page='1'),
                       thumb=_submenu_icon('certifications'), is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _tmdb_by_cert(cert, content='movie', page=1):
    """List movies/shows with a specific US certification."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    is_tv = content in ('tvshow', 'tv')
    kind = 'tv' if is_tv else 'movie'
    data = _tmdb_fetch(f'discover/{kind}',
                       {'certification': cert, 'certification_country': 'US',
                        'sort_by': 'popularity.desc', 'page': str(page)})
    results = data.get('results') or []
    total_pages = min(int(data.get('total_pages') or 1), 20)
    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No results found',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    _render_tmdb_results(results, content=content, page=page, total_pages=total_pages,
                          browse_action='tmdb_by_cert',
                          browse_params={'cert': cert, 'content': content})


# ── Providers ─────────────────────────────────────────────────────────────

def _tmdb_providers(content='movie'):
    """List popular streaming providers from TMDB."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    is_tv = content in ('tvshow', 'tv')
    kind = 'tv' if is_tv else 'movie'
    data = _tmdb_fetch(f'watch/providers/{kind}', {'watch_region': 'US'})
    providers = (data.get('results') or [])[:30]
    if not providers:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Could not load providers',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    for p in providers:
        pid = str(p.get('provider_id') or '')
        pname = p.get('provider_name') or ''
        logo = p.get('logo_path') or ''
        thumb = (f'https://image.tmdb.org/t/p/w92{logo}' if logo
                 else _submenu_icon('providers'))
        _add_directory(f'[B]{pname}[/B]',
                       build_url(action='tmdb_by_provider', provider_id=pid,
                                 provider_name=pname, content=content, page='1'),
                       thumb=thumb, is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _tmdb_by_provider(provider_id, provider_name, content='movie', page=1):
    """List movies/shows available on a streaming provider (US)."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    is_tv = content in ('tvshow', 'tv')
    kind = 'tv' if is_tv else 'movie'
    data = _tmdb_fetch(f'discover/{kind}',
                       {'with_watch_providers': provider_id, 'watch_region': 'US',
                        'sort_by': 'popularity.desc', 'page': str(page)})
    results = data.get('results') or []
    total_pages = min(int(data.get('total_pages') or 1), 20)
    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No results found',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    _render_tmdb_results(results, content=content, page=page, total_pages=total_pages,
                          browse_action='tmdb_by_provider',
                          browse_params={'provider_id': provider_id,
                                         'provider_name': provider_name, 'content': content})


# ── Languages ─────────────────────────────────────────────────────────────

_COMMON_LANGUAGES = [
    ('English', 'en'), ('Spanish', 'es'), ('French', 'fr'), ('German', 'de'),
    ('Italian', 'it'), ('Portuguese', 'pt'), ('Japanese', 'ja'), ('Korean', 'ko'),
    ('Chinese', 'zh'), ('Hindi', 'hi'), ('Arabic', 'ar'), ('Russian', 'ru'),
    ('Turkish', 'tr'), ('Swedish', 'sv'), ('Danish', 'da'), ('Norwegian', 'no'),
    ('Dutch', 'nl'), ('Polish', 'pl'), ('Thai', 'th'), ('Hebrew', 'he'),
]


def _tmdb_languages(content='movie'):
    """Language picker."""
    for lang_name, lang_code in _COMMON_LANGUAGES:
        _add_directory(f'[B]{lang_name}[/B]',
                       build_url(action='tmdb_by_language', lang=lang_code,
                                 content=content, page='1'),
                       thumb=_submenu_icon('languages'), is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _tmdb_by_language(lang, content='movie', page=1):
    """List movies/shows in a given original language."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    is_tv = content in ('tvshow', 'tv')
    kind = 'tv' if is_tv else 'movie'
    data = _tmdb_fetch(f'discover/{kind}',
                       {'with_original_language': lang, 'sort_by': 'popularity.desc',
                        'page': str(page)})
    results = data.get('results') or []
    total_pages = min(int(data.get('total_pages') or 1), 20)
    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No results found',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    _render_tmdb_results(results, content=content, page=page, total_pages=total_pages,
                          browse_action='tmdb_by_language',
                          browse_params={'lang': lang, 'content': content})


# ── Networks (TV only) ────────────────────────────────────────────────────

_POPULAR_NETWORKS = [
    ('Netflix', 213), ('HBO', 49), ('ABC', 2), ('CBS', 16), ('NBC', 6),
    ('Fox', 19), ('Amazon Prime Video', 1024), ('Disney+', 2739),
    ('Apple TV+', 2552), ('Hulu', 453), ('Peacock', 3353),
    ('Paramount+', 4330), ('Showtime', 67), ('AMC', 174), ('FX', 88),
    ('BBC One', 4), ('ITV', 137), ('Starz', 318), ('TNT', 41),
    ('Comedy Central', 47), ('Syfy', 77), ('Adult Swim', 80),
    ('Cartoon Network', 56), ('CW', 71), ('MTV', 33),
]


def _tmdb_networks():
    """List popular TV networks."""
    for net_name, net_id in _POPULAR_NETWORKS:
        _add_directory(f'[B]{net_name}[/B]',
                       build_url(action='tmdb_by_network', network_id=str(net_id),
                                 network_name=net_name, page='1'),
                       thumb=_submenu_icon('networks'), is_folder=True)
    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _tmdb_by_network(network_id, network_name, page=1):
    """List TV shows from a specific network."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    data = _tmdb_fetch('discover/tv',
                       {'with_networks': network_id, 'sort_by': 'popularity.desc',
                        'page': str(page)})
    results = data.get('results') or []
    total_pages = min(int(data.get('total_pages') or 1), 20)
    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No results found',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return
    _render_tmdb_results(results, content='tvshow', page=page, total_pages=total_pages,
                          browse_action='tmdb_by_network',
                          browse_params={'network_id': network_id, 'network_name': network_name})


# ── Because You Watched ──────────────────────────────────────────────────

def _tmdb_because_you_watched(content='movie'):
    """Show TMDB recommendations seeded from the newest watched item."""
    if not _tmdb_require_key():
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    seed_id, seed_title = '', ''
    if content == 'movie':
        # Completed local movies are removed from resume.json and stored in
        # watched.json, so use the newest local completion as the primary
        # recommendation seed.
        local_movies = watched_mod.get_watched_movies()
        if local_movies:
            seed_id = max(local_movies, key=lambda tmdb_id: float(local_movies.get(tmdb_id, 0) or 0))
            seed_id = str(seed_id)
            seed_meta = tmdb_mod.get_metadata(seed_id, 'movie') or {}
            seed_title = seed_meta.get('title') or ''
    elif content in ('tvshow', 'tv'):
        # Completed local episodes are stored in the watched ledger, so use
        # the newest watched show before falling back to resume history.
        local_shows = watched_mod.get_all_watched_shows()
        if local_shows:
            seed_id = max(
                local_shows,
                key=lambda tmdb_id: float(local_shows[tmdb_id].get('ts', 0) or 0),
            )
            seed_id = str(seed_id)
            seed_meta = tmdb_mod.get_metadata(seed_id, 'tvshow') or {}
            seed_title = seed_meta.get('title') or ''

    if not seed_id:
        recent = resume_mod.list_recent(limit=30)
        for r in recent:
            rc = r.get('content', 'movie')
            if rc == content or (content in ('tvshow', 'tv') and rc == 'episode'):
                if r.get('tmdb'):
                    seed_id = str(r['tmdb'])
                    seed_title = r.get('title') or r.get('label') or ''
                    break

    if not seed_id:
        xbmcgui.Dialog().notification(
            'C.O.S.M.O.S', 'No watch history found — play something first!',
            xbmcgui.NOTIFICATION_INFO, 4000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    is_tv = content in ('tvshow', 'tv')
    kind = 'tv' if is_tv else 'movie'
    data = _tmdb_fetch(f'{kind}/{seed_id}/recommendations')
    results = data.get('results') or []
    if not results:
        data = _tmdb_fetch(f'{kind}/{seed_id}/similar')
        results = data.get('results') or []

    if not results:
        xbmcgui.Dialog().notification('C.O.S.M.O.S', 'No recommendations found',
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    if seed_title:
        hdr = xbmcgui.ListItem(
            label=f'[COLOR grey][I]Because you watched: {seed_title}[/I][/COLOR]')
        hdr.setArt({'icon': ICON, 'thumb': ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(_handle(), build_url(action='movies_root'), hdr, isFolder=False)

    _render_tmdb_results(results, content=content)


# ── Watch history helpers ────────────────────────────────────────────────

def _add_tv_history_item(row, progress=False):
    """Render one show-level history row and open its seasons browser."""
    import json as _json
    tmdb_id = str(row.get('tmdb') or '')
    if not tmdb_id:
        return

    meta = tmdb_mod.get_metadata(tmdb_id, 'tvshow') or {}
    title = row.get('title') or row.get('label') or meta.get('title') or 'Unknown Show'
    year = row.get('year') or meta.get('year') or ''
    imdb_id = row.get('imdb') or meta.get('imdb_id') or ''
    thumb = row.get('poster') or meta.get('poster') or ICON
    fan = row.get('fanart') or meta.get('fanart') or FANART

    season = row.get('season', row.get('last_watched_s', ''))
    episode = row.get('episode', row.get('last_watched_e', ''))
    try:
        marker = f'S{int(season):02d}E{int(episode):02d}' if season and episode else ''
    except (ValueError, TypeError):
        marker = f'S{season}E{episode}' if season and episode else ''
    if progress:
        pct = int((row.get('progress') or 0) * 100)
        position = resume_mod.format_offset(row.get('pos', 0))
        marker = f'{marker} · {position} ({pct}%)' if marker else f'{position} ({pct}%)'
    display = f'[B]{title}[/B]  [COLOR grey]{marker}[/COLOR]' if marker else f'[B]{title}[/B]'

    li = xbmcgui.ListItem(label=display)
    li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fan})
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        tag.setMediaType('tvshow')
        if year and str(year).isdigit():
            tag.setYear(int(year))
        if progress:
            tag.setResumePoint(float(row.get('pos', 0)), float(row.get('dur') or 0))
    except Exception:
        pass

    payload = _json.dumps({
        'title': title, 'tmdb': tmdb_id, 'content': 'tvshow',
        'season': None, 'episode': None, 'links': [],
        'imdb': imdb_id, 'year': year, 'poster': thumb, 'fanart': fan,
    })
    url = build_url(action='tmdb_tv_seasons', tmdb=tmdb_id, name=title,
                    year=str(year or ''), imdb=imdb_id, poster=thumb, fanart=fan)
    _set_ctx(li,
             _fav_ctx_items(payload, tmdb_id, 'tvshow', title),
             _info_ctx_items(title, tmdb_id, 'tvshow', thumb, fan),
             _scrobbler_ctx_items(payload, tmdb_id, 'tvshow', title),
             _extras_ctx_items(title, tmdb_id, 'tvshow', thumb, fan),
             _trailer_ctx_items(tmdb_id, 'tvshow'),
             _local_tvshow_ctx_items(tmdb_id, title),
             _opensubtitles_ctx_items(payload, tmdb_id, 'tvshow', title))
    xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=True)


def _tmdb_watched(content='movie', limit=None):
    """Completed local watch history, grouped by unique TMDB id or show."""
    import json as _json
    is_tv = content in ('tvshow', 'tv')
    if is_tv:
        recent = []
        for show_tmdb, watched_info in watched_mod.get_all_watched_shows().items():
            show_meta = tmdb_mod.get_metadata(show_tmdb, 'tvshow') or {}
            recent.append({
                'tmdb': show_tmdb,
                'content': 'tvshow',
                'title': show_meta.get('title') or 'Watched Show',
                'poster': show_meta.get('poster', ''),
                'fanart': show_meta.get('fanart', ''),
                'imdb': show_meta.get('imdb_id', ''),
                'year': show_meta.get('year', ''),
                'last_watched_s': watched_info.get('last_watched_s', ''),
                'last_watched_e': watched_info.get('last_watched_e', ''),
                'ts': watched_info.get('ts', 0),
            })
        recent.sort(key=lambda row: row.get('ts', 0), reverse=True)
        if limit:
            recent = recent[:limit]
    else:
        # Completed movies are removed from resume.json, so the local movie
        # ledger is the source of truth for Watched and Recently Watched.
        recent = []
        for movie_tmdb, watched_ts in watched_mod.get_watched_movies().items():
            movie_meta = tmdb_mod.get_metadata(movie_tmdb, 'movie') or {}
            recent.append({
                'tmdb': movie_tmdb,
                'content': 'movie',
                'title': movie_meta.get('title') or 'Watched Movie',
                'poster': movie_meta.get('poster', ''),
                'fanart': movie_meta.get('fanart', ''),
                'ts': watched_ts,
            })
        recent.sort(key=lambda row: row.get('ts', 0), reverse=True)
        if limit:
            recent = recent[:limit]
    shown = set()
    found = False
    norm_content = 'tvshow' if is_tv else 'movie'
    for r in recent:
        rc = r.get('content', 'movie')
        if rc != norm_content and not (is_tv and rc == 'episode'):
            continue
        tmdb_id = str(r.get('tmdb') or '')
        if not tmdb_id or tmdb_id in shown:
            continue
        shown.add(tmdb_id)
        found = True
        if is_tv:
            _add_tv_history_item(r)
            continue
        raw_label = r.get('title') or r.get('label') or 'Unknown'
        label = _local_movie_label(raw_label, tmdb_id, norm_content)
        thumb = r.get('poster') or ICON
        fan = r.get('fanart') or FANART
        li = xbmcgui.ListItem(label=f'[B]{label}[/B]')
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fan})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(raw_label)
            tag.setMediaType('tvshow' if is_tv else 'movie')
        except Exception:
            pass
        payload = _json.dumps({
            'title': raw_label, 'tmdb': tmdb_id, 'content': norm_content,
            'season': None, 'episode': None, 'links': [],
            'imdb': '', 'year': '', 'poster': thumb, 'fanart': fan,
        })
        _set_ctx(li,
                  _fav_ctx_items(payload, tmdb_id, norm_content, raw_label),
                  _info_ctx_items(raw_label, tmdb_id, norm_content, thumb, fan),
                  _scrobbler_ctx_items(payload, tmdb_id, norm_content, raw_label),
                  _extras_ctx_items(raw_label, tmdb_id, norm_content, thumb, fan),
                 _trailer_ctx_items(tmdb_id, norm_content),
                 _local_movie_ctx_items(tmdb_id, norm_content, raw_label))
        xbmcplugin.addDirectoryItem(
            _handle(), build_url(action='show_links', payload=payload), li, isFolder=True)
    if not found:
        _add_directory('[COLOR grey]No watch history found yet.[/COLOR]',
                       build_url(action='movies_root' if not is_tv else 'tvshows_root'),
                       is_folder=False)
    xbmcplugin.setContent(_handle(), 'tvshows' if is_tv else 'movies')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _tmdb_recently_watched(content='movie'):
    """Recent completed movies or shows, sorted newest first."""
    _tmdb_watched(content, limit=30)


def _tmdb_in_progress(content='movie'):
    """Items still in progress (below the configured completion threshold)."""
    import json as _json
    recent = resume_mod.list_recent(limit=50)
    shown = set()
    found = False
    is_tv = content in ('tvshow', 'tv')
    norm_content = 'tvshow' if is_tv else 'movie'
    for r in recent:
        rc = r.get('content', 'movie')
        if rc != norm_content and not (is_tv and rc == 'episode'):
            continue
        if (r.get('progress') or 0) >= resume_mod.get_finished_ratio():
            continue
        tmdb_id = str(r.get('tmdb') or '')
        if not tmdb_id or tmdb_id in shown:
            continue
        # A locally completed movie must never appear in both lists, even if
        # a stale resume entry survives from an older playback session.
        if not is_tv and watched_mod.is_movie_watched(tmdb_id):
            continue
        shown.add(tmdb_id)
        found = True
        if is_tv:
            _add_tv_history_item(r, progress=True)
            continue
        pct = int((r.get('progress') or 0) * 100)
        pos_h = resume_mod.format_offset(r.get('pos', 0))
        label = r.get('title') or r.get('label') or 'Unknown'
        display = f'[B]{label}[/B]  [COLOR grey]{pos_h} ({pct}%)[/COLOR]'
        thumb = r.get('poster') or ICON
        fan = r.get('fanart') or FANART
        li = xbmcgui.ListItem(label=display)
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fan})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(label)
            tag.setMediaType('tvshow' if is_tv else 'movie')
            tag.setResumePoint(float(r.get('pos', 0)), float(r.get('dur') or 0))
        except Exception:
            pass
        payload = _json.dumps({
            'title': label, 'tmdb': tmdb_id, 'content': norm_content,
            'season': None, 'episode': None, 'links': [],
            'imdb': '', 'year': '', 'poster': thumb, 'fanart': fan,
        })
        _set_ctx(li,
                  _fav_ctx_items(payload, tmdb_id, norm_content, label),
                  _info_ctx_items(label, tmdb_id, norm_content, thumb, fan),
                  _scrobbler_ctx_items(payload, tmdb_id, norm_content, label),
                  _extras_ctx_items(label, tmdb_id, norm_content, thumb, fan),
                 _trailer_ctx_items(tmdb_id, norm_content),
                 _local_movie_ctx_items(tmdb_id, norm_content, label))
        xbmcplugin.addDirectoryItem(
            _handle(), build_url(action='show_links', payload=payload), li, isFolder=True)
    if not found:
        _add_directory('[COLOR grey]No items in progress.[/COLOR]',
                       build_url(action='movies_root' if not is_tv else 'tvshows_root'),
                       is_folder=False)
    xbmcplugin.setContent(_handle(), 'tvshows' if is_tv else 'movies')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── TV-only episode history ───────────────────────────────────────────────

def _tmdb_recently_watched_episodes():
    """All episode entries from resume history, newest first."""
    import json as _json
    recent = resume_mod.list_recent(limit=50)
    found = False
    for r in recent:
        if r.get('content') != 'episode':
            continue
        found = True
        season = r.get('season', '')
        episode = r.get('episode', '')
        title = r.get('title') or r.get('label') or 'Unknown'
        tmdb_id = str(r.get('tmdb') or '')
        try:
            se = f'S{int(season):02d}E{int(episode):02d}' if season and episode else ''
        except (ValueError, TypeError):
            se = f'S{season}E{episode}'
        display = f'[B]{title}[/B]  [COLOR grey]{se}[/COLOR]' if se else f'[B]{title}[/B]'
        thumb = r.get('poster') or ICON
        fan = r.get('fanart') or FANART
        li = xbmcgui.ListItem(label=display)
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fan})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType('episode')
            if season and str(season).isdigit():
                tag.setSeason(int(season))
            if episode and str(episode).isdigit():
                tag.setEpisode(int(episode))
        except Exception:
            pass
        payload = _json.dumps({
            'title': title, 'tmdb': tmdb_id, 'content': 'tvshow',
            'season': season or None, 'episode': episode or None, 'links': [],
            'imdb': '', 'year': '', 'poster': thumb, 'fanart': fan,
        })
        _set_ctx(li,
                  _fav_ctx_items(payload, tmdb_id, 'tvshow', title),
                  _info_ctx_items(title, tmdb_id, 'tvshow', thumb, fan),
                  _scrobbler_ctx_items(payload, tmdb_id, 'episode', title, season=season, episode=episode),
                  _extras_ctx_items(title, tmdb_id, 'tvshow', thumb, fan),
                 _trailer_ctx_items(tmdb_id, 'tvshow'))
        xbmcplugin.addDirectoryItem(
            _handle(), build_url(action='show_links', payload=payload), li, isFolder=True)
    if not found:
        _add_directory('[COLOR grey]No recently watched episodes.[/COLOR]',
                       build_url(action='tvshows_root'), is_folder=False)
    xbmcplugin.setContent(_handle(), 'episodes')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _tmdb_in_progress_episodes():
    """Episodes still in progress (below the configured completion threshold)."""
    import json as _json
    recent = resume_mod.list_recent(limit=50)
    found = False
    for r in recent:
        if r.get('content') != 'episode':
            continue
        if (r.get('progress') or 0) >= resume_mod.get_finished_ratio():
            continue
        found = True
        season = r.get('season', '')
        episode = r.get('episode', '')
        title = r.get('title') or r.get('label') or 'Unknown'
        tmdb_id = str(r.get('tmdb') or '')
        pct = int((r.get('progress') or 0) * 100)
        pos_h = resume_mod.format_offset(r.get('pos', 0))
        try:
            se = f'S{int(season):02d}E{int(episode):02d}' if season and episode else ''
        except (ValueError, TypeError):
            se = f'S{season}E{episode}'
        display = (f'[B]{title}[/B]  [COLOR grey]{se} · {pos_h} ({pct}%)[/COLOR]'
                   if se else f'[B]{title}[/B]  [COLOR grey]{pos_h} ({pct}%)[/COLOR]')
        thumb = r.get('poster') or ICON
        fan = r.get('fanart') or FANART
        li = xbmcgui.ListItem(label=display)
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fan})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType('episode')
            tag.setResumePoint(float(r.get('pos', 0)), float(r.get('dur') or 0))
            if season and str(season).isdigit():
                tag.setSeason(int(season))
            if episode and str(episode).isdigit():
                tag.setEpisode(int(episode))
        except Exception:
            pass
        payload = _json.dumps({
            'title': title, 'tmdb': tmdb_id, 'content': 'tvshow',
            'season': season or None, 'episode': episode or None, 'links': [],
            'imdb': '', 'year': '', 'poster': thumb, 'fanart': fan,
        })
        _set_ctx(li,
                  _fav_ctx_items(payload, tmdb_id, 'tvshow', title),
                  _info_ctx_items(title, tmdb_id, 'tvshow', thumb, fan),
                  _scrobbler_ctx_items(payload, tmdb_id, 'episode', title, season=season, episode=episode),
                  _extras_ctx_items(title, tmdb_id, 'tvshow', thumb, fan),
                 _trailer_ctx_items(tmdb_id, 'tvshow'))
        xbmcplugin.addDirectoryItem(
            _handle(), build_url(action='show_links', payload=payload), li, isFolder=True)
    if not found:
        _add_directory('[COLOR grey]No episodes in progress.[/COLOR]',
                       build_url(action='tvshows_root'), is_folder=False)
    xbmcplugin.setContent(_handle(), 'episodes')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)

def _tmdb_random_next_episodes():
    """Shuffled list of next episodes for variety."""
    import json as _json
    import random
    recent = resume_mod.list_recent(limit=100)
    candidates = {}
    for r in recent:
        if r.get('content') != 'episode':
            continue
        tmdb_id = str(r.get('tmdb') or '')
        if tmdb_id and tmdb_id not in candidates:
            candidates[tmdb_id] = r

    # A completed local episode clears its resume entry, so include locally
    # watched shows even when they have no active playback session.
    for tmdb_id, watched_info in watched_mod.get_all_watched_shows().items():
        if tmdb_id in candidates:
            continue
        show_meta = tmdb_mod.get_metadata(tmdb_id, 'tvshow') or {}
        candidates[tmdb_id] = {
            'tmdb': tmdb_id,
            'title': show_meta.get('title') or 'Unknown Show',
            'poster': show_meta.get('poster') or ICON,
            'fanart': show_meta.get('fanart') or FANART,
            'ts': watched_info.get('ts', 0),
        }

    entries = []
    for r in candidates.values():
        tmdb_id = str(r.get('tmdb') or '')
        if not tmdb_id:
            continue
        watched_set = watched_mod.get_watched_set(tmdb_id)
        if not watched_set:
            continue
        max_s, max_e = max(watched_set, key=lambda x: (x[0], x[1]))
        next_s, next_e = max_s, max_e + 1
        next_meta = tmdb_mod.get_episode_meta(tmdb_id, next_s, next_e)
        if not next_meta:
            next_s, next_e = max_s + 1, 1
            next_meta = tmdb_mod.get_episode_meta(tmdb_id, next_s, next_e)
        if not next_meta:
            continue
        entries.append({
            'tmdb': tmdb_id, 'title': r.get('title') or 'Unknown Show',
            'next_s': next_s, 'next_e': next_e,
            'poster': r.get('poster') or ICON, 'fanart': r.get('fanart') or FANART,
        })
    random.shuffle(entries)
    found = bool(entries)
    for e in entries:
        title = e['title']
        tmdb_id = e['tmdb']
        next_s, next_e = e['next_s'], e['next_e']
        thumb, fan = e['poster'], e['fanart']
        try:
            se = f'S{next_s:02d}E{next_e:02d}'
        except Exception:
            se = f'S{next_s}E{next_e}'
        display = f'[B]{title}[/B]  [COLOR hotpink]▶ {se}[/COLOR]'
        li = xbmcgui.ListItem(label=display)
        li.setArt({'icon': thumb, 'thumb': thumb, 'poster': thumb, 'fanart': fan})
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(title)
            tag.setMediaType('episode')
            tag.setSeason(next_s)
            tag.setEpisode(next_e)
        except Exception:
            pass
        payload = _json.dumps({
            'title': title, 'tmdb': tmdb_id, 'content': 'tvshow',
            'season': next_s, 'episode': next_e, 'links': [],
            'imdb': '', 'year': '', 'poster': thumb, 'fanart': fan,
        })
        _set_ctx(li,
                  _fav_ctx_items(payload, tmdb_id, 'tvshow', title),
                  _info_ctx_items(title, tmdb_id, 'tvshow', thumb, fan),
                  _scrobbler_ctx_items(payload, tmdb_id, 'episode', title, season=next_s, episode=next_e),
                  _extras_ctx_items(title, tmdb_id, 'tvshow', thumb, fan),
                 _trailer_ctx_items(tmdb_id, 'tvshow'))
        xbmcplugin.addDirectoryItem(
            _handle(), build_url(action='show_links', payload=payload), li, isFolder=True)
    if not found:
        _add_directory('[COLOR grey]No next episodes — watch some TV first![/COLOR]',
                       build_url(action='tvshows_root'), is_folder=False)
    xbmcplugin.setContent(_handle(), 'episodes')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)

def _check_debrid_expiry_notifications():
    """Check for expiring debrid services and show one notification per day.

    Returns a small status dictionary so the manual force action can report
    whether it actually checked accounts, was disabled/skipped, or failed.
    Each account is handled independently; one malformed provider response or
    notification failure must not prevent the other services from being
    checked.
    """
    result = {'status': 'disabled', 'accounts': 0, 'warnings': 0}
    try:
        if (ADDON.getSetting('debrid_expiry_notifications') or 'true').lower() != 'true':
            xbmc.log('COSMOS: Debrid expiry notifications are disabled.', xbmc.LOGDEBUG)
            return result
    except Exception:
        return result

    import time
    now = int(time.time())
    try:
        last_check_day = int(ADDON.getSetting('last_debrid_expiry_check_day') or '0')
    except (ValueError, TypeError, OverflowError):
        last_check_day = 0

    current_day = now // 86400  # Integer division to get day number

    # Only check once per day
    if current_day <= last_check_day:
        result['status'] = 'skipped'
        return result

    xbmc.log('COSMOS: Checking for expiring debrid services...', xbmc.LOGINFO)
    try:
        accounts = debrid.get_all_account_info()
        if not isinstance(accounts, (list, tuple)):
            raise TypeError('debrid account info was not a list')

        for acc in accounts:
            if not isinstance(acc, dict):
                xbmc.log('COSMOS: ignoring malformed debrid account record.', xbmc.LOGWARNING)
                continue
            result['accounts'] += 1
            try:
                if not acc.get('configured') or not acc.get('premium'):
                    continue

                days_left = acc.get('days_left')
                if days_left is None:
                    continue

                try:
                    days_left = int(days_left)
                except (ValueError, TypeError, OverflowError):
                    continue

                if 0 <= days_left <= 14:
                    service_name = str(acc.get('name') or 'Debrid Service')
                    if days_left > 1:
                        msg = f'{service_name} expires in {days_left} days.'
                    elif days_left == 1:
                        msg = f'{service_name} expires in 1 day.'
                    else:
                        msg = f'{service_name} expires today.'
                    try:
                        xbmcgui.Dialog().notification(
                            'Debrid Expiry Warning', msg,
                            xbmcgui.NOTIFICATION_WARNING, 8000)
                        result['warnings'] += 1
                    except Exception as notify_error:
                        xbmc.log(
                            f'COSMOS: expiry notification failed for {service_name}: '
                            f'{notify_error}', xbmc.LOGWARNING)
            except Exception as account_error:
                xbmc.log(
                    f'COSMOS: expiry check skipped malformed account '
                    f'{acc.get("name", "unknown")!r}: {account_error}',
                    xbmc.LOGWARNING)

        ADDON.setSetting('last_debrid_expiry_check_day', str(current_day))
        result['status'] = 'checked'
        xbmc.log(
            f'COSMOS: Debrid expiry check complete: {result["accounts"]} '
            f'account(s), {result["warnings"]} warning(s).', xbmc.LOGINFO)
    except Exception as e:
        result['status'] = 'failed'
        result['error'] = str(e)
        xbmc.log(f'COSMOS: Debrid expiry check failed: {e}', xbmc.LOGWARNING)
    return result

# --- Router -----------------------------------------------------------


import sys
import urllib.parse

def run(argv, default_base_url):
    # Parse the current invocation, not module-import state. Kodi can reuse
    # the language invoker for multiple plugin calls in one process.
    raw_query = argv[2] if len(argv) >= 3 else ''
    param_string = raw_query[1:] if raw_query.startswith('?') else raw_query
    params = dict(urllib.parse.parse_qsl(param_string, keep_blank_values=True))
    action = params.get('action', 'root')

    # Leaving Adult Lounge for the main Cosmos menu locks it immediately.
    if action == 'root':
        _lock_adult_lounge()

    # Keep the selected remote watched indicator fresh without blocking menu
    # rendering.  The watched module throttles this to a background sync.
    try:
        watched_mod.maybe_sync_remote()
    except Exception as e:
        xbmc.log(f'COSMOS: watched indicator sync trigger failed: {e}', xbmc.LOGDEBUG)
    
    # Show changelog modal once per new version
    if action == 'root':
        try:
            _show_changelog_if_updated()
        except Exception as e:
            xbmc.log(f'COSMOS: changelog gate failed: {e}', xbmc.LOGWARNING)
            
        # Check for debrid expiry
        try:
            _check_debrid_expiry_notifications()
        except Exception as e:
            xbmc.log(f'COSMOS: debrid expiry check failed: {e}', xbmc.LOGWARNING)

        # Auto-clear cache daily
        try:
            if (ADDON.getSetting('auto_clear_cache_enabled') or 'false').lower() == 'true':
                import time
                last_clear_ts = 0
                try:
                    last_clear_ts = int(ADDON.getSetting('last_auto_clear_ts') or '0')
                except (ValueError, TypeError):
                    pass
                
                try:
                    interval_days = int(ADDON.getSetting('auto_clear_cache_interval') or '1')
                except (ValueError, TypeError):
                    interval_days = 1
                interval_seconds = max(1, interval_days) * 24 * 3600

                if (time.time() - last_clear_ts) > interval_seconds:
                    _do_clear_cache(is_auto=True)
                    ADDON.setSetting('last_auto_clear_ts', str(int(time.time())))
        except Exception as e:
            xbmc.log(f'COSMOS: auto clear cache failed: {e}', xbmc.LOGWARNING)
            
    # so we don't interrupt playback, downloads, or background actions.
    if action == 'root':
        base_url = _effective_base_url(default_base_url)
        # Trigger hourly background scan of all enigma XML feeds
        try:
            _maybe_scan_newly_added(base_url)
        except Exception as e:
            xbmc.log(f'COSMOS: newly_added scan trigger failed: {e}', xbmc.LOGWARNING)
        # Show one-time toast when new items are detected
        try:
            _maybe_show_newly_added_toast()
        except Exception as e:
            xbmc.log(f'COSMOS: newly_added toast failed: {e}', xbmc.LOGWARNING)
        list_menu(base_url, is_root=True, fallback_url=default_base_url)
        return

    if action == 'debrid_account_status':
        _debrid_account_status()
        return

    if action == 'xxx_root':
        _xxx_root(params.get('adult_entry') == '1')
        return

    if action == 'effedupmovies_install':
        _install_effedupmovies()
        xbmcplugin.endOfDirectory(_handle(), succeeded=True, cacheToDisc=False)
        return


    if action == 'manyxxx_root':
        _manyxxx_root()
        return

    if action == 'manyxxx_list':
        _manyxxx_list(params.get('url') or manyxxx_mod.BASE_URL)
        return

    if action == 'manyxxx_categories':
        _manyxxx_categories()
        return


    if action == 'manyxxx_play':
        _manyxxx_play(params.get('url', ''), params.get('title', ''))
        return

    if action == 'hqpornxxx_root':
        _hqpornxxx_root()
        return

    if action == 'hqpornxxx_list':
        _hqpornxxx_list(params.get('url') or hqpornxxx_mod.BASE_URL)
        return

    if action == 'hqpornxxx_categories':
        _hqpornxxx_categories()
        return

    if action == 'hqpornxxx_channels':
        _hqpornxxx_channels()
        return

    if action == 'hqpornxxx_pornstars':
        _hqpornxxx_pornstars(params.get('page', '1'))
        return


    if action == 'hqpornxxx_play':
        _hqpornxxx_play(params.get('url', ''), params.get('title', ''))
        return

    if action == 'eporner_root':
        _eporner_root()
        return

    if action == 'eporner_categories':
        _eporner_categories()
        return

    if action == 'eporner_pornstars':
        _eporner_pornstars(params.get('page', '1'))
        return

    if action == 'eporner_channels':
        _eporner_channels(params.get('page', '1'))
        return

    if action == 'eporner_list':
        _eporner_list(params.get('page', '1'), params.get('order', 'latest'))
        return

    if action == 'eporner_web_list':
        _eporner_web_list(params.get('url') or 'https://www.eporner.com/best-videos/',
                          params.get('page', '1'))
        return

    if action == 'eporner_play':
        _eporner_play(params.get('url', ''), params.get('title', ''))
        return

    if action == 'menu':
        feed = params.get('feed') or _effective_base_url(default_base_url)
        feed = feed.replace('.xmll', '.xml')
        is_root = (feed == _effective_base_url(default_base_url))
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        list_menu(feed, is_root=is_root, page=page)
        return

    if action.startswith('nineanime_'):
        nineanime_mod.dispatch(params)
        return

    if action == 'show_links':
        _list_links(params.get('payload', '{}'))
        return

    if action == 'tv_seasons':
        _list_tv_seasons(params.get('feed', ''), params.get('tmdb', ''))
        return

    if action == 'tv_episodes':
        _list_tv_episodes(params.get('feed', ''), params.get('tmdb', ''),
                          params.get('season', ''))
        return

    if action == 'autoplay_next_episode':
        _autoplay_next_from_shows(params)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'play_link':
        _play_link(
            params.get('payload', '{}'),
            resume=(params.get('resume') == '1'),
            bypass_source=(params.get('direct') == '1'),
            prompt=(params.get('prompt', '1') != '0'),
            use_player=(params.get('use_player') == '1'),
        )
        return

    if action == 'open_settings':
        _open_settings()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'view_changelog':
        _show_changelog_if_updated(force=True)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'telegram_qr':
        try:
            from .telegram_qr_dialog import TelegramQrDialog
            dialog = TelegramQrDialog('TelegramQrDialog.xml', ADDON_PATH, 'Default', '720p')
            dialog.doModal()
            del dialog
        except Exception as exc:
            xbmc.log('COSMOS: Telegram QR dialog failed: %s' % exc, xbmc.LOGWARNING)
            xbmcgui.Dialog().ok('Telegram', 'Join us at https://t.me/Cosmos23456/1')
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'toggle_language_invoker':
        toggle_language_invoker()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'sync_resolveurl_creds':
        _sync_credentials_to_resolveurl()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'simkl_auth':
        # Change 'simkl_mod' to whatever you named your Simkl import at the top of the file
        simkl_mod.action_auth()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'simkl_revoke':
        simkl_mod.action_revoke()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'simkl_sync':
        simkl_mod.action_sync()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

     # ── Easynews Login Route ────────────────────────────────────────────
    if action == 'easynews_login':
        from resources.lib import easynews
        success = easynews.test_login() # Calls the test_login function in easynews.py
        if success:
            xbmcgui.Dialog().notification('Easynews', 'Login Successful!', xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification('Easynews', 'Login Failed - Check Credentials', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'usenet_downloader_test':
        from resources.lib import usenet_clients
        usenet_clients.action_test_connection()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    
    if action == 'favourites_list':
        _list_favourites()
        return

    if action == 'add_favourite':
        _add_favourite(params.get('payload', '{}'),
                       params.get('tmdb', ''),
                       params.get('content', 'movie'),
                       params.get('name', ''))
        return

    if action == 'remove_favourite':
        _remove_favourite(params.get('tmdb', ''),
                          params.get('content', 'movie'),
                          params.get('name', ''))
        return

    if action == 'open_favourite':
        _open_favourite(
            params.get('key', ''),
            root_feed=_effective_base_url(default_base_url),
        )
        return

    if action == 'mark_watched':
        ok = _mark_watched_locally({
            'tmdb': params.get('tmdb', ''),
            'title': params.get('name', ''),
            'content': 'episode',
            'season': params.get('season', ''),
            'episode': params.get('episode', ''),
        })
        _notify_watched_action('watched', ok)
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'mark_unwatched':
        ok = _mark_watched_locally({
            'tmdb': params.get('tmdb', ''),
            'title': params.get('name', ''),
            'content': 'episode',
            'season': params.get('season', ''),
            'episode': params.get('episode', ''),
        }, watched=False)
        _notify_watched_action('unwatched', ok)
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'mark_show_watched':
        _mark_show_watched_locally(params, watched=True)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'mark_show_unwatched':
        _mark_show_watched_locally(params, watched=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'mark_season_watched':
        _mark_season_watched_locally(params, watched=True)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'mark_season_unwatched':
        _mark_season_watched_locally(params, watched=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'mark_movie_watched':
        ok = _mark_watched_locally({
            'tmdb': params.get('tmdb', ''),
            'title': params.get('name', ''),
            'content': 'movie',
        })
        _notify_watched_action('watched', ok)
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'mark_movie_unwatched':
        ok = _mark_watched_locally({
            'tmdb': params.get('tmdb', ''),
            'title': params.get('name', ''),
            'content': 'movie',
        }, watched=False)
        _notify_watched_action('unwatched', ok)
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'clear_resume':
        _clear_resume(params.get('key', ''))
        return

    if action == 'remove_from_continue_watching':
        _remove_from_continue_watching(params)
        return

    if action == 'search':
        feed = params.get('feed') or _effective_base_url(default_base_url)
        _do_search(feed)
        return

    if action == 'search_results':
        feed = params.get('feed') or _effective_base_url(default_base_url)
        _list_search_results(
            feed,
            params.get('query', ''),
            page=params.get('page', '1'),
            search_source=params.get('search_source', 'both'),
        )
        return

    if action == 'downloads_list':
        _list_downloads()
        return

    if action == 'download_item':
        _download_item(params.get('payload', '{}'))
        return

    if action == 'play_local':
        _play_local(params.get('path', ''), resume=(params.get('resume') == '1'))
        return

    if action == 'clear_local_resume':
        _clear_local_resume(params.get('path', ''))
        return

    if action == 'delete_local':
        _delete_local(params.get('path', ''))
        return

    if action == 'clear_cache':
        _clear_cache()
        return
    if action == 'show_detected_regions':
        _show_detected_regions()
        return
    if action == 'test_inputstream':
        _test_inputstream()
        return
    if action == 'clear_provider_caches':
        _clear_provider_caches()
        return

    if action == 'clear_downloads_index':
        _clear_downloads_index()
        return

    if action == 'continue_watching':
        _list_continue_watching()
        return

    if action == 'mark_watched_from_cw':
        _mark_watched_from_cw(params)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'newly_added':
        feed = params.get('feed') or _effective_base_url(default_base_url)
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _list_newly_added(feed, page=page)
        return

    if action == 'sync_export':
        _sync_export()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'sync_import':
        _sync_import()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'clear_search_history':
        if xbmcgui.Dialog().yesno('C.O.S.M.O.S', 'Clear all search history?'):
            sh_mod.clear()
            xbmcgui.Dialog().notification('C.O.S.M.O.S', 'Search history cleared',
                                          xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'resume_interrupted':
        _resume_interrupted_download(params.get('part_path', ''))
        return

    if action == 'delete_interrupted':
        _delete_interrupted_part(params.get('part_path', ''))
        return

    if action == 'trailers':
        _trailers_root()
        return

    if action == 'trailers_list':
        _trailers_list(params.get('endpoint', ''))
        return

    if action == 'play_trailer':
        _play_trailer(params.get('tmdb', ''), params.get('content', 'movie'))
        return

    if action == 'actor_search':
        feed = params.get('feed') or _effective_base_url(default_base_url)
        _actor_search(feed, params.get('query', ''))
        return

    if action == 'link_zero':
        _link_zero(
            params.get('payload', '{}'),
            auto_next=(params.get('auto_next') == '1'),
        )
        return

    if action == 'trending_week':
        _trending_week()
        return

    if action == 'anime_root':
        _anime_root()
        return

    if action == 'music_root':
        _music_root()
        return

    if action == 'freebie_tv_root':
        _freebie_tv_root()
        return

    if action.startswith('vidcore_'):
        from . import vidcore
        vidcore.run(action, params, _handle(), _add_directory, build_url,
                    VIDCORE_ICON, FANART)
        return

    if action == 'samsungtvplus_root':
        from . import samsungtvplus
        samsungtvplus.root(_handle(), SAMSUNG_TVPLUS_ICON)
        return
    if action == 'samsungtvplus_play':
        from . import samsungtvplus
        samsungtvplus.play(_handle(), params.get('id', ''), params.get('region'))
        return
    if action in ('rakuten_root', 'rakuten_play'):
        from . import rakuten
        rakuten.run(action, params, _handle(), build_url, RAKUTEN_ICON)
        return
    if action == 'bbc_root':
        from . import bbc
        bbc.root(_handle())
        return

    if action.startswith('pluto_'):
        from . import pluto
        pluto.run(action, params, _add_directory, build_url, PLUTO_ICON, FANART)
        return

    if action.startswith('tubi_'):
        from . import tubi
        tubi.run(action, params, _add_directory, build_url, TUBI_ICON, TUBI_FANART)
        return

    if action.startswith('plex_'):
        from . import plex
        plex.run(action, params, _add_directory, build_url, PLEX_ICON, FANART)
        return

    if action == 'install_radiouk':
        _install_radiouk()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'install_wiki_trailers':
        _install_wiki_trailers()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action.startswith('musicmp3_'):
        from . import musicmp3
        musicmp3.run(action, params, _handle(), build_url,
                     f'{ADDON_PATH}resources/media/icon_musicmp3.png', FANART)
        return

    if action.startswith('tunein_'):
        from . import tunein
        tunein.run(action, params, _handle(), build_url,
                   _menu_icon('tunein_v2'),
                   f'{ADDON_PATH}resources/media/fanart_tunein.jpg')
        return

    if action == 'install_cartoonio':
        _install_cartoonio()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return


    if action == 'release_hub_root':
        _release_hub_root()
        return

    if action.startswith('torrentclaw_'):
        from . import torrentclaw
        torrentclaw.run(action, params, _handle(), build_url, _play_link,
                       _menu_icon('torrentclaw'), FANART)
        return

    if action == 'tracking_root':
        _tracking_root()
        return

    if action == 'punchplay_root':
        punchplay_mod.menu_root()
        return
    if action == 'punchplay_discover':
        from . import punchplay_discover
        punchplay_discover.menu(params.get('type', ''), params.get('category', ''))
        return
    if action == 'punchplay_search':
        from . import punchplay_discover
        punchplay_discover.search_menu(params.get('type', ''), params.get('q', ''))
        return
    if action == 'punchplay_catalog_action':
        from . import punchplay_actions
        punchplay_actions.action(params.get('operation', ''), params.get('payload', '{}'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'punchplay_auth':
        punchplay_mod.authorize()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'punchplay_disconnect':
        punchplay_mod.disconnect()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'punchplay_sync':
        punchplay_mod.action_sync()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'punchplay_in_progress':
        punchplay_mod.menu_in_progress(page=params.get('page', '1'))
        return
    if action == 'punchplay_now_playing':
        punchplay_mod.menu_now_playing()
        return
    if action == 'punchplay_continue_watching':
        punchplay_mod.menu_continue_watching(page=params.get('page', '1'))
        return
    if action == 'punchplay_calendar':
        punchplay_mod.menu_calendar(month=params.get('month', ''))
        return
    if action == 'punchplay_collection':
        punchplay_mod.menu_collection()
        return
    if action == 'punchplay_collection_movies':
        punchplay_mod.menu_collection_items(
            'movie', cursor=params.get('cursor', ''),
        )
        return
    if action == 'punchplay_collection_shows':
        punchplay_mod.menu_collection_items(
            'show', cursor=params.get('cursor', ''),
        )
        return
    if action == 'punchplay_my_lists':
        punchplay_mod.menu_my_lists(cursor=params.get('cursor', ''))
        return
    if action == 'punchplay_list_items':
        punchplay_mod.menu_list_items(
            params.get('list_id', ''), name=params.get('name', ''),
            dynamic=params.get('dynamic', '0'),
            offset=params.get('offset', '0'),
        )
        return
    if action == 'punchplay_play_in_progress':
        punchplay_mod.play_in_progress(
            params.get('payload', '{}'), params.get('position', '0'),
            params.get('duration', '0'),
        )
        return
    if action == 'punchplay_delete_in_progress':
        punchplay_mod.action_delete_in_progress(params.get('progress_id', ''))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'sports_hub':
        _sports_hub()
        return

    if action == 'watchwrestling_root':
        _watchwrestling_menu()
        return

    if action in ('watchwrestling_list', 'watchwrestling_sources'):
        _watchwrestling_menu(params.get('page', watchwrestling_mod.BASE),
                            sources=action == 'watchwrestling_sources',
                            title=params.get('title', 'Watch Wrestling'),
                            offset=params.get('offset', '0'))
        return

    if action == 'watchwrestling_play':
        _watchwrestling_play(params.get('source', ''), params.get('title', 'Watch Wrestling'))
        return

    if action == 'wwe_archive':
        _wwe_archive(params.get('page', '1'))
        return

    if action == 'wwe_sources':
        _wwe_sources(params.get('page', ''), params.get('title', 'WWE Archive'))
        return

    if action == 'wwe_play':
        filehost.play_direct_link(params.get('source', ''),
                                  title=params.get('title', ''), use_player=True)
        return


    if action == 'refooty_root':
        _refooty_root()
        return

    if action == 'refooty_full_matches':
        _refooty_full_matches(params.get('page', '1'))
        return

    if action == 'refooty_latest':
        _refooty_latest(params.get('page', '1'))
        return

    if action == 'refooty_countries':
        _refooty_countries()
        return

    if action == 'refooty_european':
        _refooty_european()
        return

    if action == 'refooty_leagues':
        _refooty_leagues(params.get('country', ''))
        return

    if action == 'refooty_category':
        _refooty_category(params.get('url', ''), params.get('page', '1'))
        return

    if action == 'refooty_play':
        page_url = params.get('page', '')
        title = params.get('title', 'ReFooty')
        try:
            media_url = refooty_mod.resolve_video(page_url)
        except Exception as exc:
            xbmc.log(f'COSMOS ReFooty resolver: {exc}', xbmc.LOGWARNING)
            media_url = ''
        if media_url:
            filehost.play_direct_link(media_url, title=title, use_player=True)
        else:
            xbmcgui.Dialog().notification(
                'ReFooty', 'No playable video source found',
                xbmcgui.NOTIFICATION_WARNING, 4000,
            )
        return

    if action == 'tools':
        _tools_menu(_effective_base_url(default_base_url))
        return

    if action == 'newly_added_scan':
        _manual_scan_newly_added(params.get('feed') or _effective_base_url(default_base_url))
        return

    if action == 'ookla_speedtest':
        ookla_speedtest_mod.run()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'install_inputstream_adaptive':
        nineanime_mod.install_inputstream_adaptive()
        return

    if action == 'inputstream_helper_windows':
        _inputstream_helper_windows()
        return

    if action == 'dead_link_check':
        feed = params.get('feed') or _effective_base_url(default_base_url)
        tools_mod.run_dead_link_checker(feed)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'playlist_health_check':
        feed = params.get('feed') or _effective_base_url(default_base_url)
        tools_mod.run_playlist_health_checker(feed)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'dead_link_report':
        tools_mod._show_report()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'playlist_health_report':
        tools_mod._show_health_report()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'debug_bundle_view':
        debug_bundle_mod.show_last_bundle()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'debug_bundle_open_folder':
        debug_bundle_mod.open_bundle_folder()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'debug_bundle_download_all':
        debug_bundle_mod.download_all_bundles()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'debug_bundle_clear_all':
        debug_bundle_mod.clear_all_bundles()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'sync_auto_now':
        sync_mod.auto_upload_now()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    # ── Simkl routes ────────────────────────────────────────────────────
    if action in ('simkl_search', 'simkl_discover', 'simkl_calendar', 'simkl_catalog_item', 'simkl_catalog_link',
                  'simkl_catalog_write'):
        from . import simkl_catalog
        simkl_catalog.dispatch(action, params)
        return
    if action == 'simkl_root':
        simkl_mod.menu_root()
        return
    if action == 'simkl_playback':
        simkl_mod.menu_playback(page=params.get('page', '1'))
        return
    if action == 'simkl_next_episodes':
        simkl_mod.menu_next_episodes()
        return
    if action == 'simkl_ratings':
        simkl_mod.menu_ratings()
        return
    if action == 'simkl_delete_playback':
        simkl_mod.action_delete_playback(params.get('playback_id', ''))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_auth':
        simkl_mod.action_auth()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_revoke':
        simkl_mod.action_revoke()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_sync':
        simkl_mod.action_sync()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_watchlist':
        simkl_mod.action_watchlist()
        return
    if action == 'simkl_list_items':
        simkl_mod.menu_list_items(params.get('list_name', ''), page=params.get('page', '1'))
        return
    if action == 'simkl_custom_lists':
        simkl_mod.menu_custom_lists()
        return
    if action == 'simkl_custom_list_items':
        simkl_mod.menu_custom_list_items(params.get('list_id', ''), page=params.get('page', '1'))
        return
    if action == 'simkl_history':
        simkl_mod.action_history(page=params.get('page', '1'))
        return
    if action == 'simkl_show_seasons':
        simkl_mod.menu_show_seasons(params.get('payload', '{}'))
        return
    if action == 'simkl_show_episodes':
        simkl_mod.menu_show_episodes(params.get('payload', '{}'), season=params.get('season', ''))
        return
    if action == 'simkl_add_watchlist':
        simkl_mod.action_add_watchlist(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_mark_watched':
        simkl_mod.action_mark_watched(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_rate':
        simkl_mod.action_rate(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_remove_rating':
        simkl_mod.action_remove_rating(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_remove_from_watchlist':
        simkl_mod.action_remove_from_watchlist(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_add_to_collection':
        simkl_mod.action_add_to_collection(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_remove_from_collection':
        simkl_mod.action_remove_from_collection(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_clear_collection':
        simkl_mod.action_clear_collection()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_remove_from_history':
        simkl_mod.action_remove_from_history(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'simkl_clear_history':
        simkl_mod.action_clear_history()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    # ── Trakt routes ────────────────────────────────────────────────────
    if action == 'trakt_root':
        trakt_ui_mod.menu_root()
        return
    if action == 'trakt_search':
        trakt_ui_mod.menu_search()
        return
    if action == 'trakt_search_items':
        try:
            page = max(1, int(params.get('page', '1') or 1))
        except (TypeError, ValueError):
            page = 1
        trakt_ui_mod.menu_search_items(
            params.get('kind', 'movie,show'), params.get('query'), page)
        return
    if action == 'trakt_discover':
        trakt_ui_mod.menu_discover()
        return
    if action == 'trakt_discover_kind':
        trakt_ui_mod.menu_discover_kind(params.get('kind', 'movies'))
        return
    if action == 'trakt_discover_items':
        try:
            page = max(1, int(params.get('page', '1') or 1))
        except (TypeError, ValueError):
            page = 1
        trakt_ui_mod.menu_discover_items(
            params.get('kind', 'movies'), params.get('category', 'trending'), page)
        return
    if action == 'trakt_continue_watching':
        if not trakt_ui_mod._require_auth():
            xbmcplugin.endOfDirectory(_handle(), succeeded=False)
            return
        _list_continue_watching(service='Trakt')
        return
    if action == 'trakt_auth':
        trakt_ui_mod.action_auth()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'trakt_revoke':
        trakt_ui_mod.action_revoke()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'trakt_watchlist':
        trakt_ui_mod.menu_watchlist()
        return
    if action == 'trakt_watchlist_kind':
        trakt_ui_mod.menu_watchlist_kind(
            params.get('kind', 'movies'), page=int(params.get('page', '1') or 1))
        return
    if action == 'trakt_history':
        trakt_ui_mod.menu_history()
        return
    if action == 'trakt_history_kind':
        trakt_ui_mod.menu_history_kind(
            params.get('kind', 'movies'), page=int(params.get('page', '1') or 1))
        return
    if action == 'trakt_my_lists':
        trakt_ui_mod.menu_my_lists(page=int(params.get('page', '1') or 1))
        return
    if action == 'trakt_liked_lists':
        trakt_ui_mod.menu_liked_lists(page=int(params.get('page', '1') or 1))
        return
    if action == 'trakt_following':
        trakt_ui_mod.menu_following(page=int(params.get('page', '1') or 1))
        return
    if action == 'trakt_user_lists':
        trakt_ui_mod.menu_user_lists(
            params.get('user', ''), page=int(params.get('page', '1') or 1))
        return
    if action == 'trakt_list_items':
        trakt_ui_mod.menu_list_items(params.get('user', ''),
                                     params.get('list_id', ''),
                                     page=int(params.get('page', '1') or 1))
        return
    if action == 'trakt_import_list_to_simkl':
        trakt_ui_mod.action_import_list_to_simkl(
            params.get('user', ''),
            params.get('list_id', ''),
            params.get('list_name', ''),
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'trakt_like_list':
        trakt_ui_mod.action_like_list(params.get('user', ''),
                                      params.get('list_id', ''))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'trakt_unlike_list':
        trakt_ui_mod.action_unlike_list(params.get('user', ''),
                                        params.get('list_id', ''))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'trakt_follow_user':
        trakt_ui_mod.action_follow_user(params.get('user', ''))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'trakt_follow_all':
        trakt_ui_mod.action_follow_all()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    if action == 'trakt_open_web':
        trakt_ui_mod.action_open_web(params.get('url', ''))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'trakt_test':
        trakt_ui_mod.action_test_connection()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'trakt_tv_seasons':
        trakt_ui_mod.menu_tv_seasons(
            params.get('tmdb', ''),
            imdb=params.get('imdb', ''),
            trakt_id=params.get('trakt', ''),
            title=params.get('title', ''),
            year=params.get('year', ''),
        )
        return

    if action == 'trakt_tv_episodes':
        trakt_ui_mod.menu_tv_episodes(
            params.get('tmdb', ''),
            params.get('season', ''),
            imdb=params.get('imdb', ''),
            trakt_id=params.get('trakt', ''),
            title=params.get('title', ''),
            year=params.get('year', ''),
        )
        return

    if action == 'trakt_add_watchlist':
        trakt_ui_mod.action_add_watchlist(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'trakt_remove_watchlist':
        trakt_ui_mod.action_remove_watchlist(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
    
    if action == 'trakt_mark_watched':
        trakt_ui_mod.action_mark_watched(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
        
    
    if action == 'trakt_remove_from_history':
        trakt_ui_mod.action_remove_from_history(params.get('payload'))
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return
        

    # ── DDLValley routes ─────────────────────────────────────────────────
    if action == 'ddlvalley':
        _ddlvalley_root()
        return
    if action == 'ddlvalley_movies_menu':
        _ddlvalley_movies_menu()
        return
    if action == 'ddlvalley_tv_menu':
        _ddlvalley_tv_menu()
        return
    if action == 'ddlvalley_cat':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _ddlvalley_list(params.get('category', 'movies'), page=page)
        return
    # Backward-compat aliases
    if action == 'ddlvalley_movies':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _ddlvalley_list('movies', page=page)
        return
    if action == 'ddlvalley_tv':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _ddlvalley_list('tv-shows', page=page)
        return
    if action == 'ddlvalley_search':
        _ddlvalley_search()
        return
    if action == 'ddlvalley_search_results':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _ddlvalley_search_results(params.get('query', ''), page=page)
        return
    if action == 'ddlvalley_post':
        _ddlvalley_post(params.get('url', ''))
        return

    # ── RlsBB routes ──────────────────────────────────────────────────────
    if action == 'rlsbb':
        _rlsbb_root()
        return
    if action == 'rlsbb_movies_menu':
        _rlsbb_movies_menu()
        return
    if action == 'rlsbb_tv_menu':
        _rlsbb_tv_menu()
        return
    if action == 'rlsbb_cat':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _rlsbb_cat(params.get('category', 'movies'), page=page)
        return
    if action == 'rlsbb_latest':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _rlsbb_latest(page=page)
        return
    if action == 'rlsbb_ufc':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _rlsbb_ufc(page=page)
        return
    if action == 'rlsbb_post':
        _rlsbb_post(params.get('url', ''))
        return
    if action == 'rlsbb_search':
        _rlsbb_search()
        return
    if action == 'rlsbb_search_results':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _rlsbb_search_results(params.get('query', ''), page=page)
        return

    if action == 'show_info':
        _show_info(
            title=params.get('title', ''),
            tmdb_id=params.get('tmdb', ''),
            content=params.get('content', 'movie'),
            poster=params.get('poster', ''),
            fanart=params.get('fanart', ''),
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'show_extras':
        _show_extras(
            title=params.get('title', ''),
            tmdb_id=params.get('tmdb', ''),
            content=params.get('content', 'movie'),
            poster=params.get('poster', ''),
            fanart=params.get('fanart', ''),
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    # ── Cloud (debrid file browser) ──────────────────────────────────
    if action == 'cloud_root':
        cloud_mod.cloud_root()
        return

    if action == 'cloud_browse':
        cloud_mod.cloud_browse(params.get('svc', ''), folder_id=params.get('fid', ''))
        return

    if action == 'cloud_files':
        cloud_mod.cloud_files(params.get('svc', ''), params.get('id', ''))
        return

    if action == 'cloud_play':
        cloud_mod.cloud_play(
            params.get('svc', ''),
            link=params.get('link', ''),
            tid=params.get('tid', ''),
            fid=params.get('fid', '0'),
        )
        return

    if action == 'cloud_delete':
        cloud_mod.cloud_delete(params.get('svc', ''), params.get('id', ''),
                               item_type=params.get('item_type', 'file'))
        return

    if action == 'cloud_add':
        cloud_mod.cloud_add(svc=params.get('svc', ''))
        return

    if action == 'auth_aio':
        _auth_aio()
        return

    if action == 'revoke_aio':
        _revoke_aio()
        return

    if action.startswith('auth_') or action.startswith('revoke_'):
        _run_action(action)
        return

    # ── File Host Sync ───────────────────────────────────────────────────
    if action == 'sync_filehost_logins':
        _sync_filehost_logins()
        return

    # ── TMDB Movies & TV Shows browser routes ────────────────────────────
    if action == 'movies_root':
        _movies_root()
        return

    if action == 'tvshows_root':
        _tvshows_root()
        return

    if action == 'tmdb_tv_seasons':
        _tmdb_tv_seasons(
            params.get('tmdb', ''),
            name=params.get('name', ''),
            year=params.get('year', ''),
            imdb=params.get('imdb', ''),
            poster=params.get('poster', ''),
            fanart=params.get('fanart', ''),
        )
        return

    if action == 'tmdb_tv_episodes':
        _tmdb_tv_episodes(
            params.get('tmdb', ''),
            params.get('season', '1'),
            name=params.get('name', ''),
            year=params.get('year', ''),
            imdb=params.get('imdb', ''),
            poster=params.get('poster', ''),
            fanart=params.get('fanart', ''),
        )
        return

    if action == 'tmdb_browse':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _tmdb_browse(params.get('category', 'popular'), params.get('content', 'movie'), page=page)
        return

    if action == 'tmdb_genres':
        _tmdb_genres(params.get('content', 'movie'))
        return

    if action == 'tmdb_by_genre':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _tmdb_by_genre(params.get('genre_id', ''), params.get('genre_name', ''),
                       params.get('content', 'movie'), page=page)
        return

    if action == 'tmdb_years':
        _tmdb_years(params.get('content', 'movie'))
        return

    if action == 'tmdb_by_year':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _tmdb_by_year(params.get('year', ''), params.get('content', 'movie'), page=page)
        return

    if action == 'tmdb_decades':
        _tmdb_decades(params.get('content', 'movie'))
        return

    if action == 'tmdb_by_decade':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _tmdb_by_decade(params.get('decade', ''), params.get('content', 'movie'), page=page)
        return

    if action == 'tmdb_certs':
        _tmdb_certs(params.get('content', 'movie'))
        return

    if action == 'tmdb_by_cert':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _tmdb_by_cert(params.get('cert', ''), params.get('content', 'movie'), page=page)
        return

    if action == 'tmdb_providers':
        _tmdb_providers(params.get('content', 'movie'))
        return

    if action == 'tmdb_by_provider':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _tmdb_by_provider(params.get('provider_id', ''), params.get('provider_name', ''),
                           params.get('content', 'movie'), page=page)
        return

    if action == 'tmdb_languages':
        _tmdb_languages(params.get('content', 'movie'))
        return

    if action == 'tmdb_by_language':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _tmdb_by_language(params.get('lang', ''), params.get('content', 'movie'), page=page)
        return

    if action == 'tmdb_networks':
        _tmdb_networks()
        return

    if action == 'tmdb_by_network':
        try:
            page = max(1, int(params.get('page', '1') or '1'))
        except (ValueError, TypeError):
            page = 1
        _tmdb_by_network(params.get('network_id', ''), params.get('network_name', ''), page=page)
        return

    if action == 'tmdb_because_you_watched':
        _tmdb_because_you_watched(params.get('content', 'movie'))
        return

    if action == 'tmdb_watched':
        _tmdb_watched(params.get('content', 'movie'))
        return

    if action == 'tmdb_recently_watched':
        _tmdb_recently_watched(params.get('content', 'movie'))
        return

    if action == 'tmdb_in_progress':
        _tmdb_in_progress(params.get('content', 'movie'))
        return

    if action == 'tmdb_recently_watched_episodes':
        _tmdb_recently_watched_episodes()
        return

    if action == 'tmdb_in_progress_episodes':
        _tmdb_in_progress_episodes()
        return

    if action == 'tmdb_random_next_episodes':
        _tmdb_random_next_episodes()
        return

    if action == 'opensubtitles_search':
        import json as _json
        try:
            _sub_pl = _json.loads(params.get('payload', '{}'))
        except (TypeError, ValueError):
            xbmcgui.Dialog().notification(
                'Subtitles', 'Invalid subtitle request.',
                xbmcgui.NOTIFICATION_ERROR, 3000)
            xbmcplugin.endOfDirectory(_handle(), succeeded=False)
            return
        if not isinstance(_sub_pl, dict):
            xbmcgui.Dialog().notification(
                'Subtitles', 'Invalid subtitle request.',
                xbmcgui.NOTIFICATION_ERROR, 3000)
            xbmcplugin.endOfDirectory(_handle(), succeeded=False)
            return
        opensubtitles_mod.pick_and_download(
            title=_sub_pl.get('title', ''),
            imdb_id=_sub_pl.get('imdb', ''),
            tmdb_id=_sub_pl.get('tmdb', ''),
            content=_sub_pl.get('content', 'movie'),
            season=_sub_pl.get('season'),
            episode=_sub_pl.get('episode'),
        )
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'toggle_auto_subtitles':
        current = (ADDON.getSetting('subtitle_autoload_enabled') or '').strip().lower() == 'true'
        enabled = not current
        ADDON.setSetting('subtitle_autoload_enabled', 'true' if enabled else 'false')
        opensubtitles_mod.apply_to_current_playback()
        xbmcgui.Dialog().notification(
            'Subtitles',
            'Auto-load subtitles: On' if enabled else 'Auto-load subtitles: Off',
            xbmcgui.NOTIFICATION_INFO,
            2500,
        )
        xbmc.executebuiltin('Container.Refresh')
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'opensubtitles_login':
        opensubtitles_mod.login()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'opensubtitles_login_from_settings':
        # Triggered automatically via onchange on the password field —
        # reads credentials directly from settings, no dialog needed.
        opensubtitles_mod.login_from_settings()
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    if action == 'opensubtitles_logout':
        opensubtitles_mod.logout()
        xbmcgui.Dialog().notification(
            'Subtitles', 'Logged out from OpenSubtitles.',
            xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    xbmc.log(f'COSMOS: unknown action {action}', xbmc.LOGWARNING)
    xbmcplugin.endOfDirectory(_handle(), succeeded=False)

