"""Cloud browser UI for all configured debrid services.

Lists / adds / deletes items in the user's Real-Debrid, Premiumize, Torbox,
AllDebrid, and Offcloud accounts. Designed to share the same `build_url` helper and
ListItem conventions used in cosmos.py – this module is dispatched to from
the main router and emits directory rows + xbmc dialogs.
"""

import sys
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcplugin

from . import debrid


# ── Service registry ────────────────────────────────────────────────────
SERVICES = {
    'rd': {'name': 'Real-Debrid',  'color': 'gold',       'icon': 'DefaultNetwork.png'},
    'pm': {'name': 'Premiumize',   'color': 'orange',     'icon': 'DefaultNetwork.png'},
    'tb': {'name': 'Torbox',       'color': 'deepskyblue','icon': 'DefaultNetwork.png'},
    'ad': {'name': 'AllDebrid',    'color': 'springgreen','icon': 'DefaultNetwork.png'},
    'oc': {'name': 'Offcloud',     'color': 'violet',     'icon': 'DefaultNetwork.png'},
    # LinkSnappy is supported by the resolver engine, but its official API
    # does not expose a user cloud/torrent listing like the services above.
    'ls': {'name': 'LinkSnappy',   'color': 'skyblue',    'icon': 'DefaultNetwork.png'},
}

VIDEO_EXTS = ('.mkv', '.mp4', '.avi', '.mov', '.wmv', '.m4v', '.webm', '.ts', '.flv')


def _handle():
    return int(sys.argv[1])


def _build_url(**kw):
    """Same scheme cosmos.py uses: plugin://<id>/?..."""
    base = sys.argv[0]
    return f"{base}?{urlencode(kw)}"


def _add_row(label, url, *, folder=True, playable=False, art=None, info=None,
             context=None):
    li = xbmcgui.ListItem(label=label)
    art = art or {}
    li.setArt({
        'icon':  art.get('icon',  'DefaultFolder.png'),
        'thumb': art.get('thumb', art.get('icon', 'DefaultFolder.png')),
        'fanart': art.get('fanart', ''),
    })
    if playable:
        li.setProperty('IsPlayable', 'true')
    if info:
        try:
            tag = li.getVideoInfoTag()
            if info.get('title'):  tag.setTitle(info['title'])
            if info.get('plot'):   tag.setPlot(info['plot'])
            if info.get('size'):   tag.setSize(info['size'])
        except Exception:
            pass
    if context:
        li.addContextMenuItems(context, replaceItems=False)
    xbmcplugin.addDirectoryItem(_handle(), url, li, isFolder=folder)


def _fmt_bytes(n):
    try:
        n = int(n)
    except (TypeError, ValueError):
        return ''
    for unit, step in (('GB', 1024**3), ('MB', 1024**2), ('KB', 1024)):
        if n >= step:
            return f'{n/step:.2f} {unit}'
    return f'{n} B'


def _state_color(state):
    s = (state or '').lower()
    if s in ('downloaded', 'cached', 'completed', 'finished',
             'seeding', 'uploading', 'ready'):
        return 'lime'
    if s in ('downloading', 'queued', 'magnet_conversion', 'magnet_error',
             'compressing', 'processing', 'in_queue', 'waiting'):
        return 'yellow'
    if 'error' in s or s in ('failed', 'dead', 'virus', 'magnet_error'):
        return 'red'
    return 'silver'


# ── Root: list configured services ──────────────────────────────────────
def cloud_root():
    """Show one row per authorized debrid service + an 'Add to cloud' shortcut."""
    xbmc.log('COSMOS [CLOUD] cloud_root', xbmc.LOGDEBUG)
    services = debrid.get_cloud_services()  # [(name, obj, code), ...]
    xbmc.log(f'COSMOS [CLOUD] cloud_root  services={[c for _,_,c in services]}', xbmc.LOGDEBUG)
    if not services:
        _add_row(
            '[COLOR red][B]No debrid services authorized[/B][/COLOR]   '
            '[COLOR grey](open Settings → Debrid)[/COLOR]',
            _build_url(action='open_settings'), folder=False,
        )
    else:
        for _name, _obj, code in services:
            meta = SERVICES.get(code, {})
            if code == 'ls':
                label = (f"[COLOR {meta.get('color','white')}][B]{meta.get('name', code)}"
                         f"[/B][/COLOR]   [COLOR grey]Link resolver · no cloud library API[/COLOR]")
            else:
                label = (f"[COLOR {meta.get('color','white')}][B]{meta.get('name', code)}"
                         f"[/B][/COLOR]   [COLOR grey]Browse cloud · Add · Delete[/COLOR]")
            ctx = [
                ('[COLOR cyan]Add magnet / link …[/COLOR]',
                 f'RunPlugin({_build_url(action="cloud_add", svc=code)})'),
            ]
            _add_row(label, _build_url(action='cloud_browse', svc=code),
                     context=ctx, art={'icon': meta.get('icon')})

        # Quick "add to any" entry
        _add_row(
            '[COLOR cyan][B]+ Add magnet / link to cloud[/B][/COLOR]',
            _build_url(action='cloud_add'), folder=False,
        )

    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── Browse a single service ─────────────────────────────────────────────
def cloud_browse(svc, folder_id=''):
    """List torrents/files for the given service code."""
    xbmc.log(f'COSMOS [CLOUD] cloud_browse  svc={svc!r}  folder_id={folder_id!r}', xbmc.LOGDEBUG)
    if svc not in SERVICES:
        xbmcgui.Dialog().notification('Cloud', f'Unknown service: {svc}',
                                      xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        return

    meta = SERVICES[svc]
    header = (f"[COLOR {meta['color']}][B]{meta['name']}[/B][/COLOR]   "
              f"[COLOR grey]+ Add new[/COLOR]")
    _add_row(header, _build_url(action='cloud_add', svc=svc), folder=False)

    if svc == 'rd':
        items = debrid.rd_get_torrents()
        _list_torrents(svc, items)
    elif svc == 'tb':
        items = debrid.tb_get_torrents()
        _list_torrents(svc, items)
    elif svc == 'ad':
        items = debrid.ad_get_magnets()
        _list_torrents(svc, items)
    elif svc == 'pm':
        _list_premiumize(folder_id)
    elif svc == 'oc':
        _list_torrents(svc, debrid.oc_get_cloud_items())
    elif svc == 'ls':
        _add_row(
            '[COLOR grey]LinkSnappy resolves supported links but does not expose '
            'a browsable cloud/torrent library endpoint.[/COLOR]',
            _build_url(action='cloud_add', svc='ls'),
            folder=False,
        )

    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


def _list_torrents(svc, items):
    """Render torrent-style listing (RD / TB / AD)."""
    if not items:
        _add_row('[COLOR grey]No items in cloud yet — use “+ Add” above.[/COLOR]',
                 _build_url(action='cloud_root'), folder=False)
        return
    for it in items:
        state = it.get('status', '')
        size  = it.get('size', '')
        prog  = it.get('progress', 0)
        scolor = _state_color(state)
        prog_str = f' · {prog}%' if 0 < prog < 100 else ''
        label = (f"{it.get('name','Unknown')}   "
                 f"[COLOR grey]· {size}[/COLOR]   "
                 f"[COLOR {scolor}][{state}{prog_str}][/COLOR]")
        ctx = [
            ('[COLOR red]Delete from cloud[/COLOR]',
             f'RunPlugin({_build_url(action="cloud_delete", svc=svc, id=str(it.get("id","")))})'),
        ]
        _add_row(
            label,
            _build_url(action='cloud_files', svc=svc, id=str(it.get('id', ''))),
            context=ctx,
        )


def _list_premiumize(folder_id):
    """Render Premiumize folder/file listing (recursive folders supported)."""
    items = debrid.pm_get_cloud_files(folder_id or None)
    if not items:
        _add_row('[COLOR grey]Folder empty.[/COLOR]',
                 _build_url(action='cloud_browse', svc='pm'), folder=False)
        return
    for it in items:
        size = it.get('size', '')
        if it.get('type') == 'folder':
            label = f"[COLOR yellow][B]{it['name']}/[/B][/COLOR]"
            ctx = [('[COLOR red]Delete folder[/COLOR]',
                    f'RunPlugin({_build_url(action="cloud_delete", svc="pm", id=str(it["id"]), item_type="folder")})')]
            _add_row(
                label,
                _build_url(action='cloud_browse', svc='pm', fid=str(it['id'])),
                context=ctx,
            )
        else:
            color = 'lime' if it.get('is_video') else 'silver'
            label = f"[COLOR {color}]{it['name']}[/COLOR]   [COLOR grey]· {size}[/COLOR]"
            ctx = [('[COLOR red]Delete file[/COLOR]',
                    f'RunPlugin({_build_url(action="cloud_delete", svc="pm", id=str(it["id"]))})')]
            play_url = _build_url(action='cloud_play', svc='pm',
                                  link=it.get('link', ''))
            _add_row(label, play_url, folder=False, playable=True, context=ctx)


# ── File listing inside a torrent ───────────────────────────────────────
def cloud_files(svc, item_id):
    """List files belonging to a torrent so the user can pick one to play."""
    xbmc.log(f'COSMOS [CLOUD] cloud_files  svc={svc!r}  item_id={item_id!r}', xbmc.LOGDEBUG)
    if svc == 'rd':
        files = debrid.rd_get_torrent_files(item_id)
    elif svc == 'tb':
        files = debrid.tb_get_torrent_files(item_id)
    elif svc == 'ad':
        files = debrid.ad_get_magnet_files(item_id)
    elif svc == 'oc':
        files = debrid.oc_get_cloud_files(item_id)
    else:
        files = []

    if not files:
        _add_row('[COLOR grey]No files (still downloading?)[/COLOR]',
                 _build_url(action='cloud_browse', svc=svc), folder=False)
        xbmcplugin.endOfDirectory(_handle(), succeeded=True)
        return

    for f in files:
        is_video = f.get('is_video')
        if is_video is None:
            is_video = (f.get('name', '').lower().endswith(VIDEO_EXTS))
        color = 'lime' if is_video else 'silver'
        size = f.get('size', '')
        label = f"[COLOR {color}]{f.get('name','file')}[/COLOR]   [COLOR grey]· {size}[/COLOR]"

        if svc == 'tb':
            url = _build_url(action='cloud_play', svc='tb',
                             tid=str(item_id), fid=str(f.get('id', 0)))
        else:
            url = _build_url(action='cloud_play', svc=svc, link=f.get('link', ''))
        _add_row(label, url, folder=False, playable=True)

    xbmcplugin.setContent(_handle(), 'files')
    xbmcplugin.endOfDirectory(_handle(), succeeded=True)


# ── Resolve & play ──────────────────────────────────────────────────────
def cloud_play(svc, link='', tid='', fid='0'):
    """Resolve a cloud file to a streamable URL and hand it to Kodi."""
    xbmc.log(
        f'COSMOS [CLOUD] cloud_play  svc={svc!r}  tid={tid!r}  fid={fid!r}'
        f'  link={link[:80]!r}',
        xbmc.LOGDEBUG,
    )
    final = None
    try:
        if svc == 'tb' and tid:
            xbmc.log(f'COSMOS [CLOUD] cloud_play  resolving via Torbox  tid={tid}  fid={fid}', xbmc.LOGDEBUG)
            final = debrid.tb_get_download_link(tid, fid or 0)
        elif svc == 'rd' and link:
            xbmc.log(f'COSMOS [CLOUD] cloud_play  resolving via RealDebrid  link={link[:80]!r}', xbmc.LOGDEBUG)
            rd = debrid.RealDebrid()
            final = rd.unrestrict_link(link)
        elif svc == 'pm' and link:
            xbmc.log(f'COSMOS [CLOUD] cloud_play  Premiumize direct link  link={link[:80]!r}', xbmc.LOGDEBUG)
            # PM /folder/list already returns direct streamable links.
            final = link
        elif svc == 'ad' and link:
            xbmc.log(f'COSMOS [CLOUD] cloud_play  resolving via AllDebrid  link={link[:80]!r}', xbmc.LOGDEBUG)
            ad = debrid.AllDebrid()
            final = ad.unrestrict_link(link)
        elif svc == 'ls' and link:
            xbmc.log(f'COSMOS [CLOUD] cloud_play  resolving via LinkSnappy  link={link[:80]!r}', xbmc.LOGDEBUG)
            ls = debrid.LinkSnappy()
            final = ls.unrestrict_link(link)
        elif svc == 'oc' and link:
            xbmc.log(f'COSMOS [CLOUD] cloud_play  Offcloud direct link  link={link[:80]!r}', xbmc.LOGDEBUG)
            final = link
        else:
            xbmc.log(f'COSMOS [CLOUD] cloud_play  no handler matched svc={svc!r}', xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f'COSMOS [CLOUD] cloud_play  EXCEPTION svc={svc!r}: {e}', xbmc.LOGERROR)

    if not final:
        xbmc.log(f'COSMOS [CLOUD] cloud_play  FAILED — no final URL  svc={svc!r}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Cloud', 'Could not resolve file',
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.setResolvedUrl(_handle(), False, xbmcgui.ListItem())
        return

    xbmc.log(f'COSMOS [CLOUD] cloud_play  OK  final={str(final)[:120]!r}', xbmc.LOGDEBUG)
    li = xbmcgui.ListItem(path=final)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(_handle(), True, li)


# ── Delete ──────────────────────────────────────────────────────────────
def cloud_delete(svc, item_id, item_type='file'):
    xbmc.log(f'COSMOS [CLOUD] cloud_delete  svc={svc!r}  item_id={item_id!r}', xbmc.LOGDEBUG)
    if not item_id:
        xbmc.log('COSMOS [CLOUD] cloud_delete  no item_id — aborting', xbmc.LOGWARNING)
        return
    if not xbmcgui.Dialog().yesno(
        'Confirm delete',
        f'Remove this item from {SERVICES.get(svc,{}).get("name", svc)}?'
    ):
        xbmc.log('COSMOS [CLOUD] cloud_delete  user cancelled', xbmc.LOGDEBUG)
        return
    ok = debrid.delete_cloud_item(svc, item_id, item_type=item_type)
    xbmc.log(f'COSMOS [CLOUD] cloud_delete  result={ok}  svc={svc!r}  item_id={item_id!r}', xbmc.LOGDEBUG)
    xbmcgui.Dialog().notification(
        'Cloud',
        'Deleted' if ok else 'Delete failed',
        xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR,
        3000,
    )
    xbmc.executebuiltin('Container.Refresh')


# ── Add a magnet / link ─────────────────────────────────────────────────
def cloud_add(svc=''):
    """Prompt the user for a magnet/URL and push it to the chosen service."""
    xbmc.log(f'COSMOS [CLOUD] cloud_add  svc={svc!r}', xbmc.LOGDEBUG)
    services = debrid.get_cloud_services()
    if not services:
        xbmcgui.Dialog().notification(
            'Cloud', 'No debrid services authorized',
            xbmcgui.NOTIFICATION_WARNING, 4000)
        return

    # 1) Choose service if not pre-selected
    if svc not in SERVICES:
        names = [SERVICES[c]['name'] for _n, _o, c in services]
        codes = [c for _n, _o, c in services]
        idx = xbmcgui.Dialog().select('Add to which cloud?', names)
        if idx < 0:
            return
        svc = codes[idx]

    obj = next((o for _n, o, c in services if c == svc), None)
    if obj is None:
        xbmcgui.Dialog().notification('Cloud', f'{svc.upper()} not linked',
                                      xbmcgui.NOTIFICATION_ERROR)
        return

    # 2) Get magnet / URL from clipboard or keyboard
    raw = xbmcgui.Dialog().input(
        'Paste magnet link or direct URL', type=xbmcgui.INPUT_ALPHANUM
    )
    raw = (raw or '').strip()
    if not raw:
        return

    is_magnet = raw.lower().startswith('magnet:')
    busy = xbmcgui.DialogProgressBG()
    busy.create('Cloud', f'Adding to {SERVICES[svc]["name"]} …')

    result = None
    try:
        if svc == 'oc':
            xbmc.log(f'COSMOS [CLOUD] cloud_add  queueing Offcloud request', xbmc.LOGDEBUG)
            result = debrid.oc_add_cloud_item(raw)
        elif svc == 'pm':
            result = obj.create_transfer(raw)
        elif svc == 'ls':
            # LinkSnappy has no cloud queue; resolve the supplied host link
            # immediately through its supported link-generation endpoint.
            xbmc.log(f'COSMOS [CLOUD] cloud_add  resolving via LinkSnappy  url={raw[:80]!r}', xbmc.LOGDEBUG)
            result = obj.unrestrict_link(raw)
        elif is_magnet:
            xbmc.log(f'COSMOS [CLOUD] cloud_add  add_magnet  svc={svc!r}', xbmc.LOGDEBUG)
            # allow_cloud=True: user explicitly chose to queue this torrent in
            # the Cloud menu, so blocking on the poll loop is intentional.
            result = obj.add_magnet(raw, allow_cloud=True)
        else:
            xbmc.log(f'COSMOS [CLOUD] cloud_add  unrestrict_link  svc={svc!r}  url={raw[:80]!r}', xbmc.LOGDEBUG)
            result = obj.unrestrict_link(raw)
    except Exception as e:
        xbmc.log(f'COSMOS [CLOUD] cloud_add  EXCEPTION svc={svc!r}: {e}', xbmc.LOGERROR)
    finally:
        try: busy.close()
        except Exception: pass

    xbmc.log(f'COSMOS [CLOUD] cloud_add  result={bool(result)}  svc={svc!r}', xbmc.LOGDEBUG)
    if svc == 'ls':
        if result:
            xbmcgui.Dialog().notification(
                'LinkSnappy', 'Link resolved — starting playback',
                xbmcgui.NOTIFICATION_INFO, 2500,
            )
            xbmc.Player().play(result)
        else:
            xbmcgui.Dialog().notification(
                'LinkSnappy', 'Could not resolve the supplied link',
                xbmcgui.NOTIFICATION_ERROR, 3500,
            )
        return

    if result:
        xbmcgui.Dialog().notification(
            'Cloud', f'Added to {SERVICES[svc]["name"]}',
            xbmcgui.NOTIFICATION_INFO, 4000)
        xbmc.executebuiltin(
            f'Container.Update({_build_url(action="cloud_browse", svc=svc)})'
        )
    else:
        xbmcgui.Dialog().notification(
            'Cloud', 'Failed to add (see kodi.log)',
            xbmcgui.NOTIFICATION_ERROR, 4000)
