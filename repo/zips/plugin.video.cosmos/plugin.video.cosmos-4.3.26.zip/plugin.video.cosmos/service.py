"""Run Cosmos background feed scans, events and radio metadata refreshes."""
import time
import threading

import xbmc
import xbmcgui
import xbmcaddon

from resources.lib import tunein
from resources.lib import parser
from resources.lib import newly_added
from resources.lib import punchplay
from resources.lib.filehost_credentials import sync_credentials

DEFAULT_FEED = 'https://team-enigma.xyz/extras/home.xml'


class CosmosMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        sync_credentials()


def _update(player, metadata):
    if not metadata or not hasattr(player, 'updateInfoTag'):
        return
    station = metadata.get('name') or 'TuneIn Radio'
    title = station + (' — ' + metadata['programme'] if metadata.get('programme') else '')
    item = xbmcgui.ListItem(label=title)
    item.setInfo('music', {
        'mediatype': 'song',
        'title': title,
        'artist': 'TuneIn Radio',
        'album': station,
        'genre': metadata.get('genre') or '',
        'comment': tunein._details_text(metadata, {
            'media_type': metadata.get('codec'), 'bitrate': metadata.get('bitrate')})})
    image = tunein._https_art(metadata.get('image'))
    if image:
        item.setArt({'thumb': image, 'icon': image})
    window = xbmcgui.Window(10000)
    window.setProperty('Cosmos.TuneIn.ActiveId', str(metadata.get('media_id') or ''))
    window.setProperty('Cosmos.TuneIn.ActiveName', station)
    player.updateInfoTag(item)


def main():
    monitor = CosmosMonitor()
    sync_credentials()
    player = xbmc.Player()
    punchplay_stop = threading.Event()
    punchplay_events = threading.Thread(
        target=punchplay.run_event_listener,
        args=(punchplay_stop,),
        name='cosmos-punchplay-events',
        daemon=True,
    )
    punchplay_events.start()
    active_file = ''
    addon = xbmcaddon.Addon('plugin.video.cosmos')
    last_feed_refresh = 0
    feed_worker = None
    newly_added_worker = None
    last_scan_attempt = 0
    metadata_worker = None
    last_metadata_attempt = 0

    def scan_new_arrivals(feed):
        newly_added.scan_feeds(feed)
        newly_added.show_notification(addon)

    try:
        while not monitor.abortRequested():
            try:
                if (time.time() - last_metadata_attempt >= 300
                        and (metadata_worker is None or not metadata_worker.is_alive())):
                    last_metadata_attempt = time.time()
                    metadata_worker = threading.Thread(
                        target=newly_added.prepare_metadata,
                        name='cosmos-newly-added-metadata', daemon=True)
                    metadata_worker.start()
                if (time.time() - last_scan_attempt >= 60
                        and (newly_added_worker is None or not newly_added_worker.is_alive())
                        and newly_added.should_scan()):
                    last_scan_attempt = time.time()
                    feed = (addon.getSetting('base_url') or '').strip() or DEFAULT_FEED
                    newly_added_worker = threading.Thread(
                        target=scan_new_arrivals, args=(feed,),
                        name='cosmos-newly-added', daemon=True)
                    newly_added_worker.start()
                if addon.getSetting('background_feed_refresh') != 'false':
                    try:
                        interval = max(5, int(addon.getSetting('background_feed_refresh_interval') or 30)) * 60
                    except (ValueError, TypeError, OverflowError):
                        interval = 1800
                    if (time.time() - last_feed_refresh >= interval
                            and (feed_worker is None or not feed_worker.is_alive())):
                        feed = (addon.getSetting('base_url') or '').strip() or DEFAULT_FEED
                        try:
                            feed_worker = threading.Thread(
                                target=parser.refresh_cached_feed, args=(feed,),
                                name='cosmos-menu-cache', daemon=True)
                            feed_worker.start()
                        except Exception as exc:
                            xbmc.log('COSMOS feed refresh: %s' % str(exc)[:160], xbmc.LOGWARNING)
                        last_feed_refresh = time.time()
                playing = player.isPlayingAudio()
                current = player.getPlayingFile() if playing else ''
                metadata = tunein.refresh_active_metadata() if playing else {}
                expected = metadata.get('stream_url', '')
                recent = metadata and int(metadata.get('started') or 0) + 30 >= time.time()
                if metadata and (current == expected or current == active_file or recent):
                    _update(player, metadata)
                    active_file = current
                elif not playing:
                    active_file = ''
                    window = xbmcgui.Window(10000)
                    window.clearProperty('Cosmos.TuneIn.ActiveId')
                    window.clearProperty('Cosmos.TuneIn.ActiveName')
            except Exception as exc:
                xbmc.log('COSMOS TuneIn metadata service: %s' % str(exc)[:160], xbmc.LOGWARNING)
            if monitor.waitForAbort(30):
                break
    finally:
        punchplay_stop.set()
        punchplay_events.join(timeout=2)


if __name__ == '__main__':
    main()
