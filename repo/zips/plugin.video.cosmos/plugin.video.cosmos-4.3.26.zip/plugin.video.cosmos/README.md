# C.O.S.M.O.S - Cinema On-demand Streaming Multimedia Operating System

**Version:** 4.1.89  
**Created by:** Zeus768  
**For:** Cosmos  

---

## About

This addon and code was created by **Zeus768** for Cosmos.

C.O.S.M.O.S is a playlist-driven Kodi video addon that reads its menu and content from a remote base URL. It resolves file-host links via ResolveURL or Debrid and auto-plays torrent sources via Torrentio and The Pirate Bay for Search4k / Search1080 / Search720 tokens.

---

## Features

- **Debrid Services Support**: Real-Debrid, AllDebrid, Premiumize, TorBox, LinkSnappy, Offcloud
- **Trakt Integration**: Watchlist, Collection, History, Custom Lists, Scrobbling
- **Simkl Integration**: Authentication, Watchlist, History, Manual watched status, Playback Scrobbling
- **TMDB Metadata**: Rich movie and TV show information
- **Torrent Scrapers**: Automatic torrent search and playback
- **TorrentClaw**: Release Hub browsing for recent/popular titles, movie and TV search, and torrent selection through Debrid. Enter a free TorrentClaw API key under Settings > TorrentClaw to enable magnet links; browsing does not require a key. Shows open TMDB season and episode menus with titles and artwork, followed by the separate TorrentClaw Source Picker. The API base URL is fixed at https://torrentclaw.to.
- **Vidcore SRStop / SaveFiles**: TV episode source. Configure the SaveFiles API key under Settings > Playback, then choose SaveFiles (HLS) to test available HLS streams and play them through InputStream Adaptive, falling back to a verified MP4 when HLS is unavailable. Shows match by IMDb/TVDB IDs or unique exact title/year. Requires SaveFiles direct-link access; movies are not covered.
- **Vidcore LuluStream**: Separate TV episode source that detects LuluStream links on the matching SRStop episode page. The dedicated Cosmos resolver decodes the player script without executing it, checks the media response, and passes HLS streams and required headers to InputStream Adaptive. Playback requires no API key or ResolveURL; movies are not covered.
- **Vidcore Streamtape**: Separate TV episode source that decodes SRStop links, including URLs with filenames, and reads the Streamtape player to resolve its media URL. Direct MP4 streams use Kodi's video player with the required headers; HLS/DASH results use InputStream Adaptive. Movies are not covered.
- **Vidcore Byse**: Available inside the SRStop host picker for TV episodes. Detects plain and obfuscated Byse links, resolves the native player API and AES-GCM playback data, and checks the media before playback. HLS uses InputStream Adaptive with the required player headers; MP4 uses Kodi's video player. No API key or ResolveURL is required.
- **Vidcore HDHub**: Movie and TV source using the public HDHub catalogue exposed by CineWave. Select HDHub, then choose a stream by its quality and language details. Non-video links are filtered out, and the selected link is checked before playback. MP4/MKV use Kodi's video player; HLS/DASH use InputStream Adaptive. Availability depends on the upstream catalogue and signed links.
- **Vidcore 2Embed**: Movie source using CineWave's 2EM player chain. Decodes packed player sources and detects HLS content even when the playlist uses a `.txt` suffix. Requires InputStream Adaptive. Extraction checked offline against a supplied HAR; live Kodi playback remains unverified. TV episodes are not yet supported.
- **Football Replays**: Full-match replays from footballorgin.com
- **Downloads**: Download and manage content locally
- **Cloud Browser**: Browse and play from debrid cloud storage
- **Resume Points**: Automatic playback resumption
- **Sync**: Cross-device sync via gofile.io

---

## Credits

**Author:** Zeus768  
**GitHub:** https://github.com/zeus768  
**Addon:** C.O.S.M.O.S (Cosmos)  

This addon uses the proven Debrid flow from Trakt Player (zeus768).

---

## Installation

1. Download the latest release
2. Extract to your Kodi addons directory
3. Restart Kodi
4. Configure in Settings → Debrid, Settings → Trakt, and Settings → Simkl

---

## License

GPL-2.0-only

---

## Disclaimer

### Music

The Music menu includes Radio UK and an embedded TuneIn Radio browser. TuneIn
supports station search, category/location/language browsing and native live
audio playback without a separate Kodi addon. Some stations may be unavailable
because TuneIn supplies an incompatible stream or a web page instead of audio.

TuneIn integration references the GPL-licensed Kodi TuneIn project by Brian
Hornsby and contributors; its licence notice is bundled at
`resources/licenses/tunein-GPL-3.0.txt`.

This addon does not host any content.

---

**Created with ❤️ by Zeus768 for the Cosmos community**
