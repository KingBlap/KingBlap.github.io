import xbmc
import time
from resources.lib.playback_monitor import init_monitor

try:
    from jetextractors.tools import refresh_stale_stores
    _HAS_REFRESH = True
except Exception:
    _HAS_REFRESH = False

# Start the persistent playback monitor from the service context.
# This avoids the problem where the monitor dies when the GUI window closes.
init_monitor()

monitor = xbmc.Monitor()

# Background store refresh interval (5 minutes).
# Stores are refreshed at their own REFRESH_INTERVAL via is_stale() checks.
_REFRESH_CHECK_INTERVAL = 300
_last_refresh_check = 0.0

while not monitor.abortRequested():
    try:
        now = time.time()
        if now - _last_refresh_check >= _REFRESH_CHECK_INTERVAL:
            _last_refresh_check = now
            if _HAS_REFRESH:
                refresh_stale_stores()
    except Exception:
        pass

    if monitor.waitForAbort(1):
        break
