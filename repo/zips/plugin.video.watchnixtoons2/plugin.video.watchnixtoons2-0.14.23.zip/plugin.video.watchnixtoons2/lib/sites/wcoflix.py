
SITE_SETTINGS = {
    'catalog': {
        'regex': r'''<li(?:\sdata\-id=\"[0-9]+\")?>\s*<a href="([^"]+).*?>([^<]+)''',
        'start': '"ddmcc"',
        'start_alt': False,
        'end': '<script>',
    },
    'episode': {
        'regex': r'''<a href=\"(?P<link>[^\"]+).*?(data-lang=\"(?P<type>[^\"]+)\")?>(?:<span>)?(?P<name>[^<]+)''',
        'start': 'name="pid"',
        'end': '"sidebar-all"',
    },
    'series_search': {
        'regex': r'''<a\s*href=\"(?P<link>[^\"]+).*?>([^<]+)\s*<img alt=\"(?P<name>[^\"]+)\"\s*src=\"(?P<img>[^\"]+)''',
        'start': '"aramamotoru',
        'end': '<script>',
    },
    'movie_search': {
        'regex': r'''<a href="(?P<link>[^"]+).*?>(?P<name>[^<]+)''',
        'start': '"ddmcc"',
        'end': '/ul></ul',
    },
    'episode_search': {
        'regex': r'''<a href=\"(?P<link>[^\"]+)[^>]*>(?P<name>[^<]+)</a''',
        'start': '"submit"',
        'end': '"cizgiyazisi',
    },
    'genre': {
        'regex': '''<a.*?"([^"]+).*?>(.*?)</''',
        'start': r'ddmcc">',
        'end': r'</div></div>',
    },
    'thumbnail': {
        'regex': '',
        'start': 'og:image" content="',
        'end': '',
    },
    'page_meta': {
        'regex': 'href="([^"]+)',
        'start': '"header-tag"',
        'end': '',
    },
    'page_plot': {
        'regex': r'</h3>\s*<p>(.*?)</p>',
        'start': 'Info:',
        'end': '',
    },
    'latest': {
        'url': '/last-50-recent-release',
        'regex': r'''<div class=\"img\">\s+?<a href=\"(?P<link>[^\"]+)\">\s+?<img class=\"hover-img1\" src=\"(?P<img>[^\"]+)\">\s+?</a>\s+?</div>\s+?<div class=\"recent-release-episodes\"><a href=\".*?\" rel=\"bookmark\">(?P<name>.*?)</a''',
        'start': 'fourteen columns',
        'end': '</ul>',
    },
    'latest_movies': {
        'regex': r'href=\"([^\"]+)\"\s*[^>]*>\s*<span>([^<]+)',
        'start': 'id="episodeList"',
        'end': 'class="result-meta"',
    },
    'popular': {
        'regex': '''<a href="([^"]+).*?>([^<]+)''',
        'start': '"sidebar-titles"',
        'end': '</div>',
    },
    'parent': {
        'regex': r'<h2><a href=\"([^\"]+)\"(?:[^\>]+)?><span(?:[^\>]+)>([^/<]+)<',
        'start': '"header-tag"',
        'end': '',
    },
    'chapter': {
        'regex': r'onclick=\"myFunction.*<script',
    }
}

DECODE_SOURCE_REQUIRED = True

def premium_workaround_check( html, urls ):

    """ checks if there is a work around for current domain """

    return False
