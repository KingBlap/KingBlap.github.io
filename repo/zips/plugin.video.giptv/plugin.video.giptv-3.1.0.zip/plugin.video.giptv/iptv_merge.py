# -*- coding: utf-8 -*-
"""Discovery adapter used by IPTV Merge add-ons."""


def playlist():
    from resources.lib.iptv_integration import build_m3u

    return build_m3u()


def epg():
    from resources.lib.iptv_integration import get_xmltv_text

    return get_xmltv_text()
