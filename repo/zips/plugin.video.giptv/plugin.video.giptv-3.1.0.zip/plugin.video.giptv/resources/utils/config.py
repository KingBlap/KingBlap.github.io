# -*- coding: utf-8 -*-
"""
config.py

Central configuration module for GIPTV.

- Non-credential flags live here
- Credentials are ALWAYS read from Kodi settings.xml
- This module syncs credentials into xtream_api.STATE
"""

import xbmc
import xbmcaddon

import resources.utils.settings as settings
import resources.utils.giptv as giptv
from resources.utils.xtream import STATE
from urllib.parse import urlparse, urlunparse

ADDON = xbmcaddon.Addon()


def setup_api_config():
    """
    Load credentials from Kodi settings.xml and populate STATE.
    """
    try:
        server, username, password = settings.get_api_credentials(ADDON)

        server = (server or "").strip()
        username = (username or "").strip()
        password = (password or "").strip()

        if not server or not username or not password:
            STATE.server = ""
            STATE.username = ""
            STATE.password = ""
            return False

        if not server.startswith(("http://", "https://")):
            giptv.notification(
                ADDON.getAddonInfo("name"),
                "Please configure your IPTV credentials in the add-on settings.",
                icon="ERROR",
            )
            xbmc.Monitor().waitForAbort(5)
            giptv.open_settings()
            return False

        if "@" in server:
            giptv.log(
                msg="WARNING: credentials detected in server URL — sanitizing",
                level=xbmc.LOGWARNING,
            )

        parsed = urlparse(server)

        netloc = parsed.hostname or ""
        if parsed.port:
            netloc += f":{parsed.port}"

        clean_server = urlunparse((parsed.scheme, netloc, "", "", "", ""))
        clean_server = clean_server.rstrip("/")

        changed = (
            str(getattr(STATE, "server", "") or "").rstrip("/") != clean_server
            or str(getattr(STATE, "username", "") or "") != username
            or str(getattr(STATE, "password", "") or "") != password
        )

        STATE.server = clean_server
        STATE.username = username
        STATE.password = password

        if changed:
            giptv.log(
                f"[CONFIG] Xtream credentials refreshed: {STATE.server}",
                xbmc.LOGINFO,
            )
        else:
            giptv.log(
                f"[CONFIG] Xtream credentials loaded: {STATE.server}",
                xbmc.LOGINFO,
            )

        return True

    except Exception as e:
        STATE.server = ""
        STATE.username = ""
        STATE.password = ""

        giptv.notification(
            ADDON.getAddonInfo("name"),
            f"Configuration Setup Error: {e}",
            icon="ERROR",
        )
        giptv.open_tools_window()
        return False


def ensure_api_ready():
    """
    Always sync STATE from current Kodi settings.
    Safe to call from any module at any time.
    """
    return setup_api_config()
