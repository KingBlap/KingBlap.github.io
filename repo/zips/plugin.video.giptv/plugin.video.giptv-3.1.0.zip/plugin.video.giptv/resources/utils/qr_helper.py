# -*- coding: utf-8 -*-
import os
import sys

import xbmc
import xbmcaddon
import xbmcvfs

from resources.utils import giptv
from resources.lib.windows.trakt import TraktQRAuthDialog

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


# ============================================================
#  PATH HELPERS
# ============================================================


def _translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return path


def _addon_path():
    return _translate(ADDON.getAddonInfo("path"))


def _addon_profile_path():
    path = _translate("special://profile/addon_data/{}/".format(ADDON_ID))

    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)

    return path


def _ensure_vendor_paths():
    """
    Allows vendored modules like:

        resources/lib/segno/

    to be imported by Kodi.
    """
    addon_path = _addon_path()

    paths = [
        os.path.join(addon_path, "resources", "lib"),
        os.path.join(addon_path, "resources", "lib", "python"),
        os.path.join(addon_path, "lib"),
    ]

    for p in paths:
        try:
            if p and p not in sys.path:
                sys.path.insert(0, p)
        except Exception:
            pass


_ensure_vendor_paths()


# ============================================================
#  QR GENERATION
# ============================================================


def make_tinyurl(url, timeout=6):
    url = str(url or "").strip()
    if not url:
        return ""

    try:
        import requests

        response = requests.get(
            "https://tinyurl.com/api-create.php",
            params={"url": url},
            timeout=timeout,
        )

        if response.status_code == 200:
            short_url = str(response.text or "").strip()
            if short_url.startswith("http"):
                return short_url

    except Exception as e:
        giptv.log("[QR] TinyURL failed: {}".format(e), xbmc.LOGWARNING)

    return url


def make_qrcode(url, filename="trakt_qr.png", shorten=False):
    url = str(url or "").strip()
    if not url:
        return ""

    if shorten:
        url = make_tinyurl(url)

    try:
        import segno
    except Exception as e:
        giptv.log(
            "[QR] segno is not installed/available: {}".format(e),
            xbmc.LOGERROR,
        )
        return ""

    try:
        profile = _addon_profile_path()
        image_path = os.path.join(profile, filename)

        try:
            if xbmcvfs.exists(image_path):
                xbmcvfs.delete(image_path)
        except Exception:
            pass

        qrcode = segno.make(url, micro=False)
        qrcode.save(image_path, scale=12, border=3)

        giptv.log("[QR] QR generated: {}".format(image_path), xbmc.LOGINFO)
        return image_path

    except Exception as e:
        giptv.log("[QR] failed to generate QR: {}".format(e), xbmc.LOGERROR)
        return ""


def copy_to_clipboard(text):
    text = str(text or "").strip()
    if not text:
        return False

    try:
        if sys.platform == "win32":
            from subprocess import check_call

            cmd = "echo {}|clip".format(text.replace("&", "^&"))
            check_call(cmd, shell=True)
            return True

        if sys.platform == "darwin":
            from subprocess import check_call

            cmd = "printf %s '{}' | pbcopy".format(text.replace("'", "'\\''"))
            check_call(cmd, shell=True)
            return True

        if sys.platform.startswith("linux"):
            from subprocess import Popen, PIPE

            p = Popen(["xsel", "-pi"], stdin=PIPE)
            p.communicate(input=text.encode("utf-8"))
            return True

    except Exception as e:
        giptv.log("[QR] clipboard failed: {}".format(e), xbmc.LOGWARNING)

    return False


def show_trakt_qr_auth_dialog(
    verification_url,
    user_code,
    auth_url,
    token_url,
    token_payload,
    token_headers,
    interval=5,
    expires_in=600,
):

    qr_path = make_qrcode(auth_url or verification_url, filename="trakt_auth_qr.png")

    xml_file = "giptv_trakt_qr_auth.xml"
    addon_path = ADDON.getAddonInfo("path")
    skin_path = "Default"
    resolution = "1080i"

    dialog = TraktQRAuthDialog(
        xml_file,
        addon_path,
        skin_path,
        resolution,
        verification_url=verification_url,
        user_code=user_code,
        auth_url=auth_url,
        qr_path=qr_path,
        token_url=token_url,
        token_payload=token_payload,
        token_headers=token_headers,
        interval=interval,
        expires_in=expires_in,
    )

    try:
        dialog.doModal()
        return dialog.result
    finally:
        try:
            dialog.close()
        except Exception:
            pass
        del dialog
