import json
import os

import xbmcvfs

from resources.utils import giptv

BUFFER_SIZE_MAP = {
    "0": 64,
    "1": 128,
    "2": 256,
    "3": 512,
}

BUFFER_LABEL_MAP = {
    "0": "small",
    "1": "medium",
    "2": "large",
    "3": "very large",
}

HIDDEN_GROUPS_PATH = xbmcvfs.translatePath(
    "special://profile/addon_data/plugin.video.giptv/hidden_groups.json"
)
_HIDDEN_GROUPS_DATA_CACHE = None


def _safe_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return default


def _get_selected_account(ADDON) -> str:
    value = str(ADDON.getSetting("account")).strip()
    return value if value in ("0", "1", "2") else "0"


def _get_account_suffix(ADDON, account_override=None) -> str:
    selected = (
        str(account_override).strip()
        if account_override is not None
        else _get_selected_account(ADDON)
    )

    if selected == "1":
        return "1"
    if selected == "2":
        return "2"
    return ""


def _get_account_setting(
    ADDON, base_key: str, default: str = "", account_override=None
) -> str:
    suffix = _get_account_suffix(ADDON, account_override)
    value = ADDON.getSetting(f"{base_key}{suffix}")
    if isinstance(value, str):
        value = value.strip()
    return value if value else default


def _get_enum_enabled(ADDON, setting_id: str) -> bool:
    return str(ADDON.getSetting(setting_id)).strip() == "0"


def get_api_credentials(ADDON):
    server = _get_account_setting(ADDON, "server")
    username = _get_account_setting(ADDON, "username")
    password = _get_account_setting(ADDON, "password")

    if not (server and username and password):
        giptv.notification(
            ADDON.getAddonInfo("name"),
            "Please configure your IPTV credentials in the add-on settings.",
            "INFO",
        )
        return None, None, None

    return server, username, password


def get_cache_on_off(ADDON):
    return _get_enum_enabled(ADDON, "cache")


def get_buffer_size(ADDON):
    value = _get_account_setting(ADDON, "buffer_size", "0")
    return BUFFER_SIZE_MAP.get(value, 64)


def get_buffer_size_label(ADDON):
    value = _get_account_setting(ADDON, "buffer_size", "0")
    return BUFFER_LABEL_MAP.get(value, "small")


def get_epg_offset(ADDON):
    return _safe_int(_get_account_setting(ADDON, "epg_offset", "0"), 0)


def get_catchup_offset(ADDON):
    return _safe_int(_get_account_setting(ADDON, "catchup_offset", "0"), 0)


def get_catchup_days(ADDON):
    """Number of past EPG days retained and exposed for catch-up."""
    return max(1, min(30, _safe_int(ADDON.getSetting("catchup_days") or "7", 7)))


def condense_live_versions(ADDON):
    return str(ADDON.getSetting("condense_live_versions") or "false").lower() == "true"


def _hidden_groups_key(ADDON):
    server = _get_account_setting(ADDON, "server", "").rstrip("/")
    username = _get_account_setting(ADDON, "username", "")
    return "{}|{}".format(server, username)


def _read_hidden_groups_data(ADDON):
    global _HIDDEN_GROUPS_DATA_CACHE

    if _HIDDEN_GROUPS_DATA_CACHE is not None:
        return _HIDDEN_GROUPS_DATA_CACHE

    if xbmcvfs.exists(HIDDEN_GROUPS_PATH):
        try:
            handle = xbmcvfs.File(HIDDEN_GROUPS_PATH, "r")
            try:
                data = json.loads(handle.read() or "{}")
            finally:
                handle.close()
            if isinstance(data, dict):
                _HIDDEN_GROUPS_DATA_CACHE = data
                return data
        except Exception:
            pass

    # Migrate values written by the initial settings-backed implementation.
    try:
        data = json.loads(ADDON.getSetting("hidden_channel_groups") or "{}")
        data = data if isinstance(data, dict) else {}
        _HIDDEN_GROUPS_DATA_CACHE = data
        return data
    except Exception:
        _HIDDEN_GROUPS_DATA_CACHE = {}
        return {}


def _write_hidden_groups_data(ADDON, data):
    global _HIDDEN_GROUPS_DATA_CACHE

    _HIDDEN_GROUPS_DATA_CACHE = data
    text = json.dumps(data, separators=(",", ":"))
    try:
        parent = os.path.dirname(HIDDEN_GROUPS_PATH)
        if parent and not xbmcvfs.exists(parent):
            xbmcvfs.mkdirs(parent)
        handle = xbmcvfs.File(HIDDEN_GROUPS_PATH, "w")
        try:
            handle.write(text)
        finally:
            handle.close()
    except Exception:
        pass
    # Keep the old value populated for migration/backward compatibility.
    try:
        ADDON.setSetting("hidden_channel_groups", text)
    except Exception:
        pass


def get_hidden_groups(ADDON, stream_type=None):
    data = _read_hidden_groups_data(ADDON)
    account_data = data.get(_hidden_groups_key(ADDON), {})
    if stream_type is None:
        return account_data
    return set(str(value) for value in account_data.get(str(stream_type), []))


def set_hidden_groups(ADDON, stream_type, category_ids):
    data = _read_hidden_groups_data(ADDON)
    account_key = _hidden_groups_key(ADDON)
    account_data = data.setdefault(account_key, {})
    account_data[str(stream_type)] = sorted(set(str(value) for value in category_ids))
    _write_hidden_groups_data(ADDON, data)


def hide_group(ADDON, stream_type, category_id):
    hidden = get_hidden_groups(ADDON, stream_type)
    hidden.add(str(category_id))
    set_hidden_groups(ADDON, stream_type, hidden)


def get_epg_url(ADDON):
    return _get_account_setting(ADDON, "epg_url", "")


def get_stream_format(ADDON):
    value = _get_account_setting(ADDON, "stream_format", "0")
    return {
        "0": "auto",
        "1": "ts",
        "2": "m3u8",
    }.get(value, "auto")
