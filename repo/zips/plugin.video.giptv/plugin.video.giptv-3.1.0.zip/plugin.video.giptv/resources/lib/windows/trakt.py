# -*- coding: utf-8 -*-
import threading
import time

import requests
import xbmc
import xbmcgui

from resources.lib.windows.base_window import BaseDialog
from resources.utils import giptv


class TraktQRAuthDialog(BaseDialog):
    LIST_ID = 1000
    PROGRESS_ID = 3000

    ACTION_OPEN_BROWSER = "open_browser"
    ACTION_COPY_CODE = "copy_code"
    ACTION_CANCEL = "cancel"

    def __init__(self, *args, **kwargs):
        super(TraktQRAuthDialog, self).__init__(*args, **kwargs)

        self.verification_url = kwargs.get("verification_url", "")
        self.user_code = kwargs.get("user_code", "")
        self.auth_url = kwargs.get("auth_url", "")
        self.qr_path = kwargs.get("qr_path", "")

        self.token_url = kwargs.get("token_url", "")
        self.token_payload = kwargs.get("token_payload") or {}
        self.token_headers = kwargs.get("token_headers") or {}
        self.interval = int(kwargs.get("interval", 5) or 5)
        self.expires_in = int(kwargs.get("expires_in", 600) or 600)

        self.result = None
        self.cancelled = False

        self._poll_thread = None
        self._poll_stop = threading.Event()
        self._started_at = 0

    def onInit(self):
        self._started_at = time.time()

        self.set_prop("menu_title", "Trakt Authorization")
        self.set_prop("qr_verification_url", self.verification_url or "")
        self.set_prop("qr_user_code", self.user_code or "")
        self.set_prop("qr_auth_url", self.auth_url or self.verification_url or "")
        self.set_prop("qr_image", self.qr_path or "")

        self._set_status(
            text="",
            remaining=self.expires_in,
            percent=0,
        )

        self._setup_buttons()
        self._start_polling()

    def _setup_buttons(self):
        try:
            list_control = self.getControl(self.LIST_ID)
        except Exception as e:
            giptv.log(
                "[TRAKT QR] missing button list control {}: {}".format(
                    self.LIST_ID,
                    e,
                ),
                xbmc.LOGERROR,
            )
            self._finish(None)
            return

        try:
            list_control.reset()
        except Exception:
            pass

        items = [
            {
                "label": "Open browser",
                "key": self.ACTION_OPEN_BROWSER,
            },
            {
                "label": "Copy code",
                "key": self.ACTION_COPY_CODE,
            },
            {
                "label": "Cancel",
                "key": self.ACTION_CANCEL,
            },
        ]

        for item in items:
            li = xbmcgui.ListItem(label=item.get("label", ""))
            li.setProperty("action_key", item.get("key", ""))

            try:
                list_control.addItem(li)
            except Exception:
                pass

        try:
            list_control.selectItem(0)
        except Exception:
            pass

        try:
            self.setFocus(list_control)
        except Exception:
            pass

    def _set_progress(self, percent):
        try:
            percent = max(0, min(100, int(percent)))
        except Exception:
            percent = 0

        try:
            progress_control = self.getControl(self.PROGRESS_ID)
            progress_control.setPercent(percent)
        except Exception:
            pass

    def _set_status(self, text="", remaining=None, percent=None):
        try:
            self.set_prop("qr_status", text or "")
        except Exception:
            pass

        if remaining is not None:
            try:
                self.set_prop("qr_remaining", "{}s remaining".format(int(remaining)))
            except Exception:
                pass

        if percent is not None:
            self._set_progress(percent)

            try:
                self.set_prop("qr_progress", str(int(percent)))
            except Exception:
                pass

    def _start_polling(self):
        if self._poll_thread and self._poll_thread.is_alive():
            return

        self._poll_stop.clear()

        self._poll_thread = threading.Thread(
            target=self._poll_loop,
            name="giptv_trakt_qr_poll",
            daemon=True,
        )
        self._poll_thread.start()

    def _poll_loop(self):
        giptv.log("[TRAKT QR] polling started", xbmc.LOGINFO)

        interval = max(1, int(self.interval or 5))
        expires_in = max(30, int(self.expires_in or 600))
        start = time.time()

        while not self._poll_stop.is_set():
            elapsed = int(time.time() - start)

            if elapsed >= expires_in:
                self._set_status(
                    text="Authorization expired.",
                    remaining=0,
                    percent=100,
                )
                giptv.log("[TRAKT QR] authorization expired", xbmc.LOGWARNING)
                xbmc.sleep(800)
                self._finish(None)
                return

            remaining = max(0, expires_in - elapsed)

            # Countdown bar:
            # 100% at start, 0% when expired.
            percent = int((remaining / float(expires_in)) * 100)

            self._set_status(
                "",
                remaining,
                percent,
            )
            try:
                resp = requests.post(
                    self.token_url,
                    json=self.token_payload,
                    headers=self.token_headers,
                    timeout=20,
                )

                if resp.status_code == 200:
                    data = resp.json()

                    if isinstance(data, dict) and data.get("access_token"):
                        self.result = data

                        self._set_status(
                            text="Authorization successful.",
                            remaining=remaining,
                            percent=100,
                        )

                        giptv.log("[TRAKT QR] authorization success", xbmc.LOGINFO)

                        xbmc.sleep(600)
                        self._finish(data)
                        return

                elif resp.status_code == 400:
                    # authorization_pending
                    pass

                elif resp.status_code == 429:
                    # slow_down
                    interval += 5
                    self._set_status(
                        text="Trakt asked us to slow down.",
                        remaining=remaining,
                        percent=percent,
                    )

                elif resp.status_code == 418:
                    self._set_status(
                        text="Authorization denied.",
                        remaining=remaining,
                        percent=percent,
                    )
                    giptv.log("[TRAKT QR] authorization denied", xbmc.LOGWARNING)
                    xbmc.sleep(1000)
                    self._finish(None)
                    return

                elif resp.status_code == 410:
                    self._set_status(
                        text="Authorization expired.",
                        remaining=0,
                        percent=100,
                    )
                    giptv.log("[TRAKT QR] authorization expired", xbmc.LOGWARNING)
                    xbmc.sleep(1000)
                    self._finish(None)
                    return

                elif resp.status_code in (404, 409):
                    self._set_status(
                        text="Authorization unavailable.",
                        remaining=remaining,
                        percent=percent,
                    )
                    giptv.log(
                        "[TRAKT QR] authorization failed status={}".format(
                            resp.status_code
                        ),
                        xbmc.LOGWARNING,
                    )
                    xbmc.sleep(1000)
                    self._finish(None)
                    return

            except Exception as e:
                giptv.log(
                    "[TRAKT QR] polling request failed: {}".format(e),
                    xbmc.LOGWARNING,
                )

            slept = 0
            while slept < interval and not self._poll_stop.is_set():
                xbmc.sleep(1000)
                slept += 1

        giptv.log("[TRAKT QR] polling stopped", xbmc.LOGINFO)

    def onClick(self, controlId):
        if controlId != self.LIST_ID:
            return

        try:
            list_control = self.getControl(self.LIST_ID)
            item = list_control.getSelectedItem()
            action_key = item.getProperty("action_key") if item else ""
        except Exception:
            return

        if action_key == self.ACTION_OPEN_BROWSER:
            self._open_browser()
            return

        if action_key == self.ACTION_COPY_CODE:
            self._copy_code()
            return

        if action_key == self.ACTION_CANCEL:
            self.cancelled = True
            self._poll_stop.set()
            self._finish(None)
            return

    def _open_browser(self):
        try:
            import webbrowser

            webbrowser.open(self.auth_url or self.verification_url)

            self._set_status(
                text="Browser opened.",
                remaining=self._remaining_seconds(),
                percent=self._elapsed_percent(),
            )

        except Exception as e:
            giptv.log(
                "[TRAKT QR] browser open failed: {}".format(e),
                xbmc.LOGWARNING,
            )

            self._set_status(
                text="Could not open browser.",
                remaining=self._remaining_seconds(),
                percent=self._elapsed_percent(),
            )

    def _copy_code(self):
        try:
            from resources.utils import qr_helper

            copied = qr_helper.copy_to_clipboard(self.user_code)

            if copied:
                self._set_status(
                    text="Activation code copied.",
                    remaining=self._remaining_seconds(),
                    percent=self._elapsed_percent(),
                )
            else:
                self._set_status(
                    text="Clipboard unavailable.",
                    remaining=self._remaining_seconds(),
                    percent=self._elapsed_percent(),
                )

        except Exception as e:
            giptv.log(
                "[TRAKT QR] copy code failed: {}".format(e),
                xbmc.LOGWARNING,
            )

            self._set_status(
                text="Clipboard unavailable.",
                remaining=self._remaining_seconds(),
                percent=self._elapsed_percent(),
            )

    def _remaining_seconds(self):
        try:
            elapsed = int(time.time() - float(self._started_at or time.time()))
            return max(0, int(self.expires_in or 600) - elapsed)
        except Exception:
            return 0

    def _elapsed_percent(self):
        try:
            expires = max(1, int(self.expires_in or 600))
            elapsed = int(time.time() - float(self._started_at or time.time()))
            return max(0, min(100, int((elapsed / float(expires)) * 100)))
        except Exception:
            return 0

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = action

        if action_id in self.closing_actions:
            self.cancelled = True
            self._poll_stop.set()
            self._finish(None)
            return

        super(TraktQRAuthDialog, self).onAction(action)

    def close(self):
        try:
            self._poll_stop.set()
        except Exception:
            pass

        super(TraktQRAuthDialog, self).close()
