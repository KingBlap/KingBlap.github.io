# -*- coding: utf-8 -*-
import xbmc
import xbmcgui

from resources.lib.windows.base_window import BaseDialog
from resources.utils import giptv


class SupportMeDialog(BaseDialog):
    LIST_ID = 1000

    ACTION_OPEN_BROWSER = "open_browser"
    ACTION_COPY_LINK = "copy_link"
    ACTION_CLOSE = "close"

    def __init__(self, *args, **kwargs):
        super(SupportMeDialog, self).__init__(*args, **kwargs)

        self.donation_url = kwargs.get("donation_url", "")
        self.qr_path = kwargs.get("qr_path", "")
        self.title = kwargs.get("title", "Support GIPTV")
        self.message = kwargs.get("message", "")
        self.result = None

    def onInit(self):
        self.set_prop("support_title", self.title or "Support GIPTV")
        self.set_prop("support_message", self.message or "")
        self.set_prop("support_url", self.donation_url or "")
        self.set_prop("support_qr_image", self.qr_path or "")

        self._setup_buttons()

    def _setup_buttons(self):
        try:
            list_control = self.getControl(self.LIST_ID)
        except Exception as e:
            giptv.log(
                "[SUPPORT WINDOW] missing list control {}: {}".format(
                    self.LIST_ID,
                    e,
                ),
                xbmc.LOGERROR,
            )
            self._finish(None)
            return

        try:
            list_control.reset()
        except Exception:
            pass

        items = [
            {"label": "Open browser", "key": self.ACTION_OPEN_BROWSER},
            {"label": "Copy link", "key": self.ACTION_COPY_LINK},
            {"label": "Close", "key": self.ACTION_CLOSE},
        ]

        for item in items:
            li = xbmcgui.ListItem(label=item.get("label", ""))
            li.setProperty("action_key", item.get("key", ""))

            try:
                list_control.addItem(li)
            except Exception:
                pass

        try:
            list_control.selectItem(0)
            self.setFocus(list_control)
        except Exception:
            pass

    def onClick(self, controlId):
        if controlId != self.LIST_ID:
            return

        try:
            list_control = self.getControl(self.LIST_ID)
            item = list_control.getSelectedItem()
            action_key = item.getProperty("action_key") if item else ""
        except Exception:
            return

        if action_key == self.ACTION_OPEN_BROWSER:
            self._open_browser()
            return

        if action_key == self.ACTION_COPY_LINK:
            self._copy_link()
            return

        if action_key == self.ACTION_CLOSE:
            self._finish("close")
            return

    def _open_browser(self):
        try:
            import webbrowser

            webbrowser.open(self.donation_url)
            self.set_prop("support_status", "Browser opened.")
        except Exception as e:
            giptv.log(
                "[SUPPORT WINDOW] browser open failed: {}".format(e),
                xbmc.LOGWARNING,
            )
            self.set_prop("support_status", "Could not open browser. Scan the QR code.")

    def _copy_link(self):
        try:
            from resources.utils import qr_helper

            copied = qr_helper.copy_to_clipboard(self.donation_url)

            if copied:
                self.set_prop("support_status", "Donation link copied.")
            else:
                self.set_prop(
                    "support_status", "Clipboard unavailable. Scan the QR code."
                )
        except Exception as e:
            giptv.log(
                "[SUPPORT WINDOW] copy failed: {}".format(e),
                xbmc.LOGWARNING,
            )
            self.set_prop("support_status", "Clipboard unavailable. Scan the QR code.")

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = action

        if action_id in self.closing_actions:
            self._finish(None)
            return

        super(SupportMeDialog, self).onAction(action)
