# -*- coding: utf-8 -*-
import xbmcgui
from resources.lib.windows.base_window import BaseDialog


class GIPTVToolsMenu(BaseDialog):
    LIST_ID = 1000

    def __init__(self, *args, **kwargs):
        super(GIPTVToolsMenu, self).__init__(*args, **kwargs)
        self.items = kwargs.get("items", [])

    def onInit(self):
        self.set_prop("menu_title", "GIPTV Tools")

        try:
            list_control = self.getControl(self.LIST_ID)
        except Exception:
            self._finish(None)
            return

        try:
            list_control.reset()
        except Exception:
            pass

        for item in self.items:
            li = xbmcgui.ListItem(label=item.get("label", ""))
            li.setProperty("action_key", item.get("key", ""))
            try:
                list_control.addItem(li)
            except Exception:
                pass

        if self.items:
            try:
                list_control.selectItem(0)
            except Exception:
                pass
            try:
                self.setFocus(list_control)
            except Exception:
                pass

    def onClick(self, controlId):
        if controlId != self.LIST_ID:
            return

        try:
            list_control = self.getControl(self.LIST_ID)
            item = list_control.getSelectedItem()
        except Exception:
            self._finish(None)
            return

        action_key = item.getProperty("action_key") if item else None
        self._finish(action_key)

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = action

        if action_id in self.closing_actions:
            self._finish(None)
            return

        super(GIPTVToolsMenu, self).onAction(action)
