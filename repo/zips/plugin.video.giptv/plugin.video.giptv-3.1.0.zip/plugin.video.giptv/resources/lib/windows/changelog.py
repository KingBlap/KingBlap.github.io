# -*- coding: utf-8 -*-
import xbmcgui

from resources.lib.windows.base_window import BaseDialog


class GIPTVChangeLogDialog(BaseDialog):
    LIST_ID = 1000

    ACTION_CLOSE = "close"

    def __init__(self, *args, **kwargs):
        super(GIPTVChangeLogDialog, self).__init__(*args, **kwargs)

        self.title = kwargs.get("title", "GIPTV Changelog")
        self.version = kwargs.get("version", "")
        self.subtitle = kwargs.get("subtitle", "")
        self.body = kwargs.get("body", "")
        self.footer = kwargs.get("footer", "Press OK or Back to close.")

    def onInit(self):
        self.set_prop("changelog_title", self.title)
        self.set_prop("changelog_version", self.version)
        self.set_prop("changelog_subtitle", self.subtitle)
        self.set_prop("changelog_body", self.body)
        self.set_prop("changelog_footer", self.footer)

        self._setup_buttons()

    def _setup_buttons(self):
        try:
            list_control = self.getControl(self.LIST_ID)
        except Exception:
            self._finish(None)
            return

        try:
            list_control.reset()
        except Exception:
            pass

        li = xbmcgui.ListItem(label="Close")
        li.setProperty("action_key", self.ACTION_CLOSE)

        try:
            list_control.addItem(li)
            list_control.selectItem(0)
            self.setFocus(list_control)
        except Exception:
            pass

    def onClick(self, controlId):
        if controlId != self.LIST_ID:
            return

        self._finish(self.ACTION_CLOSE)

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = action

        if action_id in self.closing_actions:
            self._finish(None)
            return

        super(GIPTVChangeLogDialog, self).onAction(action)
