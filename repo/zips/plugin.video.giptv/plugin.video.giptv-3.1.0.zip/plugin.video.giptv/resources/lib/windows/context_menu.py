# -*- coding: utf-8 -*-
import xbmcgui
from resources.lib.windows.base_window import BaseDialog


class GIPTVContextMenu(BaseDialog):
    LIST_ID = 1000

    def __init__(self, *args, **kwargs):
        super(GIPTVContextMenu, self).__init__(*args, **kwargs)
        self.title = kwargs.get("title", "Menu")
        self.items = kwargs.get("items", [])

    def onInit(self):
        self.set_prop("menu_title", self.title)

        try:
            list_control = self.getControl(self.LIST_ID)
        except Exception:
            return

        list_control.reset()

        for item in self.items:
            li = xbmcgui.ListItem(label=item.get("label", ""))
            li.setProperty("action_key", item.get("key", ""))
            list_control.addItem(li)

        try:
            if self.items and list_control.size() > 0:
                self.setFocus(list_control)
                list_control.selectItem(0)
        except Exception:
            pass

    def onClick(self, controlId):
        if controlId != self.LIST_ID:
            return

        try:
            list_control = self.getControl(self.LIST_ID)
            item = list_control.getSelectedItem()
        except Exception:
            self._finish(None)
            return

        self._finish(item.getProperty("action_key") if item else None)

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = action

        if action_id in self.closing_actions:
            self._finish(None)
            return

        super(GIPTVContextMenu, self).onAction(action)
