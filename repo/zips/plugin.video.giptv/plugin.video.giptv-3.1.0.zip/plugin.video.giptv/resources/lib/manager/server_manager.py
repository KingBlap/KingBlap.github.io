# resources/utils/server_manager.py
# -*- coding: utf-8 -*-

try:
    from urllib.parse import urlparse

except ImportError:
    import urlparse
import xbmcaddon
import xbmcgui

from resources.utils.xtream import STATE
from resources.utils.config import ensure_api_ready

ADDON = xbmcaddon.Addon()


ACCOUNTS = [
    {"account": "0", "label": "Server", "suffix": ""},
    {"account": "1", "label": "Server 1", "suffix": "1"},
    {"account": "2", "label": "Server 2", "suffix": "2"},
]


def _has_credentials(suffix):
    server = ADDON.getSetting("server%s" % suffix).strip()
    username = ADDON.getSetting("username%s" % suffix).strip()
    password = ADDON.getSetting("password%s" % suffix).strip()
    return bool(server and username and password)


def get_available_accounts():
    return [a for a in ACCOUNTS if _has_credentials(a["suffix"])]


def get_current_account():
    value = ADDON.getSetting("account").strip()
    return value if value in ("0", "1", "2") else "0"


def get_next_account():
    accounts = get_available_accounts()

    if not accounts:
        return None

    current = get_current_account()
    values = [a["account"] for a in accounts]

    if current not in values:
        return accounts[0]

    pos = values.index(current)
    return accounts[(pos + 1) % len(accounts)]


def get_next_server_label(name=False):
    next_account = get_next_account()

    if not next_account:
        return "No Servers Available"

    if name:
        host = _server_host(ADDON.getSetting("server%s" % next_account["suffix"]))

        if next_account and host:
            return "Change to %s: %s" % (next_account["label"], host)
        else:
            return "Change to Server: %s" % (host or next_account["label"])

    return "Cycle Server: %s" % next_account["label"]


def cycle_server():
    next_account = get_next_account()

    if not next_account:
        xbmcgui.Dialog().notification(
            "GIPTV",
            "No saved servers found",
            xbmcgui.NOTIFICATION_WARNING,
        )
        return False

    ADDON.setSetting("account", next_account["account"])

    STATE.server = ""
    STATE.username = ""
    STATE.password = ""

    ensure_api_ready()

    xbmcgui.Dialog().notification(
        "GIPTV",
        "Switched to %s" % next_account["label"],
        xbmcgui.NOTIFICATION_INFO,
    )

    return True


def _server_host(url):

    url = (url or "").strip()

    if not url:
        return ""

    parsed = urlparse(url if "://" in url else "http://" + url)

    return parsed.netloc or parsed.path or url
