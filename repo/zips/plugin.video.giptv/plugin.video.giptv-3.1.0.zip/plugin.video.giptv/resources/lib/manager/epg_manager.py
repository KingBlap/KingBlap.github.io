# -*- coding: utf-8 -*-
"""
EPG Manager
-----------
Responsibilities:
  - Fetch / parse / cache XMLTV data
  - Serve now/next lookups with bounded LRU cache
  - Keep XMLTV times as UTC unix timestamps
  - Apply manual EPG offset only during lookup when explicitly supplied
  - Background warm thread with single-worker guard and stop event
  - Incremental XML parse to keep peak memory low

Important timing rule
---------------------
XMLTV programme start/stop values are parsed into UTC unix timestamps.
time.time() is also UTC unix time, so do not automatically add the system
UTC offset when deciding what is currently airing.

A user-provided EPG offset may still be applied to correct bad provider data.
"""

import json
import os
import threading
import time
import xml.etree.ElementTree as ET
from collections import OrderedDict

import xbmc
import xbmcaddon
import xbmcvfs

from resources.utils import giptv, settings
from resources.utils.xtream import STATE
from resources.apis.xmltv_fetcher import fetch_xmltv, ensure_epg_source_is_current

ADDON_ID = "plugin.video.giptv"

# ---------------------------------------------------------------------------
# Retention policy
# ---------------------------------------------------------------------------

EPG_CATCHUP_KEEP_DAYS = 7
NON_CATCHUP_LOOKBACK_SECONDS = 0

# ---------------------------------------------------------------------------
# Timing constants
# ---------------------------------------------------------------------------

EPG_LOCK_FILENAME = ".epg.lock"
EPG_LOCK_TTL = 30 * 60
EPG_TTL_SECONDS = 6 * 60 * 60
SOURCE_CHECK_INTERVAL = 5 * 60
NOW_NEXT_TTL_SECONDS = 120
NOW_NEXT_CACHE_MAX = 1000

# ---------------------------------------------------------------------------
# Timezone helper
# ---------------------------------------------------------------------------


def _get_system_utc_offset_minutes():
    """
    Return the system local UTC offset in minutes.

    This is for settings/debug display only. It is not automatically applied
    during now/next lookup because lookup compares UTC unix timestamps.
    """
    try:
        if time.daylight and time.localtime().tm_isdst:
            offset_seconds = -time.altzone
        else:
            offset_seconds = -time.timezone
        return int(offset_seconds // 60)
    except Exception:
        return 0


SYSTEM_UTC_OFFSET_MINUTES = _get_system_utc_offset_minutes()

# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

_XMLTV_INDEX = None
_LAST_LOADED = 0
_LAST_SOURCE_CHECK = 0
_CACHE_DIR = None

_LOCK = threading.Lock()
_WARM_THREAD = None
_WARM_REQUESTED = False
_STOP_EVENT = threading.Event()

_NOW_NEXT_CACHE = OrderedDict()
_NOW_NEXT_CACHE_LOCK = threading.Lock()

_CATCHUP_CHANNEL_IDS = set()
_CATCHUP_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# Logging shim
# ---------------------------------------------------------------------------


def log(msg, level=xbmc.LOGINFO):
    giptv.log(msg, level)


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def _safe_part(value, default="default"):
    value = value or default
    value = str(value).strip()
    for ch in ("://", "/", "\\", ":", "?", "&", "=", " "):
        value = value.replace(ch, "_")
    return value.strip("_") or default


def _cache_dir():
    global _CACHE_DIR

    if _CACHE_DIR:
        return _CACHE_DIR

    base = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/cache")
    if not xbmcvfs.exists(base):
        xbmcvfs.mkdirs(base)

    _CACHE_DIR = base
    return base


def _cache_filename():
    user = _safe_part(getattr(STATE, "username", None), "default")

    server = getattr(STATE, "server", None) or "server"
    server = str(server).strip().lower()
    server = server.replace("http://", "").replace("https://", "").rstrip("/")
    server = _safe_part(server, "server")

    return f"epg_index_{user}_{server}.json"


def _cache_path():
    return os.path.join(_cache_dir(), _cache_filename())


def _epg_lock_path():
    return os.path.join(_cache_dir(), EPG_LOCK_FILENAME)


def _raw_xmltv_cache_path():
    user = _safe_part(getattr(STATE, "username", None), "default")
    return os.path.join(_cache_dir(), f"{user}_xmltv.xml")


# ---------------------------------------------------------------------------
# File helpers
# ---------------------------------------------------------------------------


def _read_text_file(path):
    if not xbmcvfs.exists(path):
        return ""

    f = xbmcvfs.File(path, "r")
    try:
        return f.read() or ""
    finally:
        try:
            f.close()
        except Exception:
            pass


def _write_text_file(path, text):
    f = xbmcvfs.File(path, "w")
    try:
        f.write(text)
    finally:
        try:
            f.close()
        except Exception:
            pass


def _write_text_file_atomic(path, text):
    """
    Write using a .tmp file then rename.

    This avoids broken JSON if Kodi/Android kills the process mid-write.
    """
    tmp_path = path + ".tmp"

    try:
        _write_text_file(tmp_path, text)

        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)

        renamed = xbmcvfs.rename(tmp_path, path)
        if renamed is False:
            raise RuntimeError(f"rename failed: {tmp_path} -> {path}")

        return True

    except Exception as e:
        log(f"Atomic write failed for {path}: {e}", xbmc.LOGWARNING)
        try:
            if xbmcvfs.exists(tmp_path):
                xbmcvfs.delete(tmp_path)
        except Exception:
            pass
        return False


# ---------------------------------------------------------------------------
# Now/next LRU helpers
# ---------------------------------------------------------------------------


def _clear_now_next_cache():
    with _NOW_NEXT_CACHE_LOCK:
        _NOW_NEXT_CACHE.clear()


def _get_now_next_cached(key):
    with _NOW_NEXT_CACHE_LOCK:
        value = _NOW_NEXT_CACHE.get(key)
        if value is not None:
            _NOW_NEXT_CACHE.move_to_end(key)
        return value


def _set_now_next_cached(key, value):
    with _NOW_NEXT_CACHE_LOCK:
        _NOW_NEXT_CACHE[key] = value
        _NOW_NEXT_CACHE.move_to_end(key)

        while len(_NOW_NEXT_CACHE) > NOW_NEXT_CACHE_MAX:
            _NOW_NEXT_CACHE.popitem(last=False)


# ---------------------------------------------------------------------------
# EPG lock
# ---------------------------------------------------------------------------


def _acquire_epg_lock():
    path = _epg_lock_path()
    now = time.time()

    if xbmcvfs.exists(path):
        try:
            stat = xbmcvfs.Stat(path)
            age = now - stat.st_mtime()

            if age < EPG_LOCK_TTL:
                log("EPG warm already running — skipping", xbmc.LOGINFO)
                return False

            log("Stale EPG lock found — removing", xbmc.LOGWARNING)
            xbmcvfs.delete(path)

        except Exception:
            try:
                xbmcvfs.delete(path)
            except Exception:
                pass

    try:
        _write_text_file(path, str(int(now)))
        return True
    except Exception as e:
        log(f"Failed creating EPG lock: {e}", xbmc.LOGWARNING)
        return False


def _release_epg_lock():
    path = _epg_lock_path()

    if xbmcvfs.exists(path):
        try:
            xbmcvfs.delete(path)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Channel normalisation
# ---------------------------------------------------------------------------


def _norm(s):
    return str(s or "").strip().upper().replace(" ", "_").replace("-", "_")


def set_catchup_channels(channel_ids):
    """
    Register XMLTV channel IDs for channels that support catchup.
    Call this from live stream loading code before listing streams.
    """
    global _CATCHUP_CHANNEL_IDS

    new_ids = {_norm(cid) for cid in (channel_ids or []) if cid}

    with _CATCHUP_LOCK:
        _CATCHUP_CHANNEL_IDS = new_ids

    log(f"Registered {len(new_ids)} catchup channels", xbmc.LOGINFO)


def _is_catchup_channel(channel_id):
    # Writers replace the complete set atomically, so readers can perform a
    # lock-free O(1) membership check on either the old or new snapshot.
    return channel_id in _CATCHUP_CHANNEL_IDS


def _sort_programmes_if_needed(programmes):
    """Keep already ordered provider data linear; sort only malformed order."""
    for index in range(1, len(programmes)):
        if int(programmes[index - 1][0]) > int(programmes[index][0]):
            programmes.sort(key=lambda row: int(row[0]))
            break


def _local_tag_name(tag):
    """
    Strip XML namespace from an ElementTree tag.

    Examples:
      "{urn:xmltv}title" -> "title"
      "desc"             -> "desc"
    """
    return str(tag or "").split("}", 1)[-1].lower()


def _child_text(elem, wanted_name):
    """
    Return the first child text matching wanted_name, namespace-safe.
    """
    if elem is None:
        return ""

    wanted_name = str(wanted_name or "").lower()

    for child in list(elem):
        try:
            if _local_tag_name(child.tag) == wanted_name:
                return (child.text or "").strip()
        except Exception:
            pass

    return ""


def _child_texts(elem, wanted_name, limit=None):
    """
    Return all child texts matching wanted_name, namespace-safe.
    """
    if elem is None:
        return []

    wanted_name = str(wanted_name or "").lower()
    values = []

    for child in list(elem):
        try:
            if _local_tag_name(child.tag) == wanted_name:
                text = (child.text or "").strip()
                if text:
                    values.append(text)
                    if limit and len(values) >= limit:
                        break
        except Exception:
            pass

    return values


def _extract_programme_text(elem):
    """
    Extract title + rich description from one XMLTV <programme> element.

    Supports normal XMLTV tags and namespace-wrapped tags:
      title
      sub-title
      desc
      category
      episode-num
      date
      rating/value
    """
    title = _child_text(elem, "title")
    subtitle = _child_text(elem, "sub-title")
    desc = _child_text(elem, "desc")

    categories = _child_texts(elem, "category", limit=3)
    episode_nums = _child_texts(elem, "episode-num", limit=2)
    date_value = _child_text(elem, "date")

    rating_values = []
    try:
        for child in list(elem):
            if _local_tag_name(child.tag) != "rating":
                continue
            for sub in list(child):
                if _local_tag_name(sub.tag) == "value":
                    value = (sub.text or "").strip()
                    if value:
                        rating_values.append(value)
    except Exception:
        pass

    if not title:
        title = subtitle or "No programme title"

    desc_parts = []

    if desc:
        desc_parts.append(desc)

    if subtitle and subtitle != title:
        desc_parts.append(f"Subtitle: {subtitle}")

    if categories:
        desc_parts.append("Category: " + ", ".join(categories))

    if episode_nums:
        desc_parts.append("Episode: " + ", ".join(episode_nums))

    if date_value:
        desc_parts.append(f"Date: {date_value}")

    if rating_values:
        desc_parts.append("Rating: " + ", ".join(rating_values[:2]))

    return title, "\n".join(desc_parts)


# ---------------------------------------------------------------------------
# XMLTV time parsing
# ---------------------------------------------------------------------------


def _parse_xmltv_time(t):
    """
    Parse XMLTV timestamp to a UTC unix timestamp.

    XMLTV examples:
      20260426120000 +0100
      20260426110000 +0000
      20260426120000

    If the timestamp has an explicit +HHMM/-HHMM suffix, that declared offset
    is respected. If no suffix is present, the bare value is treated as UTC.
    """
    import calendar

    if not t:
        return None

    original = t

    try:
        t = str(t).strip()
        tz_offset_minutes = 0

        if " " in t:
            bare, tz_str = t.split(" ", 1)
            tz_str = tz_str.strip()

            if tz_str and tz_str[0] in ("+", "-"):
                sign = 1 if tz_str[0] == "+" else -1
                tz_digits = tz_str[1:5]

                if len(tz_digits) == 4 and tz_digits.isdigit():
                    hh = int(tz_digits[:2])
                    mm = int(tz_digits[2:])
                    tz_offset_minutes = sign * ((hh * 60) + mm)

            t = bare

        t = t[:14]

        if len(t) != 14 or not t.isdigit():
            log(f"Invalid XMLTV timestamp: {original!r}", xbmc.LOGWARNING)
            return None

        st = time.strptime(t, "%Y%m%d%H%M%S")
        utc_ts = calendar.timegm(st) - (tz_offset_minutes * 60)
        return int(utc_ts)

    except Exception as e:
        log(f"Failed to parse XMLTV time {original!r}: {e}", xbmc.LOGWARNING)
        return None


# ---------------------------------------------------------------------------
# Retention filter
# ---------------------------------------------------------------------------


def _should_keep_programme(channel, end_ts, now_ts):
    if _is_catchup_channel(channel):
        cutoff_ts = now_ts - (EPG_CATCHUP_KEEP_DAYS * 86400)
    else:
        cutoff_ts = now_ts - NON_CATCHUP_LOOKBACK_SECONDS

    return int(end_ts) >= cutoff_ts


# ---------------------------------------------------------------------------
# XMLTV incremental parser
# ---------------------------------------------------------------------------


def _build_epg_index(xmltv_path):
    """
    Incremental iterparse — never loads the whole tree into memory.

    Returns:
      {CHANNEL_ID: [(start_ts, end_ts, title, desc), ...]}

    Do not clear child elements like <title> or <desc> before the parent
    <programme> is processed, or text can be lost. Only clear the full
    programme element after extracting everything needed.
    """
    log("Parsing XMLTV incrementally…", xbmc.LOGINFO)

    t0 = time.time()
    now_ts = int(time.time())

    index = {}
    processed = 0
    skipped = 0
    kept_count = 0

    try:
        for event, elem in ET.iterparse(xmltv_path, events=("end",)):
            if elem.tag != "programme":
                continue

            try:
                channel = elem.get("channel")
                if not channel:
                    skipped += 1
                    continue

                channel = _norm(channel)

                start_raw = elem.get("start")
                stop_raw = elem.get("stop")

                if not start_raw or not stop_raw:
                    skipped += 1
                    continue

                start_ts = _parse_xmltv_time(start_raw)
                end_ts = _parse_xmltv_time(stop_raw)

                if start_ts is None or end_ts is None:
                    skipped += 1
                    continue

                if end_ts <= start_ts:
                    skipped += 1
                    continue

                processed += 1

                if not _should_keep_programme(channel, end_ts, now_ts):
                    continue

                title, desc = _extract_programme_text(elem)

                index.setdefault(channel, []).append((start_ts, end_ts, title, desc))
                kept_count += 1
            except Exception as e:
                skipped += 1
                log(f"Skipping bad programme entry: {e}", xbmc.LOGWARNING)

            finally:
                elem.clear()

        for channel in index:
            _sort_programmes_if_needed(index[channel])

        log(
            f"XMLTV parsed: {len(index)} channels, {processed} scanned, "
            f"{kept_count} kept in {time.time() - t0:.2f}s (skipped {skipped})",
            xbmc.LOGINFO,
        )

        return index

    except Exception as e:
        log(f"Failed parsing XMLTV: {e}", xbmc.LOGERROR)
        return {}


# ---------------------------------------------------------------------------
# Index trimming
# ---------------------------------------------------------------------------


def _trim_index(index):
    now_ts = int(time.time())
    trimmed = {}

    for channel, programmes in (index or {}).items():
        channel = _norm(channel)
        kept = []

        for prog in programmes or []:
            try:
                if not prog or len(prog) < 4:
                    continue

                start_ts = int(prog[0])
                end_ts = int(prog[1])
                title = prog[2] or ""
                desc = prog[3] or ""

                if end_ts <= start_ts:
                    continue

                if _should_keep_programme(channel, end_ts, now_ts):
                    kept.append((start_ts, end_ts, title, desc))

            except Exception:
                continue

        if kept:
            _sort_programmes_if_needed(kept)
            trimmed[channel] = kept

    return trimmed


# ---------------------------------------------------------------------------
# Disk cache
# ---------------------------------------------------------------------------


def _load_cache():
    path = _cache_path()

    if not xbmcvfs.exists(path):
        return None, 0

    start = time.time()

    try:
        raw = _read_text_file(path)
        read_ms = int((time.time() - start) * 1000)

        if not raw:
            return None, 0

        parse_start = time.time()
        data = json.loads(raw)
        parse_ms = int((time.time() - parse_start) * 1000)

        if not isinstance(data, dict):
            log("Invalid EPG cache format", xbmc.LOGWARNING)
            return None, 0

        index = data.get("index") or {}
        ts = int(data.get("timestamp", 0) or 0)

        trimmed = _trim_index(index)

        log(
            f"Loaded EPG disk cache | channels={len(trimmed)} "
            f"read={read_ms}ms parse={parse_ms}ms size={len(raw)} bytes",
            xbmc.LOGINFO,
        )

        return trimmed, ts

    except Exception as e:
        log(f"Failed to load EPG cache: {e}", xbmc.LOGWARNING)
        return None, 0


def _save_cache(index):
    """
    Write trimmed index to disk. Returns the trimmed dict.
    Overwrites rather than merging to avoid memory spikes.
    """
    path = _cache_path()
    trimmed = _trim_index(index or {})
    payload = {"timestamp": int(time.time()), "index": trimmed}

    try:
        text = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))

        if _write_text_file_atomic(path, text):
            log(
                f"Saved EPG cache | channels={len(trimmed)} "
                f"size={len(text)} bytes path={path}",
                xbmc.LOGINFO,
            )

    except Exception as e:
        log(f"Failed to save EPG cache: {e}", xbmc.LOGWARNING)

    return trimmed


# ---------------------------------------------------------------------------
# Source validation
# ---------------------------------------------------------------------------


def _maybe_validate_epg_source():
    """
    Validate source URL only from warm/fetch paths, not every UI lookup.
    """
    global _LAST_SOURCE_CHECK

    now = int(time.time())

    if now - _LAST_SOURCE_CHECK < SOURCE_CHECK_INTERVAL:
        return

    try:
        ensure_epg_source_is_current()
    except Exception as e:
        log(f"Failed EPG source check: {e}", xbmc.LOGWARNING)
    finally:
        _LAST_SOURCE_CHECK = now


# ---------------------------------------------------------------------------
# Background warm worker
# ---------------------------------------------------------------------------


def _warm_epg_inner():
    """Fetch → parse → save → promote to memory cache. Must hold no locks."""
    global _XMLTV_INDEX, _LAST_LOADED, EPG_CATCHUP_KEEP_DAYS

    if _STOP_EVENT.is_set():
        return

    if not _acquire_epg_lock():
        return

    try:
        if _STOP_EVENT.is_set():
            return

        username = getattr(STATE, "username", None) or "default"
        server = getattr(STATE, "server", None) or "server"

        log(f"EPG warm-up started for {username} / {server}", xbmc.LOGINFO)
        EPG_CATCHUP_KEEP_DAYS = settings.get_catchup_days(xbmcaddon.Addon())

        try:
            from resources.apis import xtream_api

            archive_ids = []
            for stream in xtream_api.get_all_live_streams_unfiltered():
                if str(stream.get("tv_archive", stream.get("has_archive", "0"))) == "1":
                    channel_id = resolve_xmltv_channel_id(stream)
                    if channel_id:
                        archive_ids.append(channel_id)
            set_catchup_channels(archive_ids)
        except Exception as exc:
            log("Catch-up channel discovery failed: {}".format(exc), xbmc.LOGWARNING)

        _maybe_validate_epg_source()

        if _STOP_EVENT.is_set():
            return

        xmltv_path = fetch_xmltv()
        if not xmltv_path:
            log("XMLTV fetch failed during warm-up", xbmc.LOGERROR)
            return

        if _STOP_EVENT.is_set():
            return

        fresh_index = _build_epg_index(xmltv_path)
        if not fresh_index:
            log("EPG build returned empty index", xbmc.LOGWARNING)
            return

        if _STOP_EVENT.is_set():
            return

        trimmed = _save_cache(fresh_index)

        with _LOCK:
            _XMLTV_INDEX = trimmed
            _LAST_LOADED = int(time.time())

        _clear_now_next_cache()

        log("EPG warm-up complete", xbmc.LOGINFO)

    finally:
        _release_epg_lock()


def _epg_worker_loop():
    """Single worker thread — processes one warm then checks for queued re-warm."""
    global _WARM_REQUESTED, _WARM_THREAD

    log("EPG worker started", xbmc.LOGINFO)

    try:
        while not _STOP_EVENT.is_set():
            try:
                _warm_epg_inner()
            except Exception as e:
                log(f"EPG worker failed: {e}", xbmc.LOGWARNING)

            with _LOCK:
                if _STOP_EVENT.is_set():
                    break

                if _WARM_REQUESTED:
                    log("EPG worker processing queued refresh request", xbmc.LOGINFO)
                    _WARM_REQUESTED = False
                    continue

                break

    finally:
        with _LOCK:
            _WARM_THREAD = None

        log("EPG worker stopped", xbmc.LOGINFO)


def _start_warm_epg_thread(force=False):
    global _WARM_THREAD, _WARM_REQUESTED

    with _LOCK:
        if force:
            _WARM_REQUESTED = True

        if _WARM_THREAD is not None and _WARM_THREAD.is_alive():
            log("EPG warm already running — reusing existing worker", xbmc.LOGINFO)
            return False

        _WARM_REQUESTED = False
        _STOP_EVENT.clear()

        _WARM_THREAD = threading.Thread(
            target=_epg_worker_loop,
            name="giptv_epg_warm",
            daemon=True,
        )
        _WARM_THREAD.start()

        return True


def _request_epg_refresh():
    global _WARM_REQUESTED

    with _LOCK:
        if _WARM_THREAD is not None and _WARM_THREAD.is_alive():
            _WARM_REQUESTED = True
            log("EPG refresh queued", xbmc.LOGINFO)
            return False

    return _start_warm_epg_thread(force=True)


def _warm_epg_sync():
    """Blocking warm — called only when no cache exists at all."""
    try:
        _STOP_EVENT.clear()
        _warm_epg_inner()
    except Exception as e:
        log(f"EPG sync warm failed: {e}", xbmc.LOGWARNING)


def shutdown_epg_worker(wait=False, timeout=2.0):
    _STOP_EVENT.set()

    with _LOCK:
        thread = _WARM_THREAD

    if wait and thread and thread.is_alive():
        try:
            thread.join(timeout)
        except Exception:
            pass

    log("EPG worker shutdown requested", xbmc.LOGINFO)


# ---------------------------------------------------------------------------
# Primary public API
# ---------------------------------------------------------------------------


def get_xmltv_index():
    """
    Return the in-memory XMLTV index, loading from disk or fetching fresh
    as needed. Background refresh is triggered when the index is stale.

    This intentionally does not validate the EPG source synchronously on every
    call, because this function may be called while building Kodi directory UI.
    """
    global _XMLTV_INDEX, _LAST_LOADED

    now = time.time()

    with _LOCK:
        memory_index = _XMLTV_INDEX
        last_loaded = _LAST_LOADED

    if memory_index is not None:
        if now - last_loaded > EPG_TTL_SECONDS:
            _request_epg_refresh()

        return memory_index

    index, ts = _load_cache()

    if index:
        with _LOCK:
            _XMLTV_INDEX = index
            _LAST_LOADED = ts or int(now)

        if now - (ts or 0) > EPG_TTL_SECONDS:
            _request_epg_refresh()

        log("Loaded EPG index from disk cache", xbmc.LOGINFO)
        return index

    log("No cached EPG found, warming synchronously", xbmc.LOGINFO)

    _warm_epg_sync()

    with _LOCK:
        if _XMLTV_INDEX is not None:
            return _XMLTV_INDEX

    log("EPG warm failed, returning empty index", xbmc.LOGWARNING)
    return {}


def get_xmltv_index_for_channel(channel_id):
    """
    Convenience: return just the programme list for one channel.
    Returns [] if not found.
    """
    if not channel_id:
        return []

    return get_xmltv_index().get(_norm(channel_id), [])


def _effective_lookup_now(offset_minutes=0):
    """
    Return:
      (effective_now_ts, effective_offset_minutes)

    time.time() is UTC unix time. Programme timestamps are UTC unix time.
    Therefore, no system timezone correction is needed.

    offset_minutes is a manual provider correction:
      +60 means look 60 minutes ahead in the EPG.
      -60 means look 60 minutes behind in the EPG.
    """
    try:
        effective_offset = int(offset_minutes or 0)
    except Exception:
        effective_offset = 0

    now_ts = int(time.time()) + (effective_offset * 60)

    return now_ts, effective_offset


def _programme_upper_bound(programmes, timestamp):
    """Index of the first programme starting after timestamp (binary search)."""
    low = 0
    high = len(programmes)
    while low < high:
        middle = (low + high) // 2
        try:
            start_ts = int(programmes[middle][0])
        except Exception:
            # Parsed/cached EPG rows are validated, but make malformed rows
            # deterministic without falling back to a full linear scan.
            start_ts = timestamp + 1
        if start_ts <= timestamp:
            low = middle + 1
        else:
            high = middle
    return low


def get_now(xmltv_index, channel_id, offset_minutes=0):
    """
    Return the currently airing programme tuple:
      (title, desc, start_ts, end_ts)

    offset_minutes is a manual EPG shift. Positive means look ahead.
    """
    if not xmltv_index or not channel_id:
        return None

    programmes = xmltv_index.get(_norm(channel_id))
    if not programmes:
        return None

    now_ts, _effective_offset = _effective_lookup_now(offset_minutes)

    position = _programme_upper_bound(programmes, now_ts)
    if position > 0:
        try:
            start_ts, end_ts, title, desc = programmes[position - 1]
            start_ts = int(start_ts)
            end_ts = int(end_ts)
            if start_ts <= now_ts < end_ts:
                return (title, desc, start_ts, end_ts)
        except Exception:
            pass

    return None


def get_now_next(xmltv_index, channel_id, offset_minutes=0):
    """
    Return {"now": tuple|None, "next": tuple|None} for the given channel.

    Results are cached in a bounded LRU for NOW_NEXT_TTL_SECONDS seconds.
    """
    if not xmltv_index or not channel_id:
        return None

    cid = _norm(channel_id)
    programmes = xmltv_index.get(cid)

    if not programmes:
        return None

    now_ts, effective_offset = _effective_lookup_now(offset_minutes)

    bucket = now_ts // NOW_NEXT_TTL_SECONDS
    cache_key = f"{cid}:{effective_offset}:{bucket}"

    cached = _get_now_next_cached(cache_key)
    if cached is not None:
        return cached

    now_prog = None
    next_prog = None
    position = _programme_upper_bound(programmes, now_ts)

    if position > 0:
        try:
            start_ts, end_ts, title, desc = programmes[position - 1]
            start_ts = int(start_ts)
            end_ts = int(end_ts)
            if start_ts <= now_ts < end_ts:
                now_prog = (title, desc, start_ts, end_ts)
        except Exception:
            pass

    if position < len(programmes):
        try:
            start_ts, end_ts, title, desc = programmes[position]
            next_prog = (title, desc, int(start_ts), int(end_ts))
        except Exception:
            pass

    result = {
        "now": now_prog,
        "next": next_prog,
    }

    _set_now_next_cached(cache_key, result)

    return result


def get_now_for_channel(channel_id, offset_minutes=0):
    """
    Convenience wrapper when caller does not already have xmltv_index.

    Avoid using this inside big list loops because it may call get_xmltv_index().
    In navigator list routes, prefer:

        xmltv_index = get_xmltv_index()
        get_now(xmltv_index, channel_id, offset)
    """
    if not channel_id:
        return None

    xmltv_index = get_xmltv_index()
    return get_now(xmltv_index, channel_id, offset_minutes)


def get_now_next_for_channel(channel_id, offset_minutes=0):
    """
    Convenience wrapper when caller does not already have xmltv_index.

    Avoid using this inside big list loops because it may call get_xmltv_index().
    In navigator list routes, prefer:

        xmltv_index = get_xmltv_index()
        get_now_next(xmltv_index, channel_id, offset)
    """
    if not channel_id:
        return None

    xmltv_index = get_xmltv_index()
    return get_now_next(xmltv_index, channel_id, offset_minutes)


def resolve_xmltv_channel_id(stream):
    """
    Extract and normalise the XMLTV channel ID from a stream dict.
    Tries epg_channel_id then tvg_id.
    """
    if not isinstance(stream, dict):
        return None

    cid = stream.get("epg_channel_id") or stream.get("tvg_id")
    if not cid:
        return None

    return _norm(cid)


# ---------------------------------------------------------------------------
# Cache management
# ---------------------------------------------------------------------------


def clear_epg_cache():
    """Full reset: stop worker, delete disk files, wipe memory state."""
    global _XMLTV_INDEX
    global _LAST_LOADED
    global _LAST_SOURCE_CHECK
    global _WARM_THREAD
    global _WARM_REQUESTED

    user = getattr(STATE, "username", None) or "default"
    server = getattr(STATE, "server", None) or "server"

    log(f"Clearing EPG cache for user='{user}' server='{server}'", xbmc.LOGINFO)

    _STOP_EVENT.set()

    json_cache = _cache_path()

    if xbmcvfs.exists(json_cache):
        try:
            xbmcvfs.delete(json_cache)
            log(f"Deleted EPG JSON cache: {json_cache}", xbmc.LOGINFO)
        except Exception as e:
            log(f"Failed to delete EPG JSON cache: {e}", xbmc.LOGWARNING)

    tmp_cache = json_cache + ".tmp"

    if xbmcvfs.exists(tmp_cache):
        try:
            xbmcvfs.delete(tmp_cache)
        except Exception:
            pass

    xmltv_path = _raw_xmltv_cache_path()

    if xbmcvfs.exists(xmltv_path):
        try:
            xbmcvfs.delete(xmltv_path)
            log(f"Deleted XMLTV cache: {xmltv_path}", xbmc.LOGINFO)
        except Exception as e:
            log(f"Failed to delete XMLTV cache: {e}", xbmc.LOGWARNING)

    with _LOCK:
        _XMLTV_INDEX = None
        _LAST_LOADED = 0
        _WARM_REQUESTED = False
        _WARM_THREAD = None

    _LAST_SOURCE_CHECK = 0

    _clear_now_next_cache()

    try:
        _release_epg_lock()
    except Exception as e:
        log(f"Failed to release EPG lock: {e}", xbmc.LOGWARNING)

    _STOP_EVENT.clear()

    log("EPG cache fully reset", xbmc.LOGINFO)


def get_epg_system_offset():
    """
    Public accessor — returns the auto-detected system UTC offset in minutes.
    Useful for display/debug only.

    Example:
      UTC+1 returns 60
      UTC-5 returns -300
    """
    return SYSTEM_UTC_OFFSET_MINUTES
