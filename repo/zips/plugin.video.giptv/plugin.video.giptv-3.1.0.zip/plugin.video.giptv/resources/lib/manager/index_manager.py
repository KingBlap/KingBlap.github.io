# -*- coding: utf-8 -*-
import gc
import json
import os
import re
import threading
import time
import unicodedata
from collections import OrderedDict
from queue import Empty, Queue

import xbmc
import xbmcaddon
import xbmcvfs

import resources.apis.xtream_api as xtream_api
import resources.utils.giptv as giptv
from resources.utils.config import ensure_api_ready
from resources.utils.xtream import STATE

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

# ============================================================
#  GLOBAL STATE
# ============================================================

_INDEX_LOCK = threading.Lock()
_INDEX_BUILDING = False

_BUILD_QUEUE = Queue()
_BUILD_WORKER = None
_BUILD_WORKER_LOCK = threading.Lock()
_BUILD_WORKER_STOP = threading.Event()

_QUEUED_KEYS = set()
_QUEUED_KEYS_LOCK = threading.Lock()

_INDEX_DIR_CACHE = None

_INDEX_READ_CACHE = OrderedDict()
_INDEX_READ_CACHE_LOCK = threading.Lock()
_INDEX_READ_CACHE_MAX = 3

# ============================================================
#  TUNABLES
# ============================================================

INDEX_FRESH_AGE = 7 * 24 * 60 * 60
RECENT_BUILD_COOLDOWN = 24 * 60 * 60
STALE_RUNNING_AGE = 2 * 60 * 60
STALE_LOCK_AGE = 2 * 60 * 60

_FETCH_WORKERS = 4
_FETCH_TIMEOUT = 120

_BUILD_WORKER_IDLE_TIMEOUT = 10.0

_INDEX_TYPES = ("vod", "series", "live")


# ============================================================
#  PATH / STATE HELPERS
# ============================================================


def _safe_part(value, default="default"):
    value = value or default
    value = str(value).strip()

    value = value.replace("http://", "")
    value = value.replace("https://", "")

    for ch in ("://", "/", "\\", ":", "?", "&", "=", " "):
        value = value.replace(ch, "_")

    return value.strip("_") or default


def _normalise_server(server):
    server = str(server or "").strip().rstrip("/")
    if not server:
        return ""

    if not server.startswith("http://") and not server.startswith("https://"):
        server = "http://" + server

    return server.rstrip("/")


def _current_state_snapshot():
    return {
        "server": _normalise_server(getattr(STATE, "server", "") or ""),
        "username": str(getattr(STATE, "username", "") or "").strip(),
        "password": str(getattr(STATE, "password", "") or "").strip(),
    }


def _state_key_from_snapshot(snapshot):
    snapshot = snapshot or {}
    username = _safe_part(snapshot.get("username"), "default")
    server = _safe_part(snapshot.get("server"), "server")
    return "{}_{}".format(username, server)


def _state_key():
    return _state_key_from_snapshot(_current_state_snapshot())


def _snapshot_has_required_state(snapshot):
    snapshot = snapshot or {}
    return bool(
        _normalise_server(snapshot.get("server"))
        and str(snapshot.get("username") or "").strip()
        and str(snapshot.get("password") or "").strip()
    )


def _snapshot_clean(snapshot):
    snapshot = snapshot or {}
    return {
        "server": _normalise_server(snapshot.get("server")),
        "username": str(snapshot.get("username") or "").strip(),
        "password": str(snapshot.get("password") or "").strip(),
        "account_suffix": str(snapshot.get("account_suffix") or "").strip(),
    }


def _index_dir():
    global _INDEX_DIR_CACHE

    if _INDEX_DIR_CACHE:
        return _INDEX_DIR_CACHE

    path = xbmcvfs.translatePath(
        "special://profile/addon_data/{}/index".format(ADDON_ID)
    )

    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)

    _INDEX_DIR_CACHE = path
    return path


def _index_path(name, state_key=None):
    state_key = state_key or _state_key()
    return os.path.join(_index_dir(), "{}_{}_index.json".format(state_key, name))


def _index_lock_path(state_key=None):
    state_key = state_key or _state_key()
    return os.path.join(_index_dir(), ".{}.index.lock".format(state_key))


def _state_path(state_key=None):
    state_key = state_key or _state_key()
    return os.path.join(_index_dir(), "{}_index_state.json".format(state_key))


def _state_changed(build_state_key):
    try:
        return _state_key() != str(build_state_key or "")
    except Exception:
        return False


# ============================================================
#  FILE HELPERS
# ============================================================


def _read_text_file(path):
    if not xbmcvfs.exists(path):
        return ""

    f = xbmcvfs.File(path, "r")
    try:
        return f.read() or ""
    finally:
        try:
            f.close()
        except Exception:
            pass


def _write_text_file(path, text):
    f = xbmcvfs.File(path, "w")
    try:
        f.write(text)
    finally:
        try:
            f.close()
        except Exception:
            pass


def _write_text_file_atomic(path, text):
    tmp_path = path + ".tmp"

    try:
        _write_text_file(tmp_path, text)

        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)

        renamed = xbmcvfs.rename(tmp_path, path)
        if renamed is False:
            raise RuntimeError("rename failed: {} -> {}".format(tmp_path, path))

        return True

    except Exception as exc:
        giptv.log(
            "[INDEX_MANAGER] Atomic write failed for {}: {}".format(path, exc),
            xbmc.LOGERROR,
        )

        try:
            if xbmcvfs.exists(tmp_path):
                xbmcvfs.delete(tmp_path)
        except Exception:
            pass

        return False


def _file_mtime(path):
    try:
        return xbmcvfs.Stat(path).st_mtime()
    except Exception:
        return 0


def _file_size(path):
    try:
        return xbmcvfs.Stat(path).st_size()
    except Exception:
        return 0


# ============================================================
#  STATE FILE HELPERS
# ============================================================


def _read_state(state_key=None):
    raw = _read_text_file(_state_path(state_key))
    if not raw:
        return {}

    try:
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_state(data, state_key=None):
    try:
        payload = json.dumps(data or {}, ensure_ascii=False, separators=(",", ":"))
        _write_text_file_atomic(_state_path(state_key), payload)
    except Exception as exc:
        giptv.log(
            "[INDEX_MANAGER] Failed writing state file: {}".format(exc),
            xbmc.LOGWARNING,
        )


def _clear_state(state_key=None):
    path = _state_path(state_key)
    try:
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
    except Exception:
        pass


# ============================================================
#  INDEX READ CACHE
# ============================================================


def _clear_index_read_cache(name=None, state_key=None):
    with _INDEX_READ_CACHE_LOCK:
        if name is None:
            _INDEX_READ_CACHE.clear()
            return

        try:
            _INDEX_READ_CACHE.pop(_index_path(name, state_key), None)
        except Exception:
            _INDEX_READ_CACHE.clear()


def _cache_index_data(path, data):
    with _INDEX_READ_CACHE_LOCK:
        _INDEX_READ_CACHE[path] = data
        _INDEX_READ_CACHE.move_to_end(path)

        while len(_INDEX_READ_CACHE) > _INDEX_READ_CACHE_MAX:
            try:
                _INDEX_READ_CACHE.popitem(last=False)
            except Exception:
                _INDEX_READ_CACHE.clear()
                break


def _get_cached_index_data(path):
    with _INDEX_READ_CACHE_LOCK:
        data = _INDEX_READ_CACHE.get(path)
        if data is not None:
            _INDEX_READ_CACHE.move_to_end(path)
        return data


# ============================================================
#  LOCK HELPERS
# ============================================================


def _acquire_index_lock(state_key=None, max_age=STALE_LOCK_AGE):
    lock_path = _index_lock_path(state_key)
    now = time.time()

    if xbmcvfs.exists(lock_path):
        raw = _read_text_file(lock_path)

        try:
            ts = float(raw or 0)
        except Exception:
            ts = 0

        age = now - ts if ts else 0

        if ts and age < max_age:
            giptv.log(
                "[INDEX_MANAGER] Lock exists — build already running | state={}".format(
                    state_key or _state_key()
                ),
                xbmc.LOGINFO,
            )
            return False

        giptv.log(
            "[INDEX_MANAGER] Stale lock found — removing | state={}".format(
                state_key or _state_key()
            ),
            xbmc.LOGWARNING,
        )

        try:
            xbmcvfs.delete(lock_path)
        except Exception:
            pass

    try:
        _write_text_file(lock_path, str(now))
        return True
    except Exception as exc:
        giptv.log(
            "[INDEX_MANAGER] Failed creating lock file: {}".format(exc),
            xbmc.LOGERROR,
        )
        return False


def _release_index_lock(state_key=None):
    lock_path = _index_lock_path(state_key)
    try:
        if xbmcvfs.exists(lock_path):
            xbmcvfs.delete(lock_path)
    except Exception:
        pass


# ============================================================
#  NORMALISATION / SEARCH BLOB
# ============================================================


def _normalize_title(value):
    if not value:
        return ""

    value = unicodedata.normalize("NFKD", str(value))
    value = "".join(c for c in value if not unicodedata.combining(c))
    return value.lower().strip()


def _normalize_search_text(value):
    value = value or ""
    value = unicodedata.normalize("NFKD", str(value))
    value = "".join(c for c in value if not unicodedata.combining(c))
    value = value.lower().strip()
    value = re.sub(r"\s+", " ", value)
    return value


def _tokenize_search_text(value):
    value = _normalize_search_text(value)
    if not value:
        return []
    return [t for t in re.split(r"[^a-z0-9]+", value) if t]


def _make_search_blob(*parts):
    joined = " ".join([str(p or "") for p in parts if p])
    normalized = _normalize_search_text(joined)

    return {
        "search_text": normalized,
        "search_tokens": _tokenize_search_text(normalized),
    }


# ============================================================
#  INDEX I/O
# ============================================================


def _write_index(name, data, state_key=None):
    path = _index_path(name, state_key)

    try:
        payload = json.dumps(data or [], ensure_ascii=False, separators=(",", ":"))
    except Exception as exc:
        giptv.log(
            "[INDEX_MANAGER] Failed serializing {} index: {}".format(name, exc),
            xbmc.LOGERROR,
        )
        return False

    ok = _write_text_file_atomic(path, payload)
    if not ok:
        return False

    _clear_index_read_cache(name, state_key)

    giptv.log(
        "[INDEX_MANAGER] Wrote {} index | state={} items={} size={} bytes".format(
            name,
            state_key or _state_key(),
            len(data) if hasattr(data, "__len__") else "?",
            len(payload),
        ),
        xbmc.LOGINFO,
    )

    return True


def _read_index(name, use_memory_cache=True, state_key=None):
    path = _index_path(name, state_key)

    if use_memory_cache:
        cached = _get_cached_index_data(path)
        if cached is not None:
            try:
                giptv.log(
                    "[INDEX_MANAGER] Read cache hit | name={} state={} items={}".format(
                        name,
                        state_key or _state_key(),
                        len(cached),
                    ),
                    xbmc.LOGDEBUG,
                )
            except Exception:
                pass
            return cached

    if not xbmcvfs.exists(path):
        giptv.log(
            "[INDEX_MANAGER] Index file missing | name={} state={} path={}".format(
                name,
                state_key or _state_key(),
                path,
            ),
            xbmc.LOGINFO,
        )
        return []

    start = time.time()
    raw = _read_text_file(path)
    read_ms = int((time.time() - start) * 1000)

    if not raw:
        giptv.log(
            "[INDEX_MANAGER] Empty index file | name={} path={}".format(name, path),
            xbmc.LOGWARNING,
        )
        return []

    try:
        parse_start = time.time()
        data = json.loads(raw)
        parse_ms = int((time.time() - parse_start) * 1000)
    except Exception as exc:
        giptv.log(
            "[INDEX_MANAGER] Failed parsing index | name={} path={} error={}".format(
                name,
                path,
                exc,
            ),
            xbmc.LOGWARNING,
        )
        return []

    if not isinstance(data, list):
        giptv.log(
            "[INDEX_MANAGER] Invalid index format | name={} expected=list got={}".format(
                name,
                type(data).__name__,
            ),
            xbmc.LOGWARNING,
        )
        return []

    if use_memory_cache:
        _cache_index_data(path, data)

    giptv.log(
        "[INDEX_MANAGER] Loaded index | name={} state={} items={} read={}ms parse={}ms size={} bytes".format(
            name,
            state_key or _state_key(),
            len(data),
            read_ms,
            parse_ms,
            len(raw),
        ),
        xbmc.LOGINFO,
    )

    return data


# ============================================================
#  STATUS HELPERS
# ============================================================


def _index_last_modified(state_key=None):
    latest = 0

    for name in _INDEX_TYPES:
        path = _index_path(name, state_key)
        if not xbmcvfs.exists(path):
            return 0
        latest = max(latest, _file_mtime(path))

    return latest


def index_exists_and_valid(state_key=None):
    for name in _INDEX_TYPES:
        path = _index_path(name, state_key)

        if not xbmcvfs.exists(path):
            giptv.log(
                "[INDEX_MANAGER] invalid: missing | name={} state={} path={}".format(
                    name,
                    state_key or _state_key(),
                    path,
                ),
                xbmc.LOGINFO,
            )
            return False

        size = _file_size(path)

        # "[]" is valid JSON and size 2. Do not force endless rebuilds
        # if a valid account simply has no items in one section.
        if size < 2:
            giptv.log(
                "[INDEX_MANAGER] invalid: tiny | name={} size={} path={}".format(
                    name,
                    size,
                    path,
                ),
                xbmc.LOGWARNING,
            )
            return False

    return True


def index_is_fresh(max_age_seconds=INDEX_FRESH_AGE, state_key=None):
    last_mod = _index_last_modified(state_key)
    if not last_mod:
        return False

    age = time.time() - last_mod
    fresh = age < max_age_seconds

    if not fresh:
        giptv.log(
            "[INDEX_MANAGER] Index stale | state={} age={}s max={}s".format(
                state_key or _state_key(),
                int(age),
                max_age_seconds,
            ),
            xbmc.LOGINFO,
        )

    return fresh


def ran_recently(cooldown_seconds=RECENT_BUILD_COOLDOWN, state_key=None):
    state = _read_state(state_key)
    finished_at = state.get("finished_at", 0) or 0

    if not finished_at:
        return False

    try:
        return (time.time() - float(finished_at)) < cooldown_seconds
    except Exception:
        return False


def build_in_progress(max_stale_seconds=STALE_RUNNING_AGE, state_key=None):
    state = _read_state(state_key)

    if state.get("status") != "running":
        return False

    started_at = state.get("started_at", 0) or 0
    if not started_at:
        return False

    try:
        age = time.time() - float(started_at)
    except Exception:
        return False

    if age > max_stale_seconds:
        giptv.log(
            "[INDEX_MANAGER] Stale running state detected — ignoring | state={}".format(
                state_key or _state_key()
            ),
            xbmc.LOGWARNING,
        )
        return False

    return True


def should_build(
    force=False,
    cooldown_seconds=RECENT_BUILD_COOLDOWN,
    fresh_age_seconds=INDEX_FRESH_AGE,
    state_key=None,
):
    if force:
        return True, "forced"

    if build_in_progress(state_key=state_key):
        return False, "build already running"

    exists_valid = index_exists_and_valid(state_key=state_key)

    if not exists_valid:
        return True, "index missing or invalid"

    if index_is_fresh(
        max_age_seconds=fresh_age_seconds,
        state_key=state_key,
    ):
        return False, "index is still fresh"

    if ran_recently(cooldown_seconds=cooldown_seconds, state_key=state_key):
        return False, "build ran recently"

    return True, "index stale"


# ============================================================
#  FETCH / BUILD HELPERS
# ============================================================


def _is_abort_requested(monitor):
    try:
        return bool(monitor and monitor.abortRequested())
    except Exception:
        return False


def _fetch_category_list(content_type, snapshot):
    try:
        if hasattr(xtream_api, "categories_for_index"):
            data = xtream_api.categories_for_index(content_type, snapshot)
        else:
            data = xtream_api.categories(content_type)

        if data is None:
            return None

        return data if isinstance(data, list) else []

    except Exception as exc:
        giptv.log(
            "[INDEX_MANAGER] Failed fetching categories type={}: {}".format(
                content_type,
                exc,
            ),
            xbmc.LOGWARNING,
        )
        return None


def _fetch_streams_for_category(content_type, cat_id, snapshot):
    if hasattr(xtream_api, "streams_by_category_for_index"):
        return (
            xtream_api.streams_by_category_for_index(
                content_type,
                cat_id,
                snapshot,
            )
            or []
        )

    return xtream_api.streams_by_category(content_type, cat_id) or []


def _fetch_categories_parallel(
    content_type,
    cats,
    monitor,
    snapshot,
    build_state_key,
    ignore_active_state_change=False,
):
    results = []
    results_lock = threading.Lock()
    abort_event = threading.Event()
    cat_queue = Queue()

    for cat in cats or []:
        if isinstance(cat, dict) and cat.get("category_id") is not None:
            cat_queue.put(cat)

    total_cats = cat_queue.qsize()
    if not total_cats:
        return results

    is_vod = content_type == xtream_api.VOD_TYPE
    is_series = content_type == xtream_api.SERIES_TYPE

    def worker():
        while not abort_event.is_set():
            if _is_abort_requested(monitor):
                abort_event.set()
                break

            if not ignore_active_state_change and _state_changed(build_state_key):
                giptv.log(
                    "[INDEX_MANAGER] State changed during fetch — aborting worker | build_state={}".format(
                        build_state_key
                    ),
                    xbmc.LOGWARNING,
                )
                abort_event.set()
                break

            try:
                cat = cat_queue.get_nowait()
            except Empty:
                break

            try:
                cat_id = cat.get("category_id")
                cat_name = cat.get("category_name", "")
                cat_lower = _normalize_search_text(cat_name)

                streams = _fetch_streams_for_category(content_type, cat_id, snapshot)

                batch = []

                for item in streams:
                    if not isinstance(item, dict):
                        continue

                    sid = item.get("series_id") if is_series else item.get("stream_id")
                    if not sid:
                        continue

                    if is_vod:
                        title = item.get("name") or item.get("title") or "Unknown"
                        search_blob = _make_search_blob(title, cat_name)

                        batch.append(
                            {
                                "id": str(sid),
                                "title": title,
                                "lower": _normalize_title(title),
                                "category_id": cat_id,
                                "category_name": cat_name,
                                "category_lower": cat_lower,
                                "search_text": search_blob["search_text"],
                                "search_tokens": search_blob["search_tokens"],
                                "thumb": item.get("stream_icon")
                                or item.get("cover")
                                or "",
                                "tmdb": item.get("tmdb") or item.get("tmdb_id") or "",
                                "ext": item.get("container_extension", "mp4"),
                            }
                        )

                    elif is_series:
                        title = item.get("name") or item.get("title") or "Unknown"
                        search_blob = _make_search_blob(title, cat_name)

                        batch.append(
                            {
                                "id": str(sid),
                                "title": title,
                                "lower": _normalize_title(title),
                                "category_id": cat_id,
                                "category_name": cat_name,
                                "category_lower": cat_lower,
                                "search_text": search_blob["search_text"],
                                "search_tokens": search_blob["search_tokens"],
                                "thumb": item.get("cover")
                                or item.get("stream_icon")
                                or "",
                                "tmdb": item.get("tmdb") or item.get("tmdb_id") or "",
                            }
                        )

                    else:
                        title = (
                            item.get("name")
                            or item.get("stream_display_name")
                            or "Unknown Channel"
                        )
                        search_blob = _make_search_blob(title, cat_name)

                        batch.append(
                            {
                                "id": str(sid),
                                "title": title,
                                "lower": _normalize_title(title),
                                "category_id": cat_id,
                                "category_name": cat_name,
                                "category_lower": cat_lower,
                                "search_text": search_blob["search_text"],
                                "search_tokens": search_blob["search_tokens"],
                                "thumb": item.get("stream_icon")
                                or item.get("tv_logo")
                                or "",
                                "epg_channel_id": item.get("epg_channel_id")
                                or item.get("tvg_id")
                                or "",
                                "has_archive": item.get(
                                    "tv_archive", item.get("has_archive", "0")
                                ),
                                "tv_archive_duration": item.get(
                                    "tv_archive_duration", "0"
                                ),
                                "ext": item.get("container_extension", "ts"),
                            }
                        )

                if batch:
                    with results_lock:
                        results.extend(batch)

            except Exception as exc:
                giptv.log(
                    "[INDEX_MANAGER] fetch error type={} cat={}: {}".format(
                        content_type,
                        cat.get("category_id"),
                        exc,
                    ),
                    xbmc.LOGWARNING,
                )

            finally:
                try:
                    cat_queue.task_done()
                except Exception:
                    pass

    num_workers = min(_FETCH_WORKERS, total_cats)
    threads = []

    for _ in range(num_workers):
        t = threading.Thread(target=worker, name="giptv_index_fetch", daemon=True)
        t.start()
        threads.append(t)

    deadline = time.time() + _FETCH_TIMEOUT

    while time.time() < deadline:
        if _is_abort_requested(monitor):
            abort_event.set()
            giptv.log(
                "[INDEX_MANAGER] Parallel fetch aborted by monitor", xbmc.LOGWARNING
            )
            break

        if not ignore_active_state_change and _state_changed(build_state_key):
            abort_event.set()
            giptv.log(
                "[INDEX_MANAGER] Parallel fetch aborted: STATE changed | build_state={}".format(
                    build_state_key
                ),
                xbmc.LOGWARNING,
            )
            break

        if not any(t.is_alive() for t in threads):
            break

        time.sleep(0.1)
    else:
        abort_event.set()
        giptv.log(
            "[INDEX_MANAGER] Parallel fetch timed out after {}s".format(_FETCH_TIMEOUT),
            xbmc.LOGWARNING,
        )

    for t in threads:
        try:
            t.join(timeout=2)
        except Exception:
            pass

    if abort_event.is_set():
        return None

    seen = {}
    for entry in results:
        try:
            seen[str(entry["id"])] = entry
        except Exception:
            pass

    return list(seen.values())


def _abort_if_state_changed(build_state_key, ignore_active_state_change=False):
    if ignore_active_state_change:
        return False

    if _state_changed(build_state_key):
        giptv.log(
            "[INDEX_MANAGER] Aborting build because active server/account changed | build_state={} current_state={}".format(
                build_state_key,
                _state_key(),
            ),
            xbmc.LOGWARNING,
        )
        return True

    return False


# ============================================================
#  BACKGROUND QUEUE
# ============================================================


def _queue_key(source="unknown", force=False, state_key=None):
    return "{}|{}|{}".format(
        state_key or _state_key(),
        source,
        "1" if force else "0",
    )


def _remove_queued_key(key):
    with _QUEUED_KEYS_LOCK:
        _QUEUED_KEYS.discard(key)


def _index_worker():
    global _BUILD_WORKER

    giptv.log("[INDEX_MANAGER] Background worker started", xbmc.LOGINFO)

    idle_started = None

    try:
        while not _BUILD_WORKER_STOP.is_set():
            try:
                item = _BUILD_QUEUE.get(timeout=0.5)
                idle_started = None
            except Empty:
                if idle_started is None:
                    idle_started = time.time()

                if time.time() - idle_started >= _BUILD_WORKER_IDLE_TIMEOUT:
                    giptv.log(
                        "[INDEX_MANAGER] Background worker idle — stopping",
                        xbmc.LOGINFO,
                    )
                    break

                continue

            if item is None:
                try:
                    _BUILD_QUEUE.task_done()
                except Exception:
                    pass
                break

            key = item.get("queue_key")
            monitor = item.get("monitor")
            notify = bool(item.get("notify", False))
            source = item.get("source", "queued")
            force = bool(item.get("force", False))
            snapshot = item.get("snapshot") or {}
            ignore_active_state_change = bool(
                item.get("ignore_active_state_change", False)
            )

            try:
                build_index(
                    monitor=monitor,
                    notify=notify,
                    source=source,
                    force=force,
                    snapshot=snapshot,
                    ignore_active_state_change=ignore_active_state_change,
                )
            except Exception as exc:
                giptv.log(
                    "[INDEX_MANAGER] Background build crashed: {}".format(exc),
                    xbmc.LOGERROR,
                )
            finally:
                _remove_queued_key(key)
                try:
                    _BUILD_QUEUE.task_done()
                except Exception:
                    pass

    finally:
        with _BUILD_WORKER_LOCK:
            _BUILD_WORKER = None

        giptv.log("[INDEX_MANAGER] Background worker stopped", xbmc.LOGINFO)


def _ensure_build_worker():
    global _BUILD_WORKER

    with _BUILD_WORKER_LOCK:
        if _BUILD_WORKER and _BUILD_WORKER.is_alive():
            return

        _BUILD_WORKER_STOP.clear()
        _BUILD_WORKER = threading.Thread(
            target=_index_worker,
            name="giptv_index_worker",
            daemon=True,
        )
        _BUILD_WORKER.start()


def queue_build_index_for_snapshot(
    snapshot,
    monitor=None,
    notify=False,
    source="queued_snapshot",
    force=False,
):
    snapshot = _snapshot_clean(snapshot)

    if not _snapshot_has_required_state(snapshot):
        giptv.log(
            "[INDEX_MANAGER] queue snapshot skipped: account not configured/invalid",
            xbmc.LOGINFO,
        )
        return False

    state_key = _state_key_from_snapshot(snapshot)

    allowed, reason = should_build(force=force, state_key=state_key)
    if not allowed:
        giptv.log(
            "[INDEX_MANAGER] queue snapshot skipped: {} | state={} source={}".format(
                reason,
                state_key,
                source,
            ),
            xbmc.LOGINFO,
        )
        return False

    qkey = _queue_key(source=source, force=force, state_key=state_key)

    with _QUEUED_KEYS_LOCK:
        if qkey in _QUEUED_KEYS:
            giptv.log(
                "[INDEX_MANAGER] queue skipped: already queued | state={} source={}".format(
                    state_key,
                    source,
                ),
                xbmc.LOGINFO,
            )
            return False

        _QUEUED_KEYS.add(qkey)

    _ensure_build_worker()

    try:
        _BUILD_QUEUE.put_nowait(
            {
                "queue_key": qkey,
                "monitor": monitor,
                "notify": notify,
                "source": source,
                "force": force,
                "snapshot": snapshot,
                "state_key": state_key,
                # Important for startup/settings all-account builds:
                # account 2 should not abort just because account 1 is active.
                "ignore_active_state_change": True,
            }
        )

        giptv.log(
            "[INDEX_MANAGER] Build queued | state={} source={} force={}".format(
                state_key,
                source,
                force,
            ),
            xbmc.LOGINFO,
        )

        return True

    except Exception as exc:
        _remove_queued_key(qkey)
        giptv.log(
            "[INDEX_MANAGER] Failed to queue build: {}".format(exc),
            xbmc.LOGERROR,
        )
        return False


def queue_build_indexes_for_snapshots(
    snapshots,
    monitor=None,
    notify=False,
    source="startup_all_accounts",
    force=False,
):
    queued = 0
    skipped = 0
    seen = set()

    for snapshot in snapshots or []:
        snapshot = _snapshot_clean(snapshot)

        if not _snapshot_has_required_state(snapshot):
            skipped += 1
            continue

        state_key = _state_key_from_snapshot(snapshot)
        if state_key in seen:
            skipped += 1
            continue

        seen.add(state_key)

        ok = queue_build_index_for_snapshot(
            snapshot=snapshot,
            monitor=monitor,
            notify=notify,
            source=source,
            force=force,
        )

        if ok:
            queued += 1
        else:
            skipped += 1

    giptv.log(
        "[INDEX_MANAGER] queue_build_indexes_for_snapshots done | queued={} skipped={} source={}".format(
            queued,
            skipped,
            source,
        ),
        xbmc.LOGINFO,
    )

    return queued


def queue_build_index(monitor=None, notify=False, source="queued", force=False):
    try:
        ensure_api_ready()
    except Exception as exc:
        giptv.log(
            "[INDEX_MANAGER] queue_build_index ensure_api_ready failed: {}".format(exc),
            xbmc.LOGWARNING,
        )

    snapshot = _current_state_snapshot()

    return queue_build_index_for_snapshot(
        snapshot=snapshot,
        monitor=monitor,
        notify=notify,
        source=source,
        force=force,
    )


def shutdown_index_worker(wait=False, timeout=2.0):
    global _BUILD_WORKER

    with _BUILD_WORKER_LOCK:
        worker = _BUILD_WORKER

        if not worker:
            return

        _BUILD_WORKER_STOP.set()

        try:
            _BUILD_QUEUE.put_nowait(None)
        except Exception:
            pass

    if wait and worker.is_alive():
        try:
            worker.join(timeout)
        except Exception:
            pass

    with _BUILD_WORKER_LOCK:
        _BUILD_WORKER = None


# ============================================================
#  CORE BUILDER
# ============================================================


def build_index(
    monitor=None,
    notify=True,
    source="unknown",
    force=False,
    snapshot=None,
    ignore_active_state_change=False,
):
    global _INDEX_BUILDING

    if snapshot is None:
        try:
            ensure_api_ready()
        except Exception as exc:
            giptv.log(
                "[INDEX_MANAGER] build_index ensure_api_ready failed: {}".format(exc),
                xbmc.LOGWARNING,
            )
        snapshot = _current_state_snapshot()

    snapshot = _snapshot_clean(snapshot)
    build_state_key = _state_key_from_snapshot(snapshot)

    if not _snapshot_has_required_state(snapshot):
        giptv.log(
            "[INDEX_MANAGER] Build skipped: account not configured/invalid | source={}".format(
                source
            ),
            xbmc.LOGWARNING,
        )
        return False

    if _abort_if_state_changed(
        build_state_key,
        ignore_active_state_change=ignore_active_state_change,
    ):
        return False

    allowed, reason = should_build(force=force, state_key=build_state_key)
    if not allowed:
        giptv.log(
            "[INDEX_MANAGER] Skipping build: {} | state={} source={}".format(
                reason,
                build_state_key,
                source,
            ),
            xbmc.LOGINFO,
        )
        return False

    with _INDEX_LOCK:
        if _INDEX_BUILDING:
            giptv.log(
                "[INDEX_MANAGER] Build already running in-process | source={}".format(
                    source
                ),
                xbmc.LOGINFO,
            )
            return False

        _INDEX_BUILDING = True

    acquired = False
    started_at = time.time()

    try:
        if not force and build_in_progress(state_key=build_state_key):
            giptv.log(
                "[INDEX_MANAGER] Skipping build: running state already active | state={} source={}".format(
                    build_state_key,
                    source,
                ),
                xbmc.LOGINFO,
            )
            return False

        acquired = _acquire_index_lock(state_key=build_state_key)
        if not acquired:
            return False

        _write_state(
            {
                "status": "running",
                "started_at": started_at,
                "finished_at": 0,
                "source": source,
                "state_key": build_state_key,
                "server": snapshot.get("server", ""),
                "username": snapshot.get("username", ""),
                "account_suffix": snapshot.get("account_suffix", ""),
            },
            state_key=build_state_key,
        )

        giptv.log(
            "[INDEX_MANAGER] Building index | state={} server={} user={} source={} workers={}".format(
                build_state_key,
                snapshot.get("server", ""),
                snapshot.get("username", ""),
                source,
                _FETCH_WORKERS,
            ),
            xbmc.LOGINFO,
        )

        if _is_abort_requested(monitor):
            return False

        if _abort_if_state_changed(
            build_state_key,
            ignore_active_state_change=ignore_active_state_change,
        ):
            return False

        counts = {}

        for index_name, content_type in (
            ("vod", xtream_api.VOD_TYPE),
            ("series", xtream_api.SERIES_TYPE),
            ("live", xtream_api.LIVE_TYPE),
        ):
            cats = _fetch_category_list(content_type, snapshot)

            if cats is None:
                raise RuntimeError(
                    "category fetch failed for {} / {}".format(
                        index_name,
                        content_type,
                    )
                )

            if _is_abort_requested(monitor):
                return False

            if _abort_if_state_changed(
                build_state_key,
                ignore_active_state_change=ignore_active_state_change,
            ):
                return False

            items = _fetch_categories_parallel(
                content_type,
                cats,
                monitor,
                snapshot,
                build_state_key,
                ignore_active_state_change=ignore_active_state_change,
            )

            del cats

            if items is None:
                return False

            if _abort_if_state_changed(
                build_state_key,
                ignore_active_state_change=ignore_active_state_change,
            ):
                return False

            if not _write_index(index_name, items, state_key=build_state_key):
                return False

            counts[index_name] = len(items)

            del items
            gc.collect()

        finished_at = time.time()

        _write_state(
            {
                "status": "idle",
                "started_at": started_at,
                "finished_at": finished_at,
                "source": source,
                "state_key": build_state_key,
                "server": snapshot.get("server", ""),
                "username": snapshot.get("username", ""),
                "account_suffix": snapshot.get("account_suffix", ""),
                "counts": counts,
            },
            state_key=build_state_key,
        )

        giptv.log(
            "[INDEX_MANAGER] Index build complete in {:.2f}s | state={} vod={} series={} live={} source={}".format(
                finished_at - started_at,
                build_state_key,
                counts.get("vod", 0),
                counts.get("series", 0),
                counts.get("live", 0),
                source,
            ),
            xbmc.LOGINFO,
        )

        if notify:
            try:
                giptv.notification(
                    ADDON.getAddonInfo("name"),
                    "Search index rebuilt",
                    icon="INFO",
                )
            except Exception:
                pass

        return True

    except Exception as exc:
        _write_state(
            {
                "status": "error",
                "started_at": started_at,
                "finished_at": time.time(),
                "source": source,
                "state_key": build_state_key,
                "server": snapshot.get("server", ""),
                "username": snapshot.get("username", ""),
                "account_suffix": snapshot.get("account_suffix", ""),
                "error": str(exc),
            },
            state_key=build_state_key,
        )

        giptv.log(
            "[INDEX_MANAGER] Build failed: {} | state={} source={}".format(
                exc,
                build_state_key,
                source,
            ),
            xbmc.LOGERROR,
        )

        return False

    finally:
        if acquired:
            _release_index_lock(state_key=build_state_key)

        with _INDEX_LOCK:
            _INDEX_BUILDING = False

        gc.collect()


# ============================================================
#  PUBLIC ENTRY POINTS
# ============================================================


def ensure_index(monitor=None):
    try:
        ensure_api_ready()
    except Exception as exc:
        giptv.log(
            "[INDEX_MANAGER] ensure_index ensure_api_ready failed: {}".format(exc),
            xbmc.LOGWARNING,
        )

    snapshot = _current_state_snapshot()

    return queue_build_index_for_snapshot(
        snapshot=snapshot,
        monitor=monitor,
        notify=False,
        source="ensure_index",
        force=False,
    )


def on_settings_changed(monitor=None):
    try:
        ensure_api_ready()
    except Exception as exc:
        giptv.log(
            "[INDEX_MANAGER] on_settings_changed ensure_api_ready failed: {}".format(
                exc
            ),
            xbmc.LOGWARNING,
        )

    try:
        if hasattr(xtream_api, "reset_session"):
            xtream_api.reset_session()
    except Exception:
        pass

    _clear_index_read_cache()

    snapshot = _current_state_snapshot()
    state_key = _state_key_from_snapshot(snapshot)

    giptv.log(
        "[INDEX_MANAGER] Settings changed — evaluating active account rebuild | state={}".format(
            state_key
        ),
        xbmc.LOGINFO,
    )

    return queue_build_index_for_snapshot(
        snapshot=snapshot,
        monitor=monitor,
        notify=False,
        source="settings_changed",
        force=False,
    )


def force_rebuild_index(monitor=None, notify=True, source="manual"):
    return queue_build_index(
        monitor=monitor,
        notify=notify,
        source=source,
        force=True,
    )


def clear_index_files(state_key=None):
    state_key = state_key or _state_key()

    for name in _INDEX_TYPES:
        path = _index_path(name, state_key)
        try:
            if xbmcvfs.exists(path):
                xbmcvfs.delete(path)
        except Exception:
            pass

    try:
        _clear_state(state_key)
    except Exception:
        pass

    try:
        _release_index_lock(state_key)
    except Exception:
        pass

    _clear_index_read_cache(state_key=state_key)

    giptv.log(
        "[INDEX_MANAGER] Cleared index files | state={}".format(state_key),
        xbmc.LOGINFO,
    )
