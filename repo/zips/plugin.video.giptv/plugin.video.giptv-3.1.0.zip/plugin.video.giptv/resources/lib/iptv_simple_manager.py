# -*- coding: utf-8 -*-
"""Own GIPTV's local playlist/guide and its dedicated IPTV Simple instance."""

import hashlib
import json
import os
import re
import threading
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.utils import giptv, settings


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
PVR_ADDON_ID = "pvr.iptvsimple"
INSTANCE_NAME = "GIPTV"
EXPORT_SPECIAL_DIR = "special://profile/addon_data/{}/iptv_simple/".format(ADDON_ID)
PLAYLIST_SPECIAL_PATH = EXPORT_SPECIAL_DIR + "playlist.m3u8"
EPG_SPECIAL_PATH = EXPORT_SPECIAL_DIR + "epg.xml"
STATE_SPECIAL_PATH = EXPORT_SPECIAL_DIR + "sync_state.json"
PVR_PROFILE_SPECIAL_DIR = "special://profile/addon_data/{}/".format(PVR_ADDON_ID)

_SYNC_LOCK = threading.Lock()
_THREAD_LOCK = threading.Lock()
_SYNC_THREAD = None
_PENDING_FORCE_SYNC = False
_PENDING_PVR_RELOAD = False


def is_enabled():
    return str(ADDON.getSetting("iptv_simple.enabled") or "true").lower() == "true"


def _refresh_seconds():
    try:
        hours = int(ADDON.getSetting("iptv_simple.refresh_hours") or "6")
    except (TypeError, ValueError):
        hours = 6
    return max(1, min(24, hours)) * 60 * 60


def _translated(special_path):
    return xbmcvfs.translatePath(special_path)


def _ensure_export_dir():
    path = _translated(EXPORT_SPECIAL_DIR)
    if not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)
    return path


def _atomic_write(path, content):
    """Replace a local export without exposing IPTV Simple to partial content."""
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)
    payload = content.encode("utf-8") if isinstance(content, str) else content
    temp_path = "{}.{}.{}.tmp".format(
        path, os.getpid(), threading.current_thread().ident
    )
    with open(temp_path, "wb") as handle:
        handle.write(payload)
        handle.flush()
    os.replace(temp_path, path)


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _content_hash(content):
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _write_state(last_sync, playlist_hash, epg_hash):
    state = {
        "last_sync": int(last_sync),
        "playlist_sha256": playlist_hash,
        "epg_sha256": epg_hash,
    }
    _atomic_write(
        _translated(STATE_SPECIAL_PATH),
        json.dumps(state, separators=(",", ":")),
    )


def _is_due():
    state = _read_json(_translated(STATE_SPECIAL_PATH))
    try:
        last_sync = int(state.get("last_sync", 0))
    except (TypeError, ValueError):
        last_sync = 0
    return time.time() - last_sync >= _refresh_seconds()


def _json_rpc(method, params=None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        request["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result")
    except Exception:
        return None


def _pvr_details():
    return _json_rpc(
        "Addons.GetAddonDetails",
        {"addonid": PVR_ADDON_ID, "properties": ["enabled"]},
    )


def _ensure_pvr_installed():
    details = _pvr_details()
    if details and details.get("addon"):
        return details["addon"]
    giptv.log("IPTV Simple is missing; requesting automatic installation", xbmc.LOGINFO)
    xbmc.executebuiltin("InstallAddon({})".format(PVR_ADDON_ID), True)
    details = _pvr_details()
    return details.get("addon") if details else None


def _set_addon_enabled(enabled):
    return _json_rpc(
        "Addons.SetAddonEnabled",
        {"addonid": PVR_ADDON_ID, "enabled": bool(enabled)},
    ) is not None


def _kodi_major():
    match = re.match(r"\s*(\d+)", xbmc.getInfoLabel("System.BuildVersion") or "")
    return int(match.group(1)) if match else 20


def _minutes_to_inverse_hours(minutes):
    """Match GIPTV's minute offsets to IPTV Simple's opposite-sign hours."""
    value = -(float(minutes or 0) / 60.0)
    return "{:.4f}".format(value).rstrip("0").rstrip(".") or "0"


def _desired_settings():
    return {
        "kodi_addon_instance_name": INSTANCE_NAME,
        "kodi_addon_instance_enabled": "true",
        "m3uPathType": "0",
        "m3uPath": _translated(PLAYLIST_SPECIAL_PATH),
        "m3uUrl": "",
        "m3uCache": "false",
        # IPTV Simple re-reads the GIPTV-managed local file hourly. GIPTV
        # regenerates it on its own schedule and whenever settings change.
        "m3uRefreshMode": "1",
        "m3uRefreshIntervalMins": "60",
        "epgPathType": "0",
        "epgPath": _translated(EPG_SPECIAL_PATH),
        "epgUrl": "",
        "epgCache": "false",
        "epgTimeShift": _minutes_to_inverse_hours(settings.get_epg_offset(ADDON)),
        "catchupEnabled": "true",
        # Current IPTV Simple UI caps its global value at 15; the per-channel
        # M3U catchup-days tag still carries GIPTV's full configured window.
        "catchupDays": str(min(15, settings.get_catchup_days(ADDON))),
        "allChannelsCatchupMode": "0",
        "catchupCorrection": _minutes_to_inverse_hours(
            settings.get_catchup_offset(ADDON)
        ),
        "catchupOnlyOnFinishedProgrammes": "false",
    }


def _find_instance_file(directory):
    existing_ids = set()
    try:
        names = os.listdir(directory)
    except OSError:
        names = []
    for name in names:
        match = re.match(r"instance-settings-(\d+)\.xml$", name)
        if not match:
            continue
        existing_ids.add(int(match.group(1)))
        path = os.path.join(directory, name)
        try:
            root = ET.parse(path).getroot()
            for node in root.findall("setting"):
                if (
                    node.get("id") == "kodi_addon_instance_name"
                    and (node.text or "") == INSTANCE_NAME
                ):
                    return path
        except Exception:
            continue
    instance_id = 1
    while instance_id in existing_ids:
        instance_id += 1
    return os.path.join(directory, "instance-settings-{}.xml".format(instance_id))


def _configure_instance_settings():
    directory = _translated(PVR_PROFILE_SPECIAL_DIR)
    if not os.path.isdir(directory):
        os.makedirs(directory, exist_ok=True)
    path = _find_instance_file(directory)
    try:
        root = ET.parse(path).getroot()
    except Exception:
        root = ET.Element("settings", {"version": "2"})
    if root.tag != "settings":
        root = ET.Element("settings", {"version": "2"})
    root.set("version", "2")

    changed = not os.path.exists(path)
    nodes = {node.get("id"): node for node in root.findall("setting")}
    for setting_id, value in _desired_settings().items():
        node = nodes.get(setting_id)
        if node is None:
            node = ET.SubElement(root, "setting", {"id": setting_id})
            changed = True
        if (node.text or "") != value:
            node.text = value
            changed = True
        if setting_id == "kodi_addon_instance_enabled":
            node.set("default", "true")

    if changed:
        xml = ET.tostring(root, encoding="utf-8", xml_declaration=True)
        _atomic_write(path, xml)
    return changed


def _configure_legacy_settings():
    desired = _desired_settings()
    desired.pop("kodi_addon_instance_name", None)
    desired.pop("kodi_addon_instance_enabled", None)
    pvr = xbmcaddon.Addon(PVR_ADDON_ID)
    changed = False
    for setting_id, value in desired.items():
        if pvr.getSetting(setting_id) != value:
            pvr.setSetting(setting_id, value)
            changed = True
    return changed


def _playing_media():
    return xbmc.getCondVisibility("Player.HasMedia")


def _reload_pvr_when_safe():
    global _PENDING_PVR_RELOAD
    if not _PENDING_PVR_RELOAD or _playing_media():
        return False
    _set_addon_enabled(False)
    xbmc.sleep(250)
    _set_addon_enabled(True)
    _PENDING_PVR_RELOAD = False
    giptv.log("IPTV Simple reloaded with the GIPTV instance", xbmc.LOGINFO)
    return True


def _ensure_pvr_configuration():
    """Install, configure and enable the managed instance when available."""
    global _PENDING_PVR_RELOAD
    pvr = _ensure_pvr_installed()
    if not pvr:
        return False
    changed = (
        _configure_instance_settings()
        if _kodi_major() >= 20
        else _configure_legacy_settings()
    )
    if not pvr.get("enabled"):
        _set_addon_enabled(True)
        # Enabling loads both the instance file and current local exports.
        _PENDING_PVR_RELOAD = False
    elif changed:
        _PENDING_PVR_RELOAD = True
    _reload_pvr_when_safe()
    return True


def sync_now(force=False, notify=False):
    """Regenerate local files and configure IPTV Simple. Safe to call manually."""
    global _PENDING_PVR_RELOAD
    if not is_enabled():
        return False
    with _SYNC_LOCK:
        if not force and not _is_due():
            _ensure_pvr_configuration()
            _reload_pvr_when_safe()
            return True
        try:
            from resources.lib.iptv_integration import build_m3u, get_xmltv_text
            from resources.utils.config import ensure_api_ready

            if not ensure_api_ready():
                raise RuntimeError("IPTV account is not configured")
            _ensure_export_dir()
            playlist = build_m3u(use_direct=True)
            epg = get_xmltv_text()
            if not isinstance(epg, str):
                epg = epg.decode("utf-8", errors="ignore")

            previous = _read_json(_translated(STATE_SPECIAL_PATH))
            playlist_hash = _content_hash(playlist)
            epg_hash = _content_hash(epg)
            playlist_changed = (
                previous.get("playlist_sha256") != playlist_hash
                or not os.path.exists(_translated(PLAYLIST_SPECIAL_PATH))
            )
            epg_changed = (
                previous.get("epg_sha256") != epg_hash
                or not os.path.exists(_translated(EPG_SPECIAL_PATH))
            )
            if playlist_changed:
                _atomic_write(_translated(PLAYLIST_SPECIAL_PATH), playlist)
            if epg_changed:
                _atomic_write(_translated(EPG_SPECIAL_PATH), epg)

            if playlist_changed or epg_changed:
                _PENDING_PVR_RELOAD = True
            _ensure_pvr_configuration()

            _write_state(time.time(), playlist_hash, epg_hash)
            giptv.log(
                "IPTV Simple export updated: {} channels file={} epg={}".format(
                    max(0, playlist.count("#EXTINF:")),
                    _translated(PLAYLIST_SPECIAL_PATH),
                    _translated(EPG_SPECIAL_PATH),
                ),
                xbmc.LOGINFO,
            )
            if notify:
                giptv.notification(
                    ADDON.getAddonInfo("name"),
                    "IPTV Simple playlist and guide synced",
                    icon="INFO",
                )
            return True
        except Exception as exc:
            giptv.log("IPTV Simple sync failed: {}".format(exc), xbmc.LOGERROR)
            if notify:
                xbmcgui.Dialog().notification(
                    ADDON.getAddonInfo("name"),
                    "IPTV Simple sync failed: {}".format(exc),
                    xbmcgui.NOTIFICATION_ERROR,
                )
            return False


def _sync_worker(initial_force):
    global _SYNC_THREAD, _PENDING_FORCE_SYNC
    force = initial_force
    while True:
        sync_now(force=force, notify=False)
        with _THREAD_LOCK:
            if _PENDING_FORCE_SYNC:
                _PENDING_FORCE_SYNC = False
                force = True
                continue
            _SYNC_THREAD = None
            return


def request_sync(force=False):
    """Queue a non-blocking sync without losing changes during an active run."""
    global _SYNC_THREAD, _PENDING_FORCE_SYNC
    if not is_enabled():
        return False
    with _THREAD_LOCK:
        if _SYNC_THREAD is not None and _SYNC_THREAD.is_alive():
            _PENDING_FORCE_SYNC = _PENDING_FORCE_SYNC or bool(force)
            return True
        _PENDING_FORCE_SYNC = False
        _SYNC_THREAD = threading.Thread(
            target=_sync_worker,
            args=(bool(force),),
            name="giptv-iptv-simple-sync",
        )
        _SYNC_THREAD.daemon = True
        _SYNC_THREAD.start()
    return True


def maintenance():
    """Called cheaply by the service loop; expensive work runs in a worker."""
    _reload_pvr_when_safe()
    # Even between exports this inexpensive pass completes a delayed binary
    # add-on installation and applies the managed instance configuration.
    request_sync(force=False)
