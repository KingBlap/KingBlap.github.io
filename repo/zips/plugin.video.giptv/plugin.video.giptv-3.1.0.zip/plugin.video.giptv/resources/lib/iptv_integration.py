# -*- coding: utf-8 -*-
"""Shared local playlist/XMLTV export for IPTV Simple and IPTV Merge."""

import base64
import json

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

import xbmcaddon
import xbmcvfs

from resources.apis import xtream_api
from resources.apis.xmltv_fetcher import fetch_xmltv
from resources.utils import settings

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


def _escape_m3u(value):
    return (
        str(value or "")
        .replace('"', "'")
        .replace("\r", " ")
        .replace("\n", " ")
        .strip()
    )


def _category_map():
    hidden = settings.get_hidden_groups(ADDON, "live")
    categories = xtream_api.categories("live") or []
    return {
        str(category.get("category_id", "")): category.get("category_name", "Other")
        for category in categories
        if str(category.get("category_id", "")) not in hidden
    }


def get_live_channels():
    categories = _category_map()
    if not categories:
        return []
    channels = []
    for stream in xtream_api.get_all_live_streams_unfiltered():
        category_id = str(stream.get("category_id", ""))
        if category_id not in categories:
            continue
        stream_id = str(stream.get("stream_id") or "")
        name = stream.get("name") or stream.get("title") or ""
        if not stream_id or not name:
            continue
        ext = stream.get("container_extension", "ts")
        selected_format = settings.get_stream_format(ADDON)
        if selected_format in ("ts", "m3u8"):
            ext = selected_format
        direct_url = xtream_api.build_stream_url(stream_id, "live", ext)
        if not direct_url:
            continue
        epg_id = str(stream.get("epg_channel_id") or stream.get("tvg_id") or "")
        metadata = {
            "stream_type": "live",
            "stream_id": stream_id,
            "channel_id": epg_id,
            "thumb": stream.get("stream_icon") or "",
            "icon": stream.get("stream_icon") or "",
        }
        encoded_meta = base64.urlsafe_b64encode(
            json.dumps(metadata, separators=(",", ":")).encode("utf-8")
        ).decode("ascii")
        plugin_stream = "plugin://{}/?{}".format(
            ADDON_ID,
            urlencode(
                {
                    "mode": "play_stream",
                    "url": direct_url,
                    "name": name,
                    "meta": encoded_meta,
                }
            ),
        )
        channels.append(
            {
                "id": "giptv:{}".format(stream_id),
                "epg_id": epg_id,
                "stream_id": stream_id,
                "name": name,
                "logo": stream.get("stream_icon") or "",
                "group": categories[category_id],
                "stream": plugin_stream,
                "direct_url": direct_url,
                "has_archive": str(
                    stream.get("tv_archive", stream.get("has_archive", "0"))
                )
                == "1",
            }
        )
    return channels


def _catchup_source(channel):
    """Build IPTV Simple's Xtream catch-up URL template for one channel."""
    direct_url = str(channel.get("direct_url") or "")
    extension = "ts"
    if "." in direct_url.rsplit("/", 1)[-1]:
        extension = direct_url.rsplit(".", 1)[-1].split("?", 1)[0] or "ts"
    return "{}/timeshift/{}/{}/{{duration:60}}/{{Y}}-{{m}}-{{d}}:{{H}}-{{M}}/{}.{}".format(
        xtream_api.STATE.server.rstrip("/"),
        xtream_api.STATE.username,
        xtream_api.STATE.password,
        channel["stream_id"],
        extension,
    )


def build_m3u(use_direct=False):
    """Build a playlist; local PVR exports use direct URLs for lower overhead."""
    lines = ["#EXTM3U"]
    for channel in get_live_channels():
        attrs = [
            'tvg-id="{}"'.format(_escape_m3u(channel["epg_id"] or channel["id"])),
            'tvg-name="{}"'.format(_escape_m3u(channel["name"])),
            'tvg-logo="{}"'.format(_escape_m3u(channel["logo"])),
            'group-title="{}"'.format(_escape_m3u(channel["group"])),
        ]
        if channel["has_archive"]:
            attrs.extend(
                [
                    'catchup="default"',
                    'catchup-days="{}"'.format(settings.get_catchup_days(ADDON)),
                    'catchup-source="{}"'.format(
                        _escape_m3u(_catchup_source(channel))
                    ),
                ]
            )
        lines.append(
            "#EXTINF:-1 {},{}".format(
                " ".join(attrs), _escape_m3u(channel["name"])
            )
        )
        lines.append(channel["direct_url"] if use_direct else channel["stream"])
    return "\n".join(lines) + "\n"


def get_xmltv_text():
    path = fetch_xmltv()
    if not path:
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><tv/>"
    handle = xbmcvfs.File(path, "r")
    try:
        return handle.read()
    finally:
        handle.close()

