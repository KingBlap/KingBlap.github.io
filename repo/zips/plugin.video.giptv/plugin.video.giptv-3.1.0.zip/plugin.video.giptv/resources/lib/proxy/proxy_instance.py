import threading
import xbmc
import xbmcaddon

from resources.utils import settings, giptv
from resources.lib.proxy.proxy_server import IPTVStreamProxy

ADDON = xbmcaddon.Addon()

_proxy = None
_port = None
_lock = threading.Lock()


def ensure_proxy_running():
    global _proxy, _port

    current_buffer = settings.get_buffer_size(ADDON)

    with _lock:
        if _proxy is None:
            giptv.log("[GIPTV] [PROXY_INSTANCE] starting proxy", xbmc.LOGINFO)
            _proxy = IPTVStreamProxy(ADDON, host="127.0.0.1", port=0)
            _proxy._last_buffer = current_buffer
            _port = _proxy.start()
            return _port

        # Do not restart during normal playback unless you are certain
        # the running proxy cannot adapt dynamically.
        if getattr(_proxy, "_last_buffer", None) != current_buffer:
            giptv.log(
                "[GIPTV] [PROXY_INSTANCE] buffer changed but keeping current proxy alive",
                xbmc.LOGINFO,
            )
            _proxy._last_buffer = current_buffer

        return _port


def stop_proxy():
    global _proxy, _port

    with _lock:
        if _proxy is not None:
            try:
                xbmc.log("[GIPTV] [PROXY_INSTANCE] stopping proxy", xbmc.LOGINFO)
                _proxy.stop()
            except Exception:
                pass
            _proxy = None
            _port = None
