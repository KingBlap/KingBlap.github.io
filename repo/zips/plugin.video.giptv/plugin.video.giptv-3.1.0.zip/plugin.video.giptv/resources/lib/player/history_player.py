# -*- coding: utf-8 -*-
import json
import time

import xbmc
import xbmcaddon
import xbmcvfs

import resources.utils.giptv as giptv
import resources.lib.navigator as navigator

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

PENDING_PLAYBACK_PATH = xbmcvfs.translatePath(
    "special://profile/addon_data/{}/pending_playback.json".format(ADDON_ID)
)


def _read_pending():
    if not xbmcvfs.exists(PENDING_PLAYBACK_PATH):
        return {}

    try:
        f = xbmcvfs.File(PENDING_PLAYBACK_PATH, "r")
        try:
            raw = f.read()
        finally:
            f.close()

        return json.loads(raw or "{}")
    except Exception as e:
        giptv.log(
            f"[HISTORY PLAYER] Failed to read pending playback: {e}", xbmc.LOGWARNING
        )
        return {}


def _write_pending(data):
    try:
        f = xbmcvfs.File(PENDING_PLAYBACK_PATH, "w")
        try:
            f.write(json.dumps(data or {}))
        finally:
            f.close()
    except Exception as e:
        giptv.log(
            f"[HISTORY PLAYER] Failed to write pending playback: {e}", xbmc.LOGWARNING
        )


def clear_pending():
    _write_pending({})


def set_pending_playback(data):
    _write_pending(data)


class HistoryPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._started = False
        self._av_started = False
        self._start_ts = 0

    def onPlayBackStarted(self):
        self._started = True
        self._start_ts = int(time.time())
        giptv.log("[HISTORY PLAYER] Playback started", xbmc.LOGINFO)

    def onAVStarted(self):
        self._av_started = True
        giptv.log("[HISTORY PLAYER] AV started", xbmc.LOGINFO)

    def onPlayBackEnded(self):
        giptv.log("[HISTORY PLAYER] Playback ended", xbmc.LOGINFO)
        self._commit_history("ended")

    def onPlayBackStopped(self):
        giptv.log("[HISTORY PLAYER] Playback stopped", xbmc.LOGINFO)
        self._commit_history("stopped")

    def _commit_history(self, reason):
        try:
            pending = _read_pending()
            if not pending:
                giptv.log("[HISTORY PLAYER] No pending playback found", xbmc.LOGINFO)
                self._reset_state()
                return

            try:
                playing_file = self.getPlayingFile() or ""
            except Exception:
                playing_file = ""

            play_url = pending.get("play_url") or ""
            stream_type = str(pending.get("stream_type") or "").strip().lower()

            if playing_file and play_url:
                if play_url not in playing_file and playing_file not in play_url:
                    giptv.log(
                        "[HISTORY PLAYER] Playing file mismatch, using pending metadata anyway",
                        xbmc.LOGWARNING,
                    )

            watched_seconds = 0
            try:
                watched_seconds = int(float(self.getTime() or 0))
            except Exception:
                watched_seconds = 0

            wall_seconds = 0
            try:
                if self._start_ts:
                    wall_seconds = max(0, int(time.time()) - int(self._start_ts))
            except Exception:
                wall_seconds = 0

            effective_seconds = max(watched_seconds, wall_seconds)

            giptv.log(
                "[HISTORY PLAYER] Commit check "
                f"reason={reason} type={stream_type} "
                f"watched_seconds={watched_seconds} wall_seconds={wall_seconds} "
                f"effective_seconds={effective_seconds}",
                xbmc.LOGINFO,
            )

            # only skip truly accidental opens
            if stream_type != "live" and effective_seconds < 2:
                giptv.log(
                    f"[HISTORY PLAYER] Skip history write, effective_seconds={effective_seconds}",
                    xbmc.LOGINFO,
                )
                clear_pending()
                self._reset_state()
                return

            navigator.add_history_item(
                item_id=str(pending.get("stream_id") or pending.get("item_id") or ""),
                title=pending.get("title") or pending.get("name") or "Unknown",
                stream_type=stream_type,
                thumb=pending.get("thumb", ""),
                fanart=pending.get("fanart", ""),
                poster=pending.get("poster", ""),
                icon=pending.get("icon", ""),
                plot=pending.get("plot", ""),
                rating=pending.get("rating", 0),
                year=pending.get("year", 0),
                tmdb_id=pending.get("tmdb_id", ""),
                channel_id=pending.get("channel_id", ""),
                play_url=play_url,
                resume_time=effective_seconds,
                stream_id=str(pending.get("stream_id") or ""),
                is_live_epg=(stream_type == "live"),
                season=pending.get("season", ""),
                episode=pending.get("episode", ""),
                series_id=pending.get("series_id", ""),
                series_name=pending.get("series_name", ""),
            )

            giptv.log(
                f"[HISTORY PLAYER] History committed reason={reason} "
                f"title={pending.get('title') or pending.get('name')} "
                f"type={stream_type} seconds={effective_seconds}",
                xbmc.LOGINFO,
            )

        except Exception as e:
            giptv.log(f"[HISTORY PLAYER] Failed to commit history: {e}", xbmc.LOGERROR)
        finally:
            clear_pending()
            self._reset_state()

    def _reset_state(self):
        self._started = False
        self._av_started = False
        self._start_ts = 0
