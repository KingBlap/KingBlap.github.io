# -*- coding: utf-8 -*-
try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import base64
import json
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

from resources.apis import trakt_api
from resources.utils import giptv

_PLAYBACK_PROP = "giptv.trakt.playback"

_COMPLETE_PROGRESS = 95.0
_AUTOPLAY_TRIGGER_SECONDS = 45
_AUTOPLAY_TRIGGER_PROGRESS = 97.5
_SAMPLE_INTERVAL = 5.0

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")


# ============================================================
#  BASIC HELPERS
# ============================================================


def _safe_float(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return default


def _safe_int(value, default=0):
    try:
        return int(float(value))
    except Exception:
        return default


def _set_playback_data(data):
    try:
        xbmcgui.Window(10000).setProperty(_PLAYBACK_PROP, json.dumps(data or {}))
    except Exception:
        pass


def get_current_playback():
    try:
        raw = xbmcgui.Window(10000).getProperty(_PLAYBACK_PROP)
        return json.loads(raw) if raw else {}
    except Exception:
        return {}


def set_current_playback(metadata):
    meta = metadata or {}

    data = {
        "started": False,
        "last_action": None,
        "resume_applied": False,
        "stop_handled": False,
        # Next episode / Up Next state.
        "next_autoplay_triggered": False,
        "next_autoplay_pending": False,
        "autoplay_countdown_started": False,
        "upnext_countdown_finished": False,
        "upnext_countdown_started_at": 0.0,
        "upnext_countdown_seconds": 0,
        # Up Next notification state.
        "upnext_sent": False,
        "upnext_complete_sent": False,
        "upnext_near_end_sent": False,
        # Completion state.
        "complete_handled": False,
        # Last known playback state.
        "last_known_time": 0.0,
        "last_known_total": 0.0,
        "last_known_progress": 0.0,
    }

    data.update(meta)
    _set_playback_data(data)


def clear_current_playback():
    try:
        xbmcgui.Window(10000).clearProperty(_PLAYBACK_PROP)
    except Exception:
        pass


def _update_current_playback(**updates):
    data = get_current_playback() or {}
    data.update(updates)
    _set_playback_data(data)


# ============================================================
#  UP NEXT HELPERS
# ============================================================


def _is_upnext_available():
    try:
        return xbmc.getCondVisibility("System.HasAddon(service.upnext)") == 1
    except Exception:
        return False


def _decode_meta(meta_value):
    if not meta_value:
        return {}

    try:
        padded = meta_value + "=" * (-len(meta_value) % 4)
        raw = base64.urlsafe_b64decode(padded.encode("utf-8")).decode("utf-8")
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception as e:
        giptv.log("[UP NEXT] failed to decode meta: {}".format(e), xbmc.LOGWARNING)
        return {}


def _encode_upnext_data(data):
    """
    service.upnext expects notification data as a list-like encoded payload.
    Sending a raw dict can cause KeyError: 0 inside service.upnext.
    """
    try:
        raw = json.dumps(data or {}, ensure_ascii=False)
        encoded = base64.b64encode(raw.encode("utf-8")).decode("utf-8")
        return [encoded]
    except Exception as e:
        giptv.log("[UP NEXT] failed to encode data: {}".format(e), xbmc.LOGWARNING)
        return None


def _send_jsonrpc_notify_all(sender, message, data):
    try:
        payload = {
            "jsonrpc": "2.0",
            "method": "JSONRPC.NotifyAll",
            "params": {
                "sender": sender,
                "message": message,
                "data": data,
            },
            "id": 1,
        }

        raw = json.dumps(payload)
        result = xbmc.executeJSONRPC(raw)

        giptv.log(
            "[UP NEXT] JSONRPC.NotifyAll result={}".format(result),
            xbmc.LOGDEBUG,
        )

        return True

    except Exception as e:
        giptv.log("[UP NEXT] JSONRPC.NotifyAll failed: {}".format(e), xbmc.LOGWARNING)
        return False


def _build_plugin_play_url(payload):
    payload = payload or {}

    return "plugin://{}/?mode=play_stream&url={}&name={}&meta={}".format(
        ADDON_ID,
        urlparse.quote(str(payload.get("play_url") or ""), safe=""),
        urlparse.quote(str(payload.get("title") or ""), safe=""),
        urlparse.quote(str(payload.get("meta") or ""), safe=""),
    )


def _upnext_episode_dict(meta, fallback_title=""):
    meta = meta or {}

    title = (
        str(meta.get("title") or "").strip()
        or str(meta.get("name") or "").strip()
        or str(fallback_title or "").strip()
    )

    show_title = (
        str(meta.get("series_name") or "").strip()
        or str(meta.get("showtitle") or "").strip()
        or title
    )

    season = _safe_int(meta.get("season"), 0)
    episode = _safe_int(meta.get("episode"), 0)

    thumb = (
        meta.get("thumb")
        or meta.get("poster")
        or meta.get("fanart")
        or meta.get("icon")
        or ""
    )

    return {
        "episodeid": _safe_int(meta.get("stream_id"), 0),
        "tvshowid": _safe_int(meta.get("series_id"), 0),
        "title": title,
        "showtitle": show_title,
        "season": season,
        "episode": episode,
        "plot": meta.get("plot") or "",
        "art": {
            "thumb": thumb,
            "poster": meta.get("poster") or thumb,
            "fanart": meta.get("fanart") or thumb,
            "icon": meta.get("icon") or thumb,
        },
        "rating": _safe_float(meta.get("rating"), 0.0),
        "year": _safe_int(meta.get("year"), 0),
        "tmdb_id": str(meta.get("tmdb_id") or ""),
        "play_url": str(meta.get("play_url") or ""),
    }


def _send_upnext_signal(
    meta,
    force=False,
    near_end=False,
    complete=False,
    countdown_seconds=None,
):
    """
    Sends visual Up Next data to service.upnext.

    Important:
      - This is decoration only.
      - GIPTV internal autoplay remains the source of truth.
      - If service.upnext is missing/broken, autoplay still works.
    """
    meta = meta or {}

    if not force:
        if complete and meta.get("upnext_complete_sent"):
            return False
        if near_end and meta.get("upnext_near_end_sent"):
            return False
        if meta.get("upnext_sent"):
            return False

    if str(meta.get("stream_type") or "").strip().lower() != "series":
        return False

    if not _is_upnext_available():
        giptv.log("[UP NEXT] service.upnext not available", xbmc.LOGDEBUG)
        return False

    payload = _get_next_episode_payload(meta)
    if not payload:
        return False

    next_meta = _decode_meta(payload.get("meta") or "")
    next_meta.update(
        {
            "title": payload.get("title", ""),
            "name": payload.get("title", ""),
            "play_url": payload.get("play_url", ""),
        }
    )

    if not next_meta.get("series_name") and meta.get("series_name"):
        next_meta["series_name"] = meta.get("series_name")

    plugin_url = _build_plugin_play_url(payload)

    countdown = _safe_int(
        countdown_seconds
        if countdown_seconds is not None
        else meta.get("upnext_countdown_seconds"),
        _AUTOPLAY_TRIGGER_SECONDS,
    )

    if countdown <= 0:
        countdown = _AUTOPLAY_TRIGGER_SECONDS

    data = {
        "current_episode": _upnext_episode_dict(meta),
        "next_episode": _upnext_episode_dict(next_meta, payload.get("title", "")),
        "play_url": plugin_url,
        "play_info": {
            "mode": "play_stream",
            "url": payload.get("play_url", ""),
            "name": payload.get("title", ""),
            "meta": payload.get("meta", ""),
        },
        "notification_time": countdown,
    }

    encoded_data = _encode_upnext_data(data)
    if not encoded_data:
        return False

    ok = _send_jsonrpc_notify_all(
        sender="{}.SIGNAL".format(ADDON_ID),
        message="upnext_data",
        data=encoded_data,
    )

    if ok:
        updates = {"upnext_sent": True}

        if near_end:
            updates["upnext_near_end_sent"] = True

        if complete:
            updates["upnext_complete_sent"] = True

        _update_current_playback(**updates)

        giptv.log(
            "[UP NEXT] signal sent{}{} countdown={} current=S{}E{} next=S{}E{} title={}".format(
                " complete" if complete else "",
                " near_end" if near_end else "",
                countdown,
                data["current_episode"].get("season"),
                data["current_episode"].get("episode"),
                data["next_episode"].get("season"),
                data["next_episode"].get("episode"),
                data["next_episode"].get("title"),
            ),
            xbmc.LOGINFO,
        )

    return ok


# ============================================================
#  TRAKT / PLAYBACK HELPERS
# ============================================================


def stop_and_clear_current_playback(reason="manual_clear"):
    meta = get_current_playback() or {}

    if not meta:
        clear_current_playback()
        return

    try:
        started = bool(meta.get("started"))
        progress = _safe_float(meta.get("last_known_progress"), 0.0)
        current_time = _safe_float(meta.get("last_known_time"), 0.0)
        total_time = _safe_float(meta.get("last_known_total"), 0.0)

        giptv.log(
            "[TRAKT SCROBBLER] force stop reason={} progress={} "
            "current={} total={} stream_type={} tmdb_id={}".format(
                reason,
                progress,
                current_time,
                total_time,
                meta.get("stream_type"),
                meta.get("tmdb_id"),
            ),
            xbmc.LOGINFO,
        )

        if progress >= _COMPLETE_PROGRESS:
            _mark_watched_from_meta(meta, progress)
        else:
            if progress >= 1.0:
                _save_resume_point(
                    player=None,
                    force_progress=progress,
                    force_seconds=current_time,
                    force_total=total_time,
                )

            if started and progress >= 0.5:
                _scrobble_from_meta(meta, "stop", progress)

    except Exception as e:
        giptv.log("[TRAKT SCROBBLER] force stop failed: {}".format(e), xbmc.LOGWARNING)

    clear_current_playback()


def _get_time_pair(player):
    try:
        current = float(player.getTime())
    except Exception:
        current = 0.0

    try:
        total = float(player.getTotalTime())
    except Exception:
        total = 0.0

    return current, total


def _get_progress(player):
    try:
        current, total = _get_time_pair(player)

        if total <= 0 or current <= 0:
            return 0.0

        return max(0.0, min(100.0, (current / total) * 100.0))
    except Exception:
        return 0.0


def _calculate_progress(current_time, total_time):
    current_time = _safe_float(current_time, 0.0)
    total_time = _safe_float(total_time, 0.0)

    if total_time <= 0 or current_time <= 0:
        return 0.0

    return max(0.0, min(100.0, (current_time / total_time) * 100.0))


def _calculate_resume_seconds_from_progress(total_time, resume_progress):
    total_time = _safe_float(total_time, 0.0)
    resume_progress = _safe_float(resume_progress, 0.0)

    if total_time <= 0 or resume_progress <= 0.0:
        return 0

    return int((resume_progress / 100.0) * total_time)


def _scrobble_from_meta(meta, action, progress):
    stream_type = meta.get("stream_type")
    tmdb_id = meta.get("tmdb_id")
    season = meta.get("season")
    episode = meta.get("episode")
    progress = _safe_float(progress, 0.0)

    giptv.log(
        "[TRAKT SCROBBLE] action={} stream_type={} tmdb_id={} season={} episode={} progress={}".format(
            action,
            stream_type,
            tmdb_id,
            season,
            episode,
            progress,
        ),
        xbmc.LOGINFO,
    )

    if not tmdb_id:
        return False

    if stream_type == "vod":
        return trakt_api.trakt_scrobble_movie(action, tmdb_id, progress)

    if stream_type == "series":
        return trakt_api.trakt_scrobble_episode(
            action,
            tmdb_id,
            season,
            episode,
            progress,
        )

    return False


def _scrobble(action, progress):
    meta = get_current_playback() or {}
    return _scrobble_from_meta(meta, action, progress)


def _save_resume_point(
    player=None,
    force_progress=None,
    force_seconds=None,
    force_total=None,
):
    meta = get_current_playback() or {}
    stream_type = meta.get("stream_type")
    tmdb_id = meta.get("tmdb_id")
    season = meta.get("season")
    episode = meta.get("episode")

    if not tmdb_id:
        return False

    current_time = 0.0
    total_time = 0.0
    progress = 0.0

    if player is not None:
        current_time, total_time = _get_time_pair(player)
        progress = _get_progress(player)

    if force_seconds is not None:
        current_time = _safe_float(force_seconds, current_time)

    if force_total is not None:
        total_time = _safe_float(force_total, total_time)

    if current_time <= 0:
        current_time = _safe_float(meta.get("last_known_time"), 0.0)

    if total_time <= 0:
        total_time = _safe_float(meta.get("last_known_total"), 0.0)

    if force_progress is not None:
        progress = _safe_float(force_progress, progress)

    if progress <= 0.0 and total_time > 0 and current_time > 0:
        progress = _calculate_progress(current_time, total_time)

    progress = max(0.0, min(100.0, _safe_float(progress, 0.0)))

    _update_current_playback(
        last_known_time=current_time,
        last_known_total=total_time,
        last_known_progress=progress,
    )

    giptv.log(
        "[TRAKT RESUME SAVE] current={} total={} progress={}".format(
            current_time,
            total_time,
            progress,
        ),
        xbmc.LOGINFO,
    )

    if current_time < 30 and progress < 1.0:
        return False

    if total_time <= 0 or current_time <= 0:
        return False

    if progress < 1.0:
        return False

    if progress >= _COMPLETE_PROGRESS:
        return False

    if stream_type == "vod":
        return trakt_api.trakt_save_movie_progress(
            tmdb_id,
            progress,
            current_time=current_time,
            total_time=total_time,
        )

    if stream_type == "series" and season and episode:
        return trakt_api.trakt_save_episode_progress(
            tmdb_id,
            season,
            episode,
            progress,
            current_time=current_time,
            total_time=total_time,
        )

    return False


def _clear_resume_point(meta):
    stream_type = meta.get("stream_type")
    tmdb_id = meta.get("tmdb_id")
    season = meta.get("season")
    episode = meta.get("episode")

    if not tmdb_id:
        return False

    if stream_type == "vod":
        return trakt_api.trakt_clear_movie_playback(tmdb_id)

    if stream_type == "series" and season and episode:
        return trakt_api.trakt_clear_episode_playback(tmdb_id, season, episode)

    return False


def _mark_watched_from_meta(meta, progress):
    meta = meta or {}

    if meta.get("complete_handled"):
        return True

    stream_type = meta.get("stream_type")
    tmdb_id = meta.get("tmdb_id")
    season = meta.get("season")
    episode = meta.get("episode")
    progress = _safe_float(progress, 0.0)

    if progress < _COMPLETE_PROGRESS:
        return False

    if not tmdb_id:
        return False

    _update_current_playback(
        last_known_progress=progress,
        complete_handled=True,
    )

    giptv.log(
        "[TRAKT COMPLETE] stream_type={} tmdb_id={} season={} episode={} progress={}".format(
            stream_type,
            tmdb_id,
            season,
            episode,
            progress,
        ),
        xbmc.LOGINFO,
    )

    if meta.get("started"):
        _scrobble_from_meta(meta, "stop", progress)

    ok = False

    if stream_type == "vod":
        ok = trakt_api.trakt_mark_movie_watched(tmdb_id)

    elif stream_type == "series" and season and episode:
        ok = trakt_api.trakt_mark_episode_watched(tmdb_id, season, episode)

    if ok:
        _clear_resume_point(meta)
        giptv.log("[TRAKT COMPLETE] mark watched success", xbmc.LOGINFO)
    else:
        giptv.log("[TRAKT COMPLETE] mark watched failed", xbmc.LOGWARNING)

    return ok


def _maybe_mark_complete_near_end(meta, current_time, total_time, progress):
    meta = meta or {}

    if meta.get("complete_handled"):
        return False

    progress = _safe_float(progress, 0.0)
    current_time = _safe_float(current_time, 0.0)
    total_time = _safe_float(total_time, 0.0)

    if progress < _COMPLETE_PROGRESS:
        return False

    remaining = total_time - current_time if total_time > 0 else 0

    giptv.log(
        "[TRAKT COMPLETE NEAR END] progress={} remaining={} stream_type={} tmdb_id={} season={} episode={}".format(
            progress,
            remaining,
            meta.get("stream_type"),
            meta.get("tmdb_id"),
            meta.get("season"),
            meta.get("episode"),
        ),
        xbmc.LOGINFO,
    )

    return _mark_watched_from_meta(meta, progress)


def _finalize_best_known_position(player=None, assume_complete=False):
    meta = get_current_playback() or {}

    current_time = _safe_float(meta.get("last_known_time"), 0.0)
    total_time = _safe_float(meta.get("last_known_total"), 0.0)
    progress = _safe_float(meta.get("last_known_progress"), 0.0)

    if player is not None:
        try:
            fresh_time, fresh_total = _get_time_pair(player)

            if fresh_total > 0:
                if fresh_total > total_time:
                    total_time = fresh_total

                if fresh_time > current_time and fresh_time <= fresh_total + 5:
                    current_time = fresh_time
        except Exception as e:
            giptv.log(
                "[TRAKT FINALIZE] fresh player read ignored: {}".format(e),
                xbmc.LOGWARNING,
            )

    if total_time > 0 and current_time > 0:
        progress = _calculate_progress(current_time, total_time)

    if assume_complete and total_time > 0:
        current_time = max(current_time, total_time - 1)
        progress = max(progress, 100.0)

    progress = max(0.0, min(100.0, _safe_float(progress, 0.0)))

    _update_current_playback(
        last_known_time=current_time,
        last_known_total=total_time,
        last_known_progress=progress,
    )

    return current_time, total_time, progress


def _is_item_watched(meta):
    stream_type = str(meta.get("stream_type") or "").strip().lower()
    tmdb_id = str(meta.get("tmdb_id") or "").strip()
    season = str(meta.get("season") or "").strip()
    episode = str(meta.get("episode") or "").strip()

    if not tmdb_id:
        return False

    try:
        if stream_type == "vod":
            watched_ids = trakt_api.trakt_get_watched_movie_ids() or set()
            return tmdb_id in watched_ids

        if stream_type == "series" and season and episode:
            tv_maps = trakt_api.trakt_get_tv_progress_maps() or {}
            watched_episode_keys_by_show = (
                tv_maps.get("watched_episode_keys_by_show", {}) or {}
            )
            watched_episode_keys = (
                watched_episode_keys_by_show.get(tmdb_id, set()) or set()
            )
            return (season, episode) in watched_episode_keys
    except Exception as e:
        giptv.log("[TRAKT WATCHED CHECK] failed: {}".format(e), xbmc.LOGWARNING)

    return False


# ============================================================
#  NEXT EPISODE HELPERS
# ============================================================


def _get_next_episode_payload(meta):
    """
    First try prebuilt next_episode payload from router.
    If missing, resolve dynamically from navigator.
    """
    meta = meta or {}

    next_ep = meta.get("next_episode") or {}
    if isinstance(next_ep, dict):
        play_url = str(next_ep.get("play_url") or "").strip()
        title = str(next_ep.get("title") or "").strip()
        meta_encoded = str(next_ep.get("meta") or "").strip()

        if play_url and title:
            return {
                "play_url": play_url,
                "title": title,
                "meta": meta_encoded,
            }

    stream_type = str(meta.get("stream_type") or "").strip().lower()
    if stream_type != "series":
        return None

    series_id = str(meta.get("series_id") or "").strip()
    series_name = str(meta.get("series_name") or "").strip()
    season = str(meta.get("season") or "").strip()
    episode = str(meta.get("episode") or "").strip()

    if not series_id or not season or not episode:
        giptv.log(
            "[NEXT EPISODE] cannot resolve dynamically: series_id={} season={} episode={}".format(
                series_id,
                season,
                episode,
            ),
            xbmc.LOGWARNING,
        )
        return None

    try:
        from resources.lib import navigator

        candidate = navigator.play_next_episode_from_item(
            series_id=series_id,
            series_name=series_name,
            season_num=season,
            episode_num=episode,
        )

        if not candidate:
            giptv.log(
                "[NEXT EPISODE] dynamic resolver returned no candidate",
                xbmc.LOGINFO,
            )
            return None

        play_url = str(candidate.get("play_url") or "").strip()
        title = str(candidate.get("title") or "").strip()
        meta_encoded = str(candidate.get("meta") or "").strip()

        if not play_url or not title:
            giptv.log(
                "[NEXT EPISODE] dynamic candidate missing play_url/title",
                xbmc.LOGWARNING,
            )
            return None

        return {
            "play_url": play_url,
            "title": title,
            "meta": meta_encoded,
        }

    except Exception as e:
        giptv.log(
            "[NEXT EPISODE] dynamic resolve failed: {}".format(e), xbmc.LOGWARNING
        )
        return None


def _play_next_episode_from_meta(meta):
    payload = _get_next_episode_payload(meta)
    if not payload:
        giptv.log("[NEXT EPISODE] no payload to autoplay", xbmc.LOGINFO)
        return False

    try:
        plugin_url = _build_plugin_play_url(payload)

        giptv.log(
            "[NEXT EPISODE] autoplay -> {} | url={}".format(
                payload.get("title"),
                plugin_url,
            ),
            xbmc.LOGINFO,
        )

        xbmc.executebuiltin("PlayMedia({})".format(plugin_url))
        return True

    except Exception as e:
        giptv.log("[NEXT EPISODE] autoplay failed: {}".format(e), xbmc.LOGWARNING)
        return False


def _should_trigger_next_autoplay(meta, current_time, total_time, progress):
    meta = meta or {}

    if meta.get("next_autoplay_pending") or meta.get("autoplay_countdown_started"):
        return False

    if ADDON.getSetting("autoplay_next_episode") != "true":
        return False

    if str(meta.get("stream_type") or "").strip().lower() != "series":
        return False

    current_time = _safe_float(current_time, 0.0)
    total_time = _safe_float(total_time, 0.0)
    progress = _safe_float(progress, 0.0)

    if total_time <= 0 or current_time <= 0:
        return False

    remaining = total_time - current_time

    # Show Up Next as soon as the episode reaches the watched threshold.
    # The actual autoplay still waits until real EOF.
    return progress >= _COMPLETE_PROGRESS or (
        remaining <= _AUTOPLAY_TRIGGER_SECONDS or progress >= _AUTOPLAY_TRIGGER_PROGRESS
    )


def _start_upnext_countdown_only(meta, current_time, total_time, progress):
    """
    Starts Up Next countdown but does NOT autoplay.

    Actual autoplay happens only when Kodi fires onPlayBackEnded().
    """
    meta = meta or {}

    if meta.get("autoplay_countdown_started") or meta.get("next_autoplay_pending"):
        return False

    next_payload = _get_next_episode_payload(meta)
    if not next_payload:
        giptv.log("[NEXT EPISODE] countdown not started: no next payload", xbmc.LOGINFO)
        return False

    current_time = _safe_float(current_time, 0.0)
    total_time = _safe_float(total_time, 0.0)
    progress = _safe_float(progress, 0.0)

    remaining = (
        total_time - current_time if total_time > 0 else _AUTOPLAY_TRIGGER_SECONDS
    )

    countdown_seconds = min(
        _AUTOPLAY_TRIGGER_SECONDS,
        max(5, _safe_int(remaining, _AUTOPLAY_TRIGGER_SECONDS)),
    )

    started_at = time.time()

    _update_current_playback(
        next_autoplay_pending=True,
        next_autoplay_triggered=False,
        autoplay_countdown_started=True,
        upnext_countdown_finished=False,
        upnext_countdown_started_at=started_at,
        upnext_countdown_seconds=countdown_seconds,
        next_episode=next_payload,
        last_known_time=current_time,
        last_known_total=total_time,
        last_known_progress=progress,
    )

    meta_for_next = get_current_playback() or meta

    giptv.log(
        "[NEXT EPISODE] countdown started current={} total={} progress={} countdown={}".format(
            current_time,
            total_time,
            progress,
            countdown_seconds,
        ),
        xbmc.LOGINFO,
    )

    try:
        _mark_watched_from_meta(meta_for_next, max(progress, _COMPLETE_PROGRESS))
    except Exception as e:
        giptv.log(
            "[NEXT EPISODE] pre-mark watched failed: {}".format(e),
            xbmc.LOGWARNING,
        )

    try:
        _send_upnext_signal(
            get_current_playback() or meta_for_next,
            force=True,
            complete=True,
            near_end=True,
            countdown_seconds=countdown_seconds,
        )
    except Exception as e:
        giptv.log(
            "[NEXT EPISODE] Up Next signal failed: {}".format(e),
            xbmc.LOGWARNING,
        )

    def _countdown_runner():
        xbmc.sleep(int(countdown_seconds * 1000))

        data = get_current_playback() or {}
        if not data:
            return

        if not data.get("next_autoplay_pending"):
            return

        _update_current_playback(upnext_countdown_finished=True)

        giptv.log(
            "[NEXT EPISODE] countdown finished; waiting for playback end",
            xbmc.LOGINFO,
        )

    t = threading.Thread(
        target=_countdown_runner,
        name="giptv_upnext_countdown",
        daemon=True,
    )
    t.start()

    return True


def _trigger_next_autoplay(meta, current_time, total_time, progress):
    """
    Misleading name kept for compatibility.

    This no longer autoplays immediately.
    It only starts the Up Next countdown.
    """
    if not _should_trigger_next_autoplay(meta, current_time, total_time, progress):
        return False

    return _start_upnext_countdown_only(
        meta,
        current_time,
        total_time,
        progress,
    )


def _wait_for_upnext_countdown_if_needed(meta):
    """
    Called from onPlayBackEnded.

    If EOF happens before the Up Next timer finishes, wait the remainder.
    If the timer already finished, continue immediately.
    """
    meta = meta or {}

    if not meta.get("next_autoplay_pending"):
        return True

    if meta.get("upnext_countdown_finished"):
        return True

    started_at = _safe_float(meta.get("upnext_countdown_started_at"), 0.0)
    countdown_seconds = _safe_float(meta.get("upnext_countdown_seconds"), 0.0)

    if started_at <= 0 or countdown_seconds <= 0:
        return True

    elapsed = time.time() - started_at
    remaining = max(0.0, countdown_seconds - elapsed)

    if remaining > 0:
        giptv.log(
            "[NEXT EPISODE] playback ended before countdown finished; waiting {:.1f}s".format(
                remaining
            ),
            xbmc.LOGINFO,
        )
        xbmc.sleep(int(remaining * 1000))

    return True


# ============================================================
#  PLAYER MONITOR
# ============================================================


class TraktPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._sample_thread = None
        self._sample_stop = threading.Event()

    def _stop_sampler(self):
        try:
            self._sample_stop.set()
        except Exception:
            pass

    def _start_sampler(self):
        self._stop_sampler()
        self._sample_stop = threading.Event()

        def _runner():
            giptv.log("[TRAKT SAMPLER] started", xbmc.LOGINFO)

            while not self._sample_stop.is_set():
                xbmc.sleep(int(_SAMPLE_INTERVAL * 1000))

                if self._sample_stop.is_set():
                    break

                meta = get_current_playback() or {}
                if not meta:
                    continue

                stream_type = str(meta.get("stream_type") or "").strip().lower()
                if stream_type not in ("vod", "series"):
                    continue

                try:
                    if not self.isPlaying():
                        continue
                except Exception:
                    continue

                try:
                    current_time, total_time = _get_time_pair(self)
                    progress = _get_progress(self)

                    if current_time > 0 and total_time > 0:
                        _update_current_playback(
                            last_known_time=current_time,
                            last_known_total=total_time,
                            last_known_progress=progress,
                        )

                        giptv.log(
                            "[TRAKT SAMPLER] current={} total={} progress={}".format(
                                current_time,
                                total_time,
                                progress,
                            ),
                            xbmc.LOGDEBUG,
                        )

                        meta = get_current_playback() or meta

                        if stream_type == "series":
                            if _trigger_next_autoplay(
                                meta,
                                current_time,
                                total_time,
                                progress,
                            ):
                                # Stop noisy sampler logs after countdown begins.
                                # Player callbacks still remain active.
                                break
                        else:
                            _maybe_mark_complete_near_end(
                                meta,
                                current_time,
                                total_time,
                                progress,
                            )

                except Exception as e:
                    giptv.log(
                        "[TRAKT SAMPLER] sample failed: {}".format(e), xbmc.LOGWARNING
                    )

            giptv.log("[TRAKT SAMPLER] stopped", xbmc.LOGINFO)

        self._sample_thread = threading.Thread(
            target=_runner,
            name="giptv_trakt_sampler",
            daemon=True,
        )
        self._sample_thread.start()

    def onAVStarted(self):
        meta = get_current_playback() or {}

        if not meta:
            return

        if _is_item_watched(meta):
            giptv.log(
                "[TRAKT WATCHED RESET] clearing stale resume for watched item "
                "stream_type={} tmdb_id={} season={} episode={}".format(
                    meta.get("stream_type"),
                    meta.get("tmdb_id"),
                    meta.get("season"),
                    meta.get("episode"),
                ),
                xbmc.LOGINFO,
            )

            try:
                _clear_resume_point(meta)
            except Exception as e:
                giptv.log(
                    "[TRAKT WATCHED RESET] clear failed: {}".format(e),
                    xbmc.LOGWARNING,
                )

            _update_current_playback(
                resume_seconds=0,
                resume_progress=0.0,
                resume_applied=True,
                last_known_time=0.0,
                last_known_total=0.0,
                last_known_progress=0.0,
            )
        else:
            resume_applied = bool(meta.get("resume_applied"))
            resume_seconds = int(_safe_float(meta.get("resume_seconds"), 0))
            resume_progress = _safe_float(meta.get("resume_progress"), 0.0)

            if not resume_applied:
                try:
                    total_wait_ms = 0
                    total_time = 0.0

                    while total_wait_ms < 6000:
                        total_time = _safe_float(self.getTotalTime(), 0.0)
                        if total_time > 0:
                            break
                        xbmc.sleep(250)
                        total_wait_ms += 250

                    seek_to = 0

                    if resume_seconds > 0:
                        seek_to = resume_seconds
                    elif resume_progress > 0.0 and total_time > 0:
                        seek_to = _calculate_resume_seconds_from_progress(
                            total_time,
                            resume_progress,
                        )

                    if seek_to > 0:
                        if total_time > 0 and seek_to >= int(total_time) - 10:
                            seek_to = max(0, int(total_time) - 15)

                        self.seekTime(seek_to)

                        calculated_progress = resume_progress
                        if total_time > 0:
                            calculated_progress = _calculate_progress(
                                seek_to,
                                total_time,
                            )

                        _update_current_playback(
                            resume_applied=True,
                            last_known_time=float(seek_to),
                            last_known_total=total_time,
                            last_known_progress=calculated_progress,
                        )

                        giptv.log(
                            "[TRAKT RESUME] seek -> {}s "
                            "(resume_seconds={}, resume_progress={}, total={})".format(
                                seek_to,
                                resume_seconds,
                                resume_progress,
                                total_time,
                            ),
                            xbmc.LOGINFO,
                        )

                except Exception as e:
                    giptv.log(
                        "[TRAKT RESUME] seek failed: {}".format(e), xbmc.LOGWARNING
                    )

        meta = get_current_playback() or meta

        current_time, total_time = _get_time_pair(self)
        progress = _get_progress(self)

        if progress <= 0.0:
            progress = _safe_float(meta.get("last_known_progress"), 0.0)

        if current_time <= 0:
            current_time = _safe_float(meta.get("last_known_time"), 0.0)

        if total_time <= 0:
            total_time = _safe_float(meta.get("last_known_total"), 0.0)

        _update_current_playback(
            last_known_time=current_time,
            last_known_total=total_time,
            last_known_progress=progress,
        )

        self._start_sampler()

        if _scrobble("start", progress):
            _update_current_playback(started=True, last_action="start")

    def onPlayBackPaused(self):
        meta = get_current_playback() or {}

        if not meta:
            return

        current_time, total_time = _get_time_pair(self)
        progress = _get_progress(self)

        if progress <= 0.0:
            progress = _safe_float(meta.get("last_known_progress"), 0.0)

        if current_time <= 0:
            current_time = _safe_float(meta.get("last_known_time"), 0.0)

        if total_time <= 0:
            total_time = _safe_float(meta.get("last_known_total"), 0.0)

        _update_current_playback(
            last_known_time=current_time,
            last_known_total=total_time,
            last_known_progress=progress,
        )

        started = bool(meta.get("started"))

        if progress >= _COMPLETE_PROGRESS:
            _mark_watched_from_meta(meta, progress)
            return

        if started and progress >= 1.0:
            if _scrobble("pause", progress):
                _update_current_playback(last_action="pause")

        _save_resume_point(
            self,
            force_progress=progress,
            force_seconds=current_time,
            force_total=total_time,
        )

    def onPlayBackResumed(self):
        meta = get_current_playback() or {}

        if not meta:
            return

        current_time, total_time = _get_time_pair(self)
        progress = _get_progress(self)

        if progress <= 0.0:
            progress = _safe_float(meta.get("last_known_progress"), 0.0)

        if current_time <= 0:
            current_time = _safe_float(meta.get("last_known_time"), 0.0)

        if total_time <= 0:
            total_time = _safe_float(meta.get("last_known_total"), 0.0)

        _update_current_playback(
            last_known_time=current_time,
            last_known_total=total_time,
            last_known_progress=progress,
        )

        if progress >= 0.5 and progress < _COMPLETE_PROGRESS:
            if _scrobble("start", progress):
                _update_current_playback(started=True, last_action="start")

    def onPlayBackSeek(self, time, seekOffset):
        meta = get_current_playback() or {}

        if not meta:
            return

        try:
            total_time = float(self.getTotalTime())
        except Exception:
            total_time = _safe_float(meta.get("last_known_total"), 0.0)

        seek_time = _safe_float(time, 0.0)

        if total_time > 0 and seek_time > total_time + 30:
            seek_time = seek_time / 1000.0

        progress = _calculate_progress(seek_time, total_time)

        giptv.log(
            "[TRAKT SEEK] raw_time={} seek_time={} total={} progress={}".format(
                time,
                seek_time,
                total_time,
                progress,
            ),
            xbmc.LOGINFO,
        )

        _update_current_playback(
            last_known_time=seek_time,
            last_known_total=total_time,
            last_known_progress=progress,
        )

    def onPlayBackStopped(self):
        self._stop_sampler()

        meta = get_current_playback() or {}

        if not meta:
            clear_current_playback()
            return

        if meta.get("next_autoplay_pending"):
            giptv.log(
                "[NEXT EPISODE] playback stopped while next autoplay pending; clearing because this was not true EOF",
                xbmc.LOGINFO,
            )
            clear_current_playback()
            return

        if meta.get("stop_handled"):
            clear_current_playback()
            return

        _update_current_playback(stop_handled=True)
        meta = get_current_playback() or meta

        current_time, total_time, progress = _finalize_best_known_position(
            player=self,
            assume_complete=False,
        )

        started = bool(meta.get("started"))

        giptv.log(
            "[TRAKT STOPPED] started={} progress={} current={} total={} stream_type={} tmdb_id={}".format(
                started,
                progress,
                current_time,
                total_time,
                meta.get("stream_type"),
                meta.get("tmdb_id"),
            ),
            xbmc.LOGINFO,
        )

        if progress >= _COMPLETE_PROGRESS:
            _mark_watched_from_meta(get_current_playback() or meta, progress)
            clear_current_playback()
            return

        if started and progress >= 0.5:
            _scrobble_from_meta(meta, "stop", progress)

        _save_resume_point(
            player=None,
            force_progress=progress,
            force_seconds=current_time,
            force_total=total_time,
        )

        clear_current_playback()

    def onPlayBackEnded(self):
        self._stop_sampler()

        meta = get_current_playback() or {}

        if not meta:
            clear_current_playback()
            return

        current_time, total_time, progress = _finalize_best_known_position(
            player=self,
            assume_complete=True,
        )

        meta_for_next = get_current_playback() or meta

        giptv.log(
            "[TRAKT ENDED CHECK] current={} total={} progress={} stream_type={} "
            "series_id={} season={} episode={}".format(
                current_time,
                total_time,
                progress,
                meta_for_next.get("stream_type"),
                meta_for_next.get("series_id"),
                meta_for_next.get("season"),
                meta_for_next.get("episode"),
            ),
            xbmc.LOGINFO,
        )

        should_autoplay_next = False

        if progress >= _COMPLETE_PROGRESS:
            ok = _mark_watched_from_meta(meta_for_next, progress)

            should_autoplay_next = bool(
                ok
                and str(meta_for_next.get("stream_type") or "").strip().lower()
                == "series"
                and ADDON.getSetting("autoplay_next_episode") == "true"
            )
        else:
            giptv.log(
                "[TRAKT ENDED IGNORED] progress below complete threshold: {}".format(
                    progress
                ),
                xbmc.LOGWARNING,
            )

            if progress >= 1.0:
                _save_resume_point(
                    player=None,
                    force_progress=progress,
                    force_seconds=current_time,
                    force_total=total_time,
                )

        next_meta = dict(get_current_playback() or meta_for_next or {})

        pending_autoplay = bool(next_meta.get("next_autoplay_pending"))

        # If sampler somehow missed the 95% trigger, start the countdown now.
        if should_autoplay_next and not pending_autoplay:
            started = _start_upnext_countdown_only(
                next_meta,
                current_time,
                total_time,
                progress,
            )
            if started:
                next_meta = dict(get_current_playback() or next_meta or {})
                pending_autoplay = True

        if should_autoplay_next or pending_autoplay:
            _wait_for_upnext_countdown_if_needed(next_meta)

            play_meta = dict(get_current_playback() or next_meta or {})

            clear_current_playback()

            giptv.log(
                "[NEXT EPISODE] playback ended and countdown finished; autoplaying next",
                xbmc.LOGINFO,
            )

            _play_next_episode_from_meta(play_meta)
            return

        clear_current_playback()
