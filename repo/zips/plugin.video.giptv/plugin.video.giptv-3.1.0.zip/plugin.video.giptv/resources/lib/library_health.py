# -*- coding: utf-8 -*-
"""Provider-inventory health checks for favourites and recently watched items."""

import json
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.apis import xtream_api
from resources.utils import giptv
from resources.utils.config import ensure_api_ready


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
PROFILE_DIR = xbmcvfs.translatePath(
    "special://profile/addon_data/{}/".format(ADDON_ID)
)
FAVOURITES_PATH = os.path.join(PROFILE_DIR, "favourites.json")
HISTORY_PATH = os.path.join(PROFILE_DIR, "watch_history.json")
STATE_PATH = os.path.join(PROFILE_DIR, "library_health_state.json")

_SCAN_LOCK = threading.Lock()
_THREAD_LOCK = threading.Lock()
_SCAN_THREAD = None
_PENDING_FORCE = False


def is_enabled():
    return str(ADDON.getSetting("library_health.enabled") or "true").lower() == "true"


def _interval_seconds():
    try:
        hours = int(ADDON.getSetting("library_health.interval_hours") or "24")
    except (TypeError, ValueError):
        hours = 24
    return max(1, min(168, hours)) * 3600


def _account_setting(base):
    selected = str(ADDON.getSetting("account") or "0")
    suffix = selected if selected in ("1", "2") else ""
    return str(ADDON.getSetting("{}{}".format(base, suffix)) or "").strip()


def current_server_key():
    server = _account_setting("server").rstrip("/")
    username = _account_setting("username")
    return "{}|{}".format(server, username) if server or username else ""


def _read_json(path, default):
    if not xbmcvfs.exists(path):
        return default
    try:
        handle = xbmcvfs.File(path, "r")
        try:
            value = json.loads(handle.read() or "")
        finally:
            handle.close()
        return value
    except Exception:
        return default


def _atomic_json(path, value):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)
    temp = "{}.{}.{}.tmp".format(path, os.getpid(), threading.current_thread().ident)
    with open(temp, "w", encoding="utf-8") as handle:
        json.dump(value, handle, separators=(",", ":"))
        handle.flush()
    os.replace(temp, path)


def _matches_current_server(item, server_key):
    saved = str(item.get("server_key") or "").strip()
    if saved:
        return saved == server_key
    server, _, username = server_key.partition("|")
    saved_user = str(item.get("server_user") or "").strip()
    if saved_user:
        return saved_user == username
    url = str(item.get("play_url") or "")
    return bool(url and (not server or server in url) and (not username or username in url))


def _item_type(item):
    value = str(item.get("type") or "").strip().lower()
    if value in ("live", "vod", "series"):
        return value
    url = str(item.get("play_url") or "").lower()
    if "/live/" in url or "/timeshift/" in url:
        return "live"
    if "/series/" in url:
        return "series"
    return "vod"


def _item_id(item, stream_type):
    if stream_type == "series":
        return str(item.get("series_id") or item.get("id") or "")
    return str(item.get("stream_id") or item.get("id") or "")


def _inventory_ids(stream_type, rows):
    keys = {
        "live": ("stream_id", "id"),
        "vod": ("stream_id", "movie_id", "vod_id", "id"),
        "series": ("series_id", "id"),
    }[stream_type]
    result = set()
    for row in rows or []:
        for key in keys:
            value = row.get(key)
            if value not in (None, ""):
                result.add(str(value))
                break
    return result


def _due(server_key):
    state = _read_json(STATE_PATH, {})
    try:
        last = float((state.get("accounts") or {}).get(server_key, {}).get("last", 0))
    except Exception:
        last = 0
    return time.time() - last >= _interval_seconds()


def _set_state(server_key, report, complete, mark_notified=False):
    state = _read_json(STATE_PATH, {})
    accounts = state.setdefault("accounts", {})
    previous = accounts.get(server_key) or {}
    # Retry incomplete provider responses in one hour instead of waiting a day.
    checked_at = time.time() if complete else time.time() - _interval_seconds() + 3600
    try:
        previous_notified = int(previous.get("notified_missing", -1))
    except (TypeError, ValueError):
        previous_notified = -1
    current_missing = int(report.get("missing", 0))
    accounts[server_key] = {
        "last": checked_at,
        "missing": report.get("missing", 0),
        "checked": report.get("checked", 0),
        "notified_missing": (
            current_missing if mark_notified or current_missing == 0 else previous_notified
        ),
    }
    _atomic_json(STATE_PATH, state)
    return current_missing > 0 and current_missing != previous_notified


def _mark_file(path, items, server_key, inventories, checked_at):
    changed = False
    missing_titles = []
    checked = 0
    for item in items:
        if not isinstance(item, dict) or not _matches_current_server(item, server_key):
            continue
        stream_type = _item_type(item)
        inventory = inventories.get(stream_type)
        identity = _item_id(item, stream_type)
        status = "unknown"
        if inventory is not None and identity:
            checked += 1
            status = "available" if identity in inventory else "missing"
        if item.get("availability") != status:
            item["availability"] = status
            changed = True
        if item.get("availability_checked") != checked_at:
            item["availability_checked"] = checked_at
            changed = True
        if status == "missing":
            if not item.get("missing_since"):
                item["missing_since"] = checked_at
                changed = True
            missing_titles.append(str(item.get("title") or "Unknown"))
        elif item.pop("missing_since", None) is not None:
            changed = True
    if changed:
        _atomic_json(path, items)
    return checked, missing_titles


def scan_saved_streams(force=False, notify=False):
    """Check saved IDs against complete provider inventories using set lookups."""
    if not is_enabled() and not force:
        return {"checked": 0, "missing": 0, "titles": [], "skipped": True}
    with _SCAN_LOCK:
        server_key = current_server_key()
        if not server_key or not ensure_api_ready():
            return {"checked": 0, "missing": 0, "titles": [], "skipped": True}
        if not force and not _due(server_key):
            return {"checked": 0, "missing": 0, "titles": [], "skipped": True}

        favourites = _read_json(FAVOURITES_PATH, [])
        history = _read_json(HISTORY_PATH, [])
        favourites = favourites if isinstance(favourites, list) else []
        history = history if isinstance(history, list) else []
        relevant = [
            item
            for item in favourites + history
            if isinstance(item, dict) and _matches_current_server(item, server_key)
        ]
        needed = {_item_type(item) for item in relevant}
        inventories = {}
        complete = True
        for stream_type in needed:
            rows = xtream_api.get_all_streams_unfiltered(
                stream_type, force_refresh=force
            )
            # An empty response for a populated saved type is treated as
            # unverifiable, preventing mass false-positive warnings.
            if rows is None or (not rows and relevant):
                inventories[stream_type] = None
                complete = False
            else:
                inventories[stream_type] = _inventory_ids(stream_type, rows)

        # Inventory requests can take time. Re-read immediately before writing
        # so favourites/history added while the scan was running are preserved.
        latest_favourites = _read_json(FAVOURITES_PATH, [])
        latest_history = _read_json(HISTORY_PATH, [])
        if isinstance(latest_favourites, list):
            favourites = latest_favourites
        if isinstance(latest_history, list):
            history = latest_history

        checked_at = int(time.time())
        fav_checked, fav_missing = _mark_file(
            FAVOURITES_PATH, favourites, server_key, inventories, checked_at
        )
        hist_checked, hist_missing = _mark_file(
            HISTORY_PATH, history, server_key, inventories, checked_at
        )
        try:
            from resources.lib.navigator import invalidate_saved_items_cache

            invalidate_saved_items_cache()
        except Exception:
            pass
        titles = fav_missing + hist_missing
        report = {
            "checked": fav_checked + hist_checked,
            "missing": len(titles),
            "titles": titles,
            "skipped": False,
            "complete": complete,
        }
        should_notify = _set_state(server_key, report, complete, mark_notified=False)
        giptv.log(
            "Saved stream health check complete checked={} missing={} complete={}".format(
                report["checked"], report["missing"], complete
            ),
            xbmc.LOGINFO,
        )
        if notify and should_notify:
            xbmcgui.Dialog().notification(
                ADDON.getAddonInfo("name"),
                "{} saved item(s) are no longer available".format(report["missing"]),
                xbmcgui.NOTIFICATION_WARNING,
                6000,
            )
            _set_state(server_key, report, complete, mark_notified=True)
        return report


def cleanup_missing_current_account():
    server_key = current_server_key()
    removed = 0
    for path in (FAVOURITES_PATH, HISTORY_PATH):
        items = _read_json(path, [])
        if not isinstance(items, list):
            continue
        kept = []
        for item in items:
            should_remove = (
                isinstance(item, dict)
                and _matches_current_server(item, server_key)
                and item.get("availability") == "missing"
            )
            if should_remove:
                removed += 1
            else:
                kept.append(item)
        if len(kept) != len(items):
            _atomic_json(path, kept)
    try:
        from resources.lib.navigator import invalidate_saved_items_cache

        invalidate_saved_items_cache()
    except Exception:
        pass
    return removed


def run_interactive_check():
    report = scan_saved_streams(force=True, notify=False)
    if report.get("skipped"):
        xbmcgui.Dialog().ok(
            ADDON.getAddonInfo("name"),
            "Saved streams could not be checked. Verify the selected account and connection.",
        )
        return False
    missing = int(report.get("missing", 0))
    if not missing:
        xbmcgui.Dialog().ok(
            ADDON.getAddonInfo("name"),
            "Checked {} saved items. No unavailable streams were found.".format(
                report.get("checked", 0)
            ),
        )
        return True
    remove = xbmcgui.Dialog().yesno(
        ADDON.getAddonInfo("name"),
        "Found {} unavailable saved item(s). Remove them from Favourites and Recently Watched?".format(
            missing
        ),
        yeslabel="Remove",
        nolabel="Keep and warn",
    )
    if remove:
        removed = cleanup_missing_current_account()
        xbmcgui.Dialog().ok(
            ADDON.getAddonInfo("name"), "Removed {} unavailable item(s).".format(removed)
        )
    return True


def _worker(initial_force, notify):
    global _SCAN_THREAD, _PENDING_FORCE
    force = initial_force
    while True:
        scan_saved_streams(force=force, notify=notify)
        with _THREAD_LOCK:
            if _PENDING_FORCE:
                _PENDING_FORCE = False
                force = True
                continue
            _SCAN_THREAD = None
            return


def request_check(force=False, notify=False):
    global _SCAN_THREAD, _PENDING_FORCE
    if not is_enabled():
        return False
    with _THREAD_LOCK:
        if _SCAN_THREAD is not None and _SCAN_THREAD.is_alive():
            _PENDING_FORCE = _PENDING_FORCE or bool(force)
            return True
        _PENDING_FORCE = False
        _SCAN_THREAD = threading.Thread(
            target=_worker,
            args=(bool(force), bool(notify)),
            name="giptv-library-health",
            daemon=True,
        )
        _SCAN_THREAD.start()
    return True
