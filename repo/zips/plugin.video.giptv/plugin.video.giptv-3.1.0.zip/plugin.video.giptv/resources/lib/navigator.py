# -*- coding: utf-8 -*-
import sys
import datetime
import time
import os
import json
import base64
import re
import threading
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import resources.apis.tmdb_helper as TMDbHelper
import resources.apis.xtream_api as xtream_api
import resources.utils.giptv as giptv
from resources.utils import settings
from resources.lib.manager.fetch_manager import cache_handler
from resources.lib.manager.epg_manager import (
    get_now_next,
    get_xmltv_index,
    resolve_xmltv_channel_id,
    set_catchup_channels,
)
from resources.lib.cache.picon_cache import get_picon
import resources.utils.config as config
from resources.utils.xtream import STATE
from resources.apis import trakt_api
from resources.lib.manager.index_manager import _read_index

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
ADDON_ID = ADDON.getAddonInfo("id")

GLOBAL_FANART = os.path.join(ADDON_PATH, "fanart.png")
LIVE_ICON = os.path.join(ADDON_PATH, "resources", "media", "thumb", "tv.png")
SERIES_ICON = os.path.join(ADDON_PATH, "resources", "media", "thumb", "series.png")
MOVIE_ICON = os.path.join(ADDON_PATH, "resources", "media", "thumb", "movies.png")
SEARCH_ICON = os.path.join(ADDON_PATH, "resources", "media", "thumb", "search.png")
WATCHED_ICON = os.path.join(ADDON_PATH, "resources", "media", "thumb", "watched.png")
FAVOURITES_ICON = os.path.join(
    ADDON_PATH, "resources", "media", "thumb", "favourite.png"
)

if len(sys.argv) > 1 and sys.argv[1].isdigit():
    PLUGIN_HANDLE = int(sys.argv[1])
else:
    PLUGIN_HANDLE = -1

tmdb_helper = TMDbHelper.TMDbHelper()
DEFAULT_PAGE_SIZE = 23

# ---------------------------------------------------------------------------
# Module-level bounded thread pool — shared across all callers.
# max_workers=6 keeps I/O parallelism useful without thread storms.
# ---------------------------------------------------------------------------

_POOL_MAX = 6


def shutdown_thread_pool(wait=False):
    # Kept for service shutdown compatibility.
    # navigator.py no longer owns a persistent global pool.
    return


# ---------------------------------------------------------------------------
# LRU Cache
# ---------------------------------------------------------------------------


class LRUCache:
    __slots__ = ("max_items", "data")

    def __init__(self, max_items=300):
        self.max_items = max_items
        self.data = OrderedDict()

    def get(self, key, default=None):
        if key not in self.data:
            return default
        self.data.move_to_end(key)
        return self.data[key]

    def set(self, key, value):
        self.data[key] = value
        self.data.move_to_end(key)
        while len(self.data) > self.max_items:
            self.data.popitem(last=False)

    def clear(self):
        self.data.clear()


_current_items = LRUCache(max_items=20)
_picon_memory_cache = LRUCache(max_items=200)
_xmltv_channel_cache = LRUCache(max_items=500)
_tmdb_id_memory_cache = LRUCache(max_items=2000)
_tmdb_details_cache = LRUCache(max_items=500)

# In-memory index lookup dicts built once per index type, keyed by tmdb_id
_index_tmdb_map = {}  # {"vod": {tmdb_id: [items]}, "series": {tmdb_id: [items]}}


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------


def _ensure_ready():
    return config.ensure_api_ready()


def _plugin_url(**params):
    return sys.argv[0] + "?" + urlparse.urlencode(params)


def _encode_meta(meta_dict):
    try:
        raw = json.dumps(meta_dict, separators=(",", ":"))
        return base64.urlsafe_b64encode(raw.encode("utf-8")).decode("utf-8")
    except Exception:
        return ""


def _safe_int(value, default=0):
    try:
        if value in (None, "", "None", "null"):
            return default
        return int(value)
    except Exception:
        return default


def _safe_float(value, default=0.0):
    try:
        if value in (None, "", "None", "null"):
            return default
        return float(value)
    except Exception:
        return default


def _set_tag_year(tag, value):
    try:
        if value in (None, "", "0", 0):
            return
        tag.setYear(int(value))
    except Exception:
        pass


def _set_tag_rating(tag, value):
    try:
        if value in (None, "", "0", 0):
            return
        rating_value = float(value)
        try:
            tag.setRating(rating_value)
        except TypeError:
            tag.setRating(rating_value, 10)
    except Exception:
        pass


def _safe_nonempty_text(value):
    value = (value or "").strip()
    return value or None


def _normalize_search_query(value):
    return (value or "").strip().lower()


def _normalize_title(value):
    return (value or "").strip().lower()


_LIVE_VERSION_TOKENS = {
    "sd", "hd", "fhd", "uhd", "4k", "8k", "raw", "hevc", "h265", "h264",
    "50fps", "60fps", "720p", "1080p", "2160p", "3840p",
}


def _live_version_key(name):
    """Collapse quality/codec suffixes while preserving channel identity."""
    text = (name or "").lower().replace("&", " and ")
    text = re.sub(r"[\[\](){}/|:_-]+", " ", text)
    tokens = [
        token
        for token in re.findall(r"[a-z0-9]+", text)
        if token not in _LIVE_VERSION_TOKENS
    ]
    return " ".join(tokens).strip()


def _condense_live_streams(stream_list):
    groups = OrderedDict()
    for stream in stream_list or []:
        name = (
            stream.get("name")
            or stream.get("title")
            or stream.get("stream_display_name")
            or ""
        )
        key = _live_version_key(name) or _normalize_title(name)
        groups.setdefault(key, []).append(stream)
    condensed = []
    for key, versions in groups.items():
        # Prefer a version that can supply both catch-up and EPG metadata for
        # the condensed row. Playback still prompts for any available version.
        representative_source = max(
            versions,
            key=lambda stream: (
                bool(stream.get("epg_channel_id") or stream.get("tvg_id")),
                str(stream.get("tv_archive", stream.get("has_archive", "0")))
                == "1",
            ),
        )
        representative = dict(representative_source)
        if len(versions) > 1:
            representative["_giptv_versions"] = versions
            representative["_giptv_version_key"] = key
        condensed.append(representative)
    return condensed


def _encode_live_versions(versions):
    slim = []
    for stream in versions or []:
        slim.append(
            {
                "stream_id": str(stream.get("stream_id") or ""),
                "name": stream.get("name") or stream.get("title") or "Unknown",
                "container_extension": stream.get("container_extension", "ts"),
                "category_id": str(stream.get("category_id") or ""),
                "epg_channel_id": stream.get("epg_channel_id") or "",
                "tvg_id": stream.get("tvg_id") or "",
            }
        )
    return _encode_meta(slim)


def _decode_live_versions(value):
    if not value:
        return []
    try:
        raw = base64.urlsafe_b64decode(value.encode("utf-8")).decode("utf-8")
        data = json.loads(raw)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _paginate_items(items, page, page_size=DEFAULT_PAGE_SIZE):
    if not isinstance(items, list):
        giptv.log(
            "[NAV] _paginate_items received non-list type={}".format(
                type(items).__name__
            ),
            xbmc.LOGWARNING,
        )
        items = []

    page = max(1, _safe_int(page, 1))
    start = (page - 1) * page_size
    end = start + page_size
    sliced = items[start:end]
    return sliced, end < len(items), page


def _add_dir_items(items):
    if PLUGIN_HANDLE < 0:
        return
    if items:
        xbmcplugin.addDirectoryItems(PLUGIN_HANDLE, items, len(items))
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE, succeeded=True, cacheToDisc=False)


def _show_filter_keyboard(title):
    keyboard = xbmc.Keyboard("", title)
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return None
    value = keyboard.getText().strip().lower()
    return value or None


def _apply_offset_minutes(timestamp, offset_minutes):
    return timestamp + (offset_minutes * 60)


def _fmt_time(ts):
    return datetime.datetime.fromtimestamp(ts).strftime("%H:%M")


def _epg_progress(start_ts, end_ts):
    now = int(time.time())
    if end_ts <= start_ts:
        return 0
    return max(0, min(100, int((now - start_ts) * 100 / (end_ts - start_ts))))


def _progress_bar(percent, width=10):
    filled = int(width * percent / 100)
    return "●" * filled + "○" * (width - filled)


def _slim_search_items(items):
    slim = []
    for item in items or []:
        name = (
            item.get("name", "")
            or item.get("title", "")
            or item.get("stream_display_name", "")
        )
        slim.append(
            {
                "name": name,
                "lower": _normalize_title(name),
                "stream_id": item.get("stream_id", ""),
                "series_id": item.get("series_id", ""),
                "category_id": item.get("category_id", ""),
            }
        )
    return slim


def _store_current_items(stream_type, category_id, items):
    _current_items.set(f"{stream_type}_{category_id}", _slim_search_items(items))


def get_current_items(stream_type, category_id):
    return _current_items.get(f"{stream_type}_{category_id}", [])


# ---------------------------------------------------------------------------
# TMDb ID extraction / normalisation
# ---------------------------------------------------------------------------


def _extract_tmdb_id(data):
    return (
        data.get("tmdb")
        or data.get("tmdb_id")
        or data.get("tmdbId")
        or data.get("tmdbID")
        or data.get("imdb_id")
        or (data.get("info", {}) or {}).get("tmdb")
        or (data.get("info", {}) or {}).get("tmdb_id")
        or None
    )


def _normalize_tmdb_id(value):
    value = str(value or "").strip()
    return value if value.isdigit() else ""


def _clean_title_for_tmdb(title):
    value = str(title or "").strip()

    value = re.sub(r"\s*-\s*\d{4}$", "", value, flags=re.IGNORECASE)
    value = re.sub(r"\s*\(\d{4}\)$", "", value, flags=re.IGNORECASE)
    value = re.sub(r"\s*\[\d{4}\]$", "", value, flags=re.IGNORECASE)

    junk_patterns = [
        r"\b4k/uhd\b",
        r"\b4k uhd\b",
        r"\buhd\b",
        r"\b4k\b",
        r"\bfhd\b",
        r"\bhd\b",
        r"\b2160p\b",
        r"\b1080p\b",
        r"\b720p\b",
        r"\bbluray\b",
        r"\bblu[- ]?ray\b",
        r"\bbrrip\b",
        r"\bwebrip\b",
        r"\bweb[- ]?dl\b",
        r"\bhdr\b",
        r"\bdv\b",
        r"\batmos\b",
        r"\bremux\b",
        r"\bx264\b",
        r"\bx265\b",
        r"\bhevc\b",
        r"\b4k-nf\b",
        r"\bnf-do\b",
        r"\b4k-top\b",
        r"\b4k-mrvl\b",
        r"\bnf\b",
        r"\bamzn\b",
        r"\bdsnp\b",
        r"\bhmax\b",
        r"\btop\b",
        r"\bmrvl\b",
        r"\bnetflix\b",
        r"\bdual audio\b",
        r"\bmulti audio\b",
        r"\bproper\b",
        r"\brepack\b",
        r"\bextended\b",
        r"\buncut\b",
        r"\bsubbed\b",
        r"\bdubbed\b",
        r"\beng\b",
        r"\bfr\b",
        r"\bit\b",
        r"\bes\b",
        r"\bde\b",
        r"\bpt\b",
        r"\bnl\b",
        r"\bpl\b",
        r"\bru\b",
        r"\btr\b",
        r"\bar\b",
        r"\bjp\b",
        r"\bkr\b",
    ]
    for pattern in junk_patterns:
        value = re.sub(pattern, "", value, flags=re.IGNORECASE)

    value = re.sub(r"\(\s*[a-z]{2}\s*\)", "", value, flags=re.IGNORECASE)
    value = re.sub(r"\[\s*[a-z]{2}\s*\]", "", value, flags=re.IGNORECASE)
    value = re.sub(r"-\s*[a-z]{2,8}$", "", value, flags=re.IGNORECASE)
    value = re.sub(r"\s+", " ", value).strip()
    return value


# ---------------------------------------------------------------------------
# Cached TMDb lookups
# ---------------------------------------------------------------------------


def _movie_id_cache_key(stream_name, year_hint=""):
    clean_title = _clean_title_for_tmdb(stream_name)
    year_hint = str(year_hint or "").strip()
    if not year_hint.isdigit() or len(year_hint) != 4:
        year_hint = ""
    return f"{clean_title}|{year_hint}"


def _series_id_cache_key(series_name, year_hint=""):
    clean_title = _clean_title_for_tmdb(series_name)
    year_hint = str(year_hint or "").strip()
    if not year_hint.isdigit() or len(year_hint) != 4:
        year_hint = ""
    return f"{clean_title}|{year_hint}"


def _resolve_movie_tmdb_id_cached(stream_name, year_hint=""):
    cache_key = _movie_id_cache_key(stream_name, year_hint)
    memory_key = f"movie:v2:{cache_key}"

    cached = _tmdb_id_memory_cache.get(memory_key)
    if cached is not None:
        return cached

    db_cache_key = f"{STATE.username}_movie_title_id_v2_{cache_key}"
    cached_db = cache_handler.get("tmdb_data", db_cache_key)
    if cached_db:
        tmdb_id = _normalize_tmdb_id(cached_db.get("tmdb_id"))
        _tmdb_id_memory_cache.set(memory_key, tmdb_id)
        return tmdb_id

    title_for_search, year_for_search = cache_key.split("|", 1)
    tmdb_id = _normalize_tmdb_id(
        tmdb_helper.search_movie_id(title_for_search, year=year_for_search)
    )
    cache_handler.set("tmdb_data", db_cache_key, {"tmdb_id": tmdb_id})
    _tmdb_id_memory_cache.set(memory_key, tmdb_id)
    return tmdb_id


def _resolve_series_tmdb_id_cached(series_name, year_hint=""):
    cache_key = _series_id_cache_key(series_name, year_hint)
    memory_key = f"series:v2:{cache_key}"

    cached = _tmdb_id_memory_cache.get(memory_key)
    if cached is not None:
        return cached

    db_cache_key = f"{STATE.username}_series_title_id_v2_{cache_key}"
    cached_db = cache_handler.get("tmdb_data", db_cache_key)
    if cached_db:
        tmdb_id = _normalize_tmdb_id(cached_db.get("tmdb_id"))
        _tmdb_id_memory_cache.set(memory_key, tmdb_id)
        return tmdb_id

    title_for_search, year_for_search = cache_key.split("|", 1)
    tmdb_id = _normalize_tmdb_id(
        tmdb_helper.search_series_id(title_for_search, year=year_for_search)
    )
    cache_handler.set("tmdb_data", db_cache_key, {"tmdb_id": tmdb_id})
    _tmdb_id_memory_cache.set(memory_key, tmdb_id)
    return tmdb_id


def _get_tmdb_movie_details_cached(tmdb_id):
    tmdb_id = _normalize_tmdb_id(tmdb_id)
    if not tmdb_id:
        return None
    key = f"movie:{tmdb_id}"
    cached = _tmdb_details_cache.get(key)
    if cached is not None:
        return cached
    try:
        data = tmdb_helper.get_movie_details(tmdb_id)
    except Exception:
        data = None
    _tmdb_details_cache.set(key, data)
    return data


def _get_tmdb_series_details_cached(tmdb_id):
    tmdb_id = _normalize_tmdb_id(tmdb_id)
    if not tmdb_id:
        return None
    key = f"series:{tmdb_id}"
    cached = _tmdb_details_cache.get(key)
    if cached is not None:
        return cached
    try:
        data = tmdb_helper.get_series_details(tmdb_id)
    except Exception:
        data = None
    _tmdb_details_cache.set(key, data)
    return data


def _get_tmdb_season_details_cached(tmdb_id, season_num):
    tmdb_id = _normalize_tmdb_id(tmdb_id)
    if not tmdb_id:
        return None
    key = f"season:{tmdb_id}:{season_num}"
    cached = _tmdb_details_cache.get(key)
    if cached is not None:
        return cached
    try:
        data = tmdb_helper.get_season_details(tmdb_id, int(season_num))
    except Exception:
        data = None
    _tmdb_details_cache.set(key, data)
    return data


def _get_tmdb_episode_details_cached(tmdb_id, season_num, episode_num):
    tmdb_id = _normalize_tmdb_id(tmdb_id)
    if not tmdb_id:
        return None
    key = f"episode:{tmdb_id}:{season_num}:{episode_num}"
    cached = _tmdb_details_cache.get(key)
    if cached is not None:
        return cached
    try:
        data = tmdb_helper.get_episode_details(
            tmdb_id, int(season_num), int(episode_num)
        )
    except Exception:
        data = None
    _tmdb_details_cache.set(key, data)
    return data


# ---------------------------------------------------------------------------
# Art / UI helpers
# ---------------------------------------------------------------------------


def _build_art(thumb="", poster="", fanart="", icon="", fallback="DefaultVideo.png"):
    thumb = thumb or poster or fanart or icon or fallback
    poster = poster or thumb or fanart or icon or fallback
    fanart = fanart or poster or thumb or icon or fallback
    icon = icon or thumb or poster or fanart or fallback
    return {"thumb": thumb, "poster": poster, "fanart": fanart, "icon": icon}


def _get_picon_cached(stream_id, stream_icon, category_id):
    key = (str(stream_id), stream_icon or "", str(category_id or ""))
    cached = _picon_memory_cache.get(key)
    if cached is not None:
        return cached
    value = get_picon(stream_id, stream_icon, category_id)
    _picon_memory_cache.set(key, value)
    return value


def _resolve_xmltv_channel_id_cached(stream):
    stream_id = str(stream.get("stream_id", ""))
    cached = _xmltv_channel_cache.get(stream_id)
    if cached is not None:
        return cached
    value = resolve_xmltv_channel_id(stream)
    _xmltv_channel_cache.set(stream_id, value)
    return value


def _label_with_marker(label, watched=False, progress=None, skip=True):
    base = label or ""
    try:
        progress = int(float(progress)) if progress is not None else None
    except Exception:
        progress = None

    if skip:
        return base
    if progress is not None and progress > 0:
        return f"[COLOR orange][{progress}%][/COLOR]  {base}"
    return base


def _apply_tmdb_art_to_listitem(li, art, tmdb_id=None, fallback="DefaultVideo.png"):
    li.setArt(
        _build_art(
            thumb=art.get("thumb", "") or art.get("poster", ""),
            poster=art.get("poster", ""),
            fanart=art.get("fanart", ""),
            icon=art.get("thumb", "") or art.get("poster", ""),
            fallback=fallback,
        )
    )
    if tmdb_id:
        li.setProperty("tmdbnumber", str(tmdb_id))
        li.setProperty("imdbnumber", str(tmdb_id))
        try:
            li.getVideoInfoTag().setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")
        except Exception:
            pass


def _apply_basic_tag(tag, title, plot="", media_type="movie", year=None, rating=None):
    try:
        tag.setTitle(title)
    except Exception:
        pass
    try:
        tag.setPlot(plot)
    except Exception:
        pass
    try:
        tag.setMediaType(media_type)
    except Exception:
        pass
    if year is not None:
        _set_tag_year(tag, year)
    if rating is not None:
        _set_tag_rating(tag, rating)


# ---------------------------------------------------------------------------
# Index lookup (O(1) by tmdb_id after first build)
# ---------------------------------------------------------------------------


def _build_index_tmdb_map(index_type):
    if index_type in _index_tmdb_map:
        return _index_tmdb_map[index_type]

    try:
        index_items = _read_index(index_type) or []
    except Exception:
        index_items = []

    mapping = {}
    for item in index_items:
        tmdb = str(item.get("tmdb") or "").strip()
        if tmdb:
            mapping.setdefault(tmdb, []).append(item)

    _index_tmdb_map[index_type] = mapping
    return mapping


def _find_all_index_matches(index_type, title="", tmdb_id=""):
    tmdb_id = str(tmdb_id or "").strip()
    wanted = _normalize_title(title)

    if tmdb_id:
        mapping = _build_index_tmdb_map(index_type)
        if tmdb_id in mapping:
            return mapping[tmdb_id]

    try:
        index_items = _read_index(index_type) or []
    except Exception:
        index_items = []

    results = []
    seen = set()

    for item in index_items:
        try:
            item_title = _normalize_title(item.get("title") or item.get("name") or "")
            item_id = str(
                item.get("id") or item.get("stream_id") or item.get("series_id") or ""
            )
            if not wanted or not item_title:
                continue
            if not (
                wanted == item_title or wanted in item_title or item_title in wanted
            ):
                continue
            dedupe_key = "{}|{}|{}".format(
                item_id, str(item.get("category_id") or ""), item_title
            )
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            results.append(item)
        except Exception:
            pass

    return results


def _find_best_index_match(index_type, title="", tmdb_id=""):
    matches = _find_all_index_matches(index_type, title=title, tmdb_id=tmdb_id)
    return matches[0] if matches else None


# ---------------------------------------------------------------------------
# Parallel fetch helpers — all backed by the shared bounded pool
# ---------------------------------------------------------------------------


def _parallel_fetch(tasks):
    results = {}

    if not tasks:
        return results

    max_workers = min(_POOL_MAX, len(tasks))

    executor = ThreadPoolExecutor(
        max_workers=max_workers,
        thread_name_prefix="nav_tmp",
    )

    futures = {}

    try:
        for key, fn, *args in tasks:
            try:
                future = executor.submit(fn, *args)
                futures[future] = key
            except Exception:
                results[key] = None

        for future in as_completed(futures):
            key = futures[future]
            try:
                results[key] = future.result(timeout=20)
            except Exception:
                results[key] = None

    finally:
        try:
            executor.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            executor.shutdown(wait=False)
        except Exception:
            pass

    return results


def _pool_map(fn, items):
    if not items:
        return []

    max_workers = min(_POOL_MAX, len(items))

    executor = ThreadPoolExecutor(
        max_workers=max_workers,
        thread_name_prefix="nav_tmp",
    )

    futures = []

    try:
        for item in items:
            try:
                futures.append(executor.submit(fn, item))
            except Exception:
                futures.append(None)

        results = []

        for future in futures:
            if future is None:
                results.append(None)
                continue

            try:
                results.append(future.result(timeout=20))
            except Exception:
                results.append(None)

        return results

    finally:
        try:
            executor.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            executor.shutdown(wait=False)
        except Exception:
            pass


def _fetch_trakt_vod_data():
    fetched = _parallel_fetch(
        [
            ("resume_map", trakt_api.trakt_get_movie_resume_map),
            ("watched_ids", trakt_api.trakt_get_watched_movie_ids),
        ]
    )
    return (
        fetched.get("resume_map") or {},
        fetched.get("watched_ids") or set(),
    )


# ---------------------------------------------------------------------------
# Memory / diagnostics
# ---------------------------------------------------------------------------


def _log_memory_caches(context=""):
    if not xbmc.getCondVisibility("System.LogLevel.Debug"):
        return
    try:
        giptv.log(
            f"[MEM] {context} current_items={len(_current_items.data)} "
            f"picons={len(_picon_memory_cache.data)} "
            f"xmltv_ids={len(_xmltv_channel_cache.data)} "
            f"tmdb_ids={len(_tmdb_id_memory_cache.data)} "
            f"tmdb_details={len(_tmdb_details_cache.data)}",
            xbmc.LOGINFO,
        )
    except Exception:
        pass


def _trim_route_memory(is_live=False):
    _picon_memory_cache.clear()
    if not is_live:
        _xmltv_channel_cache.clear()


# ---------------------------------------------------------------------------
# Navigation helpers
# ---------------------------------------------------------------------------


def _open_root_menu():
    try:
        xbmc.executebuiltin(
            "ActivateWindow(Videos,plugin://{}/?mode=root_menu,return)".format(ADDON_ID)
        )
    except Exception:
        try:
            xbmc.executebuiltin(
                "Container.Update(plugin://{}/?mode=root_menu&_={})".format(
                    ADDON_ID, int(time.time() * 1000)
                )
            )
        except Exception:
            pass


def _notify_and_go_home(message="Server unavailable"):
    try:
        giptv.notification(ADDON.getAddonInfo("name"), message, icon="ERROR")
    except Exception:
        pass
    xbmc.sleep(250)
    _open_root_menu()


def _notify_and_open_settings(message="Server not configured correctly"):
    try:
        giptv.notification(ADDON.getAddonInfo("name"), message, icon="ERROR")
    except Exception:
        pass
    xbmc.sleep(250)
    try:
        giptv.open_settings()
    except Exception:
        pass


def _is_invalid_xtream_payload(data):
    if data is None:
        return True
    if isinstance(data, list):
        return False
    if isinstance(data, dict):
        if not data:
            return True
        try:
            lowered = json.dumps(data).lower()
        except Exception:
            lowered = str(data).lower()
        bad_markers = [
            "invalid",
            "unauthorized",
            "forbidden",
            "expired",
            "denied",
            "error",
            "available at the moment",
            "access denied",
            "auth",
        ]
        return any(marker in lowered for marker in bad_markers)
    return True


def _safe_category_list(stream_type):
    cache_key = f"{STATE.username}_{stream_type}"
    category_list = cache_handler.get("categories", cache_key)

    if category_list is not None and not isinstance(category_list, list):
        giptv.log(
            "[NAV] bad cached categories key={} type={}".format(
                cache_key, type(category_list).__name__
            ),
            xbmc.LOGWARNING,
        )
        category_list = None

    if not category_list:
        category_list = xtream_api.categories(stream_type)
        if isinstance(category_list, list) and category_list:
            cache_handler.set("categories", cache_key, category_list)

    if _is_invalid_xtream_payload(category_list):
        return None
    return category_list


def _safe_stream_list(stream_type, category_id):
    cache_key = f"{STATE.username}_{stream_type}_{category_id}"
    stream_list = cache_handler.get(stream_type, cache_key)

    if stream_list is not None and not isinstance(stream_list, list):
        giptv.log(
            "[NAV] bad cached streams key={} type={}".format(
                cache_key, type(stream_list).__name__
            ),
            xbmc.LOGWARNING,
        )
        stream_list = None

    if not stream_list:
        stream_list = xtream_api.streams_by_category(stream_type, category_id)
        if isinstance(stream_list, list) and stream_list:
            cache_handler.set(stream_type, cache_key, stream_list)

    if _is_invalid_xtream_payload(stream_list):
        return None
    return stream_list


def _has_category_matches(category_list, query):
    q = _normalize_search_query(query)
    if not q:
        return False
    return any(
        q in (c.get("category_name", "") or "").lower() for c in category_list or []
    )


def _stream_matches_query(item, query):
    q = _normalize_search_query(query)
    if not q:
        return False
    name = _normalize_search_query(item.get("name") or "")
    title = _normalize_search_query(item.get("title") or "")
    display = _normalize_search_query(item.get("stream_display_name") or "")
    return q in name or q in title or q in display


def _is_trakt_ready():
    try:
        return trakt_api.trakt_is_authenticated()
    except Exception:
        return False


def _season_rollup_from_episode_maps(
    season_num, episodes, watched_episode_keys, episode_resume_map
):
    season_key = str(season_num)
    total_count = 0
    watched_count = 0
    max_resume_progress = 0

    for ep in episodes or []:
        try:
            ep_num = str(ep.get("episode_num", ""))
            if not ep_num:
                continue
            total_count += 1
            key = (season_key, ep_num)
            if key in watched_episode_keys:
                watched_count += 1
                continue
            resume_info = episode_resume_map.get(key) or {}
            progress = _safe_float(resume_info.get("progress"), 0.0)
            if progress > max_resume_progress:
                max_resume_progress = int(progress)
        except Exception:
            pass

    watched_flag = total_count > 0 and watched_count >= total_count
    progress_value = None
    if not watched_flag:
        if watched_count > 0 and total_count > 0:
            try:
                progress_value = int(
                    (float(watched_count) / float(total_count)) * 100.0
                )
            except Exception:
                pass
        elif max_resume_progress > 0:
            progress_value = max_resume_progress

    return watched_flag, progress_value


def _show_rollup_from_episode_maps(
    episodes_by_season, watched_episode_keys, episode_resume_map
):
    total_count = 0
    watched_count = 0
    max_resume_progress = 0

    for season_num, episodes in (episodes_by_season or {}).items():
        season_key = str(season_num)
        for ep in episodes or []:
            try:
                ep_num = str(ep.get("episode_num", ""))
                if not ep_num:
                    continue
                total_count += 1
                key = (season_key, ep_num)
                if key in watched_episode_keys:
                    watched_count += 1
                    continue
                resume_info = episode_resume_map.get(key) or {}
                progress = _safe_float(resume_info.get("progress"), 0.0)
                if progress > max_resume_progress:
                    max_resume_progress = int(progress)
            except Exception:
                pass

    watched_flag = total_count > 0 and watched_count >= total_count
    progress_value = None
    if not watched_flag:
        if watched_count > 0 and total_count > 0:
            try:
                progress_value = int(
                    (float(watched_count) / float(total_count)) * 100.0
                )
            except Exception:
                pass
        elif max_resume_progress > 0:
            progress_value = max_resume_progress

    return watched_flag, progress_value


# ---------------------------------------------------------------------------
# Sort helpers
# ---------------------------------------------------------------------------


def _sort_streams(stream_list, mode):
    if not mode:
        return stream_list
    return sorted(
        stream_list,
        key=lambda s: _normalize_title(
            s.get("name") or s.get("title") or s.get("stream_display_name") or ""
        ),
        reverse=(mode == "za"),
    )


def _sort_categories(categories, mode):
    if not mode:
        return categories
    return sorted(
        categories,
        key=lambda c: c.get("category_name", "").lower(),
        reverse=(mode == "za"),
    )


# ---------------------------------------------------------------------------
# Context menu / URL builders
# ---------------------------------------------------------------------------


def _add_giptv_context_menu(list_item, menu_url):
    list_item.addContextMenuItems(
        [("GIPTV Menu", f"RunPlugin({menu_url})")],
        replaceItems=False,
    )


def _build_category_menu_url(stream_type, category_id, category_name):
    from resources.lib.manager import sort_manager

    sort_label = sort_manager.get_sort_label("categories", stream_type)
    return giptv.build_url(
        action="open_context_window",
        title=category_name,
        name=category_name,
        item_id=f"category:{stream_type}:{category_id}",
        stream_type=stream_type,
        directory_type="categories",
        directory_id=stream_type,
        refresh_mode="list_categories",
        sort_label=sort_label,
        category_id=category_id,
        category_name=category_name,
        play_url="",
        thumb="",
        poster="",
        fanart="",
        icon="",
        plot="",
        rating="0",
        year="0",
        tmdb_id="",
        channel_id="",
        epg_channel_id="",
        has_archive="0",
    )


def _build_stream_menu_url(
    *,
    item_id,
    name,
    play_url,
    stream_type,
    thumb="",
    poster="",
    fanart="",
    icon="",
    plot="",
    rating="0",
    year="0",
    tmdb_id="",
    channel_id="",
    epg_channel_id="",
    has_archive="0",
    directory_type="",
    directory_id="",
    refresh_mode="",
    sort_label="",
    category_id="",
    category_name="",
    search_query="",
    page="1",
    season="",
    episode="",
    favourite_kind="playable",
    target_mode="",
    series_id="",
    series_name="",
    season_num="",
    resume_progress="0",
):
    return giptv.build_url(
        action="open_context_window",
        title=name,
        item_id=item_id,
        name=name,
        play_url=play_url,
        stream_type=stream_type,
        thumb=thumb,
        poster=poster,
        fanart=fanart,
        icon=icon,
        plot=plot,
        rating=str(rating),
        year=str(year),
        tmdb_id=tmdb_id,
        channel_id=channel_id,
        epg_channel_id=epg_channel_id,
        has_archive=str(has_archive),
        directory_type=directory_type,
        directory_id=directory_id,
        refresh_mode=refresh_mode,
        sort_label=sort_label,
        category_id=category_id,
        category_name=category_name,
        search_query=search_query or "",
        page=str(page or "1"),
        season=str(season or ""),
        episode=str(episode or ""),
        favourite_kind=favourite_kind,
        target_mode=target_mode,
        series_id=str(series_id or ""),
        series_name=series_name or "",
        season_num=str(season_num or ""),
        resume_progress=str(resume_progress or "0"),
    )


# ---------------------------------------------------------------------------
# Pagination nav items
# ---------------------------------------------------------------------------


# def _prev_page_item(mode, page, **extra):
#     li = xbmcgui.ListItem(label="[COLOR orange]\u25c0 Previous Page[/COLOR]")
#     li.setArt({"icon": "DefaultFolderBack.png", "thumb": "DefaultFolderBack.png"})
#     return (_plugin_url(mode=mode, page=str(page - 1), **extra), li, True)


def _next_page_item(mode, page, **extra):
    li = xbmcgui.ListItem(label="[COLOR orange]Next Page \u25b6[/COLOR]")
    li.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
    return (_plugin_url(mode=mode, page=str(page + 1), **extra), li, True)


# ---------------------------------------------------------------------------
# Continue Watching builders
# ---------------------------------------------------------------------------


def _make_continue_movie_item(tmdb_id, match_list, resume_data):
    details = _get_tmdb_movie_details_cached(tmdb_id) or {}
    art = (details.get("art") or {}) if details else {}

    title = details.get("title") or ""
    if not title and match_list:
        title = match_list[0].get("title") or "Continue Watching"

    progress = _safe_float((resume_data or {}).get("progress"), 0.0)
    if progress <= 0.0 or progress >= 98.0:
        return None

    li = xbmcgui.ListItem(
        label=_label_with_marker(
            f"[B]Continue:[/B] {title}", progress=progress, skip=False
        )
    )
    _apply_tmdb_art_to_listitem(li, art, tmdb_id=tmdb_id)
    _apply_basic_tag(
        li.getVideoInfoTag(),
        title,
        plot=details.get("plot", ""),
        media_type="movie",
        year=details.get("year"),
        rating=details.get("rating"),
    )

    menu_url = _build_stream_menu_url(
        item_id=f"continue_movie:{tmdb_id}",
        name=title,
        play_url="",
        stream_type="vod",
        thumb=art.get("thumb", ""),
        poster=art.get("poster", ""),
        fanart=art.get("fanart", ""),
        icon=art.get("thumb", "") or art.get("poster", ""),
        plot=details.get("plot", ""),
        rating=str(details.get("rating") or "0"),
        year=str(details.get("year") or "0"),
        tmdb_id=str(tmdb_id),
        directory_type="continue",
        directory_id="movies",
        refresh_mode="continue_movies",
        favourite_kind="continue_folder",
        target_mode="continue_movie_versions",
        resume_progress=str(progress or 0),
    )
    _add_giptv_context_menu(li, menu_url)

    return (
        _plugin_url(mode="continue_movie_versions", tmdb_id=str(tmdb_id), title=title),
        li,
        True,
    )


def _make_continue_series_item(tmdb_id, match_list, playback_item):
    details = _get_tmdb_series_details_cached(tmdb_id) or {}
    art = (details.get("art") or {}) if details else {}

    title = details.get("title") or ""
    if not title and match_list:
        title = match_list[0].get("title") or "Continue Watching"

    progress = _safe_float((playback_item or {}).get("progress"), 0.0)
    if progress <= 0.0 or progress >= 98.0:
        return None

    li = xbmcgui.ListItem(
        label=_label_with_marker(
            f"[B]Continue:[/B] {title}", progress=progress, skip=False
        )
    )
    _apply_tmdb_art_to_listitem(li, art, tmdb_id=tmdb_id, fallback="DefaultTVShows.png")
    _apply_basic_tag(
        li.getVideoInfoTag(),
        title,
        plot=details.get("plot", ""),
        media_type="tvshow",
        year=details.get("year"),
        rating=details.get("rating"),
    )

    menu_url = _build_stream_menu_url(
        item_id=f"continue_series:{tmdb_id}",
        name=title,
        play_url="",
        stream_type="series",
        thumb=art.get("thumb", ""),
        poster=art.get("poster", ""),
        fanart=art.get("fanart", ""),
        icon=art.get("thumb", "") or art.get("poster", ""),
        plot=details.get("plot", ""),
        rating=str(details.get("rating") or "0"),
        year=str(details.get("year") or "0"),
        tmdb_id=str(tmdb_id),
        directory_type="continue",
        directory_id="series",
        refresh_mode="continue_series",
        favourite_kind="continue_folder",
        target_mode="continue_series_versions",
        resume_progress=str(progress or 0),
    )
    _add_giptv_context_menu(li, menu_url)

    return (
        _plugin_url(mode="continue_series_versions", tmdb_id=str(tmdb_id), title=title),
        li,
        True,
    )


def _get_continue_watching_movie_items():
    out = []
    seen = set()

    try:
        trakt_resume_map = trakt_api.trakt_get_movie_resume_map()
    except Exception:
        trakt_resume_map = {}

    merged = [
        {
            "tmdb_id": str(tmdb_id),
            "progress": _safe_float((resume_data or {}).get("progress"), 0.0),
        }
        for tmdb_id, resume_data in (trakt_resume_map or {}).items()
    ]
    merged.sort(key=lambda x: x["progress"], reverse=True)

    candidate_ids = [r["tmdb_id"] for r in merged if 0.0 < r["progress"] < 98.0][:8]
    # candidate_ids = [r["tmdb_id"] for r in merged if 0.0 < r["progress"] < 98.0]
    _pool_map(_get_tmdb_movie_details_cached, candidate_ids)

    for row in merged:
        try:
            tmdb_id = row["tmdb_id"]
            progress = row["progress"]
            if not tmdb_id or progress <= 0.0 or progress >= 98.0:
                continue
            if tmdb_id in seen:
                continue
            title = (_get_tmdb_movie_details_cached(tmdb_id) or {}).get("title") or ""
            match_list = _find_all_index_matches("vod", title=title, tmdb_id=tmdb_id)
            if not match_list:
                continue
            seen.add(tmdb_id)
            out.append((tmdb_id, match_list, {"progress": progress}))
        except Exception:
            pass

    return out[:6]


def _get_continue_watching_series_items():
    out = []
    seen = set()

    try:
        playback_items = trakt_api.trakt_get_playback("series")
    except Exception:
        playback_items = []

    merged = []
    for item in playback_items or []:
        try:
            show = item.get("show") or {}
            ids = show.get("ids") or {}
            episode = item.get("episode") or {}
            merged.append(
                {
                    "tmdb_id": str(ids.get("tmdb") or ""),
                    "title": show.get("title") or "",
                    "progress": _safe_float(item.get("progress"), 0.0),
                    "season": str(episode.get("season") or ""),
                    "episode": str(episode.get("number") or ""),
                    "source": "trakt",
                }
            )
        except Exception:
            pass

    merged.sort(key=lambda x: x["progress"], reverse=True)

    candidate_ids = [
        r["tmdb_id"] for r in merged if 0.0 < r["progress"] < 98.0 and r["tmdb_id"]
    ][:8]
    #     candidate_ids = [
    #     r["tmdb_id"] for r in merged if 0.0 < r["progress"] < 98.0 and r["tmdb_id"]
    # ]
    _pool_map(_get_tmdb_series_details_cached, candidate_ids)

    for row in merged:
        try:
            tmdb_id = row["tmdb_id"]
            title = row["title"]
            progress = row["progress"]
            if not tmdb_id or progress <= 0.0 or progress >= 98.0:
                continue
            if tmdb_id in seen:
                continue
            match_list = _find_all_index_matches("series", title=title, tmdb_id=tmdb_id)
            if not match_list:
                continue
            seen.add(tmdb_id)
            out.append((tmdb_id, match_list, row))
        except Exception:
            pass

    return out[:6]


# ---------------------------------------------------------------------------
# Continue Watching version lists
# ---------------------------------------------------------------------------


def _find_current_vod_stream_from_match(index_entry, tmdb_id="", title=""):
    category_id = str(index_entry.get("category_id") or "")
    if not category_id:
        return None

    current_streams = _safe_stream_list("vod", category_id)
    if not isinstance(current_streams, list):
        return None

    wanted_tmdb = str(tmdb_id or "").strip()
    wanted_title = _normalize_title(title)

    exact_tmdb = []
    exact_title = []
    partial_title = []

    for stream in current_streams:
        try:
            stream_tmdb = _normalize_tmdb_id(_extract_tmdb_id(stream))
            stream_title = _normalize_title(
                stream.get("name")
                or stream.get("title")
                or stream.get("stream_display_name")
                or ""
            )
            if wanted_tmdb and stream_tmdb == wanted_tmdb:
                exact_tmdb.append(stream)
                continue
            if wanted_title and stream_title == wanted_title:
                exact_title.append(stream)
                continue
            if wanted_title and (
                wanted_title in stream_title or stream_title in wanted_title
            ):
                partial_title.append(stream)
        except Exception:
            pass

    if exact_tmdb:
        return exact_tmdb[0]
    if exact_title:
        return exact_title[0]
    if partial_title:
        return partial_title[0]
    return None


def list_continue_movie_versions(tmdb_id, title=""):
    tmdb_id = _normalize_tmdb_id(tmdb_id)
    if not tmdb_id:
        return

    details = _get_tmdb_movie_details_cached(tmdb_id) or {}
    art = (details.get("art") or {}) if details else {}

    resume_map = {}
    try:
        resume_map = trakt_api.trakt_get_movie_resume_map()
    except Exception:
        pass

    resume_data = resume_map.get(str(tmdb_id)) or {}
    progress = _safe_float(resume_data.get("progress"), 0.0)

    matches = _find_all_index_matches("vod", title="", tmdb_id=tmdb_id)
    if not matches and title:
        matches = _find_all_index_matches("vod", title=title, tmdb_id=tmdb_id)

    items = []

    for entry in matches:
        try:
            category_id = str(entry.get("category_id") or "")
            category_name = entry.get("category_name", "Movies")

            current_stream = _find_current_vod_stream_from_match(
                entry,
                tmdb_id=tmdb_id,
                title=title or entry.get("title") or entry.get("name") or "",
            )

            stream_id = ext = live_title = ""
            if current_stream:
                stream_id = str(
                    current_stream.get("stream_id")
                    or current_stream.get("movie_id")
                    or current_stream.get("vod_id")
                    or ""
                )
                ext = current_stream.get("container_extension", "mp4")
                live_title = (
                    current_stream.get("name")
                    or current_stream.get("title")
                    or current_stream.get("stream_display_name")
                    or ""
                )

            server_title = (
                live_title
                or entry.get("title")
                or entry.get("name")
                or title
                or "Continue Watching"
            )

            thumb = (
                art.get("thumb")
                or art.get("poster")
                or entry.get("thumb")
                or entry.get("poster")
                or ""
            )
            poster = art.get("poster") or thumb
            fanart = art.get("fanart") or poster
            icon = thumb or poster

            li = xbmcgui.ListItem(
                label=_label_with_marker(
                    "{} [COLOR grey]({})[/COLOR]".format(server_title, category_name),
                    progress=progress,
                    skip=False,
                )
            )
            li.setArt(_build_art(thumb=thumb, poster=poster, fanart=fanart, icon=icon))

            tag = li.getVideoInfoTag()
            _apply_basic_tag(
                tag,
                server_title,
                plot=details.get("plot", ""),
                media_type="movie",
                year=details.get("year"),
                rating=details.get("rating"),
            )

            if tmdb_id:
                li.setProperty("tmdbnumber", str(tmdb_id))
                li.setProperty("imdbnumber", str(tmdb_id))
                try:
                    tag.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")
                except Exception:
                    pass

            plot_value = details.get("plot") or ""
            rating_value = details.get("rating") or 0
            year_value = details.get("year") or 0

            play_url = ""
            if stream_id:
                try:
                    play_url = xtream_api.build_stream_url(
                        stream_id=stream_id,
                        stream_type="vod",
                        container_extension=ext,
                    )
                except Exception:
                    play_url = ""

            metadata = {
                "thumb": thumb,
                "poster": poster,
                "fanart": fanart,
                "icon": icon,
                "plot": plot_value,
                "rating": rating_value,
                "year": year_value,
                "tmdb_id": str(tmdb_id),
                "stream_type": "vod",
                "stream_id": stream_id,
            }

            if play_url:
                li.setProperty("IsPlayable", "true")
                url = _plugin_url(
                    mode="play_stream",
                    url=play_url,
                    name=server_title,
                    meta=_encode_meta(metadata),
                )
                menu_url = _build_stream_menu_url(
                    item_id=stream_id,
                    name=server_title,
                    play_url=play_url,
                    stream_type="vod",
                    thumb=thumb,
                    poster=poster,
                    fanart=fanart,
                    icon=icon,
                    plot=plot_value,
                    rating=str(rating_value or "0"),
                    year=str(year_value or "0"),
                    tmdb_id=str(tmdb_id),
                    category_id=category_id,
                    category_name=category_name,
                    favourite_kind="playable",
                    target_mode="play_stream",
                    resume_progress=str(progress or 0),
                )
                _add_giptv_context_menu(li, menu_url)
                items.append((url, li, False))
            else:
                menu_url = _build_stream_menu_url(
                    item_id=str(entry.get("id") or ""),
                    name=server_title,
                    play_url="",
                    stream_type="vod",
                    thumb=thumb,
                    poster=poster,
                    fanart=fanart,
                    icon=icon,
                    plot=plot_value,
                    rating=str(rating_value or "0"),
                    year=str(year_value or "0"),
                    tmdb_id=str(tmdb_id),
                    category_id=category_id,
                    category_name=category_name,
                    favourite_kind="playable",
                    target_mode="list_streams",
                    resume_progress=str(progress or 0),
                )
                _add_giptv_context_menu(li, menu_url)
                items.append(
                    (
                        _plugin_url(
                            mode="list_streams",
                            stream_type="vod",
                            category_id=category_id,
                            name=category_name,
                            search_query=_normalize_search_query(server_title),
                            page="1",
                        ),
                        li,
                        True,
                    )
                )

        except Exception as e:
            giptv.log(
                "[CONTINUE MOVIE VERSIONS] row failed: {}".format(e), xbmc.LOGWARNING
            )

    xbmcplugin.setPluginCategory(
        PLUGIN_HANDLE, "Sources for {}".format(title or "Continue Watching")
    )
    xbmcplugin.setContent(PLUGIN_HANDLE, "movies")
    _add_dir_items(items)


def list_continue_series_versions(tmdb_id, title=""):

    tmdb_id = _normalize_tmdb_id(tmdb_id)
    if not tmdb_id:
        return

    details = _get_tmdb_series_details_cached(tmdb_id) or {}
    series_art = (details.get("art") or {}) if details else {}

    try:
        playback_items = trakt_api.trakt_get_playback("series")
    except Exception:
        playback_items = []

    target_playback = None
    for item in playback_items or []:
        try:
            show = item.get("show") or {}
            ids = show.get("ids") or {}
            progress = _safe_float(item.get("progress"), 0.0)
            if str(ids.get("tmdb") or "") == str(tmdb_id) and 0.0 < progress < 98.0:
                target_playback = item
                break
        except Exception:
            pass

    if not target_playback:
        _add_dir_items([])
        return

    show = target_playback.get("show") or {}
    if not title:
        title = show.get("title") or details.get("title") or "Continue Watching"

    episode = target_playback.get("episode") or {}
    season_num = str(episode.get("season") or "")
    episode_num = str(episode.get("number") or "")
    progress = _safe_float(target_playback.get("progress"), 0.0)

    if not season_num or not episode_num:
        _add_dir_items([])
        return

    matches = _find_all_index_matches("series", title=title, tmdb_id=tmdb_id)
    items = []

    for entry in matches:
        try:
            series_id = entry.get("id") or entry.get("series_id") or ""
            if not series_id:
                continue

            series_info = cache_handler.get(
                "series_info", f"{STATE.username}_{series_id}"
            )
            if not series_info:
                series_info = xtream_api.series_info_by_id(series_id)

            if not isinstance(series_info, dict):
                continue

            episodes_map = series_info.get("episodes", {}) or {}
            season_eps = episodes_map.get(str(season_num), []) or episodes_map.get(
                int(season_num), []
            )

            found_episode = next(
                (
                    ep
                    for ep in season_eps
                    if str(ep.get("episode_num", "")) == str(episode_num)
                ),
                None,
            )
            if not found_episode:
                continue

            stream_id = found_episode.get("id")
            ext = found_episode.get("container_extension", "mp4")
            play_url = xtream_api.build_stream_url(
                stream_id=stream_id,
                stream_type="series",
                container_extension=ext,
            )
            if not play_url:
                continue

            server_episode_title = (
                found_episode.get("title")
                or (found_episode.get("info") or {}).get("title")
                or "Episode {}".format(episode_num)
            )
            display_title = "S{:02d}E{:02d} - {}".format(
                int(season_num), int(episode_num), server_episode_title
            )

            tmdb_ep_details = (
                _get_tmdb_episode_details_cached(
                    tmdb_id, int(season_num), int(episode_num)
                )
                or {}
            )
            ep_art = tmdb_ep_details.get("art") or {}
            season_data = (
                _get_tmdb_season_details_cached(tmdb_id, int(season_num)) or {}
            )
            season_art = season_data.get("art") or {}

            thumb = (
                ep_art.get("thumb")
                or ep_art.get("still")
                or season_art.get("poster")
                or series_art.get("poster")
                or found_episode.get("movie_image")
                or found_episode.get("thumbnail")
                or ""
            )
            if thumb and str(thumb).startswith("/"):
                thumb = "https://image.tmdb.org/t/p/original{}".format(thumb)

            poster = season_art.get("poster") or series_art.get("poster") or thumb
            fanart = (
                ep_art.get("fanart")
                or season_art.get("fanart")
                or series_art.get("fanart")
                or poster
            )
            icon = thumb or poster

            plot_value = tmdb_ep_details.get("overview") or ""
            rating_value = tmdb_ep_details.get("vote_average") or 0
            air_date = tmdb_ep_details.get("air_date") or ""
            year_value = (
                air_date[:4] if len(air_date) >= 4 and air_date[:4].isdigit() else "0"
            )

            li = xbmcgui.ListItem(
                label=_label_with_marker(
                    "{} [COLOR grey]({})[/COLOR]".format(
                        display_title, entry.get("category_name", "TV Series")
                    ),
                    progress=progress,
                    skip=False,
                )
            )
            li.setArt(_build_art(thumb=thumb, poster=poster, fanart=fanart, icon=icon))
            li.setProperty("IsPlayable", "true")

            tag = li.getVideoInfoTag()
            tag.setTitle(server_episode_title)
            tag.setTvShowTitle(entry.get("title") or entry.get("name") or title or "")
            tag.setSeason(int(season_num))
            tag.setEpisode(int(episode_num))
            tag.setMediaType("episode")
            tag.setPlot(plot_value)
            try:
                if rating_value:
                    tag.setRating(float(rating_value), 10)
            except Exception:
                pass
            if air_date:
                try:
                    tag.setFirstAired(air_date)
                except Exception:
                    pass
            try:
                if year_value and str(year_value).isdigit():
                    tag.setYear(int(year_value))
            except Exception:
                pass
            if tmdb_id:
                try:
                    tag.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")
                except Exception:
                    pass
                li.setProperty("tmdbnumber", str(tmdb_id))
                li.setProperty("season", str(season_num))
                li.setProperty("episode", str(episode_num))

            metadata = {
                "thumb": thumb,
                "poster": poster,
                "fanart": fanart,
                "icon": icon,
                "plot": plot_value,
                "rating": rating_value,
                "year": year_value,
                "tmdb_id": str(tmdb_id),
                "stream_type": "series",
                "stream_id": str(stream_id or ""),
                "series_id": str(series_id or ""),
                "series_name": entry.get("title") or entry.get("name") or title or "",
                "season": str(season_num),
                "episode": str(episode_num),
            }

            url = _plugin_url(
                mode="play_stream",
                url=play_url,
                name=display_title,
                meta=_encode_meta(metadata),
            )

            menu_url = _build_stream_menu_url(
                item_id=str(stream_id or ""),
                name=display_title,
                play_url=play_url,
                stream_type="series",
                thumb=thumb,
                poster=poster,
                fanart=fanart,
                icon=icon,
                plot=plot_value,
                rating=str(rating_value or "0"),
                year=str(year_value or "0"),
                tmdb_id=str(tmdb_id),
                season=str(season_num),
                episode=str(episode_num),
                favourite_kind="playable",
                target_mode="play_stream",
                series_id=str(series_id),
                series_name=entry.get("title") or entry.get("name") or title,
                season_num=str(season_num),
                resume_progress=str(progress or 0),
            )
            _add_giptv_context_menu(li, menu_url)
            items.append((url, li, False))

        except Exception as e:
            giptv.log(
                "[CONTINUE SERIES VERSIONS] row failed: {}".format(e), xbmc.LOGWARNING
            )

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, title or "Continue Watching")
    xbmcplugin.setContent(PLUGIN_HANDLE, "episodes")
    _add_dir_items(items)


# ---------------------------------------------------------------------------
# EPG helpers
# ---------------------------------------------------------------------------


def _build_live_plot(now_data, next_data, epg_offset_minutes=0):
    """
    Build the EPG plot string for a live channel.

    start_ts/end_ts are UTC unix timestamps.
    datetime.fromtimestamp() displays them in local system time.
    epg_offset_minutes is only a manual fine-tune adjustment.
    """
    title, desc, start_ts, end_ts = now_data
    duration = max(0, int(end_ts) - int(start_ts))

    fine = int(epg_offset_minutes or 0) * 60

    display_start_ts = int(start_ts) + fine
    display_end_ts = int(end_ts) + fine

    # Progress should use real UTC timestamps, not display-shifted timestamps.
    pct = _epg_progress(int(start_ts), int(end_ts))
    bar = _progress_bar(pct)

    short_desc = (desc or "").strip()
    if len(short_desc) > 350:
        short_desc = short_desc[:350] + "..."

    plot_lines = [
        f"[COLOR yellow][B]Now: {title}[/B][/COLOR] "
        f"[COLOR grey][I]{_fmt_time(display_start_ts)} – {_fmt_time(display_end_ts)}[/I][/COLOR]",
        f"[COLOR green]{bar}  {pct}%[/COLOR]",
    ]

    if short_desc:
        plot_lines.append(f"[COLOR white]{short_desc}[/COLOR]")

    if next_data:
        next_title, next_desc, next_start, next_end = next_data
        next_start_display = int(next_start) + fine
        next_end_display = int(next_end) + fine

        plot_lines.append(
            f"[COLOR yellow][B]Next: {next_title}[/B][/COLOR] "
            f"[COLOR grey][I]{_fmt_time(next_start_display)} – {_fmt_time(next_end_display)}[/I][/COLOR]"
        )

        next_short_desc = (next_desc or "").strip()
        if next_short_desc:
            if len(next_short_desc) > 160:
                next_short_desc = next_short_desc[:160] + "..."
            plot_lines.append(f"[COLOR grey]{next_short_desc}[/COLOR]")

    return title, "\n".join(plot_lines), duration


def get_direct_epg_index():
    """
    Read the EPG JSON cache directly from disk.

    Delegate path resolution to epg_manager so this stays consistent with the
    patched _cache_filename() logic.
    """
    if not _ensure_ready():
        return {}

    try:
        from resources.lib.manager.epg_manager import _cache_path

        path = _cache_path()
        if not xbmcvfs.exists(path):
            return {}

        f = xbmcvfs.File(path, "r")
        try:
            raw_data = f.read()
        finally:
            f.close()

        return json.loads(raw_data).get("index", {})

    except Exception as e:
        giptv.log(f"[EPG] direct cache read failed: {e}", xbmc.LOGWARNING)
        return {}


def _load_xmltv_index_with_retry(retries=3, delay_ms=300):
    for attempt in range(retries):
        index = get_xmltv_index() or {}
        if index:
            giptv.log(
                f"[EPG] XMLTV index loaded on attempt {attempt + 1} with {len(index)} channels",
                xbmc.LOGINFO,
            )
            return index
        giptv.log(
            f"[EPG] XMLTV index empty on attempt {attempt + 1}, retrying...",
            xbmc.LOGWARNING,
        )
        xbmc.sleep(delay_ms)
    giptv.log("[EPG] XMLTV index still empty after retries", xbmc.LOGWARNING)
    return {}


# ---------------------------------------------------------------------------
# Favourite Helpers
# ---------------------------------------------------------------------------

FAVOURITES_PATH = xbmcvfs.translatePath(
    "special://profile/addon_data/{}/favourites.json".format(ADDON_ID)
)
_FAVOURITES_CACHE = None
_FAVOURITES_IDENTITY_INDEX = set()
_SAVED_ITEMS_WRITE_LOCK = threading.RLock()


def _atomic_write_json(path, data):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)
    temp_path = "{}.{}.{}.tmp".format(
        path, os.getpid(), threading.current_thread().ident
    )
    with _SAVED_ITEMS_WRITE_LOCK:
        with open(temp_path, "w", encoding="utf-8") as handle:
            json.dump(data, handle, separators=(",", ":"))
            handle.flush()
        os.replace(temp_path, path)


def invalidate_saved_items_cache():
    global _FAVOURITES_CACHE, _FAVOURITES_IDENTITY_INDEX, _HISTORY_CACHE
    _FAVOURITES_CACHE = None
    _FAVOURITES_IDENTITY_INDEX = set()
    _HISTORY_CACHE = None


def _get_active_account_suffix():
    try:
        selected = ADDON.getSetting("account")
    except Exception:
        selected = ""
    if selected == "1":
        return "1"
    if selected == "2":
        return "2"
    return ""


def _get_setting_with_suffix(base_key):
    suffix = _get_active_account_suffix()
    key = "{}{}".format(base_key, suffix) if suffix else base_key
    try:
        return str(ADDON.getSetting(key) or "").strip()
    except Exception:
        return ""


def _favourites_current_server_user():
    try:
        username = _get_setting_with_suffix("username")
        if username:
            return username
        return str(getattr(STATE, "username", "") or "").strip()
    except Exception:
        return ""


def _favourites_current_server_url():
    try:
        server = _get_setting_with_suffix("server")
        if server:
            return server.rstrip("/")
        return str(getattr(STATE, "server", "") or "").strip().rstrip("/")
    except Exception:
        return ""


def _favourites_current_server_key():
    server = _favourites_current_server_url()
    username = _favourites_current_server_user()
    if not server and not username:
        return ""
    return "{}|{}".format(server.rstrip("/"), username.strip())


def _same_favourite_identity(item, item_id, server_key):
    return str(item.get("id")) == str(item_id) and str(
        item.get("server_key") or ""
    ) == str(server_key or "")


def _legacy_item_matches_current_server(item):
    current_user = _favourites_current_server_user()
    current_server = _favourites_current_server_url()

    if not current_user and not current_server:
        return True

    saved_user = str(item.get("server_user") or "").strip()
    if saved_user and current_user:
        return saved_user == current_user

    play_url = str(item.get("play_url") or "").strip()
    if not play_url:
        return False

    if current_server and current_server in play_url:
        return (not current_user) or (current_user in play_url)

    return current_user and current_user in play_url


def _favourite_matches_current_server(item):
    current_key = _favourites_current_server_key()
    if not current_key:
        return True
    saved_key = str(item.get("server_key") or "").strip()
    if saved_key:
        return saved_key == current_key
    return _legacy_item_matches_current_server(item)


def _filter_favourites_for_current_server(items):
    return [item for item in (items or []) if _favourite_matches_current_server(item)]


def _normalize_saved_favourite_type(item):
    favourite_kind = str(item.get("favourite_kind") or "").strip().lower()
    play_url = str(item.get("play_url") or "").strip().lower()
    channel_id = str(item.get("channel_id") or "").strip()
    current_type = str(item.get("type") or "").strip().lower()

    if favourite_kind in ("series_folder", "season_folder"):
        item["type"] = "series"
        return item
    if channel_id or "/live/" in play_url:
        item["type"] = "live"
        return item
    if "/series/" in play_url:
        item["type"] = "series"
        return item
    if "/movie/" in play_url or "/vod/" in play_url:
        item["type"] = "vod"
        return item
    item["type"] = current_type if current_type in ("live", "vod", "series") else "vod"
    return item


def _read_favourites():
    global _FAVOURITES_CACHE, _FAVOURITES_IDENTITY_INDEX

    if _FAVOURITES_CACHE is not None:
        return _FAVOURITES_CACHE
    if not xbmcvfs.exists(FAVOURITES_PATH):
        _FAVOURITES_CACHE = []
        _FAVOURITES_IDENTITY_INDEX = set()
        return []
    try:
        f = xbmcvfs.File(FAVOURITES_PATH, "r")
        data = json.loads(f.read())
        f.close()
    except Exception:
        return []
    cleaned = _autoclean_favourites(data)
    _FAVOURITES_CACHE = cleaned
    _FAVOURITES_IDENTITY_INDEX = {
        (str(item.get("id")), str(item.get("server_key") or ""))
        for item in cleaned
    }
    if cleaned != data:
        _write_favourites(cleaned)
    return cleaned


def _sort_favourites(items, mode):
    if not mode:
        return items
    if mode == "recent":
        return sorted(
            items, key=lambda x: x.get("added_at", x.get("timestamp", 0)), reverse=True
        )
    if mode == "oldest":
        return sorted(items, key=lambda x: x.get("added_at", x.get("timestamp", 0)))
    if mode == "za":
        return sorted(
            items, key=lambda x: _normalize_title(x.get("title", "")), reverse=True
        )
    return sorted(items, key=lambda x: _normalize_title(x.get("title", "")))


def _write_favourites(data):
    global _FAVOURITES_CACHE, _FAVOURITES_IDENTITY_INDEX

    _FAVOURITES_CACHE = data
    _FAVOURITES_IDENTITY_INDEX = {
        (str(item.get("id")), str(item.get("server_key") or ""))
        for item in data or []
    }
    try:
        _atomic_write_json(FAVOURITES_PATH, data)
    except Exception:
        pass


def _autoclean_favourites(data):
    now_ts = int(time.time())
    cleaned = []
    for item in data or []:
        item_id = item.get("id")
        if not item_id:
            continue
        favourite_kind = item.get("favourite_kind", "playable")
        stored_play_url = str(item.get("play_url") or "")

        if not item.get("server_key"):
            user = str(item.get("server_user") or "").strip()
            play_url = str(item.get("play_url") or "").strip()
            server = ""
            if play_url.startswith("http"):
                parts = play_url.split("/")
                if len(parts) >= 3:
                    server = parts[0] + "//" + parts[2]
            if not server and user and user == _favourites_current_server_user():
                server = _favourites_current_server_url()
            if server or user:
                item["server_key"] = "{}|{}".format(server.rstrip("/"), user)

        if favourite_kind == "playable":
            if not stored_play_url or "." not in stored_play_url:
                continue
            if (
                "None" in stored_play_url
                or stored_play_url.endswith("/")
                or stored_play_url.endswith("..")
            ):
                continue

        item.setdefault("added_at", item.get("timestamp", now_ts))
        item.setdefault("server_user", "")
        item.setdefault("server_key", "")
        item.setdefault("episode", "")

        item = _normalize_saved_favourite_type(item)
        cleaned.append(item)
    return cleaned


def _coerce_series_favourite_target(
    item_id,
    title,
    stream_type,
    play_url="",
    thumb="",
    poster="",
    fanart="",
    icon="",
    plot="",
    rating=0,
    year=0,
    tmdb_id="",
    channel_id="",
    stream_id="",
    favourite_kind="playable",
    target_mode="",
    series_id="",
    series_name="",
    season_num="",
    episode="",
):
    base = {
        "item_id": item_id,
        "title": title,
        "stream_type": stream_type,
        "play_url": play_url,
        "thumb": thumb,
        "poster": poster,
        "fanart": fanart,
        "icon": icon,
        "plot": plot,
        "rating": rating,
        "year": year,
        "tmdb_id": tmdb_id,
        "channel_id": channel_id,
        "stream_id": stream_id,
        "favourite_kind": favourite_kind,
        "target_mode": target_mode,
        "series_id": series_id,
        "series_name": series_name,
        "season_num": season_num,
        "episode": episode,
    }
    if str(stream_type or "") != "series":
        return base

    if favourite_kind in ("playable", "season_folder") and series_id:
        return {
            **base,
            "item_id": str(series_id),
            "title": series_name or title,
            "play_url": "",
            "channel_id": "",
            "stream_id": "",
            "favourite_kind": "series_folder",
            "target_mode": "list_series_seasons",
            "series_id": str(series_id),
            "series_name": series_name or title,
            "season_num": "",
            "episode": "",
        }
    return base


def add_favourite(
    item_id,
    title,
    stream_type,
    play_url="",
    thumb="",
    poster="",
    fanart="",
    icon="",
    plot="",
    rating=0,
    year=0,
    tmdb_id="",
    channel_id="",
    stream_id="",
    favourite_kind="playable",
    target_mode="",
    series_id="",
    series_name="",
    season_num="",
    episode="",
    has_archive="0",
    epg_channel_id="",
):
    payload_args = _coerce_series_favourite_target(
        item_id=item_id,
        title=title,
        stream_type=stream_type,
        play_url=play_url,
        thumb=thumb,
        poster=poster,
        fanart=fanart,
        icon=icon,
        plot=plot,
        rating=rating,
        year=year,
        tmdb_id=tmdb_id,
        channel_id=channel_id,
        stream_id=stream_id,
        favourite_kind=favourite_kind,
        target_mode=target_mode,
        series_id=series_id,
        series_name=series_name,
        season_num=season_num,
        episode=episode,
    )

    data = _read_favourites()
    now_ts = int(time.time())
    current_server_key = _favourites_current_server_key()
    item_id = payload_args["item_id"]

    data = [
        i for i in data if not _same_favourite_identity(i, item_id, current_server_key)
    ]

    payload = {
        "id": item_id,
        "title": payload_args["title"],
        "type": payload_args["stream_type"],
        "thumb": payload_args["thumb"] or "",
        "poster": payload_args["poster"] or "",
        "fanart": payload_args["fanart"] or "",
        "icon": payload_args["icon"] or "",
        "plot": payload_args["plot"] or "",
        "rating": payload_args["rating"] or 0,
        "year": payload_args["year"] or 0,
        "tmdb_id": payload_args["tmdb_id"] or "",
        "play_url": payload_args["play_url"] or "",
        "channel_id": payload_args["channel_id"] or "",
        "stream_id": str(payload_args["stream_id"] or ""),
        "is_live_epg": (payload_args["stream_type"] == "live"),
        "timestamp": now_ts,
        "added_at": now_ts,
        "favourite_kind": payload_args["favourite_kind"] or "playable",
        "target_mode": payload_args["target_mode"] or "",
        "series_id": str(payload_args["series_id"] or ""),
        "series_name": payload_args["series_name"] or "",
        "season_num": str(payload_args["season_num"] or ""),
        "episode": str(payload_args["episode"] or ""),
        "has_archive": str(has_archive or "0"),
        "epg_channel_id": str(epg_channel_id or channel_id or ""),
        "server_user": _favourites_current_server_user(),
        "server_key": current_server_key,
    }
    payload = _normalize_saved_favourite_type(payload)
    data.insert(0, payload)
    _write_favourites(data)


def add_favourite_from_params(
    item_id,
    title,
    stream_type,
    play_url="",
    thumb="",
    poster="",
    fanart="",
    icon="",
    plot="",
    rating=0,
    year=0,
    tmdb_id="",
    channel_id="",
    stream_id="",
    favourite_kind="playable",
    target_mode="",
    series_id="",
    series_name="",
    season_num="",
    episode="",
    has_archive="0",
    epg_channel_id="",
):
    add_favourite(
        item_id=item_id,
        title=title,
        stream_type=stream_type,
        play_url=play_url,
        thumb=thumb,
        poster=poster,
        fanart=fanart,
        icon=icon,
        plot=plot,
        rating=rating,
        year=year,
        tmdb_id=tmdb_id,
        channel_id=channel_id,
        stream_id=stream_id,
        favourite_kind=favourite_kind,
        target_mode=target_mode,
        series_id=series_id,
        series_name=series_name,
        season_num=season_num,
        episode=episode,
        has_archive=has_archive,
        epg_channel_id=epg_channel_id,
    )


def remove_favourite(item_id):
    data = _read_favourites()
    current_server_key = _favourites_current_server_key()
    data = [
        i for i in data if not _same_favourite_identity(i, item_id, current_server_key)
    ]
    _write_favourites(data)


def remove_favourite_from_params(item_id):
    remove_favourite(item_id)


def is_favourite(item_id):
    item_id = str(item_id)
    current_server_key = _favourites_current_server_key()
    favourites = _read_favourites()
    if (item_id, current_server_key) in _FAVOURITES_IDENTITY_INDEX:
        return True
    # Only legacy entries without a server key need the slower compatibility
    # matcher. Normal favourites use the constant-time identity index above.
    return any(
        str(item.get("id")) == item_id and _favourite_matches_current_server(item)
        for item in favourites
        if not item.get("server_key")
    )


def _build_favourite_folder_url(entry):
    target_mode = entry.get("target_mode", "")
    series_id = entry.get("series_id", "")
    series_name = entry.get("series_name", "") or entry.get("title", "")
    season_num = entry.get("season_num", "")
    poster = entry.get("poster", "")
    fanart = entry.get("fanart", "")
    tmdb_id = entry.get("tmdb_id", "")

    if target_mode == "list_series_seasons" and series_id:
        return _plugin_url(
            mode="list_series_seasons", series_id=series_id, series_name=series_name
        )
    if target_mode == "list_series_episodes" and series_id and season_num:
        return _plugin_url(
            mode="list_series_episodes",
            series_id=series_id,
            season_num=season_num,
            series_name=series_name,
            series_poster=poster,
            series_fanart=fanart,
            tmdb_id=tmdb_id,
        )
    return ""


def _get_series_info_cached_for_favourites(series_id):
    if not series_id:
        return None
    try:
        data = cache_handler.get("series_info", f"{STATE.username}_{series_id}")
        if not data:
            data = xtream_api.series_info_by_id(series_id)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return None


def _folder_exists_on_current_server(entry):
    stream_type = str(entry.get("type") or "")
    favourite_kind = str(entry.get("favourite_kind") or "")
    series_id = str(entry.get("series_id") or "")

    if stream_type != "series":
        return True
    if favourite_kind in ("series_folder", "season_folder"):
        if not series_id:
            return False
        data = _get_series_info_cached_for_favourites(series_id)
        return isinstance(data, dict) and bool(data.get("episodes"))
    return True


def _apply_saved_availability(title, plot, entry):
    if str(entry.get("availability") or "") != "missing":
        return title, plot
    warning = "This saved item is no longer present in the provider inventory."
    marked_title = "[COLOR red][Unavailable][/COLOR] {}".format(title)
    marked_plot = "[COLOR red]{}[/COLOR][CR][CR]{}".format(warning, plot or "")
    return marked_title, marked_plot


def list_favourites():
    from resources.lib.manager import sort_manager

    favourites = _filter_favourites_for_current_server(_read_favourites())

    sort_mode = sort_manager.get_current_sort("favourites", "main")
    sort_label = sort_manager.get_sort_label("favourites", "main")
    favourites = _sort_favourites(favourites, sort_mode)

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, "Favourites")
    xbmcplugin.setContent(PLUGIN_HANDLE, "videos")

    if not favourites:
        item = xbmcgui.ListItem("No favourites yet for this server.")
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, "", item, isFolder=False)
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    movie_resume_map = {}
    watched_movie_ids = set()
    watched_episode_keys_by_show = {}
    episode_resume_map_by_show = {}

    if _is_trakt_ready():
        try:
            movie_resume_map = trakt_api.trakt_get_movie_resume_map() or {}
            watched_movie_ids = trakt_api.trakt_get_watched_movie_ids() or set()
            tv_maps = trakt_api.trakt_get_tv_progress_maps() or {}
            watched_episode_keys_by_show = (
                tv_maps.get("watched_episode_keys_by_show", {}) or {}
            )
            episode_resume_map_by_show = (
                tv_maps.get("episode_resume_map_by_show", {}) or {}
            )
        except Exception:
            pass

    xmltv_index = {}
    has_live = any(
        str(entry.get("type", "")).strip().lower() == "live"
        or str(entry.get("channel_id", "")).strip() != ""
        for entry in favourites
    )
    if has_live:
        xmltv_index = _load_xmltv_index_with_retry(retries=4, delay_ms=400)

    legacy_archive_map = {}
    if any(
        str(entry.get("type", "")).lower() == "live" and "has_archive" not in entry
        for entry in favourites
    ):
        try:
            legacy_archive_map = {
                str(stream.get("stream_id", "")): str(
                    stream.get("tv_archive", stream.get("has_archive", "0"))
                )
                for stream in xtream_api.get_all_live_streams_unfiltered()
            }
        except Exception:
            legacy_archive_map = {}

    sort_item = xbmcgui.ListItem(label=f"[COLOR cyan]{sort_label}[/COLOR]")
    sort_item.setArt({"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(
        PLUGIN_HANDLE,
        giptv.build_url(
            action="cycle_sort",
            directory_type="favourites",
            directory_id="main",
            refresh_mode="favourites",
        ),
        sort_item,
        isFolder=False,
    )

    for entry in favourites:
        title = entry.get("title", "Unknown")
        thumb = entry.get("thumb", "")
        poster = entry.get("poster", "")
        fanart = entry.get("fanart", "")
        icon = entry.get("icon", "")
        plot = entry.get("plot", "")
        rating = entry.get("rating", 0)
        year = entry.get("year", 0)
        tmdb_id = str(entry.get("tmdb_id", "") or "")
        play_url = entry.get("play_url", "")
        stream_type = str(entry.get("type", "vod") or "vod").strip().lower()
        stream_id = entry.get("stream_id") or entry.get("id", "")
        channel_id = entry.get("channel_id", "")
        favourite_kind = entry.get("favourite_kind", "playable")
        series_id = str(entry.get("series_id", "") or "")
        season_num = str(entry.get("season_num", "") or "")
        episode_num = str(entry.get("episode", "") or "")

        if favourite_kind in ("series_folder", "season_folder"):
            if (
                entry.get("availability") != "missing"
                and not _folder_exists_on_current_server(entry)
            ):
                continue

        play_url_lower = str(play_url or "").lower()
        if favourite_kind not in ("series_folder", "season_folder"):
            if channel_id or "/live/" in play_url_lower:
                stream_type = "live"

        display_title = title
        display_plot = plot
        watched_flag = False
        progress_value = None

        if stream_type == "live" and channel_id:
            data = (
                get_now_next(xmltv_index, channel_id, settings.get_epg_offset(ADDON))
                if xmltv_index
                else None
            )
            if data and data.get("now"):
                _, live_plot, _ = _build_live_plot(
                    data["now"], data.get("next"), settings.get_epg_offset(ADDON)
                )
                display_plot = live_plot

        elif stream_type == "vod" and tmdb_id:
            watched_flag = tmdb_id in watched_movie_ids
            if not watched_flag:
                resume_info = movie_resume_map.get(tmdb_id) or {}
                progress_value = resume_info.get("progress")

        elif stream_type == "series" and tmdb_id:
            watched_episode_keys = (
                watched_episode_keys_by_show.get(tmdb_id, set()) or set()
            )
            episode_resume_map = episode_resume_map_by_show.get(tmdb_id, {}) or {}

            if favourite_kind == "series_folder":
                episodes_by_season = {}
                series_info_response = _get_series_info_cached_for_favourites(series_id)
                if isinstance(series_info_response, dict):
                    episodes_by_season = series_info_response.get("episodes", {}) or {}
                watched_flag, progress_value = _show_rollup_from_episode_maps(
                    episodes_by_season,
                    watched_episode_keys,
                    episode_resume_map,
                )
            elif favourite_kind == "season_folder" and season_num:
                season_episodes = []
                series_info_response = _get_series_info_cached_for_favourites(series_id)
                if isinstance(series_info_response, dict):
                    episodes_by_season = series_info_response.get("episodes", {}) or {}
                    season_episodes = episodes_by_season.get(
                        str(season_num), []
                    ) or episodes_by_season.get(season_num, [])
                watched_flag, progress_value = _season_rollup_from_episode_maps(
                    season_num,
                    season_episodes,
                    watched_episode_keys,
                    episode_resume_map,
                )
            else:
                if season_num and episode_num:
                    ep_key = (str(season_num), str(episode_num))
                    watched_flag = ep_key in watched_episode_keys
                    if not watched_flag:
                        resume_info = episode_resume_map.get(ep_key) or {}
                        progress_value = resume_info.get("progress")

        display_title, display_plot = _apply_saved_availability(
            display_title, display_plot, entry
        )

        li = xbmcgui.ListItem(
            label=_label_with_marker(
                display_title, watched=watched_flag, progress=progress_value, skip=False
            )
        )
        li.setArt(
            _build_art(
                thumb=thumb,
                poster=poster,
                fanart=fanart,
                icon=icon,
                fallback="DefaultVideo.png",
            )
        )

        tag = li.getVideoInfoTag()
        try:
            tag.setTitle(display_title)
        except Exception:
            pass
        try:
            tag.setPlot(display_plot)
        except Exception:
            pass

        try:
            if stream_type == "series":
                if favourite_kind == "series_folder":
                    tag.setMediaType("tvshow")
                elif favourite_kind == "season_folder":
                    tag.setMediaType("season")
                else:
                    tag.setMediaType("episode")
                    if season_num:
                        tag.setSeason(int(season_num))
                    if episode_num:
                        tag.setEpisode(int(episode_num))
            elif stream_type == "vod":
                tag.setMediaType("movie")
            else:
                tag.setMediaType("video")
        except Exception:
            pass

        _set_tag_year(tag, year)
        _set_tag_rating(tag, rating)

        if tmdb_id:
            li.setProperty("tmdbnumber", str(tmdb_id))
            li.setProperty("imdbnumber", str(tmdb_id))
            try:
                tag.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")
            except Exception:
                pass

        if watched_flag:
            li.setProperty("playcount", "1")
            try:
                tag.setPlaycount(1)
            except Exception:
                pass

        custom_menu_url = _build_stream_menu_url(
            item_id=str(entry.get("id", "")),
            name=title,
            play_url=play_url,
            stream_type=stream_type,
            thumb=thumb,
            poster=poster,
            fanart=fanart,
            icon=icon,
            plot=display_plot,
            rating=str(rating),
            year=str(year),
            tmdb_id=tmdb_id,
            channel_id=channel_id,
            epg_channel_id=entry.get("epg_channel_id", "") or channel_id,
            has_archive=entry.get(
                "has_archive", legacy_archive_map.get(str(stream_id), "0")
            ),
            directory_type="favourites",
            directory_id="main",
            refresh_mode="favourites",
            sort_label=sort_label,
            category_name="Favourites",
            favourite_kind=favourite_kind,
            target_mode=entry.get("target_mode", ""),
            series_id=series_id,
            series_name=entry.get("series_name", ""),
            season_num=season_num,
            season=season_num,
            episode=episode_num,
            resume_progress=str(0 if watched_flag else (progress_value or 0)),
        )
        _add_giptv_context_menu(li, custom_menu_url)

        if favourite_kind in ("series_folder", "season_folder"):
            folder_url = _build_favourite_folder_url(entry)
            if not folder_url:
                continue
            xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, folder_url, li, isFolder=True)
        else:
            meta = {
                "thumb": thumb,
                "poster": poster,
                "fanart": fanart,
                "icon": icon,
                "plot": display_plot,
                "rating": rating,
                "year": year,
                "tmdb_id": tmdb_id,
                "stream_type": stream_type,
                "channel_id": channel_id,
                "stream_id": stream_id,
                "season": season_num,
                "episode": episode_num,
            }
            plugin_url = _plugin_url(
                mode="play_stream",
                url=play_url,
                id=stream_id,
                type=stream_type,
                name=title,
                meta=_encode_meta(meta),
            )
            li.setProperty("IsPlayable", "true")
            if stream_type == "live":
                li.setProperty("IsLive", "true")
            xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, plugin_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# ---------------------------------------------------------------------------
# History helpers
# ---------------------------------------------------------------------------

HISTORY_PATH = xbmcvfs.translatePath(
    "special://profile/addon_data/{}/watch_history.json".format(ADDON_ID)
)
_HISTORY_CACHE = None


def _history_current_server_key():
    server = _favourites_current_server_url()
    username = _favourites_current_server_user()
    if not server and not username:
        return ""
    return "{}|{}".format(server.rstrip("/"), username.strip())


def _same_history_identity(item, item_id, server_key):
    return str(item.get("id")) == str(item_id) and str(
        item.get("server_key") or ""
    ) == str(server_key or "")


def _normalize_saved_history_type(item):
    play_url = str(item.get("play_url") or "").strip().lower()
    channel_id = str(item.get("channel_id") or "").strip()
    current_type = str(item.get("type") or "").strip().lower()

    if channel_id or "/live/" in play_url or "/timeshift/" in play_url:
        item["type"] = "live"
        return item
    if "/series/" in play_url:
        item["type"] = "series"
        return item
    if "/movie/" in play_url or "/vod/" in play_url:
        item["type"] = "vod"
        return item
    item["type"] = current_type if current_type in ("live", "vod", "series") else "vod"
    return item


def _read_history():
    global _HISTORY_CACHE
    if _HISTORY_CACHE is not None:
        return _HISTORY_CACHE
    if not xbmcvfs.exists(HISTORY_PATH):
        _HISTORY_CACHE = []
        return []
    try:
        f = xbmcvfs.File(HISTORY_PATH, "r")
        data = json.loads(f.read())
        f.close()
    except Exception:
        return []
    cleaned = _autoclean_history(data)
    _HISTORY_CACHE = cleaned
    if cleaned != data:
        _write_history(cleaned)
    return cleaned


def _write_history(data):
    global _HISTORY_CACHE
    _HISTORY_CACHE = data
    try:
        _atomic_write_json(HISTORY_PATH, data)
    except Exception:
        pass


def _autoclean_history(data):
    cleaned = []
    for item in data or []:
        item_id = item.get("id")
        play_url = str(item.get("play_url") or "").strip()
        if not item_id:
            continue
        if not play_url or "." not in play_url:
            continue
        if "None" in play_url or play_url.endswith("/") or play_url.endswith(".."):
            continue
        item.setdefault("played_at", int(item.get("timestamp", time.time())))
        item.setdefault("season", "")
        item.setdefault("episode", "")
        item.setdefault("server_key", "")
        item = _normalize_saved_history_type(item)
        cleaned.append(item)
    return cleaned


def _history_matches_current_server(item):
    current_key = _history_current_server_key()
    if not current_key:
        return True
    saved_key = str(item.get("server_key") or "").strip()
    if saved_key:
        return saved_key == current_key

    current_user = _favourites_current_server_user()
    current_server = _favourites_current_server_url()
    if not current_user and not current_server:
        return True

    play_url = str(item.get("play_url") or "").strip()
    if not play_url:
        return False
    if current_server and current_server in play_url:
        return (not current_user) or (current_user in play_url)
    return bool(current_user and current_user in play_url)


def _filter_history_for_current_server(items):
    return [item for item in (items or []) if _history_matches_current_server(item)]


def _strip_trailing_year(value):
    value = str(value or "").strip()
    return re.sub(r"\s*\(\d{4}\)\s*$", "", value).strip()


def add_history_item(
    item_id,
    title,
    stream_type,
    thumb="",
    fanart="",
    resume_time=0,
    play_url="",
    poster="",
    icon="",
    plot="",
    rating=0,
    year=0,
    tmdb_id="",
    channel_id="",
    stream_id="",
    is_live_epg=False,
    season="",
    episode="",
    series_id="",
    series_name="",
):
    data = _read_history()
    current_server_key = _history_current_server_key()
    data = [
        i for i in data if not _same_history_identity(i, item_id, current_server_key)
    ]

    payload = {
        "id": str(item_id),
        "title": title,
        "type": str(stream_type or "").strip().lower(),
        "thumb": thumb or "",
        "poster": poster or "",
        "fanart": fanart or "",
        "icon": icon or "",
        "plot": plot or "",
        "rating": rating or 0,
        "year": year or 0,
        "tmdb_id": str(tmdb_id or ""),
        "resume": resume_time,
        "timestamp": time.time(),
        "played_at": int(time.time()),
        "play_url": play_url or "",
        "channel_id": channel_id or "",
        "stream_id": str(stream_id or ""),
        "is_live_epg": bool(is_live_epg),
        "season": str(season or ""),
        "episode": str(episode or ""),
        "series_id": str(series_id or ""),
        "series_name": series_name or "",
        "server_key": current_server_key,
    }

    payload = _normalize_saved_history_type(payload)
    data.insert(0, payload)

    if len(data) > 30:
        data = data[:30]

    _write_history(data)


def clear_history():
    current_server_key = _history_current_server_key()
    if not current_server_key:
        _write_history([])
        return
    data = _read_history()
    data = [i for i in data if str(i.get("server_key") or "") != current_server_key]
    _write_history(data)


def list_history():

    history = _filter_history_for_current_server(_read_history())
    history = sorted(history, key=lambda x: x.get("timestamp", 0), reverse=True)

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, "Recently Watched")
    xbmcplugin.setContent(PLUGIN_HANDLE, "videos")

    if not history:
        item = xbmcgui.ListItem("No recently watched items for this server.")
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, "", item, isFolder=False)
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    movie_resume_map = {}
    watched_movie_ids = set()
    watched_episode_keys_by_show = {}
    episode_resume_map_by_show = {}

    if _is_trakt_ready():
        try:
            movie_resume_map = trakt_api.trakt_get_movie_resume_map() or {}
            watched_movie_ids = trakt_api.trakt_get_watched_movie_ids() or set()
            tv_maps = trakt_api.trakt_get_tv_progress_maps() or {}
            watched_episode_keys_by_show = (
                tv_maps.get("watched_episode_keys_by_show", {}) or {}
            )
            episode_resume_map_by_show = (
                tv_maps.get("episode_resume_map_by_show", {}) or {}
            )
        except Exception:
            pass

    xmltv_index = {}
    epg_offset_minutes = settings.get_epg_offset(ADDON)
    has_live = any(
        str(item.get("type", "")).strip().lower() == "live"
        or str(item.get("channel_id", "")).strip() != ""
        for item in history
    )
    if has_live:
        xmltv_index = _load_xmltv_index_with_retry(retries=4, delay_ms=400)

    for entry in history:
        title = entry.get("title", "Unknown")
        thumb = entry.get("thumb", "")
        poster = entry.get("poster", "")
        fanart = entry.get("fanart", "")
        icon = entry.get("icon", "")
        plot = entry.get("plot", "")
        rating = entry.get("rating", 0)
        year = entry.get("year", 0)
        tmdb_id = str(entry.get("tmdb_id", "") or "")
        play_url = entry.get("play_url") or ""
        stream_type = str(entry.get("type", "vod") or "vod").strip().lower()
        stream_id = entry.get("stream_id") or entry.get("id", "")
        channel_id = entry.get("channel_id", "")
        season_num = str(entry.get("season", "") or "")
        episode_num = str(entry.get("episode", "") or "")
        series_id = str(entry.get("series_id", "") or "")
        series_name = str(entry.get("series_name", "") or "")
        episode_title = str(
            entry.get("episode_title") or entry.get("clean_episode_title") or ""
        ).strip()

        series_display_name = _strip_trailing_year(series_name)

        if stream_type == "series":
            raw_title = str(title or "").strip()

            if not episode_title:
                episode_title = raw_title

                # Remove S01E03 / 1x03 markers
                try:
                    s = int(season_num)
                    e = int(episode_num)
                    episode_title = re.sub(
                        r"\bS{:02d}E{:02d}\b".format(s, e),
                        "",
                        episode_title,
                        flags=re.IGNORECASE,
                    )
                    episode_title = re.sub(
                        r"\bS{}E{}\b".format(s, e),
                        "",
                        episode_title,
                        flags=re.IGNORECASE,
                    )
                    episode_title = re.sub(
                        r"\b{}x{:02d}\b".format(s, e),
                        "",
                        episode_title,
                        flags=re.IGNORECASE,
                    )
                    episode_title = re.sub(
                        r"\b{}x{}\b".format(s, e),
                        "",
                        episode_title,
                        flags=re.IGNORECASE,
                    )
                except Exception:
                    episode_title = re.sub(
                        r"\bS\d{1,2}E\d{1,2}\b",
                        "",
                        episode_title,
                        flags=re.IGNORECASE,
                    )
                    episode_title = re.sub(
                        r"\b\d{1,2}x\d{1,2}\b",
                        "",
                        episode_title,
                        flags=re.IGNORECASE,
                    )

                # Remove series name if it was embedded in the saved title
                if series_name:
                    series_no_year = re.sub(
                        r"\s*\(\d{4}\)\s*$", "", series_name
                    ).strip()
                    for value in (series_name, series_no_year):
                        if value:
                            episode_title = episode_title.replace(value, "")

                episode_title = re.sub(r"\s*[-–—|:]\s*", " - ", episode_title)
                episode_title = re.sub(r"^(?:\s*-\s*)+", "", episode_title)
                episode_title = re.sub(r"(?:\s*-\s*)+$", "", episode_title)
                episode_title = re.sub(r"\s+", " ", episode_title).strip()

            if not episode_title:
                episode_title = "Episode {}".format(episode_num or "")

            try:
                display_title = "S{:02d}E{:02d} - {}".format(
                    int(season_num),
                    int(episode_num),
                    episode_title,
                )
            except Exception:
                display_title = "S{}E{} - {}".format(
                    season_num,
                    episode_num,
                    episode_title,
                )

            # This is what Kodi playback screen receives as name.
            title = display_title

        play_url_lower = str(play_url or "").lower()
        if channel_id or "/live/" in play_url_lower or "/timeshift/" in play_url_lower:
            stream_type = "live"

        display_title = title
        display_plot = plot
        watched_flag = False
        progress_value = None

        if stream_type == "live" and channel_id:
            data = (
                get_now_next(xmltv_index, channel_id, epg_offset_minutes)
                if xmltv_index
                else None
            )
            if data and data.get("now"):
                _, live_plot, _ = _build_live_plot(
                    data["now"], data.get("next"), epg_offset_minutes
                )
                display_plot = live_plot

        elif stream_type == "vod" and tmdb_id:
            watched_flag = tmdb_id in watched_movie_ids
            if not watched_flag:
                resume_info = movie_resume_map.get(tmdb_id) or {}
                progress_value = resume_info.get("progress")

        elif stream_type == "series" and tmdb_id and season_num and episode_num:
            watched_episode_keys = (
                watched_episode_keys_by_show.get(tmdb_id, set()) or set()
            )
            episode_resume_map = episode_resume_map_by_show.get(tmdb_id, {}) or {}
            ep_key = (str(season_num), str(episode_num))
            watched_flag = ep_key in watched_episode_keys
            if not watched_flag:
                resume_info = episode_resume_map.get(ep_key) or {}
                progress_value = resume_info.get("progress")
            if watched_flag and stream_type in ("vod", "series"):
                continue

        display_title, display_plot = _apply_saved_availability(
            display_title, display_plot, entry
        )

        meta = {
            "thumb": thumb,
            "poster": poster,
            "fanart": fanart,
            "icon": icon,
            "plot": display_plot,
            "rating": rating,
            "year": year,
            "tmdb_id": tmdb_id,
            "stream_type": stream_type,
            "channel_id": channel_id,
            "stream_id": stream_id,
            "season": season_num,
            "episode": episode_num,
            "series_id": series_id,
            "series_name": series_name,
            "episode_title": episode_title if stream_type == "series" else "",
            "display_title": display_title if stream_type == "series" else title,
        }
        plugin_url = _plugin_url(
            mode="play_stream",
            url=play_url,
            id=stream_id,
            type=stream_type,
            name=title,
            meta=_encode_meta(meta),
        )

        li = xbmcgui.ListItem(
            label=_label_with_marker(
                display_title, watched=watched_flag, progress=progress_value, skip=False
            )
        )
        li.setArt(
            _build_art(
                thumb=thumb,
                poster=poster,
                fanart=fanart,
                icon=icon,
                fallback="DefaultVideo.png",
            )
        )

        tag = li.getVideoInfoTag()
        try:
            tag.setTitle(display_title)
        except Exception:
            pass
        try:
            tag.setPlot(display_plot)
        except Exception:
            pass
        try:
            if stream_type == "series":
                tag.setMediaType("episode")

                if series_display_name:
                    try:
                        tag.setTvShowTitle(series_display_name)
                    except Exception:
                        pass

                if episode_title:
                    try:
                        tag.setTitle(episode_title)
                    except Exception:
                        pass

                if season_num:
                    tag.setSeason(int(season_num))
                if episode_num:
                    tag.setEpisode(int(episode_num))
            elif stream_type == "vod":
                tag.setMediaType("movie")
            else:
                tag.setMediaType("video")
        except Exception:
            pass

        _set_tag_year(tag, year)
        _set_tag_rating(tag, rating)

        if watched_flag:
            li.setProperty("playcount", "1")
            try:
                tag.setPlaycount(1)
            except Exception:
                pass

        li.setProperty("IsPlayable", "true")
        if stream_type == "live":
            li.setProperty("IsLive", "true")

        if tmdb_id:
            li.setProperty("tmdbnumber", str(tmdb_id))
            li.setProperty("imdbnumber", str(tmdb_id))
            try:
                tag.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")
            except Exception:
                pass

        custom_menu_url = _build_stream_menu_url(
            item_id=str(stream_id or ""),
            name=title,
            play_url=play_url,
            stream_type=stream_type,
            thumb=thumb,
            poster=poster,
            fanart=fanart,
            icon=icon,
            plot=display_plot,
            rating=str(rating),
            year=str(year),
            tmdb_id=tmdb_id,
            channel_id=channel_id,
            epg_channel_id=channel_id,
            has_archive="0",
            directory_type="history",
            directory_id="main",
            refresh_mode="recently_watched",
            category_name="Recently Watched",
            season=season_num,
            episode=episode_num,
            favourite_kind="playable",
            target_mode="play_stream",
            resume_progress=str(0 if watched_flag else (progress_value or 0)),
        )
        li.addContextMenuItems(
            [
                ("GIPTV Menu", "RunPlugin({})".format(custom_menu_url)),
                (
                    "Clear Recently Watched",
                    "RunPlugin({}?mode=clear_history)".format(sys.argv[0]),
                ),
            ],
            replaceItems=False,
        )
        xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, plugin_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)


# ---------------------------------------------------------------------------
# Root menu
# ---------------------------------------------------------------------------


def root_menu():
    try:
        from resources.utils.giptv import maybe_prompt_build_index

        maybe_prompt_build_index()
    except Exception as e:
        giptv.log(f"[ROOT MENU] index prompt failed: {e}", xbmc.LOGWARNING)

    items = []

    for label, icon, mode_params in [
        (
            "[B][COLOR gold]Favourites[/COLOR][/B]",
            FAVOURITES_ICON,
            {"mode": "favourites"},
        ),
        (
            "[B][COLOR orange]Recently Watched[/COLOR][/B]",
            WATCHED_ICON,
            {"mode": "recently_watched"},
        ),
    ]:
        li = xbmcgui.ListItem(label)
        li.setArt({"icon": icon, "thumb": icon, "fanart": icon})
        li.addContextMenuItems(
            [
                (
                    "GIPTV Menu",
                    f"RunPlugin(plugin://{ADDON_ID}/?action=open_tools_window)",
                )
            ]
        )
        items.append((_plugin_url(**mode_params), li, True))

    for label, stream_type, thumb in [
        ("[B]Live TV[/B]", "live", LIVE_ICON),
        ("[B]Movies[/B]", "vod", MOVIE_ICON),
        ("[B]TV Series[/B]", "series", SERIES_ICON),
    ]:
        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": thumb, "icon": thumb, "fanart": thumb})
        li.addContextMenuItems(
            [
                (
                    "GIPTV Menu",
                    f"RunPlugin(plugin://{ADDON_ID}/?action=open_tools_window)",
                )
            ]
        )
        items.append(
            (
                _plugin_url(mode="list_categories", stream_type=stream_type, page="1"),
                li,
                True,
            )
        )

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, "Xtream Content Streams")
    xbmcplugin.setContent(PLUGIN_HANDLE, "videos")
    _add_dir_items(items)
    _log_memory_caches("after root_menu")
    del items
    _trim_route_memory(is_live=False)


# ---------------------------------------------------------------------------
# list_categories
# ---------------------------------------------------------------------------


def list_categories(stream_type, search_query=None, page=1):

    if search_query is None:
        raw_params = (
            sys.argv[2][1:]
            if len(sys.argv) > 2 and sys.argv[2].startswith("?")
            else sys.argv[2]
        )
        params = dict(urlparse.parse_qsl(raw_params))
        search_query = params.get("search") or params.get("search_query")

    search_query = _normalize_search_query(search_query)
    page = max(1, _safe_int(page, 1))
    items = []

    if not search_query and page == 1:
        if stream_type == "vod" and _is_trakt_ready():
            for (
                tmdb_id,
                match_list,
                resume_data,
            ) in _get_continue_watching_movie_items():
                try:
                    row = _make_continue_movie_item(tmdb_id, match_list, resume_data)
                    if row:
                        items.append(row)
                except Exception as e:
                    giptv.log(
                        "[CONTINUE MOVIES] row failed: {}".format(e), xbmc.LOGWARNING
                    )
        elif stream_type == "series" and _is_trakt_ready():
            for (
                tmdb_id,
                match_list,
                playback_item,
            ) in _get_continue_watching_series_items():
                try:
                    row = _make_continue_series_item(tmdb_id, match_list, playback_item)
                    if row:
                        items.append(row)
                except Exception as e:
                    giptv.log(
                        "[CONTINUE SERIES] row failed: {}".format(e), xbmc.LOGWARNING
                    )

    category_list = _safe_category_list(stream_type)
    if category_list is None:
        _notify_and_open_settings("Xtream server/category response invalid")
        return
    if not isinstance(category_list, list):
        _notify_and_open_settings("Xtream categories invalid")
        return


    hidden_groups = settings.get_hidden_groups(ADDON, stream_type)
    if hidden_groups:
        category_list = [
            category for category in category_list
            if str(category.get("category_id", "")) not in hidden_groups
        ]

    if search_query:
        category_list = [
            c
            for c in category_list
            if search_query in (c.get("category_name", "") or "").lower()
        ]

    from resources.lib.manager import sort_manager

    sort_mode = sort_manager.get_current_sort("categories", stream_type)
    category_list = _sort_categories(category_list, sort_mode)

    next_mode = "list_series_streams" if stream_type == "series" else "list_streams"
    page_items, has_next, page = _paginate_items(category_list, page)

    # if page > 1:
    #     items.append(
    #         _prev_page_item(
    #             "list_categories",
    #             page,
    #             stream_type=stream_type,
    #             search_query=search_query or "",
    #         )
    #     )

    for category in page_items:
        try:
            category_name = category.get("category_name", "Unknown Category")
            category_id = category.get("category_id")
            li = xbmcgui.ListItem(label=category_name)
            li.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
            _add_giptv_context_menu(
                li, _build_category_menu_url(stream_type, category_id, category_name)
            )
            items.append(
                (
                    _plugin_url(
                        mode=next_mode,
                        stream_type=stream_type,
                        category_id=category_id,
                        name=category_name,
                        page="1",
                    ),
                    li,
                    True,
                )
            )
        except Exception as e:
            giptv.log("[NAV] category row failed: {}".format(e), xbmc.LOGWARNING)

    if has_next:
        items.append(
            _next_page_item(
                "list_categories",
                page,
                stream_type=stream_type,
                search_query=search_query or "",
            )
        )

    _add_dir_items(items)
    _log_memory_caches("after list_categories")
    del items, category_list, page_items
    _trim_route_memory(is_live=False)


# ---------------------------------------------------------------------------
# list_streams
# ---------------------------------------------------------------------------


def list_streams(stream_type, category_id, name, search_query=None, page=1):

    search_query = _normalize_search_query(search_query)
    page = max(1, _safe_int(page, 1))
    items = []

    stream_list = _safe_stream_list(stream_type, category_id)
    if stream_list is None:
        _notify_and_go_home("Xtream stream response invalid")
        return
    if not isinstance(stream_list, list):
        _notify_and_go_home("Xtream stream data invalid")
        return

    if search_query:
        stream_list = [s for s in stream_list if _stream_matches_query(s, search_query)]

    if stream_type != "live":
        _store_current_items(stream_type, category_id, stream_list)
    else:
        _current_items.set(f"{stream_type}_{category_id}", [])

    is_live = stream_type == "live"
    is_vod = stream_type == "vod"

    xbmcplugin.setContent(PLUGIN_HANDLE, "movies" if is_vod else "videos")

    epg_offset_minutes = settings.get_epg_offset(ADDON) if is_live else 0
    xmltv_index = {}
    movie_resume_map = {}
    watched_movie_ids = set()

    if is_vod and _is_trakt_ready():
        movie_resume_map, watched_movie_ids = _fetch_trakt_vod_data()

    if is_live:
        catchup_ids = []
        for stream in stream_list:
            try:
                has_catchup = (
                    str(stream.get("tv_archive", stream.get("has_archive", "0"))) == "1"
                )
                if has_catchup:
                    cid = _resolve_xmltv_channel_id_cached(stream)
                    if cid:
                        catchup_ids.append(cid)
            except Exception:
                pass
        set_catchup_channels(catchup_ids)

        start = time.time()
        xmltv_index = _load_xmltv_index_with_retry(retries=4, delay_ms=400)
        giptv.log(f"EPG load took {time.time() - start:.3f}s", xbmc.LOGINFO)

    from resources.lib.manager import sort_manager

    sort_dir_id = f"{stream_type}:{category_id}"
    sort_mode = sort_manager.get_current_sort("streams", sort_dir_id)
    sort_label = sort_manager.get_sort_label("streams", sort_dir_id)
    stream_list = _sort_streams(stream_list, sort_mode)

    if is_live and settings.condense_live_versions(ADDON):
        stream_list = _condense_live_streams(stream_list)

    page_streams, has_next, page = _paginate_items(stream_list, page)

    # if page > 1:
    #     items.append(
    #         _prev_page_item(
    #             "list_streams",
    #             page,
    #             stream_type=stream_type,
    #             category_id=category_id,
    #             name=name,
    #             search_query=search_query or "",
    #         )
    #     )

    for stream in page_streams:
        stream_id = str(
            stream.get("stream_id")
            or stream.get("movie_id")
            or stream.get("vod_id")
            or ""
        )
        if not stream_id:
            continue

        stream_name = (
            stream.get("name")
            or stream.get("title")
            or stream.get("stream_display_name")
            or "Unknown Stream"
        )

        versions = stream.get("_giptv_versions") or []
        if is_live and len(versions) > 1:
            version_key = stream.get("_giptv_version_key", "")
            channel_id = _resolve_xmltv_channel_id_cached(stream) or ""
            has_archive = str(
                stream.get("tv_archive", stream.get("has_archive", "0"))
            ) == "1"
            live_data = (
                get_now_next(xmltv_index, channel_id, epg_offset_minutes)
                if channel_id and xmltv_index
                else None
            )
            display_label = "{}  [COLOR grey]({} versions)[/COLOR]".format(
                stream_name, len(versions)
            )
            display_plot = "Choose one of {} available channel versions".format(
                len(versions)
            )
            epg_title = stream_name
            epg_duration = 0
            if live_data and live_data.get("now"):
                epg_title, display_plot, epg_duration = _build_live_plot(
                    live_data["now"], live_data.get("next"), epg_offset_minutes
                )
                display_label = (
                    "[COLOR green][LIVE][/COLOR] {}  "
                    "[COLOR grey]({} versions)[/COLOR]"
                ).format(stream_name, len(versions))

            version_item = xbmcgui.ListItem(label=display_label)
            version_icon = _get_picon_cached(
                stream_id, stream.get("stream_icon"), stream.get("category_id")
            )
            version_art = _build_art(
                thumb=version_icon,
                poster=version_icon,
                fanart=version_icon,
                icon=version_icon,
                fallback="DefaultVideo.png",
            )
            version_item.setArt(version_art)
            try:
                tag = version_item.getVideoInfoTag()
                tag.setTitle(epg_title)
                tag.setPlot(display_plot)
                if epg_duration:
                    tag.setDuration(epg_duration)
                tag.setMediaType("video")
            except Exception:
                pass
            version_item.setProperty("IsLive", "true")

            representative_ext = stream.get("container_extension", "ts")
            selected_format = settings.get_stream_format(ADDON)
            if selected_format in ("ts", "m3u8"):
                representative_ext = selected_format
            representative_url = xtream_api.build_stream_url(
                stream_id,
                "live",
                representative_ext,
            )
            menu_url = _build_stream_menu_url(
                item_id=stream_id,
                name=stream_name,
                play_url=representative_url or "",
                stream_type="live",
                thumb=version_art.get("thumb", ""),
                poster=version_art.get("poster", ""),
                fanart=version_art.get("fanart", ""),
                icon=version_art.get("icon", ""),
                plot=display_plot,
                channel_id=channel_id,
                epg_channel_id=str(stream.get("epg_channel_id", "")),
                has_archive="1" if has_archive else "0",
                directory_type="streams",
                directory_id=sort_dir_id,
                refresh_mode="list_streams",
                sort_label=sort_label,
                category_id=category_id,
                category_name=name,
                search_query=search_query or "",
                page=str(page),
                favourite_kind="playable",
                target_mode="play_stream",
            )
            _add_giptv_context_menu(version_item, menu_url)
            items.append((
                _plugin_url(
                    mode="select_live_version",
                    category_id=category_id,
                    version_key=version_key,
                    name=stream_name,
                    versions=_encode_live_versions(versions),
                ),
                version_item,
                False,
            ))
            continue
        stream_icon = _get_picon_cached(
            stream_id, stream.get("stream_icon"), stream.get("category_id")
        )

        list_item = xbmcgui.ListItem(label=stream_name)
        art_dict = {}
        ext = stream.get("container_extension", "mp4")
        stream_type_for_api = "live"

        plot_value = ""
        rating_value = 0
        year_value = 0
        tmdb_id_value = ""
        channel_id_value = ""
        stream_type_value = "vod" if is_vod else "live"
        watched_flag = False
        progress_value = None

        if is_vod:
            stream_type_for_api = "vod"
            info_data = stream.get("info", {}) or {}

            raw_tmdb_id = (
                stream.get("tmdb")
                or stream.get("tmdb_id")
                or info_data.get("tmdb")
                or info_data.get("tmdb_id")
            )
            tmdb_id = _normalize_tmdb_id(raw_tmdb_id)

            if not tmdb_id:
                release_date = stream.get("release_date") or ""
                year_hint = ""
                if "-" in release_date:
                    year_part = release_date.split("-")[0]
                    if year_part.isdigit():
                        year_hint = year_part
                elif len(release_date) == 4 and release_date.isdigit():
                    year_hint = release_date
                tmdb_id = _resolve_movie_tmdb_id_cached(stream_name, year_hint)

            tmdb_details = _get_tmdb_movie_details_cached(tmdb_id) if tmdb_id else None

            if tmdb_details:
                art_raw = tmdb_details.get("art", {}) or {}
                art_dict = _build_art(
                    thumb=art_raw.get("thumb", ""),
                    poster=art_raw.get("poster", "") or stream_icon,
                    fanart=art_raw.get("fanart", ""),
                    icon=art_raw.get("icon", "") or stream_icon,
                    fallback=stream_icon or "DefaultVideo.png",
                )
                if tmdb_id:
                    list_item.setProperty("tmdbnumber", tmdb_id)
                    list_item.setProperty("imdbnumber", tmdb_id)

                tag = list_item.getVideoInfoTag()
                tag.setTitle(tmdb_details.get("title") or stream_name)
                tag.setPlot(tmdb_details.get("plot") or "")
                tag.setMediaType("movie")
                if tmdb_details.get("year") and str(tmdb_details["year"]).isdigit():
                    tag.setYear(int(tmdb_details["year"]))
                try:
                    if tmdb_details.get("rating") is not None:
                        tag.setRating(float(tmdb_details["rating"]), 10)
                except Exception:
                    pass
                try:
                    if tmdb_details.get("duration") is not None:
                        tag.setDuration(int(tmdb_details["duration"]))
                    elif info_data.get("duration_secs"):
                        tag.setDuration(int(info_data["duration_secs"]))
                except Exception:
                    pass

                plot_value = tmdb_details.get("plot") or ""
                rating_value = tmdb_details.get("rating") or 0
                year_value = (
                    int(tmdb_details["year"])
                    if tmdb_details.get("year") and str(tmdb_details["year"]).isdigit()
                    else 0
                )
                tmdb_id_value = _normalize_tmdb_id(
                    tmdb_details.get("tmdb_id") or tmdb_id
                )
            else:
                movie_plot = (
                    stream.get("plot")
                    or info_data.get("plot")
                    or "No description available."
                )
                duration = 0
                try:
                    if info_data.get("duration_secs"):
                        duration = int(info_data["duration_secs"])
                except Exception:
                    pass
                year = 0
                release_date = stream.get("release_date") or ""
                if "-" in release_date:
                    year_part = release_date.split("-")[0]
                    if year_part.isdigit():
                        year = int(year_part)
                elif len(release_date) == 4 and release_date.isdigit():
                    year = int(release_date)

                tag = list_item.getVideoInfoTag()
                tag.setTitle(stream_name)
                tag.setPlot(movie_plot)
                tag.setMediaType("movie")
                if duration > 0:
                    tag.setDuration(duration)
                if year > 0:
                    tag.setYear(year)

                art_dict = _build_art(
                    thumb=stream_icon,
                    poster=stream_icon,
                    fanart=stream_icon,
                    icon=stream_icon,
                    fallback="DefaultVideo.png",
                )
                plot_value = movie_plot
                year_value = year
                tmdb_id_value = _normalize_tmdb_id(raw_tmdb_id or tmdb_id)

            resolved_tmdb_id = str(tmdb_id_value or tmdb_id or "")
            watched_flag = (
                resolved_tmdb_id in watched_movie_ids if resolved_tmdb_id else False
            )
            if resolved_tmdb_id:
                resume_info = movie_resume_map.get(resolved_tmdb_id) or {}
                if resume_info:
                    progress_value = resume_info.get("progress")

            if watched_flag:
                list_item.setProperty("playcount", "1")
                try:
                    list_item.getVideoInfoTag().setPlaycount(1)
                except Exception:
                    pass

            list_item.setLabel(
                _label_with_marker(
                    stream_name,
                    watched=watched_flag,
                    progress=progress_value,
                    skip=False,
                )
            )

        else:
            stream_type_for_api = "live"
            ext = stream.get("container_extension", "ts")
            selected_format = settings.get_stream_format(ADDON)
            if selected_format == "ts":
                ext = "ts"
            elif selected_format == "m3u8":
                ext = "m3u8"

            art_dict = _build_art(
                thumb=stream_icon,
                poster=stream_icon,
                fanart=stream_icon,
                icon=stream_icon,
                fallback="DefaultVideo.png",
            )
            channel_id = _resolve_xmltv_channel_id_cached(stream)
            channel_id_value = channel_id or ""

            data = (
                get_now_next(xmltv_index, channel_id, epg_offset_minutes)
                if channel_id
                else None
            )
            tag = list_item.getVideoInfoTag()

            if data and data.get("now"):
                title, plot, duration = _build_live_plot(
                    data["now"], data.get("next"), epg_offset_minutes
                )
                list_item.setLabel(f"[COLOR green][LIVE][/COLOR] {stream_name}")
                tag.setTitle(title)
                tag.setPlot(plot)
                tag.setDuration(duration)
                tag.setMediaType("video")
                list_item.setProperty("IsLive", "true")
                plot_value = plot
            else:
                tag.setTitle(stream_name)
                tag.setPlot(stream_name)
                tag.setMediaType("video")
                plot_value = stream_name

        play_url = xtream_api.build_stream_url(
            stream_id=stream_id,
            stream_type=stream_type_for_api,
            container_extension=ext,
        )
        if not play_url:
            continue

        metadata = {
            "thumb": art_dict.get("thumb", ""),
            "poster": art_dict.get("poster", ""),
            "fanart": art_dict.get("fanart", ""),
            "icon": art_dict.get("icon", ""),
            "plot": plot_value,
            "rating": rating_value,
            "year": year_value,
            "tmdb_id": tmdb_id_value,
            "stream_type": stream_type_value,
            "channel_id": channel_id_value,
            "stream_id": stream_id,
        }

        url = _plugin_url(
            mode="play_stream",
            url=play_url,
            name=stream_name,
            meta=_encode_meta(metadata),
        )
        list_item.setProperty("IsPlayable", "true")
        list_item.setArt(art_dict)

        menu_url = None
        if is_live:
            menu_url = _build_stream_menu_url(
                item_id=stream_id,
                name=stream_name,
                play_url=play_url,
                stream_type=stream_type_value,
                thumb=art_dict.get("thumb", ""),
                poster=art_dict.get("poster", ""),
                fanart=art_dict.get("fanart", ""),
                icon=art_dict.get("icon", ""),
                plot=plot_value,
                rating=str(rating_value),
                year=str(year_value),
                tmdb_id=tmdb_id_value,
                channel_id=channel_id_value,
                epg_channel_id=str(stream.get("epg_channel_id", "")),
                has_archive=str(
                    stream.get("tv_archive", stream.get("has_archive", "0"))
                ),
                directory_type="streams",
                directory_id=sort_dir_id,
                refresh_mode="list_streams",
                sort_label=sort_label,
                category_id=category_id,
                category_name=name,
                search_query=search_query or "",
                page=str(page),
                favourite_kind="playable",
                target_mode="play_stream",
            )
        elif is_vod:
            menu_url = _build_stream_menu_url(
                item_id=stream_id,
                name=stream_name,
                play_url=play_url,
                stream_type=stream_type_value,
                thumb=art_dict.get("thumb", ""),
                poster=art_dict.get("poster", ""),
                fanart=art_dict.get("fanart", ""),
                icon=art_dict.get("icon", ""),
                plot=plot_value,
                rating=str(rating_value),
                year=str(year_value),
                tmdb_id=tmdb_id_value,
                directory_type="streams",
                directory_id=sort_dir_id,
                refresh_mode="list_streams",
                sort_label=sort_label,
                category_id=category_id,
                category_name=name,
                search_query=search_query or "",
                page=str(page),
                favourite_kind="playable",
                target_mode="play_stream",
                resume_progress=str(0 if watched_flag else (progress_value or 0)),
            )

        if menu_url:
            _add_giptv_context_menu(list_item, menu_url)
        items.append((url, list_item, False))

    if has_next:
        items.append(
            _next_page_item(
                "list_streams",
                page,
                stream_type=stream_type,
                category_id=category_id,
                name=name,
                search_query=search_query or "",
            )
        )

    _add_dir_items(items)
    _log_memory_caches("after list_streams")
    del items, stream_list, page_streams, xmltv_index
    _trim_route_memory(is_live=is_live)


def select_live_version(category_id, version_key, name="", versions_encoded=""):
    versions = _decode_live_versions(versions_encoded)
    if not versions:
        # Compatibility fallback for older URLs already held by a Kodi view.
        stream_list = _safe_stream_list("live", category_id) or []
        versions = []
        for stream in stream_list:
            stream_name = (
                stream.get("name")
                or stream.get("title")
                or stream.get("stream_display_name")
                or "Unknown"
            )
            if _live_version_key(stream_name) == version_key:
                versions.append(stream)
    if not versions:
        giptv.notification(ADDON.getAddonInfo("name"), "Channel versions are no longer available", icon="ERROR")
        return

    choice = xbmcgui.Dialog().select(
        "Choose {} version".format(name or "channel"),
        [v.get("name") or v.get("title") or "Unknown" for v in versions],
    )
    if choice < 0:
        return
    stream = versions[choice]
    stream_id = str(stream.get("stream_id") or "")
    if not stream_id:
        return
    stream_name = stream.get("name") or stream.get("title") or name
    ext = stream.get("container_extension", "ts")
    selected_format = settings.get_stream_format(ADDON)
    if selected_format in ("ts", "m3u8"):
        ext = selected_format
    play_url = xtream_api.build_stream_url(stream_id, "live", ext)
    channel_id = _resolve_xmltv_channel_id_cached(stream) or ""
    icon = _get_picon_cached(
        stream_id, stream.get("stream_icon"), stream.get("category_id")
    )
    metadata = {
        "thumb": icon,
        "poster": icon,
        "fanart": icon,
        "icon": icon,
        "plot": stream_name,
        "stream_type": "live",
        "channel_id": channel_id,
        "stream_id": stream_id,
    }
    xbmc.executebuiltin(
        "PlayMedia({})".format(_plugin_url(
            mode="play_stream", url=play_url, name=stream_name, meta=_encode_meta(metadata)
        ))
    )


# ---------------------------------------------------------------------------
# Catchup
# ---------------------------------------------------------------------------


def list_catchup_dates(stream_id, channel_id, name):

    if channel_id:
        set_catchup_channels([channel_id])

    xmltv_index = get_xmltv_index()
    cid = str(channel_id).strip().upper().replace(" ", "_").replace("-", "_")
    programmes = xmltv_index.get(cid, [])

    items = []
    if not programmes:
        _add_dir_items(items)
        _trim_route_memory(is_live=True)
        return

    try:
        epg_fine_tune = int(settings.get_epg_offset(ADDON) or 0)
    except Exception:
        epg_fine_tune = 0

    now_ts = int(time.time())
    cutoff_ts = now_ts - (settings.get_catchup_days(ADDON) * 86400)
    dates = set()

    for start_ts, _, _, _ in programmes:
        try:
            start_ts = int(start_ts)
        except Exception:
            continue

        if cutoff_ts <= start_ts <= now_ts:
            display_ts = _apply_offset_minutes(start_ts, -epg_fine_tune)
            dates.add(datetime.datetime.fromtimestamp(display_ts).date())

    for d in sorted(dates, reverse=True):
        date_label = d.strftime("%A %d %B")

        li = xbmcgui.ListItem(label=date_label)
        li.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})

        folder_url = giptv.build_url(
            mode="list_catchup_programmes",
            stream_id=stream_id,
            channel_id=channel_id,
            date=d.isoformat(),
            name=name,
        )

        menu_url = _build_stream_menu_url(
            item_id=f"catchup_date:{stream_id}:{channel_id}:{d.isoformat()}",
            name=date_label,
            play_url="",
            stream_type="live",
            thumb="DefaultFolder.png",
            poster="DefaultFolder.png",
            fanart="",
            icon="DefaultFolder.png",
            plot=f"Catchup programmes for {name}",
            rating="0",
            year="0",
            tmdb_id="",
            channel_id=channel_id,
            epg_channel_id=channel_id,
            has_archive="0",
            directory_type="catchup",
            directory_id=str(channel_id or stream_id),
            refresh_mode="list_catchup_dates",
            category_name=name,
            favourite_kind="catchup_date",
            target_mode="list_catchup_programmes",
        )
        _add_giptv_context_menu(li, menu_url)

        # IMPORTANT: this must be INSIDE the date loop
        items.append((folder_url, li, True))

    _add_dir_items(items)
    _trim_route_memory(is_live=True)


def list_catchup_programmes(stream_id, channel_id, date, name=""):

    if channel_id:
        set_catchup_channels([channel_id])

    xmltv = get_xmltv_index()
    cid = str(channel_id).strip().upper().replace(" ", "_").replace("-", "_")
    now_ts = int(time.time())
    cutoff_ts = now_ts - (settings.get_catchup_days(ADDON) * 86400)
    programmes = xmltv.get(cid, [])

    try:
        catchup_offset = int(settings.get_catchup_offset(ADDON) or 0)
    except Exception:
        catchup_offset = 0

    try:
        epg_fine_tune = int(settings.get_epg_offset(ADDON) or 0)
    except Exception:
        epg_fine_tune = 0

    items = []

    for start_ts, end_ts, title, desc in programmes:
        try:
            start_ts = int(start_ts)
            end_ts = int(end_ts)
        except Exception:
            continue

        display_start_ts = _apply_offset_minutes(start_ts, -epg_fine_tune)
        display_dt = datetime.datetime.fromtimestamp(display_start_ts)

        if (
            display_dt.date().isoformat() != date
            or start_ts > now_ts
            or end_ts < cutoff_ts
        ):
            continue

        duration = max(1, int((end_ts - start_ts) / 60))

        # Server playback start.
        # This is for provider/catchup correction, not display correction.
        url_ts = _apply_offset_minutes(start_ts, catchup_offset)
        start_str = datetime.datetime.fromtimestamp(url_ts).strftime("%Y-%m-%d:%H-%M")
        label_time = display_dt.strftime("%H:%M")

        final_url = (
            f"{STATE.server.rstrip('/')}/timeshift/"
            f"{STATE.username}/{STATE.password}/"
            f"{duration}/{start_str}/{stream_id}.ts"
        )

        display_title = f"{label_time} — {title}"

        metadata = {
            "thumb": "",
            "poster": "",
            "fanart": "",
            "icon": "",
            "plot": desc or "",
            "rating": 0,
            "year": 0,
            "tmdb_id": "",
            "stream_type": "live",
            "channel_id": channel_id,
            "stream_id": stream_id,
            "is_catchup": True,
        }

        url = giptv.build_url(
            mode="play_catchup",
            url=final_url,
            name=title,
            meta=_encode_meta(metadata),
        )

        li = xbmcgui.ListItem(label=display_title)
        li.setArt(_build_art(fallback="DefaultVideo.png"))

        tag = li.getVideoInfoTag()
        try:
            tag.setTitle(title)
            tag.setPlot(desc or "")
            tag.setMediaType("video")
            tag.setDuration(duration * 60)
        except Exception:
            pass

        li.setProperty("IsPlayable", "true")
        li.setProperty("IsLive", "true")

        menu_url = _build_stream_menu_url(
            item_id=f"catchup:{stream_id}:{channel_id}:{start_str}",
            name=display_title,
            play_url=final_url,
            stream_type="live",
            thumb="",
            poster="",
            fanart="",
            icon="",
            plot=desc or "",
            rating="0",
            year="0",
            tmdb_id="",
            channel_id=channel_id,
            epg_channel_id=channel_id,
            has_archive="0",
            directory_type="catchup",
            directory_id=str(channel_id or stream_id),
            refresh_mode="list_catchup_programmes",
            category_name=name or "Catchup",
            favourite_kind="catchup_programme",
            target_mode="play_catchup",
        )
        _add_giptv_context_menu(li, menu_url)

        items.append((url, li, False))

    _add_dir_items(items)
    _trim_route_memory(is_live=True)


# ---------------------------------------------------------------------------
# list_series_streams
# ---------------------------------------------------------------------------


def list_series_streams(stream_type, category_id, name, search_query=None, page=1):

    search_query = _normalize_search_query(search_query)
    page = max(1, _safe_int(page, 1))
    items = []

    series_list = _safe_stream_list(stream_type, category_id)
    if series_list is None:
        _notify_and_go_home("Xtream series response invalid")
        return
    if not isinstance(series_list, list):
        _notify_and_go_home("Xtream series data invalid")
        return

    if search_query:
        series_list = [s for s in series_list if _stream_matches_query(s, search_query)]

    from resources.lib.manager import sort_manager

    sort_dir_id = f"{stream_type}:{category_id}"
    sort_mode = sort_manager.get_current_sort("streams", sort_dir_id)
    sort_label = sort_manager.get_sort_label("streams", sort_dir_id)
    series_list = _sort_streams(series_list, sort_mode)

    xbmcplugin.setContent(PLUGIN_HANDLE, "tvshows")
    page_series, has_next, page = _paginate_items(series_list, page)

    def _resolve_series_tmdb(series):
        tmdb_id = _normalize_tmdb_id(_extract_tmdb_id(series))
        if not tmdb_id:
            release_date = series.get("release_date") or ""
            year_str = release_date.split("-")[0] if "-" in release_date else ""
            tmdb_id = _resolve_series_tmdb_id_cached(
                series.get("name", "") or series.get("title", "") or "",
                year_str,
            )
        return tmdb_id

    series_tmdb_ids = [_resolve_series_tmdb(s) for s in page_series]
    unique_ids = list({t for t in series_tmdb_ids if t})

    details_map = {}
    if unique_ids:
        _pool_map(_get_tmdb_series_details_cached, unique_ids)
        for tid in unique_ids:
            try:
                details_map[tid] = _get_tmdb_series_details_cached(tid) or {}
            except Exception:
                details_map[tid] = {}

    watched_episode_keys_by_show = {}
    episode_resume_map_by_show = {}

    if _is_trakt_ready():
        try:
            tv_maps = trakt_api.trakt_get_tv_progress_maps()
            watched_episode_keys_by_show = (
                tv_maps.get("watched_episode_keys_by_show", {}) or {}
            )
            episode_resume_map_by_show = (
                tv_maps.get("episode_resume_map_by_show", {}) or {}
            )
        except Exception:
            pass

    # if page > 1:
    #     items.append(
    #         _prev_page_item(
    #             "list_series_streams",
    #             page,
    #             stream_type=stream_type,
    #             category_id=category_id,
    #             name=name,
    #             search_query=search_query or "",
    #         )
    #     )

    for series, tmdb_id in zip(page_series, series_tmdb_ids):
        series_name = series.get("name", "Unknown Series")
        series_id = series.get("series_id")
        plot = series.get("plot", "No description available.")
        rating_str = series.get("rating", "0")
        genre = series.get("genre", "")
        cast_str = series.get("cast", "")
        series_icon = series.get("cover", "")

        release_date = series.get("release_date") or ""
        year_str = release_date.split("-")[0] if "-" in release_date else ""
        year = int(year_str) if year_str.isdigit() else 0

        try:
            rating = float(rating_str)
        except Exception:
            rating = 0.0

        cast_list = [c.strip() for c in cast_str.split(",")] if cast_str else []
        watched_flag = False
        progress_value = None

        if tmdb_id and series_id:
            try:
                series_info_response = cache_handler.get(
                    "series_info", f"{STATE.username}_{series_id}"
                )
                if not series_info_response:
                    series_info_response = xtream_api.series_info_by_id(series_id)
                episodes_by_season = {}
                if isinstance(series_info_response, dict):
                    episodes_by_season = series_info_response.get("episodes", {}) or {}
                watched_episode_keys = (
                    watched_episode_keys_by_show.get(str(tmdb_id), set()) or set()
                )
                episode_resume_map = (
                    episode_resume_map_by_show.get(str(tmdb_id), {}) or {}
                )
                watched_flag, progress_value = _show_rollup_from_episode_maps(
                    episodes_by_season,
                    watched_episode_keys,
                    episode_resume_map,
                )
            except Exception:
                pass

        details = details_map.get(tmdb_id, {}) if tmdb_id else {}
        detail_art = (details.get("art") or {}) if details else {}

        if detail_art.get("poster"):
            series_icon = detail_art.get("poster")
        if details:
            if details.get("plot"):
                plot = details.get("plot")
            if details.get("rating") is not None:
                try:
                    rating = float(details.get("rating") or 0.0)
                except Exception:
                    pass
            genre_list = details.get("genre") or []
            if genre_list:
                genre = ", ".join(genre_list)
            cast_data = details.get("cast") or []
            if cast_data:
                cast_list = [c.get("name") for c in cast_data if c.get("name")]

        art_dict = _build_art(
            thumb=detail_art.get("thumb", ""),
            poster=detail_art.get("poster", "") or series_icon or "",
            fanart=detail_art.get("fanart", ""),
            icon=detail_art.get("thumb", "")
            or detail_art.get("poster", "")
            or series_icon
            or "",
            fallback="DefaultTVShows.png",
        )

        li = xbmcgui.ListItem(
            label=_label_with_marker(
                series_name, watched=watched_flag, progress=progress_value, skip=False
            )
        )
        li.setArt(art_dict)

        tag = li.getVideoInfoTag()
        try:
            tag.setTitle(series_name)
        except Exception:
            pass
        try:
            tag.setPlot(plot)
        except Exception:
            pass
        try:
            if genre:
                tag.setGenres(
                    genre
                    if isinstance(genre, list)
                    else [g.strip() for g in str(genre).split(",") if g.strip()]
                )
        except Exception:
            pass
        try:
            tag.setMediaType("tvshow")
        except Exception:
            pass
        _set_tag_year(tag, year)
        _set_tag_rating(tag, rating)
        try:
            if cast_list:
                tag.setCast([xbmc.Actor(actor) for actor in cast_list if actor])
        except Exception:
            pass

        if watched_flag:
            li.setProperty("playcount", "1")
            try:
                tag.setPlaycount(1)
            except Exception:
                pass

        if tmdb_id:
            try:
                tag.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")
            except Exception:
                pass
            li.setProperty("imdbnumber", str(tmdb_id))
            li.setProperty("tmdbnumber", str(tmdb_id))

        menu_url = _build_stream_menu_url(
            item_id=str(series_id),
            name=series_name,
            play_url="",
            stream_type="series",
            thumb=art_dict.get("thumb", ""),
            poster=art_dict.get("poster", ""),
            fanart=art_dict.get("fanart", ""),
            icon=art_dict.get("icon", ""),
            plot=plot,
            rating=str(rating),
            year=str(year),
            tmdb_id=str(tmdb_id or ""),
            directory_type="streams",
            directory_id=sort_dir_id,
            refresh_mode="list_series_streams",
            sort_label=sort_label,
            category_id=category_id,
            category_name=name,
            search_query=search_query or "",
            page=str(page),
            favourite_kind="series_folder",
            target_mode="list_series_seasons",
            series_id=str(series_id or ""),
            series_name=series_name,
        )
        _add_giptv_context_menu(li, menu_url)
        items.append(
            (
                _plugin_url(
                    mode="list_series_seasons",
                    series_id=series_id,
                    series_name=series_name,
                ),
                li,
                True,
            )
        )

    if has_next:
        items.append(
            _next_page_item(
                "list_series_streams",
                page,
                stream_type=stream_type,
                category_id=category_id,
                name=name,
                search_query=search_query or "",
            )
        )

    _add_dir_items(items)
    _log_memory_caches("after list_series_streams")
    del items, series_list, page_series
    _trim_route_memory(is_live=False)


# ---------------------------------------------------------------------------
# list_series_seasons
# ---------------------------------------------------------------------------


def list_series_seasons(series_id, series_name):

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, series_name)
    xbmcplugin.setContent(PLUGIN_HANDLE, "seasons")

    series_info_response = cache_handler.get(
        "series_info", f"{STATE.username}_{series_id}"
    )
    if not series_info_response:
        series_info_response = xtream_api.series_info_by_id(series_id)

    if not isinstance(series_info_response, dict):
        _notify_and_go_home("Series details unavailable")
        return
    if "episodes" not in series_info_response:
        _notify_and_go_home("Series episode data unavailable")
        return

    episodes_by_season = series_info_response.get("episodes", {})
    if not episodes_by_season:
        giptv.notification(
            ADDON.getAddonInfo("name"),
            f"No seasons or episodes found for {series_name}.",
            icon="INFO",
        )
        return

    series_info = series_info_response.get(
        "info", series_info_response.get("series_info", {})
    )
    tmdb_id = _normalize_tmdb_id(_extract_tmdb_id(series_info_response))
    if not tmdb_id:
        release_date = (
            series_info.get("releaseDate") or series_info.get("release_date") or ""
        )
        year_hint = release_date[:4] if release_date[:4].isdigit() else ""
        tmdb_id = _resolve_series_tmdb_id_cached(series_name, year_hint)

    tmdb_series_details = _get_tmdb_series_details_cached(tmdb_id) if tmdb_id else None
    detail_art = (tmdb_series_details or {}).get("art") or {}

    series_poster = (
        detail_art.get("poster")
        or series_info_response.get("cover")
        or series_info.get("cover", "")
    )
    series_fanart = detail_art.get("fanart") or ""

    watched_episode_keys = set()
    episode_resume_map = {}

    if _is_trakt_ready() and tmdb_id:
        try:
            tv_maps = trakt_api.trakt_get_tv_progress_maps()
            watched_episode_keys = (
                tv_maps.get("watched_episode_keys_by_show", {}).get(str(tmdb_id), set())
                or set()
            )
            episode_resume_map = (
                tv_maps.get("episode_resume_map_by_show", {}).get(str(tmdb_id), {})
                or {}
            )
        except Exception:
            pass

    season_nums = list(episodes_by_season.keys())
    season_details_map = {}

    if tmdb_id and season_nums:
        _pool_map(
            lambda s: _get_tmdb_season_details_cached(tmdb_id, int(s)), season_nums
        )
        for s in season_nums:
            try:
                season_details_map[str(s)] = (
                    _get_tmdb_season_details_cached(tmdb_id, int(s)) or {}
                )
            except Exception:
                season_details_map[str(s)] = {}

    items = []

    for season_num in sorted(season_nums, key=int):
        season_title = f"Season {season_num}"
        season_data = season_details_map.get(str(season_num), {}) if tmdb_id else {}
        season_art = (season_data.get("art") or {}) if season_data else {}
        season_plot = (season_data.get("overview") or "") or series_info.get("plot", "")
        season_rating = (season_data.get("vote_average") or 0) or series_info.get(
            "rating", "0"
        )

        season_episodes = episodes_by_season.get(
            str(season_num), []
        ) or episodes_by_season.get(season_num, [])
        watched_flag, progress_value = _season_rollup_from_episode_maps(
            season_num,
            season_episodes,
            watched_episode_keys,
            episode_resume_map,
        )

        url = _plugin_url(
            mode="list_series_episodes",
            series_id=series_id,
            season_num=season_num,
            series_name=series_name,
            series_poster=series_poster,
            series_fanart=series_fanart,
            tmdb_id=tmdb_id,
        )

        li = xbmcgui.ListItem(
            label=_label_with_marker(
                season_title, watched=watched_flag, progress=progress_value, skip=False
            )
        )
        art_dict = _build_art(
            thumb=season_art.get("poster", "") or series_poster,
            poster=season_art.get("poster", "") or series_poster,
            fanart=season_art.get("fanart", "") or series_fanart,
            icon=season_art.get("poster", "") or series_poster,
            fallback="DefaultSeason.png",
        )
        li.setArt(art_dict)

        tag = li.getVideoInfoTag()
        try:
            tag.setMediaType("season")
            tag.setTitle(season_title)
            tag.setTvShowTitle(series_name)
            tag.setSeason(int(season_num))
            if season_plot:
                tag.setPlot(season_plot)
        except Exception:
            pass

        air_date = season_data.get("air_date") or ""
        if air_date:
            _set_tag_year(tag, air_date[:4])
        elif series_info.get("releaseDate"):
            _set_tag_year(tag, str(series_info.get("releaseDate"))[:4])
        _set_tag_rating(tag, season_rating)

        if watched_flag:
            li.setProperty("playcount", "1")
            try:
                tag.setPlaycount(1)
            except Exception:
                pass

        li.setProperty("tvshow.tmdb_id", str(tmdb_id or ""))
        li.setProperty("season", str(season_num))
        li.setProperty("mediatype", "season")

        custom_menu_url = giptv.build_url(
            action="open_context_window",
            item_id=f"season:{series_id}:{season_num}",
            name=season_title,
            play_url="",
            stream_type="series",
            thumb=art_dict.get("thumb", ""),
            poster=art_dict.get("poster", ""),
            fanart=art_dict.get("fanart", ""),
            icon=art_dict.get("icon", ""),
            plot=season_plot,
            rating=str(season_rating or "0"),
            year="",
            tmdb_id=str(tmdb_id or ""),
            channel_id="",
            epg_channel_id="",
            has_archive="0",
            directory_type="",
            directory_id="",
            refresh_mode="",
            sort_label="",
            category_id="",
            category_name=series_name,
            search_query="",
            page="1",
            season=str(season_num),
            favourite_kind="season_folder",
            target_mode="list_series_episodes",
            series_id=str(series_id or ""),
            series_name=series_name,
            season_num=str(season_num),
            resume_progress=str(0 if watched_flag else (progress_value or 0)),
        )
        _add_giptv_context_menu(li, custom_menu_url)
        items.append((url, li, True))

    _add_dir_items(items)
    _log_memory_caches("after list_series_seasons")
    del items, episodes_by_season, series_info_response
    _trim_route_memory(is_live=False)


# ---------------------------------------------------------------------------
# list_series_episodes
# ---------------------------------------------------------------------------


def list_series_episodes(
    series_id, season_num, series_name, series_poster="", series_fanart="", tmdb_id=""
):

    raw_params = (
        sys.argv[2][1:]
        if len(sys.argv) > 2 and sys.argv[2].startswith("?")
        else sys.argv[2]
    )
    params = dict(urlparse.parse_qsl(raw_params))
    series_poster = params.get("series_poster", series_poster)
    series_fanart = params.get("series_fanart", series_fanart)
    tmdb_id = params.get("tmdb_id") or tmdb_id

    xbmcplugin.setPluginCategory(PLUGIN_HANDLE, f"{series_name} - Season {season_num}")
    xbmcplugin.setContent(PLUGIN_HANDLE, "episodes")

    series_info = cache_handler.get("series_info", f"{STATE.username}_{series_id}")
    if not series_info:
        series_info = xtream_api.series_info_by_id(series_id)
    if not isinstance(series_info, dict):
        _notify_and_go_home("Episode data unavailable")
        return

    episodes = series_info.get("episodes", {}).get(str(season_num), [])
    if not episodes:
        episodes = series_info.get("episodes", {}).get(season_num, [])
    if not episodes:
        giptv.notification(
            ADDON.getAddonInfo("name"),
            f"No episodes found for Season {season_num}.",
            icon="INFO",
        )
        return

    tmdb_series_details = _get_tmdb_series_details_cached(tmdb_id) if tmdb_id else None
    tmdb_series_art = (tmdb_series_details or {}).get("art") or {}

    if tmdb_series_art.get("poster"):
        series_poster = tmdb_series_art.get("poster")
    if tmdb_series_art.get("fanart"):
        series_fanart = tmdb_series_art.get("fanart")

    season_data = (
        _get_tmdb_season_details_cached(tmdb_id, int(season_num)) if tmdb_id else None
    )
    season_art = (season_data or {}).get("art") or {}

    watched_episode_keys = set()
    episode_resume_map = {}

    if _is_trakt_ready() and tmdb_id:
        try:
            tv_maps = trakt_api.trakt_get_tv_progress_maps()
            watched_episode_keys = (
                tv_maps.get("watched_episode_keys_by_show", {}).get(str(tmdb_id), set())
                or set()
            )
            episode_resume_map = (
                tv_maps.get("episode_resume_map_by_show", {}).get(str(tmdb_id), {})
                or {}
            )
        except Exception:
            pass

    episode_details_map = {}
    if tmdb_id:
        ep_nums = []
        for ep in episodes:
            try:
                ep_nums.append(int(ep.get("episode_num", 1)))
            except Exception:
                pass
        if ep_nums:
            _pool_map(
                lambda n: _get_tmdb_episode_details_cached(tmdb_id, int(season_num), n),
                ep_nums,
            )
            for n in ep_nums:
                try:
                    episode_details_map[str(n)] = (
                        _get_tmdb_episode_details_cached(
                            tmdb_id, int(season_num), int(n)
                        )
                        or {}
                    )
                except Exception:
                    episode_details_map[str(n)] = {}

    items = []

    for episode in episodes:
        episode_data = episode.get("info")
        if isinstance(episode_data, list):
            episode_data = episode_data[0] if episode_data else {}
        if not isinstance(episode_data, dict):
            episode_data = {}

        episode_num_str = str(episode.get("episode_num", "1"))
        base_title = episode.get("title", f"Episode {episode_num_str}")
        episode_title = (
            f"S{int(season_num):02d}E{int(episode_num_str):02d} - {base_title}"
        )

        stream_id = episode.get("id")
        ext = episode.get("container_extension", "mp4")
        play_url = xtream_api.build_stream_url(
            stream_id=stream_id, stream_type="series", container_extension=ext
        )
        if not play_url:
            continue

        watched_flag = (str(season_num), str(episode_num_str)) in watched_episode_keys
        resume_info = (
            episode_resume_map.get((str(season_num), str(episode_num_str))) or {}
        )
        progress_value = resume_info.get("progress") if resume_info else None

        li = xbmcgui.ListItem(
            label=_label_with_marker(
                episode_title, watched=watched_flag, progress=progress_value
            )
        )

        if watched_flag:
            li.setProperty("playcount", "1")
            try:
                li.getVideoInfoTag().setPlaycount(1)
            except Exception:
                pass

        li.setProperty("IsPlayable", "true")

        episode_icon = episode_data.get("movie_image", "") or episode.get(
            "thumbnail", ""
        )
        tmdb_ep_details = (
            episode_details_map.get(str(episode_num_str), {}) if tmdb_id else {}
        )
        ep_art = (tmdb_ep_details.get("art") or {}) if tmdb_ep_details else {}

        ep_thumb = (
            ep_art.get("thumb")
            or ep_art.get("still")
            or tmdb_ep_details.get("still_path")
            or ""
        )
        if ep_thumb and ep_thumb.startswith("/"):
            ep_thumb = "https://image.tmdb.org/t/p/original{}".format(ep_thumb)

        art_dict = _build_art(
            thumb=ep_thumb
            or episode_icon
            or season_art.get("poster", "")
            or series_poster,
            poster=season_art.get("poster", "") or series_poster,
            fanart=ep_art.get("fanart", "")
            or season_art.get("fanart", "")
            or series_fanart,
            icon=ep_thumb
            or episode_icon
            or season_art.get("poster", "")
            or series_poster,
            fallback="DefaultVideo.png",
        )
        li.setArt(art_dict)

        tag = li.getVideoInfoTag()
        try:
            tag.setTitle(base_title)
            tag.setTvShowTitle(series_name)
            tag.setSeason(int(season_num))
            tag.setEpisode(int(episode_num_str))
            tag.setMediaType("episode")
        except Exception:
            pass

        plot_value = ""
        rating_value = 0
        year_value = 0

        if tmdb_ep_details:
            plot_value = tmdb_ep_details.get("overview") or ""
            rating_value = tmdb_ep_details.get("vote_average") or 0
            air_date = tmdb_ep_details.get("air_date") or ""
            if len(air_date) >= 4 and air_date[:4].isdigit():
                year_value = int(air_date[:4])
            try:
                tag.setPlot(plot_value)
            except Exception:
                pass
            _set_tag_rating(tag, rating_value)
            if air_date:
                try:
                    tag.setFirstAired(air_date)
                except Exception:
                    pass
            try:
                if tmdb_ep_details.get("runtime"):
                    tag.setDuration(int(tmdb_ep_details.get("runtime")))
            except Exception:
                pass
            _set_tag_year(tag, year_value)
        else:
            plot_value = episode_data.get("plot", "") or ""
            try:
                tag.setPlot(plot_value)
            except Exception:
                pass

        if tmdb_id:
            try:
                tag.setUniqueIDs({"tmdb": str(tmdb_id)}, "tmdb")
            except Exception:
                pass
            li.setProperty("tmdbnumber", str(tmdb_id))
            li.setProperty("season", str(season_num))
            li.setProperty("episode", str(episode_num_str))

        metadata = {
            "thumb": art_dict.get("thumb", ""),
            "poster": art_dict.get("poster", ""),
            "fanart": art_dict.get("fanart", ""),
            "icon": art_dict.get("icon", ""),
            "plot": plot_value,
            "rating": rating_value,
            "year": year_value,
            "tmdb_id": str(tmdb_id or ""),
            "stream_type": "series",
            "stream_id": str(stream_id or ""),
            "series_id": str(series_id or ""),
            "series_name": series_name or "",
            "season": str(season_num),
            "episode": str(episode_num_str),
        }

        url = _plugin_url(
            mode="play_stream",
            url=play_url,
            name=episode_title,
            meta=_encode_meta(metadata),
        )

        custom_menu_url = giptv.build_url(
            action="open_context_window",
            item_id=str(stream_id or ""),
            name=episode_title,
            play_url=play_url,
            stream_type="series",
            thumb=art_dict.get("thumb", ""),
            poster=art_dict.get("poster", ""),
            fanart=art_dict.get("fanart", ""),
            icon=art_dict.get("icon", ""),
            plot=plot_value,
            rating=str(rating_value),
            year=str(year_value),
            tmdb_id=str(tmdb_id or ""),
            season=str(season_num),
            episode=str(episode_num_str),
            channel_id="",
            epg_channel_id="",
            has_archive="0",
            directory_type="",
            directory_id="",
            refresh_mode="",
            sort_label="",
            category_id="",
            category_name=series_name,
            search_query="",
            page="1",
            favourite_kind="playable",
            target_mode="play_stream",
            series_id=str(series_id or ""),
            series_name=series_name,
            season_num=str(season_num),
            resume_progress=str(0 if watched_flag else (progress_value or 0)),
        )
        _add_giptv_context_menu(li, custom_menu_url)
        items.append((url, li, False))

    _add_dir_items(items)
    _log_memory_caches("after list_series_episodes")
    del items, episodes, series_info
    _trim_route_memory(is_live=False)


# ---------------------------------------------------------------------------
# Filter prompts
# ---------------------------------------------------------------------------


def prompt_filter_categories(stream_type):
    category_list = _safe_category_list(stream_type)
    if category_list is None:
        _notify_and_open_settings("Xtream server/category response invalid")
        return
    value = _normalize_search_query(
        _safe_nonempty_text(_show_filter_keyboard("Filter"))
    )
    if not value or not _has_category_matches(category_list, value):
        return
    xbmc.executebuiltin(
        "Container.Update({})".format(
            _plugin_url(
                mode="list_categories",
                stream_type=stream_type,
                search_query=value,
                page="1",
            )
        )
    )


def prompt_filter_streams(stream_type, category_id, name):
    stream_list = _safe_stream_list(stream_type, category_id)
    if stream_list is None:
        _notify_and_go_home("Xtream stream response invalid")
        return
    value = _normalize_search_query(
        _safe_nonempty_text(_show_filter_keyboard("Filter"))
    )
    if not value or not any(_stream_matches_query(s, value) for s in stream_list):
        return
    xbmc.executebuiltin(
        "Container.Update({})".format(
            _plugin_url(
                mode="list_streams",
                stream_type=stream_type,
                category_id=category_id,
                name=name,
                search_query=value,
                page="1",
            )
        )
    )


def prompt_filter_series(stream_type, category_id, name):
    series_list = _safe_stream_list(stream_type, category_id)
    if series_list is None:
        _notify_and_go_home("Xtream series response invalid")
        return
    value = _normalize_search_query(
        _safe_nonempty_text(_show_filter_keyboard("Filter"))
    )
    if not value or not any(_stream_matches_query(s, value) for s in series_list):
        return
    xbmc.executebuiltin(
        "Container.Update({})".format(
            _plugin_url(
                mode="list_series_streams",
                stream_type=stream_type,
                category_id=category_id,
                name=name,
                search_query=value,
                page="1",
            )
        )
    )


# ---------------------------------------------------------------------------
# Next episode
# ---------------------------------------------------------------------------


def _sorted_series_episode_rows(episodes_by_season):
    rows = []
    for season_key, season_eps in (episodes_by_season or {}).items():
        try:
            season_num = int(season_key)
        except Exception:
            continue
        for ep in season_eps or []:
            try:
                ep_num = int(ep.get("episode_num") or 0)
            except Exception:
                ep_num = 0
            if ep_num <= 0:
                continue
            rows.append({"season": season_num, "episode": ep_num, "data": ep})
    rows.sort(key=lambda x: (x["season"], x["episode"]))
    return rows


def _build_next_episode_candidate(series_id, tmdb_id, row, series_name=""):
    ep = row.get("data") or {}
    stream_id = str(ep.get("id") or "")
    if not stream_id:
        return None

    ext = ep.get("container_extension", "mp4")
    try:
        play_url = xtream_api.build_stream_url(
            stream_id=stream_id, stream_type="series", container_extension=ext
        )
    except Exception:
        play_url = ""
    if not play_url:
        return None

    season_num = str(row.get("season"))
    episode_num = str(row.get("episode"))

    tmdb_ep_details = {}
    if tmdb_id:
        try:
            tmdb_ep_details = (
                _get_tmdb_episode_details_cached(
                    tmdb_id, int(season_num), int(episode_num)
                )
                or {}
            )
        except Exception:
            pass

    episode_title = (
        ep.get("title")
        or (ep.get("info") or {}).get("title")
        or tmdb_ep_details.get("name")
        or "Episode {}".format(episode_num)
    )
    display_title = "S{:02d}E{:02d} - {}".format(
        int(season_num), int(episode_num), episode_title
    )
    plot_value = (
        tmdb_ep_details.get("overview") or (ep.get("info") or {}).get("plot") or ""
    )
    rating_value = tmdb_ep_details.get("vote_average") or 0
    air_date = tmdb_ep_details.get("air_date") or ""
    year_value = air_date[:4] if len(air_date) >= 4 and air_date[:4].isdigit() else "0"

    thumb = (
        (tmdb_ep_details.get("art") or {}).get("thumb")
        or (tmdb_ep_details.get("art") or {}).get("still")
        or (ep.get("info") or {}).get("movie_image")
        or ep.get("thumbnail")
        or ""
    )
    if thumb and str(thumb).startswith("/"):
        thumb = "https://image.tmdb.org/t/p/original{}".format(thumb)

    poster = thumb
    fanart = (tmdb_ep_details.get("art") or {}).get("fanart") or thumb
    icon = thumb or poster

    return {
        "series_id": str(series_id or ""),
        "series_name": series_name or "",
        "season": season_num,
        "episode": episode_num,
        "stream_id": stream_id,
        "title": display_title,
        "play_url": play_url,
        "thumb": thumb,
        "poster": poster,
        "fanart": fanart,
        "icon": icon,
        "plot": plot_value,
        "rating": rating_value,
        "year": year_value,
        "tmdb_id": str(tmdb_id or ""),
        "stream_type": "series",
        "meta": _encode_meta(
            {
                "thumb": thumb,
                "poster": poster,
                "fanart": fanart,
                "icon": icon,
                "plot": plot_value,
                "rating": rating_value,
                "year": year_value,
                "tmdb_id": str(tmdb_id or ""),
                "stream_type": "series",
                "stream_id": stream_id,
                "series_id": str(series_id or ""),
                "series_name": series_name or "",
                "season": season_num,
                "episode": episode_num,
            }
        ),
    }


def get_next_episode_for_series(
    series_id, tmdb_id="", current_season="", current_episode="", series_name=""
):
    if not series_id:
        giptv.log("[NEXT EPISODE] missing series_id", xbmc.LOGWARNING)
        return None

    series_info = cache_handler.get("series_info", f"{STATE.username}_{series_id}")
    if not series_info:
        series_info = xtream_api.series_info_by_id(series_id)
    if not isinstance(series_info, dict):
        giptv.log("[NEXT EPISODE] series_info unavailable", xbmc.LOGWARNING)
        return None

    if not tmdb_id:
        try:
            info_block = series_info.get("info", {}) or {}
            tmdb_id = _normalize_tmdb_id(
                _extract_tmdb_id(series_info) or _extract_tmdb_id(info_block)
            )
        except Exception:
            tmdb_id = ""

    episodes_by_season = series_info.get("episodes", {}) or {}
    rows = _sorted_series_episode_rows(episodes_by_season)
    if not rows:
        giptv.log("[NEXT EPISODE] no episode rows found", xbmc.LOGWARNING)
        return None

    watched_episode_keys = set()
    episode_resume_map = {}

    if _is_trakt_ready() and tmdb_id:
        try:
            tv_maps = trakt_api.trakt_get_tv_progress_maps() or {}
            watched_episode_keys = (
                tv_maps.get("watched_episode_keys_by_show", {}).get(str(tmdb_id), set())
                or set()
            )
            episode_resume_map = (
                tv_maps.get("episode_resume_map_by_show", {}).get(str(tmdb_id), {})
                or {}
            )
        except Exception:
            pass

    current_index = -1
    try:
        cs = int(current_season)
        ce = int(current_episode)
        for idx, row in enumerate(rows):
            if row["season"] == cs and row["episode"] == ce:
                current_index = idx
                break
    except Exception:
        pass

    if current_index >= 0:
        for row in rows[current_index + 1 :]:
            ep_key = (str(row["season"]), str(row["episode"]))
            if ep_key not in watched_episode_keys:
                candidate = _build_next_episode_candidate(
                    series_id, tmdb_id, row, series_name=series_name
                )
                if candidate:
                    giptv.log(
                        "[NEXT EPISODE] picked first unwatched after current series_id={} season={} episode={}".format(
                            series_id, candidate.get("season"), candidate.get("episode")
                        ),
                        xbmc.LOGINFO,
                    )
                    return candidate

        if current_index + 1 < len(rows):
            candidate = _build_next_episode_candidate(
                series_id, tmdb_id, rows[current_index + 1], series_name=series_name
            )
            if candidate:
                giptv.log(
                    "[NEXT EPISODE] fallback physical next series_id={} season={} episode={}".format(
                        series_id, candidate.get("season"), candidate.get("episode")
                    ),
                    xbmc.LOGINFO,
                )
                return candidate

    best_resume_row = None
    best_resume_progress = 0.0

    for row in rows:
        ep_key = (str(row["season"]), str(row["episode"]))
        if ep_key in watched_episode_keys:
            continue
        resume_info = episode_resume_map.get(ep_key) or {}
        progress = _safe_float(resume_info.get("progress"), 0.0)
        if 0.0 < progress < 98.0 and progress > best_resume_progress:
            best_resume_progress = progress
            best_resume_row = row

    if best_resume_row:
        candidate = _build_next_episode_candidate(
            series_id, tmdb_id, best_resume_row, series_name=series_name
        )
        if candidate:
            giptv.log(
                "[NEXT EPISODE] picked resume row series_id={} season={} episode={} progress={}".format(
                    series_id,
                    candidate.get("season"),
                    candidate.get("episode"),
                    best_resume_progress,
                ),
                xbmc.LOGINFO,
            )
            return candidate

    for row in rows:
        ep_key = (str(row["season"]), str(row["episode"]))
        if ep_key not in watched_episode_keys:
            candidate = _build_next_episode_candidate(
                series_id, tmdb_id, row, series_name=series_name
            )
            if candidate:
                giptv.log(
                    "[NEXT EPISODE] picked first unwatched series_id={} season={} episode={}".format(
                        series_id, candidate.get("season"), candidate.get("episode")
                    ),
                    xbmc.LOGINFO,
                )
                return candidate

    giptv.log("[NEXT EPISODE] no candidate resolved", xbmc.LOGINFO)
    return None


def play_next_episode_from_item(
    series_id, series_name="", season_num="", episode_num=""
):

    series_id = str(series_id or "").strip()
    season_num = str(season_num or "").strip()
    episode_num = str(episode_num or "").strip()

    if not series_id or not season_num or not episode_num:
        giptv.log(
            "[NEXT EPISODE] missing series_id/season_num/episode_num", xbmc.LOGWARNING
        )
        return None

    series_info = cache_handler.get("series_info", f"{STATE.username}_{series_id}")
    if not series_info:
        series_info = xtream_api.series_info_by_id(series_id)
    if not isinstance(series_info, dict):
        giptv.log("[NEXT EPISODE] series_info unavailable", xbmc.LOGWARNING)
        return None

    tmdb_id = ""
    try:
        info_block = series_info.get("info", {}) or {}
        tmdb_id = _normalize_tmdb_id(
            _extract_tmdb_id(series_info) or _extract_tmdb_id(info_block)
        )
    except Exception:
        pass

    candidate = get_next_episode_for_series(
        series_id=series_id,
        tmdb_id=tmdb_id,
        current_season=season_num,
        current_episode=episode_num,
        series_name=series_name,
    )

    if candidate:
        giptv.log(
            "[NEXT EPISODE] resolved candidate series_id={} season={} episode={} title={}".format(
                series_id,
                candidate.get("season"),
                candidate.get("episode"),
                candidate.get("title"),
            ),
            xbmc.LOGINFO,
        )
    else:
        giptv.log("[NEXT EPISODE] no next candidate found", xbmc.LOGINFO)

    return candidate
