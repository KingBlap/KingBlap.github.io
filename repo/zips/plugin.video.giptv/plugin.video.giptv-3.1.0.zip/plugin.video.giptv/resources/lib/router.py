# router.py
# -*- coding: utf-8 -*-

try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse

import urllib.request
import urllib.parse
import json
import base64

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.proxy.proxy_instance import ensure_proxy_running
from resources.lib.navigator import (
    list_favourites,
    add_favourite_from_params,
    remove_favourite_from_params,
    list_history,
    clear_history,
    add_history_item,
    PLUGIN_HANDLE,
    get_current_items,
    root_menu,
    list_streams,
    list_categories,
    list_catchup_dates,
    list_catchup_programmes,
    list_series_streams,
    list_series_seasons,
    list_series_episodes,
    list_continue_movie_versions,
    list_continue_series_versions,
    select_live_version,
    get_next_episode_for_series,
)
from resources.apis import trakt_api
from resources.lib.player import trakt_scrobbler
from resources.lib.player.history_player import set_pending_playback

import resources.apis.xtream_api as xtream_api
import resources.lib.manager.search_manager as search
import resources.utils.giptv as giptv

ADDON = xbmcaddon.Addon()


def open_addon_settings():
    giptv.open_settings()


def _refresh_current_container():
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        giptv.log(f"[ROUTER] container refresh failed: {e}", xbmc.LOGWARNING)


def _decode_meta(meta_value):
    if not meta_value:
        return {}

    try:
        raw = base64.urlsafe_b64decode(meta_value.encode("utf-8")).decode("utf-8")
        return json.loads(raw)
    except Exception as e:
        giptv.log(f"Failed to decode meta: {e}", xbmc.LOGWARNING)
        return {}


def _safe_int(value, default=0):
    try:
        if value in (None, "", "None", "null"):
            return default
        return int(float(value))
    except Exception:
        return default


def build_stream_fallbacks(url):
    fallbacks = [url]

    if url.endswith(".ts"):
        fallbacks.append(url[:-3] + ".m3u8")

    base = url.rsplit(".", 1)[0]
    fallbacks.append(base)

    seen = set()
    out = []
    for u in fallbacks:
        if u and u not in seen:
            out.append(u)
            seen.add(u)

    return out


HEADER_PROFILES = [
    {"User-Agent": "VLC/3.0.20 LibVLC/3.0.20"},
    {"User-Agent": "Lavf/60.16.100"},
    {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        )
    },
]


def _get_setting(key, default=""):
    try:
        value = ADDON.getSetting(key)
        return value if value != "" else default
    except Exception:
        return default


def _set_setting(key, value):
    try:
        ADDON.setSetting(key, str(value))
    except Exception:
        pass


def _is_first_run():
    return _get_setting("first_run_done", "false").lower() != "true"


def open_with_rotating_headers(url, timeout):
    for headers in HEADER_PROFILES:
        try:
            giptv.log(f"Trying headers: {headers['User-Agent']}", xbmc.LOGINFO)
            req = urllib.request.Request(url, headers=headers)
            return urllib.request.urlopen(req, timeout=timeout)
        except Exception as e:
            giptv.log(f"Header failed: {e}", xbmc.LOGINFO)

    raise RuntimeError("All header profiles failed to open stream")


def _get_local_kodi_resume():
    try:
        resume_seconds = _safe_int(xbmc.getInfoLabel("ListItem.ResumeTime"), 0)
        total_seconds = _safe_int(xbmc.getInfoLabel("ListItem.ResumeTimeTotal"), 0)

        resume_progress = 0.0
        if total_seconds > 0 and resume_seconds > 0:
            resume_progress = max(
                0.0,
                min(100.0, (float(resume_seconds) / float(total_seconds)) * 100.0),
            )

        giptv.log(
            f"[KODI LOCAL RESUME] seconds={resume_seconds} total={total_seconds} progress={resume_progress}",
            xbmc.LOGINFO,
        )

        return {
            "resume_seconds": resume_seconds,
            "resume_total": total_seconds,
            "resume_progress": resume_progress,
        }
    except Exception as e:
        giptv.log(f"[KODI LOCAL RESUME] failed: {e}", xbmc.LOGWARNING)
        return {
            "resume_seconds": 0,
            "resume_total": 0,
            "resume_progress": 0.0,
        }


def stream_responds(url, timeout=2):
    try:
        with open_with_rotating_headers(url, timeout) as resp:
            status = getattr(resp, "status", 200)
            return status == 200
    except Exception:
        return False


def _is_vod_url(url):
    url_lower = url.lower()
    return (
        url_lower.endswith((".mkv", ".mp4"))
        or "/movie/" in url_lower
        or "/series/" in url_lower
        or "vod" in url_lower
    )


def _is_hls_url(url):
    return ".m3u8" in url.lower()


def _detect_stream_type(url):
    url_lower = url.lower()
    if "/live/" in url_lower:
        return "live"
    if "/movie/" in url_lower or "vod" in url_lower:
        return "vod"
    return "series"


def _is_catchup_url(url):
    return "/timeshift/" in url.lower()


def _extract_stream_id(url):
    last_part = url.split("/")[-1]
    return last_part.split(".")[0]


def _refresh_runtime_state():
    try:
        from resources.utils.config import ensure_api_ready

        return ensure_api_ready()

    except Exception as e:
        giptv.log(f"[ROUTER] runtime state refresh failed: {e}", xbmc.LOGWARNING)

    retry = xbmcgui.Dialog().yesno(
        ADDON.getAddonInfo("name"),
        "Could not connect to the selected server.",
        "Would you like to try again or open settings?",
        yeslabel="Try Again",
        nolabel="Open Settings",
    )

    if retry:
        try:
            from resources.utils.config import ensure_api_ready

            return ensure_api_ready()
        except Exception as e:
            giptv.log(
                f"[ROUTER] runtime state refresh retry failed: {e}",
                xbmc.LOGWARNING,
            )
            giptv.notification(
                ADDON.getAddonInfo("name"),
                "Still could not connect to server.",
                icon="ERROR",
            )
            return False

    try:
        xbmc.sleep(200)
        giptv.open_settings()
    except Exception:
        pass

    return False


def _clear_any_stale_trakt_state():
    try:
        trakt_scrobbler.stop_and_clear_current_playback("router_clear")
    except Exception as e:
        giptv.log(f"[TRAKT ROUTER CLEAR] failed: {e}", xbmc.LOGWARNING)
        try:
            trakt_scrobbler.clear_current_playback()
        except Exception:
            pass


def _handle_trakt_mark_watched(url_params):
    stream_type = url_params.get("stream_type", [""])[0]
    tmdb_id = url_params.get("tmdb_id", [""])[0]
    ok = False

    if stream_type == "vod":
        ok = trakt_api.trakt_mark_movie_watched(tmdb_id)

    elif stream_type == "series":
        season = url_params.get("season", [""])[0]
        episode = url_params.get("episode", [""])[0]
        ok = trakt_api.trakt_mark_episode_watched(tmdb_id, season, episode)

    if ok:
        _refresh_current_container()
        return

    giptv.notification(
        ADDON.getAddonInfo("name"),
        "Failed to mark watched on Trakt",
        icon="ERROR",
    )


def _handle_trakt_unmark_watched(url_params):
    stream_type = url_params.get("stream_type", [""])[0]
    tmdb_id = url_params.get("tmdb_id", [""])[0]
    ok = False

    if stream_type == "vod":
        ok = trakt_api.trakt_unmark_movie_watched(tmdb_id)

    elif stream_type == "series":
        season = url_params.get("season", [""])[0]
        episode = url_params.get("episode", [""])[0]
        ok = trakt_api.trakt_unmark_episode_watched(tmdb_id, season, episode)

    if ok:
        _refresh_current_container()
        return

    giptv.notification(
        ADDON.getAddonInfo("name"),
        "Failed to unmark watched on Trakt",
        icon="ERROR",
    )


def _write_history_entry(url, name, stream_type, metadata=None):
    metadata = metadata or {}

    stream_id = metadata.get("stream_id") or _extract_stream_id(url)

    add_history_item(
        item_id=str(stream_id),
        title=name,
        stream_type=stream_type,
        thumb=metadata.get("thumb", ""),
        fanart=metadata.get("fanart", ""),
        poster=metadata.get("poster", ""),
        icon=metadata.get("icon", ""),
        plot=metadata.get("plot", ""),
        rating=metadata.get("rating", 0),
        year=metadata.get("year", 0),
        tmdb_id=metadata.get("tmdb_id", ""),
        channel_id=metadata.get("channel_id", ""),
        play_url=url,
        resume_time=0,
        stream_id=str(stream_id or ""),
        is_live_epg=(stream_type == "live"),
        season=metadata.get("season", ""),
        episode=metadata.get("episode", ""),
        series_id=metadata.get("series_id", ""),
        series_name=metadata.get("series_name", ""),
    )


def _resolve_direct_stream(url, name, is_live=False, metadata=None):
    metadata = metadata or {}

    stream_type = metadata.get("stream_type") or _detect_stream_type(url)
    if is_live and stream_type == "series":
        stream_type = "live"

    li = xbmcgui.ListItem(path=url)
    li.setLabel(name)
    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)
    li.setProperty("seekable", "false" if is_live else "true")

    if is_live:
        li.setProperty("isLive", "true")

    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, li)


def _resolve_proxied_stream(url, name, port, metadata=None, is_live=True):
    metadata = metadata or {}

    proxied = "http://127.0.0.1:{}/stream?u={}".format(
        port,
        urllib.parse.quote(url, safe=""),
    )

    giptv.log(f"Using proxied stream: {proxied}", xbmc.LOGINFO)

    li = xbmcgui.ListItem(path=proxied)
    li.setLabel(name)
    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)
    li.setProperty("isLive", "true" if is_live else "false")
    li.setProperty("seekable", "false" if is_live else "true")

    xbmcplugin.setResolvedUrl(PLUGIN_HANDLE, True, li)


def play_stream(url, name, metadata=None):
    metadata = metadata or {}

    is_vod = _is_vod_url(url)
    is_hls = _is_hls_url(url)
    is_catchup = _is_catchup_url(url)
    is_live = not is_vod and not is_catchup

    giptv.log(
        f"name={name} vod={is_vod} catchup={is_catchup} hls={is_hls} url={url}",
        xbmc.LOGINFO,
    )

    if is_hls:
        giptv.log(f"Using direct HLS stream: {url}", xbmc.LOGINFO)
        _resolve_direct_stream(url, name, is_live=is_live, metadata=metadata)
        return

    candidates = build_stream_fallbacks(url)
    working = None

    for candidate in candidates:
        giptv.log(f"Trying stream: {candidate}", xbmc.LOGINFO)
        if stream_responds(candidate):
            working = candidate
            giptv.log(f"Stream OK: {candidate}", xbmc.LOGINFO)
            break

    if not working:
        try:
            _clear_any_stale_trakt_state()
        except Exception:
            pass

        xbmcgui.Dialog().notification(
            "Playback failed",
            "Stream unavailable",
            xbmcgui.NOTIFICATION_ERROR,
            5000,
        )
        return

    if _is_hls_url(working):
        giptv.log(f"Fallback selected direct HLS stream: {working}", xbmc.LOGINFO)
        _resolve_direct_stream(working, name, is_live=is_live, metadata=metadata)
        return

    port = ensure_proxy_running()

    if is_vod or is_catchup:
        giptv.log(
            f"Using proxied {'catch-up' if is_catchup else 'VOD'} stream: {working}",
            xbmc.LOGINFO,
        )
        _resolve_proxied_stream(working, name, port, metadata=metadata, is_live=False)
        return

    _resolve_proxied_stream(working, name, port, metadata=metadata, is_live=True)


def _load_trakt_resume_into_metadata(metadata):
    metadata = metadata or {}
    stream_type = metadata.get("stream_type")
    tmdb_id = metadata.get("tmdb_id")

    if stream_type not in ("vod", "series") or not tmdb_id:
        return metadata

    try:
        trakt_resume_data = None

        if stream_type == "vod":
            trakt_resume_data = trakt_api.trakt_get_movie_resume(tmdb_id)

        elif (
            stream_type == "series"
            and metadata.get("season")
            and metadata.get("episode")
        ):
            trakt_resume_data = trakt_api.trakt_get_episode_resume(
                tmdb_id,
                metadata.get("season"),
                metadata.get("episode"),
            )

        trakt_progress = 0.0
        trakt_seconds = 0
        trakt_playback_id = None

        if trakt_resume_data:
            trakt_progress = float(trakt_resume_data.get("progress") or 0.0)
            trakt_seconds = _safe_int(trakt_resume_data.get("resume_seconds"), 0)
            trakt_playback_id = trakt_resume_data.get("playback_id")

        local_resume = _get_local_kodi_resume()
        local_progress = float(local_resume.get("resume_progress") or 0.0)
        local_seconds = _safe_int(local_resume.get("resume_seconds"), 0)
        local_total = _safe_int(local_resume.get("resume_total"), 0)

        use_local = False

        if local_seconds > 0:
            if local_seconds >= (trakt_seconds + 10):
                use_local = True
            elif local_progress >= (trakt_progress + 1.0):
                use_local = True

        chosen_seconds = trakt_seconds
        chosen_progress = trakt_progress

        if use_local:
            chosen_seconds = local_seconds
            chosen_progress = local_progress

            giptv.log(
                f"[RESUME PICK] using KODI local over Trakt "
                f"(local={local_seconds}s/{local_progress}%, trakt={trakt_seconds}s/{trakt_progress}%)",
                xbmc.LOGINFO,
            )

            try:
                if chosen_progress > 0.0 and chosen_progress < 95.0:
                    if stream_type == "vod":
                        trakt_api.trakt_save_movie_progress(
                            tmdb_id,
                            chosen_progress,
                            current_time=chosen_seconds,
                            total_time=local_total,
                        )
                    elif stream_type == "series":
                        trakt_api.trakt_save_episode_progress(
                            tmdb_id,
                            metadata.get("season"),
                            metadata.get("episode"),
                            chosen_progress,
                            current_time=chosen_seconds,
                            total_time=local_total,
                        )

                    giptv.log(
                        f"[RESUME SYNC] pushed local resume to Trakt "
                        f"seconds={chosen_seconds} progress={chosen_progress}",
                        xbmc.LOGINFO,
                    )
            except Exception as e:
                giptv.log(f"[RESUME SYNC] failed: {e}", xbmc.LOGWARNING)

        else:
            giptv.log(
                f"[RESUME PICK] using Trakt "
                f"(local={local_seconds}s/{local_progress}%, trakt={trakt_seconds}s/{trakt_progress}%)",
                xbmc.LOGINFO,
            )

        if chosen_progress > 0.0 and chosen_progress < 95.0:
            metadata["resume_progress"] = chosen_progress

        if chosen_seconds > 0:
            metadata["resume_seconds"] = chosen_seconds

        if trakt_playback_id is not None:
            metadata["trakt_playback_id"] = trakt_playback_id

        giptv.log(
            f"[TRAKT RESUME LOAD] tmdb_id={metadata.get('tmdb_id')} "
            f"season={metadata.get('season')} episode={metadata.get('episode')} "
            f"resume_seconds={metadata.get('resume_seconds', 0)} "
            f"resume_progress={metadata.get('resume_progress', 0)} "
            f"playback_id={metadata.get('trakt_playback_id', '')}",
            xbmc.LOGINFO,
        )

    except Exception as e:
        giptv.log(f"[TRAKT RESUME LOAD] failed: {e}", xbmc.LOGWARNING)

    return metadata


def _handle_play(url_params):
    url = url_params.get("url", [""])[0]
    name = url_params.get("name", [""])[0]
    metadata = _decode_meta(url_params.get("meta", [""])[0])

    giptv.log(
        f"play_stream name={name} url={url} meta_keys={list(metadata.keys())}",
        xbmc.LOGINFO,
    )

    giptv.log(
        f"[TRAKT PLAY] stream_type={metadata.get('stream_type')} "
        f"tmdb_id={metadata.get('tmdb_id')} season={metadata.get('season')} "
        f"episode={metadata.get('episode')}",
        xbmc.LOGINFO,
    )

    stream_type = metadata.get("stream_type")

    if stream_type in ("vod", "series"):
        metadata = _load_trakt_resume_into_metadata(metadata)

        if stream_type == "series":
            try:
                series_id = str(metadata.get("series_id") or "").strip()
                tmdb_id = str(metadata.get("tmdb_id") or "").strip()
                season = str(metadata.get("season") or "").strip()
                episode = str(metadata.get("episode") or "").strip()
                series_name = str(metadata.get("series_name") or "").strip()

                if series_id and season and episode:
                    next_data = get_next_episode_for_series(
                        series_id=series_id,
                        tmdb_id=tmdb_id,
                        current_season=season,
                        current_episode=episode,
                        series_name=series_name,
                    )

                    if next_data:
                        metadata["next_episode"] = {
                            "play_url": next_data.get("play_url", ""),
                            "title": next_data.get("title", ""),
                            "meta": next_data.get("meta", ""),
                            "series_id": next_data.get("series_id", ""),
                            "season": next_data.get("season", ""),
                            "episode": next_data.get("episode", ""),
                            "stream_id": next_data.get("stream_id", ""),
                        }

                        giptv.log(
                            "[NEXT EPISODE] preloaded next "
                            "series_id={} season={} episode={} title={}".format(
                                series_id,
                                next_data.get("season"),
                                next_data.get("episode"),
                                next_data.get("title"),
                            ),
                            xbmc.LOGINFO,
                        )
                    else:
                        giptv.log(
                            "[NEXT EPISODE] no preload candidate "
                            "series_id={} season={} episode={}".format(
                                series_id,
                                season,
                                episode,
                            ),
                            xbmc.LOGINFO,
                        )
            except Exception as e:
                giptv.log(f"[NEXT EPISODE] preload failed: {e}", xbmc.LOGWARNING)

        trakt_scrobbler.set_current_playback(metadata)
    else:
        _clear_any_stale_trakt_state()

    pending = {
        "title": name,
        "name": name,
        "play_url": url,
        "thumb": metadata.get("thumb", ""),
        "poster": metadata.get("poster", ""),
        "fanart": metadata.get("fanart", ""),
        "icon": metadata.get("icon", ""),
        "plot": metadata.get("plot", ""),
        "rating": metadata.get("rating", 0),
        "year": metadata.get("year", 0),
        "tmdb_id": metadata.get("tmdb_id", ""),
        "stream_type": metadata.get("stream_type", ""),
        "channel_id": metadata.get("channel_id", ""),
        "stream_id": str(metadata.get("stream_id", "")),
        "series_id": str(metadata.get("series_id", "")),
        "series_name": metadata.get("series_name", ""),
        "season": metadata.get("season", ""),
        "episode": metadata.get("episode", ""),
    }

    set_pending_playback(pending)
    play_stream(url, name, metadata)


def _handle_add_favourite(url_params):
    add_favourite_from_params(
        item_id=url_params.get("item_id", [""])[0],
        title=url_params.get("title", [""])[0],
        stream_type=url_params.get("stream_type", [""])[0],
        play_url=url_params.get("play_url", [""])[0],
        thumb=url_params.get("thumb", [""])[0],
        poster=url_params.get("poster", [""])[0],
        fanart=url_params.get("fanart", [""])[0],
        icon=url_params.get("icon", [""])[0],
        plot=url_params.get("plot", [""])[0],
        rating=url_params.get("rating", ["0"])[0],
        year=url_params.get("year", ["0"])[0],
        tmdb_id=url_params.get("tmdb_id", [""])[0],
        channel_id=url_params.get("channel_id", [""])[0],
        stream_id=url_params.get("stream_id", [""])[0],
        favourite_kind=url_params.get("favourite_kind", ["playable"])[0],
        target_mode=url_params.get("target_mode", [""])[0],
        series_id=url_params.get("series_id", [""])[0],
        series_name=url_params.get("series_name", [""])[0],
        season_num=url_params.get("season_num", [""])[0],
        episode=url_params.get("episode", [""])[0],
        has_archive=url_params.get("has_archive", ["0"])[0],
        epg_channel_id=url_params.get("epg_channel_id", [""])[0],
    )
    giptv.notification(
        ADDON.getAddonInfo("name"),
        "Added to Favourites",
        icon="INFO",
    )
    _refresh_current_container()


def _handle_remove_favourite(url_params):
    remove_favourite_from_params(item_id=url_params.get("item_id", [""])[0])
    giptv.notification(
        ADDON.getAddonInfo("name"),
        "Removed from Favourites",
        icon="INFO",
    )
    _refresh_current_container()


def _handle_recently_watched():
    list_history()


def _handle_clear_history():
    clear_history()
    giptv.notification(
        ADDON.getAddonInfo("name"),
        "Recently Watched Reset Done",
        icon="INFO",
    )
    _refresh_current_container()


def _handle_search(url_params):
    current_items = get_current_items(
        url_params.get("stream_type", [None])[0],
        url_params.get("category_id", [None])[0],
    )
    search.dynamic_filter_search(items=current_items)


def handle_routing(url_params):
    _refresh_runtime_state()
    mode = url_params.get("mode", [None])[0]

    # Let settings/tools routes work even if server is not ready.
    no_state_modes = {
        None,
        "root_menu",
        "open_settings",
        "clear_history",
        "trakt_mark_watched",
        "trakt_unmark_watched",
        "add_favourite",
        "remove_favourite",
    }

    if mode not in no_state_modes:
        if not _refresh_runtime_state():
            giptv.log(
                "[ROUTER] Aborting route: runtime state unavailable", xbmc.LOGWARNING
            )
            return

    search_query = url_params.get("search_query", [None])[0]
    query = url_params.get("query", [""])[0]

    giptv.log(
        f"mode={mode} search_query={search_query} query={query} params={list(url_params.keys())}",
        xbmc.LOGINFO,
    )

    if mode is None:
        if _is_first_run():
            giptv.log("Initial launch → first run tools window", xbmc.LOGINFO)
            _set_setting("first_run_done", "true")
            xbmc.executebuiltin(
                f"RunPlugin(plugin://{ADDON.getAddonInfo('id')}/?action=open_tools_window)"
            )
            return

        giptv.log("Initial launch → root menu", xbmc.LOGINFO)
        root_menu()
        return

    if mode == "root_menu":
        root_menu()
        return

    if mode == "list_streams":
        list_streams(
            url_params.get("stream_type", [""])[0],
            url_params.get("category_id", [""])[0],
            url_params.get("name", [""])[0],
            search_query,
            url_params.get("page", ["1"])[0],
        )
        return

    if mode == "select_live_version":
        select_live_version(
            url_params.get("category_id", [""])[0],
            url_params.get("version_key", [""])[0],
            url_params.get("name", [""])[0],
            url_params.get("versions", [""])[0],
        )
        return

    if mode == "catchup_dates":
        s_id = url_params.get("stream_id", [""])[0]
        c_id = url_params.get("channel_id", [""])[0]
        name = (
            url_params.get("name", [""])[0]
            or url_params.get("title", [""])[0]
            or url_params.get("channel_name", [""])[0]
        )

        if s_id and c_id:
            list_catchup_dates(
                stream_id=s_id,
                channel_id=c_id,
                name=name,
            )
        return

    if mode == "list_catchup_programmes":
        s_id = url_params.get("stream_id", [""])[0]
        c_id = url_params.get("channel_id", [""])[0]
        date = url_params.get("date", [""])[0]
        name = url_params.get("name", [""])[0]

        if s_id and c_id and date:
            list_catchup_programmes(
                stream_id=s_id,
                channel_id=c_id,
                date=date,
                name=name,
            )
        return

    if mode == "list_series_streams":
        list_series_streams(
            url_params.get("stream_type", [""])[0],
            url_params.get("category_id", [""])[0],
            url_params.get("name", [""])[0],
            search_query,
            url_params.get("page", ["1"])[0],
        )
        return

    if mode == "list_series_seasons":
        list_series_seasons(
            url_params.get("series_id", [""])[0],
            url_params.get("series_name", [""])[0],
        )
        return

    if mode == "list_series_episodes":
        list_series_episodes(
            url_params.get("series_id", [""])[0],
            url_params.get("season_num", [""])[0],
            url_params.get("series_name", [""])[0],
        )
        return

    if mode == "play_next_episode":
        try:
            series_id = url_params.get("series_id", [""])[0]
            tmdb_id = url_params.get("tmdb_id", [""])[0]
            season = url_params.get("season", [""])[0]
            episode = url_params.get("episode", [""])[0]
            series_name = url_params.get("series_name", [""])[0]

            next_data = get_next_episode_for_series(
                series_id=series_id,
                tmdb_id=tmdb_id,
                current_season=season,
                current_episode=episode,
                series_name=series_name,
            )

            if not next_data:
                giptv.notification(
                    ADDON.getAddonInfo("name"),
                    "No next episode found",
                    icon="INFO",
                )
                return

            next_url = next_data.get("play_url")
            next_name = next_data.get("title")
            next_meta = next_data.get("meta") or ""

            if not next_url or not next_name:
                giptv.notification(
                    ADDON.getAddonInfo("name"),
                    "No next episode found",
                    icon="INFO",
                )
                return

            xbmc.executebuiltin(
                "PlayMedia(plugin://{}/?mode=play_stream&url={}&name={}&meta={})".format(
                    ADDON.getAddonInfo("id"),
                    urlparse.quote(next_url, safe=""),
                    urlparse.quote(next_name, safe=""),
                    urlparse.quote(next_meta, safe=""),
                )
            )
            _refresh_current_container()
        except Exception as e:
            giptv.log(f"[ROUTER] play_next_episode failed: {e}", xbmc.LOGWARNING)
            giptv.notification(
                ADDON.getAddonInfo("name"),
                "Failed to play next episode",
                icon="ERROR",
            )
        return

    if mode == "continue_movie_versions":
        list_continue_movie_versions(
            url_params.get("tmdb_id", [""])[0],
            url_params.get("title", [""])[0],
        )
        return

    if mode == "continue_series_versions":
        list_continue_series_versions(
            url_params.get("tmdb_id", [""])[0],
            url_params.get("title", [""])[0],
        )
        return

    if mode == "play_stream":
        _handle_play(url_params)
        return

    if mode == "play_catchup":
        _handle_play(url_params)
        return

    if mode == "open_settings":
        open_addon_settings()
        return

    if mode == "recently_watched":
        _handle_recently_watched()
        return

    if mode == "clear_history":
        _handle_clear_history()
        return

    if mode == "favourites":
        list_favourites()
        return

    if mode == "add_favourite":
        _handle_add_favourite(url_params)
        return

    if mode == "remove_favourite":
        _handle_remove_favourite(url_params)
        return

    if mode == "trakt_mark_watched":
        _handle_trakt_mark_watched(url_params)
        return

    if mode == "trakt_unmark_watched":
        _handle_trakt_unmark_watched(url_params)
        return

    if mode == "search":
        _handle_search(url_params)
        return

    if mode == "global_search":
        if query:
            search.global_search(query)
        else:
            search.global_search()
        return

    if mode == "global_vod_search":
        if query:
            search.global_vod_search(query)
        else:
            search.global_vod_search()
        return

    if mode == "global_series_search":
        if query:
            search.global_series_search(query)
        else:
            search.global_series_search()
        return

    if mode == "global_live_search":
        if query:
            search.global_live_search(query)
        else:
            search.global_live_search()
        return

    if mode == "list_categories":
        list_categories(
            url_params.get("stream_type", [xtream_api.LIVE_TYPE])[0],
            search_query,
            url_params.get("page", ["1"])[0],
        )
        return

    giptv.log(f"Unknown mode received: {mode}", xbmc.LOGERROR)
    giptv.ok_dialog(
        ADDON.getAddonInfo("name"),
        f"Unknown mode: {mode}",
    )
