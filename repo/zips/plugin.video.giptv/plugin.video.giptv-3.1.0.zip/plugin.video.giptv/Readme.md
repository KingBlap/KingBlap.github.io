GIPTV Kodi Plugin

A dedicated Kodi video addon for accessing streams from an Xtream Codes compatible IPTV service. This plugin uses the official Xtream Codes API endpoints for reliable authentication, navigation, and stream playback.
Features

    Secure Authentication: User credentials (Server URL, Username, and Password) are stored securely within the Kodi Addon Settings.

    Live TV Access: Browse and play Live TV channels organized by category.

    VOD & Series Support: (Foundation built-in) Future support for browsing Movies (VOD) and TV Series.

    Dynamic URL Generation: Stream URLs are built automatically using the Xtream Codes format, ensuring correct playback.

Installation and Setup

1. Configuration

After installing the addon in Kodi (via "Install from zip file"):

    Navigate to the Video Add-ons section.

    Right-click (or long-press/context menu) on the GIPTV Client addon.

    Select Settings.

    Under the Account Details tab, enter the following required information:

        Server URL: The full URL of your provider (e.g., http://vpn.hddsdsakd.xyz).

        Username: Your Xtream Codes username.

        Password: Your Xtream Codes password.

    Click OK to save the changes.

2. Usage

   Open the GIPTV Client addon.

   The addon will attempt to authenticate and display your Live TV Categories.

   Select a category to view the list of available channels.

   Select a channel to begin playback.

## Live TV options and PVR integration

- Hide a group from its GIPTV context menu, or use the separate **Channel Groups** settings section to manage hidden Live TV, Movie, and TV Series groups. Hidden live groups are also omitted from PVR exports.
- **Catch-up window (days)** defaults to seven days and can be changed in settings (subject to the provider's available archive and EPG data).
- **Condense channel quality versions** groups SD/HD/FHD/UHD/4K and codec variants and asks which version to play.
- IPTV Merge discovers GIPTV as an add-on source through `iptv_merge.py`; add GIPTV once as a playlist source and once as an EPG source.
- IPTV Simple setup is automatic by default. GIPTV maintains local `playlist.m3u8` and `epg.xml` files, installs/enables IPTV Simple when available, and creates a dedicated **GIPTV** instance without replacing other PVR configurations. The refresh interval and a manual sync action are under **PVR / IPTV Simple** settings.
- Trakt supports device authorization, scrobbling, resume progress, watched/unwatched state, Watchlist, Collection, and persistent background cache warming.
- Saved favourites and history are checked against the current provider inventory. Missing entries are labelled as unavailable and can be removed from **Check Saved Streams** without silent data loss.

# **_NOTE_**

Will be making changes to improve overall addon so keep it updated!!!
Install this repo for the plugin [GFLIX REPO](https://g00380316.github.io/GIPTV/).
