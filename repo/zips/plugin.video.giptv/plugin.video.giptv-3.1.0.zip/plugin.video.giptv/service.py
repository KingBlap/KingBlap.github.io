# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui

from resources.utils import giptv
from resources.utils.config import ensure_api_ready
from resources.lib.player.trakt_scrobbler import TraktPlayer
from resources.lib.player.proxy import ProxyPlayer
from resources.lib.player.history_player import HistoryPlayer
from resources.lib.proxy.proxy_instance import stop_proxy

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
_TRAKT_SETTING_IDS = {
    "trakt_access_token",
    "trakt_refresh_token",
    "trakt_expires_at",
    "trakt_username",
}


def _tracked_settings_snapshot():
    keys = [
        "account",
        "server", "username", "password",
        "server1", "username1", "password1",
        "server2", "username2", "password2",
        "epg_url", "epg_url1", "epg_url2",
        "epg_offset", "epg_offset1", "epg_offset2",
        "catchup_offset", "catchup_offset1", "catchup_offset2",
        "catchup_days", "hidden_channel_groups",
        "stream_format", "stream_format1", "stream_format2",
        "iptv_simple.enabled", "iptv_simple.refresh_hours",
        "library_health.enabled", "library_health.interval_hours",
    ] + sorted(_TRAKT_SETTING_IDS)
    return {key: ADDON.getSetting(key) for key in keys}


_LAST_SETTINGS_SNAPSHOT = _tracked_settings_snapshot()


# ============================================================
#  PROFILE / UPDATE LOCK HELPERS
# ============================================================


def get_profile_path(subpath=""):
    base = "special://profile/addon_data/{}/".format(ADDON_ID)
    if subpath:
        base = base + subpath.lstrip("/")
    return xbmcvfs.translatePath(base)


def ensure_profile_dir():
    path = get_profile_path()
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def get_service_lock_path():
    ensure_profile_dir()
    return get_profile_path(".serviceRan")


def read_service_lock():
    path = get_service_lock_path()

    if not xbmcvfs.exists(path):
        return ""

    try:
        f = xbmcvfs.File(path, "r")
        try:
            return (f.read() or "").strip()
        finally:
            try:
                f.close()
            except Exception:
                pass
    except Exception as e:
        giptv.log("Failed to read service lock: {}".format(e), xbmc.LOGWARNING)
        return ""


def write_service_lock(version):
    ensure_profile_dir()
    path = get_service_lock_path()

    try:
        f = xbmcvfs.File(path, "w")
        try:
            f.write(str(version))
        finally:
            try:
                f.close()
            except Exception:
                pass
    except Exception as e:
        giptv.log("Failed to write service lock: {}".format(e), xbmc.LOGERROR)


def _version_tuple(version):
    try:
        return tuple(int(part) for part in str(version).split("."))
    except Exception:
        return (0, 0, 0)


def show_changelog():
    from resources.lib.windows.changelog import GIPTVChangeLogDialog

    addon = xbmcaddon.Addon()
    version = addon.getAddonInfo("version")

    body = (
        "[B][COLOR FF2A82DA]Automatic Kodi TV Integration[/COLOR][/B][CR]"
        "• GIPTV now owns a local M3U playlist and XMLTV guide.[CR]"
        "• IPTV Simple is installed, enabled, and configured automatically.[CR]"
        "• Catch-up metadata and the configurable archive window are exported natively.[CR][CR]"
        "[B][COLOR FF2A82DA]Trakt Completed and Hardened[/COLOR][/B][CR]"
        "• Reliable scrobbling, resume, watched state, and token refresh.[CR]"
        "• Added Trakt Watchlist and Collection actions.[CR]"
        "• Persistent cache warming reduces repeated network requests.[CR][CR]"
        "[B][COLOR FF2A82DA]Saved Item Health[/COLOR][/B][CR]"
        "• Favourites and Recently Watched are checked against provider inventories.[CR]"
        "• Unavailable entries are clearly warned and can be removed safely.[CR][CR]"
        "[B][COLOR FF2A82DA]Live TV and Performance[/COLOR][/B][CR]"
        "• Separate hidden group management for Live TV, Movies, and Series.[CR]"
        "• Optional channel-version condensation preserves EPG and catch-up.[CR]"
        "• Faster indexed lookups, atomic persistence, and reduced duplicate work.[CR]"
    )
    try:
        addon_path = xbmcvfs.translatePath(addon.getAddonInfo("path"))

        dialog = GIPTVChangeLogDialog(
            "giptv_changelog.xml",
            addon_path,
            "Default",
            "1080i",
            title="GIPTV Updated",
            version="v{}".format(version),
            subtitle="Here is what changed in this version.",
            body=body,
            footer="Thanks for using GIPTV. Press OK or Back to close.",
        )

        dialog.doModal()
        del dialog

    except Exception as e:
        giptv.log("Failed to show changelog window: {}".format(e), xbmc.LOGWARNING)

        try:
            xbmcgui.Dialog().ok(
                addon.getAddonInfo("name"),
                "GIPTV updated to v{}[CR][CR]{}".format(version, body),
            )
        except Exception:
            pass


def run_update_tasks_once():
    current_version = ADDON.getAddonInfo("version")
    last_ran_version = read_service_lock()

    if last_ran_version == current_version:
        giptv.log(
            "Update tasks already ran for {}".format(current_version),
            xbmc.LOGINFO,
        )
        return

    giptv.log(
        "Running one-time update tasks for {} previous={}".format(
            current_version,
            last_ran_version or "none",
        ),
        xbmc.LOGINFO,
    )

    if _version_tuple(current_version) <= _version_tuple("2.6.1"):
        try:
            giptv.log("Applying legacy cache reset", xbmc.LOGINFO)
            giptv.wipe_all_thumbnails()
            giptv.clear_cache()
            giptv.clear_search_index()
        except Exception as e:
            giptv.log("Legacy cache reset failed: {}".format(e), xbmc.LOGWARNING)

    write_service_lock(current_version)

    xbmc.sleep(500)
    show_changelog()


# ============================================================
#  SETTINGS / ACCOUNT HELPERS
# ============================================================


def _setting(key, default=""):
    try:
        value = ADDON.getSetting(key)
        return value if value not in (None, "") else default
    except Exception:
        return default


def _normalise_server(server):
    server = str(server or "").strip().rstrip("/")
    if not server:
        return ""

    if not server.startswith("http://") and not server.startswith("https://"):
        server = "http://" + server

    return server.rstrip("/")


def _account_snapshot_for_suffix(suffix):
    """
    suffix:
      ""  -> server / username / password
      "1" -> server1 / username1 / password1
      "2" -> server2 / username2 / password2
    """
    server_key = "server{}".format(suffix) if suffix else "server"
    username_key = "username{}".format(suffix) if suffix else "username"
    password_key = "password{}".format(suffix) if suffix else "password"

    server = _normalise_server(_setting(server_key, ""))
    username = str(_setting(username_key, "") or "").strip()
    password = str(_setting(password_key, "") or "").strip()

    if not server or not username or not password:
        giptv.log(
            "Service account skipped: suffix={} configured=False".format(
                suffix or "default"
            ),
            xbmc.LOGINFO,
        )
        return None

    return {
        "server": server,
        "username": username,
        "password": password,
        "account_suffix": suffix,
    }


def get_configured_account_snapshots():
    snapshots = []
    seen = set()

    for suffix in ("", "1", "2"):
        snapshot = _account_snapshot_for_suffix(suffix)
        if not snapshot:
            continue

        key = "{}|{}".format(
            snapshot.get("server", "").rstrip("/"),
            snapshot.get("username", ""),
        )

        if key in seen:
            giptv.log(
                "Service account skipped duplicate: suffix={} key={}".format(
                    suffix or "default",
                    key,
                ),
                xbmc.LOGINFO,
            )
            continue

        seen.add(key)
        snapshots.append(snapshot)

    giptv.log(
        "Service found {} configured account snapshot(s) for indexing".format(
            len(snapshots)
        ),
        xbmc.LOGINFO,
    )

    return snapshots


# ============================================================
#  STATE / INDEX HELPERS
# ============================================================


def refresh_runtime_state(reason="service"):
    try:
        ok = ensure_api_ready()
        giptv.log(
            "Service STATE refresh reason={} ok={}".format(reason, ok),
            xbmc.LOGINFO,
        )
        return ok
    except Exception as e:
        giptv.log(
            "Service STATE refresh failed reason={} error={}".format(reason, e),
            xbmc.LOGWARNING,
        )
        return False


def queue_all_configured_account_indexes(monitor, source):
    snapshots = get_configured_account_snapshots()

    if not snapshots:
        giptv.log(
            "Service index queue skipped: no configured accounts | source={}".format(
                source
            ),
            xbmc.LOGWARNING,
        )
        return False

    try:
        from resources.lib.manager.index_manager import (
            queue_build_indexes_for_snapshots,
        )

        queued = queue_build_indexes_for_snapshots(
            snapshots=snapshots,
            monitor=monitor,
            notify=False,
            source=source,
            force=False,
        )

        giptv.log(
            "Service account index queue complete | source={} queued={}".format(
                source,
                queued,
            ),
            xbmc.LOGINFO,
        )

        return queued > 0

    except Exception as e:
        giptv.log(
            "Service account index queue failed | source={} error={}".format(
                source,
                e,
            ),
            xbmc.LOGWARNING,
        )
        return False


def queue_startup_index_check(monitor):
    refresh_runtime_state("startup_index")
    return queue_all_configured_account_indexes(
        monitor=monitor,
        source="startup_all_accounts",
    )


def handle_settings_changed(monitor):
    global _LAST_SETTINGS_SNAPSHOT
    giptv.log("Settings Changed", xbmc.LOGINFO)

    current_snapshot = _tracked_settings_snapshot()
    changed = {
        key
        for key, value in current_snapshot.items()
        if _LAST_SETTINGS_SNAPSHOT.get(key) != value
    }
    _LAST_SETTINGS_SNAPSHOT = current_snapshot

    if not changed:
        try:
            giptv.container_refresh()
        except Exception:
            pass
        giptv.log(
            "Service: UI-only settings change handled without provider rebuild",
            xbmc.LOGINFO,
        )
        return False

    # Token refreshes update four hidden settings. They must not rebuild the
    # Xtream index, EPG, PVR playlist, and provider inventory each time.
    if changed and changed.issubset(_TRAKT_SETTING_IDS):
        try:
            from resources.apis.trakt_api import request_trakt_warm

            request_trakt_warm(force_refresh=False)
        except Exception:
            pass
        giptv.log(
            "Service: handled Trakt-only settings change without provider rebuild",
            xbmc.LOGINFO,
        )
        return False

    refresh_runtime_state("settings_changed")

    try:
        import resources.apis.xtream_api as xtream_api

        if hasattr(xtream_api, "reset_session"):
            xtream_api.reset_session()
    except Exception as e:
        giptv.log(
            "Service: xtream session reset failed: {}".format(e),
            xbmc.LOGWARNING,
        )

    try:
        from resources.lib.manager import index_manager

        index_manager._clear_index_read_cache()
    except Exception:
        pass

    try:
        from resources.lib.manager import epg_manager

        epg_manager._request_epg_refresh()
    except Exception as e:
        giptv.log(
            "Service: EPG refresh after settings change failed: {}".format(e),
            xbmc.LOGWARNING,
        )

    try:
        from resources.lib.iptv_simple_manager import request_sync

        request_sync(force=True)
    except Exception as e:
        giptv.log(
            "Service: IPTV Simple sync request failed: {}".format(e),
            xbmc.LOGWARNING,
        )

    try:
        from resources.lib.library_health import request_check

        request_check(force=True, notify=True)
    except Exception as e:
        giptv.log(
            "Service: saved stream health request failed: {}".format(e),
            xbmc.LOGWARNING,
        )

    try:
        from resources.apis.trakt_api import request_trakt_warm

        request_trakt_warm(force_refresh=False)
    except Exception as e:
        giptv.log(
            "Service: Trakt warm request failed: {}".format(e), xbmc.LOGWARNING
        )

    try:
        giptv.container_refresh()
    except Exception as e:
        giptv.log(
            "Service: container refresh failed: {}".format(e),
            xbmc.LOGWARNING,
        )

    return queue_all_configured_account_indexes(
        monitor=monitor,
        source="settings_changed_all_accounts",
    )


# ============================================================
#  SETTINGS MONITOR
# ============================================================


class SettingsMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        handle_settings_changed(self)


# ============================================================
#  SHUTDOWN HELPERS
# ============================================================


def shutdown_index_worker():
    try:
        from resources.lib.manager.index_manager import (
            shutdown_index_worker as _shutdown,
        )

        _shutdown(wait=False)
    except Exception as e:
        giptv.log(
            "Service shutdown: index worker cleanup failed: {}".format(e),
            xbmc.LOGWARNING,
        )


def shutdown_trakt_state():
    try:
        from resources.lib.player import trakt_scrobbler

        trakt_scrobbler.stop_and_clear_current_playback("service_shutdown")
    except Exception as e:
        giptv.log(
            "Service shutdown: trakt cleanup failed: {}".format(e),
            xbmc.LOGWARNING,
        )


def shutdown_proxy():
    try:
        stop_proxy()
    except Exception as e:
        giptv.log(
            "Service shutdown: stop_proxy failed: {}".format(e),
            xbmc.LOGWARNING,
        )


def shutdown_navigator_pool():
    try:
        from resources.lib import navigator

        navigator.shutdown_thread_pool(wait=False)
    except Exception as e:
        giptv.log(
            "Service shutdown: navigator pool shutdown failed: {}".format(e),
            xbmc.LOGWARNING,
        )


def shutdown_epg_worker():
    try:
        from resources.lib.manager.epg_manager import shutdown_epg_worker as _shutdown

        _shutdown(wait=False)
    except Exception as e:
        giptv.log(
            "Service shutdown: epg cleanup failed: {}".format(e),
            xbmc.LOGWARNING,
        )


def shutdown_picon_workers():
    try:
        from resources.lib.cache.picon_cache import shutdown_picon_workers as _shutdown

        _shutdown(wait=False)
    except Exception as e:
        giptv.log(
            "Service shutdown: picon cleanup failed: {}".format(e),
            xbmc.LOGWARNING,
        )


def shutdown_xtream_session():
    try:
        import resources.apis.xtream_api as xtream_api

        if hasattr(xtream_api, "reset_session"):
            xtream_api.reset_session()
    except Exception as e:
        giptv.log(
            "Service shutdown: xtream session cleanup failed: {}".format(e),
            xbmc.LOGWARNING,
        )


def shutdown_all():
    giptv.log("Service shutting down", xbmc.LOGINFO)

    shutdown_index_worker()
    shutdown_trakt_state()
    shutdown_proxy()
    shutdown_navigator_pool()
    shutdown_epg_worker()
    shutdown_picon_workers()
    shutdown_xtream_session()


# ============================================================
#  MAIN SERVICE LOOP
# ============================================================

if __name__ == "__main__":
    monitor = SettingsMonitor()

    trakt_player = TraktPlayer()
    proxy_player = ProxyPlayer()
    history_player = HistoryPlayer()

    giptv.log("Trakt player monitor initialized", xbmc.LOGINFO)
    giptv.log("Proxy player monitor initialized", xbmc.LOGINFO)
    giptv.log("History player monitor initialized", xbmc.LOGINFO)

    xbmc.sleep(3000)

    try:
        run_update_tasks_once()
    except Exception as e:
        giptv.log(
            "Service: update tasks failed: {}".format(e),
            xbmc.LOGWARNING,
        )

    queue_startup_index_check(monitor)

    try:
        from resources.lib.iptv_simple_manager import request_sync

        request_sync(force=False)
    except Exception as e:
        giptv.log(
            "Service: startup IPTV Simple sync failed: {}".format(e),
            xbmc.LOGWARNING,
        )

    try:
        from resources.lib.library_health import request_check

        request_check(force=False, notify=True)
    except Exception as e:
        giptv.log(
            "Service: startup saved stream health check failed: {}".format(e),
            xbmc.LOGWARNING,
        )

    try:
        from resources.apis.trakt_api import request_trakt_warm

        request_trakt_warm(force_refresh=False)
    except Exception as e:
        giptv.log(
            "Service: startup Trakt warm failed: {}".format(e), xbmc.LOGWARNING
        )

    giptv.log("Entering main monitor loop", xbmc.LOGINFO)

    try:
        maintenance_tick = 0
        while not monitor.abortRequested():
            if monitor.waitForAbort(1):
                break
            maintenance_tick += 1
            if maintenance_tick >= 60:
                maintenance_tick = 0
                try:
                    from resources.lib.iptv_simple_manager import maintenance

                    maintenance()
                except Exception as e:
                    giptv.log(
                        "Service: IPTV Simple maintenance failed: {}".format(e),
                        xbmc.LOGWARNING,
                    )
                try:
                    from resources.lib.library_health import request_check

                    request_check(force=False, notify=True)
                except Exception as e:
                    giptv.log(
                        "Service: saved stream health maintenance failed: {}".format(
                            e
                        ),
                        xbmc.LOGWARNING,
                    )
                try:
                    from resources.apis.trakt_api import request_trakt_warm

                    request_trakt_warm(force_refresh=False)
                except Exception as e:
                    giptv.log(
                        "Service: Trakt cache maintenance failed: {}".format(e),
                        xbmc.LOGWARNING,
                    )

    finally:
        shutdown_all()
