"""GIPTV add-on package marker used by IPTV Merge discovery."""
